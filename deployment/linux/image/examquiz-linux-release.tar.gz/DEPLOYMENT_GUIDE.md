# 📘 Guide Complet de Déploiement Pas-à-Pas — Plateforme ExamQuiz (Linux & Windows)

Ce document décrit étape par étape la procédure de déploiement, d'initialisation, d'exploitation et d'exportation des notes finales de la plateforme **ExamQuiz** sous **Linux** et sous **Windows** (en mode autonome LAN / Salle de TP ou en mode conteneurisé Docker).

---

## 📂 1. Organisation des Dossiers de Déploiement & d'Archivage

```text
ExaminationQuiz APP/
├── deploy.sh                     # Script global de déploiement (.sh) à la racine
├── deploy.bash                   # Point d'entrée Bash (.bash) à la racine
├── setup_and_seed.sh             # Script rapide de réinitialisation & peuplement de la BDD
├── logins.txt                    # Récapitulatif de tous les identifiants (Admin, Enseignants, 16 Étudiants)
├── DEPLOYMENT_GUIDE.md           # Documentation détaillée pas-à-pas (ce document)
│
├── archive_data/                 # 📦 Dossier de conservation des données & modèles d'examens
│   ├── README_ARCHIVE.md
│   ├── exams_backup/             # Sauvegarde JSON + snapshot SQLite avant purge de déploiement
│   ├── templates/                # Modèles JSON d'examens (Python, Cryptographie, Linux)
│   └── question_banks/           # Banques complètes (414 QCM + 183 Exos + 47 Défis Python + Linux)
│
├── deploy/
│   ├── linux/                    # 🐧 Dossier dédié au déploiement LINUX
│   │   ├── image/
│   │   │   └── examquiz-linux-release.tar.gz   # Image finale autonome Linux
│   │   ├── install_and_deploy.sh               # Installation + peuplement BDD + lancement
│   │   ├── install_and_deploy.bash             # Variante .bash
│   │   ├── init_test_db.sh                     # Réinitialisation propre des données de test
│   │   ├── start_server.sh / stop_server.sh    # Démarrage / arrêt du serveur Uvicorn (port 8000)
│   │   ├── build_linux_image.sh                # Générateur de l'image finale Linux (.tar.gz / Docker .tar)
│   │   ├── load_linux_image.sh                 # Déploiement direct depuis l'image finale Linux
│   │   ├── Dockerfile.linux & docker-compose.linux.yml
│   │   ├── examquiz.service                    # Service systemd pour démarrage automatique Linux
│   │   └── README_LINUX.md
│   │
│   └── windows/                  # 🪟 Dossier dédié au déploiement WINDOWS
│       ├── image/
│       │   └── examquiz-windows-release.zip    # Image finale autonome Windows
│       ├── install_and_deploy.bat              # Script Windows Batch (Invite de commandes)
│       ├── install_and_deploy.ps1              # Script Windows PowerShell
│       ├── install_and_deploy.sh / .bash       # Scripts Bash pour Git Bash / WSL sous Windows
│       ├── init_test_db.bat / init_test_db.sh  # Réinitialisation propre des données de test
│       ├── start_server.bat / stop_server.bat  # Démarrage / arrêt du serveur Windows (port 8000)
│       ├── build_windows_image.bat             # Générateur de l'image finale Windows (.zip)
│       ├── load_windows_image.bat              # Extraction et lancement direct de l'image Windows
│       ├── Dockerfile.windows & docker-compose.windows.yml
│       └── README_WINDOWS.md
```

---

## 🐧 2. Déploiement Pas-à-Pas sous LINUX (`deploy/linux/`)

### Option A — Déploiement depuis l'Image Finale Linux (`deploy/linux/image/`)
1. Copiez le dossier `deploy/linux/` (ou uniquement `deploy/linux/image/examquiz-linux-release.tar.gz` et `deploy/linux/load_linux_image.sh`) sur le serveur Linux cible.
2. Ouvrez un terminal et rendez les scripts exécutables :
   ```bash
   chmod +x deploy/linux/*.sh deploy/linux/*.bash
   ```
3. Lancez le chargeur d'image (extrait automatiquement l'application dans `/opt/examquiz`, configure `.venv`, initialise la base de données avec les comptes de test et démarre le serveur) :
   ```bash
   sudo ./deploy/linux/load_linux_image.sh /opt/examquiz
   ```

### Option B — Déploiement Direct par Script Bash (`install_and_deploy.sh`)
Depuis la racine du projet sous Linux :
```bash
chmod +x deploy.sh deploy.bash setup_and_seed.sh deploy/linux/*.sh
./deploy/linux/install_and_deploy.sh
```
Le script exécute automatiquement les 4 étapes suivantes :
1. Vérifie/installe `python3` et `python3-venv`, puis crée l'environnement virtuel `.venv`.
2. Installe toutes les dépendances depuis `requirements.txt`.
3. Exécute `scripts/reset_and_seed_exact_3_exams.py` pour purger les anciens examens et insérer l'Administrateur, les 3 modules avec leurs enseignants, les 4 classes de 4 étudiants et les examens modèles.
4. Démarre le serveur de production `uvicorn` sur `0.0.0.0:8000` et affiche l'adresse IP LAN de la salle.

### Option C — Installation en tant que Service `systemd` (Démarrage Automatique)
```bash
./deploy/linux/install_and_deploy.sh --systemd
sudo systemctl status examquiz.service
```

### Option D — Déploiement Docker sous Linux
```bash
./deploy/linux/install_and_deploy.sh --docker
# ou manuellement :
docker compose -f deploy/linux/docker-compose.linux.yml up -d --build
```

---

## 🪟 3. Déploiement Pas-à-Pas sous WINDOWS (`deploy/windows/`)

### Option A — Déploiement depuis l'Image Finale Windows (`deploy/windows/image/`)
1. Copiez `deploy\windows\image\examquiz-windows-release.zip` (ou l'ensemble du dossier `deploy\windows\`) sur le poste ou serveur Windows cible.
2. Double-cliquez sur `deploy\windows\load_windows_image.bat` (ou décompressez `examquiz-windows-release.zip` dans `C:\ExamQuiz` puis lancez `deploy\windows\install_and_deploy.bat`).

### Option B — Déploiement via Invite de Commandes (`.bat`) ou PowerShell (`.ps1`)
- **Via Invite de commandes (CMD)** :
  ```bat
  deploy\windows\install_and_deploy.bat
  ```
- **Via PowerShell** :
  ```powershell
  powershell -ExecutionPolicy Bypass -File .\deploy\windows\install_and_deploy.ps1
  ```

### Option C — Déploiement via Git Bash ou WSL sous Windows (`.sh` / `.bash`)
```bash
bash deploy/windows/install_and_deploy.sh
# ou depuis la racine :
bash deploy.sh
```

### Option D — Déploiement Docker Desktop sous Windows
```powershell
docker compose -f deploy/windows/docker-compose.windows.yml up -d --build
```

---

## 👥 4. Données de Test Pré-Configurées au Déploiement

Lors du déploiement (ou à tout moment via `./setup_and_seed.sh` ou `deploy/linux/init_test_db.sh` / `deploy\windows\init_test_db.bat`), la base de données est nettoyée de tout ancien examen et peuplée avec :

### 4.1 Administrateur Principal
| Rôle | Identifiant | Mot de passe | Nom Complet | Email |
| :--- | :--- | :--- | :--- | :--- |
| **Super Admin** | `admin` | `Admin123!` | Administrateur Principal | `admin@ecole.fr` |

### 4.2 Les 3 Modules de Test & Leurs Enseignants Associés
| Code Module | Intitulé du Module | Identifiant Enseignant | Mot de passe | Nom de l'Enseignant |
| :--- | :--- | :--- | :--- | :--- |
| **`PYTHON_INIT`** | Programmation Python & Algorithmique | `prof_python` | `ProfPython1!` | Dr. Martin Laurent (Resp. Python) |
| **`CRYPTO`** | Cryptographie & Sécurité | `prof_crypto` | `ProfCrypto1!` | Dr. Sophie Bernard (Resp. Crypto) |
| **`LINUX_ADMIN`** | Administration Système Linux | `prof_linux` | `ProfLinux1!` | Dr. Karim Mansouri (Resp. Linux) |
| *(Tous modules)* | Coordinateur Pédagogique | `prof_martin` | `prof123` | Dr. Martin Laurent |

### 4.3 Les 4 Classes de 4 Étudiants (16 Étudiants Complets)

#### Classe 1 : `DEV-IA` (*Développement & IA*)
| Matricule | Identifiant | Mot de passe | Nom Complet | Email | Promotion |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `ETU-ETU_DEV1` | `etu_dev1` | `StudentDev1!` | Alice Dev (IA-1) | `alice.dev@exam.local` | `2025-2026` |
| `ETU-ETU_DEV2` | `etu_dev2` | `StudentDev2!` | Bob Dev (IA-2) | `bob.dev@exam.local` | `2025-2026` |
| `ETU-ETU_DEV3` | `etu_dev3` | `StudentDev3!` | Clara Dev (IA-3) | `clara.dev@exam.local` | `2025-2026` |
| `ETU-ETU_DEV4` | `etu_dev4` | `StudentDev4!` | David Dev (IA-4) | `david.dev@exam.local` | `2025-2026` |

#### Classe 2 : `SYS-ADMIN` (*Systèmes & Réseaux Linux*)
| Matricule | Identifiant | Mot de passe | Nom Complet | Email | Promotion |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `ETU-ETU_SYS1` | `etu_sys1` | `StudentSys1!` | Emma Sys (Linux-1) | `emma.sys@exam.local` | `2025-2026` |
| `ETU-ETU_SYS2` | `etu_sys2` | `StudentSys2!` | Fares Sys (Linux-2) | `fares.sys@exam.local` | `2025-2026` |
| `ETU-ETU_SYS3` | `etu_sys3` | `StudentSys3!` | Gilles Sys (Linux-3) | `gilles.sys@exam.local` | `2025-2026` |
| `ETU-ETU_SYS4` | `etu_sys4` | `StudentSys4!` | Hajar Sys (Linux-4) | `hajar.sys@exam.local` | `2025-2026` |

#### Classe 3 : `CYBER-SEC` (*Cybersécurité & Cryptographie*)
| Matricule | Identifiant | Mot de passe | Nom Complet | Email | Promotion |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `ETU-ETU_SEC1` | `etu_sec1` | `StudentSec1!` | Ines Sec (Crypto-1) | `ines.sec@exam.local` | `2025-2026` |
| `ETU-ETU_SEC2` | `etu_sec2` | `StudentSec2!` | Jules Sec (Crypto-2) | `jules.sec@exam.local` | `2025-2026` |
| `ETU-ETU_SEC3` | `etu_sec3` | `StudentSec3!` | Karim Sec (Crypto-3) | `karim.sec@exam.local` | `2025-2026` |
| `ETU-ETU_SEC4` | `etu_sec4` | `StudentSec4!` | Lena Sec (Crypto-4) | `lena.sec@exam.local` | `2025-2026` |

#### Classe 4 : `GRP-1` (*Génie Logiciel & Systèmes — Groupe 1*)
| Matricule | Identifiant | Mot de passe | Nom Complet | Email | Promotion |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `ETU-001` | `etudiant1` | `etu123` | Alice Dupont (GL-1) | `etudiant1@exam.local` | `2025-2026` |
| `ETU-ETU_LOG2` | `etu_log2` | `StudentLog2!` | Thomas Garnier (GL-2) | `thomas.log@exam.local` | `2025-2026` |
| `ETU-ETU_LOG3` | `etu_log3` | `StudentLog3!` | Camille Chevalier (GL-3) | `camille.log@exam.local` | `2025-2026` |
| `ETU-ETU_LOG4` | `etu_log4` | `StudentLog4!` | Maxime Lambert (GL-4) | `maxime.log@exam.local` | `2025-2026` |

### 4.4 Examens Modèles Pré-Insérés pour les 3 Modules
1. **`EXAM-THEO-PYTHON`** — *Épreuve Officielle : Théorie Python* (`PYTHON_INIT`, Volet Théorique, 45 min, `/20`)
2. **`EXAM-PRAC-PYTHON`** — *Épreuve Officielle : Pratique Python* (`PYTHON_INIT`, Volet Pratique sur machine avec 5 défis algorithmiques, 60 min, `/20`)
3. **`EXAM-THEO-CRYPTO`** — *Épreuve Officielle : Théorie Cryptographie* (`CRYPTO`, Volet Théorique, 45 min, `/20`)
4. **`EXAM-THEO-LINUX`** — *Épreuve Officielle : Administration Système Linux* (`LINUX_ADMIN`, Volet Théorique POSIX/FHS, 45 min, `/20`)

---

## 📥 5. Téléchargement des Notes Finales de Tous les Étudiants à Chaque Examen

À l'issue de chaque examen (ou à tout moment pendant/après la session), l'enseignant du module ou l'administrateur peut télécharger **en un clic** le relevé complet des notes finales de **tous les étudiants** inscrits :

1. **Depuis le Tableau de Bord Enseignant (`Mes Épreuves & Examens`)** :
   - Sur la ligne de chaque examen, cliquez sur :
     - **`📥 Notes CSV`** : Télécharge le fichier `notes_finales_<MODULE>_<EXAM_ID>.csv` (encodage UTF-8 avec BOM pour ouverture directe dans Microsoft Excel / LibreOffice Calc) contenant les 16 étudiants (ou les classes assignées), leur matricule, classe, statut (`Soumis` / `Non présenté`), score brut, note finale `/20` et décision (`Validé` / `Ajourné` / `Absent`).
     - **`📄 PV Notes PDF`** : Génère et télécharge le Procès-Verbal officiel au format PDF paysage (`pv_notes_finales_<MODULE>_<EXAM_ID>.pdf`) avec l'en-tête récapitulatif (inscrits, copies soumises, moyenne de l'épreuve) et le tableau complet des étudiants.

2. **Depuis la Salle de Surveillance en Direct (`🖥️ Surveiller` / Live Proctoring)** :
   - Après avoir cliqué sur `🛑 Clôturer l'Épreuve` (ou à tout moment dans la barre d'outils de la salle), cliquez directement sur **`📥 Notes Finales (CSV)`** ou **`📄 PV Notes (PDF)`**.

3. **Depuis l'Interface Administrateur (`Examens & Surveillance` et `Bulletins Académiques`)** :
   - Dans l'onglet **Examens**, chaque épreuve dispose des boutons **`📥 Notes CSV`** et **`📄 PV PDF`**.
   - Dans l'onglet **Bulletins Académiques**, vous pouvez également filtrer par **Spécialité/Classe** et par **Module** pour télécharger le PV de classe combinant Volet Théorique + Volet Pratique + Moyenne, ainsi que les bulletins individuels PDF/DOCX/ZIP.

