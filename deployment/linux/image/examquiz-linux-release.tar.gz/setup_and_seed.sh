#!/usr/bin/env bash
# ==============================================================================
# ExamQuiz Platform — Script d'Initialisation & Peuplement de la Base de Données
# Purge les anciens examens, archive les banques dans archive_data/, et insère :
#   - 1 Administrateur (admin / Admin123!)
#   - 3 Modules (PYTHON_INIT, CRYPTO, LINUX_ADMIN) + leurs enseignants dédiés
#   - 4 Classes × 4 Étudiants = 16 Étudiants complets
#   - 4 Examens Modèles (Théorie Python, Pratique Python, Cryptographie, Linux)
# ==============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ -f ".venv/bin/python" ]; then
    PY_BIN=".venv/bin/python"
elif [ -f ".venv/Scripts/python.exe" ]; then
    PY_BIN=".venv/Scripts/python.exe"
elif command -v python3 &>/dev/null; then
    PY_BIN="python3"
else
    PY_BIN="python"
fi

echo "🔄 Réinitialisation et amorçage des données de déploiement..."
"$PY_BIN" scripts/reset_and_seed_exact_3_exams.py
echo "✅ Opération terminée. Consultez logins.txt pour tous les identifiants."

