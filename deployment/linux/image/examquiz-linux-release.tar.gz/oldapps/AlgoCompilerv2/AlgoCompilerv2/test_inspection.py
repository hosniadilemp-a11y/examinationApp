import re

with open('Exos/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Find math formulas
inline = re.findall(r'(?<!\$)\$(?!\$)(.+?)(?<!\$)\$(?!\$)', content)
block = re.findall(r'\$\$(.+?)\$\$', content, re.DOTALL)
print(f'Inline math occurrences: {len(inline)}')
print(f'Block math occurrences: {len(block)}')

# Check for any unclosed $ or weird LaTeX
odd_dollars = []
for line_no, line in enumerate(content.splitlines(), 1):
    # ignore script tags and code
    if '<script' in line or '</script>' in line or 'function' in line or '`' in line:
        continue
    # count non-escaped $
    d_count = line.count('$')
    if d_count % 2 != 0:
        odd_dollars.append((line_no, line))

print(f'Lines with odd number of $: {len(odd_dollars)}')
for lno, l in odd_dollars[:10]:
    print(f'Line {lno}: {l}')
