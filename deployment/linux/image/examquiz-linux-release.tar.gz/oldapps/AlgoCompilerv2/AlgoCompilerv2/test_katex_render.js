const fs = require('fs');
const katex = require('./AlgoExamination/client/node_modules/katex');

const html = fs.readFileSync('Exos/index.html', 'utf-8');
const body = html.split('<script>')[0];

// Extract math
const inlineRegex = /(?<!\$)\$(?!\$)(.+?)(?<!\$)\$(?!\$)/g;
const blockRegex = /\$\$(.+?)\$\$/gs;

let match;
let totalInline = 0;
let errorsInline = 0;
while ((match = inlineRegex.exec(body)) !== null) {
    totalInline++;
    const formula = match[1];
    try {
        katex.renderToString(formula, { displayMode: false, throwOnError: true });
    } catch (e) {
        errorsInline++;
        console.error(`INLINE ERROR at [${match.index}]: "${formula}" -> ${e.message}`);
    }
}

let totalBlock = 0;
let errorsBlock = 0;
while ((match = blockRegex.exec(body)) !== null) {
    totalBlock++;
    const formula = match[1];
    try {
        katex.renderToString(formula, { displayMode: true, throwOnError: true });
    } catch (e) {
        errorsBlock++;
        console.error(`BLOCK ERROR at [${match.index}]: "${formula}" -> ${e.message}`);
    }
}

console.log(`Summary: Inline tested: ${totalInline}, Errors: ${errorsInline}`);
console.log(`Summary: Block tested: ${totalBlock}, Errors: ${errorsBlock}`);
