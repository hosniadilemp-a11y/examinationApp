with open('Exos/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

exercises = [
    "Exercice 1 : Rotation des Anneaux d'une Matrice",
    "Exercice 2 : ADN Équilibré (Bear and Steady Gene)",
    "Exercice 3 : Filtre Médian 2D pour Débruitage d'Image",
    "Exercice 4 : Triplets Magnifiques (Beautiful Triplets)"
]

for ex in exercises:
    print(f"Checking '{ex}':", ex in text)

print("Checking AlgoCompiler code presence:")
print("01 code:", "ALGORITHME RotationAnneauxMatrice" in text)
print("02 code:", "ALGORITHME GeneEquilibre" in text)
print("03 code:", "ALGORITHME FiltreMedian2D" in text)
print("04 code:", "ALGORITHME TripletsMagnifiques" in text)
