# 📋 Spécifications Fonctionnelles et Techniques — Interface Enseignant (AlgoExamination)

---

## 1. 🗑️ Suppression du Bouton Prototype IA
- **Description** : Retirer le bouton d'accès au module expérimental "Lab Prototype IA" (`LocalAIEvaluatorPrototype.jsx`) de l'interface Enseignant (`TeacherDashboard.jsx`).
- **Comportement Attendu** :
  - Masquer/supprimer le bouton ou l'onglet "Lab Prototype IA" de la navigation du tableau de bord de l'enseignant.
  - Conserver le composant sous-jacent sans impacter le reste de l'application.

---

## 2. ⚖️ Règle de Correction Déterministe Hybride (Sans Module IA)
- **Description** : Ignorer temporairement le module d'évaluation par LLM/IA et appliquer le nouveau barème déterministe combinant Tests Unitaires et Analyse Structurelle AST des algorithmes.
- **Règles de Calcul des Notes** :
  - **Cas 1 : Au moins 1 test unitaire est réussi (`passedTests > 0`)** :
    - **50%** de la note attribués aux Tests Unitaires au prorata des tests réussis : `(passedTests / totalTests) * 50% * NoteMax`.
    - **50%** de la note attribués à l’Analyse Structurelle AST (vérification de la syntaxe algorithmique, boucles, conditions, types).
  - **Cas 2 : Aucun test unitaire n'est réussi (`passedTests == 0`)** :
    - **20%** de la note réservés aux Tests Unitaires (donne `0 Pts` sur la partie tests).
    - **80%** de la note attribués à l’Analyse Structurelle AST (pour valoriser la structure du code et l'effort algorithmique de l'étudiant même en cas d'erreur à l'exécution).

---

## 3. 🎓 Gestion des Étudiants & Calcul Automatique de l'Année Scolaire
- **Description** : Enrichir le module "Gestion des Étudiants" (`StudentManager.jsx`) avec la gestion de l'Année Scolaire.
- **Règle Métier de l'Année Scolaire** :
  - Une année scolaire commence le **1er Septembre** de chaque année (ex: à partir du 1er Septembre 2025, l'année scolaire courante est l'année entière `2026`).
  - Si l'année scolaire n'est pas renseignée lors de la création d'un étudiant (manuelle ou import), le système la calcule et l'affecte **automatiquement par défaut** au format entier (ex: `2026`).
  - Ajout du champ `academicYear` / `annéeScolaire` dans le modèle `Student` de la base de données et dans les formulaires/tableaux d'étudiants.

---

## 4. 🧩 Page Dédiée à la Création / Édition de Problèmes ("Problem Creation Studio")
- **Points d'Accès** :
  1. Bouton "Nouveau Problème" dans la **Banque de Problèmes Algorithmiques**.
  2. Étape 3 ("Exercices & Attribution du Barème") du créateur d'examens.

- **Fonctionnalités Détaillées** :
  - **a. Auto-Sélection & Persistence DB** : Lorsqu'un problème est créé à partir de l'assistant de création d'examen, il est immédiatement enregistré en base de données (`Problem`) et automatiquement rattaché à la liste d'exercices de l'examen en cours d'édition (brouillon UI puis finalisé dans `ExamProblem` lors de la sauvegarde de l'examen).
  - **b. Éditeur Markdown avec Prévisualisation Temps Réel** : Éditeur de description du sujet en Markdown avec volet de prévisualisation HTML instantanée.
  - **c. Éditeur de Code Template & Palette de Briques Algorithmiques** :
    - Éditeur de code algorithmique identique à l'environnement étudiant (CodeMirror avec coloration syntaxique `ALGO`).
    - Palette interactive de briques algorithmiques (`Lire Tableau`, `Afficher Tableau`, `Tri`, `Recherche`, etc.) testables et configurables par l'enseignant.
  - **d. Éditeur de Solution de Référence & Exécution des Tests** :
    - Éditeur séparé pour la solution officielle de référence.
    - Exécution interactive de la solution de référence contre la suite de tests directement dans l'interface de création avec retours détaillés test par test.
  - **e. Import / Export JSON via l'Interface UI** :
    - Boutons d'exportation pour télécharger le problème (ou l'examen complet) sous forme de fichier `.json`.
    - Boutons d'importation pour charger un problème ou un examen à partir d'un fichier `.json`.
  - **f. Gestionnaire de Cas de Tests Unitaires** :
    - Interface complète pour ajouter, modifier et supprimer des cas de tests (Entrées, Sorties attendues, Points/Pondération, Masqué/Visible).

---

## 5. 📁 Exportation et Persistence JSON des Problèmes et Examens (Côté UI)
- **Description** : Permettre à l'enseignant de télécharger et d'importer la structure complète des problèmes et des examens au format `.json` standardisé depuis l'interface utilisateur.

---

## 6. 🔍 Filtrage Multi-Critères pour l'Attribution des Examens aux Étudiants
- **Location** : Étape 4 du créateur d'examen ("Attribution des Étudiants").
- **Fonctionnalités** :
  - Affichage de la liste complète des étudiants inscrits.
  - Barre de filtres dynamiques combinables par :
    - **Groupe** (ex. G01, G02, G03)
    - **Spécialité** (ex. 1CP, 2CP, CS)
    - **Année Scolaire** (ex. 2026)
  - Boutons d'action rapide : "Tout Sélectionner les étudiants filtrés" / "Tout Désélectionner".