import re

with open('Exos/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Extract only the HTML body before <script>
body_content = content.split('<script>')[0]

# Find all inline $...$ and block $$...$$
inline_matches = re.findall(r'(?<!\$)\$(?!\$)(.+?)(?<!\$)\$(?!\$)', body_content)
block_matches = re.findall(r'\$\$(.+?)\$\$', body_content, re.DOTALL)

with open('math_report.txt', 'w', encoding='utf-8') as out:
    out.write(f"Total inline math: {len(inline_matches)}\n")
    out.write(f"Total block math: {len(block_matches)}\n\n")
    out.write("--- INLINE MATH SAMPLES ---\n")
    for i, m in enumerate(inline_matches):
        out.write(f"[{i+1}] {m}\n")
    out.write("\n--- BLOCK MATH SAMPLES ---\n")
    for i, m in enumerate(block_matches):
        out.write(f"[{i+1}] {m.strip()}\n")

print(f"Total inline: {len(inline_matches)}, Total block: {len(block_matches)}")
