# Simulate the JS DNA algorithm exactly
def simulate(dnaSequence):
    dnaLen = len(dnaSequence)
    dnaTargetFreq = dnaLen // 4
    dnaCountsOut = { 'A': 0, 'C': 0, 'G': 0, 'T': 0 }
    for c in dnaSequence:
        dnaCountsOut[c] += 1
    
    dnaLeftPtr = 0
    dnaRightPtr = 0
    dnaMinFound = dnaLen
    dnaBestL = 0
    dnaBestR = dnaLen - 1

    def isOutsideValid():
        return all(dnaCountsOut[b] <= dnaTargetFreq for b in ['A', 'C', 'G', 'T'])

    def step():
        nonlocal dnaLeftPtr, dnaRightPtr, dnaMinFound, dnaBestL, dnaBestR
        if dnaRightPtr > dnaLen:
            return False

        if isOutsideValid() and dnaLeftPtr < dnaRightPtr:
            curLen = dnaRightPtr - dnaLeftPtr
            if curLen < dnaMinFound:
                dnaMinFound = curLen
                dnaBestL = dnaLeftPtr
                dnaBestR = dnaRightPtr - 1
            charL = dnaSequence[dnaLeftPtr]
            dnaCountsOut[charL] += 1
            dnaLeftPtr += 1
        else:
            if dnaRightPtr < dnaLen:
                charR = dnaSequence[dnaRightPtr]
                dnaCountsOut[charR] -= 1
                dnaRightPtr += 1
            else:
                dnaRightPtr += 1

        if isOutsideValid() and dnaLeftPtr < dnaRightPtr:
            curLen = dnaRightPtr - dnaLeftPtr
            if curLen < dnaMinFound:
                dnaMinFound = curLen
                dnaBestL = dnaLeftPtr
                dnaBestR = dnaRightPtr - 1
        return True

    safety = 0
    while dnaRightPtr <= dnaLen and safety < 100:
        safety += 1
        if not step():
            break
    
    print(f"Sequence: {dnaSequence}")
    print(f"MinFound: {dnaMinFound}, Best: [{dnaBestL}..{dnaBestR}] = '{dnaSequence[dnaBestL:dnaBestR+1]}'")
    print(f"Final Pointers at end of loop: Left={dnaLeftPtr}, Right={dnaRightPtr}")

simulate("GAAATAAA")
simulate("TGATGCCGTCCCCTCA")
