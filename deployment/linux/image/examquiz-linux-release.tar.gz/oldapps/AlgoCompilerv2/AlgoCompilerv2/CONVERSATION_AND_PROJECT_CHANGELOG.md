# Historique Complet de la Session & Journal des Modifications (Changelog)

**Date :** 30 Août 2026  
**Projet :** AlgoCompilerv2 — Plateforme d'Examen et de Correction Algorithmique (AlgoExamination & AlgoCompiler)  
**Branche Principale (Sauvegardée) :** `main`  
**Branche de Travail Créée :** `develop`  

---

## 1. Contexte & Problématique Initiale

### A. Incohérence des Notes & Module Scoring (Single Source of Truth)
- **Constat :** Des divergences existaient entre les scores calculés par les modules d'analyse (Tests automatiques, Analyse de structure AST) et la note finale affichée pour l'étudiant (`CC0001` - BELKACEM).
- **Solution Appliquée :**
  - Centralisation intégrale du calcul des notes côté serveur (`grading.controller.js`).
  - Ajout des fonctions `evaluateSingleSubmission` et `recalculateStudentAssignmentFinalScore`.
  - Création des endpoints API `/api/exams/:id/calculate-exercise` et `/api/exams/:id/recalculate-all`.
  - L'interface React (`CorrectionWorkspace.jsx`) ne calcule plus les notes localement : elle reçoit et affiche directement la décomposition officielle calculée et stockée en base de données.

---

## 2. Synthèse Chronologique des Demandes & Réalisations

### 1. Gestion des Examens & Suppression Universelle
- **Demande :** Permettre la suppression d'un examen quel que soit son statut (même terminé, complété ou archivé).
- **Fichiers modifiés :**
  - `client/src/components/ExamManager.jsx`
  - `server/src/controllers/exam.controller.js`
- **Résultat :** Le bouton de suppression (`🗑️ Supprimer`) est accessible pour tous les examens avec confirmation de sécurité SweetAlert2 et suppression en cascade propre (assignations, soumissions, logs).

### 2. Banque de Problèmes — Aperçu Épuré
- **Demande :** Ne plus afficher le code brut Markdown dans les cartes d'aperçu de la banque de problèmes.
- **Fichier modifié :** `client/src/components/ProblemBank.jsx`
- **Résultat :** Remplacement du bloc brut Markdown par des métadonnées structurées et soignées : Thématique, Niveau de difficulté, Limite de temps `⏱️`, Mode (`🧪 X Tests` ou `Évaluation Manuelle`), Tags `🏷️`.

### 3. Création d'Examen — Filtrage des Étudiants par Année / Promotion
- **Demande :** Pouvoir filtrer les étudiants par promotion / année académique dans l'étape d'attribution des étudiants.
- **Fichier modifié :** `client/src/components/ExamManager.jsx`
- **Résultat :** Ajout dynamique du sélecteur `Toutes les Années` / `Année 2026 (Promo 2026)` aux côtés du filtre par groupe TD.

### 4. Correction de l'erreur `ChevronRight is not defined` dans ProblemStudio
- **Demande :** Résoudre l'erreur bloquante au clic sur les accordéons du studio de création de problème.
- **Fichier modifié :** `client/src/components/ProblemStudio.jsx`
- **Résultat :** Importation des icônes manquantes (`ChevronRight`, `ChevronLeft`, `ArrowRight`). Toutes les étapes pliables s'ouvrent et se ferment sans erreur.

### 5. Épuration de l'Espace de Correction (`CorrectionWorkspace.jsx`)
- **Demandes :**
  1. Renommer `🏆 Note Finale de la Copie sur /20` en `🏆 Note Finale` et supprimer la ligne `Total Brut: X / 20 pts`.
  2. Mettre à jour `📝 Notes des Exercices (Sauvegarde Automatique):` en `📝 Notes des Exercices :`.
  3. Placer la navigation d'étudiant (`←`, liste déroulante, `→`) dans la barre latérale droite, directement au-dessus des informations de l'étudiant.
  4. Supprimer le bouton `Scanner QR Code`.
  5. Supprimer la barre de raccourcis clavier `⌨️ Nav: ↑ / ↓ ...`.
  6. Positionner la navigation des exercices (`↑ / ↓`, onglets `EXO 1`, `EXO 2`, etc.) directement après le bouton `← Retour` dans la barre supérieure.
  7. Supprimer le bandeau intermédiaire `Exercice X : Titre ...` dans le panneau central pour aérer la vue, et afficher le nom complet de l'exercice actif dynamiquement dans la barre supérieure (`📖 EXO X : Titre (Y pts)`).
  8. Dans la liste des notes des exercices, afficher uniquement `EXO 1`, `EXO 2`, etc. et afficher uniquement l'icône (`🔄` ou `⚡`) avec une infobulle (tooltip) au survol.
  9. Aligner `🏆 Note Finale` et la note (`XX.XX / 20`) sur une **seule et même ligne horizontale**.
  10. Dans la liste déroulante de sélection d'étudiant, n'afficher que le **Nom et Prénom** de l'étudiant.

---

## 3. Guide de Gestion des Branches Git

### A. Structure des Branches
- **`main`** : Version stable de référence, contenant tous les correctifs et les finitions visuelles validées.
- **`develop`** : Branche de travail pour les futurs développements.

### B. Commandes pour Revenir à la Version Principale (`main`)
Si des erreurs surviennent lors de modifications futures sur la branche de développement :
```bash
# Annuler les modifications non validées et revenir sur la branche stable :
git checkout main

# Pour voir l'état des branches :
git branch -a

# Pour créer une nouvelle branche d'expérimentation propre à partir de main :
git checkout -b feature/nouvelle-fonctionnalite main
```

---

## 4. Statut de Validation

- **Vite Build (`npm run build`) :** ✅ Sortie code 0 (Aucune erreur de compilation ou de bundle).
- **Backend Node.js / Express / Prisma :** ✅ Schémas et endpoints synchronisés et opérationnels.
