@echo off
setlocal enabledelayedexpansion
title AlgoExamination - Serveur Local d'Examen

echo =============================================================
echo       ALGOEXAMINATION - LANCEMENT DU SERVEUR D'EXAMEN
echo =============================================================
echo.

cd /d "%~dp0"

REM 1. Charger les images si l'archive locale est presente
if exist "algoexam_images.tar.gz" (
    echo [1/3] Chargement des images Docker depuis la cle USB...
    docker load -i algoexam_images.tar.gz
    echo.
) else (
    echo [1/3] Images Docker deja chargees.
)

REM 2. Demarrer les conteneurs Docker
echo [2/3] Demarrage des services d'examen...
docker compose up -d
echo.

REM 3. Detection precise de l'adresse IP locale via PowerShell
echo [3/3] Detection de l'adresse IP de la salle...
set "LOCAL_IP="
for /f "tokens=*" %%i in ('powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias 'Wi-Fi*','Ethernet*','Connexion*' -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -notlike '172.17.*' -and $_.IPAddress -notlike '172.18.*' } | Select-Object -First 1).IPAddress"') do (
    set "LOCAL_IP=%%i"
)

if not defined LOCAL_IP (
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -notlike '172.*' } | Select-Object -First 1).IPAddress"') do (
        set "LOCAL_IP=%%i"
    )
)

if not defined LOCAL_IP (
    set "LOCAL_IP=ADRESSE_IP_DU_PC"
)

REM 4. Generer le fichier texte recapitulatif
(
echo =============================================================
echo        ALGOEXAMINATION - INFORMATIONS DE CONNEXION
echo =============================================================
echo.
echo 1. ACCES POUR LES CANDIDATS / ETUDIANTS :
echo    Ouvrir dans le navigateur : http://!LOCAL_IP!
echo    (Aucun numero de port a taper pour les etudiants)
echo.
echo 2. ACCES POUR L'ENSEIGNANT / SURVEILLANCE :
echo    Ouvrir dans le navigateur : http://localhost:5175
echo    Identifiants :
echo      - Email        : teacher@esi.dz
echo      - Mot de passe : admin123
echo.
echo 3. POUR ARRETER L'EXAMEN :
echo    Double-cliquez sur "arreter_examen.bat"
echo =============================================================
) > "INFOS_CONNEXION.txt"

echo.
echo =============================================================
echo [OK] SERVEUR D'EXAMEN OPERATIONNEL ET EN COURS D'EXECUTION !
echo =============================================================
echo.
echo [1] ACCES CANDIDATS / ETUDIANTS (Sur leurs PC de salle) :
echo     URL : http://!LOCAL_IP!
echo     (Port standard 80 - Aucun port a taper)
echo.
echo [2] ACCES ENSEIGNANT / SURVEILLANCE (Sur ce PC) :
echo     URL : http://localhost:5175
echo     Email        : teacher@esi.dz
echo     Mot de passe : admin123
echo.
echo Les informations ont aussi ete enregistrees dans : INFOS_CONNEXION.txt
echo =============================================================
echo.
echo Ouverture automatique de votre interface enseignant...
timeout /t 2 >nul
start http://localhost:5175
echo.
echo Appuyez sur une touche pour fermer cette fenetre (le serveur reste actif en arriere-plan).
pause >nul
