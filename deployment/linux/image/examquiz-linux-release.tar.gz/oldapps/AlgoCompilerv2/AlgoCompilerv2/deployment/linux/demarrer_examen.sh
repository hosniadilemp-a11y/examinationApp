#!/bin/bash
set -e

echo "====================================================="
echo "   AlgoExamination — Lancement du Serveur d'Examen   "
echo "====================================================="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Charger les images si le fichier tar.gz est présent
if [ -f "algoexam_images.tar.gz" ]; then
    echo "Chargement des images Docker depuis l'archive locale..."
    docker load < algoexam_images.tar.gz
fi

# 2. Démarrer les conteneurs
echo "Démarrage des services d'examen..."
docker compose up -d

# 3. Détecter l'adresse IP locale de la machine
LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")

echo ""
echo "====================================================="
echo "✔ SERVEUR D'EXAMEN PRÊT & OPÉRATIONNEL !"
echo "====================================================="
echo ""
echo "👨‍🎓 ACCÈS ÉTUDIANTS (Sur leurs PC de salle) :"
echo "   👉 http://$LOCAL_IP"
echo "   (Aucun numéro de port à saisir pour les étudiants)"
echo ""
echo "👨‍🏫 ACCÈS ENSEIGNANT / SURVEILLANCE :"
echo "   👉 http://localhost:5175  (ou http://$LOCAL_IP:5175)"
echo "   Identifiants : teacher@esi.dz / admin123"
echo "====================================================="
