@echo off
title AlgoExamination - Mise a Jour Sans Perte

echo =============================================================
echo       ALGOEXAMINATION - MISE A JOUR SANS PERTE DE DONNEES
echo =============================================================
echo.

cd /d "%~dp0"

if not exist "algoexam_images.tar.gz" (
    echo [ERREUR] Fichier 'algoexam_images.tar.gz' introuvable dans ce dossier.
    echo Veuillez vous assurer que le fichier de mise a jour est bien present.
    echo.
    pause
    exit /b 1
)

echo [1/2] Chargement de la nouvelle version applicative...
docker load -i algoexam_images.tar.gz
echo.

echo [2/2] Redemarrage des conteneurs avec le nouveau code...
docker compose down
docker compose up -d

echo.
echo =============================================================
echo [OK] MISE A JOUR TERMINEE AVEC SUCCES !
echo Vos examens, notes et copies sont 100%% conserves.
echo =============================================================
echo.
pause
