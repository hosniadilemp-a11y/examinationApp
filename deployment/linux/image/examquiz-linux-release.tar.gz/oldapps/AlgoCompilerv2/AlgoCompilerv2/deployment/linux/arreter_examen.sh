#!/bin/bash
echo "Arrêt des services d'examen..."
docker compose down
echo "✔ Services arrêtés proprement. Vos données d'examen sont conservées en sécurité."
