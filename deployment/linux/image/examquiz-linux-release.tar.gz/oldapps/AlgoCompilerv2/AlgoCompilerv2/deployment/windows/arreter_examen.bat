@echo off
title AlgoExamination - Arret du Serveur

echo =============================================================
echo       ALGOEXAMINATION - ARRET DU SERVEUR D'EXAMEN
echo =============================================================
echo.

cd /d "%~dp0"

echo Arret des conteneurs d'examen en cours...
docker compose down

echo.
echo =============================================================
echo [OK] Serveur arrete proprement.
echo Vos donnees d'examen et les copies sont conservees en securite.
echo =============================================================
echo.
pause
