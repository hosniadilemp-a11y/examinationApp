#!/bin/bash
set -e

echo "====================================================="
echo "   AlgoExamination — Mise à Jour Sans Perte          "
echo "====================================================="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f "algoexam_images.tar.gz" ]; then
    echo "❌ Erreur : Fichier 'algoexam_images.tar.gz' introuvable."
    echo "Veuillez copier le fichier de mise à jour fourni depuis votre clé USB."
    exit 1
fi

echo "1. Chargement de la nouvelle image applicative..."
docker load < algoexam_images.tar.gz

echo "2. Redémarrage des conteneurs avec le nouveau code..."
docker compose down
docker compose up -d

echo ""
echo "====================================================="
echo "✔ MISE À JOUR TERMINÉE AVEC SUCCÈS !"
echo "✔ Base de données et copies existantes 100% conservées !"
echo "====================================================="
