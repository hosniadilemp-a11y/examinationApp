#!/bin/bash
set -e

echo "====================================================="
echo "   Starting AlgoExamination Docker Container         "
echo "====================================================="

cd /app/server

# Wait for PostgreSQL database to accept connections
echo "Waiting for PostgreSQL database to be ready..."
until node -e "
const { Client } = require('pg');
const client = new Client({ connectionString: process.env.DATABASE_URL });
client.connect().then(() => { client.end(); process.exit(0); }).catch(() => process.exit(1));
" > /dev/null 2>&1; do
    echo "  Database is starting up... waiting 2s"
    sleep 2
done

echo "✔ Database connection established."

# Ensure database schema is synchronized (without destroying existing tables)
echo "Synchronizing Prisma Database Schema..."
npx prisma db push --skip-generate

# Start Nginx in the background
echo "Starting Nginx Web Proxy (Port 80 Student & Port 5175 Staff)..."
nginx

# Start Node.js Express API Server in foreground
echo "Starting Node.js Backend Server on Port 4000..."
exec node src/index.js
