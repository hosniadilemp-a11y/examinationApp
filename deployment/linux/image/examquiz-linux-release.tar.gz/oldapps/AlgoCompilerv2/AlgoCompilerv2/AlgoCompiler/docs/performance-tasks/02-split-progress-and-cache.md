# 02. Split Progress Endpoint And Cache

Status: `done`
Priority: `critical`

## Goal
Break the heavy `/api/user/progress` payload into smaller, purpose-built endpoints and cache expensive sections.

## Why
The current progress route aggregates quizzes, submissions, badges, leaderboard placement, activity heatmap, advanced charts, and XP in one request.

## Scope
- Summary stats
- Advanced charts
- Badges
- Heatmap
- Leaderboard placement
- XP snapshot

## Implementation outline
1. Define a minimal summary endpoint for first paint.
2. Split advanced charts into a separate endpoint.
3. Split badge metadata and earned badges into a separate endpoint.
4. Cache stable sub-payloads by user and invalidate on submission or quiz save.

## Validation
- Progress page first response shrinks noticeably.
- Advanced content loads after summary without blocking the page.

## Implemented
- Added dedicated cached endpoints for progress summary, badges, and advanced charts.
- Updated the progress page to render the summary first, then load badges and advanced charts in parallel.
- Rewired the course page and badges page to use lighter progress payloads instead of the full aggregate route.
- Stopped server-rendering `/progress` from building a fresh summary on demand; the page now uses only a warm cached summary for first paint and falls back to client fetches otherwise.
- Added short-lived pending cache entries plus automatic summary refresh while global leaderboard stats are still being recomputed.
