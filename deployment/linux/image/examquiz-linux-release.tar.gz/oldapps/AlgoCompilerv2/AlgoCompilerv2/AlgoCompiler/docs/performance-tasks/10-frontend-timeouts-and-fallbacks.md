# 10. Frontend Timeouts And Fallbacks

Status: `done`
Priority: `high`

## Goal
Prevent the UI from appearing frozen when the backend is slow.

## Why
An infinite spinner feels worse than a controlled timeout with a clear message.

## Scope
- Challenge submission
- Run tests
- Problem load
- Optional progress or leaderboard fetches

## Implementation outline
1. Wrap `fetch` calls with `AbortController`.
2. Use endpoint-specific timeouts.
3. Show actionable user-facing timeout errors.
4. Keep retry behavior straightforward.

## Validation
- Slow backend paths fail clearly instead of spinning forever.

## Implemented
- Added explicit timeouts for challenge problem load.
- Added explicit timeouts for challenge navigation.
- Added explicit timeouts for submit and stdin execution.
- Added explicit timeout handling for the live leaderboard modal.
- Added explicit timeouts and visible loading/error states for course initialization and chapter loading.
- Added explicit timeouts for quiz load and quiz-save flows, with immediate results rendering before background sync completes.
- Added clearer leaderboard states for retry, partial fallback, and long refresh windows.
- Added progress page timeout handling and status notes for summary, badges, and advanced stats instead of leaving the profile in a silent loading state.
- Added automatic in-page polling for the main leaderboard so simplified data upgrades to the full dataset without a manual refresh.
