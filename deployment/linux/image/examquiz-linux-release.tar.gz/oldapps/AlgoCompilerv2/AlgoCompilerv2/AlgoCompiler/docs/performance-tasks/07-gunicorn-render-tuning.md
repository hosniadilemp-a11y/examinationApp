# 07. Gunicorn And Render Tuning

Status: `partial`
Priority: `high`

## Goal
Tune the Render process model so one slow request does not degrade the whole app.

## Why
A single Gunicorn worker with many threads can still feel sticky for CPU-bound or DB-bound bursts.

## Current state
- Render now starts with `--workers 2 --threads 4 --timeout 120`.
- Persistent app workers now keep a small SQLAlchemy client-side pool even when using the transaction pooler, to avoid reconnect latency on every request.

## Remaining work
- Validate the new worker/thread balance with real overlapping traffic on Render.
- Revisit values if DB requests remain long even after the connection-path fixes.

## Validation
- Throughput improves under overlapping requests.
- Hung requests do not stay alive forever.
