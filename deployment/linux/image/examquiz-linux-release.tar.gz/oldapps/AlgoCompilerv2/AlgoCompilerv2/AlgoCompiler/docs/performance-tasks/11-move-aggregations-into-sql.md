# 11. Move Aggregations Into SQL

Status: `pending`
Priority: `medium`

## Goal
Push large row aggregation and grouping down into Postgres where it belongs.

## Why
Python loops over large result sets are slower and transfer more data than needed.

## Candidate areas
- Live contest aggregation
- Leaderboard rollups
- Progress distributions
- Placement metrics

## Validation
- Fewer rows are transferred to the app for aggregated endpoints.
