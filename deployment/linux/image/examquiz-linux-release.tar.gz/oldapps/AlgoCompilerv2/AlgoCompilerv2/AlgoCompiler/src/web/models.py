from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_login import UserMixin

db = SQLAlchemy()
attempt_session_pk_type = db.BigInteger().with_variant(db.Integer, 'sqlite')

def get_current_academic_year(dt=None):
    if dt is None:
        dt = datetime.utcnow()
    if dt.month >= 9:
        return dt.year + 1
    return dt.year

class Chapter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    identifier = db.Column(db.String(50), nullable=False, unique=True) # e.g., 'intro', 'tableaux'
    questions = db.relationship('Question', backref='chapter', lazy=True)

class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapter.id'), nullable=False, index=True)
    type = db.Column(db.String(20), nullable=False) # 'MCQ' or 'TrueFalse'
    difficulty = db.Column(db.String(20), nullable=False) # 'Easy', 'Medium', 'Hard'
    concept = db.Column(db.String(100), nullable=False) # e.g., 'Boucles', 'Variables'
    text = db.Column(db.Text, nullable=False)
    explanation = db.Column(db.Text, nullable=False)
    choices = db.relationship('Choice', backref='question', lazy=True, cascade="all, delete-orphan")

class Choice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id'), nullable=False, index=True)
    text = db.Column(db.Text, nullable=False)
    is_correct = db.Column(db.Boolean, default=False, nullable=False)

class UserProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapter.id'), nullable=False, index=True)
    score = db.Column(db.Integer, nullable=False)
    total_questions = db.Column(db.Integer, nullable=False)
    details = db.Column(db.Text, nullable=True) # JSON string of concept mastery
    completed_at = db.Column(db.DateTime, default=datetime.utcnow)

class Problem(db.Model):
    __tablename__ = 'problems'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=False) # store Markdown or HTML
    topic = db.Column(db.String(100), nullable=False, index=True)
    difficulty = db.Column(db.String(50), nullable=False, index=True) # Easy, Medium, Hard
    is_published = db.Column(db.Boolean, default=False, nullable=False, index=True)
    template_code = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship to test cases
    test_cases = db.relationship('TestCase', backref='problem', lazy=True, cascade="all, delete-orphan")
    challenge_attempt_sessions = db.relationship(
        'ChallengeAttemptSession',
        backref='problem',
        lazy=True,
        cascade="all, delete-orphan"
    )

class TestCase(db.Model):
    __tablename__ = 'test_cases'
    
    id = db.Column(db.Integer, primary_key=True)
    problem_id = db.Column(db.Integer, db.ForeignKey('problems.id'), nullable=False, index=True)
    input_data = db.Column(db.Text, nullable=False)
    expected_output = db.Column(db.Text, nullable=False)
    is_public = db.Column(db.Boolean, default=False) # Only public cases used for "Run Tests"

class CourseChapter(db.Model):
    __tablename__ = 'course_chapters'

    id = db.Column(db.Integer, primary_key=True)
    identifier = db.Column(db.String(60), nullable=False, unique=True, index=True)
    title = db.Column(db.String(255), nullable=False)
    icon = db.Column(db.String(100), nullable=False, default='fas fa-book')
    order_index = db.Column(db.Integer, nullable=False, default=0, index=True)
    is_published = db.Column(db.Boolean, default=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    sections = db.relationship(
        'CourseSection',
        backref='chapter',
        lazy=True,
        cascade="all, delete-orphan",
        order_by="CourseSection.order_index"
    )

class CourseSection(db.Model):
    __tablename__ = 'course_sections'

    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('course_chapters.id'), nullable=False, index=True)
    title = db.Column(db.String(255), nullable=True)
    content = db.Column(db.Text, nullable=True)
    code = db.Column(db.Text, nullable=True)
    order_index = db.Column(db.Integer, nullable=False, default=0, index=True)

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=True) # Nullable for OAuth users
    name = db.Column(db.String(100), unique=True, nullable=False) # Pseudo
    equipped_title = db.Column(db.String(500), nullable=True) # JSON or comma-separated up to 3 titles
    date_of_birth = db.Column(db.Date, nullable=True)
    study_year = db.Column(db.String(50), nullable=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.study_year or not str(self.study_year).strip():
            self.study_year = str(get_current_academic_year())
    
    # Security Questions
    security_question = db.Column(db.String(200), nullable=True)
    security_answer = db.Column(db.String(200), nullable=True)
    
    # Email verification & Password Reset
    email_verified = db.Column(db.Boolean, default=False)
    verification_code = db.Column(db.String(6), nullable=True)
    reset_code = db.Column(db.String(10), nullable=True) # Increased to 10 for 'PENDING' status
    reset_code_expires = db.Column(db.DateTime, nullable=True)
    
    # Security / Rate Limiting
    failed_login_attempts = db.Column(db.Integer, default=0)
    resend_attempts = db.Column(db.Integer, default=0)
    lockout_until = db.Column(db.DateTime, nullable=True)
    
    # OAuth fields
    oauth_provider = db.Column(db.String(50), nullable=True) # 'google', 'github', etc.
    oauth_id = db.Column(db.String(100), nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_seen = db.Column(db.DateTime, nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    force_password_change = db.Column(db.Boolean, default=False)


    # Relationships
    quiz_attempts = db.relationship('QuizAttempt', backref='user', lazy=True, cascade="all, delete-orphan")
    challenge_submissions = db.relationship('ChallengeSubmission', backref='user', lazy=True, cascade="all, delete-orphan")



class QuizAttempt(db.Model):
    __tablename__ = 'quiz_attempts'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapter.id'), nullable=False, index=True)
    score = db.Column(db.Integer, nullable=False)
    total_questions = db.Column(db.Integer, nullable=False)
    
    # Status interpretation: 'in_progress', 'completed', 'auto_finalized'
    status = db.Column(db.String(20), default='completed', nullable=False)
    all_correct = db.Column(db.Boolean, default=False)
    none_correct = db.Column(db.Boolean, default=False)
    
    details = db.Column(db.Text, nullable=True) # JSON string of answers
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class ChallengeAttemptSession(db.Model):
    __tablename__ = 'challenge_attempt_sessions'

    id = db.Column(attempt_session_pk_type, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    problem_id = db.Column(db.Integer, db.ForeignKey('problems.id'), nullable=False, index=True)
    started_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    completed_at = db.Column(db.DateTime, nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship(
        'User',
        backref=db.backref('challenge_attempt_sessions', lazy=True, cascade="all, delete-orphan")
    )
    submissions = db.relationship(
        'ChallengeSubmission',
        back_populates='attempt_session',
        lazy=True
    )

class ChallengeSubmission(db.Model):
    __tablename__ = 'challenge_submissions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    problem_id = db.Column(db.Integer, db.ForeignKey('problems.id'), nullable=False, index=True)
    score = db.Column(db.Float, nullable=False) # e.g. percentage of tests passed
    code = db.Column(db.Text, nullable=True)
    passed = db.Column(db.Boolean, default=False) # True if all test cases passed
    time_taken_seconds = db.Column(db.Integer, default=0)
    test_cases_total = db.Column(db.Integer, nullable=False, default=0)
    test_cases_passed = db.Column(db.Integer, nullable=False, default=0)
    avg_execution_time_ms = db.Column(db.Numeric(12, 3), nullable=True)
    avg_memory_kb = db.Column(db.Numeric(12, 2), nullable=True)
    test_case_metrics_json = db.Column(db.JSON, nullable=True)
    attempt_session_id = db.Column(
        attempt_session_pk_type,
        db.ForeignKey('challenge_attempt_sessions.id'),
        nullable=True,
        index=True
    )
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    attempt_session = db.relationship(
        'ChallengeAttemptSession',
        back_populates='submissions'
    )

class UserBadge(db.Model):
    __tablename__ = 'user_badges'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    badge_id = db.Column(db.String(50), nullable=False) # e.g. "badge1", "badge_hacker_gold"
    awarded_at = db.Column(db.DateTime, default=datetime.utcnow)
    seen = db.Column(db.Boolean, default=False)
    
    user = db.relationship('User', backref=db.backref('badges', lazy=True, cascade="all, delete-orphan"))


# ── Q&A Module ────────────────────────────────────────────────────────────────

class QAQuestion(db.Model):
    __tablename__ = 'qa_questions'

    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    title      = db.Column(db.String(255), nullable=False)
    body       = db.Column(db.Text, nullable=False)
    code       = db.Column(db.Text, nullable=True)   # optional code snippet
    vote_score = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    author  = db.relationship('User', backref=db.backref('qa_questions', lazy=True))
    answers = db.relationship('QAAnswer', backref='question', lazy=True,
                              cascade='all, delete-orphan', order_by='QAAnswer.created_at.asc()')


class QAAnswer(db.Model):
    __tablename__ = 'qa_answers'

    id          = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('qa_questions.id'), nullable=False, index=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    body        = db.Column(db.Text, nullable=False)
    code        = db.Column(db.Text, nullable=True)
    vote_score  = db.Column(db.Integer, default=0)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship('User', backref=db.backref('qa_answers', lazy=True))


class QAVote(db.Model):
    """One vote per user per target (question or answer). value = +1 or -1."""
    __tablename__ = 'qa_votes'
    __table_args__ = (
        db.UniqueConstraint('user_id', 'target_type', 'target_id', name='uq_qa_vote'),
    )

    id          = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    target_type = db.Column(db.String(10), nullable=False)   # 'question' | 'answer'
    target_id   = db.Column(db.Integer, nullable=False)
    value       = db.Column(db.Integer, nullable=False)       # +1 or -1
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    voter = db.relationship('User', backref=db.backref('qa_votes', lazy=True))
