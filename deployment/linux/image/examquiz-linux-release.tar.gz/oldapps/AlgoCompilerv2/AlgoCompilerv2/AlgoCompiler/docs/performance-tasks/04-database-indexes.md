# 04. Database Indexes

Status: `pending`
Priority: `critical`

## Goal
Add the missing Postgres indexes that match the hottest query shapes on Supabase.

## Why
Even correct code will feel slow if the database repeatedly scans large tables.

## Proposed index candidates
- `challenge_submissions (user_id, passed, timestamp desc)`
- `challenge_submissions (problem_id, passed, timestamp desc)`
- `challenge_submissions (problem_id, user_id, passed)`
- `challenge_attempt_sessions (user_id, problem_id, completed_at, started_at desc)`
- `quiz_attempts (user_id, chapter_id, timestamp desc)`

## Implementation outline
1. Capture `EXPLAIN ANALYZE` on the main queries.
2. Create indexes in a dedicated SQL migration file.
3. Re-measure the hot endpoints.

## Validation
- Query plans switch from sequential scans to index scans where expected.
