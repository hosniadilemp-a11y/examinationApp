# 12. Lazy Load Secondary UI

Status: `pending`
Priority: `minor`

## Goal
Load only the essential data for first render, then fetch secondary visualizations after.

## Why
Charts, badges detail, and secondary visual components should not block core task flows.

## Candidate areas
- Progress advanced charts
- Heatmaps
- Badge detail panels
- Non-critical leaderboard extras

## Validation
- First meaningful paint improves while secondary data still loads correctly.
