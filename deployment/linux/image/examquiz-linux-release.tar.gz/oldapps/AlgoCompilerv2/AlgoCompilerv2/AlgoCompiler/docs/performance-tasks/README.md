# Performance Optimization Roadmap

This folder tracks the progressive smoothness and latency improvements for the app.

Status legend:
- `pending`: scoped but not started
- `in_progress`: actively being implemented
- `partial`: partly implemented, needs follow-up
- `done`: implemented and verified

Priority order:
1. [Background Post-Submit Work](./01-background-post-submit-work.md)
2. [Split Progress Endpoint And Cache](./02-split-progress-and-cache.md)
3. [Precompute Global Stats](./03-precompute-global-stats.md)
4. [Database Indexes](./04-database-indexes.md)
5. [Lightweight UI Endpoints](./05-lightweight-ui-endpoints.md)
6. [Cache Public Problem Data](./06-cache-public-problem-data.md)
7. [Gunicorn And Render Tuning](./07-gunicorn-render-tuning.md)
8. [Parser Production Tuning](./08-parser-production-tuning.md)
9. [Request Timing Instrumentation](./09-request-timing-instrumentation.md)
10. [Frontend Timeouts And Fallbacks](./10-frontend-timeouts-and-fallbacks.md)
11. [Move Aggregations Into SQL](./11-move-aggregations-into-sql.md)
12. [Lazy Load Secondary UI](./12-lazy-load-secondary-ui.md)

Current implementation batch:
- `done`: 02 split progress endpoint and cache
- `done`: 09 request timing instrumentation
- `done`: 10 frontend timeouts and fallbacks
- `partial`: 01 background post-submit work
- `partial`: 03 precompute global stats
- `partial`: 05 lightweight UI endpoints
- `partial`: 06 cache public problem data
- `partial`: 07 gunicorn and render tuning

Execution notes:
- Start with changes that reduce request latency without changing product behavior.
- Prefer measuring before and after each batch.
- Keep Supabase compatibility first-class for both Render and local development.
