# 06. Cache Public Problem Data

Status: `partial`
Priority: `high`

## Goal
Cache read-mostly challenge data and navigation metadata.

## Why
Problem statements, public test cases, and published-problem ordering change far less often than they are read.

## Current state
- Problem detail payload can be cached in-process.
- Published problem ID ordering can be cached in-process.
- Course outline and chapter payloads can be cached in-process.
- Quiz question banks can be cached in-process and sampled without repeated N+1 reads.
- Startup warmup now preloads the course outline, challenge navigation, and leaderboard snapshot in the background.

## Remaining work
- Add explicit invalidation from admin edits and publishing changes.
- Consider Redis if multi-instance cache coherence becomes necessary.

## Validation
- Repeated opens of the same challenge avoid repeated identical DB reads.
