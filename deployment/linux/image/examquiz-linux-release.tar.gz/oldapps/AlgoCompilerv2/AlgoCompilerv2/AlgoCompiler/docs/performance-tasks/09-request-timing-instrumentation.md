# 09. Request Timing Instrumentation

Status: `done`
Priority: `high`

## Goal
Measure where time is actually spent so optimizations are data-driven.

## Why
Without stage timings, slow requests are guesswork.

## Scope
- Request total timing
- Submit stage timing: DB read, compile, execute, persist
- Heavy read endpoints such as progress and problem fetches

## Implementation outline
1. Add lightweight timing helpers in Flask.
2. Log per-request totals for slow requests.
3. Log stage timings for challenge submission.
4. Keep logs structured and safe to enable on Render.

## Validation
- Slow requests show the exact hot stage.
- Logs are readable enough to compare before and after changes.

## Implemented
- Added total request timing header support.
- Added slow-request logging for challenge and API endpoints.
- Added per-stage timing logs for challenge submission.
