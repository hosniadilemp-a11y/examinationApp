import os
import sys

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))

try:
    from compiler.parser import parser
    print("Parser imported successfully.")
except ImportError as e:
    print(f"Failed to import parser: {e}")
    sys.exit(1)

EXAMPLES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), 'examples'))

def verify_examples():
    success_count = 0
    fail_count = 0
    failed_files = []

    for root, dirs, files in os.walk(EXAMPLES_DIR):
        for f in files:
            if f.endswith('.algo'):
                filepath = os.path.join(root, f)
                rel_path = os.path.relpath(filepath, EXAMPLES_DIR)
                try:
                    with open(filepath, 'r', encoding='utf-8') as file:
                        code = file.read()
                    
                    # Try to parse
                    parser.parse(code)
                    print(f"[OK] {rel_path}")
                    success_count += 1
                except Exception as e:
                    print(f"[FAIL] {rel_path}: {e}")
                    failed_files.append((rel_path, str(e)))
                    fail_count += 1

    print("\n" + "="*30)
    print(f"Verification Summary:")
    print(f"Total: {success_count + fail_count}")
    print(f"Passed: {success_count}")
    print(f"Failed: {fail_count}")
    print("="*30)

    if failed_files:
        print("\nFailed Files Details:")
        for path, err in failed_files:
            print(f"- {path}: {err}")
        return False
    return True

if __name__ == "__main__":
    verify_examples()
