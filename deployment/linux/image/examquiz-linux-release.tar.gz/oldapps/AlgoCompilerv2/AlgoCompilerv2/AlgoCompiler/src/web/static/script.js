document.addEventListener('DOMContentLoaded', () => {
    const runBtn = document.getElementById('run-btn');
    const clearConsoleBtn = document.getElementById('clear-console-btn');
    const filenameInput = document.getElementById('filename-input');
    const codeEditorElement = document.getElementById('code-editor');
    const consoleLogs = document.getElementById('console-logs');
    const consoleInputContainer = document.getElementById('console-input-container');
    const consoleInput = document.getElementById('console-input');

    // Examples Sidebar Elements
    const openExamplesBtn = document.getElementById('open-examples-btn');
    const closeExamplesBtn = document.getElementById('close-examples-btn');
    const examplesSidebar = document.getElementById('examples-sidebar');
    const examplesOverlay = document.getElementById('examples-overlay');
    const examplesContent = document.getElementById('examples-content');

    const variablesBody = document.querySelector('#variables-table tbody');
    const statusBadge = document.getElementById('status-badge');
    const fileStateBadge = document.getElementById('file-state');

    let eventSource = null;
    let editor = null;
    let currentRunId = null;

    console.log("Script initialization started");
    console.log("Essential elements found:", {
        runBtn: !!runBtn,
        codeEditorElement: !!codeEditorElement,
        consoleLogs: !!consoleLogs,
        openExamplesBtn: !!openExamplesBtn,
        examplesContent: !!examplesContent
    });

    // Initialize CodeMirror with sophisticated IDE features
    if (codeEditorElement && !window.CURRENT_PROBLEM_ID) {
        editor = CodeMirror.fromTextArea(codeEditorElement, {
            mode: "algo", // Use custom mode from algo-mode.js
            theme: "dracula",
            lineNumbers: true,
            lineWrapping: false,
            indentUnit: 4,
            smartIndent: true,
            tabSize: 4,
            indentWithTabs: false,

            // Bracket and tag matching
            matchBrackets: true,
            autoCloseBrackets: true,

            // Active line highlighting
            styleActiveLine: true,
            // Code folding with custom Algo fold helper
            foldGutter: true,
            gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],

            // Scrollbar
            scrollbarStyle: "simple",

            // Selection
            showCursorWhenSelecting: true,

            // Keyboard shortcuts and commands
            extraKeys: {
                "Ctrl-Space": "autocomplete",        // Autocomplete
                "Ctrl-/": "toggleComment",           // Toggle comment
                "Ctrl-F": "find",                    // Find
                "Ctrl-H": "replace",                 // Replace
                "Ctrl-G": "jumpToLine",              // Go to line
                "Alt-G": "jumpToLine",               // Alternative go to line
                "Ctrl-Z": "undo",                    // Undo
                "Ctrl-Y": "redo",                    // Redo
                "Ctrl-Shift-Z": "redo",              // Alternative redo
                "Ctrl-S": function (cm) {             // Save file
                    saveFile();
                    return false; // Prevent browser save dialog
                },
                "Ctrl-N": function (cm) {             // New file
                    newFile();
                    return false;
                },
                "Ctrl-O": function (cm) {             // Open file
                    document.getElementById('file-input').click();
                    return false;
                },
                "Ctrl-D": function (cm) {             // Select next occurrence
                    var sel = cm.getSelection();
                    if (sel) {
                        var cursor = cm.getCursor();
                        var searchCursor = cm.getSearchCursor(sel, cursor);
                        if (searchCursor.findNext()) {
                            cm.addSelection(searchCursor.from(), searchCursor.to());
                        }
                    }
                },
                "Ctrl-Shift-D": function (cm) {       // Duplicate line
                    var cursor = cm.getCursor();
                    var line = cm.getLine(cursor.line);
                    cm.replaceRange('\n' + line, { line: cursor.line, ch: line.length });
                },
                "Alt-Up": function (cm) {             // Move line up
                    var cursor = cm.getCursor();
                    if (cursor.line > 0) {
                        var line = cm.getLine(cursor.line);
                        cm.replaceRange("", { line: cursor.line, ch: 0 }, { line: cursor.line + 1, ch: 0 });
                        cm.replaceRange(line + "\n", { line: cursor.line - 1, ch: 0 });
                        cm.setCursor({ line: cursor.line - 1, ch: cursor.ch });
                    }
                },
                "Alt-Down": function (cm) {           // Move line down
                    var cursor = cm.getCursor();
                    if (cursor.line < cm.lineCount() - 1) {
                        var line = cm.getLine(cursor.line);
                        cm.replaceRange("", { line: cursor.line, ch: 0 }, { line: cursor.line + 1, ch: 0 });
                        cm.replaceRange(line + "\n", { line: cursor.line + 1, ch: 0 });
                        cm.setCursor({ line: cursor.line + 1, ch: cursor.ch });
                    }
                },
                "Ctrl-Shift-F": function (cm) {       // Format code
                    formatAlgoCode(cm);
                },
                "Shift-Ctrl-F": function (cm) {       // Format code
                    formatAlgoCode(cm);
                },
                "Alt-Shift-F": function (cm) {        // VS Code style
                    formatAlgoCode(cm);
                },
                "Tab": function (cm) {
                    // Smart tab: indent or insert spaces
                    if (cm.somethingSelected()) {
                        cm.indentSelection("add");
                    } else {
                        cm.replaceSelection("    ");
                    }
                },
                "Shift-Tab": function (cm) {          // Unindent
                    cm.indentSelection("subtract");
                },
                "F11": function (cm) {                // Fullscreen
                    toggleIDEFullscreen();
                },
                "Enter": function (cm) {
                    if (cm.getOption("disableInput")) return CodeMirror.Pass;
                    const cursor = cm.getCursor();
                    const line = cm.getLine(cursor.line);
                    const lineTextUntilCursor = line.slice(0, cursor.ch);
                    const textBefore = lineTextUntilCursor.trim();

                    // 1. Smart Block Auto-Closing (Parity with AlgoExamination)
                    if (!lineTextUntilCursor.includes('//') && ((lineTextUntilCursor.match(/"/g) || []).length % 2 === 0)) {
                        let closer = '';
                        let openerRegex = null;
                        let closerRegex = null;

                        if (/(^|\s)alors$/i.test(textBefore)) {
                            closer = 'FinSi;';
                            openerRegex = /\bSi\b/gi;
                            closerRegex = /\bFinSi\b/gi;
                        } else if (/(^|\s)faire$/i.test(textBefore)) {
                            if (/pour/i.test(textBefore) || /pour\b/i.test(lineTextUntilCursor)) {
                                closer = 'FinPour;';
                                openerRegex = /\bPour\b/gi;
                                closerRegex = /\bFinPour\b/gi;
                            } else {
                                closer = 'FinTantQue;';
                                openerRegex = /\bTantQue\b/gi;
                                closerRegex = /\bFinTantQue\b/gi;
                            }
                        } else if (/^repeter$/i.test(textBefore)) {
                            closer = "Jusqu'a (condition);";
                            openerRegex = /\bRepeter\b/gi;
                            closerRegex = /\bJusqu'a\b/gi;
                        }

                        if (closer) {
                            const totalLines = cm.lineCount();
                            let textAfterCursor = line.slice(cursor.ch) + "\n";
                            for (let i = cursor.line + 1; i < totalLines; i++) {
                                textAfterCursor += cm.getLine(i) + "\n";
                            }
                            const openersAfter = (textAfterCursor.match(openerRegex) || []).length;
                            const closersAfter = (textAfterCursor.match(closerRegex) || []).length;

                            if (closersAfter <= openersAfter) {
                                const indentMatch = line.match(/^\s*/);
                                const baseIndent = indentMatch ? indentMatch[0] : '';
                                const innerIndent = baseIndent + '    ';
                                const insertText = '\n' + innerIndent + '\n' + baseIndent + closer;
                                cm.replaceRange(insertText, cursor);
                                cm.setCursor({ line: cursor.line + 1, ch: innerIndent.length });
                                return;
                            }
                        }
                    }

                    // 2. Auto-semicolon logic:
                    const trimmedLine = line.trim();
                    if (trimmedLine.length > 0 &&
                        !trimmedLine.startsWith("//") &&
                        !/[;:\.\,\{\[\(\^]$/.test(trimmedLine) &&
                        !/^(Algorithme|Var|Const|Debut|Alors|Faire|Sinon|Repeter|Type|Enregistrement|Fin|FinSi|FinPour|FinTantQue)/i.test(trimmedLine) &&
                        !/\s+(Alors|Faire)$/i.test(trimmedLine)
                    ) {
                        const lastCharIdx = line.search(/\S\s*$/);
                        if (cursor.ch > lastCharIdx) {
                            cm.replaceRange(";", { line: cursor.line, ch: line.length });
                        }
                    }
                    return CodeMirror.Pass;
                }
            },

            // Enable undo/redo history
            undoDepth: 200,
            historyEventDelay: 1000,

            // Autocomplete options
            hintOptions: {
                hint: (CodeMirror.helpers.hint && CodeMirror.helpers.hint.algo) || CodeMirror.hint.anyword,
                completeSingle: false,
                alignWithWord: true,
                closeOnUnfocus: true
            }
        });

        window.editor = editor;
        editor.setSize("100%", null); // Let flex handle height

        function applyEditorThemeFromBody() {
            if (!editor) return;
            const isLight = document.body.classList.contains('light-theme');
            editor.setOption('theme', isLight ? 'default' : 'dracula');
        }
        applyEditorThemeFromBody();
        window.addEventListener('themechange', applyEditorThemeFromBody);

        // If code was requested from the standalone course page, inject it on load.
        try {
            const pendingCourseCode = localStorage.getItem('algocompiler.pendingCourseCode');
            const fromExercise = localStorage.getItem('algocompiler.fromExercise');

            if (pendingCourseCode) {
                editor.setValue(pendingCourseCode);

                // Format the code immediately after loading
                if (typeof formatAlgoCode === 'function') {
                    formatAlgoCode(editor);
                }

                localStorage.removeItem('algocompiler.pendingCourseCode');
                localStorage.removeItem('algocompiler.fromExercise');

                // Add "Back to Course" notification
                showCourseReturnNotification(!!fromExercise);
            }
        } catch (error) {
            console.warn("Unable to read pending course code from storage:", error);
        }

        // Auto-trigger autocomplete after typing
        let typingTimer;
        editor.on("inputRead", function (cm, change) {
            if (change.text[0].match(/[\w]/)) {
                clearTimeout(typingTimer);
                typingTimer = setTimeout(function () {
                    // Only show if user has typed at least 2 characters
                    var cursor = cm.getCursor();
                    var token = cm.getTokenAt(cursor);
                    if (token.string.length >= 2) {
                        cm.showHint({ hint: CodeMirror.helpers.hint.algo });
                    }
                }, 300); // 300ms delay
            }
        });

        // (Removed editor-only fullscreen option mapping)
    }

    function showCourseReturnNotification(isExercise) {
        const notify = document.createElement('div');
        notify.className = 'course-return-notification';
        notify.innerHTML = `
            <div class="course-notify-content">
                <i class="fas fa-graduation-cap"></i>
                <span>${isExercise ? 'Exercice chargé ! Bonne chance.' : 'Exemple chargé dans l\'éditeur.'}</span>
                <a href="/course" class="course-return-link">Retourner au cours</a>
                <button class="course-notify-close"><i class="fas fa-times"></i></button>
            </div>
        `;
        document.body.appendChild(notify);

        const closeBtn = notify.querySelector('.course-notify-close');
        closeBtn.onclick = () => notify.remove();

        // Auto remove after 10s
        setTimeout(() => { if (notify.parentNode) notify.remove(); }, 10000);
    }

    // ═══════════════════════════════════════════════════════════
    // FULLSCREEN LOGIC (IDE-WIDE)
    // ═══════════════════════════════════════════════════════════
    window.toggleIDEFullscreen = function () {
        const container = document.querySelector('.container');
        if (!document.fullscreenElement) {
            container.requestFullscreen().catch(err => {
                console.error(`Error attempting to enable full-screen mode: ${err.message}`);
            });
        } else {
            document.exitFullscreen();
        }
    }

    const fullscreenBtn = document.getElementById('fullscreen-btn');
    if (fullscreenBtn) {
        fullscreenBtn.addEventListener('click', toggleIDEFullscreen);
    }

    document.addEventListener('fullscreenchange', () => {
        const isFS = !!document.fullscreenElement;
        console.log("Fullscreen changed. State:", isFS);
        if (fullscreenBtn) {
            fullscreenBtn.title = isFS ? 'Quitter le plein écran (F11)' : 'Plein Écran (F11)';
            fullscreenBtn.innerHTML = isFS
                ? '<i class="fas fa-compress"></i>'
                : '<i class="fas fa-expand"></i>';
        }
        // Force editor refresh on transition
        if (editor) {
            setTimeout(() => {
                editor.refresh();
                console.log("Editor refreshed after fullscreen change");
            }, 150);
        }
    });

    // Global keyboard listener for shortcuts (like F11)
    document.addEventListener('keydown', (e) => {
        if (e.key === 'F11') {
            e.preventDefault();
            console.log("F11 pressed globally - toggling IDE fullscreen");
            toggleIDEFullscreen();
        }
    });

    // Code formatting function for Algo - Refined for structural alignment
    window.formatAlgoCode = function (cm) {
        var code = cm.getValue();
        var lines = code.split('\n');
        var formatted = [];
        var indentLevel = 0;
        var indentStr = '    '; // 4 spaces

        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();

            // Decrease indent BEFORE the line for block-closing or section-switching keywords
            // These keywords should shift back out to the same level as their header
            if (/^(Fin|Sinon|Jusqua|Debut|Var|Const|Type)/i.test(line)) {
                indentLevel = Math.max(0, indentLevel - 1);
            }

            // Add formatted line
            if (line) {
                formatted.push(indentStr.repeat(indentLevel) + line);
            } else {
                formatted.push('');
            }

            // Increase indent AFTER the line for block-opening keywords
            // Note: Algorithme, Fonction, Procedure themselves don't increase indent
            // because the next line is usually Var/Debut which will handle its own indent.
            if (/^(Var|Const|Debut|Si|Sinon|Pour\s|Tant\s*Que\s|Repeter|Type|Enregistrement)/i.test(line) ||
                /\s+(Alors|Faire|Enregistrement)$/i.test(line)) {
                indentLevel++;
            }
        }

        cm.setValue(formatted.join('\n'));
    }

    // ═══════════════════════════════════════════════════════════
    // STATUS BAR — live cursor position, char count, line count
    // ═══════════════════════════════════════════════════════════
    const statusCursor = document.getElementById('status-cursor');
    const statusChars = document.getElementById('status-chars');
    const statusLines = document.getElementById('status-lines');
    const statusFontSize = document.getElementById('status-fontsize');
    const wordWrapBtn = document.getElementById('wordwrap-btn');

    function getActiveEditor() {
        return window.editor || editor;
    }

    function updateStatusBar() {
        const activeEditor = getActiveEditor();
        if (!activeEditor) return;
        const cursor = activeEditor.getCursor();
        const line = cursor.line + 1;
        const col = cursor.ch + 1;
        const text = activeEditor.getValue();
        const charCount = text.length;
        const lineCount = activeEditor.lineCount();

        if (statusCursor) statusCursor.innerHTML = `<i class="fas fa-map-pin"></i> Ln ${line}, Col ${col}`;
        if (statusChars) statusChars.innerHTML = `<i class="fas fa-font"></i> ${charCount.toLocaleString()} car.`;
        if (statusLines) statusLines.innerHTML = `<i class="fas fa-list-ol"></i> ${lineCount} lignes`;
    }

    if (editor) {
        editor.on('cursorActivity', updateStatusBar);
        editor.on('change', updateStatusBar);
        editor._algoStatusHandlersBound = true;
        updateStatusBar(); // initial
    }

    // ═══════════════════════════════════════════════════════════
    // FONT SIZE ZOOM — buttons + Ctrl+= / Ctrl+-
    // ═══════════════════════════════════════════════════════════
    let currentFontSize = 14;
    const MIN_FONT = 10;
    const MAX_FONT = 24;
    const DEFAULT_FONT = 14;

    function applyFontSize(size) {
        currentFontSize = Math.min(MAX_FONT, Math.max(MIN_FONT, size));
        const activeEditor = getActiveEditor();
        if (activeEditor) {
            activeEditor.getWrapperElement().style.fontSize = currentFontSize + 'px';
            activeEditor.refresh();
        }
        if (statusFontSize) statusFontSize.textContent = currentFontSize + 'px';
    }

    const fontIncBtn = document.getElementById('font-increase-btn');
    const fontDecBtn = document.getElementById('font-decrease-btn');
    const fontResetBtn = document.getElementById('font-reset-btn');

    if (fontIncBtn) fontIncBtn.addEventListener('click', () => applyFontSize(currentFontSize + 1));
    if (fontDecBtn) fontDecBtn.addEventListener('click', () => applyFontSize(currentFontSize - 1));
    if (fontResetBtn) fontResetBtn.addEventListener('click', () => applyFontSize(DEFAULT_FONT));

    // Ctrl+= to increase, Ctrl+- to decrease
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && (e.key === '=' || e.key === '+')) {
            e.preventDefault();
            applyFontSize(currentFontSize + 1);
        }
        if (e.ctrlKey && e.key === '-') {
            e.preventDefault();
            applyFontSize(currentFontSize - 1);
        }
        if (e.ctrlKey && e.key === '0') {
            e.preventDefault();
            applyFontSize(DEFAULT_FONT);
        }
        // F5 to run
        if (e.key === 'F5') {
            e.preventDefault();
            runBtn && runBtn.click();
        }
    });

    // ═══════════════════════════════════════════════════════════
    // WORD WRAP TOGGLE
    // ═══════════════════════════════════════════════════════════
    let wordWrapEnabled = false;

    function toggleWordWrap() {
        const activeEditor = getActiveEditor();
        wordWrapEnabled = !wordWrapEnabled;
        if (activeEditor) activeEditor.setOption('lineWrapping', wordWrapEnabled);
        if (wordWrapBtn) wordWrapBtn.classList.toggle('active', wordWrapEnabled);
    }

    if (wordWrapBtn) wordWrapBtn.addEventListener('click', toggleWordWrap);

    // (IDE-wide fullscreen logic moved above)


    // ═══════════════════════════════════════════════════════════
    // RESIZABLE PANE SPLITTER
    // ═══════════════════════════════════════════════════════════
    const splitter = document.getElementById('pane-splitter');
    const editorPane = document.querySelector('.editor-pane');
    const outputPane = document.querySelector('.output-pane');
    const editorLayout = document.querySelector('.editor-layout');

    if (splitter && editorPane && outputPane) {
        let isResizing = false;
        let startX = 0;
        let startEditorWidth = 0;

        splitter.addEventListener('mousedown', (e) => {
            isResizing = true;
            startX = e.clientX;
            startEditorWidth = editorPane.getBoundingClientRect().width;
            splitter.classList.add('dragging');
            document.body.style.cursor = 'col-resize';
            document.body.style.userSelect = 'none';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (!isResizing) return;
            const layoutWidth = editorLayout.getBoundingClientRect().width;
            const delta = e.clientX - startX;
            let newEditorWidth = startEditorWidth + delta;
            // Enforce min/max: each pane must be at least 250px
            newEditorWidth = Math.max(250, Math.min(layoutWidth - 255, newEditorWidth));
            const newOutputWidth = layoutWidth - newEditorWidth - 5; // 5 = splitter width
            editorPane.style.flex = 'none';
            editorPane.style.width = newEditorWidth + 'px';
            outputPane.style.flex = 'none';
            outputPane.style.width = newOutputWidth + 'px';
            if (editor) editor.refresh();
        });

        document.addEventListener('mouseup', () => {
            if (isResizing) {
                isResizing = false;
                splitter.classList.remove('dragging');
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
            }
        });
    }

    // File management variables
    let currentFileName = "programme.algo";
    let isModified = false;
    let fileHandle = null; // Store the file handle for File System Access API


    // Track modifications
    if (editor) {
        editor.on("change", function () {
            isModified = true;
            updateTitle();
        });
    }

    // Update window title and UI with file name and modified status
    function updateTitle() {
        const modifiedMark = isModified ? " *" : "";
        document.title = `${currentFileName}${modifiedMark} - AlgoCompiler`;

        if (filenameInput && filenameInput.value !== currentFileName) {
            filenameInput.value = currentFileName;
        }

        if (fileStateBadge) {
            if (isModified) {
                fileStateBadge.style.display = 'inline-block';
                fileStateBadge.style.backgroundColor = '#d29922'; // Yellow/Orange
                fileStateBadge.textContent = "Non enregistré";
            } else {
                fileStateBadge.style.display = 'none';
            }
        }
    }

    // Handle filename input changes
    if (filenameInput) {
        filenameInput.addEventListener('change', (e) => {
            let newName = e.target.value.trim();
            if (!newName.endsWith('.algo')) {
                newName += '.algo';
            }
            currentFileName = newName;
            fileHandle = null; // Clear handle on manual rename
            updateTitle();
        });
    }

    // Clear Console
    if (clearConsoleBtn) {
        clearConsoleBtn.addEventListener('click', () => {
            if (consoleLogs) consoleLogs.innerHTML = '';
            updateVariables({});
        });
    }

    // New file
    async function newFile() {
        if (isModified) {
            if (!confirm("Vous avez des modifications non sauvegardées. Continuer?")) {
                return;
            }
        }

        if (editor) {
            editor.setValue(`Algorithme NouveauProgramme;
Var
    // Déclarez vos variables ici
Debut
    // Écrivez votre code ici
    Ecrire("Bonjour!");
Fin.`);
        }

        currentFileName = "programme.algo";
        isModified = false;
        fileHandle = null; // Reset handle
        updateTitle();
        statusBadge.textContent = "Nouveau";
        statusBadge.style.backgroundColor = "#28a745";
    }

    // Open File
    async function openFile() {
        if (isModified) {
            if (!confirm("Vous avez des modifications non sauvegardées. Continuer?")) {
                return;
            }
        }

        // Try File System Access API
        if ('showOpenFilePicker' in window) {
            try {
                const [handle] = await window.showOpenFilePicker({
                    types: [{
                        description: 'Fichiers Algo',
                        accept: { 'text/plain': ['.algo', '.txt'] }
                    }],
                    multiple: false
                });

                const file = await handle.getFile();
                const content = await file.text();

                if (editor) {
                    editor.setValue(content);
                } else {
                    codeEditorElement.value = content;
                }

                fileHandle = handle;
                currentFileName = file.name;
                isModified = false;
                updateTitle();
                statusBadge.textContent = "Chargé";
                statusBadge.style.backgroundColor = "#28a745";

            } catch (err) {
                // User cancelled or error
                if (err.name !== 'AbortError') {
                    console.error('Error opening file:', err);
                }
            }
        } else {
            // Fallback to input element
            document.getElementById('file-input').click();
        }
    }

    // Save file
    async function saveFile() {
        const code = editor ? editor.getValue() : codeEditorElement.value;

        if (fileHandle) {
            // Write to existing handle
            try {
                const writable = await fileHandle.createWritable();
                await writable.write(code);
                await writable.close();

                isModified = false;
                updateTitle();
                statusBadge.textContent = "Sauvegardé";
                statusBadge.style.backgroundColor = "#28a745";
                setTimeout(() => {
                    statusBadge.textContent = "Prêt";
                    statusBadge.style.backgroundColor = "#28a745";
                }, 2000);
            } catch (err) {
                console.error('Error saving file:', err);
                alert("Erreur lors de la sauvegarde: " + err.message);
            }
        } else {
            // No handle, use Save As
            await saveFileAs();
        }
    }

    // Save File As
    async function saveFileAs() {
        const code = editor ? editor.getValue() : codeEditorElement.value;

        if ('showSaveFilePicker' in window) {
            try {
                // Ensure filename has .algo extension
                let suggestedName = currentFileName;
                if (!suggestedName.endsWith('.algo')) {
                    suggestedName += '.algo';
                }

                const handle = await window.showSaveFilePicker({
                    suggestedName: suggestedName,
                    types: [{
                        description: 'Fichiers Algo',
                        accept: { 'application/octet-stream': ['.algo'] }
                    }],
                });

                const writable = await handle.createWritable();
                await writable.write(code);
                await writable.close();

                fileHandle = handle;
                currentFileName = handle.name;
                isModified = false;
                updateTitle();

                statusBadge.textContent = "Sauvegardé";
                statusBadge.style.backgroundColor = "#28a745";
                setTimeout(() => {
                    statusBadge.textContent = "Prêt";
                    statusBadge.style.backgroundColor = "#28a745";
                }, 2000);

            } catch (err) {
                if (err.name !== 'AbortError') {
                    console.error('Error saving file as:', err);
                }
            }
        } else {
            // Fallback download
            const blob = new Blob([code], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = currentFileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            isModified = false;
            updateTitle();
            statusBadge.textContent = "Sauvegardé";
            statusBadge.style.backgroundColor = "#28a745";
            setTimeout(() => {
                statusBadge.textContent = "Prêt";
                statusBadge.style.backgroundColor = "#28a745";
            }, 2000);
        }
    }

    // Load file (Fallback for input element)
    function loadFile(file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            const content = e.target.result;
            if (editor) {
                editor.setValue(content);
            } else {
                codeEditorElement.value = content;
            }
            currentFileName = file.name;
            isModified = false;
            fileHandle = null; // No handle from input element
            updateTitle();
            statusBadge.textContent = "Chargé";
            statusBadge.style.backgroundColor = "#28a745";
        };
        reader.readAsText(file);
    }

    // Editor Toolbar Buttons
    const undoBtn = document.getElementById('undo-btn');
    const redoBtn = document.getElementById('redo-btn');
    const commentBtn = document.getElementById('comment-btn');
    const searchBtn = document.getElementById('search-btn');
    const replaceBtn = document.getElementById('replace-btn');
    const formatBtn = document.getElementById('format-btn');

    if (undoBtn && editor) {
        undoBtn.addEventListener('click', () => {
            editor.undo();
        });
    }

    if (redoBtn && editor) {
        redoBtn.addEventListener('click', () => {
            editor.redo();
        });
    }

    if (commentBtn && editor) {
        commentBtn.addEventListener('click', () => {
            const selection = editor.getSelection();
            if (selection) {
                // Toggle comment on selection
                editor.toggleComment();
            } else {
                // Comment current line
                const cursor = editor.getCursor();
                editor.toggleComment();
            }
        });
    }

    if (searchBtn && editor) {
        searchBtn.addEventListener('click', () => {
            editor.execCommand('find');
        });
    }

    if (replaceBtn && editor) {
        replaceBtn.addEventListener('click', () => {
            editor.execCommand('replace');
        });
    }

    if (formatBtn && editor) {
        formatBtn.addEventListener('click', () => {
            formatAlgoCode(editor);
        });
    }

    // Event listeners for file management buttons
    const newBtn = document.getElementById('new-btn');
    const openBtn = document.getElementById('open-btn');
    const saveBtn = document.getElementById('save-btn');
    const fileInput = document.getElementById('file-input');

    if (newBtn) {
        newBtn.addEventListener('click', newFile);
    }

    if (openBtn) {
        openBtn.addEventListener('click', openFile);
    }

    if (saveBtn) {
        saveBtn.addEventListener('click', saveFile);
    }

    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                loadFile(file);
            }
            // Reset input so same file can be loaded again
            e.target.value = '';
        });
    }

    // Prevent accidental page close with unsaved changes
    window.addEventListener('beforeunload', (e) => {
        if (isModified) {
            e.preventDefault();
            e.returnValue = '';
            return '';
        }
    });

    // Initialize title
    updateTitle();

    // Sidebar Toggle Logic
    function openSidebar() {
        examplesSidebar.classList.add('open');
        examplesOverlay.classList.add('show');
    }

    function closeSidebar() {
        examplesSidebar.classList.remove('open');
        examplesOverlay.classList.remove('show');
    }

    if (openExamplesBtn) openExamplesBtn.addEventListener('click', openSidebar);
    if (closeExamplesBtn) closeExamplesBtn.addEventListener('click', closeSidebar);
    if (examplesOverlay) examplesOverlay.addEventListener('click', closeSidebar);


    // Load Examples into Sidebar
    async function loadExamples() {
        try {
            console.log("loadExamples: Fetching examples...");
            const response = await fetch('/examples');
            console.log("loadExamples: HTTP Status", response.status);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const data = await response.json();
            console.log("Examples loaded:", data);

            // Clear loading placeholder
            if (examplesContent) examplesContent.innerHTML = '';

            // Define category order
            const order = ["Basics", "Arrays", "Strings", "Pointers", "Dynamic Allocation", "Functions", "Enregistrements", "Listes_Chainees", "Piles", "Files"];

            // Map categories to icons and localized names
            const categoryMeta = {
                "Basics": { icon: "fas fa-leaf", label: "Les Bases" },
                "Arrays": { icon: "fas fa-table", label: "Tableaux" },
                "Strings": { icon: "fas fa-language", label: "Chaînes de Caractères" },
                "Pointers": { icon: "fas fa-bullseye", label: "Pointeurs" },
                "Dynamic Allocation": { icon: "fas fa-link", label: "Allocation Dynamique" },
                "Functions": { icon: "fas fa-cogs", label: "Fonctions & Procédures" },
                "Enregistrements": { icon: "fas fa-id-card", label: "Enregistrements (Struct)" },
                "Listes_Chainees": { icon: "fas fa-project-diagram", label: "Listes Chaînées" },
                "Piles": { icon: "fas fa-layer-group", label: "Piles (Stack)" },
                "Files": { icon: "fas fa-stream", label: "Files (Queue)" }
            };

            // Process predefined tracked categories
            order.forEach(category => {
                if (data[category] && data[category].length > 0) {
                    addCategory(category, data[category]);
                }
            });

            // Process arbitrary other categories
            Object.keys(data).forEach(category => {
                if (!order.includes(category) && data[category].length > 0) {
                    addCategory(category, data[category]);
                }
            });

            function addCategory(rawName, files) {
                const categoryDiv = document.createElement('div');
                categoryDiv.className = 'example-category';
                // Load state from local storage. Default is collapsed (true).
                const isCollapsed = localStorage.getItem(`example-category-${rawName}`) !== 'false';
                
                if (isCollapsed) {
                    categoryDiv.classList.add('collapsed');
                }

                const title = document.createElement('div');
                title.className = 'example-category-title';
                
                const iconHtml = categoryMeta[rawName] ? `<i class="${categoryMeta[rawName].icon}"></i>` : `<i class="fas fa-folder"></i>`;
                const labelHtml = categoryMeta[rawName] ? categoryMeta[rawName].label : rawName;
                
                title.innerHTML = `
                    <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
                        <span>${iconHtml} ${labelHtml}</span>
                        <i class="fas fa-chevron-down toggle-icon" style="transition: transform 0.2s; ${isCollapsed ? 'transform: rotate(-90deg);' : ''}"></i>
                    </div>
                `;

                categoryDiv.appendChild(title);
                
                const contentDiv = document.createElement('div');
                contentDiv.className = 'example-category-content';
                contentDiv.style.display = isCollapsed ? 'none' : 'block';

                files.forEach(file => {
                    const btn = document.createElement('button');
                    btn.className = 'example-btn';

                    // Track path in dataset
                    btn.dataset.path = file.path;

                    // Style tutorials specifically
                    if (file.name.startsWith('00_Tutoriel')) {
                        btn.classList.add('tutorial');
                        btn.innerHTML = `<i class="fas fa-graduation-cap"></i> ${file.name.replace('00_Tutoriel_', '').replace('.algo', '').replace(/_/g, ' ')}`;
                    } else {
                        btn.innerHTML = `<i class="fas fa-file-code"></i> ${file.name.replace('.algo', '').replace(/_/g, ' ')}`;
                    }

                    // Attach click handler cleanly
                    btn.addEventListener('click', () => loadExampleFile(file.path));

                    contentDiv.appendChild(btn);
                });
                
                title.addEventListener('click', () => {
                    const willCollapse = contentDiv.style.display !== 'none';
                    contentDiv.style.display = willCollapse ? 'none' : 'block';
                    categoryDiv.classList.toggle('collapsed', willCollapse);
                    const icon = title.querySelector('.toggle-icon');
                    if(icon) {
                        icon.style.transform = willCollapse ? 'rotate(-90deg)' : 'rotate(0deg)';
                    }
                    localStorage.setItem(`example-category-${rawName}`, willCollapse ? 'true' : 'false');
                    updateGlobalExpandCollapseButtons();
                });

                categoryDiv.appendChild(contentDiv);

                if (examplesContent) examplesContent.appendChild(categoryDiv);
            }

        } catch (e) {
            console.error("Failed to load examples", e);
            if (examplesContent) examplesContent.innerHTML = `<div class="text-danger p-3"><i class="fas fa-exclamation-triangle"></i> Erreur lors du chargement des exemples.</div>`;
            if (statusBadge) {
                statusBadge.textContent = "Err Exemples";
                statusBadge.style.backgroundColor = "#da3633";
            }
        }
    }
    loadExamples();

    // Global Expand/Collapse Buttons Logic
    const expandAllBtn = document.getElementById('expand-all-btn');
    const collapseAllBtn = document.getElementById('collapse-all-btn');

    function updateGlobalExpandCollapseButtons() {
        if (!expandAllBtn || !collapseAllBtn) return;
        const allCategories = document.querySelectorAll('.example-category');
        if (allCategories.length === 0) return;

        let allExpanded = true;
        let allCollapsed = true;

        allCategories.forEach(cat => {
            if (cat.classList.contains('collapsed')) {
                allExpanded = false;
            } else {
                allCollapsed = false;
            }
        });

        expandAllBtn.style.display = allExpanded ? 'none' : 'block';
        collapseAllBtn.style.display = allExpanded ? 'block' : 'none';
        
        // If entirely collapsed, make sure expand is shown.
        if (allCollapsed) {
            expandAllBtn.style.display = 'block';
            collapseAllBtn.style.display = 'none';
        }
    }

    if (expandAllBtn) {
        expandAllBtn.addEventListener('click', () => {
            const categories = document.querySelectorAll('.example-category');
            categories.forEach(cat => {
                const title = cat.querySelector('.example-category-title');
                const contentDiv = cat.querySelector('.example-category-content');
                if (cat.classList.contains('collapsed')) {
                    contentDiv.style.display = 'block';
                    cat.classList.remove('collapsed');
                    const icon = title.querySelector('.toggle-icon');
                    if (icon) icon.style.transform = 'rotate(0deg)';
                    
                    // Hack to get the rawName. Assumes ID or specific class isn't available easily. 
                    // Better approach is data attributes, but this relies on structure.
                    // Instead of full sync, clear or set local storage based on icon.
                }
            });
            // Clear local storage for all example categories to 'expanded' (false collapsed) 
            for (let i = 0; i < localStorage.length; i++) {
                 const key = localStorage.key(i);
                 if (key && key.startsWith('example-category-')) {
                     localStorage.setItem(key, 'false');
                 }
            }
            updateGlobalExpandCollapseButtons();
        });
    }

    if (collapseAllBtn) {
        collapseAllBtn.addEventListener('click', () => {
             const categories = document.querySelectorAll('.example-category');
             categories.forEach(cat => {
                const title = cat.querySelector('.example-category-title');
                const contentDiv = cat.querySelector('.example-category-content');
                if (!cat.classList.contains('collapsed')) {
                    contentDiv.style.display = 'none';
                    cat.classList.add('collapsed');
                    const icon = title.querySelector('.toggle-icon');
                    if (icon) icon.style.transform = 'rotate(-90deg)';
                }
            });
            // Set local storage for all example categories to 'collapsed' (true)
            for (let i = 0; i < localStorage.length; i++) {
                 const key = localStorage.key(i);
                 if (key && key.startsWith('example-category-')) {
                     localStorage.setItem(key, 'true');
                 }
            }
            updateGlobalExpandCollapseButtons();
        });
    }


    // Fetch and load a specific example file
    async function loadExampleFile(filename) {
        if (!filename) return;

        if (isModified) {
            if (!confirm("Vous avez des modifications non sauvegardées. Écraser votre travail avec cet exemple ?")) {
                return;
            }
        }

        try {
            console.log(`Loading example: ${filename}`);
            const response = await fetch(`/example/${filename}`);
            if (response.ok) {
                const data = await response.json();
                if (editor) {
                    editor.setValue(data.code);
                } else if (codeEditorElement) {
                    codeEditorElement.value = data.code;
                }

                // Treat as new file visually
                currentFileName = filename.split('/').pop();
                fileHandle = null;
                isModified = false;
                updateTitle();
                if (statusBadge) {
                    statusBadge.textContent = "Exemple chargé";
                    statusBadge.style.backgroundColor = "#28a745";
                }

                // Close the sidebar immediately on selection for better UX
                closeSidebar();
            } else {
                console.error("Failed to fetch example content");
            }
        } catch (e) {
            console.error("Failed to load example content", e);
        }
    }

    // Update Variable Table
    function updateVariables(vars) {
        const variablesBody = document.getElementById('variables-body');
        if (!variablesBody) return;
        const variablesTable = variablesBody.closest('table');
        const thead = variablesTable.querySelector('thead tr');

        // Ensure Type and Size headers exist
        const requiredHeaders = ['Nom', 'Valeur', 'Adresse', 'Type', 'Taille'];
        if (thead && thead.children.length < requiredHeaders.length) {
            thead.innerHTML = ''; // Rebuild headers
            requiredHeaders.forEach(text => {
                const th = document.createElement('th');
                th.textContent = text;
                thead.appendChild(th);
            });
        }

        variablesBody.innerHTML = '';
        if (!vars || Object.keys(vars).length === 0) {
            variablesBody.innerHTML = '<tr><td colspan="5" class="placeholder-text">Aucune donnée</td></tr>';
            return;
        }

        for (const [keyName, info] of Object.entries(vars)) {
            const row = document.createElement('tr');

            const nameCell = document.createElement('td');
            nameCell.textContent = (info && info.name) ? info.name : keyName;

            const valueCell = document.createElement('td');
            valueCell.className = 'font-mono';

            const addrCell = document.createElement('td');
            addrCell.className = 'font-mono text-gray-500 text-xs';

            const typeCell = document.createElement('td');
            typeCell.className = 'text-xs text-gray-500';

            const sizeCell = document.createElement('td');
            sizeCell.className = 'text-xs text-gray-500 font-mono';

            // Handle different info structures
            if (typeof info === 'object' && info !== null) {
                // Formatting based on type
                if (info.type === 'POINTEUR' || info.type === 'Pointeur') {
                    if (info.target_address && info.target_address !== 'ERROR') {
                        valueCell.textContent = `${info.value} → ${info.target_address}`;
                    } else {
                        valueCell.textContent = info.value;
                    }
                } else {
                    valueCell.textContent = info.value;
                }
                addrCell.textContent = info.address || '-';
                typeCell.textContent = info.type || 'Inconnu';
                sizeCell.textContent = info.size !== undefined ? info.size : '-';
            } else {
                // Legacy simple format
                valueCell.textContent = String(info);
                addrCell.textContent = '-';
                typeCell.textContent = 'Inconnu';
                sizeCell.textContent = '-';
            }

            row.appendChild(nameCell);
            row.appendChild(valueCell);
            row.appendChild(addrCell);
            row.appendChild(typeCell);
            row.appendChild(sizeCell);

            // Add data-type for CSS styling
            if (info && info.type) {
                row.setAttribute('data-type', info.type.toUpperCase());
            }

            variablesBody.appendChild(row);
        }
    }

    // Execution Logic
    function startLogic(btn) {
        console.log("startLogic triggered", { btnText: btn.innerText });
        // Get code from CodeMirror if active
        const code = editor ? editor.getValue() : codeEditorElement.value;
        console.log("Code length:", code.length);

        if (btn.innerText.includes('Arrêter')) {
            console.log("Stopping execution...");
            stopExecution();
            return;
        }

        // UI Reset
        btn.innerHTML = '<i class="fas fa-stop"></i> Arrêter';
        if (consoleLogs) consoleLogs.innerHTML = '';
        updateVariables({});
        if (statusBadge) {
            statusBadge.textContent = "Exécution...";
            statusBadge.style.backgroundColor = "#d29922";
        }
        if (consoleInputContainer) consoleInputContainer.style.display = 'none';

        if (eventSource) {
            console.log("Closing existing EventSource");
            eventSource.close();
        }

        // Get Input File Content if any
        const inputFileContent = window.inputFileContent || "";
        console.log("Input file content length:", inputFileContent.length);

        runExecution(code, inputFileContent);
    }

    async function runExecution(code, inputFileContent) {
        try {
            console.log("Starting execution...");
            const response = await fetch('/start_execution', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: code, inputFileContent: inputFileContent })
            });
            const data = await response.json();

            if (!data.success) {
                // Check if we have detailed errors
                if (data.details && Array.isArray(data.details)) {
                    appendToConsole("ÉCHEC DE LA COMPILATION:\n", 'error');
                    data.details.forEach(err => {
                        const loc = `Ligne ${err.line}, Colonne ${err.column}`;
                        const span = document.createElement('span');
                        span.style.color = '#da3633';
                        if (err.error_code) {
                            span.innerHTML = `<a href="/doc/errors#${err.error_code}" target="_blank" style="color: #ffb86c; font-weight: bold; text-decoration: underline;">[${err.error_code}]</a> [${err.type}] ${loc}: ${err.message}\n`;
                        } else {
                            span.textContent = `[${err.type}] ${loc}: ${err.message}\n`;
                        }
                        if (consoleLogs) consoleLogs.appendChild(span);
                    });
                } else {
                    appendToConsole(data.error, 'error');
                }
                finishExecution();
                return;
            }

            currentRunId = data.run_id || null;
            console.log("Connecting to stream...");
            eventSource = new EventSource(`/stream?run_id=${encodeURIComponent(currentRunId || '')}`);

            eventSource.onmessage = (e) => {
                const msg = JSON.parse(e.data);

                if (msg.type === 'stdout') {
                    appendToConsole(msg.data);
                } else if (msg.type === 'trace') {
                    if (msg.data.variables) updateVariables(msg.data.variables);
                } else if (msg.type === 'input_request') {
                    console.log("Input request received from server");
                    showInputPrompt();
                } else if (msg.type === 'error') {
                    appendToConsole('\n' + msg.data, 'error');
                } else if (msg.type === 'finished') {
                    if (statusBadge) {
                        statusBadge.textContent = "Terminé";
                        statusBadge.style.backgroundColor = "#238636";
                    }
                    if (eventSource) eventSource.close();
                    finishExecution();
                } else if (msg.type === 'stopped') {
                    if (statusBadge) {
                        statusBadge.textContent = "Arrêté";
                        statusBadge.style.backgroundColor = "#cf222e";
                    }
                    appendToConsole('\n' + (msg.data || "Arrêt"), 'error');
                    if (eventSource) eventSource.close();
                    finishExecution(true);
                }
            };

            eventSource.onerror = (e) => {
                console.error("Stream error", e);
                if (eventSource && eventSource.readyState === EventSource.CLOSED) {
                    finishExecution();
                }
            };

        } catch (error) {
            console.error("Execution error", error);
            appendToConsole(`Erreur système: ${error.message}`, 'error');
            finishExecution();
        }
    }

    async function stopExecution() {
        if (eventSource) {
            eventSource.close();
            eventSource = null;
        }

        if (statusBadge) {
            statusBadge.textContent = "Arrêt en cours...";
            statusBadge.style.backgroundColor = "#cf222e";
        }

        if (!currentRunId) {
            finishExecution(true);
            return;
        }

        try {
            await fetch('/stop_execution', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ run_id: currentRunId })
            });
        } catch (e) {
            console.error("Failed to stop execution on server", e);
        }

        finishExecution(true); // true = stopped manually
    }

    function finishExecution(stopped = false) {
        const btn = document.getElementById('run-btn');
        if (btn) btn.innerHTML = '<i class="fas fa-play"></i> Exécuter';

        if (eventSource) {
            eventSource.close();
            eventSource = null;
        }
        currentRunId = null;
        if (consoleInputContainer) consoleInputContainer.style.display = 'none';

        if (stopped) {
            if (statusBadge) {
                statusBadge.textContent = "Arrêté";
                statusBadge.style.backgroundColor = "#cf222e";
            }
            appendToConsole("\n[Exécution interrompue par l'utilisateur]", 'error');
        } else {
            if (statusBadge && statusBadge.textContent === "Exécution...") {
                statusBadge.textContent = "Terminé";
                statusBadge.style.backgroundColor = "#238636";
            }
        }
    }

    function showInputPrompt() {
        console.log("Showing input prompt (forced)");

        let container = consoleInputContainer;
        if (!container) {
            container = document.getElementById('console-input-container');
        }

        if (!container) {
            console.error("consoleInputContainer NOT FOUND in DOM");
            return;
        }

        if (statusBadge) {
            statusBadge.textContent = "Attente saisie...";
            statusBadge.style.backgroundColor = "#1f6feb";
        }

        container.style.display = 'flex';
        container.setAttribute('style', 'display: flex !important;');

        if (consoleInput) {
            consoleInput.value = '';
            consoleInput.focus();
        }

        if (consoleLogs) consoleLogs.scrollTop = consoleLogs.scrollHeight;
    }

    // Console Helper
    function appendToConsole(text, type = 'normal') {
        if (!consoleLogs) return;
        const span = document.createElement('span');
        span.textContent = text;
        if (type === 'error') span.style.color = '#da3633';
        if (type === 'input') span.style.color = '#238636';
        consoleLogs.appendChild(span);
        consoleLogs.scrollTop = consoleLogs.scrollHeight;
        const execOutput = document.getElementById('execution-output');
        if (execOutput) execOutput.scrollTop = execOutput.scrollHeight;
    }

    if (consoleInput) {
        consoleInput.addEventListener('keydown', async (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const text = consoleInput.value;
                appendToConsole(text + '\n', 'input');
                if (consoleInputContainer) consoleInputContainer.style.display = 'none';
                if (statusBadge) {
                    statusBadge.textContent = "Exécution...";
                    statusBadge.style.backgroundColor = "#d29922";
                }

                console.log("Sending input to server:", text);

                try {
                    const response = await fetch('/send_input', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ input: text, run_id: currentRunId })
                    });
                    if (!response.ok) throw new Error(`HTTP ${response.status}`);
                } catch (err) {
                    console.error("Failed to send input", err);
                    appendToConsole(`Erreur envoi: ${err.message}\n`, 'error');
                }
            }
        });
    }

    // Initial Setup
    if (runBtn) {
        runBtn.addEventListener('click', () => startLogic(runBtn));
    }

    // Input File Handling
    const inputFileBtn = document.getElementById('input-file-btn');
    const inputFileSelect = document.getElementById('input-file-select');
    const inputFileStatus = document.getElementById('input-file-status');
    window.inputFileContent = "";

    if (inputFileBtn) {
        inputFileBtn.addEventListener('click', () => {
            if (inputFileSelect) inputFileSelect.click();
        });
    }

    if (inputFileSelect) {
        inputFileSelect.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    window.inputFileContent = e.target.result;
                    if (inputFileStatus) {
                        inputFileStatus.style.display = 'inline';
                        inputFileStatus.textContent = file.name;
                        inputFileStatus.title = "Fichier d'entrée chargé pour la prochaine exécution";
                    }
                };
                reader.readAsText(file);
            }
        });
    }

    window.initEditorUI = function () {
        editor = window.editor || editor;
        if (!editor) return;

        const formatBtn = document.getElementById('format-btn');
        if (formatBtn) formatBtn.onclick = () => window.formatAlgoCode(editor);

        const undoBtn = document.getElementById('undo-btn');
        if (undoBtn) undoBtn.onclick = () => editor.undo();

        const redoBtn = document.getElementById('redo-btn');
        if (redoBtn) redoBtn.onclick = () => editor.redo();

        const commentBtn = document.getElementById('comment-btn');
        if (commentBtn) commentBtn.onclick = () => editor.execCommand('toggleComment');

        const searchBtn = document.getElementById('search-btn');
        if (searchBtn) searchBtn.onclick = () => editor.execCommand('find');

        const replaceBtn = document.getElementById('replace-btn');
        if (replaceBtn) replaceBtn.onclick = () => editor.execCommand('replace');

        if (wordWrapBtn) {
            wordWrapBtn.onclick = () => {
                const wrap = !editor.getOption('lineWrapping');
                editor.setOption('lineWrapping', wrap);
                wordWrapEnabled = wrap;
                wordWrapBtn.classList.toggle('active', wrap);
            };
        }

        if (!editor._algoStatusHandlersBound) {
            editor.on('cursorActivity', updateStatusBar);
            editor.on('change', updateStatusBar);
            editor._algoStatusHandlersBound = true;
        }

        wordWrapEnabled = !!editor.getOption('lineWrapping');
        if (wordWrapBtn) wordWrapBtn.classList.toggle('active', wordWrapEnabled);
        applyFontSize(currentFontSize);
        updateStatusBar();
    };
});
