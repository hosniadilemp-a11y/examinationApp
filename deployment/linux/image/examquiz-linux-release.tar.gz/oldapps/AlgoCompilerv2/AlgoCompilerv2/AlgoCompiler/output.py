# Algo: RotationAnneauxMatrice

# Helper functions (dependency order)
_b_str = str
_b_int = int
_b_float = float
_b_len = len
_b_range = range
_b_isinstance = isinstance
_b_bool = bool
_b_list = list
_b_type = type
_b_input = input
_b_print = print
_b_enumerate = enumerate
_b_abs = abs
_b_min = min
_b_max = max
_b_pow = pow

_algo_input_buffer = []
def _algo_read():
    global _algo_input_buffer
    while True:
        if _algo_input_buffer:
            return _algo_input_buffer.pop(0)
        try:
            line = _b_input()
        except EOFError:
            return ''
        if line is None:
            return ''
        parts = _b_str(line).strip().split()
        if parts:
            _algo_input_buffer.extend(parts)

def _algo_ecrire(*args):
    parts = []
    for a in args:
        s = _algo_to_string(a)
        # Display #0 as the visible null sentinel
        s = s.replace('#0', chr(0))
        s = s.replace('\\n', '\n').replace('\\t', '\t')
        parts.append(s)
    out_str = ' '.join(parts)
    if out_str and not out_str.endswith('\n') and not out_str.endswith(' '):
        out_str += ' '
    _b_print(out_str, end='')

def _algo_to_string(val):
    if val is None: return 'NIL'
    if _b_isinstance(val, _b_bool): return 'Vrai' if val else 'Faux'
    if _b_isinstance(val, _b_list):
        res = ''
        for char in val:
            if char is None or char == '\0' or char == '#0': break
            res += _b_str(char)
        return res
    return _b_str(val)

def _algo_deref_to_list(target):
    # Dereference a Pointer to get its backing list
    if hasattr(target, 'base_var') and target.base_var is not None:
        return target.base_var
    if hasattr(target, 'get_target_container'):
        try: return target.get_target_container()
        except: pass
    return target

def _algo_assign_fixed_string(target_list, source_val):
    target_list = _algo_deref_to_list(target_list)
    if not _b_isinstance(target_list, _b_list):
        raise TypeError('Variable Chaine non initialisee. Declarez avec s[N]: Chaine.')
    limit = _b_len(target_list)
    s_val = ''
    if hasattr(source_val, '_get_target_container'):
        targ = source_val._get_target_container()
        while hasattr(targ, '_get_target_container'): targ = targ._get_target_container()
        if _b_isinstance(targ, _b_list):
            s_val = _algo_to_string(targ[source_val.index:])
        else:
            s_val = _algo_to_string(source_val._get_string() if hasattr(source_val, '_get_string') else source_val._get())
    else:
        s_val = _algo_to_string(source_val)
    if '#0' in s_val:
        s_val = s_val.split('#0')[0]
    if limit > 0:
        s_val = s_val[:limit-1]
        for i in _b_range(_b_len(s_val)):
            target_list[i] = s_val[i]
        target_list[_b_len(s_val)] = '#0'
        for i in _b_range(_b_len(s_val)+1, limit):
            target_list[i] = None
    return target_list

def _algo_longueur(val):
    if val is None: return 0
    s = _algo_to_string(val)
    s = s.split('#0')[0] if '#0' in s else s
    return _b_len(s)

def _algo_set_char(target_list, index, char_val):
    target_list = _algo_deref_to_list(target_list)
    if not _b_isinstance(target_list, _b_list):
        raise TypeError(f'Cannot set char: not a list (got {_b_type(target_list).__name__})')
    idx = _b_int(index)  # 0-based index
    if 0 <= idx < _b_len(target_list):
        if char_val == '#0' or char_val is None:
            target_list[idx] = '#0'
        else:
            target_list[idx] = _b_str(char_val)[0]
    return target_list

def _algo_get_char(target_list, index):
    target_list = _algo_deref_to_list(target_list)
    if _b_isinstance(target_list, _b_list):
        idx = _b_int(index)  # 0-based index
        if 0 <= idx < _b_len(target_list):
            c = target_list[idx]
            return c if c is not None and c != '#0' else '#0'
        return ''
    s = _b_str(target_list)
    idx = _b_int(index)
    return s[idx] if 0 <= idx < _b_len(s) else ''

def _algo_concat(*args):
    res = ''
    for a in args:
        s = _algo_to_string(a)
        s = s.split('#0')[0] if '#0' in s else s
        res += s
    return res

def _algo_abs(x):
    return _b_abs(x)

def _algo_sqrt(x):
    import math
    res = math.sqrt(x)
    return _b_int(res) if hasattr(res, 'is_integer') and res.is_integer() else res

def _algo_puissance(base, exp):
    return _b_pow(base, exp)

def _algo_min(*args):
    if _b_len(args) == 1 and _b_isinstance(args[0], (_b_list, tuple)):
        return _b_min(args[0])
    return _b_min(*args)

def _algo_max(*args):
    if _b_len(args) == 1 and _b_isinstance(args[0], (_b_list, tuple)):
        return _b_max(args[0])
    return _b_max(*args)

def _algo_sous_chaine(s, pos, count=None):
    val = _algo_to_string(s)
    val = val.split('#0')[0] if '#0' in val else val
    start = _b_int(pos) - 1
    if start < 0: start = 0
    if count is None:
        return val[start:]
    c = _b_int(count)
    if c < 0: return ''
    return val[start : start + c]

Abs = abs = _algo_abs
Sqrt = sqrt = _algo_sqrt
Puissance = puissance = _algo_puissance
Min = min = _algo_min
Max = max = _algo_max
SousChaine = souschaine = _algo_sous_chaine
Longueur = longueur = _algo_longueur
Concat = concat = _algo_concat

def _algo_make_string(s, max_size=256):
    s = _b_str(s) if not _b_isinstance(s, _b_str) else s
    s = s[:max_size - 1]  # leave room for #0
    arr = [None] * max_size
    for i, c in _b_enumerate(s):
        arr[i] = c
    arr[_b_len(s)] = '#0'
    return arr

def _algo_read_typed(current_val, input_val=None, target_type_name='CHAINE'):
    if input_val is None: input_val = _algo_read()
    t = target_type_name.upper()
    if 'CHAINE' in t:
        if _b_isinstance(current_val, _b_list):
            _algo_assign_fixed_string(current_val, input_val)
            return current_val
        return _b_str(input_val)
    if 'BOOLEEN' in t or _b_isinstance(current_val, _b_bool):
        s = _b_str(input_val).lower()
        if s in ['vrai', 'true', '1']: return True
        if s in ['faux', 'false', '0']: return False
        raise ValueError(f"Type mismatch: '{input_val}' n'est pas un Booleen valide.")
    elif 'ENTIER' in t or _b_isinstance(current_val, _b_int):
        try: return _b_int(input_val)
        except:
            if input_val == '' or input_val is None: return 0
            raise ValueError(f"Type mismatch: '{input_val}' n'est pas un Entier valide.")
    elif 'REEL' in t or _b_isinstance(current_val, _b_float):
        try: return _b_float(input_val)
        except:
            if input_val == '' or input_val is None: return 0.0
            raise ValueError(f"Type mismatch: '{input_val}' n'est pas un Reel valide.")
    return input_val

_algo_heap = {}
_algo_heap_next_addr = 50000

def _algo_allouer(size_in_bytes, element_size=1):
    global _algo_heap_next_addr
    if hasattr(size_in_bytes, '_assign') or isinstance(size_in_bytes, Pointer):
        target_ptr = size_in_bytes
        sz = 4
        el_sz = 1
        addr = _algo_heap_next_addr
        _algo_heap_next_addr += sz
        allocated_list = [None]
        _algo_heap[addr] = allocated_list
        _algo_vars_info[f'_heap_{addr}'] = {'addr': addr, 'size': sz, 'element_size': el_sz}
        new_ptr = Pointer(var_name=f'_heap_{addr}', namespace=_algo_heap, index=0, base_var=allocated_list)
        new_ptr._heap_addr = addr
        target_ptr._assign(new_ptr)
        return new_ptr
    size_in_bytes = int(size_in_bytes)
    addr = _algo_heap_next_addr
    _algo_heap_next_addr += size_in_bytes
    num_elements = size_in_bytes // element_size if element_size > 0 else size_in_bytes
    allocated_list = [None] * max(1, num_elements)
    _algo_heap[addr] = allocated_list
    _algo_vars_info[f'_heap_{addr}'] = {'addr': addr, 'size': size_in_bytes, 'element_size': element_size}
    ptr = Pointer(var_name=f'_heap_{addr}', namespace=_algo_heap, index=0, base_var=allocated_list)
    ptr._heap_addr = addr
    return ptr

def _algo_liberer(ptr):
    if ptr and hasattr(ptr, '_heap_addr'):
        addr = ptr._heap_addr
        if addr in _algo_heap:
            del _algo_heap[addr]
            ptr.base_var = None
            ptr.var_name = None

_algo_record_sizes = {}

def _algo_taille(type_name):
    t = type_name.lower()
    if 'pointeur' in t or t.startswith('^'): return 1
    if 'entier' in t: return 4
    if 'reel' in t: return 8
    if 'booleen' in t: return 1
    if 'caractere' in t: return 1
    if 'chaine' in t: return 1
    # User-defined record type — uses precomputed sizes
    if type_name in _algo_record_sizes: return _algo_record_sizes[type_name]
    return 4

def _algo_allouer_record(record_dict):
    global _algo_heap_next_addr
    addr = _algo_heap_next_addr
    _algo_heap_next_addr += 1
    _algo_heap[addr] = record_dict
    ptr = Pointer(var_name=None, namespace=None, index=0, base_var=record_dict)
    ptr._heap_addr = addr
    return ptr

global _algo_vars_info
_algo_vars_info = {"mat": {"addr": 1000, "size": 64, "element_size": 4, "type": "Entier"}, "R": {"addr": 1064, "size": 4, "element_size": 4, "type": "Entier"}, "N": {"addr": 1068, "size": 4, "element_size": 4, "type": "Entier"}, "M": {"addr": 1072, "size": 4, "element_size": 4, "type": "Entier"}, "K": {"addr": 1076, "size": 4, "element_size": 4, "type": "Entier"}, "perimetre": {"addr": 1080, "size": 4, "element_size": 4, "type": "Entier"}, "r_eff": {"addr": 1084, "size": 4, "element_size": 4, "type": "Entier"}, "step": {"addr": 1088, "size": 4, "element_size": 4, "type": "Entier"}, "k": {"addr": 1092, "size": 4, "element_size": 4, "type": "Entier"}, "temp": {"addr": 1096, "size": 4, "element_size": 4, "type": "Entier"}, "j": {"addr": 1100, "size": 4, "element_size": 4, "type": "Entier"}, "i": {"addr": 1104, "size": 4, "element_size": 4, "type": "Entier"}}


class Pointer:
    def __init__(self, var_name=None, namespace=None, index=0, base_var=None, alloc_name=None):
        self.var_name = var_name
        self.namespace = namespace if namespace is not None else {}
        self.index = index
        self.base_var = base_var
        self.alloc_name = alloc_name if alloc_name is not None else var_name
        self._heap_addr = None

    def _get_target_container(self):
        # base_var takes priority — used for record-backed pointers from _algo_allouer_record
        if self.base_var is not None:
            return self.base_var
        # Only after checking base_var do we apply the NIL check on var_name
        if self.var_name is None:
            raise ValueError("Cannot dereference NIL pointer")
        if self.var_name in self.namespace:
            return self.namespace[self.var_name]
        elif self.var_name in globals():
            return globals()[self.var_name]
        else:
            raise NameError(f"Variable '{self.var_name}' not found")

    def _get(self):
        target = self._get_target_container()
        if isinstance(target, list):
            if not (0 <= self.index < len(target)):
                raise IndexError(f"Segmentation fault: Access out of bounds at index {self.index}")
            return target[self.index]
        if self.index != 0:
             raise IndexError("Segmentation fault: Pointer arithmetic on scalar variable out of bounds")
        return target

    def _get_string(self):
        target = self._get_target_container()
        if isinstance(target, list):
            if not (0 <= self.index < len(target)): return ""
            return _algo_to_string(target[self.index:])
        return str(target)

    
    def _set(self, value):
        target = self._get_target_container()
        if isinstance(target, list):
            if not (0 <= self.index < len(target)):
                raise IndexError(f"Segmentation fault: Write out of bounds at index {self.index}")
            target[self.index] = value
        else:
            if self.index != 0:
                 raise IndexError("Segmentation fault: Pointer arithmetic on scalar variable out of bounds")
            if self.var_name in self.namespace:
                self.namespace[self.var_name] = value
            else:
                globals()[self.var_name] = value
    
    def _assign(self, other):
        # Mutates this pointer to point to what 'other' points to (used for Var parameters)
        if isinstance(other, Pointer):
            self.var_name = other.var_name
            self.namespace = other.namespace
            self.index = other.index
            self.base_var = other.base_var
            self.alloc_name = getattr(other, 'alloc_name', other.var_name)
            self._heap_addr = getattr(other, '_heap_addr', None)
        elif other is None:
            self.var_name = None
            self.namespace = {}
            self.index = 0
            self.base_var = None
            self.alloc_name = None
            self._heap_addr = None
        else:
             raise TypeError("Cannot assign non-pointer to pointer via _assign")

    def _clone(self):
        new_ptr = Pointer(self.var_name, self.namespace, self.index, self.base_var, getattr(self, 'alloc_name', self.var_name))
        new_ptr._heap_addr = self._heap_addr
        return new_ptr

    def __add__(self, offset):
        new_ptr = Pointer(self.var_name, self.namespace, self.index + int(offset), self.base_var, getattr(self, 'alloc_name', self.var_name))
        new_ptr._heap_addr = self._heap_addr
        return new_ptr

    def __sub__(self, offset):
        new_ptr = Pointer(self.var_name, self.namespace, self.index - int(offset), self.base_var, getattr(self, 'alloc_name', self.var_name))
        new_ptr._heap_addr = self._heap_addr
        return new_ptr

    def __eq__(self, other):
        if other is None:
            # If it has a heap address or base_var, it's not NIL
            if self._heap_addr is not None or self.base_var is not None:
                return False
            return self.var_name is None
        if isinstance(other, Pointer):
            # Check for heap address equality if both have it
            if self._heap_addr is not None and getattr(other, '_heap_addr', None) is not None:
                return self._heap_addr + self.index == other._heap_addr + other.index
            return (self.var_name == other.var_name and 
                    self.index == other.index and 
                    id(self.base_var) == id(other.base_var))
        return False
    
    def __str__(self):
        if self._heap_addr is not None:
            return f"@{self._heap_addr + self.index}"
        if self.var_name is None:
            return "NIL"
        try:
            lookup_name = self.alloc_name if hasattr(self, 'alloc_name') and self.alloc_name else self.var_name
            if lookup_name in _algo_vars_info:
                info = _algo_vars_info[lookup_name]
                base = info['addr']
                stride = info.get('element_size', 1)
                addr = base + (self.index * stride)
                return f"@{addr}"
            else:
                return f"@{lookup_name}+{self.index}"

        except:
            return "UNKNOWN"

    def __repr__(self):
        return str(self)

    def __getitem__(self, i):
        if isinstance(i, str):
            target = self._get_target_container()
            if isinstance(target, list) and len(target) == 1 and isinstance(target[0], dict):
                target = target[0]
            return target[i]
        return (self + i)._get()

    def __setitem__(self, i, value):
        if isinstance(i, str):
            target = self._get_target_container()
            if isinstance(target, list) and len(target) == 1 and isinstance(target[0], dict):
                target = target[0]
            target[i] = value
            return
        (self + i)._set(value)


mat = [[None] * 4 for _ in range(4)]
M = 0
N = 0
R = 0 # Entier
K = 0 # Entier
k = 0
step = 0
r_eff = 0
perimetre = 0 # Entier
i = 0
j = 0
temp = 0 # Entier




M = _b_int(4)
N = _b_int(4)
R = _b_int(2)
temp = _b_int(1)
for i in range(int(0), int(M - 1) + 1):
    for j in range(int(0), int(N - 1) + 1):
        _tmp_val = temp
        mat[int(i)][int(j)] = _tmp_val._clone() if hasattr(_tmp_val, '_clone') else _tmp_val
        temp = _b_int(temp + 1)
_algo_ecrire('=== MATRICE ORIGINALE (4x4) ===\n')
for i in range(int(0), int(M - 1) + 1):
    _algo_ecrire('[ ')
    for j in range(int(0), int(N - 1) + 1):
        _algo_ecrire(mat[int(i)][int(j)], ' ')
        if mat[int(i)][int(j)] < 10:
            _algo_ecrire(' ')
    _algo_ecrire(']\n')
_algo_ecrire('\n')
if M < N:
    K = _b_int(M // 2)
else:
    K = _b_int(N // 2)
_algo_ecrire("Nombre d'anneaux concentriques (K) : ", K, '\n')
_algo_ecrire('Nombre de rotations demandees (R) : ', R, '\n\n')
for k in range(int(0), int(K - 1) + 1):
    perimetre = _b_int(2 * (M - 2 * k) + 2 * (N - 2 * k) - 4)
    r_eff = _b_int(R % perimetre)
    _algo_ecrire('Anneau ', k, ' : perimetre = ', perimetre, ', rotations effectives = ', r_eff, '\n')
    for step in range(int(1), int(r_eff) + 1):
        temp = _b_int(mat[int(k)][int(k)])
        for j in range(int(k), int(N - 2 - k) + 1):
            _tmp_val = mat[int(k)][int(j + 1)]
            mat[int(k)][int(j)] = _tmp_val._clone() if hasattr(_tmp_val, '_clone') else _tmp_val
        for i in range(int(k), int(M - 2 - k) + 1):
            _tmp_val = mat[int(i + 1)][int(N - 1 - k)]
            mat[int(i)][int(N - 1 - k)] = _tmp_val._clone() if hasattr(_tmp_val, '_clone') else _tmp_val
        j = _b_int(N - 1 - k)
        while j > k:
            _tmp_val = mat[int(M - 1 - k)][int(j - 1)]
            mat[int(M - 1 - k)][int(j)] = _tmp_val._clone() if hasattr(_tmp_val, '_clone') else _tmp_val
            j = _b_int(j - 1)
        i = _b_int(M - 1 - k)
        while i > k + 1:
            _tmp_val = mat[int(i - 1)][int(k)]
            mat[int(i)][int(k)] = _tmp_val._clone() if hasattr(_tmp_val, '_clone') else _tmp_val
            i = _b_int(i - 1)
        _tmp_val = temp
        mat[int(k + 1)][int(k)] = _tmp_val._clone() if hasattr(_tmp_val, '_clone') else _tmp_val
_algo_ecrire('\n=== MATRICE APRES ', R, ' ROTATIONS ANTI-HORAIRE ===\n')
for i in range(int(0), int(M - 1) + 1):
    _algo_ecrire('[ ')
    for j in range(int(0), int(N - 1) + 1):
        _algo_ecrire(mat[int(i)][int(j)], ' ')
        if mat[int(i)][int(j)] < 10:
            _algo_ecrire(' ')
    _algo_ecrire(']\n')
_algo_ecrire('\nVerification terminee avec succes !\n')
