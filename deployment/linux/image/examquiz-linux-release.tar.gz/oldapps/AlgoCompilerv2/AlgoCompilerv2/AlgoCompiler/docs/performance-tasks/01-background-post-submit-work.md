# 01. Background Post-Submit Work

Status: `partial`
Priority: `critical`

## Goal
Return challenge submission results immediately after test execution, while moving non-blocking work out of the request path.

## Why
The user cares first about pass/fail results. XP recomputation, badge refresh, cache refresh, and secondary derived stats should not delay that response.

## Scope
- Challenge submission save path
- XP and level refresh
- Badge refresh
- Optional leaderboard cache warmup

## Current state
- Submission returns before synchronous XP recomputation completes.
- User level refresh is already scheduled in the background.
- Quiz results now render before quiz-progress persistence completes.
- Quiz XP and level refresh are scheduled after the save commit instead of blocking the response.

## Remaining work
- Move badge recomputation out of heavy progress requests into a dedicated refresh path.
- Optionally warm leaderboard cache after submission commit, not during reads.
- Add visibility into background task failures.

## Implementation outline
1. Keep compile, test execution, and submission persistence in the request.
2. Schedule secondary recomputations through a small executor or queue.
3. Cache the refreshed result for later reads.
4. Ensure background refresh failures do not break the request response.

## Validation
- Submission response time decreases under logged-in full submit.
- Results page loads before XP refresh completes.
- Later reads reflect updated level/badges.
