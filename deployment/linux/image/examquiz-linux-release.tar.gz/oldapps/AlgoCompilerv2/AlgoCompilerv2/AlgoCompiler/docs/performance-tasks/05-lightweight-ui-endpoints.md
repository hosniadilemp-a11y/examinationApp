# 05. Lightweight UI Endpoints

Status: `partial`
Priority: `high`

## Goal
Use small endpoints for small UI needs instead of reusing large generic endpoints.

## Why
Requesting full datasets just to render tiny widgets wastes both database time and network time.

## Current state
- Challenge navigation can use a dedicated problem ID list.
- Header level pill can use a dedicated level endpoint.
- Course progress now uses a summary-only progress endpoint.
- Badges page and badge polling now use a badges-only endpoint.
- Progress page now loads summary, badges, and advanced charts from separate endpoints.
- Challenge page HTML now renders its shell without blocking on a synchronous problem lookup.

## Remaining work
- Audit the rest of the UI for oversized requests.
- Replace heavy badge and progress fetches where a compact endpoint is enough.

## Validation
- Page chrome loads without triggering full progress or full problems payloads.
