import sys
import os
import re
# SECURITY_HARDENING_V1.1
import secrets
import logging
import datetime
import time
import threading
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from dotenv import load_dotenv
from urllib.parse import urlparse, urljoin

APP_DIR = os.path.abspath(os.path.dirname(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(APP_DIR, '..', '..'))

# Load local development secrets from .env first, then legacy env.env if present.
for env_path in (
    os.path.join(PROJECT_ROOT, '.env'),
    os.path.join(PROJECT_ROOT, 'env.env'),
    os.path.join(PROJECT_ROOT, 'AlgoCompiler.env'),
):
    if os.path.exists(env_path):
        load_dotenv(env_path, override=False)

app_env = (os.environ.get('APP_ENV') or os.environ.get('FLASK_ENV') or '').strip().lower()
is_production = (
    app_env in {'production', 'prod'}
    or os.environ.get('RENDER') == 'true'
    or bool(os.environ.get('K_SERVICE'))
)
is_local_dev = not is_production

# Add parent directory to path to allow importing 'compiler'
sys.path.append(os.path.abspath(os.path.join(APP_DIR, '..')))

print(">>> [DEBUG] APP STARTING UP...", flush=True)

from flask import Flask, render_template, request, jsonify, Response, session as flask_session, flash, redirect, url_for
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import current_user, login_required
import io
import contextlib
from compiler.parser import parser, compile_algo
from compiler.french_exception_translator import translate_exception
print(">>> [DEBUG] PARSER IMPORTED", flush=True)

from web.debugger import TraceRunner
from web.models import db, get_current_academic_year, Chapter, Question, Choice, Problem, TestCase, User, QuizAttempt, ChallengeSubmission, ChallengeAttemptSession, UserBadge, CourseChapter, CourseSection
from web.extensions import login_manager, oauth, mail
from web.sandbox.runner import execute_code
print(">>> [DEBUG] MODELS AND EXTENSIONS IMPORTED", flush=True)
from sqlalchemy import func, distinct
from sqlalchemy.orm import joinedload
from sqlalchemy.pool import NullPool
import json

# Handle Windows console encoding issues for scientific/accented characters
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except:
        pass

# Aggressively silence all logging to prevent OSError [Errno 22] on Windows console
logging.disable(logging.CRITICAL)
logging.getLogger('werkzeug').setLevel(logging.ERROR)
logging.getLogger('werkzeug').disabled = True

app = Flask(__name__)
# Fix for OAuth redirection if behind a proxy (Render, Heroku, etc.)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

PROBLEM_LEADERBOARD_CACHE_TTL_SECONDS = 60
problem_leaderboard_cache = {}
PROBLEM_DETAIL_CACHE_TTL_SECONDS = 300
problem_detail_cache = {}
problem_navigation_cache = {'expires_at': 0, 'problem_ids': []}
problem_cache_lock = threading.Lock()
COURSE_CONTENT_CACHE_TTL_SECONDS = int(os.environ.get('COURSE_CONTENT_CACHE_TTL_SECONDS', '300'))
course_outline_cache = {'expires_at': 0, 'payload': None}
course_chapter_cache = {}
course_cache_lock = threading.Lock()
QUIZ_BANK_CACHE_TTL_SECONDS = int(os.environ.get('QUIZ_BANK_CACHE_TTL_SECONDS', '300'))
quiz_question_bank_cache = {}
quiz_cache_lock = threading.Lock()
USER_LEVEL_CACHE_TTL_SECONDS = 300
user_level_cache = {}
user_level_refresh_futures = {}
user_level_cache_lock = threading.Lock()
GLOBAL_USER_STATS_CACHE_TTL_SECONDS = int(os.environ.get('GLOBAL_USER_STATS_CACHE_TTL_SECONDS', '120'))
global_user_stats_cache = {'expires_at': 0, 'payload': None}
global_user_stats_refresh_future = None
global_user_stats_refresh_state = {
    'status': 'idle',
    'started_at': None,
    'finished_at': None,
    'last_error': None
}
global_user_stats_cache_lock = threading.Lock()
USER_PROGRESS_CACHE_TTL_SECONDS = int(os.environ.get('USER_PROGRESS_CACHE_TTL_SECONDS', '90'))
user_progress_cache = {}
user_progress_cache_lock = threading.Lock()
USER_PROGRESS_ADVANCED_CACHE_TTL_SECONDS = int(os.environ.get('USER_PROGRESS_ADVANCED_CACHE_TTL_SECONDS', '180'))
user_progress_advanced_cache = {}
user_progress_advanced_cache_lock = threading.Lock()
USER_BADGES_CACHE_TTL_SECONDS = int(os.environ.get('USER_BADGES_CACHE_TTL_SECONDS', '120'))
user_badges_cache = {}
user_badges_cache_lock = threading.Lock()

# Thread-safe in-memory cache for static Chapter metadata to avoid repeated DB queries
_chapter_cache = {'expires_at': 0, 'chapters': [], 'id_to_identifier': {}}
_chapter_cache_lock = threading.Lock()

def get_all_chapters_cached():
    now_ts = time.time()
    with _chapter_cache_lock:
        if _chapter_cache['expires_at'] > now_ts and _chapter_cache['chapters']:
            return _chapter_cache['chapters']
    chapters = Chapter.query.all()
    id_map = {c.id: c.identifier for c in chapters}
    with _chapter_cache_lock:
        _chapter_cache['expires_at'] = now_ts + 600
        _chapter_cache['chapters'] = chapters
        _chapter_cache['id_to_identifier'] = id_map
    return chapters

def get_chapter_id_to_identifier_map():
    now_ts = time.time()
    with _chapter_cache_lock:
        if _chapter_cache['expires_at'] > now_ts and _chapter_cache['id_to_identifier']:
            return _chapter_cache['id_to_identifier']
    get_all_chapters_cached()
    with _chapter_cache_lock:
        return dict(_chapter_cache['id_to_identifier'])

background_task_executor = ThreadPoolExecutor(
    max_workers=max(2, int(os.environ.get('BACKGROUND_TASK_WORKERS', '2')))
)
SLOW_REQUEST_THRESHOLD_MS = float(os.environ.get('SLOW_REQUEST_THRESHOLD_MS', '1500'))
REQUEST_TIMING_HEADER = 'X-Request-Duration-Ms'

APP_BUILD_ID = (
    os.environ.get('APP_BUILD_ID')
    or os.environ.get('RENDER_GIT_COMMIT')
    or os.environ.get('GIT_COMMIT')
    or 'dev'
)
ASSET_VERSION = os.environ.get('STATIC_ASSET_VERSION') or APP_BUILD_ID[:12]


SECURITY_HONOREE_USER_ID = 29
SECURITY_HONOREE_BADGE = {
    'icon': 'fas fa-user-shield',
    'label': 'Gardien de la securite',
    'short_label': 'Securite',
    'description': (
        "Reconnu pour la securisation de la plateforme et l'amelioration "
        "de la communaute AlgoCompiler."
    ),
}
LEADERBOARD_TOP_STYLES = {
    1: {'slug': 'gold', 'label': 'Gold', 'emoji': '\U0001F947'},
    2: {'slug': 'silver', 'label': 'Silver', 'emoji': '\U0001F948'},
    3: {'slug': 'bronze', 'label': 'Bronze', 'emoji': '\U0001F949'},
}
HALL_OF_FAME_ACKNOWLEDGMENT = (
    "Reconnaissance officielle adressee a Abdelkafi Habbeddine 252 pour son "
    "engagement exemplaire dans la securisation de la plateforme AlgoCompiler. "
    "Son travail a contribue a renforcer la fiabilite de l environnement, a "
    "proteger la communaute et a soutenir une experience plus sure pour tous "
    "les membres. Cette distinction souligne egalement son role dans "
    "l amelioration continue de la communaute, de ses standards et de sa "
    "dynamique collaborative."
)


def is_truthy(value):
    return str(value or '').strip().lower() in {'1', 'true', 'yes', 'on'}


def current_request_duration_ms():
    started_at = getattr(request, '_perf_started_at', None)
    if started_at is None:
        return None
    return round((time.perf_counter() - started_at) * 1000, 3)


def log_perf_event(label, **fields):
    serialized_fields = ' '.join(
        f'{key}={json.dumps(value, ensure_ascii=False)}'
        for key, value in fields.items()
    )
    print(f">>> [PERF] {label} {serialized_fields}".strip(), flush=True)


def _is_safe_path(base_dir, requested_path):
    base_dir_abs = os.path.abspath(base_dir)
    requested_abs = os.path.abspath(requested_path)
    try:
        return os.path.commonpath([base_dir_abs, requested_abs]) == base_dir_abs
    except ValueError:
        return False


def _is_safe_redirect_target(target):
    if not target:
        return False
    host_url = urlparse(request.host_url)
    redirect_url = urlparse(urljoin(request.host_url, target))
    return redirect_url.scheme in ('http', 'https') and host_url.netloc == redirect_url.netloc


def generate_csrf_token():
    token = flask_session.get('_csrf_token')
    if not token:
        token = secrets.token_urlsafe(32)
        flask_session['_csrf_token'] = token
    return token


def get_submitted_csrf_token():
    token = request.headers.get('X-CSRF-Token') or request.headers.get('X-CSRFToken')
    if token:
        return token
    token = request.form.get('csrf_token')
    if token:
        return token
    data = request.get_json(silent=True) or {}
    return data.get('csrf_token')


def csrf_error_response():
    if request.is_json or request.path.startswith('/api/') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': False, 'error': 'Invalid or missing CSRF token'}), 400

    flash('Votre session a expiré. Veuillez réessayer.', 'danger')
    if _is_safe_redirect_target(request.referrer):
        return redirect(request.referrer)
    return redirect(url_for('index'))


@app.before_request
def update_last_seen():
    if current_user.is_authenticated:
        import datetime
        now = datetime.datetime.now(datetime.timezone.utc)
        if current_user.last_seen is None:
            current_user.last_seen = now
            try:
                db.session.commit()
            except:
                db.session.rollback()
        else:
            # We need to make sure last_seen is offset-aware before comparing
            last_seen_utc = current_user.last_seen
            if last_seen_utc.tzinfo is None:
                last_seen_utc = last_seen_utc.replace(tzinfo=datetime.timezone.utc)
            if (now - last_seen_utc).total_seconds() > 3600:
                current_user.last_seen = now
                try:
                    db.session.commit()
                except:
                    db.session.rollback()


@app.before_request
def protect_against_csrf():
    if request.method not in ('POST', 'PUT', 'PATCH', 'DELETE'):
        return None
        
    # Exempt chat API from strict CSRF (secured individually by @login_required)
    if request.path == '/api/chat/message':
        return None

    expected_token = flask_session.get('_csrf_token')
    submitted_token = get_submitted_csrf_token()
    if not expected_token or not submitted_token or not secrets.compare_digest(expected_token, submitted_token):
        return csrf_error_response()
    return None


@app.before_request
def start_request_timing():
    request._perf_started_at = time.perf_counter()


@app.teardown_request
def cleanup_db_session(exc):
    if exc is not None:
        db.session.rollback()
    db.session.remove()


# Basic Config
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config['TEMPLATES_AUTO_RELOAD'] = not is_production

flask_debug_raw = os.environ.get('FLASK_DEBUG', '').strip().lower()
if is_production:
    app.config['DEBUG'] = False
else:
    app.config['DEBUG'] = flask_debug_raw in {'1', 'true', 'yes', 'on'} if flask_debug_raw else is_local_dev

# VULN-001: Fail loudly in production if SECRET_KEY is not set
if is_production and not os.environ.get('SECRET_KEY'):
    import warnings
    warnings.warn(
        "SECRET_KEY is not set! A random key is being used, which will "
        "invalidate all sessions on every restart. Set SECRET_KEY in your "
        "environment variables.",
        stacklevel=1
    )
# VULN-015: Limit upload/request size to prevent DoS via large payloads
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
database_url = os.environ.get('DATABASE_URL')
direct_database_url = (
    os.environ.get('SUPABASE_DIRECT_URL')
    or os.environ.get('DIRECT_DATABASE_URL')
)
session_pooler_url = (
    os.environ.get('SUPABASE_SESSION_POOLER_URL')
    or os.environ.get('SESSION_DATABASE_URL')
)
if direct_database_url and database_url and 'supabase.com:6543' in database_url and is_local_dev:
    database_url = direct_database_url
elif session_pooler_url and database_url and 'pooler.supabase.com:6543' in database_url:
    database_url = session_pooler_url

is_transaction_pooler = bool(database_url and 'pooler.supabase.com:6543' in database_url)
is_session_pooler = bool(
    database_url
    and 'pooler.supabase.com:5432' in database_url
)

if is_transaction_pooler and not is_local_dev:
    print(
        ">>> [WARN] Using Supabase transaction pooler (:6543) on a persistent web app. "
        "Prefer a session pooler URL (:5432) when available.",
        flush=True
    )
use_psycopg3 = False
if database_url:
    # Attempt to detect which driver to use
    import importlib.util
    if importlib.util.find_spec('psycopg') is not None:
        use_psycopg3 = True
    
    if database_url.startswith('postgres://'):
        driver = 'postgresql+psycopg://' if use_psycopg3 else 'postgresql://'
        database_url = database_url.replace('postgres://', driver, 1)
    elif database_url.startswith('postgresql://'):
        if use_psycopg3:
            database_url = database_url.replace('postgresql://', 'postgresql+psycopg://', 1)
    
    # Hide password in logs
    safe_log_url = database_url.split('@')[-1] if '@' in database_url else "HIDDEN"
    print(f">>> CONFIGURED DATABASE_URL: {safe_log_url} (Psycopg3: {use_psycopg3})", flush=True)
app.config['SQLALCHEMY_DATABASE_URI'] = database_url or f"sqlite:///{os.path.join(BASE_DIR, 'algocompiler.db')}"
if not app.config['SQLALCHEMY_DATABASE_URI']:
     # Fail-safe
     app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(BASE_DIR, 'algocompiler.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
engine_options = {
    'pool_recycle': 300,
    'pool_pre_ping': True,
}
if use_psycopg3 and database_url and database_url.startswith('postgresql'):
    engine_options['connect_args'] = {
        'connect_timeout': int(os.environ.get('DB_CONNECT_TIMEOUT_SECONDS', '5'))
    }

if is_transaction_pooler:
    # Supabase transaction pooler (PgBouncer transaction mode) works best without client-side pooling
    engine_options['poolclass'] = NullPool
else:
    engine_options['pool_size'] = 10
    engine_options['max_overflow'] = 20

# Force zero statement cache to prevent DuplicatePreparedStatement errors with psycopg3
# Note: statement_cache_size is not supported with some poolers/dialects in this way
# if use_psycopg3:
#     engine_options['statement_cache_size'] = 0

app.config['SQLALCHEMY_ENGINE_OPTIONS'] = engine_options
# Production session security
session_cookie_secure = os.environ.get('SESSION_COOKIE_SECURE')
if session_cookie_secure is not None:
    app.config['SESSION_COOKIE_SECURE'] = is_truthy(session_cookie_secure)
elif database_url and not database_url.startswith('sqlite'):
    app.config['SESSION_COOKIE_SECURE'] = not is_local_dev

if database_url and not database_url.startswith('sqlite'):
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    from datetime import timedelta
    app.config['REMEMBER_COOKIE_DURATION'] = timedelta(days=30)
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)

safe_uri = app.config['SQLALCHEMY_DATABASE_URI'].split('@')[-1] if '@' in app.config['SQLALCHEMY_DATABASE_URI'] else "sqlite"
print(f">>> [DEBUG] SQLALCHEMY_DATABASE_URI: {safe_uri}", flush=True)

def ensure_schema_migrations():
    """Ensure newly added columns exist in both SQLite and PostgreSQL without requiring full re-creations."""
    try:
        from sqlalchemy import text
        engine = db.engine
        dialect_name = engine.dialect.name

        columns_to_ensure = [
            ('quiz_attempts', 'status', 'VARCHAR(20)', "'completed'"),
            ('quiz_attempts', 'all_correct', 'BOOLEAN', 'FALSE'),
            ('quiz_attempts', 'none_correct', 'BOOLEAN', 'FALSE'),
            ('users', 'equipped_title', 'VARCHAR(500)', 'NULL'),
            ('users', 'study_year', 'VARCHAR(50)', 'NULL'),
            ('users', 'date_of_birth', 'DATE', 'NULL'),
            ('challenge_submissions', 'avg_execution_time_ms', 'NUMERIC(12, 3)', 'NULL'),
            ('challenge_submissions', 'avg_memory_kb', 'NUMERIC(12, 2)', 'NULL'),
            ('challenge_submissions', 'test_case_metrics_json', 'JSON' if dialect_name == 'postgresql' else 'TEXT', 'NULL'),
            ('challenge_submissions', 'attempt_session_id', 'BIGINT' if dialect_name == 'postgresql' else 'INTEGER', 'NULL'),
            ('problems', 'is_published', 'BOOLEAN', 'FALSE'),
        ]

        with engine.connect() as conn:
            if dialect_name == 'postgresql':
                for table, col, col_type, default_val in columns_to_ensure:
                    default_part = f" DEFAULT {default_val}" if default_val and default_val != 'NULL' else ""
                    try:
                        conn.execute(text(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {col} {col_type}{default_part};"))
                    except Exception as col_err:
                        print(f">>> [WARNING] Column {table}.{col} migration warning: {col_err}", flush=True)
                conn.commit()
            elif dialect_name == 'sqlite':
                for table, col, col_type, default_val in columns_to_ensure:
                    try:
                        res = conn.execute(text(f"PRAGMA table_info({table})")).fetchall()
                        existing_cols = [r[1] for r in res]
                        if existing_cols and col not in existing_cols:
                            default_part = f" DEFAULT {default_val}" if default_val and default_val != 'NULL' else ""
                            conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col} {col_type}{default_part};"))
                    except Exception as col_err:
                        print(f">>> [WARNING] Column {table}.{col} migration warning: {col_err}", flush=True)
                conn.commit()
            print(">>> [DEBUG] SCHEMA MIGRATIONS VERIFIED OK", flush=True)
    except Exception as e:
        print(f">>> [WARNING] SCHEMA MIGRATIONS CHECK FAILED (NON-FATAL): {e}", flush=True)


try:
    print(">>> [DEBUG] INITIALIZING DB...", flush=True)
    db.init_app(app)
    with app.app_context():
        should_auto_create_schema = (
            is_truthy(os.environ.get('AUTO_CREATE_DB_SCHEMA'))
            if os.environ.get('AUTO_CREATE_DB_SCHEMA') is not None
            else not (database_url and not database_url.startswith('sqlite'))
        )
        if should_auto_create_schema:
            print(">>> [DEBUG] ENSURING TABLES EXIST (db.create_all)...", flush=True)
            db.create_all()
            print(">>> [DEBUG] DB TABLES CHECKED/CREATED OK", flush=True)
        else:
            print(">>> [DEBUG] SKIPPING db.create_all() FOR MANAGED REMOTE DATABASE", flush=True)

        ensure_schema_migrations()

        should_run_startup_security_migration = (
            is_truthy(os.environ.get('STARTUP_SECURITY_MIGRATION'))
            if os.environ.get('STARTUP_SECURITY_MIGRATION') is not None
            else should_auto_create_schema
        )
        if should_run_startup_security_migration:
            try:
                from web.auth import migrate_security_answers_to_hashes
                migrated_security_answers = migrate_security_answers_to_hashes()
                if migrated_security_answers:
                    print(f">>> [DEBUG] SECURITY ANSWERS HASHED: {migrated_security_answers}", flush=True)
            except Exception as migrate_err:
                print(f">>> [DEBUG] SECURITY ANSWER MIGRATION FAILED (NON-FATAL): {migrate_err}", flush=True)
        else:
            print(">>> [DEBUG] SKIPPING STARTUP SECURITY MIGRATION FOR MANAGED REMOTE DATABASE", flush=True)

        should_auto_seed_on_empty = (
            is_truthy(os.environ.get('AUTO_SEED_ON_EMPTY'))
            if os.environ.get('AUTO_SEED_ON_EMPTY') is not None
            else should_auto_create_schema
        )
        if should_auto_seed_on_empty and not os.environ.get('SKIP_SEED'):
            if Question.query.count() == 0:
                print(">>> [DEBUG] DB EMPTY. SEEDING QUESTIONS FROM JSON...", flush=True)
                try:
                    from web.seed_from_json import seed_from_json
                    seed_from_json()
                    print(">>> [DEBUG] QUESTION SEEDING COMPLETED", flush=True)
                except Exception as seed_err:
                    print(f">>> [DEBUG] QUESTION SEEDING FAILED (NON-FATAL): {seed_err}", flush=True)
        else:
            print(">>> [DEBUG] SKIPPING AUTO-SEED CHECK FOR MANAGED REMOTE DATABASE", flush=True)

except Exception as e:
    print(f">>> [CRITICAL] DB SETUP FAILED: {e}", flush=True)
    import traceback
    traceback.print_exc()
    sys.stdout.flush()

# Mail Config (Resend defaults for easier testing)
app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.resend.com')
app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 465))
app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'false').lower() in ['true', 'on', '1']
app.config['MAIL_USE_SSL'] = os.environ.get('MAIL_USE_SSL', 'true').lower() in ['true', 'on', '1']
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', 'resend')
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', '')
app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', 'onboarding@resend.dev')

# OAuth Config Placeholder
app.config['GOOGLE_CLIENT_ID'] = os.environ.get('GOOGLE_CLIENT_ID', 'placeholder')
app.config['GOOGLE_CLIENT_SECRET'] = os.environ.get('GOOGLE_CLIENT_SECRET', 'placeholder')
app.config['GITHUB_CLIENT_ID'] = os.environ.get('GITHUB_CLIENT_ID', 'placeholder')
app.config['GITHUB_CLIENT_SECRET'] = os.environ.get('GITHUB_CLIENT_SECRET', 'placeholder')

# Initialize extensions
login_manager.init_app(app)
oauth.init_app(app)
mail.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

@app.context_processor
def inject_supabase_credentials():
    # Inject announcement modified time
    announcement_path = os.path.join(app.root_path, 'templates', 'announcement.html')
    mtime = 0
    if os.path.exists(announcement_path):
        mtime = int(os.path.getmtime(announcement_path))

    # NOTE: Supabase URL and anon key are restored for chat functionality.
    # RLS should be used on Supabase side to protect sensitive data.
    return {
        'ANNOUNCEMENT_MTIME': mtime,
        'APP_BUILD_ID': APP_BUILD_ID,
        'ASSET_VERSION': ASSET_VERSION,
        'csrf_token': generate_csrf_token,
        'INJECTED_SUPABASE_URL': os.environ.get('SUPABASE_URL'),
        'INJECTED_SUPABASE_ANON_KEY': os.environ.get('SUPABASE_ANON_KEY')
    }

# Register Auth Blueprint
from web.auth import auth_bp
app.register_blueprint(auth_bp)

# Register Admin Blueprint (Teacher Dashboard at /admin)
from web.admin import admin_bp
app.register_blueprint(admin_bp)

# Register Q&A Blueprint
from web.qa import qa_bp
app.register_blueprint(qa_bp)

# Correct path to examples and fixtures
EXAMPLES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'examples'))
FIXTURES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fixtures'))

@app.route('/')
@app.route('/home')
def index():
    return render_template('index.html')

@app.route('/quiz')
def quiz_redirect():
    return redirect('/course')

@app.route('/challenges')
def challenges_redirect():
    return redirect('/problems')

@app.route('/announcement')
def announcement():
    return render_template('announcement.html')

from flask import send_from_directory
@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/course')
def course():
    return render_template('course.html')

@app.route('/demo-course/<path:filename>')
@app.route('/demoCourse/<path:filename>')
def demo_course_file(filename):
    full_path = os.path.join(os.path.join(app.root_path, 'DemoCourse'), filename)
    if not _is_safe_path(os.path.join(app.root_path, 'DemoCourse'), full_path):
        return jsonify({'error': 'Invalid filename'}), 400
    return send_from_directory(os.path.join(app.root_path, 'DemoCourse'), filename)

@app.route('/api/course', methods=['GET'])
def get_course():
    return jsonify(get_cached_course_outline_payload())


@app.route('/api/course/chapters/<string:identifier>', methods=['GET'])
def get_course_chapter(identifier):
    payload = get_cached_course_chapter_payload(identifier)
    if not payload:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(payload)

@app.route('/progress')
@login_required
def progress_page():
    from web.auth import CS_PIONEER_NAMES
    initial_progress = None
    try:
        initial_progress = {
            'success': True,
            'progress': get_cached_user_progress_summary_payload(current_user.id)
        }
    except Exception:
        initial_progress = None
    cur_pioneer = ""
    cur_digits = ""
    if current_user.name and '#' in current_user.name:
        parts = current_user.name.split('#', 1)
        cur_pioneer = parts[0].strip()
        cur_digits = parts[1].strip()
    return render_template(
        'progress.html',
        initial_progress=initial_progress,
        cs_names=CS_PIONEER_NAMES,
        cur_pioneer=cur_pioneer,
        cur_digits=cur_digits
    )

@app.route('/problems')
def problems_page():
    return render_template('problems.html')

@app.route('/challenge/<int:problem_id>')
def challenge_page(problem_id):
    problem = db.session.get(Problem, problem_id)
    if not problem:
        return render_template('errors.html'), 404
    if not problem.is_published:
        return render_template('errors.html'), 403
    if current_user.is_authenticated:
        get_or_create_active_attempt_session(current_user.id, problem_id)
    return render_template('challenge.html', problem_id=problem_id)

def utcnow():
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)

def decimal_to_float(value):
    if value is None:
        return None
    if isinstance(value, Decimal):
        return float(value)
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

def safe_metric_sort_value(value):
    converted = decimal_to_float(value)
    return converted if converted is not None else float('inf')

def average_metric_from_json(metrics_json, key):
    if not isinstance(metrics_json, list):
        return None
    values = []
    for item in metrics_json:
        if not isinstance(item, dict):
            continue
        numeric_value = decimal_to_float(item.get(key))
        if numeric_value is not None:
            values.append(numeric_value)
    if not values:
        return None
    return round(sum(values) / len(values), 3)

def build_test_case_metrics(results):
    return [
        {
            'test_case_id': result.get('test_case_id'),
            'passed': bool(result.get('passed')),
            'execution_time_ms': round(float(result.get('execution_time_ms') or 0.0), 3),
            'memory_usage_kb': int(result.get('memory_usage_kb') or 0),
            'error': result.get('error')
        }
        for result in results
    ]

def get_or_create_active_attempt_session(user_id, problem_id):
    session = (
        ChallengeAttemptSession.query
        .filter_by(user_id=user_id, problem_id=problem_id, completed_at=None)
        .order_by(ChallengeAttemptSession.started_at.desc())
        .first()
    )
    if session:
        return session

    session = ChallengeAttemptSession(
        user_id=user_id,
        problem_id=problem_id,
        started_at=utcnow(),
        created_at=utcnow()
    )
    db.session.add(session)
    db.session.commit()
    return session

def invalidate_problem_leaderboard_cache(problem_id=None):
    if problem_id is None:
        problem_leaderboard_cache.clear()
        return
    problem_leaderboard_cache.pop(int(problem_id), None)


def invalidate_problem_detail_cache(problem_id=None):
    with problem_cache_lock:
        if problem_id is None:
            problem_detail_cache.clear()
            problem_navigation_cache['expires_at'] = 0
            problem_navigation_cache['problem_ids'] = []
            return

        problem_detail_cache.pop(int(problem_id), None)
        problem_navigation_cache['expires_at'] = 0
        problem_navigation_cache['problem_ids'] = []


def invalidate_course_content_cache(identifier=None):
    with course_cache_lock:
        course_outline_cache['expires_at'] = 0
        course_outline_cache['payload'] = None
        if identifier is None:
            course_chapter_cache.clear()
            return
        course_chapter_cache.pop(str(identifier), None)


def get_cached_course_outline_payload():
    now_ts = time.time()
    with course_cache_lock:
        cached_payload = course_outline_cache.get('payload')
        if cached_payload is not None and cached_payload.get('chapters') and course_outline_cache['expires_at'] > now_ts:
            return cached_payload

    chapters = (
        CourseChapter.query
        .filter_by(is_published=True)
        .order_by(CourseChapter.order_index.asc(), CourseChapter.id.asc())
        .all()
    )
    payload = {
        'chapters': [
            {
                'id': chapter.identifier,
                'title': chapter.title,
                'icon': chapter.icon,
                'file': f"/api/course/chapters/{chapter.identifier}",
                'sections': []
            }
            for chapter in chapters
        ]
    }

    with course_cache_lock:
        course_outline_cache['expires_at'] = now_ts + COURSE_CONTENT_CACHE_TTL_SECONDS
        course_outline_cache['payload'] = payload
    return payload


def get_cached_course_chapter_payload(identifier):
    cache_key = str(identifier)
    now_ts = time.time()
    with course_cache_lock:
        cached_entry = course_chapter_cache.get(cache_key)
        if cached_entry and cached_entry['expires_at'] > now_ts:
            return cached_entry['payload']

    chapter = (
        CourseChapter.query
        .options(joinedload(CourseChapter.sections))
        .filter_by(identifier=cache_key, is_published=True)
        .first()
    )
    if not chapter:
        return None

    payload = {
        'id': chapter.identifier,
        'title': chapter.title,
        'sections': [
            {
                'title': section.title,
                'content': section.content,
                'code': section.code
            }
            for section in chapter.sections
        ]
    }

    with course_cache_lock:
        course_chapter_cache[cache_key] = {
            'expires_at': now_ts + COURSE_CONTENT_CACHE_TTL_SECONDS,
            'payload': payload
        }

    return payload


def prewarm_course_cache_in_background():
    def _prewarm_job():
        try:
            with app.app_context():
                get_cached_course_outline_payload()
                chapters = CourseChapter.query.filter_by(is_published=True).all()
                for ch in chapters:
                    get_cached_course_chapter_payload(ch.identifier)
                print(">>> [DEBUG] COURSE CONTENT PRE-WARMED IN BACKGROUND", flush=True)
        except Exception as pe:
            print(f">>> [DEBUG] PREWARM FAILED (NON-FATAL): {pe}", flush=True)

    background_task_executor.submit(_prewarm_job)


try:
    prewarm_course_cache_in_background()
except Exception:
    pass


def invalidate_quiz_bank_cache(chapter_identifier=None):
    with quiz_cache_lock:
        if chapter_identifier is None:
            quiz_question_bank_cache.clear()
            return
        quiz_question_bank_cache.pop(str(chapter_identifier), None)


def get_cached_quiz_question_bank(chapter_identifier):
    cache_key = str(chapter_identifier)
    now_ts = time.time()
    with quiz_cache_lock:
        cached_entry = quiz_question_bank_cache.get(cache_key)
        if cached_entry and cached_entry['expires_at'] > now_ts:
            return cached_entry['payload']

    chapter = (
        Chapter.query
        .options(joinedload(Chapter.questions).joinedload(Question.choices))
        .filter_by(identifier=cache_key)
        .first()
    )
    if not chapter:
        return None

    payload = {
        'chapter_id': chapter.id,
        'questions': [
            {
                'id': question.id,
                'type': question.type,
                'difficulty': question.difficulty,
                'concept': question.concept,
                'text': question.text,
                'explanation': question.explanation,
                'choices': [
                    {
                        'id': choice.id,
                        'text': choice.text,
                        'is_correct': bool(choice.is_correct)
                    }
                    for choice in question.choices
                ]
            }
            for question in chapter.questions
        ]
    }

    with quiz_cache_lock:
        quiz_question_bank_cache[cache_key] = {
            'expires_at': now_ts + QUIZ_BANK_CACHE_TTL_SECONDS,
            'payload': payload
        }
    return payload


def get_cached_problem_payload(problem_id):
    now_ts = time.time()
    cache_key = int(problem_id)
    with problem_cache_lock:
        cached_entry = problem_detail_cache.get(cache_key)
        if cached_entry and cached_entry['expires_at'] > now_ts:
            return cached_entry['payload']

    problem = (
        Problem.query
        .options(joinedload(Problem.test_cases))
        .filter(Problem.id == cache_key)
        .first()
    )
    if not problem:
        return None

    payload = {
        'id': problem.id,
        'title': problem.title,
        'description': problem.description,
        'topic': problem.topic,
        'difficulty': problem.difficulty,
        'template_code': problem.template_code,
        'is_published': bool(problem.is_published),
        'test_cases': [
            {
                'id': tc.id,
                'input': tc.input_data,
                'expected_output': tc.expected_output
            }
            for tc in problem.test_cases if tc.is_public
        ]
    }
    with problem_cache_lock:
        problem_detail_cache[cache_key] = {
            'expires_at': now_ts + PROBLEM_DETAIL_CACHE_TTL_SECONDS,
            'payload': payload
        }
    return payload


def get_cached_navigation_problem_ids():
    now_ts = time.time()
    with problem_cache_lock:
        if problem_navigation_cache['expires_at'] > now_ts:
            return list(problem_navigation_cache['problem_ids'])

    problem_ids = [
        row[0]
        for row in db.session.query(Problem.id)
        .filter(Problem.is_published.is_(True))
        .order_by(Problem.id.asc())
        .all()
    ]
    with problem_cache_lock:
        problem_navigation_cache['expires_at'] = now_ts + PROBLEM_DETAIL_CACHE_TTL_SECONDS
        problem_navigation_cache['problem_ids'] = list(problem_ids)
    return problem_ids


def invalidate_user_level_cache(user_id=None):
    with user_level_cache_lock:
        if user_id is None:
            user_level_cache.clear()
            user_level_refresh_futures.clear()
            return
        user_level_cache.pop(int(user_id), None)
        user_level_refresh_futures.pop(int(user_id), None)


def invalidate_global_user_stats_cache():
    with global_user_stats_cache_lock:
        global_user_stats_cache['expires_at'] = 0
        global_user_stats_cache['payload'] = None
    with user_badges_cache_lock:
        user_badges_cache.clear()


def invalidate_user_progress_summary_cache(user_id=None):
    with user_progress_cache_lock:
        if user_id is None:
            user_progress_cache.clear()
            return
        user_progress_cache.pop(int(user_id), None)


def invalidate_user_progress_advanced_cache(user_id=None):
    with user_progress_advanced_cache_lock:
        if user_id is None:
            user_progress_advanced_cache.clear()
            return
        user_progress_advanced_cache.pop(int(user_id), None)


def invalidate_user_badges_cache(user_id=None):
    with user_badges_cache_lock:
        if user_id is None:
            user_badges_cache.clear()
            return
        user_badges_cache.pop(int(user_id), None)


def invalidate_user_progress_cache(user_id=None):
    invalidate_user_progress_summary_cache(user_id)
    invalidate_user_progress_advanced_cache(user_id)
    invalidate_user_badges_cache(user_id)


def get_cached_user_payload(cache, lock, ttl_seconds, user_id, builder):
    user_id = int(user_id)
    now_ts = time.time()
    with lock:
        cached_entry = cache.get(user_id)
        if cached_entry and cached_entry['expires_at'] > now_ts:
            return cached_entry['payload']

    payload = builder(user_id)
    with lock:
        cache[user_id] = {
            'expires_at': now_ts + ttl_seconds,
            'payload': payload
        }
    return payload


def get_default_level_badge():
    return {
        'num': 1,
        'name': 'Débutant',
        'icon': '🧭',
        'icon_class': 'fa-solid fa-compass',
        'color': '#94a3b8',
        'glow': 'rgba(148,163,184,0.45)'
    }


def has_rankable_leaderboard_score(entry):
    try:
        return float((entry or {}).get('score') or 0) > 0
    except (TypeError, ValueError):
        return False


def leaderboard_sort_key(item):
    user_id, entry = item
    entry = entry or {}
    return (
        0 if has_rankable_leaderboard_score(entry) else 1,
        -float(entry.get('score') or 0),
        -int(entry.get('challenges') or 0),
        -int(entry.get('quizzes') or 0),
        -int(entry.get('badges') or 0),
        str(entry.get('name') or '').strip().lower(),
        int(user_id)
    )


def compute_user_leaderboard_bucket(stats_by_user, user_id):
    if not stats_by_user or user_id not in stats_by_user:
        return {
            'rank': None,
            'total_users': 0,
            'top_percent': 100.0,
            'bucket_percent': 100,
            'bucket_label': 'Top 100%'
        }

    ranked_users = [
        item
        for item in sorted(stats_by_user.items(), key=leaderboard_sort_key)
        if has_rankable_leaderboard_score(item[1])
    ]

    total_users = len(ranked_users)
    if not has_rankable_leaderboard_score(stats_by_user.get(user_id)):
        return {
            'rank': None,
            'total_users': total_users,
            'top_percent': 100.0,
            'bucket_percent': 100,
            'bucket_label': 'Top 100%'
        }

    user_rank = next((index for index, (uid, _) in enumerate(ranked_users, start=1) if uid == user_id), None)
    if user_rank is None:
        return {
            'rank': None,
            'total_users': total_users,
            'top_percent': 100.0,
            'bucket_percent': 100,
            'bucket_label': 'Top 100%'
        }

    if total_users <= 1:
        top_percent = 1.0
    else:
        top_percent = round((user_rank / total_users) * 100, 1)

    if user_rank == 1:
        bucket_percent = 1
    else:
        thresholds = [1, 5, 10, 20, 50, 70]
        bucket_percent = next((threshold for threshold in thresholds if top_percent <= threshold), 100)

    return {
        'rank': user_rank,
        'total_users': total_users,
        'top_percent': top_percent,
        'bucket_percent': bucket_percent,
        'bucket_label': f'Top {bucket_percent}%'
    }


def compute_user_prestige_badge(user_id, global_user_stats=None):
    """Compute prestige badge: Top 1, Top 2, Top 3, Top 1%, Top 5% across all users all-time."""
    if global_user_stats is None:
        global_user_stats = get_bulk_users_stats(allow_stale=True)
    bucket = compute_user_leaderboard_bucket(global_user_stats, user_id)
    
    rank = bucket.get('rank')
    top_pct = bucket.get('top_percent', 100.0)
    
    if rank == 1:
        return {
            'type': 'top1',
            'label': '🥇 N° 1 Global',
            'short_label': '🥇 Top 1',
            'class': 'prestige-top1',
            'icon': 'fas fa-crown',
            'color': '#ffd700',
            'rank': 1,
            'percentile': top_pct
        }
    elif rank == 2:
        return {
            'type': 'top2',
            'label': '🥈 N° 2 Global',
            'short_label': '🥈 Top 2',
            'class': 'prestige-top2',
            'icon': 'fas fa-medal',
            'color': '#e2e8f0',
            'rank': 2,
            'percentile': top_pct
        }
    elif rank == 3:
        return {
            'type': 'top3',
            'label': '🥉 N° 3 Global',
            'short_label': '🥉 Top 3',
            'class': 'prestige-top3',
            'icon': 'fas fa-medal',
            'color': '#f97316',
            'rank': 3,
            'percentile': top_pct
        }
    elif rank is not None and top_pct <= 1.0:
        return {
            'type': 'top1pct',
            'label': '💎 Top 1% Global',
            'short_label': '💎 Top 1%',
            'class': 'prestige-top1pct',
            'icon': 'fas fa-gem',
            'color': '#38bdf8',
            'rank': rank,
            'percentile': top_pct
        }
    elif rank is not None and top_pct <= 5.0:
        return {
            'type': 'top5pct',
            'label': '⚡ Top 5% Global',
            'short_label': '⚡ Top 5%',
            'class': 'prestige-top5pct',
            'icon': 'fas fa-bolt',
            'color': '#c084fc',
            'rank': rank,
            'percentile': top_pct
        }
    elif rank is not None and top_pct <= 10.0:
        return {
            'type': 'top10pct',
            'label': f'Top 10% (#{rank})',
            'short_label': 'Top 10%',
            'class': 'prestige-top10pct',
            'icon': 'fas fa-award',
            'color': '#10b981',
            'rank': rank,
            'percentile': top_pct
        }
    return None


def decorate_leaderboard_entry(user_id, raw_entry, rank=None, global_stats=None):
    entry = dict(raw_entry or {})
    entry['user_id'] = int(user_id)
    entry['rank'] = rank
    entry['is_ranked'] = rank is not None
    entry['display_rank'] = rank if rank is not None else '--'

    style = LEADERBOARD_TOP_STYLES.get(rank)
    entry['rank_style'] = style['slug'] if style else None
    entry['rank_badge'] = style['emoji'] if style else None
    entry['security_badge'] = (
        dict(SECURITY_HONOREE_BADGE)
        if int(user_id) == SECURITY_HONOREE_USER_ID
        else None
    )
    entry['prestige_badge'] = compute_user_prestige_badge(user_id, global_stats)
    entry['equipped_title'] = raw_entry.get('equipped_title') or (raw_entry.get('level') or {}).get('name')
    return entry


def build_ranked_leaderboard_entries(stats_by_user, year=None):
    items = list((stats_by_user or {}).items())
    if year is not None and str(year).lower() not in {'overall', 'all'}:
        target_year = str(year)
        items = [
            (uid, entry) for uid, entry in items
            if str(entry.get('study_year') or '') == target_year
        ]

    sorted_items = sorted(items, key=leaderboard_sort_key)
    entries = []
    ranked_position = 0

    for user_id, raw_entry in sorted_items:
        rank = None
        if has_rankable_leaderboard_score(raw_entry):
            ranked_position += 1
            rank = ranked_position
        entries.append(decorate_leaderboard_entry(user_id, raw_entry, rank=rank, global_stats=stats_by_user))

    return entries


def build_public_honoree_payload(user_id, entries_by_user=None):
    user = db.session.get(User, int(user_id))
    if not user:
        return None

    return {
        'name': user.name,
        'security_badge': (
            dict(SECURITY_HONOREE_BADGE)
            if int(user_id) == SECURITY_HONOREE_USER_ID
            else None
        ),
    }


def build_global_leaderboard_response_payload(year=None):
    stats = get_bulk_users_stats(allow_stale=True, refresh_async=True)
    with global_user_stats_cache_lock:
        has_cached_payload = global_user_stats_cache.get('payload') is not None
        refresh_status = dict(global_user_stats_refresh_state)

    if stats is None:
        fallback_stats = build_lightweight_leaderboard_payload()
        if fallback_stats:
            leaderboard = build_ranked_leaderboard_entries(fallback_stats, year=year)
            ranked_count = sum(1 for entry in leaderboard if entry.get('is_ranked'))
            return {
                'success': True,
                'leaderboard': leaderboard,
                'loading': False,
                'partial': True,
                'refresh_status': refresh_status['status'],
                'ranked_user_count': ranked_count,
                'unranked_user_count': len(leaderboard) - ranked_count,
            }

        has_any_user = db.session.query(User.id).limit(1).first() is not None
        if not has_any_user:
            return {
                'success': True,
                'leaderboard': [],
                'loading': False,
                'partial': False,
                'refresh_status': refresh_status['status'],
                'ranked_user_count': 0,
                'unranked_user_count': 0,
            }

    if stats is None and not has_cached_payload:
        return {
            'success': True,
            'leaderboard': [],
            'loading': True,
            'partial': False,
            'refresh_status': refresh_status['status'],
            'ranked_user_count': 0,
            'unranked_user_count': 0,
        }

    leaderboard = build_ranked_leaderboard_entries(stats or {}, year=year)
    ranked_count = sum(1 for entry in leaderboard if entry.get('is_ranked'))

    return {
        'success': True,
        'leaderboard': leaderboard,
        'loading': False,
        'partial': False,
        'refresh_status': refresh_status['status'],
        'ranked_user_count': ranked_count,
        'unranked_user_count': len(leaderboard) - ranked_count,
    }


def get_cached_bulk_user_level(user_id):
    user_id = int(user_id)
    now_ts = time.time()
    with global_user_stats_cache_lock:
        cached_payload = global_user_stats_cache.get('payload')
        if cached_payload is not None and global_user_stats_cache['expires_at'] > now_ts:
            level = (cached_payload.get(user_id) or {}).get('level')
            if level:
                return level
    try:
        snapshot = get_cached_user_level_snapshot(user_id)
        if snapshot and snapshot.get('level'):
            return snapshot['level']
    except Exception:
        pass
    return get_default_level_badge()


def build_user_level_snapshot(user_id):
    xp_total, _, level_dict, xp_to_next = compute_xp_and_level(user_id)
    return {
        'xp_total': xp_total,
        'level': level_dict,
        'xp_to_next': xp_to_next,
        'computed_at': utcnow().isoformat()
    }


def get_cached_user_level_snapshot(user_id, force_refresh=False):
    user_id = int(user_id)
    now_ts = time.time()
    with user_level_cache_lock:
        cached_entry = user_level_cache.get(user_id)
        if cached_entry and not force_refresh and cached_entry['expires_at'] > now_ts:
            return cached_entry['payload']

    payload = build_user_level_snapshot(user_id)
    with user_level_cache_lock:
        user_level_cache[user_id] = {
            'expires_at': now_ts + USER_LEVEL_CACHE_TTL_SECONDS,
            'payload': payload
        }
    return payload


def refresh_user_level_snapshot(user_id):
    user_id = int(user_id)
    try:
        with app.app_context():
            payload = build_user_level_snapshot(user_id)
    except Exception as exc:
        print(f">>> [WARN] USER LEVEL REFRESH FAILED FOR {user_id}: {exc}", flush=True)
        raise
    finally:
        with user_level_cache_lock:
            future = user_level_refresh_futures.get(user_id)
            if future is not None and future.done():
                user_level_refresh_futures.pop(user_id, None)

    with user_level_cache_lock:
        user_level_cache[user_id] = {
            'expires_at': time.time() + USER_LEVEL_CACHE_TTL_SECONDS,
            'payload': payload
        }
        user_level_refresh_futures.pop(user_id, None)
    return payload


def schedule_user_level_refresh(user_id):
    user_id = int(user_id)
    with user_level_cache_lock:
        future = user_level_refresh_futures.get(user_id)
        if future and not future.done():
            return future
        future = background_task_executor.submit(refresh_user_level_snapshot, user_id)
        user_level_refresh_futures[user_id] = future
        return future

def get_problem_leaderboard_base(problem_id):
    now_ts = time.time()
    cache_key = int(problem_id)
    cached = problem_leaderboard_cache.get(cache_key)
    if cached and cached['expires_at'] > now_ts:
        return cached['payload']
    if cached:
        problem_leaderboard_cache.pop(cache_key, None)

    problem = db.session.get(Problem, problem_id)
    if not problem:
        return None

    submissions = (
        ChallengeSubmission.query
        .options(joinedload(ChallengeSubmission.user))
        .filter(
            ChallengeSubmission.problem_id == problem_id,
            ChallengeSubmission.passed == True
        )
        .all()
    )

    selected_rows = {}
    available_years = set()
    for submission in submissions:
        if not submission.user:
            continue

        study_year = str(submission.user.study_year or '').strip()
        joined_year = submission.user.created_at.year if submission.user.created_at else None
        effective_year = int(study_year) if study_year.isdigit() else joined_year
        if effective_year is not None:
            available_years.add(effective_year)
        if joined_year is not None:
            available_years.add(joined_year)

        current_level = get_cached_bulk_user_level(submission.user_id)

        row = {
            'submission_id': submission.id,
            'user_id': submission.user_id,
            'name': submission.user.name or f'User {submission.user_id}',
            'study_year': study_year or (str(joined_year) if joined_year else ''),
            'joined_year': joined_year,
            'level': current_level,
            'equipped_title': getattr(submission.user, 'equipped_title', None) or (current_level.get('name') if isinstance(current_level, dict) else 'Débutant'),
            'prestige_badge': compute_user_prestige_badge(submission.user_id),
            'time_taken_seconds': int(submission.time_taken_seconds or 0),
            'avg_execution_time_ms': (
                decimal_to_float(submission.avg_execution_time_ms)
                if decimal_to_float(submission.avg_execution_time_ms) is not None
                else average_metric_from_json(submission.test_case_metrics_json, 'execution_time_ms')
            ),
            'avg_memory_kb': (
                decimal_to_float(submission.avg_memory_kb)
                if decimal_to_float(submission.avg_memory_kb) is not None
                else average_metric_from_json(submission.test_case_metrics_json, 'memory_usage_kb')
            ),
            'timestamp': submission.timestamp,
            'test_cases_total': int(submission.test_cases_total or 0),
            'test_cases_passed': int(submission.test_cases_passed or 0),
            '_selection_key': (
                safe_metric_sort_value(submission.avg_execution_time_ms),
                safe_metric_sort_value(submission.avg_memory_kb),
                int(submission.time_taken_seconds or 0),
                submission.timestamp or datetime.datetime.max,
                submission.id
            )
        }

        existing = selected_rows.get(submission.user_id)
        if existing is None or row['_selection_key'] < existing['_selection_key']:
            selected_rows[submission.user_id] = row

    rows = []
    for row in selected_rows.values():
        row.pop('_selection_key', None)
        rows.append(row)

    current_acad_year = get_current_academic_year()
    if current_acad_year:
        available_years.add(current_acad_year)

    payload = {
        'problem': {
            'id': problem.id,
            'title': problem.title,
            'difficulty': problem.difficulty
        },
        'rows': rows,
        'available_years': sorted(available_years, reverse=True)
    }
    problem_leaderboard_cache[cache_key] = {
        'expires_at': now_ts + PROBLEM_LEADERBOARD_CACHE_TTL_SECONDS,
        'payload': payload
    }
    return payload

def compute_participation_aware_score(value, values, missing_score=0.0, baseline_score=6.0):
    numeric_values = [decimal_to_float(v) for v in values if decimal_to_float(v) is not None]
    numeric_value = decimal_to_float(value)
    if numeric_value is None:
        return round(missing_score, 3)

    if not numeric_values:
        return 10.0

    best = min(numeric_values)
    worst = max(numeric_values)
    if best == worst:
        return 10.0

    relative_score = (worst - numeric_value) / (worst - best)
    raw_score = 2.0 + 8.0 * relative_score
    participant_count = len(numeric_values)
    confidence = min(1.0, max(0.0, (participant_count - 1) / 4.0))
    adjusted_score = baseline_score + confidence * (raw_score - baseline_score)
    return round(max(missing_score, min(10.0, adjusted_score)), 3)

def compute_problem_placement_counts(passed_submissions):
    best_submissions_by_problem = defaultdict(dict)
    for sub in passed_submissions:
        selected_for_problem = best_submissions_by_problem[sub.problem_id]
        avg_exec_raw = getattr(sub, 'avg_execution_time_ms', None)
        avg_memory_raw = getattr(sub, 'avg_memory_kb', None)
        metrics_json = getattr(sub, 'test_case_metrics_json', None)
        avg_exec = (
            decimal_to_float(avg_exec_raw)
            if decimal_to_float(avg_exec_raw) is not None
            else average_metric_from_json(metrics_json, 'execution_time_ms')
        )
        avg_memory = (
            decimal_to_float(avg_memory_raw)
            if decimal_to_float(avg_memory_raw) is not None
            else average_metric_from_json(metrics_json, 'memory_usage_kb')
        )
        candidate = {
            'user_id': sub.user_id,
            'time_taken_seconds': int(getattr(sub, 'time_taken_seconds', 0) or 0),
            'avg_execution_time_ms': avg_exec,
            'avg_memory_kb': avg_memory,
            'timestamp': getattr(sub, 'timestamp', None),
            '_selection_key': (
                safe_metric_sort_value(avg_exec),
                safe_metric_sort_value(avg_memory),
                int(getattr(sub, 'time_taken_seconds', 0) or 0),
                getattr(sub, 'timestamp', None) or datetime.datetime.max,
                getattr(sub, 'id', 0)
            )
        }
        existing = selected_for_problem.get(sub.user_id)
        if existing is None or candidate['_selection_key'] < existing['_selection_key']:
            selected_for_problem[sub.user_id] = candidate

    placement_counts = defaultdict(lambda: {'top1': 0, 'top3': 0, 'top10': 0})
    for problem_rows in best_submissions_by_problem.values():
        rows = list(problem_rows.values())
        solve_values = [row.get('time_taken_seconds') for row in rows if row.get('time_taken_seconds') is not None]
        exec_values = [row.get('avg_execution_time_ms') for row in rows if row.get('avg_execution_time_ms') is not None]
        memory_values = [row.get('avg_memory_kb') for row in rows if row.get('avg_memory_kb') is not None]

        ranked_rows = []
        for row in rows:
            tests_score = 10.0
            solve_time_score = compute_participation_aware_score(row.get('time_taken_seconds'), solve_values)
            execution_score = compute_participation_aware_score(
                row.get('avg_execution_time_ms'),
                exec_values,
                missing_score=2.0
            )
            memory_score = compute_participation_aware_score(
                row.get('avg_memory_kb'),
                memory_values,
                missing_score=2.0
            )
            final_score = round(
                tests_score + solve_time_score + execution_score + memory_score,
                3
            )
            ranked_rows.append({
                'user_id': row['user_id'],
                'final_score': final_score,
                'time_taken_seconds': int(row.get('time_taken_seconds') or 0),
                'avg_execution_time_ms': row.get('avg_execution_time_ms'),
                'avg_memory_kb': row.get('avg_memory_kb'),
                'timestamp': row.get('timestamp') or datetime.datetime.max
            })

        ranked_rows.sort(
            key=lambda row: (
                -row['final_score'],
                row['time_taken_seconds'],
                safe_metric_sort_value(row.get('avg_execution_time_ms')),
                safe_metric_sort_value(row.get('avg_memory_kb')),
                row['timestamp'],
                row['user_id']
            )
        )

        for rank, row in enumerate(ranked_rows, start=1):
            counters = placement_counts[row['user_id']]
            if rank == 1:
                counters['top1'] += 1
            if rank <= 3:
                counters['top3'] += 1
            if rank <= 10:
                counters['top10'] += 1

    return placement_counts

def build_problem_leaderboard_rows(problem_id, year=None):
    base_payload = get_problem_leaderboard_base(problem_id)
    if base_payload is None:
        return None

    rows = list(base_payload['rows'])
    if year is not None:
        rows = [row for row in rows if row.get('joined_year') == year or str(row.get('study_year')) == str(year)]

    solve_values = [row.get('time_taken_seconds') for row in rows if row.get('time_taken_seconds') is not None]
    exec_values = [row.get('avg_execution_time_ms') for row in rows if row.get('avg_execution_time_ms') is not None]
    memory_values = [row.get('avg_memory_kb') for row in rows if row.get('avg_memory_kb') is not None]

    scored_rows = []
    for row in rows:
        scored_row = dict(row)
        scored_row['tests_score'] = 10.0
        scored_row['solve_time_score'] = compute_participation_aware_score(
            row.get('time_taken_seconds'),
            solve_values
        )
        scored_row['execution_score'] = compute_participation_aware_score(
            row.get('avg_execution_time_ms'),
            exec_values,
            missing_score=2.0
        )
        scored_row['memory_score'] = compute_participation_aware_score(
            row.get('avg_memory_kb'),
            memory_values,
            missing_score=2.0
        )
        scored_row['final_score'] = round(
            scored_row['tests_score']
            + scored_row['solve_time_score']
            + scored_row['execution_score']
            + scored_row['memory_score'],
            3
        )
        scored_rows.append(scored_row)

    ranked_rows = sorted(
        scored_rows,
        key=lambda row: (
            -row['final_score'],
            int(row.get('time_taken_seconds') or 0),
            safe_metric_sort_value(row.get('avg_execution_time_ms')),
            safe_metric_sort_value(row.get('avg_memory_kb')),
            row.get('timestamp') or datetime.datetime.max,
            row.get('user_id') or 0
        )
    )

    for index, row in enumerate(ranked_rows, start=1):
        row['rank'] = index
        row['badge_label'] = 'Top 1' if index == 1 else ('Top 10' if index <= 10 else None)

    return {
        'problem': base_payload['problem'],
        'available_years': base_payload['available_years'],
        'rows': ranked_rows
    }

def sort_problem_leaderboard_rows(rows, sort_key, order):
    if sort_key == 'final_score':
        ranked_rows = sorted(
            rows,
            key=lambda row: (
                row['rank'],
                int(row.get('time_taken_seconds') or 0),
                safe_metric_sort_value(row.get('avg_execution_time_ms')),
                safe_metric_sort_value(row.get('avg_memory_kb')),
                row.get('timestamp') or datetime.datetime.max,
                row.get('user_id') or 0
            )
        )
        return list(reversed(ranked_rows)) if order == 'asc' else ranked_rows

    def metric_key(row):
        metric_value = decimal_to_float(row.get(sort_key))
        is_missing = metric_value is None
        sortable_value = metric_value if metric_value is not None else 0.0
        if order == 'desc':
            sortable_value *= -1
        return (is_missing, sortable_value, row['rank'])

    return sorted(rows, key=metric_key)

def serialize_leaderboard_row(row):
    return {
        'rank': row['rank'],
        'user_id': row['user_id'],
        'name': row['name'],
        'level': row['level'],
        'joined_year': row.get('joined_year'),
        'study_year': str(row.get('study_year') or row.get('joined_year') or ''),
        'time_taken_seconds': int(row.get('time_taken_seconds') or 0),
        'avg_execution_time_ms': decimal_to_float(row.get('avg_execution_time_ms')),
        'avg_memory_kb': decimal_to_float(row.get('avg_memory_kb')),
        'tests_score': round(float(row.get('tests_score') or 0.0), 3),
        'solve_time_score': round(float(row.get('solve_time_score') or 0.0), 3),
        'execution_score': round(float(row.get('execution_score') or 0.0), 3),
        'memory_score': round(float(row.get('memory_score') or 0.0), 3),
        'final_score': round(float(row.get('final_score') or 0.0), 3),
        'badge_label': row.get('badge_label'),
        'equipped_title': row.get('equipped_title'),
        'prestige_badge': row.get('prestige_badge')
    }

@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    Security headers added: VULN-012
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    r.headers['X-App-Build'] = APP_BUILD_ID

    # ── Security headers (VULN-012) ────────────────────────────────────────
    r.headers['X-Frame-Options'] = 'SAMEORIGIN'
    r.headers['X-Content-Type-Options'] = 'nosniff'
    r.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    r.headers['X-XSS-Protection'] = '1; mode=block'
    if not app.debug:
        r.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    # ───────────────────────────────────────────────────────────────────────

    request_duration_ms = current_request_duration_ms()
    if request_duration_ms is not None:
        r.headers[REQUEST_TIMING_HEADER] = f"{request_duration_ms:.3f}"
        interesting_prefixes = (
            '/api/submissions',
            '/api/user/progress',
            '/api/problems',
            '/api/challenge',
            '/challenge/'
        )
        is_interesting = any(request.path.startswith(prefix) for prefix in interesting_prefixes)
        if request_duration_ms >= SLOW_REQUEST_THRESHOLD_MS or (is_interesting and request_duration_ms >= 250):
            log_perf_event(
                'request',
                method=request.method,
                path=request.path,
                status=getattr(r, 'status_code', None),
                duration_ms=request_duration_ms
            )
    return r

@app.route('/examples')
def list_examples():
    try:
        categories = {
            "Basics": [],
            "Arrays": [],
            "Strings": [],
            "Functions": [],
            "Pointers": [],
            "Dynamic_Allocation": [],
            "Enregistrements": [],
            "Listes_Chainees": [],
            "Piles": [],
            "Files": []
        }

        # Helper to categorize based on filename
        def categorize(filepath, is_fixture=False):
            if is_fixture:
                return "Fixtures"
            
            dirname = os.path.dirname(filepath).replace('\\', '/')
            if dirname:
                cat = dirname.replace('Allocation', ' Allocation').replace('_', ' ').replace('  ', ' ')
                # normalize common case
                if "dynamic" in cat.lower() and "alloc" in cat.lower():
                    cat = "Dynamic Allocation"
                if "enregistr" in cat.lower():
                    return "Enregistrements"
                if "pile" in cat.lower() or "stack" in cat.lower():
                    return "Piles"
                if "file" in cat.lower() or "queue" in cat.lower():
                    return "Files"
                if "liste" in cat.lower() or "chain" in cat.lower():
                    return "Listes_Chainees"
                return cat

            name = filepath.lower()
            if "dynamic" in name or "alloc" in name:
                return "Dynamic Allocation"
            if name.startswith("str_") or "string" in name or "chaine" in name:
                return "Strings"
            if "ptr" in name or "pointer" in name:
                return "Pointers"
            if "liste" in name or "chain" in name or "linked" in name:
                return "Listes_Chainees"
            if "pile" in name or "stack" in name:
                return "Piles"
            if "file" in name or "queue" in name:
                return "Files"
            if "record" in name or "enregistr" in name:
                return "Enregistrements"
            if "func" in name or "fonction" in name or "proc" in name:
                return "Functions"
            if "array" in name or "tableau" in name:
                return "Arrays"
            if name.startswith("test_"):
                return "Tests"
            return "Basics"

        # Main examples
        if os.path.exists(EXAMPLES_DIR):
            for root, dirs, files in os.walk(EXAMPLES_DIR):
                for f in files:
                    if f.endswith('.algo'):
                        # Get relative path for grouping
                        rel_path = os.path.relpath(os.path.join(root, f), EXAMPLES_DIR)
                        cat = categorize(rel_path)
                        # Ensure forward slashes for URLs
                        filepath_url = rel_path.replace('\\\\', '/')
                        if cat not in ["Tests", "Fixtures"]:
                            if cat not in categories:
                                categories[cat] = []
                            categories[cat].append({'name': f, 'path': filepath_url})
        
        # Sort each category: 00_Tutoriel first, then alphabetically
        for cat in categories:
            categories[cat].sort(key=lambda x: (
                0 if x['name'].startswith('00_Tutoriel') else 1,
                x['name'].lower()
            ))

        # Remove empty categories
        filtered_categories = {k: v for k, v in categories.items() if v and k not in ["Tests", "Fixtures"]}
        return jsonify(filtered_categories)
    except Exception as e:
        print(f"DEBUG: Exception in list_examples: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({})

@app.route('/example/<path:filename>')
def get_example(filename):
    try:
        # Determine path
        if filename.startswith('fixtures/'):
            real_filename = filename.split('/', 1)[1]
            filepath = os.path.join(FIXTURES_DIR, real_filename)
            base_dir = FIXTURES_DIR
        else:
            filepath = os.path.join(EXAMPLES_DIR, filename)
            base_dir = EXAMPLES_DIR

        if not _is_safe_path(base_dir, filepath):
             return jsonify({'error': "Invalid filename"}), 400

        if not os.path.exists(filepath):
            return jsonify({'error': "File not found"}), 404
            
        with open(filepath, 'r', encoding='utf-8') as f:
            code_content = f.read()
            
        # Check for associated .input file
        input_content = ""
        # Handle input file path logic based on directory
        base_path = os.path.splitext(filepath)[0]
        input_filepath = base_path + ".input"
        
        if os.path.exists(input_filepath):
             with open(input_filepath, 'r', encoding='utf-8') as f:
                 input_content = f.read()

        return jsonify({
            'code': code_content,
            'input': input_content
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/validate_algo', methods=['POST'])
def validate_algo():
    """Validate a course snippet against the current compiler without executing it."""
    try:
        data = request.get_json(silent=True) or {}
        code = data.get('code', '')
        if isinstance(code, dict):
            code = json.dumps(code)
        code = str(code)

        if not code.strip():
            return jsonify({'ok': False, 'errors': [{'message': 'Code vide'}]}), 200

        result = compile_algo(code)

        # Modern parser returns (python_code, errors)
        if isinstance(result, tuple):
            python_code, errors = result
            if errors:
                return jsonify({'ok': False, 'errors': errors}), 200
                
            return jsonify({'ok': bool(python_code), 'errors': []}), 200

        # Backward compatibility
        return jsonify({'ok': bool(result), 'errors': [] if result else [{'message': 'Compilation failed'}]}), 200
    except Exception as e:
        return jsonify({'ok': False, 'errors': [{'message': str(e)}]}), 200

# --- QUIZ API ENDPOINTS ---

import random

@app.route('/api/quiz/<chapter_identifier>')
def get_quiz(chapter_identifier):
    try:
        quiz_question_bank = get_cached_quiz_question_bank(chapter_identifier)
        if not quiz_question_bank:
            return jsonify({'error': 'Chapter not found in database'}), 404

        # Requirements: 6 Easy, 8 Medium, 6 Hard (Total 20)
        # If not enough, get as many as possible
        easy_q = []
        medium_q = []
        hard_q = []
        for question in quiz_question_bank['questions']:
            if question['difficulty'] == 'Easy':
                easy_q.append(question)
            elif question['difficulty'] == 'Medium':
                medium_q.append(question)
            elif question['difficulty'] == 'Hard':
                hard_q.append(question)

        selected_questions = (
            random.sample(easy_q, min(6, len(easy_q))) +
            random.sample(medium_q, min(8, len(medium_q))) +
            random.sample(hard_q, min(6, len(hard_q)))
        )
        random.shuffle(selected_questions)

        quiz_data = []
        for q in selected_questions:
            # Get the correct choice and up to 3 random incorrect choices
            correct_choice = next((choice for choice in q['choices'] if choice['is_correct']), None)
            incorrect_choices = [choice for choice in q['choices'] if not choice['is_correct']]
            selected_incorrect = random.sample(incorrect_choices, min(3, len(incorrect_choices)))

            final_choices = []
            if correct_choice:
                final_choices.append(dict(correct_choice))
            final_choices.extend(dict(choice) for choice in selected_incorrect)
            random.shuffle(final_choices)

            quiz_data.append({
                'id': q['id'],
                'type': q['type'],
                'difficulty': q['difficulty'],
                'concept': q['concept'],
                'text': q['text'],
                'explanation': q['explanation'],
                'choices': final_choices
            })

        # Auto-finalize any previously unfinished quiz attempt for this chapter
        if current_user.is_authenticated:
            unfinished = QuizAttempt.query.filter_by(
                user_id=current_user.id,
                chapter_id=quiz_question_bank['chapter_id'],
                status='in_progress'
            ).first()
            if unfinished:
                unfinished.status = 'auto_finalized'
                unfinished.timestamp = datetime.datetime.utcnow()
                db.session.commit()
                invalidate_global_user_stats_cache()
                invalidate_user_progress_cache(current_user.id)

        return jsonify({'questions': quiz_data})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/quiz/save_progress', methods=['POST'])
def save_quiz_progress():
    try:
        data = request.json
        chapter_identifier = data.get('chapter_identifier')
        score = data.get('score', 0)
        total = data.get('total', 0)
        details = data.get('details', '{}') 
        status = data.get('status', 'completed')

        quiz_question_bank = get_cached_quiz_question_bank(chapter_identifier)
        if not quiz_question_bank:
            return jsonify({'error': 'Chapter not found'}), 404
        chapter_id = quiz_question_bank['chapter_id']

        if current_user.is_authenticated:
            # Check interpretation
            all_correct = (score == total and total > 0)
            none_correct = (score == 0)

            # Check if updating an existing in_progress attempt
            existing_in_progress = QuizAttempt.query.filter_by(
                user_id=current_user.id,
                chapter_id=chapter_id,
                status='in_progress'
            ).first()

            if existing_in_progress:
                existing_in_progress.score = score
                existing_in_progress.total_questions = total
                existing_in_progress.status = status
                existing_in_progress.all_correct = all_correct
                existing_in_progress.none_correct = none_correct
                existing_in_progress.details = json.dumps(details)
                existing_in_progress.timestamp = datetime.datetime.utcnow()
                attempt = existing_in_progress
            else:
                attempt = QuizAttempt(
                    user_id=current_user.id,
                    chapter_id=chapter_id,
                    score=score,
                    total_questions=total,
                    status=status,
                    all_correct=all_correct,
                    none_correct=none_correct,
                    details=json.dumps(details)
                )
                db.session.add(attempt)

            db.session.commit()
            invalidate_global_user_stats_cache()
            invalidate_user_progress_cache(current_user.id)
            invalidate_user_level_cache(current_user.id)
            schedule_global_user_stats_refresh()
            schedule_user_level_refresh(current_user.id)

            # Percentile calculation
            # Calculate how many unique users have a score lower than this one
            all_scores = db.session.query(
                func.max(QuizAttempt.score)
            ).filter(
                QuizAttempt.chapter_id == chapter_id
            ).group_by(QuizAttempt.user_id).all()
            
            all_scores_list = [s[0] for s in all_scores if s[0] is not None]
            total_participants = len(all_scores_list)
            
            percentile = 0
            if total_participants > 1:
                # Count scores strictly lower
                lower_scores = sum(1 for s in all_scores_list if s < score)
                percentile = (lower_scores / (total_participants - 1)) * 100
            elif total_participants == 1:
                percentile = 100

            return jsonify({
                'success': True,
                'saved': True,
                'percentile': round(percentile, 1),
                'level_refresh_pending': True
            })

        return jsonify({'success': True, 'saved': False})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

import queue
import uuid

_ORIGINAL_STDOUT = sys.stdout
_ORIGINAL_STDERR = sys.stderr
_execution_io_local = threading.local()


class ThreadBoundTextProxy:
    def __init__(self, fallback, attr_name):
        self.fallback = fallback
        self.attr_name = attr_name

    def _target(self):
        return getattr(_execution_io_local, self.attr_name, None) or self.fallback

    def write(self, text):
        return self._target().write(text)

    def flush(self):
        target = self._target()
        if hasattr(target, 'flush'):
            return target.flush()
        return None

    def isatty(self):
        target = self._target()
        return target.isatty() if hasattr(target, 'isatty') else False

    def fileno(self):
        target = self._target()
        if hasattr(target, 'fileno'):
            return target.fileno()
        raise io.UnsupportedOperation("fileno")

    def __getattr__(self, name):
        return getattr(self._target(), name)


EXECUTION_STDOUT_PROXY = ThreadBoundTextProxy(_ORIGINAL_STDOUT, 'stdout')
EXECUTION_STDERR_PROXY = ThreadBoundTextProxy(_ORIGINAL_STDERR, 'stderr')

# Global Session State
class GlobalSession:
    def __init__(self, owner_id=None, run_id=None):
        self.owner_id = owner_id
        self.run_id = run_id
        self.input_queue = queue.Queue(maxsize=1000) # Limit size to prevent memory issues
        self.output_queue = queue.Queue(maxsize=10000) # Limit output buffer
        self.is_running = False
        self.current_thread = None
        self.current_ctx = None
        self.created_at = time.time()
        self.updated_at = self.created_at

    def reset(self):
        self.input_queue = queue.Queue(maxsize=1000)
        self.output_queue = queue.Queue(maxsize=10000)
        self.is_running = False
        self.current_thread = None
        self.current_ctx = None
        self.touch()

    def touch(self):
        self.updated_at = time.time()


class ExecutionManager:
    def __init__(self, ttl_seconds=3600, max_active_runs_per_owner=3):
        self.ttl_seconds = ttl_seconds
        self.max_active_runs_per_owner = max_active_runs_per_owner
        self.runs = {}
        self.lock = threading.Lock()

    def _cleanup_locked(self):
        now = time.time()
        stale_run_ids = [
            run_id for run_id, state in self.runs.items()
            if not state.is_running and (now - state.updated_at) > self.ttl_seconds
        ]
        for run_id in stale_run_ids:
            self.runs.pop(run_id, None)

    def create_run(self, owner_id):
        with self.lock:
            self._cleanup_locked()
            active_runs = sum(
                1 for state in self.runs.values()
                if state.owner_id == owner_id and state.is_running
            )
            if active_runs >= self.max_active_runs_per_owner:
                return None

            run_id = uuid.uuid4().hex
            state = GlobalSession(owner_id=owner_id, run_id=run_id)
            self.runs[run_id] = state
            return state

    def get_run(self, owner_id, run_id):
        if not run_id:
            return None

        with self.lock:
            self._cleanup_locked()
            state = self.runs.get(run_id)
            if not state or state.owner_id != owner_id:
                return None
            state.touch()
            return state

    def remove_run(self, run_id):
        with self.lock:
            self.runs.pop(run_id, None)


execution_manager = ExecutionManager()


def get_execution_owner_id():
    owner_id = flask_session.get('_execution_owner_id')
    if not owner_id:
        owner_id = secrets.token_urlsafe(24)
        flask_session['_execution_owner_id'] = owner_id
        flask_session.modified = True
    return owner_id


def get_requested_run_id():
    if request.method == 'GET':
        return request.args.get('run_id', '').strip()

    data = request.get_json(silent=True) or {}
    return str(data.get('run_id') or request.form.get('run_id') or '').strip()

import ctypes

def terminate_thread(thread):
    """Terminates a python thread from another thread.
    :param thread: a threading.Thread instance
    """
    if not thread or not thread.is_alive():
        return

    exc = ctypes.py_object(SystemExit)
    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(thread.ident), exc)
    if res == 0:
        # Thread might be dead already
        pass
    elif res > 1:
        # """if it returns a number greater than one, you're in trouble,
        # and you should call it again with exc=NULL to revert the effect"""
        ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(thread.ident), None)
        raise SystemError("PyThreadState_SetAsyncExc failed")

@app.route('/stop_execution', methods=['POST'])
def stop_execution_route():
    owner_id = get_execution_owner_id()
    run_state = execution_manager.get_run(owner_id, get_requested_run_id())
    if run_state and run_state.is_running:
        run_state.is_running = False
        run_state.touch()
        if hasattr(run_state, 'current_ctx') and run_state.current_ctx:
            run_state.current_ctx.is_running = False
        
        # Force kill the thread
        if run_state.current_thread:
             try:
                 terminate_thread(run_state.current_thread)
             except Exception as e:
                 print(f"Error terminating thread: {e}")

        # Unblock any waiting input
        try:
             # Drain input queue to ensure put doesn't block if full
             while not run_state.input_queue.empty():
                 try: run_state.input_queue.get_nowait()
                 except: break
             run_state.input_queue.put(None) 
        except:
             pass
        
        # Clear queues
        try:
            with run_state.input_queue.mutex:
                run_state.input_queue.queue.clear()
            with run_state.output_queue.mutex:
                run_state.output_queue.queue.clear()
        except Exception:
            # In case mutex is locked or other issues
            pass
            
        # session.output_queue.put({'type': 'finished', 'data': 'Execution stopped by user.'})
        # We rely on the thread catching SystemExit and sending 'stopped'
        
        return jsonify({'success': True})
    if not run_state:
        return jsonify({'success': False, 'error': 'Execution not found'}), 404
    return jsonify({'success': False, 'error': 'Not running'}), 409

@app.route('/doc/errors')
def doc_errors():
    return render_template('errors.html')

@app.route('/start_execution', methods=['POST'])
def start_execution():
    data = request.get_json(silent=True) or {}
    code = data.get('code', '')
    if isinstance(code, dict):
        # Fallback if frontend accidentally sends an object or object payload was double-nested
        import json
        code = json.dumps(code)
    code = str(code)

    try:
        owner_id = get_execution_owner_id()
        run_state = execution_manager.create_run(owner_id)
        if run_state is None:
            return jsonify({
                'success': False,
                'error': 'Too many active executions for this browser session. Stop one before starting another.'
            }), 429

        # Transpile to Python
        # Use compile_algo to ensure indent_level is reset
        result = compile_algo(code)
        
        # Handle tuple return (code, errors)
        if isinstance(result, tuple):
            python_code, errors = result
            if errors:
                execution_manager.remove_run(run_state.run_id)
                # Return structured errors
                return jsonify({'success': False, 'error': 'Compilation failed', 'details': errors})
        else:
             python_code = result # Fallback for backward compatibility if parser didn't update (shouldn't happen)

        if not python_code:
            execution_manager.remove_run(run_state.run_id)
            return jsonify({'success': False, 'error': 'Compilation failed (Syntax Error)'})

        if os.environ.get('LOG_COMPILED_CODE', '').lower() in ('1', 'true', 'yes', 'on'):
            print(f"\n--- DEBUG: GENERATED PYTHON CODE (LIVE EXECUTION) ---\n{python_code}\n-----------------------------------------------------\n")

        # Save to file only when explicitly enabled
        if os.environ.get('WRITE_COMPILED_OUTPUT', '').lower() in ('1', 'true', 'yes', 'on'):
            with open(f'output_{run_state.run_id}.py', 'w', encoding='utf-8') as f:
                f.write(python_code)

        # Reset Session
        run_state.reset()
        run_state.is_running = True
        run_state.touch()
        
        class RunContext:
            def __init__(self, in_q, out_q):
                self.is_running = True
                self.input_queue = in_q
                self.output_queue = out_q
                
        ctx = RunContext(run_state.input_queue, run_state.output_queue)
        run_state.current_ctx = ctx
        
        # Check for pre-loaded input file
        input_file_content = data.get('inputFileContent', '')
        if input_file_content:
             # Split by lines and put into input queue
             lines = input_file_content.split('\n')
             for line in lines:
                 run_state.input_queue.put(line.strip())

        # Thread Target
        def run_script():
            try:
                # Mock Input
                def mock_input(prompt=''):
                    if prompt:
                        ctx.output_queue.put({'type': 'stdout', 'data': prompt})
                    
                    # Check if we have pre-loaded input in queue
                    if not ctx.input_queue.empty():
                         return ctx.input_queue.get()

                    # Request Input from Frontend
                    # print("DEBUG: Sending input_request to frontend")
                    ctx.output_queue.put({'type': 'input_request'})
                    
                    # Block wait for input
                    # print("DEBUG: Waiting for input from session.input_queue")
                    user_input = ctx.input_queue.get()
                    if user_input is None: # Signal to stop
                        raise EOFError("Execution Terminated")
                    return user_input

                # Mock Print? 
                # We need to capture stdout.
                # TraceRunner captures it, but we also want real-time streaming.
                # Let's create a stream-like object that puts to queue.
                class StreamToQueue:
                    def __init__(self):
                        import io
                        self.buffer = io.StringIO()
                    def write(self, text):
                        if text:
                            self.buffer.write(text)
                            try:
                                # Use timeout to allow checking if session is still running
                                # This prevents deadlock if queue is full and stop is requested
                                while ctx.is_running:
                                    try:
                                        ctx.output_queue.put({'type': 'stdout', 'data': text}, timeout=0.5)
                                        break
                                    except queue.Full:
                                        if not ctx.is_running: break
                                        continue
                            except Exception:
                                pass
                    def flush(self):
                        pass

                    def isatty(self):
                        return False

                    def getvalue(self):
                        return self.buffer.getvalue()

                    def fileno(self):
                        import io
                        raise io.UnsupportedOperation("fileno")
                
                stream = StreamToQueue()
                _execution_io_local.stdout = stream
                _execution_io_local.stderr = stream
                
                # Redirect through thread-aware proxies so one execution cannot capture another thread's logs.
                with contextlib.redirect_stdout(EXECUTION_STDOUT_PROXY), contextlib.redirect_stderr(EXECUTION_STDERR_PROXY):

                    # Prepare builtins
                    # Custom print to ensure capture
                    def custom_print(*args, **kwargs):
                        sep = kwargs.get('sep', ' ')
                        end = kwargs.get('end', '\n')
                        file = kwargs.get('file', None)
                        if file is None:
                            text = sep.join(map(str, args)) + end
                            stream.write(text)
                        else:
                            try:
                                file.write(sep.join(map(str, args)) + end)
                            except:
                                pass

                    # Helper to convert Algo types (like char lists) to string for display
                    def _algo_to_string(val):
                        if isinstance(val, bool): return "Vrai" if val else "Faux"
                        if isinstance(val, list):
                            res = ""
                            for char in val:
                                if char is None or char == "\0": break
                                res += str(char)
                            return res
                        return str(val)

                    def _algo_longueur(val):
                        """Calculate length of a string (stops at null terminator for fixed strings)"""
                        if isinstance(val, list):
                            return len(_algo_to_string(val))
                        return len(str(val))
                
                    def _algo_concat(val1, val2):
                        """Concatenate two strings, handling fixed-size string arrays"""
                        # Convert both values to strings
                        s1 = _algo_to_string(val1) if isinstance(val1, list) else str(val1)
                        s2 = _algo_to_string(val2) if isinstance(val2, list) else str(val2)
                        return s1 + s2
                        
                    def _algo_assign_fixed_string(target_list, source_val):
                        # Update target_list in-place to match source_val (string or list)
                        if not isinstance(target_list, list): return target_list
                        limit = len(target_list)
                        s_val = ''
                        if hasattr(source_val, '_get_target_container'):
                            targ = source_val._get_target_container()
                            while hasattr(targ, '_get_target_container'): 
                                targ = targ._get_target_container()
                            if isinstance(targ, list):
                                s_val = _algo_to_string(targ[source_val.index:])
                            else:
                                s_val = str(source_val._get_string() if hasattr(source_val, '_get_string') else source_val._get())
                        elif isinstance(source_val, list):
                             s_val = _algo_to_string(source_val)
                        else:
                             s_val = str(source_val)
                        
                        if limit > 0:
                            s_val = s_val[:limit-1]
                            for i in range(len(s_val)):
                                target_list[i] = s_val[i]
                            target_list[len(s_val)] = '\0'
                            for i in range(len(s_val)+1, limit):
                                target_list[i] = None
                        return target_list

                    # Mock input for LIRE if needed
                    def _algo_read_typed(current_val, raw_val, target_type_name='CHAINE'):
                        type_to_check = target_type_name.upper()
                        if 'CHAINE' in type_to_check:
                            if isinstance(current_val, list):
                                 _algo_assign_fixed_string(current_val, raw_val)
                                 return current_val
                            return str(raw_val)
                        if 'BOOLEEN' in type_to_check or isinstance(current_val, bool):
                            val_str = str(raw_val).lower()
                            if val_str in ['vrai', 'true', '1']: return True
                            if val_str in ['faux', 'false', '0']: return False
                            raise ValueError(f"Type mismatch: '{raw_val}' n'est pas un Booléen valide.")
                        if 'ENTIER' in type_to_check or isinstance(current_val, int):
                            try: return int(raw_val)
                            except: raise ValueError(f"Type mismatch: '{raw_val}' n'est pas un Entier valide.")
                        if 'REEL' in type_to_check or isinstance(current_val, float):
                            try: return float(raw_val)
                            except: raise ValueError(f"Type mismatch: '{raw_val}' n'est pas un Reel valide.")
                        if isinstance(current_val, list): return raw_val 
                        return str(raw_val)

                    def _algo_set_char(target_list, index, char_val):
                        if not isinstance(target_list, list): return target_list
                        idx = int(index)
                        if 0 <= idx < len(target_list):
                            c = str(char_val)[0] if char_val else "\0"
                            target_list[idx] = c
                        return target_list

                    def _algo_get_char(target_list, index):
                        if isinstance(target_list, list):
                            idx = int(index)
                            if 0 <= idx < len(target_list):
                                c = target_list[idx]
                                return c if c is not None and c != "\0" else ""
                            return ""
                        s = str(target_list)
                        idx = int(index)
                        return s[idx] if 0 <= idx < len(s) else ""

                    # VULN-002: Hardened builtins for interactive debugger
                    _orig_import = __builtins__.__import__ if hasattr(__builtins__, '__import__') else __builtins__['__import__']
                    def _restricted_import(name, globals=None, locals=None, fromlist=(), level=0):
                        if name not in ('math', 'random'):
                            raise ImportError(f"Security Sandbox: Import of module '{name}' is prohibited in interactive mode.")
                        return _orig_import(name, globals, locals, fromlist, level)

                    allowed_builtins = [
                        'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'bytearray', 'bytes', 'callable',
                        'chr', 'dict', 'divmod', 'enumerate', 'filter', 'float', 'format', 'frozenset',
                        'getattr', 'hasattr', 'setattr',
                        'hash', 'hex', 'id', 'int', 'isinstance', 'issubclass', 'iter', 'len', 'list',
                        'map', 'max', 'min', 'next', 'object', 'oct', 'ord', 'pow', 'range', 'repr',
                        'reversed', 'round', 'set', 'slice', 'sorted', 'str', 'sum', 'tuple', 'type', 'zip',
                        'globals', 'locals',
                        '__build_class__',
                        'ArithmeticError', 'AssertionError', 'AttributeError', 'BaseException', 'EOFError', 
                        'Exception', 'False', 'IndexError', 'KeyError', 'MemoryError', 'NameError', 'None', 
                        'OSError', 'RuntimeError', 'StopIteration', 'SyntaxError', 'SystemExit', 'True', 'TypeError', 'ValueError'
                    ]
                    
                    import builtins
                    safe_builtins = {}
                    for k in allowed_builtins:
                        if hasattr(builtins, k):
                            safe_builtins[k] = getattr(builtins, k)
                    
                    safe_builtins['print'] = custom_print
                    safe_builtins['input'] = mock_input
                    safe_builtins['__import__'] = _restricted_import

                    exec_globals = {
                        '__name__': '__main__',
                        '_algo_to_string': _algo_to_string,
                        '_algo_longueur': _algo_longueur,
                        '_algo_concat': _algo_concat,
                        '_algo_assign_fixed_string': _algo_assign_fixed_string,
                        '_algo_set_char': _algo_set_char,
                        '_algo_get_char': _algo_get_char,
                        '_algo_read': _algo_read_typed,
                        '_algo_ecrire': custom_print,
                        'print': custom_print,
                        'input': mock_input, 
                        '__builtins__': safe_builtins
                    }

                    tracer = TraceRunner()
                    
                    def on_log_step(step):
                         if not ctx.is_running:
                             raise SystemExit("Execution stopped by user")
                         try:
                             while ctx.is_running:
                                 try:
                                     ctx.output_queue.put({'type': 'trace', 'data': step}, timeout=0.1)
                                     break
                                 except queue.Full:
                                     if not ctx.is_running: break
                                     continue
                         except:
                             pass
                    
                    # Run execution
                    tracer.run(python_code, exec_globals, stdout_capture=stream, on_step=on_log_step)


            except SystemExit:
                 ctx.output_queue.put({'type': 'stopped', 'data': 'Exécution interrompue.'})
            except Exception as e:
                # Translate Python errors to friendly Algo errors using the canonical compiler error translator
                error_type = type(e).__name__
                translated_msg = translate_exception(e, py_code=python_code, algo_code=code, include_lineno=False)
                run_state.output_queue.put({'type': 'error', 'data': f"Erreur d'exécution ({error_type}): {translated_msg}"})
            finally:
                for attr_name in ('stdout', 'stderr'):
                    if hasattr(_execution_io_local, attr_name):
                        delattr(_execution_io_local, attr_name)
                # If we stopped manually, we might have already sent 'stopped'
                # But to be safe, let's mark finished if we were running
                if run_state.is_running:
                     run_state.output_queue.put({'type': 'finished'})
                     run_state.is_running = False
                run_state.touch()

        # Start Thread
        t = threading.Thread(target=run_script)
        t.daemon = True # Kill thread if main process ends
        run_state.current_thread = t
        t.start()

        return jsonify({'success': True, 'run_id': run_state.run_id})

    except Exception as e:
        if 'run_state' in locals() and run_state and not run_state.is_running:
            execution_manager.remove_run(run_state.run_id)
        return jsonify({'success': False, 'error': str(e)})

@app.route('/stream')
def stream():
    owner_id = get_execution_owner_id()
    run_state = execution_manager.get_run(owner_id, get_requested_run_id())
    if not run_state:
        return jsonify({'error': 'Execution not found'}), 404

    def event_stream():
        try:
            while True:
                try:
                    # Get message from queue, wait up to 1s
                    msg = run_state.output_queue.get(timeout=1.0)
                    run_state.touch()
                    yield f"data: {json.dumps(msg)}\n\n"
                    if msg['type'] in ('finished', 'stopped'):
                        break
                except queue.Empty:
                    if not run_state.is_running and run_state.output_queue.empty():
                        break
                    # Send heartbeat
                    yield ": keepalive\n\n"
        finally:
            if not run_state.is_running and run_state.output_queue.empty():
                execution_manager.remove_run(run_state.run_id)
    
    return Response(event_stream(), mimetype="text/event-stream")

@app.route('/send_input', methods=['POST'])
def send_input():
    owner_id = get_execution_owner_id()
    data = request.get_json(silent=True) or {}
    run_state = execution_manager.get_run(owner_id, str(data.get('run_id', '')).strip())
    if not run_state:
         return jsonify({'success': False, 'error': 'Execution not found'}), 404
    if not run_state.is_running:
         return jsonify({'success': False, 'error': 'Not running'}), 409
         
    user_input = data.get('input')
    # print(f"DEBUG: Received input from frontend: '{user_input}'")
    run_state.input_queue.put(user_input)
    run_state.touch()
    return jsonify({'success': True})


@app.route('/api/problems', methods=['GET'])
def get_problems():
    topics = request.args.getlist('topic')
    difficulties = request.args.getlist('difficulty')
    
    query = Problem.query.filter(Problem.is_published.is_(True))
    if topics:
        query = query.filter(Problem.topic.in_(topics))
    if difficulties:
        query = query.filter(Problem.difficulty.in_(difficulties))
    
    problems = query.all()
    
    # Get solved problems for the current user if authenticated
    solved_ids = set()
    if current_user.is_authenticated:
        solved_submissions = ChallengeSubmission.query.filter_by(user_id=current_user.id, passed=True).all()
        solved_ids = {s.problem_id for s in solved_submissions}

    from sqlalchemy import case, distinct
    # Count distinct users who attempted and solved each problem in a single query
    stats_query = (
        db.session.query(
            ChallengeSubmission.problem_id,
            func.count(distinct(ChallengeSubmission.user_id)).label('attempted'),
            func.count(distinct(case((ChallengeSubmission.passed.is_(True), ChallengeSubmission.user_id), else_=None))).label('solvers')
        )
        .group_by(ChallengeSubmission.problem_id)
        .all()
    )
    attempt_map = {row[0]: row[1] for row in stats_query}
    solver_map = {row[0]: row[2] for row in stats_query}
    
    problems_data = [
        {
            'id': p.id,
            'title': p.title,
            'topic': p.topic,
            'difficulty': p.difficulty,
            'solved': p.id in solved_ids if current_user.is_authenticated else None,
            'attempted_users': attempt_map.get(p.id, 0),
            'solvers': solver_map.get(p.id, 0),
            'success_rate': round((solver_map.get(p.id, 0) / attempt_map.get(p.id, 1)) * 100, 1) if attempt_map.get(p.id, 0) else 0,
            'description': p.description[:150] + '...' if p.description and len(p.description) > 150 else p.description
        }
        for p in problems
    ]

    # Sort: unsolved first (for authenticated users), then by difficulty (Easy < Medium < Hard)
    diff_order = {'Easy': 0, 'Medium': 1, 'Hard': 2}
    problems_data.sort(key=lambda x: (
        1 if x['solved'] is True else 0,
        diff_order.get(x['difficulty'], 3),
        x['id']
    ))

    return jsonify({
        'success': True,
        'problems': problems_data
    })

@app.route('/api/problems/<int:problem_id>', methods=['GET'])
def get_problem(problem_id):
    problem_payload = get_cached_problem_payload(problem_id)
    if not problem_payload:
        return jsonify({'success': False, 'error': 'Problem not found'}), 404
    if not problem_payload.get('is_published'):
        return jsonify({'success': False, 'error': 'Problem not published'}), 403

    return jsonify({
        'success': True,
        'problem': {k: v for k, v in problem_payload.items() if k != 'is_published'}
    })


@app.route('/api/problems/navigation', methods=['GET'])
def get_problem_navigation():
    return jsonify({
        'success': True,
        'problem_ids': get_cached_navigation_problem_ids()
    })

@app.route('/problems/<int:problem_id>/leaderboard')
def problem_leaderboard_page(problem_id):
    problem = {
        'id': problem_id,
        'title': f'Problème #{problem_id}',
        'difficulty': 'Chargement...'
    }
    return render_template('problem_leaderboard.html', problem=problem)

@app.route('/api/problems/<int:problem_id>/leaderboard', methods=['GET'])
def get_problem_leaderboard(problem_id):
    problem = db.session.get(Problem, problem_id)
    if not problem:
        return jsonify({'success': False, 'error': 'Problem not found'}), 404
    if not problem.is_published:
        return jsonify({'success': False, 'error': 'Problem not published'}), 403

    year_param = (request.args.get('year') or '').strip().lower()
    year = None
    if year_param and year_param not in {'overall', 'all', 'tous', 'none', '*'}:
        if year_param in {'current', 'default'}:
            year = get_current_academic_year()
        else:
            try:
                year = int(year_param)
            except ValueError:
                return jsonify({'success': False, 'error': 'Invalid year filter'}), 400

    sort_key = (request.args.get('sort') or 'final_score').strip()
    allowed_sorts = {'final_score', 'time_taken_seconds', 'avg_execution_time_ms', 'avg_memory_kb'}
    if sort_key not in allowed_sorts:
        sort_key = 'final_score'

    order = (request.args.get('order') or ('desc' if sort_key == 'final_score' else 'asc')).strip().lower()
    if order not in {'asc', 'desc'}:
        order = 'desc' if sort_key == 'final_score' else 'asc'

    try:
        page = max(1, int(request.args.get('page', 1)))
    except ValueError:
        page = 1
    try:
        page_size = min(100, max(1, int(request.args.get('page_size', 10))))
    except ValueError:
        page_size = 10

    payload = build_problem_leaderboard_rows(problem_id, year=year)
    if payload is None:
        return jsonify({'success': False, 'error': 'Problem not found'}), 404

    ranked_rows = payload['rows']
    sorted_rows = sort_problem_leaderboard_rows(ranked_rows, sort_key, order)
    total_items = len(sorted_rows)
    total_pages = max(1, (total_items + page_size - 1) // page_size)
    if page > total_pages:
        page = total_pages

    start = (page - 1) * page_size
    end = start + page_size
    paged_rows = sorted_rows[start:end]

    return jsonify({
        'success': True,
        'problem': payload['problem'],
        'available_years': payload['available_years'],
        'top_users': [serialize_leaderboard_row(row) for row in ranked_rows[:3]],
        'leaderboard': [serialize_leaderboard_row(row) for row in paged_rows],
        'sort': sort_key,
        'order': order,
        'filters': {'year': year},
        'pagination': {
            'page': page,
            'page_size': page_size,
            'total_items': total_items,
            'total_pages': total_pages
        }
    })

@app.route('/submission_results')
def submission_results():
    return render_template('submission_results.html')


@app.route('/api/submissions/custom', methods=['POST'])
def submit_custom_code():
    data = request.get_json()
    code = data.get('code')
    custom_input = data.get('input', '')
    
    # 1. Compile Algo code to Python
    result = compile_algo(code)
    
    # Handle tuple return (code, errors)
    if isinstance(result, tuple):
        python_code, errors = result
        if errors:
            return jsonify({'success': False, 'error': 'Compilation failed', 'details': errors})
    else:
        python_code = result
        
    if not python_code:
        return jsonify({'success': False, 'error': 'Compilation failed (Syntax Error)'})
        
        
    tc_data = [{
        'id': 'custom',
        'input': custom_input,
        'expected_output': ''
    }]
    
    
    results = execute_code(python_code, tc_data)
    avg_execution_time_ms = round(
        sum(float(r.get('execution_time_ms') or 0.0) for r in results) / len(results),
        3
    ) if results else None
    avg_memory_kb = round(
        sum(float(r.get('memory_usage_kb') or 0.0) for r in results) / len(results),
        2
    ) if results else None
    
    return jsonify({
        'success': True,
        'all_passed': results[0]['passed'],
        'results': results,
        'avg_execution_time_ms': avg_execution_time_ms,
        'avg_memory_kb': avg_memory_kb,
        'metrics_summary': {
            'time_taken_seconds': 0,
            'test_cases_total': len(results),
            'test_cases_passed': sum(1 for r in results if r.get('passed')),
            'avg_execution_time_ms': avg_execution_time_ms,
            'avg_memory_kb': avg_memory_kb
        }
    })

@app.route('/api/submissions', methods=['POST'])
def submit_code():
    submit_started_at = time.perf_counter()
    submit_timings = {}
    data = request.get_json()
    problem_id = data.get('problem_id')
    code = data.get('code')
    execute_all = data.get('execute_all', False)
    requested_time_taken_seconds = data.get('time_taken_seconds', 0)

    stage_started_at = time.perf_counter()
    problem = db.session.get(Problem, problem_id)
    submit_timings['problem_lookup_ms'] = round((time.perf_counter() - stage_started_at) * 1000, 3)
    if not problem:
        return jsonify({'success': False, 'error': 'Problem not found'}), 404

    # 1. Compile Algo code to Python
    stage_started_at = time.perf_counter()
    result = compile_algo(code)
    submit_timings['compile_ms'] = round((time.perf_counter() - stage_started_at) * 1000, 3)
    
    # Handle tuple return (code, errors)
    if isinstance(result, tuple):
        python_code, errors = result
        if errors:
            # Return structured errors exactly as expected by frontend mapping
            return jsonify({'success': False, 'error': 'Compilation failed', 'details': errors})
    else:
        python_code = result
        
    if not python_code:
        return jsonify({'success': False, 'error': 'Compilation failed (Syntax Error)'})
    
    
    # 2. Select test cases
    stage_started_at = time.perf_counter()
    if execute_all:
        test_cases = problem.test_cases
    else:
        test_cases = [tc for tc in problem.test_cases if tc.is_public]
    submit_timings['select_tests_ms'] = round((time.perf_counter() - stage_started_at) * 1000, 3)
        
    # 3. Format test case data for sandbox
    stage_started_at = time.perf_counter()
    tc_data = [{
        'id': tc.id,
        'input': tc.input_data,
        'expected_output': tc.expected_output
    } for tc in test_cases]
    submit_timings['prepare_tests_ms'] = round((time.perf_counter() - stage_started_at) * 1000, 3)
    
    # 4. Execute in sandbox
    stage_started_at = time.perf_counter()
    raw_results = execute_code(python_code, tc_data)
    submit_timings['execute_ms'] = round((time.perf_counter() - stage_started_at) * 1000, 3)

    # Merge original tc_data with execution results
    results = []
    for i, raw_res in enumerate(raw_results):
        tc_info = tc_data[i]
        results.append({
            'test_case_id': tc_info['id'],
            'input': tc_info['input'],
            'expected_output': tc_info['expected_output'],
            'actual_output': raw_res['actual_output'],
            'passed': raw_res['passed'],
            'error': raw_res['error'],
            'execution_time_ms': round(float(raw_res.get('execution_time_ms') or 0.0), 3),
            'memory_usage_kb': int(raw_res.get('memory_usage_kb') or 0)
        })

    # Calculate all_passed
    all_passed = all(r['passed'] for r in results) if results else False
    passed_count = sum(1 for r in results if r['passed'])
    total_count = len(results)
    avg_execution_time_ms = round(
        sum(float(r.get('execution_time_ms') or 0.0) for r in results) / total_count,
        3
    ) if total_count else None
    avg_memory_kb = round(
        sum(float(r.get('memory_usage_kb') or 0.0) for r in results) / total_count,
        2
    ) if total_count else None
    submission_timestamp = utcnow()
    effective_time_taken_seconds = int(requested_time_taken_seconds or 0)
    attempt_session = None
    if current_user.is_authenticated and execute_all:
        attempt_session = get_or_create_active_attempt_session(current_user.id, problem.id)
        if attempt_session and attempt_session.started_at:
            effective_time_taken_seconds = max(
                0,
                int((submission_timestamp - attempt_session.started_at).total_seconds())
            )
    metrics_summary = {
        'time_taken_seconds': effective_time_taken_seconds,
        'test_cases_total': total_count,
        'test_cases_passed': passed_count,
        'avg_execution_time_ms': avg_execution_time_ms,
        'avg_memory_kb': avg_memory_kb
    }

    # Save submission if user is logged in and it's a full submission
    level_refresh_scheduled = False
    if current_user.is_authenticated and execute_all:
        score_percent = passed_count / total_count * 100 if total_count else 0

        stage_started_at = time.perf_counter()
        submission = ChallengeSubmission(
            user_id=current_user.id,
            problem_id=problem.id,
            score=score_percent,
            code=code,
            passed=all_passed,
            time_taken_seconds=effective_time_taken_seconds,
            test_cases_total=total_count,
            test_cases_passed=passed_count,
            avg_execution_time_ms=avg_execution_time_ms,
            avg_memory_kb=avg_memory_kb,
            test_case_metrics_json=build_test_case_metrics(results),
            attempt_session_id=attempt_session.id if attempt_session else None,
            timestamp=submission_timestamp
        )
        if all_passed and attempt_session and attempt_session.completed_at is None:
            attempt_session.completed_at = submission_timestamp
        db.session.add(submission)
        db.session.commit()
        invalidate_problem_leaderboard_cache(problem.id)
        invalidate_global_user_stats_cache()
        invalidate_user_progress_cache(current_user.id)
        invalidate_user_level_cache(current_user.id)
        schedule_global_user_stats_refresh()
        schedule_user_level_refresh(current_user.id)
        level_refresh_scheduled = True
        submit_timings['persist_submission_ms'] = round((time.perf_counter() - stage_started_at) * 1000, 3)
    else:
        submit_timings['persist_submission_ms'] = 0.0

    submit_timings['total_ms'] = round((time.perf_counter() - submit_started_at) * 1000, 3)
    log_perf_event(
        'submit_code',
        problem_id=problem_id,
        execute_all=bool(execute_all),
        authenticated=bool(current_user.is_authenticated),
        test_count=len(tc_data),
        timings=submit_timings
    )

    return jsonify({
        'success': True,
        'all_passed': all_passed,
        'results': results,
        'time_taken_seconds': effective_time_taken_seconds,
        'avg_execution_time_ms': avg_execution_time_ms,
        'avg_memory_kb': avg_memory_kb,
        'metrics_summary': metrics_summary,
        'leaderboard_url': url_for('problem_leaderboard_page', problem_id=problem.id),
        'problem_title': problem.title,
        'level_refresh_scheduled': level_refresh_scheduled
    })


# ─────────────────────────────────────────────────────────────────────────────
# XP POINTS & LEVEL SYSTEM
# ─────────────────────────────────────────────────────────────────────────────
LEVEL_DEFS = [
    # (min_xp, level_num, name_fr, color, glow, icon, icon_class, special_requirement_key)
    (0,    1, "Débutant",    "#94a3b8", "rgba(148,163,184,0.45)", "🧭", "fa-solid fa-compass", None),
    (200,  2, "Explorateur", "#38bdf8", "rgba(56,189,248,0.5)",   "⚡", "fa-solid fa-bolt-lightning", None),
    (500,  3, "Bosseur",     "#f97316", "rgba(249,115,22,0.5)",   "🔥", "fa-solid fa-fire-flame-curved", None),
    (1000, 4, "Expert",      "#a855f7", "rgba(168,85,247,0.5)",   "💎", "fa-solid fa-gem", None),
    (2000, 5, "Master",      "#ffc107", "rgba(255,193,7,0.55)",   "🏆", "fa-solid fa-chess-knight", None),
    (4000, 6, "Légende",     "#ec4899", "rgba(236,72,153,0.55)",  "👑", "fa-solid fa-crown", "master_criteria"),
]

def compute_xp_and_level(user_id, preloaded_quiz_attempts=None, preloaded_submissions=None, preloaded_badges=None, preloaded_problems=None):
    """Return (xp_total, xp_breakdown, level_dict, xp_to_next) for a user."""
    from web.models import QuizAttempt, ChallengeSubmission, UserBadge

    quiz_attempts = preloaded_quiz_attempts if preloaded_quiz_attempts is not None else QuizAttempt.query.filter_by(user_id=user_id).all()
    submissions   = preloaded_submissions if preloaded_submissions is not None else ChallengeSubmission.query.filter_by(user_id=user_id, passed=True).all()
    badges        = preloaded_badges if preloaded_badges is not None else UserBadge.query.filter_by(user_id=user_id).all()

    chapters = get_chapter_id_to_identifier_map()

    breakdown = []
    xp = 0

    # Quiz XP — per chapter, count the BEST attempt (if score >= 80%) → +15 XP
    chapter_best = {}
    for qa in quiz_attempts:
        pct = qa.score / qa.total_questions if qa.total_questions else 0
        if pct >= 0.8:
            prev = chapter_best.get(qa.chapter_id, 0)
            chapter_best[qa.chapter_id] = max(prev, qa.score)
    for cid, best_score in chapter_best.items():
        ident = chapters.get(cid, f"Chap {cid}")
        breakdown.append({"label": f"Quiz — {ident.capitalize()}", "xp": 15, "icon": "📚"})
        xp += 15

    # Challenge XP — per unique passed problem → scaled by difficulty (Easy: 15, Medium: 30, Hard: 60)
    passed_pids = set()
    for sub in submissions:
        if sub.problem_id not in passed_pids:
            passed_pids.add(sub.problem_id)
    
    if passed_pids:
        if preloaded_problems is not None:
            passed_problems = [p for p in preloaded_problems if p.id in passed_pids]
        else:
            passed_problems = Problem.query.filter(Problem.id.in_(passed_pids)).all()
        for p in passed_problems:
            if p.difficulty == 'Easy':
                val = 15
                icon = "🌱"
            elif p.difficulty == 'Medium':
                val = 30
                icon = "⚡"
            elif p.difficulty == 'Hard':
                val = 60
                icon = "🔥"
            else:
                val = 35
                icon = "⚔️"
            breakdown.append({"label": f"Défi #{p.id} ({p.difficulty})", "xp": val, "icon": icon})
            xp += val

    # Badge XP — scaled by difficulty (easy: 10 XP, up to hard: 100 XP)
    badge_defs = get_badge_definitions()
    for ub in badges:
        b_def = badge_defs.get(ub.badge_id, {})
        title_str = b_def.get('title')
        raw_name = b_def.get('name')
        
        badge_icon = "🏅"
        if title_str and not title_str.startswith('<'):
            parts = title_str.split(' ', 1)
            if len(parts) == 2 and len(parts[0]) <= 4:
                badge_icon = parts[0]
                label = parts[1]
            else:
                label = title_str
        elif raw_name:
            label = raw_name
        else:
            clean_name = ub.badge_id.replace('title_', '').replace('_', ' ').title()
            label = clean_name
            
        b_xp = b_def.get('xp', 10)
        prefix = "Titre : " if "title_" in ub.badge_id else "Badge : "
        breakdown.append({"label": f"{prefix}{label}", "xp": b_xp, "icon": badge_icon})
        xp += b_xp

    # Determine level
    # Check master criteria for level 6
    total_challenges = len(passed_pids)
    all_quiz_pct = 0
    if quiz_attempts:
        # average of best % per chapter
        chapter_pct = {}
        for qa in quiz_attempts:
            p = qa.score / qa.total_questions * 100 if qa.total_questions else 0
            chapter_pct[qa.chapter_id] = max(chapter_pct.get(qa.chapter_id, 0), p)
        all_quiz_pct = sum(chapter_pct.values()) / len(chapter_pct) if chapter_pct else 0

    master_ok = (xp >= 4000 and all_quiz_pct >= 95 and total_challenges >= 50)
    
    current_level = LEVEL_DEFS[0]
    for lvl in LEVEL_DEFS:
        min_xp, lnum, name, color, glow, icon, icon_class, special = lvl
        if special == "master_criteria":
            if master_ok:
                current_level = lvl
        elif xp >= min_xp:
            current_level = lvl

    # XP to next level
    next_xp = None
    for lvl in LEVEL_DEFS:
        if lvl[0] > xp:
            next_xp = lvl[0]
            break
    # If we're level 6 (max) and criteria met, no next level
    if current_level[1] == 6:
        xp_to_next = 0
        next_level_name = None
    elif next_xp is not None:
        xp_to_next = next_xp - xp
        next_level_name = [l[2] for l in LEVEL_DEFS if l[0] == next_xp][0]
    else:
        xp_to_next = 0
        next_level_name = None

    level_dict = {
        "num": current_level[1],
        "name": current_level[2],
        "color": current_level[3],
        "glow": current_level[4],
        "icon": current_level[5],
        "icon_class": current_level[6],
        "min_xp": current_level[0],
        "next_xp": next_xp,
        "next_level_name": next_level_name,
    }
    return xp, breakdown, level_dict, xp_to_next

def compute_bulk_users_stats_payload(include_placements=True, write_cache=True):
    now_ts = time.time()
    all_users = db.session.query(User.id, User.name, User.created_at, User.study_year, User.equipped_title).all()
    if not all_users:
        if write_cache:
            with global_user_stats_cache_lock:
                global_user_stats_cache['expires_at'] = now_ts + GLOBAL_USER_STATS_CACHE_TTL_SECONDS
                global_user_stats_cache['payload'] = {}
        return {}

    # 1. Bulk Fetch all data
    quiz_attempts = db.session.query(
        QuizAttempt.user_id,
        QuizAttempt.chapter_id,
        QuizAttempt.score,
        QuizAttempt.total_questions
    ).all()
    if include_placements:
        submissions = db.session.query(
            ChallengeSubmission.id,
            ChallengeSubmission.user_id,
            ChallengeSubmission.problem_id,
            ChallengeSubmission.time_taken_seconds,
            ChallengeSubmission.avg_execution_time_ms,
            ChallengeSubmission.avg_memory_kb,
            ChallengeSubmission.timestamp
        ).filter(
            ChallengeSubmission.passed.is_(True)
        ).all()
    else:
        submissions = db.session.query(
            ChallengeSubmission.user_id,
            ChallengeSubmission.problem_id
        ).filter(
            ChallengeSubmission.passed.is_(True)
        ).all()
    user_badges = db.session.query(UserBadge.user_id, UserBadge.badge_id).all()
    badge_defs = get_badge_definitions()
    problems = {
        row.id: row.difficulty
        for row in db.session.query(Problem.id, Problem.difficulty).all()
    }

    # 2. Group data by user_id
    qa_by_user = {}
    for qa in quiz_attempts:
        if qa.user_id not in qa_by_user: qa_by_user[qa.user_id] = []
        qa_by_user[qa.user_id].append(qa)

    sub_by_user = {}
    for sub in submissions:
        if sub.user_id not in sub_by_user: sub_by_user[sub.user_id] = []
        sub_by_user[sub.user_id].append(sub)

    badges_by_user = {}
    for ub in user_badges:
        u_id = ub[0]
        b_id = ub[1]
        if u_id not in badges_by_user: badges_by_user[u_id] = []
        badges_by_user[u_id].append(b_id)

    # 2b. Compute per-problem placements in memory so the global leaderboard
    # can expose Top 1 / Top 3 / Top 10 without issuing one query per problem.
    if include_placements:
        placement_counts = compute_problem_placement_counts(submissions)
    else:
        placement_counts = defaultdict(lambda: {'top1': 0, 'top3': 0, 'top10': 0})

    # 3. Compute for each user
    results = {}
    for user in all_users:
        uid = user.id
        u_qas = qa_by_user.get(uid, [])
        u_subs = sub_by_user.get(uid, [])
        u_badges = badges_by_user.get(uid, [])

        xp = 0
        
        # Quiz XP
        chapter_best = {}
        chapter_pct = {}
        q_count = 0
        for qa in u_qas:
            pct = qa.score / qa.total_questions if qa.total_questions else 0
            chapter_pct[qa.chapter_id] = max(chapter_pct.get(qa.chapter_id, 0), pct * 100)
            if pct >= 0.8:
                prev = chapter_best.get(qa.chapter_id, 0)
                if prev == 0: q_count += 1
                chapter_best[qa.chapter_id] = max(prev, qa.score)
        
        for _ in chapter_best:
            xp += 15

        # Challenge XP
        passed_pids = set()
        for sub in u_subs:
            if sub.problem_id not in passed_pids:
                passed_pids.add(sub.problem_id)
        
        for pid in passed_pids:
            diff = problems.get(pid, 'Easy')
            if diff == 'Easy': val = 15
            elif diff == 'Medium': val = 30
            elif diff == 'Hard': val = 60
            else: val = 25
            xp += val

        # Badge XP (excluding revoked/lost competitive badges)
        user_top1 = placement_counts[uid]['top1']
        for bid in u_badges:
            if bid == 'title_vainqueur' and user_top1 < 1:
                continue
            if bid == 'title_roi_podium' and user_top1 < 3:
                continue
            if bid == 'title_legende' and user_top1 < 10:
                continue
            b_def = badge_defs.get(bid, {})
            xp += b_def.get('xp', 10)

        # Level detection
        total_challenges = len(passed_pids)
        all_quiz_pct = sum(chapter_pct.values()) / len(chapter_pct) if chapter_pct else 0
        master_ok = (xp >= 4000 and all_quiz_pct >= 95 and total_challenges >= 50)
        
        current_level = LEVEL_DEFS[0]
        for lvl in LEVEL_DEFS:
            min_xp, lnum, name, color, glow, icon, icon_class, special = lvl
            if special == "master_criteria":
                if master_ok: current_level = lvl
            elif xp >= min_xp:
                current_level = lvl

        results[uid] = {
            'name': user.name,
            'score': xp,
            'level': {
                'num': current_level[1],
                'name': current_level[2],
                'icon': current_level[5],
                'icon_class': current_level[6],
                'color': current_level[3],
                'glow': current_level[4]
            },
            'quizzes': q_count,
            'challenges': total_challenges,
            'badges': len(u_badges),
            'year_created': user.created_at.year if user.created_at else None,
            'study_year': str(user.study_year) if user.study_year else None,
            'joined_year': user.created_at.year if user.created_at else None,
            'top1': placement_counts[uid]['top1'],
            'top3': placement_counts[uid]['top3'],
            'top10': placement_counts[uid]['top10'],
            'equipped_title': getattr(user, 'equipped_title', None)
        }

    if write_cache:
        with global_user_stats_cache_lock:
            global_user_stats_cache['expires_at'] = now_ts + GLOBAL_USER_STATS_CACHE_TTL_SECONDS
            global_user_stats_cache['payload'] = results
    return results


def sync_all_competitive_badges():
    """Ensure all users with competitive badges still satisfy current criteria, otherwise revoke them."""
    try:
        revocable = ('title_vainqueur', 'title_roi_podium', 'title_legende', 'title_tireur_elite')
        holders = db.session.query(UserBadge.user_id).filter(UserBadge.badge_id.in_(revocable)).distinct().all()
        for (uid,) in holders:
            build_user_badges_payload(uid)
    except Exception as e:
        print(f">>> [WARNING] sync_all_competitive_badges error: {e}", flush=True)


def refresh_global_user_stats_cache():
    global global_user_stats_refresh_future
    started_at = utcnow().isoformat()
    with global_user_stats_cache_lock:
        global_user_stats_refresh_state['status'] = 'running'
        global_user_stats_refresh_state['started_at'] = started_at
        global_user_stats_refresh_state['last_error'] = None
    try:
        with app.app_context():
            compute_bulk_users_stats_payload()
            sync_all_competitive_badges()
    except Exception as exc:
        log_perf_event('global_user_stats_refresh_failed', error=str(exc))
        with global_user_stats_cache_lock:
            global_user_stats_refresh_state['status'] = 'failed'
            global_user_stats_refresh_state['finished_at'] = utcnow().isoformat()
            global_user_stats_refresh_state['last_error'] = str(exc)
    finally:
        with global_user_stats_cache_lock:
            if global_user_stats_refresh_state['status'] != 'failed':
                global_user_stats_refresh_state['status'] = 'idle'
                global_user_stats_refresh_state['finished_at'] = utcnow().isoformat()
            global_user_stats_refresh_future = None


def schedule_global_user_stats_refresh():
    global global_user_stats_refresh_future
    with global_user_stats_cache_lock:
        future = global_user_stats_refresh_future
        if future and not future.done():
            return future
        future = background_task_executor.submit(refresh_global_user_stats_cache)
        global_user_stats_refresh_future = future
        return future


def build_lightweight_leaderboard_payload():
    return compute_bulk_users_stats_payload(include_placements=False, write_cache=False)


def get_bulk_users_stats(allow_stale=False, refresh_async=False):
    """Return cached per-user stats used by progress and leaderboard views."""
    now_ts = time.time()
    with global_user_stats_cache_lock:
        cached_payload = global_user_stats_cache.get('payload')
        cache_is_fresh = cached_payload is not None and global_user_stats_cache['expires_at'] > now_ts

    if cache_is_fresh:
        return cached_payload

    if allow_stale and cached_payload is not None:
        if refresh_async:
            schedule_global_user_stats_refresh()
        return cached_payload

    if refresh_async:
        schedule_global_user_stats_refresh()
        return cached_payload

    return compute_bulk_users_stats_payload()

def safe_entry_date(entry):
    if entry is None:
        return None
    if isinstance(entry, (datetime.datetime, datetime.date)):
        return entry.date() if isinstance(entry, datetime.datetime) else entry
    ts = getattr(entry, 'timestamp', None) if not isinstance(entry, str) else entry
    if not ts:
        return None
    if isinstance(ts, datetime.datetime):
        return ts.date()
    if isinstance(ts, datetime.date):
        return ts
    if isinstance(ts, str):
        try:
            return datetime.date.fromisoformat(ts.split('T')[0].strip())
        except Exception:
            return None
    return None

def compute_user_streak(user_id, preloaded_dates=None):
    """Compute current streak (consecutive active days) and best historical streak."""
    if preloaded_dates is not None:
        active_dates = set(preloaded_dates)
        raw_dates = set(preloaded_dates)
    else:
        from sqlalchemy import union
        qa_q = db.session.query(func.date(QuizAttempt.timestamp).label('act_date')).filter(QuizAttempt.user_id == user_id)
        sub_q = db.session.query(func.date(ChallengeSubmission.timestamp).label('act_date')).filter(
            ChallengeSubmission.user_id == user_id,
            ChallengeSubmission.passed.is_(True)
        )
        union_rows = union(qa_q, sub_q).alias('combined_dates')
        dates = db.session.query(union_rows.c.act_date).distinct().all()
        active_dates = {r[0] if isinstance(r[0], datetime.date) else r[0] for r in dates if r[0]}
        raw_dates = {r[0] for r in dates if r[0]}

    active_dates = set()
    for d in raw_dates:
        parsed = safe_entry_date(d)
        if parsed:
            active_dates.add(parsed)

    if not active_dates:
        return {'current_streak': 0, 'best_streak': 0, 'is_active_today': False}

    today = utcnow().date()
    yesterday = today - datetime.timedelta(days=1)
    is_active_today = today in active_dates

    # Check if current streak is alive (active today or yesterday)
    current_streak = 0
    check_date = today if is_active_today else yesterday
    while check_date in active_dates:
        current_streak += 1
        check_date -= datetime.timedelta(days=1)

    # Calculate best streak
    best_streak = 0
    cur_streak_counter = 0
    prev_date = None
    for d in sorted(list(active_dates)):
        if prev_date is None or d == prev_date + datetime.timedelta(days=1):
            cur_streak_counter += 1
        else:
            cur_streak_counter = 1
        prev_date = d
        if cur_streak_counter > best_streak:
            best_streak = cur_streak_counter

    return {
        'current_streak': current_streak,
        'best_streak': max(best_streak, current_streak),
        'is_active_today': is_active_today
    }


LEGACY_TITLE_MIGRATION = {
    "⚡ Explorateur de Code": "🧭 Explorateur de Code",
    "🔥 Khabeche Acharné": "📚 Khabeche Acharné",
    "🏆 Grand M3alem": "🥋 Grand M3alem",
    "👑 Roi du Podium": "🏆 Roi du Podium",
    "⚡ Légende Intouchable": "💎 Légende Intouchable",
    "⚡ Métronome du Code": "⏱️ Métronome du Code",
}


def compute_unlocked_titles(user_id, xp=0, level_num=1, top1_count=0, streak_days=0,
                           preloaded_badges=None, preloaded_topic_counts=None,
                           preloaded_high_score_quizzes=None, preloaded_equipped_title=None):
    """Return unlocked titles and up to 3 active titles for user_id with unique icons and badge linkage."""
    earned_badges = set()
    topic_counts = {}
    high_score_quizzes = 0

    if preloaded_badges is not None:
        if isinstance(preloaded_badges, set):
            earned_badges = preloaded_badges
        else:
            earned_badges = {getattr(b, 'badge_id', b) for b in preloaded_badges}
    else:
        try:
            earned_badges = {b.badge_id for b in UserBadge.query.filter_by(user_id=user_id).all()}
        except Exception:
            pass

    if preloaded_topic_counts is not None and preloaded_high_score_quizzes is not None:
        topic_counts = preloaded_topic_counts
        high_score_quizzes = preloaded_high_score_quizzes
    else:
        try:
            if preloaded_topic_counts is not None:
                topic_counts = preloaded_topic_counts
            else:
                passed_rows = ChallengeSubmission.query.join(Problem).filter(
                    ChallengeSubmission.user_id == user_id,
                    ChallengeSubmission.passed == True
                ).with_entities(Problem.id, Problem.topic).distinct().all()
                for _, topic in passed_rows:
                    norm_t = normalize_problem_topic(topic)
                    topic_counts[norm_t] = topic_counts.get(norm_t, 0) + 1

            if preloaded_high_score_quizzes is not None:
                high_score_quizzes = preloaded_high_score_quizzes
            else:
                quiz_attempts = QuizAttempt.query.filter_by(user_id=user_id).all()
                high_score_quizzes = sum(1 for qa in quiz_attempts if qa.total_questions > 0 and (qa.score / qa.total_questions) >= 0.8)
        except Exception:
            pass

    unlocked = [
        "🌱 Novice de l'Algorithmique",
    ]
    # Progression & XP
    if "title_explorateur" in earned_badges or level_num >= 2 or xp >= 200:
        unlocked.append("🧭 Explorateur de Code")
    if "title_khabeche" in earned_badges or level_num >= 3 or xp >= 500:
        unlocked.append("📚 Khabeche Acharné")
    if "title_virtuose" in earned_badges or level_num >= 4 or xp >= 1000:
        unlocked.append("⚙️ Virtuose des Algorithmes")
    if "title_m3alem" in earned_badges or level_num >= 5 or xp >= 2000:
        unlocked.append("🥋 Grand M3alem")
    if "title_oustoura" in earned_badges or level_num >= 6 or xp >= 4000:
        unlocked.append("👑 L'Oustoura Vivante")

    # Compétition & Podiums (Dynamiques : révoqués si la place est perdue)
    if "title_vainqueur" in earned_badges and top1_count >= 1:
        unlocked.append("🥇 Vainqueur de Défi")
    if "title_roi_podium" in earned_badges and top1_count >= 3:
        unlocked.append("🏆 Roi du Podium")
    if "title_legende" in earned_badges and top1_count >= 10:
        unlocked.append("💎 Légende Intouchable")
    if "title_tireur_elite" in earned_badges:
        unlocked.append("🎯 Tireur d'Élite O(1)")

    # Assiduité & Streaks
    if "streak_3" in earned_badges or streak_days >= 3:
        unlocked.append("🔥 Flamme Ardente")
    if "streak_7" in earned_badges or streak_days >= 7:
        unlocked.append("⏱️ Métronome du Code")
    if "streak_14" in earned_badges or streak_days >= 14:
        unlocked.append("🛡️ Disciple Indomptable")
    if "streak_30" in earned_badges or streak_days >= 30 or xp >= 1500:
        unlocked.append("🌙 Gardien de la Nuit")

    # Spécialités & Maîtrise
    if "title_dompteur_tableaux" in earned_badges or topic_counts.get("Arrays", 0) >= 5 or xp >= 300:
        unlocked.append("🧩 Dompteur de Tableaux")
    if "title_tisserand_chaines" in earned_badges or topic_counts.get("Strings", 0) >= 5 or xp >= 300:
        unlocked.append("🧵 Tisserand de Chaînes")
    if "title_grand_maitre_quiz" in earned_badges or high_score_quizzes >= 10 or xp >= 600:
        unlocked.append("🧠 Grand Maître des Quiz")

    if preloaded_equipped_title is not None:
        raw_equipped = preloaded_equipped_title
    else:
        user = db.session.get(User, user_id)
        raw_equipped = getattr(user, 'equipped_title', None) if user else None

    equipped_titles = []
    if raw_equipped:
        try:
            parsed = json.loads(raw_equipped)
            if isinstance(parsed, list):
                equipped_titles = [LEGACY_TITLE_MIGRATION.get(t, t) for t in parsed if LEGACY_TITLE_MIGRATION.get(t, t) in unlocked]
            elif isinstance(parsed, str):
                migrated = LEGACY_TITLE_MIGRATION.get(parsed, parsed)
                if migrated in unlocked:
                    equipped_titles = [migrated]
        except Exception:
            for part in str(raw_equipped).split(','):
                part = LEGACY_TITLE_MIGRATION.get(part.strip(), part.strip())
                if part in unlocked:
                    equipped_titles.append(part)

    # Allow at most 3 equipped titles
    equipped_titles = equipped_titles[:3]
    if not equipped_titles:
        equipped_titles = [unlocked[-1]]

    return {
        'equipped': equipped_titles[0],
        'equipped_titles': equipped_titles,
        'unlocked': unlocked
    }

def get_badge_definitions():
    return {
        # --- TITRES & SUCCÈS ASSOCIÉS (Icônes uniques & Déblocage synchronisé) ---
        # 1. Progression & XP
        "title_novice": {"name": "Novice de l'Algorithmique", "desc": "Niveau 1 atteint (Tous les étudiants)", "icon": "fas fa-seedling", "category": "progression", "title": "🌱 Novice de l'Algorithmique", "xp": 10, "difficulty": "Easy"},
        "title_explorateur": {"name": "Explorateur de Code", "desc": "Niveau 2 atteint (200 XP)", "icon": "fas fa-compass", "category": "progression", "title": "🧭 Explorateur de Code", "xp": 15, "difficulty": "Easy"},
        "title_khabeche": {"name": "Khabeche Acharné", "desc": "Niveau 3 atteint (500 XP)", "icon": "fas fa-book", "category": "progression", "title": "📚 Khabeche Acharné", "xp": 20, "difficulty": "Medium"},
        "title_virtuose": {"name": "Virtuose des Algorithmes", "desc": "Niveau 4 atteint (1000 XP)", "icon": "fas fa-cogs", "category": "progression", "title": "⚙️ Virtuose des Algorithmes", "xp": 25, "difficulty": "Medium"},
        "title_m3alem": {"name": "Grand M3alem", "desc": "Niveau 5 atteint (2000 XP)", "icon": "fas fa-user-ninja", "category": "progression", "title": "🥋 Grand M3alem", "xp": 25, "difficulty": "Hard"},
        "title_oustoura": {"name": "L'Oustoura Vivante", "desc": "Niveau 6 atteint (4000 XP)", "icon": "fas fa-crown", "category": "progression", "title": "👑 L'Oustoura Vivante", "xp": 30, "difficulty": "Hard"},

        # 2. Compétition & Podiums
        "title_vainqueur": {"name": "Vainqueur de Défi", "desc": "Au moins 1 première place (Top 1)", "icon": "fas fa-medal", "category": "competition", "title": "🥇 Vainqueur de Défi", "xp": 15, "difficulty": "Medium"},
        "title_roi_podium": {"name": "Roi du Podium", "desc": "Au moins 3 premières places (Top 1)", "icon": "fas fa-trophy", "category": "competition", "title": "🏆 Roi du Podium", "xp": 20, "difficulty": "Medium"},
        "title_legende": {"name": "Légende Intouchable", "desc": "Au moins 10 premières places (Top 1)", "icon": "fas fa-gem", "category": "competition", "title": "💎 Légende Intouchable", "xp": 25, "difficulty": "Hard"},
        "title_tireur_elite": {"name": "Tireur d'Élite O(1)", "desc": "Temps d'exécution optimal N°1 (Défi Medium/Hard)", "icon": "fas fa-crosshairs", "category": "competition", "title": "🎯 Tireur d'Élite O(1)", "xp": 25, "difficulty": "Hard"},

        # 3. Assiduité & Séries (Streaks)
        "streak_3": {"name": "Flamme Ardente", "desc": "Série active de 3 jours consécutifs", "icon": "fas fa-fire", "category": "streak", "title": "🔥 Flamme Ardente", "xp": 10, "difficulty": "Easy"},
        "streak_7": {"name": "Métronome du Code", "desc": "Série active de 7 jours consécutifs", "icon": "fas fa-stopwatch", "category": "streak", "title": "⏱️ Métronome du Code", "xp": 25, "difficulty": "Easy"},
        "streak_14": {"name": "Disciple Indomptable", "desc": "Série active de 14 jours consécutifs", "icon": "fas fa-shield-alt", "category": "streak", "title": "🛡️ Disciple Indomptable", "xp": 50, "difficulty": "Medium"},
        "streak_30": {"name": "Gardien de la Nuit", "desc": "Série active de 30 jours consécutifs", "icon": "fas fa-moon", "category": "streak", "title": "🌙 Gardien de la Nuit", "xp": 100, "difficulty": "Hard"},

        # 4. Spécialités Algorithmiques
        "title_dompteur_tableaux": {"name": "Dompteur de Tableaux", "desc": "Au moins 5 défis résolus sur les Tableaux", "icon": "fas fa-puzzle-piece", "category": "maitre", "title": "🧩 Dompteur de Tableaux", "xp": 15, "difficulty": "Medium"},
        "title_tisserand_chaines": {"name": "Tisserand de Chaînes", "desc": "Au moins 5 défis résolus sur les Chaînes", "icon": "fas fa-scroll", "category": "maitre", "title": "🧵 Tisserand de Chaînes", "xp": 15, "difficulty": "Medium"},
        "title_grand_maitre_quiz": {"name": "Grand Maître des Quiz", "desc": "Au moins 10 quiz réussis avec un score ≥ 80%", "icon": "fas fa-brain", "category": "maitre", "title": "🧠 Grand Maître des Quiz", "xp": 25, "difficulty": "Hard"},

        # --- Autres Badges Spécifiques ---
        "course_1": {"name": "Premier Pas", "desc": "1 cours terminé", "icon": "fas fa-book-open", "category": "course", "xp": 10, "difficulty": "Easy"},
        "course_3": {"name": "Étudiant Assidu", "desc": "3 cours terminés", "icon": "fas fa-book-reader", "category": "course", "xp": 25, "difficulty": "Easy"},
        "course_7": {"name": "Érudit", "desc": "7 cours terminés", "icon": "fas fa-graduation-cap", "category": "course", "xp": 50, "difficulty": "Medium"},
        "course_10_master": {"name": "Algo Master", "desc": "10 cours terminés", "icon": "fas fa-university", "category": "course", "xp": 100, "difficulty": "Hard"},
        "chall_1": {"name": "Développeur", "desc": "1 défi terminé", "icon": "fas fa-keyboard", "category": "challenges", "xp": 10, "difficulty": "Easy"},
        "chall_5": {"name": "Codeur", "desc": "5 défis terminés", "icon": "fas fa-laptop-code", "category": "challenges", "xp": 25, "difficulty": "Easy"},
        "chall_10_beg": {"name": "Débutant", "desc": "10 défis terminés", "icon": "fas fa-medal", "category": "challenges", "xp": 40, "difficulty": "Medium"},
        "chall_20_int": {"name": "Intermédiaire", "desc": "20 défis terminés", "icon": "fas fa-award", "category": "challenges", "xp": 60, "difficulty": "Medium"},
        "chall_50_adv": {"name": "Avancé", "desc": "50 défis terminés", "icon": "fas fa-trophy", "category": "challenges", "xp": 80, "difficulty": "Hard"},
        "chall_100_mast": {"name": "Maître des Défis", "desc": "100 défis terminés", "icon": "fas fa-crown", "category": "challenges", "xp": 100, "difficulty": "Hard"},
        "hacker_bronze": {"name": "Hacker Bronze", "desc": "Tous cours, avg > 70%, 10 défis dont 2 difficiles", "icon": "fas fa-user-ninja", "category": "mastery", "xp": 50, "difficulty": "Medium"},
        "hacker_gold": {"name": "Hacker Or", "desc": "Tous cours, avg > 80%, 15 défis dont 3 difficiles", "icon": "fas fa-user-ninja", "category": "mastery", "xp": 75, "difficulty": "Hard"},
        "hacker_platinum": {"name": "Hacker Platine", "desc": "Tous cours, avg > 90%, 20 défis dont 4 difficiles", "icon": "fas fa-user-ninja", "category": "mastery", "xp": 85, "difficulty": "Hard"},
        "hacker_diamond": {"name": "Hacker Diamant", "desc": "Tous cours, avg > 92%, 30 défis dont 6 difficiles", "icon": "fas fa-user-astronaut", "category": "mastery", "xp": 90, "difficulty": "Hard"},
        "hacker_master": {"name": "Maître Hacker", "desc": "Tous cours, avg > 95%, 40 défis dont 8 difficiles", "icon": "fas fa-user-secret", "category": "mastery", "xp": 95, "difficulty": "Hard"},
        "hacker_grandmaster": {"name": "Grand Maître Hacker", "desc": "Tous cours, avg > 99%, 50 défis dont 10 difficiles", "icon": "fas fa-user-secret", "category": "mastery", "xp": 100, "difficulty": "Hard"},
        "maitre_tableaux": {"name": "Maitre des Tableaux", "desc": "20 problèmes sur Arrays", "icon": "fas fa-table", "category": "maitre", "xp": 60, "difficulty": "Medium"},
        "maitre_chaines": {"name": "Maitre des Chaines", "desc": "20 problèmes sur Strings", "icon": "fas fa-font", "category": "maitre", "xp": 60, "difficulty": "Medium"},
        "maitre_enregistrements": {"name": "Maitre des Enregistrements", "desc": "20 problèmes d'Enregistrements", "icon": "fas fa-address-card", "category": "maitre", "xp": 60, "difficulty": "Medium"},
        "maitre_listes": {"name": "Maitre des Listes Chainees", "desc": "20 problèmes sur LinkedList", "icon": "fas fa-link", "category": "maitre", "xp": 60, "difficulty": "Medium"},
        "maitre_files": {"name": "Maitre des Files", "desc": "20 problèmes sur Files", "icon": "fas fa-layer-group", "category": "maitre", "xp": 60, "difficulty": "Medium"},
        "maitre_piles": {"name": "Maitre des Piles", "desc": "20 problèmes sur Piles", "icon": "fas fa-bars", "category": "maitre", "xp": 60, "difficulty": "Medium"},
    }


def build_chapter_stats_map(quiz_attempts):
    chapter_stats = {}
    for qa in quiz_attempts:
        chap_id = qa.chapter_id
        is_completed = (qa.score / qa.total_questions) >= 0.8 if qa.total_questions > 0 else False
        score_perc = (qa.score / qa.total_questions * 100) if qa.total_questions > 0 else 0
        if chap_id not in chapter_stats:
            chapter_stats[chap_id] = {
                'all_correct': is_completed,
                'taken': True,
                'score': qa.score,
                'total': qa.total_questions,
                'attempts_count': 1,
                'total_perc': score_perc
            }
            continue

        chapter_stats[chap_id]['attempts_count'] += 1
        chapter_stats[chap_id]['total_perc'] += score_perc
        if is_completed:
            chapter_stats[chap_id]['all_correct'] = True
        if qa.score > chapter_stats[chap_id]['score']:
            chapter_stats[chap_id]['score'] = qa.score
            chapter_stats[chap_id]['total'] = qa.total_questions

    for chap_id, stats in chapter_stats.items():
        stats['avg_score'] = round(stats['total_perc'] / stats['attempts_count'], 1)
    return chapter_stats


def build_frontend_chapter_stats(chapter_stats, chapters):
    chapter_map = {chapter.id: chapter.identifier for chapter in chapters}
    frontend_chapter_stats = {}
    for chapter_id, stats in chapter_stats.items():
        identifier = chapter_map.get(chapter_id)
        if identifier:
            frontend_chapter_stats[identifier] = stats
    return frontend_chapter_stats, chapter_map


def build_challenge_stats_map(submissions):
    challenge_stats = {}
    for sub in submissions:
        problem_stats = challenge_stats.setdefault(sub.problem_id, {'passed': False, 'best_score': 0})
        if sub.passed:
            problem_stats['passed'] = True
        if sub.score > problem_stats['best_score']:
            problem_stats['best_score'] = sub.score
    return challenge_stats


def normalize_problem_topic(value):
    topic = str(value or '').strip().lower()
    if 'pile' in topic or 'stack' in topic:
        return 'Piles'
    if 'liste' in topic or 'chain' in topic or 'linked' in topic:
        return 'Listes_Chainees'
    if 'file' in topic or 'queue' in topic:
        return 'Files'
    if 'array' in topic or 'tableau' in topic:
        return 'Arrays'
    if 'string' in topic or 'chaine' in topic:
        return 'Strings'
    if 'enregistr' in topic or 'record' in topic:
        return 'Enregistrements'
    return str(value or '').strip()


def build_user_progress_summary_payload(user_id):
    quiz_attempts = QuizAttempt.query.filter_by(user_id=user_id).order_by(QuizAttempt.timestamp.desc()).all()
    submissions = ChallengeSubmission.query.filter_by(user_id=user_id).order_by(ChallengeSubmission.timestamp.desc()).all()

    chapter_stats = build_chapter_stats_map(quiz_attempts)
    frontend_chapter_stats, _ = build_frontend_chapter_stats(chapter_stats, get_all_chapters_cached())
    challenge_stats = build_challenge_stats_map(submissions)

    total_quizzes = len(quiz_attempts)
    passed_quizzes = sum(1 for qa in quiz_attempts if qa.total_questions > 0 and (qa.score / qa.total_questions) >= 0.5)
    valid_attempts = [qa for qa in quiz_attempts if qa.total_questions > 0]
    avg_quiz_score_pct = sum((qa.score / qa.total_questions) * 100 for qa in valid_attempts) / len(valid_attempts) if valid_attempts else 0.0

    total_challenges_attempted = len(set(sub.problem_id for sub in submissions))
    total_available_challenges = Problem.query.filter_by(is_published=True).count()
    if total_available_challenges == 0:
        total_available_challenges = Problem.query.count()
    passed_challenges = sum(1 for stats in challenge_stats.values() if stats['passed'])

    global_user_stats = get_bulk_users_stats()
    global_user_stats = get_bulk_users_stats() or {}
    current_global_stats = global_user_stats.get(user_id, {})
    current_user_placements = {
        'top1': current_global_stats.get('top1', 0),
        'top3': current_global_stats.get('top3', 0),
        'top10': current_global_stats.get('top10', 0)
    }
    top1_percentage = round((current_user_placements['top1'] / total_available_challenges) * 100, 1) if total_available_challenges else 0.0
    top3_percentage = round((current_user_placements['top3'] / total_available_challenges) * 100, 1) if total_available_challenges else 0.0
    top10_percentage = round((current_user_placements['top10'] / total_available_challenges) * 100, 1) if total_available_challenges else 0.0
    leaderboard_bucket = compute_user_leaderboard_bucket(global_user_stats, user_id)

    xp_total, xp_breakdown, level_dict, xp_to_next = compute_xp_and_level(
        user_id,
        preloaded_quiz_attempts=quiz_attempts,
        preloaded_submissions=[s for s in submissions if s.passed]
    )
    with user_level_cache_lock:
        user_level_cache[user_id] = {
            'expires_at': time.time() + USER_LEVEL_CACHE_TTL_SECONDS,
            'payload': {
                'xp_total': xp_total,
                'level': level_dict,
                'xp_to_next': xp_to_next,
                'computed_at': utcnow().isoformat()
            }
        }

    distinct_active_dates = {entry.timestamp.date() for entry in submissions if entry.timestamp and entry.passed} | {entry.timestamp.date() for entry in quiz_attempts if entry.timestamp}
    distinct_active_dates = {safe_entry_date(entry) for entry in submissions if entry.passed and safe_entry_date(entry)} | {safe_entry_date(entry) for entry in quiz_attempts if safe_entry_date(entry)}
    streak_info = compute_user_streak(user_id, preloaded_dates=distinct_active_dates)
    quizzes_high_score = sum(1 for qa in quiz_attempts if qa.total_questions > 0 and (qa.score / qa.total_questions) >= 0.8)
    titles_info = compute_unlocked_titles(
        user_id=user_id,
        xp=xp_total,
        level_num=level_dict.get('num', 1),
        top1_count=current_user_placements['top1'],
        streak_days=streak_info.get('current_streak', 0),
        preloaded_high_score_quizzes=quizzes_high_score
    )
    prestige_badge = compute_user_prestige_badge(user_id, global_user_stats)

    return {
        'chapter_stats': frontend_chapter_stats,
        'challenge_stats': challenge_stats,
        'total_quizzes_taken': total_quizzes,
        'total_quizzes_passed': passed_quizzes,
        'passed_quizzes': passed_quizzes,
        'avg_quiz_score_pct': avg_quiz_score_pct,
        'total_challenges_attempted': total_challenges_attempted,
        'total_available_challenges': total_available_challenges,
        'challenges_completed': passed_challenges,
        'top1_finishes': current_user_placements['top1'],
        'top1_percentage': top1_percentage,
        'top3_finishes': current_user_placements['top3'],
        'top3_percentage': top3_percentage,
        'top10_finishes': current_user_placements['top10'],
        'top10_percentage': top10_percentage,
        'leaderboard_bucket': leaderboard_bucket,
        'prestige_badge': prestige_badge,
        'streak': streak_info,
        'titles': titles_info,
        'xp_total': xp_total,
        'xp_breakdown': xp_breakdown,
        'level': level_dict,
        'xp_to_next': xp_to_next
    }


def build_user_badges_payload(user_id):
    quiz_attempts = QuizAttempt.query.filter_by(user_id=user_id).order_by(QuizAttempt.timestamp.desc()).all()
    submissions = ChallengeSubmission.query.filter_by(user_id=user_id).order_by(ChallengeSubmission.timestamp.desc()).all()

    chapter_stats = build_chapter_stats_map(quiz_attempts)
    frontend_chapter_stats, _ = build_frontend_chapter_stats(chapter_stats, get_all_chapters_cached())
    challenge_stats = build_challenge_stats_map(submissions)
    challenges_completed = sum(1 for stats in challenge_stats.values() if stats['passed'])
    courses_completed = sum(1 for stats in frontend_chapter_stats.values() if stats.get('all_correct'))

    hard_problems_passed = ChallengeSubmission.query.join(Problem).filter(
        ChallengeSubmission.user_id == user_id,
        ChallengeSubmission.passed == True,
        Problem.difficulty == 'Hard'
    ).with_entities(Problem.id).distinct().count()

    total_course_score = sum(stats['score'] / stats['total'] for stats in chapter_stats.values()) if chapter_stats else 0
    num_courses_taken = len(chapter_stats) if chapter_stats else 1
    avg_course_score = (total_course_score / num_courses_taken) * 100
    distinct_active_days = {entry.timestamp.date() for entry in submissions} | {entry.timestamp.date() for entry in quiz_attempts}
    distinct_active_days = {safe_entry_date(entry) for entry in submissions if safe_entry_date(entry)} | {safe_entry_date(entry) for entry in quiz_attempts if safe_entry_date(entry)}
    active_days = len(distinct_active_days)

    passed_problem_rows = ChallengeSubmission.query.join(Problem).filter(
        ChallengeSubmission.user_id == user_id,
        ChallengeSubmission.passed == True
    ).with_entities(Problem.id, Problem.topic).distinct().all()
    topic_counts_norm = {}
    for _, topic in passed_problem_rows:
        normalized_topic = normalize_problem_topic(topic)
        topic_counts_norm[normalized_topic] = topic_counts_norm.get(normalized_topic, 0) + 1

    badges_to_award = []
    # --- Titres & Succès Associés ---
    badges_to_award.append("title_novice")
    xp_total, _, level_dict, _ = compute_xp_and_level(
        user_id,
        preloaded_quiz_attempts=quiz_attempts,
        preloaded_submissions=[s for s in submissions if s.passed]
    )
    level_num = level_dict.get('num', 1)
    bulk_stats = get_bulk_users_stats()
    user_bulk = bulk_stats.get(user_id, {})
    top1_count = user_bulk.get('top1', 0)
    quizzes_high_score = sum(1 for qa in quiz_attempts if qa.total_questions > 0 and (qa.score / qa.total_questions) >= 0.8)

    if level_num >= 2 or xp_total >= 200: badges_to_award.append("title_explorateur")
    if level_num >= 3 or xp_total >= 500: badges_to_award.append("title_khabeche")
    if level_num >= 4 or xp_total >= 1000: badges_to_award.append("title_virtuose")
    if level_num >= 5 or xp_total >= 2000: badges_to_award.append("title_m3alem")
    if level_num >= 6 or xp_total >= 4000: badges_to_award.append("title_oustoura")

    if top1_count >= 1: badges_to_award.append("title_vainqueur")
    if top1_count >= 3: badges_to_award.append("title_roi_podium")
    if top1_count >= 10: badges_to_award.append("title_legende")

    # Tireur d'Élite O(1) : classé N°1 au temps d'exécution CPU sur au moins un défi Medium ou Hard
    has_optimal_exec = False
    passed_med_hard_subs = db.session.query(ChallengeSubmission).join(
        Problem, ChallengeSubmission.problem_id == Problem.id
    ).filter(
        ChallengeSubmission.user_id == user_id,
        ChallengeSubmission.passed.is_(True),
        Problem.difficulty.in_(['Medium', 'Hard'])
    ).all()
    med_hard_problem_ids = [
        sub.problem_id for sub in passed_med_hard_subs
        if sub.avg_execution_time_ms is not None
    ]
    if med_hard_problem_ids:
        min_times = dict(
            db.session.query(
                ChallengeSubmission.problem_id,
                func.min(ChallengeSubmission.avg_execution_time_ms)
            ).filter(
                ChallengeSubmission.problem_id.in_(med_hard_problem_ids),
                ChallengeSubmission.passed.is_(True),
                ChallengeSubmission.avg_execution_time_ms.isnot(None)
            ).group_by(ChallengeSubmission.problem_id).all()
        )
        for sub in passed_med_hard_subs:
            if sub.avg_execution_time_ms is not None:
                min_time = min_times.get(sub.problem_id)
                if min_time is not None and sub.avg_execution_time_ms <= min_time:
                    has_optimal_exec = True
                    break
    if has_optimal_exec:
        badges_to_award.append("title_tireur_elite")

    if topic_counts_norm.get("Arrays", 0) >= 5: badges_to_award.append("title_dompteur_tableaux")
    if topic_counts_norm.get("Strings", 0) >= 5: badges_to_award.append("title_tisserand_chaines")
    if quizzes_high_score >= 10: badges_to_award.append("title_grand_maitre_quiz")

    # --- Séries (Streaks) ---
    if active_days >= 3: badges_to_award.append("streak_3")
    if active_days >= 7: badges_to_award.append("streak_7")
    if active_days >= 14: badges_to_award.append("streak_14")
    if active_days >= 30: badges_to_award.append("streak_30")
    if active_days >= 60: badges_to_award.append("streak_60")
    if active_days >= 90: badges_to_award.append("streak_90")
    if active_days >= 180: badges_to_award.append("streak_180")
    if active_days >= 365: badges_to_award.append("streak_365")
    if courses_completed >= 1: badges_to_award.append("course_1")
    if courses_completed >= 3: badges_to_award.append("course_3")
    if courses_completed >= 7: badges_to_award.append("course_7")
    if courses_completed >= 10: badges_to_award.append("course_10_master")
    if challenges_completed >= 1: badges_to_award.append("chall_1")
    if challenges_completed >= 5: badges_to_award.append("chall_5")
    if challenges_completed >= 10: badges_to_award.append("chall_10_beg")
    if challenges_completed >= 20: badges_to_award.append("chall_20_int")
    if challenges_completed >= 50: badges_to_award.append("chall_50_adv")
    if challenges_completed >= 100: badges_to_award.append("chall_100_mast")

    all_courses_finished = courses_completed >= 10
    if all_courses_finished and avg_course_score > 70 and challenges_completed >= 10 and hard_problems_passed >= 2:
        badges_to_award.append("hacker_bronze")
    if all_courses_finished and avg_course_score > 80 and challenges_completed >= 15 and hard_problems_passed >= 3:
        badges_to_award.append("hacker_gold")
    if all_courses_finished and avg_course_score > 90 and challenges_completed >= 20 and hard_problems_passed >= 4:
        badges_to_award.append("hacker_platinum")
    if all_courses_finished and avg_course_score > 92 and challenges_completed >= 30 and hard_problems_passed >= 6:
        badges_to_award.append("hacker_diamond")
    if all_courses_finished and avg_course_score > 95 and challenges_completed >= 40 and hard_problems_passed >= 8:
        badges_to_award.append("hacker_master")
    if all_courses_finished and avg_course_score > 99 and challenges_completed >= 50 and hard_problems_passed >= 10:
        badges_to_award.append("hacker_grandmaster")

    if topic_counts_norm.get("Arrays", 0) >= 20: badges_to_award.append("maitre_tableaux")
    if topic_counts_norm.get("Strings", 0) >= 20: badges_to_award.append("maitre_chaines")
    if topic_counts_norm.get("Enregistrements", 0) >= 20: badges_to_award.append("maitre_enregistrements")
    if topic_counts_norm.get("Listes_Chainees", 0) >= 20: badges_to_award.append("maitre_listes")
    if topic_counts_norm.get("Files", 0) >= 20: badges_to_award.append("maitre_files")
    if topic_counts_norm.get("Piles", 0) >= 20: badges_to_award.append("maitre_piles")

    COMPETITIVE_REVOCABLE_BADGES = {
        "title_vainqueur",
        "title_roi_podium",
        "title_legende",
        "title_tireur_elite"
    }

    existing_badges = {badge.badge_id: badge for badge in UserBadge.query.filter_by(user_id=user_id).all()}
    new_badges_awarded = []
    badges_revoked = []

    # 1. Award newly earned badges
    for badge_id in badges_to_award:
        if badge_id in existing_badges:
            continue
        badge = UserBadge(user_id=user_id, badge_id=badge_id, seen=False)
        db.session.add(badge)
        new_badges_awarded.append(badge_id)
        existing_badges[badge_id] = badge

    # 2. Revoke dynamic competitive badges that are no longer earned (e.g. lost Top 1)
    for badge_id in COMPETITIVE_REVOCABLE_BADGES:
        if badge_id in existing_badges and badge_id not in badges_to_award:
            db.session.delete(existing_badges[badge_id])
            badges_revoked.append(badge_id)
            del existing_badges[badge_id]

    if new_badges_awarded or badges_revoked:
        # If any titles were revoked, unequip them if currently equipped on user profile
        if badges_revoked:
            user = db.session.get(User, user_id)
            if user and user.equipped_title:
                try:
                    b_defs = get_badge_definitions()
                    revoked_labels = set()
                    for r_bid in badges_revoked:
                        t = b_defs.get(r_bid, {}).get('title')
                        if t:
                            revoked_labels.add(t.strip())
                    
                    eq = user.equipped_title.strip()
                    if eq.startswith('['):
                        parsed_eq = json.loads(eq)
                        cleaned = [t for t in parsed_eq if t.strip() not in revoked_labels]
                        if not cleaned:
                            cleaned = ["🌱 Novice de l'Algorithmique"]
                        user.equipped_title = json.dumps(cleaned)
                    else:
                        if eq in revoked_labels:
                            user.equipped_title = json.dumps(["🌱 Novice de l'Algorithmique"])
                except Exception:
                    pass

        db.session.commit()
        invalidate_global_user_stats_cache()
        invalidate_user_level_cache(user_id)
        invalidate_user_progress_summary_cache(user_id)
        schedule_global_user_stats_refresh()

    badge_defs = get_badge_definitions()
    badges_response = [{
        "id": badge_id,
        "identifier": badge_id,
        "name": meta["name"],
        "description": meta["desc"],
        "icon": meta["icon"],
        "category": meta["category"],
        "xp": meta.get("xp", 10),
        "difficulty": meta.get("difficulty", "Easy"),
        "earned": badge_id in existing_badges,
        "seen": existing_badges[badge_id].seen if badge_id in existing_badges else True
    } for badge_id, meta in badge_defs.items()]

    tracked_topics = ["Arrays", "Strings", "Enregistrements", "Listes_Chainees", "Files", "Piles"]
    topic_counts = {topic: topic_counts_norm.get(topic, 0) for topic in tracked_topics}

    return {
        'badges': badges_response,
        'active_days': active_days,
        'courses_completed': courses_completed,
        'hard_challenges_completed': hard_problems_passed,
        'avg_course_score': avg_course_score,
        'challenges_completed': challenges_completed,
        'topic_counts': topic_counts,
        'quizzes_high_score': quizzes_high_score,
        'top1_finishes': top1_count,
        'level': level_dict,
        'xp_total': xp_total,
        'summary_refresh_required': bool(new_badges_awarded),
        'newly_awarded_badge_ids': new_badges_awarded
    }


def build_user_progress_advanced_payload(user_id):
    quiz_attempts = QuizAttempt.query.filter_by(user_id=user_id).order_by(QuizAttempt.timestamp.desc()).all()
    submissions = ChallengeSubmission.query.filter_by(user_id=user_id).order_by(ChallengeSubmission.timestamp.desc()).all()
    chapter_map = get_chapter_id_to_identifier_map()

    passed_problem_rows = ChallengeSubmission.query.join(Problem).filter(
        ChallengeSubmission.user_id == user_id,
        ChallengeSubmission.passed == True
    ).with_entities(Problem.id, Problem.topic, Problem.difficulty).distinct().all()

    challenge_topic_dist = {}
    challenge_diff_dist = {'Easy': 0, 'Medium': 0, 'Hard': 0}
    for _, topic, difficulty in passed_problem_rows:
        challenge_topic_dist[topic] = challenge_topic_dist.get(topic, 0) + 1
        if difficulty in challenge_diff_dist:
            challenge_diff_dist[difficulty] += 1

    daily_stats = {}
    for qa in quiz_attempts:
        day = qa.timestamp.date().isoformat()
        day_stats = daily_stats.setdefault(day, {'total_score': 0, 'count': 0})
        day_stats['total_score'] += ((qa.score / qa.total_questions) * 20) if qa.total_questions > 0 else 0
        day_stats['count'] += 1
    daily_avg_quiz_score = [
        {'day': day, 'avg': round(stats['total_score'] / stats['count'], 1)}
        for day, stats in sorted(daily_stats.items())
    ]

    quiz_evolution_per_chapter = {}
    for qa in sorted(quiz_attempts, key=lambda item: item.timestamp):
        identifier = chapter_map.get(qa.chapter_id)
        if not identifier:
            continue
        quiz_evolution_per_chapter.setdefault(identifier, []).append({
            'ts': qa.timestamp.isoformat(),
            'score': round(((qa.score / qa.total_questions) * 20), 1) if qa.total_questions > 0 else 0
        })

    activity_map = {}
    one_year_ago = datetime.date.today() - datetime.timedelta(days=365)
    for sub in submissions:
        day = sub.timestamp.date()
        if day >= one_year_ago:
            day_key = day.isoformat()
            activity_map[day_key] = activity_map.get(day_key, 0) + 1
    for qa in quiz_attempts:
        day = qa.timestamp.date()
        if day >= one_year_ago:
            day_key = day.isoformat()
            activity_map[day_key] = activity_map.get(day_key, 0) + 1

    return {
        'activity_map': activity_map,
        'advanced_stats': {
            'challenge_topic_dist': challenge_topic_dist,
            'challenge_diff_dist': challenge_diff_dist,
            'daily_avg_quiz_score': daily_avg_quiz_score,
            'quiz_evolution_per_chapter': quiz_evolution_per_chapter
        }
    }


def get_cached_user_progress_summary_payload(user_id):
    return get_cached_user_payload(
        user_progress_cache,
        user_progress_cache_lock,
        USER_PROGRESS_CACHE_TTL_SECONDS,
        user_id,
        build_user_progress_summary_payload
    )


def get_cached_user_badges_payload(user_id):
    payload = get_cached_user_payload(
        user_badges_cache,
        user_badges_cache_lock,
        USER_BADGES_CACHE_TTL_SECONDS,
        user_id,
        build_user_badges_payload
    )
    if payload.get('summary_refresh_required') or payload.get('newly_awarded_badge_ids'):
        response_payload = dict(payload)
        with user_badges_cache_lock:
            cached_entry = user_badges_cache.get(int(user_id))
            if cached_entry and cached_entry.get('payload'):
                cached_entry['payload'] = {
                    **cached_entry['payload'],
                    'summary_refresh_required': False,
                    'newly_awarded_badge_ids': []
                }
        return response_payload
    return payload


def get_cached_user_progress_advanced_payload(user_id):
    return get_cached_user_payload(
        user_progress_advanced_cache,
        user_progress_advanced_cache_lock,
        USER_PROGRESS_ADVANCED_CACHE_TTL_SECONDS,
        user_id,
        build_user_progress_advanced_payload
    )


def build_user_progress_payload(user_id):
    badges_payload = get_cached_user_badges_payload(user_id)
    summary_payload = get_cached_user_progress_summary_payload(user_id)
    advanced_payload = get_cached_user_progress_advanced_payload(user_id)
    return {
        **summary_payload,
        **badges_payload,
        **advanced_payload
    }


def get_cached_user_progress_payload(user_id):
    return build_user_progress_payload(user_id)


@app.route('/api/user/progress/summary', methods=['GET'])
def get_user_progress_summary():
    if not current_user.is_authenticated:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401

    return jsonify({
        'success': True,
        'progress': get_cached_user_progress_summary_payload(current_user.id)
    })
    try:
        payload = get_cached_user_progress_summary_payload(current_user.id)
        return jsonify({
            'success': True,
            'progress': payload
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': f"Erreur serveur: {str(e)}"}), 500


@app.route('/api/user/progress/badges', methods=['GET'])
def get_user_progress_badges():
    if not current_user.is_authenticated:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401

    return jsonify({
        'success': True,
        'progress': get_cached_user_badges_payload(current_user.id)
    })


@app.route('/api/user/progress/advanced', methods=['GET'])
def get_user_progress_advanced():
    if not current_user.is_authenticated:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401

    return jsonify({
        'success': True,
        'progress': get_cached_user_progress_advanced_payload(current_user.id)
    })


@app.route('/api/user/progress', methods=['GET'])
def get_user_progress():
    if not current_user.is_authenticated:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401

    return jsonify({
        'success': True,
        'progress': get_cached_user_progress_payload(current_user.id)
    })


@app.route('/api/user/level', methods=['GET'])
def get_user_level():
    if not current_user.is_authenticated:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401

    snapshot = get_cached_user_level_snapshot(current_user.id)
    return jsonify({
        'success': True,
        'xp_total': snapshot['xp_total'],
        'level': snapshot['level'],
        'xp_to_next': snapshot['xp_to_next'],
        'computed_at': snapshot['computed_at']
    })

@app.route('/leaderboards')
@app.route('/leaderboard')
def leaderboard_page():
    return render_template('leaderboard.html')

@app.route('/hall-of-fame')
@app.route('/leaderboard/hall-of-fame')
def hall_of_fame_page():
    return redirect(url_for('leaderboard_page'))

@app.route('/api/leaderboard', methods=['GET'])
def get_leaderboard():
    try:
        year_param = (request.args.get('year') or '').strip().lower()
        year = None
        if year_param and year_param not in {'overall', 'all'}:
            if year_param in {'current', 'default'}:
                year = get_current_academic_year()
            else:
                try:
                    year = int(year_param)
                except ValueError:
                    return jsonify({'success': False, 'error': 'Invalid year filter'}), 400

        payload = build_global_leaderboard_response_payload(year=year)
        entries = payload.get('leaderboard', [])
        ranked_entries = [e for e in entries if e.get('is_ranked')]
        
        # Determine podium for the requested year, or fallback to previous year if < 3 ranked
        podium = []
        podium_is_fallback = False
        podium_year = str(year) if year is not None else 'overall'

        if len(ranked_entries) >= 3:
            podium = ranked_entries[:3]
            podium_is_fallback = False
        else:
            # Fallback for podium: look at previous years (e.g. year - 1, year - 2, or overall)
            found_fallback = False
            if year is not None:
                for candidate_prev in [year - 1, year - 2, 2026]:
                    if candidate_prev != year and candidate_prev >= 2020:
                        prev_payload = build_global_leaderboard_response_payload(year=candidate_prev)
                        prev_ranked = [e for e in prev_payload.get('leaderboard', []) if e.get('is_ranked')]
                        if len(prev_ranked) >= 3:
                            podium = prev_ranked[:3]
                            podium_is_fallback = True
                            podium_year = str(candidate_prev)
                            found_fallback = True
                            break
            
            if not found_fallback:
                # Fallback to overall
                overall_payload = build_global_leaderboard_response_payload(year=None)
                overall_ranked = [e for e in overall_payload.get('leaderboard', []) if e.get('is_ranked')]
                podium = overall_ranked[:3]
                podium_is_fallback = (year is not None)
                podium_year = 'overall'

        payload['podium'] = podium
        payload['podium_is_fallback'] = podium_is_fallback
        payload['podium_year'] = podium_year
        payload['active_year'] = str(year) if year is not None else 'overall'

        return jsonify(payload)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/hall-of-fame', methods=['GET'])
def get_hall_of_fame():
    try:
        payload = build_global_leaderboard_response_payload()
        entries = payload.get('leaderboard', [])
        ranked_entries = [entry for entry in entries if entry.get('is_ranked')]
        entries_by_user = {
            int(entry['user_id']): entry
            for entry in entries
            if entry.get('user_id') is not None
        }

        payload.update({
            'podium': ranked_entries[:3],
            'top_contributors': ranked_entries[:12],
            'honoree': build_public_honoree_payload(SECURITY_HONOREE_USER_ID, entries_by_user),
            'acknowledgment': HALL_OF_FAME_ACKNOWLEDGMENT,
        })
        return jsonify(payload)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/badges')
@login_required
def badges_page():
    return render_template('badges.html')

@app.route('/api/user/badges/seen', methods=['POST'])
@login_required
def mark_badges_seen():
    try:
        data = request.json or {}
        badge_ids = data.get('badge_ids', [])
        
        if badge_ids:
            # Mark specific badges
            UserBadge.query.filter(
                UserBadge.user_id == current_user.id,
                UserBadge.badge_id.in_(badge_ids)
            ).update({"seen": True}, synchronize_session=False)
        else:
            # Mark all as seen
            UserBadge.query.filter_by(
                user_id=current_user.id, 
                seen=False
            ).update({"seen": True}, synchronize_session=False)
            
        db.session.commit()
        invalidate_user_badges_cache(current_user.id)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/update_profile', methods=['POST'])
@login_required
def update_profile():
    try:
        try:
            from web.auth import CS_PIONEER_NAMES
        except ImportError:
            from auth import CS_PIONEER_NAMES

        data = request.get_json(silent=True) or {}
        if not data:
            return jsonify({'success': False, 'error': 'Données non fournies'}), 400
        
        name = (data.get('name') or '').strip()
        dob_str = data.get('date_of_birth')
        study_year = data.get('study_year')
        
        if not name or '#' not in name:
            return jsonify({'success': False, 'error': 'Le pseudo doit respecter le format NomPionnier#4Chiffres (ex: Turing#4821)'}), 400
            
        parts = name.split('#', 1)
        pioneer = parts[0].strip()
        digits = parts[1].strip()

        if pioneer not in CS_PIONEER_NAMES:
            return jsonify({'success': False, 'error': f"Le nom '{pioneer}' n'est pas dans la liste officielle des pionniers / concepts informatiques autorisés."}), 400

        if not re.match(r'^\d{4}$', digits):
            return jsonify({'success': False, 'error': 'Le code doit comporter exactement 4 chiffres numériques (ex: 4821)'}), 400

        final_name = f"{pioneer}#{digits}"

        # Check if name is taken by another user
        existing_user = User.query.filter(func.lower(User.name) == final_name.lower(), User.id != current_user.id).first()
        if existing_user:
            return jsonify({'success': False, 'error': f"Le pseudo '{final_name}' est déjà utilisé par un autre étudiant."}), 400
            
        current_user.name = final_name
        if study_year is not None:
            current_user.study_year = str(study_year).strip() if str(study_year).strip() else None
        
        if dob_str:
            try:
                from datetime import datetime as dt
                current_user.date_of_birth = dt.strptime(str(dob_str).strip(), '%Y-%m-%d').date()
            except ValueError:
                pass # Ignore invalid date format
        elif dob_str == '':
            current_user.date_of_birth = None
                
        db.session.commit()
        invalidate_global_user_stats_cache()
        invalidate_user_progress_cache(current_user.id)
        schedule_global_user_stats_refresh()
        
        return jsonify({
            'success': True,
            'message': 'Profil mis à jour avec succès',
            'name': final_name
        })
    except Exception as e:
        db.session.rollback()
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': f"Erreur serveur: {str(e)}"}), 500


@app.route('/api/users/<int:user_id>/card_profile', methods=['GET'])
def get_user_card_profile(user_id):
    try:
        user = db.session.get(User, user_id)
        if not user:
            return jsonify({'success': False, 'error': 'Utilisateur introuvable'}), 404

        global_user_stats = get_bulk_users_stats(allow_stale=True, refresh_async=True) or {}
        user_stats = global_user_stats.get(user_id, {})

        user_badges_raw = UserBadge.query.filter_by(user_id=user_id).order_by(UserBadge.awarded_at.desc()).all()
        quiz_attempts = QuizAttempt.query.filter_by(user_id=user_id).all()
        submissions = ChallengeSubmission.query.filter_by(user_id=user_id, passed=True).all()
        earned_badge_ids = {ub.badge_id for ub in user_badges_raw}

        xp_total, xp_breakdown, level_dict, xp_to_next = compute_xp_and_level(
            user_id,
            preloaded_quiz_attempts=quiz_attempts,
            preloaded_submissions=submissions,
            preloaded_badges=user_badges_raw
        )
        act_dates = [qa.timestamp for qa in quiz_attempts if qa.timestamp] + [sub.timestamp for sub in submissions if sub.timestamp]
        streak_info = compute_user_streak(user_id, preloaded_dates=act_dates)

        top1 = user_stats.get('top1', 0)
        top3 = user_stats.get('top3', 0)
        top10 = user_stats.get('top10', 0)

        titles_info = compute_unlocked_titles(
            user_id=user_id,
            xp=xp_total,
            level_num=level_dict.get('num', 1),
            top1_count=top1,
            streak_days=streak_info.get('current_streak', 0),
            preloaded_badges=earned_badge_ids,
            preloaded_equipped_title=user.equipped_title
        )
        badge_defs = get_badge_definitions()
        badges = []
        for ub in user_badges_raw:
            b_def = badge_defs.get(ub.badge_id, {
                'name': ub.badge_id,
                'desc': 'Succès débloqué',
                'icon': 'fas fa-medal',
                'category': 'achievement',
                'xp': 10,
                'difficulty': 'Easy'
            })
            badges.append({
                'id': ub.badge_id,
                'name': b_def['name'],
                'desc': b_def['desc'],
                'icon': b_def['icon'],
                'category': b_def.get('category', 'achievement'),
                'xp': b_def.get('xp', 10),
                'difficulty': b_def.get('difficulty', 'Easy'),
                'awarded_at': ub.awarded_at.isoformat() if ub.awarded_at else None
            })

        passed_challenges_count = len({sub.problem_id for sub in submissions if sub.problem_id is not None})
        passed_quizzes_count = user_stats.get('quizzes', 0)

        is_owner = current_user.is_authenticated and current_user.id == user_id

        bucket = compute_user_leaderboard_bucket(global_user_stats, user_id)
        prestige_badge = compute_user_prestige_badge(user_id, global_user_stats)

        return jsonify({
            'success': True,
            'card': {
                'user_id': user.id,
                'name': user.name,
                'study_year': user.study_year or 'Non spécifiée',
                'joined_year': user.created_at.year if user.created_at else None,
                'equipped_title': titles_info['equipped'],
                'equipped_titles': titles_info.get('equipped_titles', [titles_info['equipped']]),
                'unlocked_titles': titles_info['unlocked'] if is_owner else titles_info.get('equipped_titles', [titles_info['equipped']]),
                'is_owner': is_owner,
                'level': level_dict,
                'xp_total': xp_total,
                'xp_to_next': xp_to_next,
                'streak': streak_info,
                'global_rank': bucket.get('rank'),
                'total_ranked_users': bucket.get('total_users'),
                'percentile': bucket.get('top_percent'),
                'prestige_badge': prestige_badge,
                'stats': {
                    'top1': top1,
                    'top3': top3,
                    'top10': top10,
                    'challenges_completed': passed_challenges_count,
                    'quizzes_passed': passed_quizzes_count,
                    'score_pts': user_stats.get('score', 0)
                },
                'badges': badges
            }
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': f"Erreur serveur: {str(e)}"}), 500


@app.route('/api/user/title', methods=['POST'])
@login_required
def equip_user_title():
    data = request.get_json() or {}
    raw_titles = data.get('titles')
    if raw_titles is None and data.get('title'):
        raw_titles = [data.get('title')]

    if not isinstance(raw_titles, list) or not raw_titles:
        return jsonify({'success': False, 'error': 'Veuillez sélectionner au moins un titre.'}), 400

    clean_titles = [str(t).strip() for t in raw_titles if str(t).strip()]
    if not clean_titles:
        return jsonify({'success': False, 'error': 'Veuillez sélectionner au moins un titre.'}), 400
    if len(clean_titles) > 3:
        return jsonify({'success': False, 'error': 'Vous ne pouvez équiper que 3 titres maximum.'}), 400

    global_user_stats = get_bulk_users_stats(allow_stale=True)
    user_stats = global_user_stats.get(current_user.id, {})
    xp_total, _, level_dict, _ = compute_xp_and_level(current_user.id)
    streak_info = compute_user_streak(current_user.id)

    titles_info = compute_unlocked_titles(
        user_id=current_user.id,
        xp=xp_total,
        level_num=level_dict.get('num', 1),
        top1_count=user_stats.get('top1', 0),
        streak_days=streak_info.get('current_streak', 0)
    )

    for t in clean_titles:
        if t not in titles_info['unlocked']:
            return jsonify({'success': False, 'error': f"Le titre « {t} » n'est pas encore débloqué."}), 400

    current_user.equipped_title = json.dumps(clean_titles)
    db.session.commit()
    invalidate_user_progress_cache(current_user.id)
    invalidate_global_user_stats_cache()
    schedule_global_user_stats_refresh()

    return jsonify({
        'success': True,
        'equipped_title': clean_titles[0],
        'equipped_titles': clean_titles,
        'message': f"{len(clean_titles)} titre(s) équipé(s) avec succès !"
    })

@app.route('/api/challenge/<int:problem_id>/live')
def live_contest(problem_id):
    from web.models import ChallengeSubmission
    import datetime
    
    # Simplified real-time tracking: only consider submissions from the last 24 hours
    cutoff = datetime.datetime.utcnow() - datetime.timedelta(hours=24)
    from sqlalchemy.orm import joinedload
    submissions = ChallengeSubmission.query.options(joinedload(ChallengeSubmission.user)).filter(
        ChallengeSubmission.problem_id == problem_id,
        ChallengeSubmission.timestamp >= cutoff
    ).all()
    
    user_map = {}
    for s in submissions:
        uid = s.user_id
        if uid not in user_map:
            user_map[uid] = {
                'user': s.user,
                'attempts': 0,
                'best_score': 0,
                'passed': False,
                'best_time': 999999
            }
        
        entry = user_map[uid]
        entry['attempts'] += 1
        
        if s.score > entry['best_score']:
            entry['best_score'] = s.score
            entry['best_time'] = s.time_taken_seconds
            entry['passed'] = s.passed
        elif s.score == entry['best_score'] and s.time_taken_seconds < entry['best_time']:
            entry['best_time'] = s.time_taken_seconds

    results = []
    for uid, data in user_map.items():
        status = 'Échoué'
        if data['passed']:
            status = 'Réussi'
        elif data['best_score'] > 0:
            status = 'Partiel'
            
        results.append({
            'user_id': uid,
            'name': data['user'].name if data['user'] else f"User {uid}",
            'score': round(data['best_score'], 1),
            'time_taken': data['best_time'] if data['best_time'] != 999999 else 0,
            'attempts': data['attempts'],
            'status': status,
            'passed': data['passed']
        })
        
    results.sort(key=lambda x: (-x['score'], x['time_taken']))
    
    return jsonify({'success': True, 'leaderboard': results})


@app.route('/api/chat/message', methods=['POST'])
@login_required
def api_chat_message():
    import re
    from sqlalchemy import text
    data = request.get_json(silent=True) or {}
    text_content = data.get('text', '').strip()

    if not text_content:
        return jsonify({'success': False, 'error': 'Message text is required'}), 400

    # Strip HTML/script tags to prevent stored XSS in the chat (Fix #5)
    text_content = re.sub(r'<[^>]+>', '', text_content)
    if not text_content:
        return jsonify({'success': False, 'error': 'Message text is required'}), 400

    try:
        sql = text("INSERT INTO chat_messages (user_id, user_name, text) VALUES (:user_id, :user_name, :text)")
        db.session.execute(sql, {'user_id': current_user.id, 'user_name': current_user.name, 'text': text_content})
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        print(f">>> [ERROR] Error saving chat message: {e}", flush=True)
try:
    schedule_global_user_stats_refresh()
except Exception:
    pass


if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    debug_enabled = (not is_production) and os.environ.get('FLASK_DEBUG', '').lower() in ('1', 'true', 'yes', 'on')
    host = '127.0.0.1' if debug_enabled else '0.0.0.0'
    app.run(debug=debug_enabled, host=host, port=port, use_reloader=debug_enabled)
