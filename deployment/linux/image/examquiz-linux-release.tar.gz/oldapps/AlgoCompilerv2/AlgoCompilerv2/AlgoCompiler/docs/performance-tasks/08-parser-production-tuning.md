# 08. Parser Production Tuning

Status: `pending`
Priority: `medium`

## Goal
Reduce parser startup and compile-path overhead in production.

## Why
The parser is currently built with debug enabled, which is not a production setting.

## Scope
- Disable parser debug in production
- Confirm parser tables are reused correctly
- Avoid unnecessary startup work on Render

## Validation
- Startup and first compile path improve.
