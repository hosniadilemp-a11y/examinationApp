import sys
import os
import subprocess

files = [
    "../Exos/01_rotation_anneaux_matrice.algo",
    "../Exos/02_adn_equilibre_steady_bear.algo",
    "../Exos/03_filtre_median_debruitage.algo",
    "../Exos/04_triplets_magnifiques.algo"
]

all_passed = True
for f in files:
    print(f"\n=================== RUNNING {f} ===================")
    res = subprocess.run([sys.executable, "tests/test_and_run_algo.py", f], capture_output=True, text=True)
    print(res.stdout)
    if res.returncode != 0:
        print("FAILED!")
        print(res.stderr)
        all_passed = False
    else:
        print("PASSED (Code 0)")

if all_passed:
    print("\nALL 4 ALGO FILES COMPILED AND EXECUTED SUCCESSFULLY!")
else:
    print("\nSOME ALGO FILES FAILED!")
    sys.exit(1)
