# 03. Precompute Global Stats

Status: `partial`
Priority: `critical`

## Goal
Replace repeated in-request full-table Python aggregation with precomputed stats.

## Why
Bulk global computations become slower as users, submissions, and quiz attempts grow.

## Scope
- Global XP leaderboard stats
- Per-user placement counters
- Cached ranking buckets

## Implementation outline
1. Create a scheduled or on-demand snapshot builder.
2. Store compact derived stats in memory cache or a dedicated table.
3. Refresh snapshots after relevant writes or on a cadence.

## Validation
- Progress and leaderboard endpoints stop scanning entire tables on every request.

## Progress so far
- Added an in-process TTL cache for global per-user stats used by progress and leaderboard reads.
- Added invalidation on quiz save, submission save, and profile updates so repeated reads no longer recompute every time.
- Reduced leaderboard snapshot reads to the columns actually needed instead of loading full ORM rows.
- Added a lightweight fallback leaderboard path so the page can render while richer stats are still refreshing.

## Remaining work
- Replace the read-time full-table rebuild with an explicit snapshot builder.
- Move snapshot refresh to a cadence or background refresh path instead of rebuilding on cache miss.
