import sys
import os

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from compiler.parser import compile_algo

def test_file(algo_path):
    print(f"=== Testing: {algo_path} ===")
    with open(algo_path, 'r', encoding='utf-8') as f:
        code = f.read()

    res = compile_algo(code)
    errors = None
    py_code = None
    if isinstance(res, tuple):
        py_code, errors = res
    else:
        py_code = res

    if errors:
        print("COMPILATION FAILED:")
        for err in errors:
            print(f"  {err}")
        return False

    print("COMPILATION SUCCESS.")
    print("--- Executing generated Python code ---")
    try:
        # Create a fresh global dict
        env = {}
        exec(py_code, env)
        print("--- Execution finished successfully ---\n")
        return True
    except Exception as e:
        import traceback
        print("RUNTIME ERROR:")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    if len(sys.argv) > 1:
        success = test_file(sys.argv[1])
        sys.exit(0 if success else 1)
    else:
        print("Usage: python test_and_run_algo.py <algo_file>")
