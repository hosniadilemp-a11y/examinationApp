import subprocess
import os

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
html_url = "file:///" + os.path.abspath("Exos/index.html").replace("\\", "/")

cmd = [
    chrome_path,
    "--headless=new",
    "--disable-gpu",
    "--dump-dom",
    html_url
]

res = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore')
print(f"Return code: {res.returncode}")
print(f"Stdout length: {len(res.stdout)}")
if len(res.stdout) > 0:
    print(f"Contains 'katex-html': {'katex-html' in res.stdout}")
    print(f"Contains 'katex': {'katex' in res.stdout}")
    print(f"Contains 'matrix-grid-elem': {'matrix-grid-elem' in res.stdout}")
if res.stderr:
    print(f"Stderr (first 300 chars): {res.stderr[:300]}")
