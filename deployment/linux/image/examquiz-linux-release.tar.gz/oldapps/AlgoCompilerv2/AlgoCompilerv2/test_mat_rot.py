# Test matrix rotation algorithms
def get_matrix(R, C):
    val = 1
    m = []
    for i in range(R):
        m.append(list(range(val, val + C)))
        val += C
    return m

def print_mat(m):
    for r in m:
        print([f"{x:2d}" for x in r])

def step_anti(m, R, C):
    import copy
    m = copy.deepcopy(m)
    numRings = min(R, C) // 2
    for k in range(numRings):
        temp = m[k][k]
        for j in range(k, C - 1 - k):
            m[k][j] = m[k][j + 1]
        for i in range(k, R - 1 - k):
            m[i][C - 1 - k] = m[i + 1][C - 1 - k]
        for j in range(C - 1 - k, k, -1):
            m[R - 1 - k][j] = m[R - 1 - k][j - 1]
        for i in range(R - 1 - k, k + 1, -1):
            m[i][k] = m[i - 1][k]
        m[k + 1][k] = temp
    return m

def step_clock(m, R, C):
    import copy
    m = copy.deepcopy(m)
    numRings = min(R, C) // 2
    for k in range(numRings):
        temp = m[k][k]
        for i in range(k, R - 1 - k):
            m[i][k] = m[i + 1][k]
        for j in range(k, C - 1 - k):
            m[R - 1 - k][j] = m[R - 1 - k][j + 1]
        for i in range(R - 1 - k, k, -1):
            m[i][C - 1 - k] = m[i - 1][C - 1 - k]
        for j in range(C - 1 - k, k + 1, -1):
            m[k][j] = m[k][j - 1]
        m[k][k + 1] = temp
    return m

m0 = get_matrix(4, 4)
print("Initial 4x4:")
print_mat(m0)
m1 = step_anti(m0, 4, 4)
print("\nAfter 1 step Anti-clockwise:")
print_mat(m1)
m2 = step_anti(m1, 4, 4)
print("\nAfter 2 steps Anti-clockwise:")
print_mat(m2)
m_back = step_clock(m1, 4, 4)
print("\nAfter 1 anti + 1 clock (should equal m0):")
print_mat(m_back)
assert m_back == m0, f"Clockwise did not invert anti-clockwise! {m_back} != {m0}"
print("ASSERTION PASSED: clock inverts anti!")

# Test on 6x4 (non-square)
m_rect = get_matrix(6, 4)
m_rect_1 = step_anti(m_rect, 6, 4)
m_rect_back = step_clock(m_rect_1, 6, 4)
assert m_rect_back == m_rect, "Non-square clock failed to invert anti!"
print("ASSERTION PASSED: non-square 6x4 clock inverts anti!")
