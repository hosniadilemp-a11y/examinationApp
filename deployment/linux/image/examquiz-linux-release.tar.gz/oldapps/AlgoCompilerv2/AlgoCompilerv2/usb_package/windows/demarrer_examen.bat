@echo off
chcp 65001 > nul
title AlgoExamination - Serveur Local d'Examen

echo =====================================================
echo    AlgoExamination — Lancement du Serveur d'Examen
echo =====================================================

cd /d "%~dp0"

REM 1. Charger les images si le fichier tar.gz est présent
if exist "algoexam_images.tar.gz" (
    echo Chargement des images Docker depuis l'archive locale...
    docker load -i algoexam_images.tar.gz
)

REM 2. Démarrer les services Docker
echo Demarrage des conteneurs...
docker compose up -d

REM 3. Recuperer l'adresse IP locale
for /f "tokens=4" %%a in ('route print ^| findstr 0.0.0.0 ^| findstr /v "127.0.0.1"') do (
    set LOCAL_IP=%%a
    goto :ip_found
)
:ip_found

echo.
echo =====================================================
echo ✔ SERVEUR D'EXAMEN PRÊT ^& OPÉRATIONNEL !
echo =====================================================
echo.
echo 👨‍🎓 ACCÈS ÉTUDIANTS (Sur leurs PC de salle) :
if defined LOCAL_IP (
    echo    👉 http://%LOCAL_IP%
) else (
    echo    👉 http://ADRESSE_IP_DU_PC
)
echo    (Aucun numéro de port à saisir pour les étudiants)
echo.
echo 👨‍🏫 ACCÈS ENSEIGNANT / SURVEILLANCE :
echo    👉 http://localhost:5175
echo    Identifiants : teacher@esi.dz / admin123
echo =====================================================
echo.
echo Ouverture automatique de votre interface enseignant...
start http://localhost:5175
pause
