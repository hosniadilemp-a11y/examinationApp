@echo off
chcp 65001 > nul
echo Arret des services d'examen...
docker compose down
echo.
echo ✔ Services arretes proprement. Vos donnees d'examen sont conservees en securite.
pause
