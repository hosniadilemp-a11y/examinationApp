@echo off
chcp 65001 > nul
title AlgoExamination - Mise à Jour Sécurisée

echo =====================================================
echo    AlgoExamination — Mise à Jour Sans Perte
echo =====================================================

cd /d "%~dp0"

if not exist "algoexam_images.tar.gz" (
    echo ❌ Erreur : Fichier 'algoexam_images.tar.gz' introuvable.
    echo Veuillez copier le fichier de mise a jour fourni depuis votre cle USB.
    pause
    exit /b 1
)

echo 1. Chargement de la nouvelle image applicative...
docker load -i algoexam_images.tar.gz

echo 2. Redemarrage des conteneurs avec le nouveau code...
docker compose down
docker compose up -d

echo.
echo =====================================================
echo ✔ MISE À JOUR TERMINÉE AVEC SUCCÈS !
echo ✔ Base de données et copies existantes 100%% conservées !
echo =====================================================
pause
