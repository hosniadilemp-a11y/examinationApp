const prisma = require('./prisma');
const bcrypt = require('bcryptjs');

async function main() {
  console.log('Seeding AlgoExamination database...');

  // 1. Create Default Teacher
  const hashedPassword = await bcrypt.hash('admin123', 10);
  const teacher = await prisma.teacher.upsert({
    where: { email: 'teacher@algoexam.edu' },
    update: { password: hashedPassword },
    create: {
      email: 'teacher@algoexam.edu',
      name: 'Prof. Mohamed BENAMARA',
      password: hashedPassword,
      role: 'ADMIN'
    }
  });
  console.log(`Teacher created/updated: ${teacher.email}`);

  // 2. Create Sample Students
  const sampleStudents = [
    { studentId: '2026001', firstName: 'Ahmed', lastName: 'BENALI', group: 'G1', speciality: 'Computer Science' },
    { studentId: '2026002', firstName: 'Sara', lastName: 'KHELIFI', group: 'G1', speciality: 'Computer Science' },
    { studentId: '2026003', firstName: 'Ali', lastName: 'AMRANE', group: 'G2', speciality: 'Software Engineering' },
    { studentId: '2026004', firstName: 'Yasmine', lastName: 'BOUMEDIENE', group: 'G2', speciality: 'Software Engineering' },
    { studentId: '2026005', firstName: 'Karim', lastName: 'HAMDI', group: 'G3', speciality: 'Artificial Intelligence' }
  ];

  for (const s of sampleStudents) {
    await prisma.student.upsert({
      where: { studentId: s.studentId },
      update: s,
      create: s
    });
  }
  console.log(`Created ${sampleStudents.length} sample students`);

  // 3. Create Starter Problems
  const problem1 = await prisma.problem.create({
    data: {
      title: 'Somme de Deux Entiers',
      topic: 'Basics',
      difficulty: 'Easy',
      description: `### Objectif
Écrire un algorithme qui lit deux entiers \`A\` et \`B\` puis affiche leur somme.

#### Format d'entrée
- Ligne 1: premier entier \`A\`
- Ligne 2: deuxième entier \`B\`

#### Format de sortie
- Affiche la valeur de \`A + B\``,
      templateCode: {
        ALGO: `Algorithme SommeDeuxEntiers;
Var
    A, B, S : Entier;
Debut
    Lire(A);
    Lire(B);
    S := A + B;
    Ecrire(S);
Fin.`,
        PYTHON: `A = int(input())
B = int(input())
print(A + B)`
      },
      testCases: {
        create: [
          { inputData: '5\n10', expectedOutput: '15', isPublic: true },
          { inputData: '-3\n7', expectedOutput: '4', isPublic: true },
          { inputData: '100\n200', expectedOutput: '300', isPublic: false }
        ]
      }
    }
  });

  const problem2 = await prisma.problem.create({
    data: {
      title: 'Maximum d\'un Tableau',
      topic: 'Arrays',
      difficulty: 'Medium',
      description: `### Objectif
Écrire un algorithme qui lit la taille \`N\` d'un tableau, puis les \`N\` éléments du tableau, et enfin affiche la plus grande valeur.

#### Format d'entrée
- Ligne 1: \`N\` (taille du tableau)
- Lignes suivantes: \`N\` entiers

#### Format de sortie
- La valeur maximale contenue dans le tableau.`,
      templateCode: {
        ALGO: `Algorithme MaxTableau;
Var
    N, i, val, maxVal : Entier;
Debut
    Lire(N);
    Lire(maxVal);
    Pour i := 2 a N Faire
        Lire(val);
        Si (val > maxVal) Alors
            maxVal := val;
        Fin Si;
    Fin Pour;
    Ecrire(maxVal);
Fin.`,
        PYTHON: `N = int(input())
arr = [int(input()) for _ in range(N)]
print(max(arr))`
      },
      testCases: {
        create: [
          { inputData: '4\n12\n5\n28\n14', expectedOutput: '28', isPublic: true },
          { inputData: '3\n-5\n-1\n-10', expectedOutput: '-1', isPublic: true },
          { inputData: '1\n42', expectedOutput: '42', isPublic: false }
        ]
      }
    }
  });

  // 4. Create Sample Examination
  const exam = await prisma.exam.create({
    data: {
      title: 'Examen de Remplacement — Algorithmique (Midterm)',
      description: 'Examen pratique d\'algorithmique en environnement contrôlé.',
      durationMinutes: 90,
      prefix: 'AL2026',
      status: 'SCHEDULED',
      teacherId: teacher.id,
      maxViolationsAllowed: 4,
      copyDisabled: true,
      pasteDisabled: true,
      fullscreenRequired: true,
      allowedLanguages: ['ALGO']
    }
  });

  // Attach problems to exam
  await prisma.examProblem.createMany({
    data: [
      { examId: exam.id, problemId: problem1.id, orderIndex: 1, points: 10 },
      { examId: exam.id, problemId: problem2.id, orderIndex: 2, points: 20 }
    ]
  });

  // Assign sample students & generate access numbers (e.g. AL20260001, AL20260002)
  const students = await prisma.student.findMany();
  let seq = 1;
  for (const s of students) {
    const accessNumber = `AL2026${String(seq).padStart(4, '0')}`;
    seq++;

    await prisma.examAssignment.create({
      data: {
        examId: exam.id,
        studentId: s.id,
        accessNumber,
        status: 'NOT_ENTERED'
      }
    });
  }

  console.log('Seeding completed successfully!');
  console.log(`Sample Exam created: "${exam.title}" (ID: ${exam.id})`);
  console.log('Sample Access Numbers: AL20260001, AL20260002, AL20260003');
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
