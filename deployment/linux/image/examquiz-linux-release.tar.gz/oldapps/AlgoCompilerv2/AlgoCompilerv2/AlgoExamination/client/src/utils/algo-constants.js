// 10 Official AlgoCompiler Course Chapters
export const ALGO_CHAPTERS = [
  { id: 'CH1', title: "Chapitre 1: Introduction à l'Algorithmique", badge: "Bases & I/O" },
  { id: 'CH2', title: "Chapitre 2: Tableaux et Matrices", badge: "Tableaux & Matrices" },
  { id: 'CH3', title: "Chapitre 3: Chaînes de Caractères", badge: "Chaînes & Mots" },
  { id: 'CH4', title: "Chapitre 4: Allocation Dynamique", badge: "Pointeurs & Mémoire" },
  { id: 'CH5', title: "Chapitre 5: Actions Paramétrées (Fonctions & Procédures)", badge: "Sous-Programmes" },
  { id: 'CH6', title: "Chapitre 6: Les Enregistrements", badge: "Structures (Records)" },
  { id: 'CH7', title: "Chapitre 7: Les Fichiers", badge: "E/S Fichiers" },
  { id: 'CH8', title: "Chapitre 8: Les Listes Chaînées", badge: "Listes Dynamiques" },
  { id: 'CH9', title: "Chapitre 9: Les Piles (Stacks)", badge: "Piles LIFO" },
  { id: 'CH10', title: "Chapitre 10: Les Files (Queues)", badge: "Files FIFO" },
];

// 100% AlgoCompiler-Compliant Code Bricks Catalog
export const COMPREHENSIVE_CODE_BRICKS = [
  // Chapter 1: Base & I/O
  { id: 'CH1_STRUCT', chapterId: 'CH1', chapterTitle: "Chapitre 1: Base & I/O", label: '📄 Squelette ALGO', snippet: 'ALGORITHME Exercice_Base;\nVAR\n   n, i : ENTIER;\nDEBUT\n   LIRE(n);\n   ECRIRE(n);\nFIN.' },
  { id: 'CH1_SAISIE', chapterId: 'CH1', chapterTitle: "Chapitre 1: Base & I/O", label: '🔁 Saisie Sécurisée (REPETER)', snippet: 'REPETER\n   ECRIRE("Saisir un nombre:");\n   LIRE(n);\nJUSQUA (n > 0);' },
  { id: 'CH1_PERMUT', chapterId: 'CH1', chapterTitle: "Chapitre 1: Base & I/O", label: '🔄 Permutation Variables', snippet: 'tmp := a;\na := b;\nb := tmp;' },

  // Chapter 2: Tableaux & Matrices
  { id: 'CH2_LIRE_1D', chapterId: 'CH2', chapterTitle: "Chapitre 2: Tableaux & Matrices", label: '📥 Lire Tableau 1D', snippet: 'POUR i := 1 A n FAIRE\n   LIRE(T[i]);\nFINPOUR;' },
  { id: 'CH2_ECRIRE_1D', chapterId: 'CH2', chapterTitle: "Chapitre 2: Tableaux & Matrices", label: '📤 Afficher Tableau 1D', snippet: 'POUR i := 1 A n FAIRE\n   ECRIRE(T[i]);\nFINPOUR;' },
  { id: 'CH2_MAX_MIN', chapterId: 'CH2', chapterTitle: "Chapitre 2: Tableaux & Matrices", label: '⚡ Max Tableau', snippet: 'maxVal := T[1];\nPOUR i := 2 A n FAIRE\n   SI T[i] > maxVal ALORS\n      maxVal := T[i];\n   FINSI;\nFINPOUR;' },
  { id: 'CH2_LIRE_2D', chapterId: 'CH2', chapterTitle: "Chapitre 2: Tableaux & Matrices", label: '🔲 Lire Matrice 2D', snippet: 'POUR i := 1 A n FAIRE\n   POUR j := 1 A m FAIRE\n      LIRE(M[i, j]);\n   FINPOUR;\nFINPOUR;' },
  { id: 'CH2_TRI_BULLES', chapterId: 'CH2', chapterTitle: "Chapitre 2: Tableaux & Matrices", label: '📊 Tri à Bulles', snippet: 'POUR i := 1 A n - 1 FAIRE\n   POUR j := 1 A n - i FAIRE\n      SI T[j] > T[j+1] ALORS\n         tmp := T[j];\n         T[j] := T[j+1];\n         T[j+1] := tmp;\n      FINSI;\n   FINPOUR;\nFINPOUR;' },

  // Chapter 3: Chaînes de Caractères
  { id: 'CH3_LEN', chapterId: 'CH3', chapterTitle: "Chapitre 3: Chaînes", label: '📏 Longueur de Chaîne (LONGUEUR)', snippet: 'taille := LONGUEUR(ch);' },
  { id: 'CH3_CONCAT', chapterId: 'CH3', chapterTitle: "Chapitre 3: Chaînes", label: '🔗 Concaténation (CONCAT)', snippet: 'chRes := CONCAT(ch1, ch2);' },
  { id: 'CH3_ASCII', chapterId: 'CH3', chapterTitle: "Chapitre 3: Chaînes", label: '🔢 Code ASCII Caractère', snippet: 'codeAscii := ASCII(\'A\');' },
  { id: 'CH3_INV', chapterId: 'CH3', chapterTitle: "Chapitre 3: Chaînes", label: '🔄 Inverser Chaîne', snippet: 'chInv := "";\nPOUR i := LONGUEUR(ch) A 1 FAIRE\n   chInv := CONCAT(chInv, ch[i]);\nFINPOUR;' },

  // Chapter 4: Allocation Dynamique
  { id: 'CH4_ALLOUER', chapterId: 'CH4', chapterTitle: "Chapitre 4: Allocation Dynamique", label: '📌 Allouer Mémoire (ALLOUER)', snippet: 'p := ALLOUER(10);' },
  { id: 'CH4_ALLOUER_STRUCT', chapterId: 'CH4', chapterTitle: "Chapitre 4: Allocation Dynamique", label: '🔳 Allouer Structure (TAILLE)', snippet: 'p := ALLOUER(taille(Noeud));' },
  { id: 'CH4_LIBERER', chapterId: 'CH4', chapterTitle: "Chapitre 4: Allocation Dynamique", label: '🗑️ Libérer Pointeur (LIBERER)', snippet: 'LIBERER(p);' },

  // Chapter 5: Actions Paramétrées
  { id: 'CH5_FONC', chapterId: 'CH5', chapterTitle: "Chapitre 5: Actions Paramétrées", label: '⚙️ Déclaration Fonction ALGO', snippet: 'Fonction CalculerSomme(a, b : Entier) : Entier;\nVar\n   res : Entier;\nDebut\n   res := a + b;\n   Retourner res;\nFin;' },
  { id: 'CH5_PROC', chapterId: 'CH5', chapterTitle: "Chapitre 5: Actions Paramétrées", label: '🛠️ Procédure avec VAR', snippet: 'Procedure PermuterVal(VAR x, y : Entier);\nVar\n   tmp : Entier;\nDebut\n   tmp := x;\n   x := y;\n   y := tmp;\nFin;' },

  // Chapter 6: Les Enregistrements
  { id: 'CH6_STRUCT', chapterId: 'CH6', chapterTitle: "Chapitre 6: Enregistrements", label: '📦 Déclaration Enregistrement', snippet: 'Type Etudiant = Enregistrement\n   nom : Chaine;\n   age : Entier;\nFin;' },
  { id: 'CH6_USAGE', chapterId: 'CH6', chapterTitle: "Chapitre 6: Enregistrements", label: '📋 Accès Champs Enregistrement', snippet: 'e.nom := "Alice";\ne.age := 20;' },

  // Chapter 7: Les Fichiers (E/S Fichiers & Open File)
  { id: 'CH7_OPEN_READ', chapterId: 'CH7', chapterTitle: "Chapitre 7: Les Fichiers", label: '📂 Ouvrir Fichier (Lecture)', snippet: 'OUVRIR(f, "donnees.txt", "LECTURE");' },
  { id: 'CH7_OPEN_WRITE', chapterId: 'CH7', chapterTitle: "Chapitre 7: Les Fichiers", label: '💾 Ouvrir Fichier (Écriture)', snippet: 'OUVRIR(f, "resultat.txt", "ECRITURE");' },
  { id: 'CH7_READ_LINE', chapterId: 'CH7', chapterTitle: "Chapitre 7: Les Fichiers", label: '📖 Lire Fichier (LIRE_FICHIER)', snippet: 'LIRE_FICHIER(f, val);' },
  { id: 'CH7_WRITE_LINE', chapterId: 'CH7', chapterTitle: "Chapitre 7: Les Fichiers", label: '✍️ Écrire Fichier (ECRIRE_FICHIER)', snippet: 'ECRIRE_FICHIER(f, val);' },
  { id: 'CH7_CLOSE', chapterId: 'CH7', chapterTitle: "Chapitre 7: Les Fichiers", label: '🔒 Fermer Fichier (FERMER)', snippet: 'FERMER(f);' },

  // Chapter 8: Les Listes Chaînées
  { id: 'CH8_NODE', chapterId: 'CH8', chapterTitle: "Chapitre 8: Listes Chaînées", label: '🔗 Déclaration Nœud Liste', snippet: 'Type Noeud = Enregistrement\n   valeur : Entier;\n   suivant : ^Noeud;\nFin;' },
  { id: 'CH8_ADD_HEAD', chapterId: 'CH8', chapterTitle: "Chapitre 8: Listes Chaînées", label: '⬆️ Insertion Tête de Liste', snippet: 'nouveau := ALLOUER(taille(Noeud));\nnouveau^.valeur := val;\nnouveau^.suivant := tete;\ntete := nouveau;' },
  { id: 'CH8_TRAVERSE', chapterId: 'CH8', chapterTitle: "Chapitre 8: Listes Chaînées", label: '🚶 Parcours Liste (NIL)', snippet: 'curr := tete;\nTANTQUE curr <> NIL FAIRE\n   ECRIRE(curr^.valeur);\n   curr := curr^.suivant;\nFINTANTQUE;' },

  // Chapter 9: Les Piles (Stacks)
  { id: 'CH9_STRUCT_PILE', chapterId: 'CH9', chapterTitle: "Chapitre 9: Les Piles", label: '📚 Structure Pile (Stack)', snippet: 'Type Pile = Enregistrement\n   elements : Tableau[1..100] De Entier;\n   sommet : Entier;\nFin;' },
  { id: 'CH9_EMPILER', chapterId: 'CH9', chapterTitle: "Chapitre 9: Les Piles", label: '📥 Procédure Empiler', snippet: 'Procedure Empiler(VAR P : Pile; val : Entier);\nDebut\n   SI P.sommet < 100 ALORS\n      P.sommet := P.sommet + 1;\n      P.elements[P.sommet] := val;\n   FINSI;\nFin;' },

  // Chapter 10: Les Files (Queues)
  { id: 'CH10_STRUCT_FILE', chapterId: 'CH10', chapterTitle: "Chapitre 10: Les Files", label: '🎟️ Structure File (Queue)', snippet: 'Type File = Enregistrement\n   elements : Tableau[1..100] De Entier;\n   tete, queue : Entier;\nFin;' },
  { id: 'CH10_ENFILER', chapterId: 'CH10', chapterTitle: "Chapitre 10: Les Files", label: '➡️ Procédure Enfiler', snippet: 'Procedure Enfiler(VAR F : File; val : Entier);\nDebut\n   F.queue := F.queue + 1;\n   F.elements[F.queue] := val;\nFin;' }
];

// Markdown Templates Catalog
export const MARKDOWN_TEMPLATES = [
  {
    id: 'STANDARD',
    label: '📋 Modèle Standard (Entrée / Sortie)',
    template: `## 🎯 Objectif ##
Écrire un algorithme permettant de résoudre le problème demandé en respectant scrupuleusement la syntaxe \`ALGO\`.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`N\` (ENTIER) — Taille des données.
- **Lignes suivantes** : Données saisies sur la sortie standard.

### 📤 Sorties Attendues (STDOUT) ###
- Afficher le résultat calculé sur la sortie standard.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
5
10 20 30 40 50
\`\`\`

**Sortie Attendue :**
\`\`\`
50
\`\`\`

### ⚠️ Contraintes & Remarques ###
- $1 \\le N \\le 1000$
- Conserver scrupuleusement la structure des blocs \`VAR\`, \`DEBUT\` et \`FIN.\`.`
  },
  {
    id: 'MATRICES',
    label: '🔲 Modèle Tableaux & Matrices',
    template: `## 🎯 Objectif ##
Écrire un algorithme qui effectue un traitement sur une matrice $N \\times M$ d'entiers.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`N\` et \`M\` (ENTIERS) — Nombre de lignes et de colonnes.
- **Lignes 2..N+1** : Éléments de la matrice $N \\times M$.

### 📤 Sorties Attendues (STDOUT) ###
- Afficher la matrice résultat ou la somme calculée.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
2 3
1 2 3
4 5 6
\`\`\`

**Sortie Attendue :**
\`\`\`
21
\`\`\``
  },
  {
    id: 'STRINGS',
    label: '🔠 Modèle Traitement de Chaînes',
    template: `## 🎯 Objectif ##
Écrire un algorithme qui lit une chaîne de caractères \`CH\` et affiche la transformation demandée.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`CH\` (CHAINE) — Chaîne d'entrée.

### 📤 Sorties Attendues (STDOUT) ###
- Afficher la chaîne modifiée ou le comptage.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
AlgoCompiler
\`\`\`

**Sortie Attendue :**
\`\`\`
12
\`\`\``
  },
  {
    id: 'DATA_STRUCTURES',
    label: '📚 Modèle Structures de Données (Piles / Files / Listes)',
    template: `## 🎯 Objectif ##
Implémenter la gestion d'une structure de données dynamique (\`Pile\`, \`File\`, ou \`Liste Chaînée\`).

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`N\` (ENTIER) — Nombre d'éléments insérés.
- **Ligne 2** : Valeurs des éléments.

### 📤 Sorties Attendues (STDOUT) ###
- Afficher l'état final de la structure ou la valeur extraite.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
3
10 20 30
\`\`\`

**Sortie Attendue :**
\`\`\`
30 20 10
\`\`\``
  }
];
