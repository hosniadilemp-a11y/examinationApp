import React, { useState, useEffect } from 'react';
import {
  getExamResults,
  downloadAllStudentPDFBlob,
  downloadStudentPDFBlob,
  exportExamResults,
  importExamResults
} from '../services/api';
import { getSystemVaultKey } from './SystemSettingsModal';
import { getSocket, joinExamRoom } from '../services/socket';
import {
  ArrowLeft, Download, Trophy, Clock, Users, ShieldAlert,
  CheckCircle, XCircle, AlertCircle, BarChart2, TrendingUp, RefreshCw,
  FileText, Package, Upload, Lock, Eye, Check
} from 'lucide-react';
import Swal from 'sweetalert2';

export default function ExamResults({ examId, examTitle, onBack }) {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);
  const [search, setSearch]   = useState('');
  const [sortCol, setSortCol] = useState('score'); // 'score' | 'name' | 'code' | 'time' | 'violations'
  const [sortAsc, setSortAsc] = useState(false);
  const [isDownloadingPDF, setIsDownloadingPDF] = useState(false);
  const [downloadingStudentId, setDownloadingStudentId] = useState(null);
  const [zipProgress, setZipProgress] = useState(null);

  const loadResults = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getExamResults(examId);
      setData(res);
    } catch (err) {
      console.error('Failed to load exam results:', err);
      setError(err.data?.error || err.message || 'Erreur lors du chargement des résultats');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadResults();
  }, [examId]);

  // Download single student copy PDF
  const handleDownloadSinglePDF = async (studentId, lastName, firstName, accessNumber) => {
    if (downloadingStudentId) return;
    setDownloadingStudentId(studentId);
    try {
      const blob = await downloadStudentPDFBlob(examId, studentId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const safeName = `${(lastName || 'ETUDIANT').replace(/[^\w]/g, '_')}_${(firstName || '').replace(/[^\w]/g, '_')}_${(accessNumber || '').replace(/[^\w]/g, '_')}`;
      a.download = `Copie_${safeName}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      console.error('Single PDF error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Téléchargement PDF',
        text: 'Impossible de télécharger la copie PDF de cet étudiant.',
        background: '#111827', color: '#fff'
      });
    } finally {
      setDownloadingStudentId(null);
    }
  };

  // Download all copies as ZIP with live progress
  const handleDownloadAllPDFsZIP = async () => {
    if (isDownloadingPDF) return;
    setIsDownloadingPDF(true);
    setZipProgress({ done: 0, total: 0, studentName: '', status: 'start' });

    const socket = getSocket();
    joinExamRoom(examId, null, true);

    const onProgress = (payload) => {
      setZipProgress(payload);
      if (payload.status === 'done') socket.off('pdf_zip_progress', onProgress);
    };
    socket.on('pdf_zip_progress', onProgress);

    try {
      const blob = await downloadAllStudentPDFBlob(examId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Copies_${(data?.exam?.title || examTitle || 'Examen').replace(/[^\w]/g, '_')}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('All PDFs ZIP Error:', err);
      socket.off('pdf_zip_progress', onProgress);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Téléchargement ZIP',
        text: 'Impossible de générer le ZIP des copies.',
        background: '#111827', color: '#fff'
      });
    } finally {
      setIsDownloadingPDF(false);
      setTimeout(() => setZipProgress(null), 2500);
    }
  };

  // Export Encrypted Results (.algoresults) — Zero-prompt 1-click export
  const handleExportEncryptedResults = async () => {
    try {
      const vaultKey = getSystemVaultKey();
      const encryptedData = await exportExamResults(examId, vaultKey);
      const jsonStr = JSON.stringify(encryptedData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Resultats_Officiels_${(data?.exam?.title || 'Examen').replace(/[^\w]/g, '_')}.algoresults`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: '🔒 Résultats Exportés !',
        text: 'Le fichier chiffré .algoresults a été téléchargé avec succès (AES-256-GCM automatique).',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export results error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Impossible d’exporter les résultats.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Import Encrypted Results (.algoresults) — Simple file selection
  const handleImportEncryptedResults = async () => {
    const { value: formValues } = await Swal.fire({
      title: '📥 Importer des Résultats Externes (.algoresults)',
      html: `
        <div style="text-align: left; font-size: 0.88rem; color: #cbd5e1; display: flex; flex-direction: column; gap: 12px;">
          <div>
            <label style="display: block; margin-bottom: 4px; font-weight: bold;">Sélectionner le fichier .algoresults :</label>
            <input type="file" id="swal-results-file" accept=".algoresults,.json" style="width: 100%; font-size: 0.82rem; background: #0f172a; padding: 8px; border: 1px solid #334155; border-radius: 4px; color: #fff;" />
          </div>
          <div>
            <label style="display: block; margin-bottom: 4px; font-size: 0.78rem; color: #94a3b8;">Mot de passe personnalisé (optionnel, laissez vide si standard) :</label>
            <input type="password" id="swal-results-passphrase" placeholder="Optionnel (Déchiffrement auto par défaut)" style="width: 100%; font-size: 0.82rem; background: #0f172a; padding: 6px; border: 1px solid #334155; border-radius: 4px; color: #fff;" />
          </div>
        </div>
      `,
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: 'Importer & Synchroniser',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff',
      preConfirm: () => {
        const fileInput = document.getElementById('swal-results-file');
        const passInput = document.getElementById('swal-results-passphrase');
        if (!fileInput.files || fileInput.files.length === 0) {
          Swal.showValidationMessage('Veuillez sélectionner un fichier .algoresults');
          return false;
        }
        return { file: fileInput.files[0], passphrase: passInput.value.trim() };
      }
    });

    if (!formValues) return;

    try {
      const vaultKey = getSystemVaultKey();
      const formData = new FormData();
      formData.append('results', formValues.file);
      formData.append('passphrase', formValues.passphrase || vaultKey);

      const res = await importExamResults(examId, formData);
      Swal.fire({
        icon: 'success',
        title: 'Résultats Synchronisés !',
        text: res.message || 'Les notes ont été mises à jour avec succès.',
        background: '#111827',
        color: '#fff'
      });
      loadResults();
    } catch (err) {
      console.error('Import results error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Importation',
        text: err.message || 'Échec du déchiffrement ou de l’importation.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const formatDuration = (ms) => {
    if (!ms || ms < 0) return '—';
    const totalSecs = Math.floor(ms / 1000);
    const h = Math.floor(totalSecs / 3600);
    const m = Math.floor((totalSecs % 3600) / 60);
    const s = totalSecs % 60;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  };

  const exportCSV = () => {
    if (!data || !data.studentRows) return;
    const { problems, studentRows } = data;

    const headers = [
      'Code Anonyme',
      'Matricule',
      'Nom',
      'Prénom',
      'Groupe',
      'Spécialité',
      'Statut Exam',
      'Statut Correction',
      'Note Finale /20',
      'Mention',
      'Score Total (%)',
      'Points Gagnés',
      'Points Max',
      'Tests Passés',
      'Temps (min)',
      'Violations',
      ...problems.map(p => `P: ${p.title} (Pts)`)
    ];

    const rows = studentRows.map(s => {
      const timeMins = s.timeTakenMs ? (s.timeTakenMs / 60000).toFixed(1) : '';
      const probScores = s.problemScores.map(ps => `${ps.earnedPoints}/${ps.maxPoints}`);
      const val20 = parseFloat(s.finalScore20) || 0;
      let mention = 'Ajourné';
      if (val20 >= 16) mention = 'Très Bien';
      else if (val20 >= 14) mention = 'Bien';
      else if (val20 >= 12) mention = 'Assez Bien';
      else if (val20 >= 10) mention = 'Passable';

      return [
        `"${s.accessNumber || ''}"`,
        `"${s.studentCode || ''}"`,
        `"${s.lastName || ''}"`,
        `"${s.firstName || ''}"`,
        `"${s.group || ''}"`,
        `"${s.speciality || 'Informatique'}"`,
        `"${s.status || ''}"`,
        `"${s.gradingStatus === 'GRADED' ? 'Corrigé' : 'Non corrigé'}"`,
        s.finalScore20 || '0.00',
        `"${mention}"`,
        s.totalPercent,
        s.totalEarned,
        s.totalMaxScore,
        `"${s.totalPassed}/${s.totalTestsAll}"`,
        timeMins,
        s.violations,
        ...probScores
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF'
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Resultats_DeAnonymises_${(examTitle || 'Examen').replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '16px', background: '#0b0f19' }}>
        <RefreshCw size={36} color="#3b82f6" style={{ animation: 'spin 1s linear infinite' }} />
        <p style={{ color: 'var(--text-muted)' }}>Dé-anonymisation et calcul des résultats officiels...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '16px', background: '#0b0f19' }}>
        <AlertCircle size={48} color="#ef4444" />
        <h2 style={{ color: '#f87171' }}>Impossible de charger les résultats</h2>
        <p style={{ color: 'var(--text-muted)' }}>{error}</p>
        <button className="btn btn-primary" onClick={onBack}><ArrowLeft size={16} /> Retour au tableau de bord</button>
      </div>
    );
  }

  const exam = data?.exam || {};
  const problems = data?.problems || [];
  const studentRows = data?.studentRows || [];
  const stats = data?.stats || {};

  // Filter & sort
  const filteredStudents = studentRows.filter(s => {
    const q = search.toLowerCase();
    return (
      (s.firstName && s.firstName.toLowerCase().includes(q)) ||
      (s.lastName && s.lastName.toLowerCase().includes(q)) ||
      (s.accessNumber && s.accessNumber.toLowerCase().includes(q)) ||
      (s.group && s.group.toLowerCase().includes(q)) ||
      (s.studentCode && s.studentCode.toLowerCase().includes(q))
    );
  }).sort((a, b) => {
    let diff = 0;
    if (sortCol === 'score') diff = (b.finalScore20 || 0) - (a.finalScore20 || 0);
    else if (sortCol === 'name') diff = (a.lastName || '').localeCompare(b.lastName || '');
    else if (sortCol === 'code') diff = (a.accessNumber || '').localeCompare(b.accessNumber || '');
    else if (sortCol === 'time') diff = (b.timeTakenMs || 0) - (a.timeTakenMs || 0);
    else if (sortCol === 'violations') diff = (b.violations || 0) - (a.violations || 0);
    return sortAsc ? -diff : diff;
  });

  return (
    <div style={{ minHeight: '100vh', background: '#0b0f19', color: '#fff', padding: '24px 32px' }}>

      {/* ── ZIP PROGRESS OVERLAY ── */}
      {zipProgress && zipProgress.status !== 'done' && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 9999,
          background: 'linear-gradient(90deg, #1e293b 0%, #0f172a 100%)',
          borderBottom: '2px solid #3b82f6', padding: '10px 24px',
          display: 'flex', alignItems: 'center', gap: '16px', boxShadow: '0 4px 24px rgba(0,0,0,0.5)'
        }}>
          <div style={{ animation: 'spin 1s linear infinite', display: 'flex' }}>
            <RefreshCw size={18} color="#3b82f6" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
              <span>📦 Génération des copies PDF en cours…</span>
              <span style={{ color: '#60a5fa' }}>{zipProgress.done} / {zipProgress.total} copies</span>
            </div>
            <div style={{ height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{
                height: '100%', borderRadius: '4px',
                background: 'linear-gradient(90deg, #3b82f6 0%, #06b6d4 100%)',
                width: zipProgress.total > 0 ? `${Math.round((zipProgress.done / zipProgress.total) * 100)}%` : '5%',
                transition: 'width 0.4s ease'
              }} />
            </div>
            {zipProgress.studentName && (
              <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '3px' }}>
                Dernière copie générée : <strong style={{ color: '#a5b4fc' }}>{zipProgress.studentName}</strong>
              </div>
            )}
          </div>
          <span style={{ fontSize: '0.8rem', color: '#60a5fa', fontWeight: '700' }}>
            {zipProgress.total > 0 ? `${Math.round((zipProgress.done / zipProgress.total) * 100)}%` : '…'}
          </span>
        </div>
      )}

      {/* ── Top Bar ── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', flexWrap: 'wrap', gap: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button className="btn btn-secondary" onClick={onBack} style={{ padding: '8px 14px' }}>
            <ArrowLeft size={16} /> Retour
          </button>
          <div>
            <h1 style={{ fontSize: '1.5rem', fontWeight: '800', margin: 0, display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span>📊 Résultats Dé-Anonymisés</span>
              <span style={{ fontSize: '0.78rem', background: '#065f46', color: '#a7f3d0', padding: '3px 10px', borderRadius: '12px', fontWeight: '700' }}>
                Noms ↔ Codes Rétablis
              </span>
            </h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', margin: '2px 0 0 0' }}>
              Examen : <strong style={{ color: '#fff' }}>{exam.title}</strong> • Durée: {exam.durationMinutes} min • Inscrits: {stats.total}
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <button className="btn btn-secondary" onClick={loadResults} style={{ padding: '8px 12px' }}>
            <RefreshCw size={14} /> Actualiser
          </button>

          <button
            className="btn btn-secondary"
            onClick={handleExportEncryptedResults}
            style={{ padding: '8px 14px', background: 'rgba(30, 41, 59, 0.8)', border: '1px solid #334155', color: '#93c5fd', display: 'flex', alignItems: 'center', gap: '6px' }}
            title="Exporter les résultats officiels au format chiffré (.algoresults)"
          >
            <Lock size={15} /> Exporter Résultats (.algoresults)
          </button>

          <button
            className="btn btn-secondary"
            onClick={handleImportEncryptedResults}
            style={{ padding: '8px 14px', background: 'rgba(30, 41, 59, 0.8)', border: '1px solid #334155', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '6px' }}
            title="Importer un fichier externe .algoresults"
          >
            <Upload size={15} /> Importer Résultats
          </button>

          <button
            className="btn btn-primary"
            onClick={handleDownloadAllPDFsZIP}
            disabled={isDownloadingPDF}
            style={{ padding: '8px 16px', fontWeight: '700', background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            {isDownloadingPDF ? (
              <span>⌛ Génération ZIP...</span>
            ) : (
              <><FileText size={15} /> Télécharger Toutes les Copies (ZIP)</>
            )}
          </button>

          <button className="btn btn-success" onClick={exportCSV} style={{ padding: '8px 16px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Download size={15} /> Exporter CSV
          </button>
        </div>
      </div>

      {/* ── KPI Cards (6 metrics) ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px', marginBottom: '24px' }}>
        <div className="glass-panel" style={{ padding: '18px', textAlign: 'center' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '6px' }}>MOYENNE CLASSE</div>
          <div style={{ fontSize: '1.8rem', fontWeight: '800', color: stats.avgScore20 >= 10 ? '#34d399' : '#f87171' }}>
            {stats.avgScore20} <span style={{ fontSize: '1rem', color: '#93c5fd' }}>/ 20</span>
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>{stats.avgScorePct}% de réussite</div>
        </div>

        <div className="glass-panel" style={{ padding: '18px', textAlign: 'center' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '6px' }}>MEILLEURE / PIRE</div>
          <div style={{ fontSize: '1.35rem', fontWeight: '800', color: '#60a5fa' }}>
            {stats.maxScore20} <span style={{ fontSize: '0.85rem', color: '#93c5fd' }}>/20</span> • {stats.minScore20} <span style={{ fontSize: '0.85rem', color: '#f87171' }}>/20</span>
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>Note Max / Min</div>
        </div>

        <div className="glass-panel" style={{ padding: '18px', textAlign: 'center' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '6px' }}>PARTICIPATION</div>
          <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#34d399' }}>
            {stats.finished} <span style={{ fontSize: '1rem', color: 'var(--text-muted)', fontWeight: 'normal' }}>/ {stats.total}</span>
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            {stats.kickedOut > 0 ? `(${stats.kickedOut} exclu(s))` : 'Copies soumises & notées'}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '18px', textAlign: 'center' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '6px' }}>TEMPS MOYEN</div>
          <div style={{ fontSize: '1.4rem', fontWeight: '800', color: '#fbbf24' }}>
            {formatDuration(stats.avgTimeMs)}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>Par étudiant connecté</div>
        </div>

        <div className="glass-panel" style={{ padding: '18px', textAlign: 'center' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '6px' }}>VIOLATIONS TOTALES</div>
          <div style={{ fontSize: '1.8rem', fontWeight: '800', color: stats.totalViolations > 0 ? '#ef4444' : '#34d399' }}>
            {stats.totalViolations}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>Sorties FS &amp; Incidents</div>
        </div>

        <div className="glass-panel" style={{ padding: '18px', textAlign: 'center' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '6px' }}>TAUX DE MOYENNE</div>
          <div style={{ fontSize: '1.8rem', fontWeight: '800', color: '#c084fc' }}>
            {stats.total > 0 ? Math.round((studentRows.filter(s => s.finalScore20 >= 10).length / stats.total) * 100) : 0}%
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>Étudiants &ge; 10 / 20</div>
        </div>
      </div>

      {/* ── Middle Row: Distribution & Per-Problem Analytics ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '24px' }}>

        {/* Histogram Distribution */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <BarChart2 size={18} color="#60a5fa" />
            <h3 style={{ fontSize: '1rem', margin: 0 }}>Distribution des Notes sur /20</h3>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {stats.distribution.map(d => {
              const pct = stats.total > 0 ? Math.round((d.count / stats.total) * 100) : 0;
              return (
                <div key={d.label} style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '0.85rem' }}>
                  <span style={{ width: '90px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{d.label}</span>
                  <div style={{ flex: 1, background: 'rgba(255,255,255,0.06)', borderRadius: '4px', height: '22px', overflow: 'hidden', display: 'flex', alignItems: 'center', position: 'relative' }}>
                    <div style={{
                      width: `${pct}%`, height: '100%',
                      background: d.label.includes('18') || d.label.includes('16') || d.label.includes('14') ? '#34d399' : d.label.includes('10') || d.label.includes('12') ? '#fbbf24' : '#f87171',
                      transition: 'width 0.4s ease'
                    }} />
                    <span style={{ position: 'absolute', right: '10px', fontSize: '0.75rem', fontWeight: '700', color: '#fff' }}>
                      {d.count} ({pct}%)
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Per-problem performance & Average Score per Exercise */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <TrendingUp size={18} color="#34d399" />
            <h3 style={{ fontSize: '1rem', margin: 0 }}>Moyenne et Réussite par Exercice</h3>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {stats.problemStats.map((p, idx) => {
              const passPct = p.total > 0 ? Math.round((p.passed / p.total) * 100) : 0;
              return (
                <div key={p.problemId} style={{ background: 'rgba(0,0,0,0.2)', padding: '10px 14px', borderRadius: '8px', border: '1px solid var(--panel-border)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px', fontSize: '0.85rem' }}>
                    <span style={{ fontWeight: '700', color: '#fff' }}>Ex {idx + 1}: {p.title} ({p.maxPoints} pts)</span>
                    <span style={{ color: '#34d399', fontWeight: '700' }}>
                      Moyenne: {parseFloat(Number(p.avgEarnedPoints || 0).toFixed(2))} / {p.maxPoints} pts
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    <span>{p.passed}/{p.total} valides ({passPct}%)</span>
                    <span>Soumis: {p.submitted}/{p.total}</span>
                  </div>
                  <div style={{ background: 'rgba(255,255,255,0.06)', borderRadius: '4px', height: '10px', overflow: 'hidden' }}>
                    <div style={{ width: `${Math.min(100, Math.round((p.avgEarnedPoints / (p.maxPoints || 1)) * 100))}%`, height: '100%', background: p.avgScore20 >= 10 ? '#34d399' : '#f87171' }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── De-anonymized Student Results Table ── */}
      <div className="glass-panel" style={{ padding: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <h3 style={{ fontSize: '1.1rem', margin: 0, fontWeight: '800' }}>📋 Tableau Dé-Anonymisé des Étudiants</h3>
            <p style={{ margin: '2px 0 0 0', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Correspondance complète Code Anonyme ↔ Identité Réelle ↔ Notes officielles
            </p>
          </div>

          <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
            <input
              type="text"
              className="form-input"
              placeholder="Rechercher par nom, code anonyme, matricule..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ width: '320px', padding: '6px 12px', fontSize: '0.85rem' }}
            />

            <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              {filteredStudents.length} / {studentRows.length} étudiants
            </span>
          </div>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
            <thead>
              <tr style={{ background: 'rgba(0,0,0,0.4)', borderBottom: '1px solid var(--panel-border)', textAlign: 'left' }}>
                <th style={{ padding: '10px 12px' }}>#</th>
                <th style={{ padding: '10px 12px', cursor: 'pointer' }} onClick={() => { setSortCol('code'); setSortAsc(!sortAsc); }}>
                  Code Anonyme {sortCol === 'code' ? (sortAsc ? '▲' : '▼') : ''}
                </th>
                <th style={{ padding: '10px 12px', cursor: 'pointer' }} onClick={() => { setSortCol('name'); setSortAsc(!sortAsc); }}>
                  Nom &amp; Prénom {sortCol === 'name' ? (sortAsc ? '▲' : '▼') : ''}
                </th>
                <th style={{ padding: '10px 12px' }}>Matricule</th>
                <th style={{ padding: '10px 12px' }}>Groupe</th>
                <th style={{ padding: '10px 12px' }}>Statut</th>
                <th style={{ padding: '10px 12px', cursor: 'pointer', textAlign: 'center' }} onClick={() => { setSortCol('score'); setSortAsc(!sortAsc); }}>
                  Note Finale /20 {sortCol === 'score' ? (sortAsc ? '▲' : '▼') : ''}
                </th>
                {problems.map((p, i) => (
                  <th key={p.id} style={{ padding: '10px 12px', textAlign: 'center' }}>Ex {i+1} ({p.points}p)</th>
                ))}
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8 + problems.length} style={{ padding: '30px', textAlign: 'center', color: 'var(--text-muted)' }}>
                    Aucun étudiant ne correspond à la recherche.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s, idx) => {
                  const isFinished = s.status === 'FINISHED' || s.gradingStatus === 'GRADED';
                  const isDownloadingThis = downloadingStudentId === s.studentId;

                  return (
                    <tr key={s.studentId || idx} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', background: idx % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.015)' }}>
                      <td style={{ padding: '10px 12px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{idx + 1}</td>
                      <td style={{ padding: '10px 12px', fontFamily: 'var(--font-mono)', color: '#60a5fa', fontWeight: '800' }}>
                        {s.accessNumber}
                      </td>
                      <td style={{ padding: '10px 12px', fontWeight: '700', color: '#fff' }}>
                        {s.lastName?.toUpperCase()} {s.firstName}
                      </td>
                      <td style={{ padding: '10px 12px', fontFamily: 'var(--font-mono)', color: '#a78bfa' }}>
                        {s.studentCode || '—'}
                      </td>
                      <td style={{ padding: '10px 12px', color: 'var(--text-muted)' }}>{s.group || '—'}</td>
                      <td style={{ padding: '10px 12px' }}>
                        <span className={`badge ${s.gradingStatus === 'GRADED' ? 'badge-green' : isFinished ? 'badge-blue' : 'badge-yellow'}`}>
                          {s.gradingStatus === 'GRADED' ? '✅ Corrigé' : s.status}
                        </span>
                      </td>
                      <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                        <div style={{
                          fontWeight: '800', fontSize: '1.05rem',
                          color: (parseFloat(s.finalScore20) || 0) >= 10 ? '#34d399' : '#f87171'
                        }}>
                          {parseFloat(Number(s.finalScore20 || 0).toFixed(2))} <span style={{ fontSize: '0.85rem', color: '#93c5fd' }}>/ 20</span>
                        </div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                          {parseFloat(Number(s.totalEarned || 0).toFixed(2))} / {s.totalMaxScore} pts ({s.totalPercent}%)
                        </div>
                      </td>
                      {s.problemScores.map(ps => (
                        <td key={ps.problemId} style={{ padding: '10px 12px', textAlign: 'center', fontFamily: 'var(--font-mono)' }}>
                          <span style={{ color: ps.earnedPoints === ps.maxPoints ? '#34d399' : ps.earnedPoints > 0 ? '#fbbf24' : 'var(--text-muted)', fontWeight: '700' }}>
                            {parseFloat(Number(ps.earnedPoints || 0).toFixed(2))}/{ps.maxPoints}
                          </span>
                        </td>
                      ))}
                      <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                        <button
                          className="btn btn-secondary"
                          onClick={() => handleDownloadSinglePDF(s.studentId, s.lastName, s.firstName, s.accessNumber)}
                          disabled={isDownloadingThis}
                          style={{ padding: '4px 10px', fontSize: '0.75rem', fontWeight: '700', color: '#93c5fd', background: '#1e293b', border: '1px solid #334155' }}
                          title="Télécharger la copie PDF complète avec en-tête et QR code"
                        >
                          {isDownloadingThis ? '⌛' : <><FileText size={12} /> PDF</>}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
