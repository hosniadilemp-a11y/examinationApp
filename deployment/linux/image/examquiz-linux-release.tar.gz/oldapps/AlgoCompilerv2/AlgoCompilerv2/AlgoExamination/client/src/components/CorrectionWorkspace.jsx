import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { getSocket, joinExamRoom } from '../services/socket.js';
import {
  getExamGradingData,
  saveProblemGrade,
  calculateExerciseGrade,
  recalculateAllExamGrades,
  updateGeneralFeedback,
  analyzeSubmissionSyntax,
  runTeacherSandboxCode,
  downloadStudentPDFBlob,
  downloadAllStudentPDFBlob,
  verifyQRCodePayload,
  evaluateAIModule,
  finalizeExamCorrection,
  exportExamBundle
} from '../services/api';
import {
  ArrowLeft, ArrowRight, Save, CheckCircle, AlertCircle, RefreshCw,
  Play, Columns, BookOpen, User, CheckSquare, Square, Sparkles, Terminal, Trash2, Trophy, Eye, Edit3, Code, Wand2, GitFork, GitBranch, X, ChevronRight, ChevronDown, ChevronUp,
  FileText, ShieldCheck, QrCode, Printer, AlertTriangle, Layers, Cpu, BarChart2, Sliders, Check, Users, Zap, Lock, Package, CheckCheck
} from 'lucide-react';
import Swal from 'sweetalert2';
import { renderMarkdownHTML, formatOutputText } from '../utils/markdown';

// ── Helper: Normalize output for comparison (mirrors server-side normalizeOutput) ──
function roundToNextQuarterPoint(val, maxVal) {
  if (val === null || val === undefined || isNaN(parseFloat(val)) || parseFloat(val) <= 0) return 0;
  const num = parseFloat(val);
  const rounded = Math.round((Math.ceil(num * 4) / 4) * 100) / 100;
  const cleanMax = maxVal !== undefined ? Math.round(parseFloat(maxVal) * 100) / 100 : undefined;
  return cleanMax !== undefined ? Math.min(cleanMax, rounded) : rounded;
}

const roundToNextHalfPoint = roundToNextQuarterPoint;

function normalizeOutput(str) {
  if (!str) return '';
  return str
    .replace(/\r\n/g, ' ')
    .replace(/[\n\r\t]+/g, ' ')
    .trim()
    .replace(/[ \t]+/g, ' ');
}

function isTestOutputMatching(actual, expected) {
  const normActual = normalizeOutput(actual);
  const normExpected = normalizeOutput(expected);
  return normActual === normExpected;
}

// ── Helper: Slice Code by Question Markers ────────────────────────────────
function sliceCodeByQuestionMarkers(codeStr) {
  if (!codeStr || typeof codeStr !== 'string') return {};
  const startRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:starts|commence|d[ée]bute?)\s*(?:here|ici)?|(?:d[ée]but)\s+question\s+(\d+))\s*$/gim;
  const endRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:ends|se\s+termine|termine|fin)\s*(?:here|ici)?|(?:fin)\s+question\s+(\d+))\s*$/gim;
  const starts = {};
  const ends = {};
  let match;
  while ((match = startRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    starts[qNum] = match.index + match[0].length;
  }
  while ((match = endRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    ends[qNum] = match.index;
  }
  const slices = {};
  const questionNums = Object.keys(starts);
  if (questionNums.length === 0) {
    slices[1] = codeStr.trim();
    return slices;
  }
  for (const qNum of questionNums) {
    if (ends[qNum] !== undefined && ends[qNum] >= starts[qNum]) {
      slices[qNum] = codeStr.substring(starts[qNum], ends[qNum]).trim();
    } else {
      slices[qNum] = '';
    }
  }
  return slices;
}

// ── Helper: Extract code from Json or String currentCodeMap ─────────────
function extractCodeFromMap(currentCodeMap, problemId) {
  if (!currentCodeMap || !problemId) return null;
  let map = currentCodeMap;
  if (typeof map === 'string') {
    try { map = JSON.parse(map); } catch (e) {}
  }
  if (!map || typeof map !== 'object') return null;

  if (map[problemId]) {
    const val = map[problemId];
    if (typeof val === 'string' && val.trim()) return val;
    if (val && typeof val === 'object' && val.code && val.code.trim()) return val.code;
  }

  const targetKey = String(problemId).toLowerCase().trim();
  for (const k of Object.keys(map)) {
    if (String(k).toLowerCase().trim() === targetKey) {
      const val = map[k];
      if (typeof val === 'string' && val.trim()) return val;
      if (val && typeof val === 'object' && val.code && val.code.trim()) return val.code;
    }
  }

  return null;
}

// ── 5 Random Pedagogical Feedback Variants per Score Range ────────────────
const APPRECIATION_VARIANTS = {
  EXCELLENT: [
    "Excellent travail ! Une maîtrise remarquable des concepts et de la syntaxe algorithmique.",
    "Copie exemplaire. La démarche logique et la structure du code sont irréprochables.",
    "Très haut niveau. Raisonnement fluide, efficace et parfaite gestion des structures de données.",
    "Remarquable ! L'ensemble des problèmes est résolu avec élégance et précision.",
    "Prestation excellente. Algorithmes optimisés et respect rigoureux des spécifications."
  ],
  VERY_GOOD: [
    "Très bon travail ! Bonne structure d'ensemble et logique globale très bien maîtrisée.",
    "Très bonne copie. Les choix algorithmiques sont judicieux et bien implémentés.",
    "Résultat très satisfaisant. La majorité des exercices est traitée avec succès.",
    "Très bon niveau d'assimilation. Rigueur d'écriture et raisonnement solide.",
    "Travail de grande qualité. De très bons réflexes algorithmiques sur l'ensemble du sujet."
  ],
  GOOD: [
    "Bon travail dans l'ensemble. La démarche est correcte malgré quelques petites imperfections.",
    "Bonne copie. L'étudiant fait preuve d'une bonne compréhension des notions fondamentales.",
    "Résultat positif. Les algorithmes principaux sont fonctionnels et bien structurés.",
    "Bonne maîtrise globale des structures de contrôle et des types de variables.",
    "Ensemble satisfaisant. Quelques détails syntaxiques à affiner pour viser l'excellence."
  ],
  ENCOURAGING: [
    "Encouragements. Les bases sont acquises, des progrès notables sont à portée de main.",
    "Travail convenable. La logique du problème est comprise, mais manque parfois d'optimisation.",
    "Résultat encourageant. Continuez vos efforts d'entraînement sur les cas particuliers.",
    "Ensemble moyen supérieur. Quelques étourderies d'initialisation ou de boucle à corriger.",
    "Bonne volonté évidente. Avec plus de pratique régulière, le niveau sera très bon."
  ],
  BORDERLINE: [
    "Passable / Limite. Notions de base comprises mais la mise en pratique reste fragile.",
    "Niveau juste moyen. Il convient de revoir la méthode de conception des boucles et conditions.",
    "Résultat tout juste à la moyenne. Attention à la rigueur de la syntaxe et des déclarations.",
    "Compétences de base présentes mais fragilités sur les problèmes plus élaborés.",
    "Passe de justesse. Une révision ciblée des exercices types est fortement recommandée."
  ],
  WEAK: [
    "Travail insuffisant. Des révisions approfondies des notions fondamentales sont requises.",
    "Résultat sous la moyenne. Difficultés visibles dans l'enchaînement logique des instructions.",
    "Compréhension incomplète du sujet. Il est nécessaire de reprendre les TP et cours de base.",
    "Les algorithmes sont inachevés ou comportent des erreurs de logique majeures.",
    "Niveau insuffisant. Un retravail complet des notions de boucles et tableaux s'impose."
  ],
  DANGER: [
    "En danger ! Un effort important et soutenu est indispensable pour remonter le niveau.",
    "Résultat très préoccupant. Lacunes importantes sur l'ensemble des exercices proposés.",
    "Attention : le niveau actuel est en deçà des attentes fondamentales de la matière.",
    "Difficultés sérieuses. Un accompagnement ou un travail personnel intensif est requis.",
    "Performance insuffisante. Révision prioritaire des concepts élémentaires nécessaire."
  ],
  FAIL: [
    "Travail nettement insuffisant. Reprise impérative et urgente des notions de base !",
    "Copie très faible. L'étudiant ne maîtrise pas la syntaxe ni la structure algorithmique.",
    "Niveau très insuffisant. Les bases du cours doivent être totalement réétudiées.",
    "Résultat très insuffisant. Manque d'investissement ou d'assimilation des principes clés.",
    "Lacunes majeures. Une remise à niveau complète est indispensable."
  ]
};

function getSuggestedAppreciation(score20) {
  const score = parseFloat(score20) || 0;
  let list;
  if (score >= 18)   list = APPRECIATION_VARIANTS.EXCELLENT;
  else if (score >= 16)   list = APPRECIATION_VARIANTS.VERY_GOOD;
  else if (score >= 14)   list = APPRECIATION_VARIANTS.GOOD;
  else if (score >= 12)   list = APPRECIATION_VARIANTS.ENCOURAGING;
  else if (score >= 10)   list = APPRECIATION_VARIANTS.BORDERLINE;
  else if (score >= 9)    list = APPRECIATION_VARIANTS.WEAK;
  else if (score >= 8.5)  list = APPRECIATION_VARIANTS.DANGER;
  else                    list = APPRECIATION_VARIANTS.FAIL;

  const randomIndex = Math.floor(Math.random() * list.length);
  return list[randomIndex];
}

const formatPts = val => {
  if (val === null || val === undefined || isNaN(parseFloat(val))) return '0';
  const num = parseFloat(val);
  return Number.isInteger(num) ? String(num) : String(Math.round(num * 100) / 100);
};

// ── Pure AST Parser for Algorithmic Pseudo-code ─────────────────────────────
function parsePseudoCodeAST(code) {
  if (!code || typeof code !== 'string') return null;

  const lines = code.split('\n');
  let programName = 'Anonyme';
  const variables = [];
  const rootBody = [];
  const stack = [{ nodeType: 'Program', body: rootBody, variables: variables }];

  let inVarSection = false;

  lines.forEach((lineText, idx) => {
    const lineNum = idx + 1;
    const clean = lineText.replace(/\/\/.*$/, '').replace(/\/\*[\s\S]*?\*\//, '').trim();
    if (!clean) return;

    // 1. Program Header
    const algoMatch = clean.match(/^ALGORITHME\s+([a-zA-Z0-9_]+)/i);
    if (algoMatch) {
      programName = algoMatch[1];
      return;
    }

    // 2. Variables Section Keyword
    if (/^(VARIABLES|VAR)\b/i.test(clean)) {
      inVarSection = true;
      return;
    }

    // 3. Function Declaration: Fonction Nom(p: Type) : RetType;
    const funcMatch = clean.match(/^(?:FONCTION|FUNCTION)\s+([a-zA-Z0-9_]+)\s*(?:\((.*?)\))?\s*(?::\s*([a-zA-Z0-9_\[\]\.]+))?;?/i);
    if (funcMatch) {
      inVarSection = false;
      const rawParams = funcMatch[2] ? funcMatch[2].split(',').map(p => {
        const parts = p.split(':');
        return { name: parts[0]?.trim(), type: parts[1]?.trim() || 'Inconnu' };
      }) : [];
      const funcNode = {
        type: 'FunctionDeclaration',
        name: funcMatch[1],
        params: rawParams,
        returnType: funcMatch[3] ? funcMatch[3].trim() : 'Entier',
        variables: [],
        body: [],
        line: lineNum
      };
      const currentParent = stack[stack.length - 1];
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(funcNode);
      stack.push({ nodeType: 'FunctionDeclaration', body: funcNode.body, variables: funcNode.variables });
      return;
    }

    // 4. Procedure Declaration: Procedure Nom(p: Type);
    const procMatch = clean.match(/^(?:PROCEDURE)\s+([a-zA-Z0-9_]+)\s*(?:\((.*?)\))?;?/i);
    if (procMatch) {
      inVarSection = false;
      const rawParams = procMatch[2] ? procMatch[2].split(',').map(p => {
        const parts = p.split(':');
        return { name: parts[0]?.trim(), type: parts[1]?.trim() || 'Inconnu' };
      }) : [];
      const procNode = {
        type: 'ProcedureDeclaration',
        name: procMatch[1],
        params: rawParams,
        variables: [],
        body: [],
        line: lineNum
      };
      const currentParent = stack[stack.length - 1];
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(procNode);
      stack.push({ nodeType: 'ProcedureDeclaration', body: procNode.body, variables: procNode.variables });
      return;
    }

    // 5. DEBUT
    if (/^DEBUT\b/i.test(clean)) {
      inVarSection = false;
      return;
    }

    // 6. Variable Declarations
    if (inVarSection) {
      const varDecl = clean.match(/^([a-zA-Z0-9_,\s]+)\s*:\s*([a-zA-Z0-9_\[\]\.]+);?/i);
      if (varDecl) {
        const names = varDecl[1].split(',').map(n => n.trim()).filter(Boolean);
        const typeStr = varDecl[2].trim();
        const currentParent = stack[stack.length - 1];
        const targetVars = currentParent.variables || variables;
        names.forEach(n => targetVars.push({ name: n, type: typeStr }));
      }
      return;
    }

    const currentParent = stack[stack.length - 1];

    // 7. Closures: FINSI, FINPOUR, FINTANTQUE, FIN;
    if (/^FIN\s*SI\b|^FINSI\b/i.test(clean)) {
      if (stack.length > 1 && stack[stack.length - 1].nodeType === 'IfStatement') stack.pop();
      return;
    }
    if (/^FIN\s*POUR\b|^FINPOUR\b/i.test(clean)) {
      if (stack.length > 1 && stack[stack.length - 1].nodeType === 'ForLoopStatement') stack.pop();
      return;
    }
    if (/^FIN\s*TANTQUE\b|^FINTANTQUE\b/i.test(clean)) {
      if (stack.length > 1 && stack[stack.length - 1].nodeType === 'WhileLoopStatement') stack.pop();
      return;
    }
    if (/^FIN\b|^FIN;/i.test(clean)) {
      if (stack.length > 1) {
        stack.pop();
      }
      return;
    }

    // 8. SINON
    if (/^SINON\b/i.test(clean)) {
      if (currentParent.nodeType === 'IfStatement') currentParent.inAlternate = true;
      return;
    }

    // 9. Return Statement: Retourner / Renvoyer / Return
    const retMatch = clean.match(/^(?:RETOURNER|RENVOYER|RETURN)\s+(.*?);?$/i);
    if (retMatch) {
      const retNode = {
        type: 'ReturnStatement',
        argument: retMatch[1].trim(),
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(retNode);
      return;
    }

    // 10. If Statement
    const ifMatch = clean.match(/^SI\s+(.*?)\s+ALORS/i);
    if (ifMatch) {
      const ifNode = {
        type: 'IfStatement',
        nodeType: 'IfStatement',
        condition: ifMatch[1].trim(),
        consequent: [],
        alternate: [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(ifNode);
      stack.push({ nodeType: 'IfStatement', consequent: ifNode.consequent, alternate: ifNode.alternate, inAlternate: false });
      return;
    }

    // 11. For Loop
    const forMatch = clean.match(/^POUR\s+([a-zA-Z0-9_]+)\s*(?::=|=|<-)\s*(.*?)\s+A\s+(.*?)\s+FAIRE/i);
    if (forMatch) {
      const forNode = {
        type: 'ForLoopStatement',
        nodeType: 'ForLoopStatement',
        iterator: forMatch[1].trim(),
        start: forMatch[2].trim(),
        end: forMatch[3].trim(),
        body: [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(forNode);
      stack.push({ nodeType: 'ForLoopStatement', body: forNode.body });
      return;
    }

    // 12. While Loop
    const whileMatch = clean.match(/^TANTQUE\s+\(?(.*?)\)?\s+FAIRE/i);
    if (whileMatch) {
      const whileNode = {
        type: 'WhileLoopStatement',
        nodeType: 'WhileLoopStatement',
        condition: whileMatch[1].trim(),
        body: [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(whileNode);
      stack.push({ nodeType: 'WhileLoopStatement', body: whileNode.body });
      return;
    }

    // 13. Call Expression: Ecrire, Lire, or any function/procedure call
    const callMatch = clean.match(/^([a-zA-Z0-9_]+)\s*\((.*?)\);?$/i);
    if (callMatch && !/^(SI|POUR|TANTQUE|VAR|VARIABLES|DEBUT|FIN|ALGORITHME|FONCTION|PROCEDURE|RETOURNER)$/i.test(callMatch[1])) {
      const callNode = {
        type: 'CallExpression',
        callee: callMatch[1],
        args: callMatch[2] ? callMatch[2].split(',').map(a => a.trim()).filter(Boolean) : [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(callNode);
      return;
    }

    // 14. Assignment Statement
    const assignMatch = clean.match(/^([a-zA-Z0-9_\[\]\.]+)\s*(?::=|=|<-)\s*(.*?);?$/);
    if (assignMatch) {
      const assignNode = {
        type: 'AssignmentStatement',
        target: assignMatch[1].trim(),
        expression: assignMatch[2].trim(),
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(assignNode);
      return;
    }

    // 15. Generic Expression
    const genericNode = {
      type: 'ExpressionStatement',
      code: clean,
      line: lineNum
    };
    const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
    if (targetArray) targetArray.push(genericNode);
  });

  return {
    type: 'Program',
    name: programName,
    variables,
    body: rootBody
  };
}

// ── Authentic Graphical Visual AST Tree Node Graph Component ──────────────────
function RealASTTreeNodeGraph({ node, isLast = true, depth = 0, isRoot = true }) {
  const [collapsed, setCollapsed] = useState(false);

  if (!node) return null;

  const nodeTheme = node.type === 'Program'
    ? { bg: 'rgba(59, 130, 246, 0.15)', border: '#60a5fa', text: '#93c5fd', badge: '📦 Program', glow: 'rgba(59, 130, 246, 0.3)' }
    : node.type === 'FunctionDeclaration'
    ? { bg: 'rgba(168, 85, 247, 0.18)', border: '#a855f7', text: '#d8b4fe', badge: 'ƒ Fonction', glow: 'rgba(168, 85, 247, 0.3)' }
    : node.type === 'ProcedureDeclaration'
    ? { bg: 'rgba(14, 165, 233, 0.18)', border: '#0ea5e9', text: '#7dd3fc', badge: '⚙ Procédure', glow: 'rgba(14, 165, 233, 0.3)' }
    : node.type === 'ReturnStatement'
    ? { bg: 'rgba(236, 72, 153, 0.18)', border: '#ec4899', text: '#fbcfe8', badge: '↵ Retourner', glow: 'rgba(236, 72, 153, 0.3)' }
    : node.type === 'IfStatement'
    ? { bg: 'rgba(245, 158, 11, 0.15)', border: '#fbbf24', text: '#fef3c7', badge: '🔀 IfCondition', glow: 'rgba(245, 158, 11, 0.3)' }
    : node.type === 'ForLoopStatement' || node.type === 'WhileLoopStatement'
    ? { bg: 'rgba(192, 132, 252, 0.15)', border: '#c084fc', text: '#e9d5ff', badge: node.type === 'ForLoopStatement' ? '🔁 ForLoop' : '🔄 WhileLoop', glow: 'rgba(192, 132, 252, 0.3)' }
    : node.type === 'CallExpression'
    ? { bg: 'rgba(16, 185, 129, 0.15)', border: '#34d399', text: '#a7f3d0', badge: '⚡ Call', glow: 'rgba(16, 185, 129, 0.3)' }
    : node.type === 'AssignmentStatement'
    ? { bg: 'rgba(251, 191, 36, 0.12)', border: '#f59e0b', text: '#fde68a', badge: '📝 Assign', glow: 'rgba(251, 191, 36, 0.25)' }
    : { bg: 'rgba(156, 163, 175, 0.12)', border: '#9ca3af', text: '#e5e7eb', badge: '• Expr', glow: 'rgba(156, 163, 175, 0.2)' };

  const children = node.type === 'Program' ? node.body
    : node.type === 'IfStatement' ? [...(node.consequent || []), ...(node.alternate || [])]
    : node.body || [];

  const hasChildren = children && children.length > 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', position: 'relative', margin: '4px 0 4px 0' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        {!isRoot && (
          <div style={{ display: 'flex', alignItems: 'center', width: '20px', justifyContent: 'center' }}>
            <svg width="20" height="28" style={{ overflow: 'visible' }}>
              <path
                d="M 0 -14 V 14 H 20"
                fill="none"
                stroke={nodeTheme.border}
                strokeWidth="2"
                strokeDasharray={collapsed ? '3 3' : 'none'}
                opacity="0.75"
              />
            </svg>
          </div>
        )}

        {/* Graphical AST Node Card */}
        <div
          onClick={() => hasChildren && setCollapsed(!collapsed)}
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            padding: '6px 14px',
            borderRadius: '8px',
            background: `linear-gradient(135deg, ${nodeTheme.bg}, rgba(15, 23, 42, 0.95))`,
            border: `1.5px solid ${nodeTheme.border}`,
            boxShadow: `0 4px 14px ${nodeTheme.glow}`,
            cursor: hasChildren ? 'pointer' : 'default',
            transition: 'all 0.2s ease',
            maxWidth: '100%'
          }}
        >
          {hasChildren && (
            <span style={{ color: nodeTheme.text, display: 'flex', alignItems: 'center' }}>
              {collapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
            </span>
          )}

          <span style={{
            fontSize: '0.75rem',
            fontWeight: '800',
            padding: '2px 7px',
            borderRadius: '4px',
            background: 'rgba(0,0,0,0.5)',
            color: nodeTheme.border,
            border: `1px solid ${nodeTheme.border}44`,
            letterSpacing: '0.5px'
          }}>
            {nodeTheme.badge}
          </span>

          {node.type === 'Program' && (
            <span style={{ color: '#fff', fontWeight: '700', fontSize: '0.83rem' }}>
              "{node.name}" <span style={{ color: '#94a3b8', fontSize: '0.75rem' }}>({node.variables?.length || 0} variables)</span>
            </span>
          )}

          {node.type === 'FunctionDeclaration' && (
            <span style={{ color: '#d8b4fe', fontWeight: '700', fontSize: '0.83rem' }}>
              {node.name}({node.params?.map(p => `${p.name}: ${p.type}`).join(', ') || ''}) : {node.returnType || 'Entier'}
            </span>
          )}

          {node.type === 'ProcedureDeclaration' && (
            <span style={{ color: '#7dd3fc', fontWeight: '700', fontSize: '0.83rem' }}>
              {node.name}({node.params?.map(p => `${p.name}: ${p.type}`).join(', ') || ''})
            </span>
          )}

          {node.type === 'ReturnStatement' && (
            <code style={{ color: '#fbcfe8', fontSize: '0.8rem', background: 'rgba(0,0,0,0.3)', padding: '2px 6px', borderRadius: '4px' }}>
              Retourner {node.argument}
            </code>
          )}

          {node.type === 'IfStatement' && (
            <code style={{ color: '#fef3c7', fontSize: '0.8rem', background: 'rgba(0,0,0,0.3)', padding: '2px 6px', borderRadius: '4px' }}>
              cond: "{node.condition}"
            </code>
          )}

          {node.type === 'ForLoopStatement' && (
            <code style={{ color: '#e9d5ff', fontSize: '0.8rem', background: 'rgba(0,0,0,0.3)', padding: '2px 6px', borderRadius: '4px' }}>
              {node.iterator} := {node.start} → {node.end}
            </code>
          )}

          {node.type === 'WhileLoopStatement' && (
            <code style={{ color: '#e9d5ff', fontSize: '0.8rem', background: 'rgba(0,0,0,0.3)', padding: '2px 6px', borderRadius: '4px' }}>
              cond: "{node.condition}"
            </code>
          )}

          {node.type === 'CallExpression' && (
            <code style={{ color: '#93c5fd', fontSize: '0.8rem', background: 'rgba(0,0,0,0.3)', padding: '2px 6px', borderRadius: '4px' }}>
              {node.callee}({node.args ? node.args.join(', ') : ''})
            </code>
          )}

          {node.type === 'AssignmentStatement' && (
            <code style={{ color: '#fbbf24', fontSize: '0.8rem', background: 'rgba(0,0,0,0.3)', padding: '2px 6px', borderRadius: '4px' }}>
              {node.target} := {node.expression}
            </code>
          )}

          {node.line && (
            <span style={{ fontSize: '0.68rem', color: '#64748b', background: 'rgba(255,255,255,0.05)', padding: '1px 5px', borderRadius: '3px' }}>
              L{node.line}
            </span>
          )}
        </div>
      </div>

      {/* Program Level Variables Badges */}
      {node.type === 'Program' && node.variables && node.variables.length > 0 && !collapsed && (
        <div style={{ marginLeft: '28px', marginTop: '6px', marginBottom: '4px', display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Variables déclarées:</span>
          {node.variables.map((v, vIdx) => (
            <span key={vIdx} style={{ fontSize: '0.7rem', background: 'rgba(59,130,246,0.15)', color: '#60a5fa', border: '1px solid rgba(59,130,246,0.3)', padding: '1px 6px', borderRadius: '4px' }}>
              {v.name}: <strong style={{ color: '#93c5fd' }}>{v.type}</strong>
            </span>
          ))}
        </div>
      )}

      {/* Sub-Tree Branches */}
      {hasChildren && !collapsed && (
        <div style={{ marginLeft: isRoot ? '12px' : '24px', borderLeft: `2px dashed ${nodeTheme.border}33`, paddingLeft: '8px', marginTop: '4px' }}>
          {children.map((child, idx) => (
            <RealASTTreeNodeGraph
              key={idx}
              node={child}
              isLast={idx === children.length - 1}
              depth={depth + 1}
              isRoot={false}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ── Helper to detect untouched template code on client side ────────────────
function isUntouchedTemplateCode(studentCode, starterTemplate) {
  if (!studentCode || typeof studentCode !== 'string') return true;

  const sanitize = (str) => {
    if (!str || typeof str !== 'string') return '';
    return str
      .replace(/\/\/.*$/gm, '')
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/;/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const cleanCode = sanitize(studentCode);
  if (!cleanCode) return true;

  if (starterTemplate) {
    let tplStr = '';
    if (typeof starterTemplate === 'string') {
      const trimmed = starterTemplate.trim();
      if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
        try {
          const parsed = JSON.parse(trimmed);
          if (parsed && typeof parsed === 'object') {
            tplStr = parsed.ALGO || parsed.code || parsed.PYTHON || '';
          }
        } catch (e) {
          tplStr = starterTemplate;
        }
      } else {
        tplStr = starterTemplate;
      }
    } else if (typeof starterTemplate === 'object' && starterTemplate !== null) {
      tplStr = starterTemplate.ALGO || starterTemplate.code || starterTemplate.PYTHON || '';
    }

    if (typeof tplStr === 'string' && tplStr.trim()) {
      const cleanTpl = sanitize(tplStr);
      const hasPlaceholderMarkers = /(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo|code\s+mod[èe]le)/i.test(tplStr);
      if (hasPlaceholderMarkers && cleanCode.toLowerCase() === cleanTpl.toLowerCase()) {
        return true;
      }
    }
  }

  return false;
}

// ── Multi-Tier AST Structural Semantic Similarity Engine ────────────────────
function calculateCodeSimilarity(studentCode, referenceSolution, starterTemplate = '') {
  if (!studentCode || !referenceSolution) return 0;
  if (studentCode.includes('Code Modèle de Départ') || studentCode.includes('Aucun code rédigé')) return 0;
  if (isUntouchedTemplateCode(studentCode, starterTemplate)) return 0;

  const sanitize = (str) =>
    (str || '').replace(/\/\/.*$/gm, '')
       .replace(/\/\*[\s\S]*?\*\//g, '')
       .replace(/;/g, '')
       .trim();

  const code1 = sanitize(studentCode);
  const code2 = sanitize(referenceSolution);
  const codeTpl = sanitize(starterTemplate);

  if (!code1 || !code2) return 0;

  const ast1 = parsePseudoCodeAST(code1);
  const ast2 = parsePseudoCodeAST(code2);
  const hasPlaceholderMarkers = /(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo|code\s+mod[èe]le)/i.test(starterTemplate || '');
  const astTpl = (codeTpl && hasPlaceholderMarkers) ? parsePseudoCodeAST(codeTpl) : null;

  const extractASTDelta = (body = [], tplBody = []) => {
    if (!tplBody || tplBody.length === 0) return body;
    return body.filter(node => {
      return !tplBody.some(tplNode => tplNode.type === node.type && JSON.stringify(tplNode) === JSON.stringify(node));
    });
  };

  const delta1 = astTpl ? extractASTDelta(ast1?.body, astTpl?.body) : (ast1?.body || []);
  const delta2 = astTpl ? extractASTDelta(ast2?.body, astTpl?.body) : (ast2?.body || []);

  if (astTpl && (!delta1 || delta1.length === 0)) {
    return 0;
  }

  const compareASTBodies = (body1 = [], body2 = []) => {
    if (!body1.length && !body2.length) return 1;
    if (!body1.length || !body2.length) return 0;

    let totalMatches = 0;
    const maxLen = Math.max(body1.length, body2.length);
    const varMap = new Map();
    let varCounter = 1;

    const canonicalExpr = (expr) => {
      if (!expr) return '';
      return expr
        .replace(/[0-9]+/g, ' NUM ')
        .replace(/([^a-z0-9_\u00C0-\u00FF])/gi, ' $1 ')
        .split(/\s+/)
        .filter(Boolean)
        .map(tok => {
          const lower = tok.toLowerCase();
          if (['+', '-', '*', '/', '(', ')', 'num'].includes(lower)) return lower;
          if (!varMap.has(lower)) varMap.set(lower, `VAR_${varCounter++}`);
          return varMap.get(lower);
        })
        .join(' ');
    };

    for (let i = 0; i < maxLen; i++) {
      const n1 = body1[i];
      const n2 = body2[i];

      if (!n1 || !n2) continue;

      if (n1.type !== n2.type) {
        totalMatches += 0.1;
        continue;
      }

      if (n1.type === 'CallExpression') {
        const sameCallee = (n1.callee || '').toLowerCase() === (n2.callee || '').toLowerCase();
        const sameArgCount = (n1.args || []).length === (n2.args || []).length;
        if (sameCallee && sameArgCount) totalMatches += 1.0;
        else if (sameCallee) totalMatches += 0.7;
        else totalMatches += 0.2;
      } else if (n1.type === 'AssignmentStatement') {
        const expr1 = canonicalExpr(n1.expression);
        const expr2 = canonicalExpr(n2.expression);

        if (expr1 === expr2) {
          totalMatches += 1.0;
        } else {
          const set1 = new Set(expr1.split(' '));
          const set2 = new Set(expr2.split(' '));
          let intersect = 0;
          set1.forEach(t => { if (set2.has(t)) intersect++; });
          const union = new Set([...set1, ...set2]).size;
          const overlap = union > 0 ? (intersect / union) : 0;
          totalMatches += 0.3 + 0.6 * overlap;
        }
      } else if (n1.type === 'IfStatement') {
        const subConsequent = compareASTBodies(n1.consequent, n2.consequent);
        const subAlternate = compareASTBodies(n1.alternate, n2.alternate);
        totalMatches += 0.5 * subConsequent + 0.5 * subAlternate;
      } else if (n1.type === 'ForLoopStatement' || n1.type === 'WhileLoopStatement') {
        const subBody = compareASTBodies(n1.body, n2.body);
        totalMatches += subBody;
      } else {
        totalMatches += 0.8;
      }
    }

    return totalMatches / maxLen;
  };

  const targetReferenceBody = (delta2 && delta2.length > 0) ? delta2 : ast2?.body;
  const astSimilarity = compareASTBodies(delta1, targetReferenceBody);

  const canonicalizeTokens = (str) => {
    const keywords = new Set([
      'algorithme', 'variables', 'var', 'debut', 'fin', 'entier', 'reel', 'chaine',
      'booleen', 'tableau', 'de', 'lire', 'ecrire', 'si', 'alors', 'sinon',
      'finsi', 'pour', 'a', 'faire', 'finpour', 'tantque', 'fintantque', 'retourner'
    ]);

    const vMap = new Map();
    let counter = 1;

    return str.toLowerCase()
      .replace(/[0-9]+/g, ' NUM ')
      .replace(/([^a-z0-9_\u00C0-\u00FF])/gi, ' $1 ')
      .split(/\s+/)
      .filter(Boolean)
      .map(tok => {
        if (keywords.has(tok) || /^[^a-z0-9_]$/i.test(tok) || tok === 'NUM') return tok;
        if (!vMap.has(tok)) vMap.set(tok, `VAR_${counter++}`);
        return vMap.get(tok);
      });
  };

  const normTokens1 = canonicalizeTokens(code1);
  const normTokens2 = canonicalizeTokens(code2);

  const getNGrams = (tokens, n = 3) => {
    const grams = new Set();
    for (let i = 0; i <= tokens.length - n; i++) grams.add(tokens.slice(i, i + n).join(' '));
    return grams;
  };

  const grams1 = getNGrams(normTokens1, 3);
  const grams2 = getNGrams(normTokens2, 3);
  let gramIntersect = 0;
  grams1.forEach(g => { if (grams2.has(g)) gramIntersect++; });
  const gramUnion = new Set([...grams1, ...grams2]).size;
  const nGramSim = gramUnion > 0 ? (gramIntersect / gramUnion) : 0;

  const finalScore = Math.round((0.60 * astSimilarity + 0.25 * nGramSim + 0.15 * Math.min(1, normTokens1.length / Math.max(1, normTokens2.length))) * 100);

  return Math.min(100, Math.max(0, finalScore));
}

function getStarterTemplateCode(problem) {
  if (!problem) return '';
  let tCode = problem.templateCode;
  if (typeof tCode === 'string' && tCode.trim()) {
    try {
      const parsed = JSON.parse(tCode);
      if (parsed && typeof parsed === 'object') tCode = parsed;
    } catch (e) {}
  }
  if (typeof tCode === 'object' && tCode !== null) {
    if (typeof tCode.ALGO === 'string' && tCode.ALGO.trim()) return tCode.ALGO;
    if (typeof tCode.code === 'string' && tCode.code.trim()) return tCode.code;
  }
  if (typeof tCode === 'string') return tCode;
  return problem.starterTemplate || '';
}

function getProblemReferenceSolution(problem) {
  if (!problem) return '';
  const safeTitle = (problem.title || 'Exercice').trim();
  let defaultRef = problem.referenceSolution;
  if (defaultRef && defaultRef.trim()) return defaultRef.trim();

  const tpl = getStarterTemplateCode(problem);
  if (tpl && tpl.trim() && !/(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo)/i.test(tpl)) {
    return tpl.trim();
  }

  const lower = safeTitle.toLowerCase();
  if (lower.includes('somme') || lower.includes('add')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   A, B, Somme : Entier\nDEBUT\n   // Solution Repère : Somme de deux entiers\n   Lire(A);\n   Lire(B);\n   Somme := A + B;\n   Ecrire(Somme);\nFIN.`;
  } else if (lower.includes('max') || lower.includes('grand')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   N, i, Val, MaxVal : Entier\nDEBUT\n   // Solution Repère : Recherche du Maximum\n   Lire(N);\n   Lire(MaxVal);\n   Pour i := 2 a N Faire\n      Lire(Val);\n      Si (Val > MaxVal) Alors\n         MaxVal := Val;\n      FinSi;\n   FinPour;\n   Ecrire(MaxVal);\nFIN.`;
  } else if (lower.includes('tri') || lower.includes('bulle')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   T : Tableau [1..100] de Entier\n   N, i, j, Temp : Entier\nDEBUT\n   // Solution Repère : Tri à Bulles\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]) FinPour;\n   Pour i := 1 a N-1 Faire\n      Pour j := 1 a N-i Faire\n         Si (T[j] > T[j+1]) Alors\n            Temp := T[j]; T[j] := T[j+1]; T[j+1] := Temp;\n         FinSi;\n      FinPour;\n   FinPour;\nFIN.`;
  } else if (lower.includes('factorielle') || lower.includes('fact')) {
    return `ALGORITHME Solution_Factorielle\nVARIABLES\n   N, i, Fact : Entier\nDEBUT\n   Lire(N);\n   Fact := 1;\n   Pour i := 1 a N Faire\n      Fact := Fact * i;\n   FinPour;\n   Ecrire(Fact);\nFIN.`;
  } else {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   N, Val_${safeTitle.replace(/\s+/g, '')} : Entier\nDEBUT\n   // Solution Repère pour ${safeTitle}\n   Lire(N);\n   Val_${safeTitle.replace(/\s+/g, '')} := N * 2;\n   Ecrire(Val_${safeTitle.replace(/\s+/g, '')});\nFIN.`;
  }
}

// ── Student-to-Student Similarity Metric Calculator ────────────────────────
function calculateStudentToStudentSimilarity(codeA, codeB) {
  if (!codeA || !codeB) return { astSim: 0, textSim: 0, semSim: 0, totalSim: 0 };

  const normTokens = (str) =>
    str.replace(/\/\/.*/g, '').replace(/[\s;,.\(\)\[\]]+/g, ' ').toLowerCase().trim().split(' ').filter(t => t.length > 1);

  const tokensA = normTokens(codeA);
  const tokensB = normTokens(codeB);
  const setA = new Set(tokensA);
  const setB = new Set(tokensB);

  let intersectCount = 0;
  setA.forEach(t => { if (setB.has(t)) intersectCount++; });
  const unionCount = new Set([...setA, ...setB]).size;
  const textSim = unionCount > 0 ? Math.round((intersectCount / unionCount) * 100) : 0;

  const astSim = calculateCodeSimilarity(codeA, codeB);
  const semSim = Math.round((astSim * 0.6) + (textSim * 0.4));
  const totalSim = Math.round((astSim * 0.5) + (semSim * 0.3) + (textSim * 0.2));

  return { astSim, textSim, semSim, totalSim };
}

// ── Module 2: Interactive Solution Comparison Modal (Student Code ↕ Reference Code & AST) ──
function CompareSolutionsModal({ isOpen, onClose, studentCode, referenceSolution, studentAST, refAST, similarityRatio, modalTitle }) {
  const [showStudentCode, setShowStudentCode] = React.useState(true);
  const [showRefCode, setShowRefCode] = React.useState(true);

  const finalStudentAST = React.useMemo(() => studentAST || (studentCode ? parsePseudoCodeAST(studentCode) : null), [studentAST, studentCode]);
  const finalRefAST = React.useMemo(() => refAST || (referenceSolution ? parsePseudoCodeAST(referenceSolution) : null), [refAST, referenceSolution]);

  if (!isOpen) return null;

  const classification = similarityRatio >= 85
    ? { label: '✅ Structure Équivalente', color: '#34d399', bg: 'rgba(16,185,129,0.18)', border: '#10b981', desc: 'Même structure algorithmique sous-jacente malgré les variations de noms de variables ou de formatage.' }
    : similarityRatio >= 65
    ? { label: '⚡ Structure Similaire', color: '#fbbf24', bg: 'rgba(245,158,11,0.18)', border: '#f59e0b', desc: 'Larges parties de l’algorithme structurellement liées.' }
    : similarityRatio >= 35
    ? { label: '⚠️ Structure Différente', color: '#60a5fa', bg: 'rgba(59,130,246,0.18)', border: '#3b82f6', desc: 'Structure algorithmique sensiblement différente.' }
    : { label: '❌ Structure Incorrecte / Non Conforme', color: '#f87171', bg: 'rgba(239,68,68,0.18)', border: '#ef4444', desc: 'La structure ne réalise pas l’algorithme demandé.' };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(6px)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
      <div className="glass-panel" style={{ width: '94%', maxWidth: '1280px', height: '90vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', border: '1px solid #334155' }}>
        {/* Modal Header */}
        <div style={{ padding: '14px 20px', background: '#0f172a', borderBottom: '1px solid #334155', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <Columns size={20} color="#c084fc" />
            <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: '800', color: '#fff' }}>
              🔍 Comparaison des Solutions &amp; Structures AST {modalTitle ? `(${modalTitle})` : '(Module 2)'}
            </h3>
            <span style={{ padding: '4px 12px', borderRadius: '20px', fontSize: '0.8rem', fontWeight: '800', background: classification.bg, color: classification.color, border: `1px solid ${classification.border}` }}>
              {classification.label} ({similarityRatio}%)
            </span>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '4px' }}>
            <X size={22} />
          </button>
        </div>

        {/* Structural Classification Summary Banner */}
        <div style={{ padding: '10px 20px', background: 'rgba(15, 23, 42, 0.8)', borderBottom: '1px solid #1e293b', fontSize: '0.82rem', color: '#cbd5e1', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ color: classification.color, fontWeight: '700' }}>💡 Analyse Structurelle AST :</span>
          <span>{classification.desc} (Les différences superficielles de noms de variables, d'indentation ou de majuscules sont ignorées).</span>
        </div>

        {/* Comparison Panes Grid */}
        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', padding: '16px', overflow: 'hidden', background: '#05070d' }}>
          {/* Left: Student Code & AST */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', overflow: 'hidden' }}>
            <div style={{ display: 'flex', flexDirection: 'column', background: '#0f172a', borderRadius: '8px', border: '1px solid #1e293b', overflow: 'hidden', flex: showStudentCode ? 1 : 'none' }}>
              <div 
                onClick={() => setShowStudentCode(!showStudentCode)}
                style={{ padding: '8px 14px', background: 'rgba(59,130,246,0.15)', color: '#60a5fa', fontSize: '0.8rem', fontWeight: '700', borderBottom: showStudentCode ? '1px solid #1e293b' : 'none', cursor: 'pointer', userSelect: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
              >
                <span>📄 Code Soumis par l’Étudiant</span>
                <span style={{ fontSize: '0.75rem', color: '#93c5fd' }}>{showStudentCode ? '▲ Réduire' : '▼ Déplier le code'}</span>
              </div>
              {showStudentCode && (
                <pre style={{ flex: 1, margin: 0, padding: '12px', color: '#e2e8f0', fontFamily: 'var(--font-mono)', fontSize: '0.83rem', lineHeight: '1.6', overflowY: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-all', maxHeight: '280px' }}>
                  {studentCode}
                </pre>
              )}
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: '#0f172a', borderRadius: '8px', border: '1px solid #1e293b', overflow: 'hidden' }}>
              <div style={{ padding: '6px 12px', background: 'rgba(168,85,247,0.15)', color: '#c084fc', fontSize: '0.78rem', fontWeight: '700', borderBottom: '1px solid #1e293b' }}>
                🌳 Arbre Syntaxique Abstrait (AST Étudiant)
              </div>
              <div style={{ flex: 1, padding: '10px', overflowY: 'auto' }}>
                {finalStudentAST ? <RealASTTreeNodeGraph node={finalStudentAST} /> : <span style={{ color: '#64748b', fontSize: '0.8rem' }}>AST indisponible</span>}
              </div>
            </div>
          </div>

          {/* Right: Proposed / Reference Code & AST */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', overflow: 'hidden' }}>
            <div style={{ display: 'flex', flexDirection: 'column', background: '#0f172a', borderRadius: '8px', border: '1px solid #1e293b', overflow: 'hidden', flex: showRefCode ? 1 : 'none' }}>
              <div 
                onClick={() => setShowRefCode(!showRefCode)}
                style={{ padding: '8px 14px', background: 'rgba(16,185,129,0.15)', color: '#34d399', fontSize: '0.8rem', fontWeight: '700', borderBottom: showRefCode ? '1px solid #1e293b' : 'none', cursor: 'pointer', userSelect: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
              >
                <span>💡 Solution Proposée / Repère (Enseignant)</span>
                <span style={{ fontSize: '0.75rem', color: '#6ee7b7' }}>{showRefCode ? '▲ Réduire' : '▼ Déplier le code'}</span>
              </div>
              {showRefCode && (
                <pre style={{ flex: 1, margin: 0, padding: '12px', color: '#a7f3d0', fontFamily: 'var(--font-mono)', fontSize: '0.83rem', lineHeight: '1.6', overflowY: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-all', maxHeight: '280px' }}>
                  {referenceSolution}
                </pre>
              )}
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: '#0f172a', borderRadius: '8px', border: '1px solid #1e293b', overflow: 'hidden' }}>
              <div style={{ padding: '6px 12px', background: 'rgba(52,211,153,0.15)', color: '#34d399', fontSize: '0.78rem', fontWeight: '700', borderBottom: '1px solid #1e293b' }}>
                🌳 Arbre Syntaxique Abstrait (AST Solution Proposée)
              </div>
              <div style={{ flex: 1, padding: '10px', overflowY: 'auto' }}>
                {finalRefAST ? <RealASTTreeNodeGraph node={finalRefAST} /> : <span style={{ color: '#64748b', fontSize: '0.8rem' }}>AST indisponible</span>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Student-to-Student Similarity Diff Comparison Modal ───────────────────
function CompareSimilarityModal({ isOpen, onClose, currentStudent, targetStudent, currentCode, targetCode, metrics }) {
  if (!isOpen || !targetStudent) return null;

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(6px)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
      <div className="glass-panel" style={{ width: '94%', maxWidth: '1280px', height: '90vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', border: '1px solid #ef4444' }}>
        {/* Modal Header */}
        <div style={{ padding: '14px 20px', background: '#0f172a', borderBottom: '1px solid #334155', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <AlertTriangle size={20} color="#f87171" />
            <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: '800', color: '#fff' }}>
              ⚠️ Comparaison d’Intégrité Académique entre Étudiants
            </h3>
            <span style={{ padding: '4px 12px', borderRadius: '20px', fontSize: '0.8rem', fontWeight: '800', background: metrics.totalSim >= 85 ? 'rgba(239,68,68,0.2)' : 'rgba(245,158,11,0.2)', color: metrics.totalSim >= 85 ? '#f87171' : '#fbbf24', border: `1px solid ${metrics.totalSim >= 85 ? '#ef4444' : '#f59e0b'}` }}>
              Similarité Globale : {metrics.totalSim}%
            </span>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '4px' }}>
            <X size={22} />
          </button>
        </div>

        {/* Metrics Breakdown Banner */}
        <div style={{ padding: '12px 20px', background: 'rgba(15, 23, 42, 0.9)', borderBottom: '1px solid #1e293b', display: 'flex', gap: '24px', alignItems: 'center', flexWrap: 'wrap', fontSize: '0.85rem' }}>
          <span style={{ color: '#94a3b8', fontWeight: '700' }}>📊 Métriques Calculées :</span>
          <span style={{ color: '#60a5fa' }}>🌳 Similarité AST / Structure : <strong>{metrics.astSim}%</strong></span>
          <span style={{ color: '#c084fc' }}>🔤 Similarité Textuelle : <strong>{metrics.textSim}%</strong></span>
          <span style={{ color: '#34d399' }}>🧠 Similarité Sémantique : <strong>{metrics.semSim}%</strong></span>
          <span style={{ marginLeft: 'auto', fontSize: '0.75rem', color: '#94a3b8', fontStyle: 'italic' }}>
            (Comparaison non-destructive — conserve les soumissions originales des étudiants)
          </span>
        </div>

        {/* Side-by-side Code Diff Panes */}
        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', padding: '16px', overflow: 'hidden', background: '#05070d' }}>
          {/* Student A (Current Student) */}
          <div style={{ display: 'flex', flexDirection: 'column', background: '#0f172a', borderRadius: '8px', border: '1px solid #1e293b', overflow: 'hidden' }}>
            <div style={{ padding: '8px 14px', background: 'rgba(59,130,246,0.15)', color: '#60a5fa', fontSize: '0.8rem', fontWeight: '700', borderBottom: '1px solid #1e293b', display: 'flex', justifyContent: 'space-between' }}>
              <span>👤 Copie A (Actuelle) : Anonyme [{currentAssignment?.accessNumber || 'A'}]</span>
              <span style={{ fontSize: '0.75rem', color: '#93c5fd' }}>Code: {currentAssignment?.accessNumber || 'N/A'}</span>
            </div>
            <pre style={{ flex: 1, margin: 0, padding: '14px', color: '#e2e8f0', fontFamily: 'var(--font-mono)', fontSize: '0.84rem', lineHeight: '1.6', overflowY: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
              {currentCode}
            </pre>
          </div>

          {/* Student B (Similar Student) */}
          <div style={{ display: 'flex', flexDirection: 'column', background: '#0f172a', borderRadius: '8px', border: '1px solid #ef4444', overflow: 'hidden' }}>
            <div style={{ padding: '8px 14px', background: 'rgba(239,68,68,0.15)', color: '#f87171', fontSize: '0.8rem', fontWeight: '700', borderBottom: '1px solid #ef4444', display: 'flex', justifyContent: 'space-between' }}>
              <span>👤 Copie B (Similaire) : Anonyme [{targetStudent?.accessNumber || targetStudent?.studentId || 'B'}]</span>
              <span style={{ fontSize: '0.75rem', color: '#fca5a5' }}>Code: {targetStudent?.accessNumber || 'N/A'}</span>
            </div>
            <pre style={{ flex: 1, margin: 0, padding: '14px', color: '#fca5a5', fontFamily: 'var(--font-mono)', fontSize: '0.84rem', lineHeight: '1.6', overflowY: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
              {targetCode}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Interactive Code Viewer with Line Highlighting & Comments ──────────
function AnnotatedCodeViewer({ code, lineComments = {}, onLineCommentsChange }) {
  const [activeCommentLine, setActiveCommentLine] = useState(null);
  const [newCommentText, setNewCommentText]       = useState('');

  const lines = useMemo(() => {
    if (!code) return [];
    return code.split('\n');
  }, [code]);

  const handleAddComment = (lineNum) => {
    const textToSave = newCommentText.trim();
    let updated;
    if (!textToSave) {
      updated = { ...lineComments };
      delete updated[lineNum];
    } else {
      updated = { ...lineComments, [lineNum]: textToSave };
    }
    onLineCommentsChange(updated);
    setActiveCommentLine(null);
    setNewCommentText('');
  };

  const handleRemoveComment = (lineNum) => {
    const updated = { ...lineComments };
    delete updated[lineNum];
    onLineCommentsChange(updated);
  };

  return (
    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.86rem', lineHeight: '1.6' }}>
      {lines.map((lineText, idx) => {
        const lineNum = idx + 1;
        const comment = lineComments[lineNum];
        const isEditing = activeCommentLine === lineNum;
        const isCommented = !!comment;

        return (
          <React.Fragment key={lineNum}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                background: isCommented
                  ? 'rgba(245, 158, 11, 0.15)'
                  : isEditing
                  ? 'rgba(59, 130, 246, 0.15)'
                  : 'transparent',
                borderLeft: isCommented
                  ? '3px solid #f59e0b'
                  : isEditing
                  ? '3px solid #3b82f6'
                  : '3px solid transparent',
                paddingRight: '12px'
              }}
            >
              <div
                onClick={() => {
                  if (isEditing) setActiveCommentLine(null);
                  else {
                    setActiveCommentLine(lineNum);
                    setNewCommentText(comment || '');
                  }
                }}
                title="Cliquer pour annoter la ligne"
                style={{
                  width: '46px',
                  textAlign: 'right',
                  paddingRight: '12px',
                  color: isCommented ? '#fbbf24' : 'var(--text-muted)',
                  userSelect: 'none',
                  cursor: 'pointer',
                  fontSize: '0.78rem',
                  fontWeight: isCommented ? '700' : '400'
                }}
              >
                {lineNum} {isCommented ? '💬' : ''}
              </div>

              <div style={{ flex: 1, whiteSpace: 'pre-wrap', wordBreak: 'break-all', color: isCommented ? '#fef3c7' : '#f3f4f6' }}>
                {lineText || ' '}
              </div>

              <button
                onClick={() => {
                  if (isEditing) setActiveCommentLine(null);
                  else {
                    setActiveCommentLine(lineNum);
                    setNewCommentText(comment || '');
                  }
                }}
                style={{
                  background: 'none', border: 'none', color: isCommented ? '#fbbf24' : 'var(--text-muted)',
                  cursor: 'pointer', opacity: isCommented ? 1 : 0.4, fontSize: '0.8rem', padding: '0 4px'
                }}
                title="Ajouter une remarque"
              >
                💬
              </button>
            </div>

            {isEditing && (
              <div style={{
                margin: '4px 16px 6px 48px', padding: '8px 12px', background: '#1e1b4b',
                border: '1px solid #6366f1', borderRadius: '8px', display: 'flex', gap: '8px', alignItems: 'center'
              }}>
                <span style={{ fontSize: '0.8rem', color: '#c084fc', fontWeight: '700' }}>💬 Ligne {lineNum}:</span>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Remarque..."
                  value={newCommentText}
                  onChange={e => setNewCommentText(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleAddComment(lineNum);
                    if (e.key === 'Escape') setActiveCommentLine(null);
                  }}
                  autoFocus
                  style={{ flex: 1, padding: '4px 8px', fontSize: '0.82rem' }}
                />
                <button className="btn btn-primary" onClick={() => handleAddComment(lineNum)} style={{ padding: '4px 10px', fontSize: '0.78rem' }}>
                  Enregistrer
                </button>
                <button className="btn btn-secondary" onClick={() => setActiveCommentLine(null)} style={{ padding: '4px 8px', fontSize: '0.78rem' }}>
                  Annuler
                </button>
              </div>
            )}

            {isCommented && !isEditing && (
              <div style={{
                margin: '2px 16px 6px 48px', padding: '6px 12px', background: 'rgba(30, 27, 75, 0.95)',
                border: '1px solid rgba(168, 85, 247, 0.4)', borderRadius: '6px', color: '#e9d5ff',
                fontSize: '0.8rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
                <div>
                  <strong style={{ color: '#c084fc', marginRight: '6px' }}>💬 Remarque Ligne {lineNum}:</strong>
                  <span>{comment}</span>
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button onClick={() => { setActiveCommentLine(lineNum); setNewCommentText(comment); }} style={{ background: 'none', border: 'none', color: '#c084fc', cursor: 'pointer', fontSize: '0.75rem' }}>
                    ✏️
                  </button>
                  <button onClick={() => handleRemoveComment(lineNum)} style={{ background: 'none', border: 'none', color: '#f87171', cursor: 'pointer', fontSize: '0.75rem' }}>
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

export default function CorrectionWorkspace({ examId, onBack, onViewResults }) {
  const [data, setData]             = useState(null);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState(null);

  // Navigation state
  const [studentIdx, setStudentIdx] = useState(0);
  const [problemIdx, setProblemIdx] = useState(0);

  // Assistance tools state
  const [showDiff, setShowDiff]         = useState(true);
  const [showASTModal, setShowASTModal] = useState(false);
  const [showCompareSolutionsModal, setShowCompareSolutionsModal] = useState(false);
  const [similarityCompareModal, setSimilarityCompareModal] = useState({ isOpen: false, targetStudent: null, targetCode: '', metrics: null });
  const [similarityThreshold, setSimilarityThreshold] = useState(70);
  const [selectedQuestionCompare, setSelectedQuestionCompare] = useState(null);

  const [syntaxReport, setSyntaxReport] = useState(null);
  const [analyzing, setAnalyzing]       = useState(false);
  const [sandboxInput, setSandboxInput] = useState('');
  const [sandboxOutput, setSandboxOutput] = useState(null);
  const [executingSandbox, setExecutingSandbox] = useState(false);
  const [hiddenTestResults, setHiddenTestResults] = useState(null);

  // Module 3 Local AI Evaluation State
  const [aiEvaluationMap, setAiEvaluationMap] = useState({});
  const [selectedAIModel, setSelectedAIModel] = useState('qwen1_5b');
  const aiEvaluatedKeysRef = React.useRef(new Set()); // tracks keys already evaluated/loading

  // Auto-Evaluated Student Test Pass Status Map: { [testCaseId]: { passed: boolean, actualOutput: string } }
  const [studentTestStatusMap, setStudentTestStatusMap] = useState({});

  // Teacher Code Editor & View Tabs
  const [activeCodeView, setActiveCodeView]   = useState('ORIGINAL');
  const [correctedCodeInput, setCorrectedCodeInput] = useState('');

  // Form state & Persistent Line Comments Dictionary per Problem
  const [exerciseScores, setExerciseScores] = useState({});
  const [lineCommentsMapByProblem, setLineCommentsMapByProblem] = useState({});
  const [generalFeedbackInput, setGeneralFeedbackInput] = useState('');
  const [isManualFeedbackEdit, setIsManualFeedbackEdit] = useState(false);
  const [savingStatus, setSavingStatus] = useState('');

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getExamGradingData(examId);
      setData(res);
    } catch (err) {
      console.error('Failed to load grading data:', err);
      setError(err.data?.error || err.message || 'Erreur lors du chargement des données.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [examId]);

  const currentAssignment = useMemo(() => {
    if (!data || !data.assignments || data.assignments.length === 0) return null;
    return data.assignments[studentIdx] || null;
  }, [data, studentIdx]);

  const currentStudent = useMemo(() => {
    return currentAssignment?.student || null;
  }, [currentAssignment]);

  const currentProblem = useMemo(() => {
    if (!data || !data.problems || data.problems.length === 0) return null;
    return data.problems[problemIdx] || null;
  }, [data, problemIdx]);

  const currentSubmission = useMemo(() => {
    if (!data || !currentStudent || !currentProblem) return null;
    return data.submissions.find(
      s => s.studentId === currentStudent.id && s.problemId === currentProblem.id
    ) || null;
  }, [data, currentStudent, currentProblem]);

  const { studentCode, isCustomCode } = useMemo(() => {
    const starterTpl = getStarterTemplateCode(currentProblem);
    const sanitize = (str) => (str || '').replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').replace(/;/g, '').replace(/\s+/g, ' ').trim();

    if (currentSubmission?.sourceCode && currentSubmission.sourceCode.trim()) {
      const cleanSub = sanitize(currentSubmission.sourceCode);
      const cleanTpl = sanitize(starterTpl);
      const hasPlaceholderMarkers = /(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo|code\s+mod[èe]le)/i.test(starterTpl);
      const isUntouched = hasPlaceholderMarkers && cleanTpl && cleanSub.toLowerCase() === cleanTpl.toLowerCase();
      return { studentCode: currentSubmission.sourceCode, isCustomCode: !isUntouched };
    }
    const extracted = extractCodeFromMap(currentAssignment?.currentCodeMap, currentProblem?.id);
    if (extracted && extracted.trim()) {
      const cleanExt = sanitize(extracted);
      const cleanTpl = sanitize(starterTpl);
      const hasPlaceholderMarkers = /(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo|code\s+mod[èe]le)/i.test(starterTpl);
      const isUntouched = hasPlaceholderMarkers && cleanTpl && cleanExt.toLowerCase() === cleanTpl.toLowerCase();
      return { studentCode: extracted, isCustomCode: !isUntouched };
    }

    if (starterTpl && starterTpl.trim()) {
      return { studentCode: starterTpl, isCustomCode: false };
    }

    const defaultTemplate = `ALGORITHME ${(currentProblem?.title || 'Exercice').replace(/\s+/g, '_')}\nVARIABLES\n   // [Code Modèle de Départ]\n   // L'étudiant n'a pas rédigé de solution personnalisée\nDEBUT\n   // Indiquez votre algorithme ici\nFIN.`;

    return { studentCode: defaultTemplate, isCustomCode: false };
  }, [currentSubmission, currentAssignment, currentProblem]);

  const effectiveRefSolution = useMemo(() => {
    return currentProblem?.referenceSolution || getProblemReferenceSolution(currentProblem) || '';
  }, [currentProblem]);

  const similarityRatio = useMemo(() => {
    if (!effectiveRefSolution || !studentCode) return 0;
    const starterTpl = getStarterTemplateCode(currentProblem);
    return calculateCodeSimilarity(studentCode, effectiveRefSolution, starterTpl);
  }, [studentCode, effectiveRefSolution, currentProblem]);

  // AST Trees for Student Code & Reference Solution
  const studentAST = useMemo(() => parsePseudoCodeAST(studentCode), [studentCode]);
  const refAST = useMemo(() => parsePseudoCodeAST(effectiveRefSolution), [effectiveRefSolution]);

  // Student Plagiarism / Similarity Analysis across all submitted copies for active exercise
  const similarStudents = useMemo(() => {
    if (!data || !data.assignments || !currentProblem || !studentCode || !currentStudent) return [];

    const results = [];
    data.assignments.forEach(a => {
      if (!a.student || a.studentId === currentStudent.id) return;

      const otherSub = data.submissions.find(s => s.studentId === a.studentId && s.problemId === currentProblem.id);
      const otherCodeMap = extractCodeFromMap(a.currentCodeMap, currentProblem.id);
      const otherCode = otherSub?.sourceCode || otherCodeMap || '';

      if (!otherCode || otherCode.includes('Code Modèle de Départ') || otherCode.trim().length < 20) return;

      const metrics = calculateStudentToStudentSimilarity(studentCode, otherCode);
      if (metrics.totalSim >= similarityThreshold) {
        results.push({
          student: a.student,
          accessNumber: a.accessNumber,
          submissionCode: otherCode,
          metrics
        });
      }
    });

    return results.sort((x, y) => y.metrics.totalSim - x.metrics.totalSim);
  }, [data, currentProblem, currentStudent, studentCode, similarityThreshold]);

  // Fetch Module 3 Local AI Evaluation
  const fetchAIEvaluation = useCallback(async (force = false) => {
    if (!currentProblem || !currentStudent) return;
    const key = `${currentStudent.id}_${currentProblem.id}`;

    if (!studentCode || !studentCode.trim()) {
      setAiEvaluationMap(prev => ({
        ...prev,
        [key]: {
          loading: false,
          result: {
            module3_ai: {
              score: 0,
              scoreOut10: 0,
              evaluationDetails: {
                classification: 'Copie Blanche',
                strengths: [],
                errors: ['Aucun code soumis par l\'étudiant.'],
                feedback_fr: 'Copie blanche : aucun code rédigé par l\'étudiant (note 0/20).'
              }
            }
          },
          error: null
        }
      }));
      return;
    }

    // Use ref to check without stale closure — avoids infinite loop
    if (force) aiEvaluatedKeysRef.current.delete(key);
    if (!force && aiEvaluatedKeysRef.current.has(key)) return;

    aiEvaluatedKeysRef.current.add(key);
    setAiEvaluationMap(prev => ({
      ...prev,
      [key]: { loading: true, result: null, error: null }
    }));

    try {
      const res = await evaluateAIModule(
        currentProblem.id,
        studentCode,
        { sandbox: 50, ast: 25, ai: 25 },
        selectedAIModel
      );

      setAiEvaluationMap(prev => ({
        ...prev,
        [key]: { loading: false, result: res, error: null }
      }));

      // Auto-populate score field with 3-module composite score IF not set
      if (res && res.compositeScore && currentProblem?.id) {
        const earned = res.compositeScore.earnedPoints ?? Math.round(((res.compositeScore.scorePct || 0) / 100) * (currentProblem.points || 5) * 10) / 10;
        setExerciseScores(prev => {
          if (prev[currentProblem.id] === undefined || prev[currentProblem.id] === '' || prev[currentProblem.id] === null) {
            return { ...prev, [currentProblem.id]: earned };
          }
          return prev;
        });
      }
    } catch (err) {
      console.error('AI Evaluation error:', err);
      setAiEvaluationMap(prev => ({
        ...prev,
        [key]: { loading: false, result: null, error: err.data?.error || err.message || 'Le modele IA local n\'a pas repondu.' }
      }));
    }
  }, [currentProblem, studentCode, currentStudent, selectedAIModel]);

  // Explicit Manual Calculation handler for active or target problem
  const [isCalculatingExercise, setIsCalculatingExercise] = useState(false);

  const handleCalculateExerciseScore = async (targetProbId) => {
    const probId = targetProbId || currentProblem?.id;
    if (!probId || !currentStudent || isCalculatingExercise) return;

    const prob = data?.problems?.find(p => p.id === probId) || currentProblem;
    if (!prob) return;

    setIsCalculatingExercise(true);
    setSavingStatus('Calcul de la note côté serveur...');

    try {
      const res = await calculateExerciseGrade(examId, {
        studentId: currentStudent.id,
        problemId: probId,
        forceRunTests: true
      });

      setData(prev => {
        if (!prev) return prev;
        const updatedSubmissions = [...prev.submissions];
        const existingIdx = updatedSubmissions.findIndex(
          s => s.studentId === currentStudent.id && s.problemId === probId
        );
        if (existingIdx >= 0) updatedSubmissions[existingIdx] = res.submission;
        else updatedSubmissions.push(res.submission);

        const updatedAssignments = prev.assignments.map(a =>
          a.studentId === currentStudent.id
            ? { ...a, ...res.assignment, student: res.assignment?.student || a.student }
            : a
        );

        return { ...prev, submissions: updatedSubmissions, assignments: updatedAssignments };
      });

      const breakdown = res.submission?.evaluationBreakdown;
      if (breakdown?.testResults && probId === currentProblem?.id) {
        setHiddenTestResults(breakdown.testResults);
      }

      setExerciseScores(prev => ({ ...prev, [probId]: res.submission.manualScore }));
      setSavingStatus('Calcul effectué & enregistré');
      setTimeout(() => setSavingStatus(''), 1500);

      if (probId === currentProblem?.id) {
        fetchAIEvaluation(true);
      }

      const maxPts = prob.points || 20;
      Swal.fire({
        icon: 'success',
        title: 'Note Calculée !',
        text: `Exercice "${prob.title}" : ${res.submission.manualScore} / ${maxPts} pts (Calculé côté serveur)`,
        timer: 1500,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Calculate exercise score error:', err);
      setSavingStatus('Erreur de calcul');
    } finally {
      setIsCalculatingExercise(false);
    }
  };

  // Live Test Suite Summary Metrics
  const testSummary = useMemo(() => {
    if (!currentProblem?.testCases || currentProblem.testCases.length === 0) return null;
    const tcs = currentProblem.testCases;
    const publicTCs = tcs.filter(tc => tc.isPublic);
    const hiddenTCs = tcs.filter(tc => !tc.isPublic);

    let publicPassed = 0;
    let hiddenPassed = 0;
    let evaluatedCount = 0;

    tcs.forEach(tc => {
      const status = studentTestStatusMap[tc.id];
      if (status) {
        evaluatedCount++;
        if (status.passed) {
          if (tc.isPublic) publicPassed++;
          else hiddenPassed++;
        }
      }
    });

    const totalPassed = publicPassed + hiddenPassed;

    return {
      totalCount: tcs.length,
      evaluatedCount,
      totalPassed,
      publicTotal: publicTCs.length,
      publicPassed,
      hiddenTotal: hiddenTCs.length,
      hiddenPassed,
      allPassed: evaluatedCount === tcs.length && totalPassed === tcs.length
    };
  }, [currentProblem, studentTestStatusMap]);

  // Total Max Points
  const totalExamMaxPoints = useMemo(() => {
    if (!data || !data.problems) return 0;
    return data.problems.reduce((sum, p) => sum + (p.points || 0), 0);
  }, [data]);

  const [subQuestionScores, setSubQuestionScores] = useState({});

  // Sync exerciseScores & lineComments map when student changes
  useEffect(() => {
    if (!data || !currentStudent) return;

    const scores = {};
    const commentsMap = {};
    const subQMap = {};

    data.problems.forEach(p => {
      const sub = data.submissions.find(s => s.studentId === currentStudent.id && s.problemId === p.id);
      const starterTpl = getStarterTemplateCode(p);
      const isUntouched = isUntouchedTemplateCode(sub?.sourceCode, starterTpl);

      if (sub && sub.manualScore !== null && sub.manualScore !== undefined) {
        scores[p.id] = sub.manualScore;
      } else {
        scores[p.id] = '';
      }

      if (sub?.teacherFeedback) {
        try {
          const parsed = JSON.parse(sub.teacherFeedback);
          if (parsed && parsed.lineComments) {
            commentsMap[p.id] = parsed.lineComments;
          }
        } catch (e) {}
      }

      if (sub?.evaluationBreakdown?.questionsBreakdown) {
        const qMap = {};
        sub.evaluationBreakdown.questionsBreakdown.forEach(qb => {
          qMap[qb.questionId || qb.orderIndex] = qb.pointsAwarded;
        });
        subQMap[p.id] = qMap;
      }
    });

    setExerciseScores(scores);
    setLineCommentsMapByProblem(commentsMap);
    setSubQuestionScores(subQMap);

    if (currentAssignment?.generalFeedback) {
      setGeneralFeedbackInput(currentAssignment.generalFeedback);
      setIsManualFeedbackEdit(true);
    } else {
      setIsManualFeedbackEdit(false);
    }
  }, [studentIdx, currentStudent?.id, data?.submissions]);

  // Sync problem-specific corrected version code when exercise tab changes
  useEffect(() => {
    if (currentSubmission?.teacherFeedback) {
      try {
        const parsed = JSON.parse(currentSubmission.teacherFeedback);
        if (parsed && typeof parsed === 'object') {
          setCorrectedCodeInput(parsed.versionCorrige || '');
        } else {
          setCorrectedCodeInput('');
        }
      } catch (e) {
        setCorrectedCodeInput('');
      }
    } else {
      setCorrectedCodeInput('');
    }

    setSyntaxReport(null);
    setSandboxOutput(null);
    setHiddenTestResults(null);
  }, [problemIdx, currentSubmission]);

  // Active Line Comments for current problem
  const activeLineComments = useMemo(() => {
    return lineCommentsMapByProblem[currentProblem?.id] || [];
  }, [lineCommentsMapByProblem, currentProblem]);

  const handleAddLineComment = (lineNum, text) => {
    if (!currentProblem?.id || !text.trim()) return;
    const existing = lineCommentsMapByProblem[currentProblem.id] || [];
    const updated = [...existing.filter(c => c.line !== lineNum), { line: lineNum, comment: text.trim() }];

    setLineCommentsMapByProblem(prev => ({ ...prev, [currentProblem.id]: updated }));
    handleSaveGrade(currentProblem.id, undefined, updated, undefined, undefined);
  };

  const handleRemoveLineComment = (lineNum) => {
    if (!currentProblem?.id) return;
    const existing = lineCommentsMapByProblem[currentProblem.id] || [];
    const updated = existing.filter(c => c.line !== lineNum);

    setLineCommentsMapByProblem(prev => ({ ...prev, [currentProblem.id]: updated }));
    handleSaveGrade(currentProblem.id, undefined, updated, undefined, undefined);
  };

  // Calculate live total raw earned & scaled /20 score
  const totalRawEarned = useMemo(() => {
    if (!data || !data.problems) return 0;
    let total = 0;
    data.problems.forEach(p => {
      const val = exerciseScores[p.id];
      if (val !== '' && val !== null && val !== undefined) {
        total += parseFloat(val) || 0;
      }
    });
    return Math.round(total * 100) / 100;
  }, [data, exerciseScores]);

  const scaledGrade20 = useMemo(() => {
    if (totalExamMaxPoints <= 0) return '0.00';
    return ((totalRawEarned / totalExamMaxPoints) * 20).toFixed(2);
  }, [totalRawEarned, totalExamMaxPoints]);

  // Auto-track score changes to update suggested general feedback if not manually edited
  useEffect(() => {
    if (!isManualFeedbackEdit) {
      const suggested = getSuggestedAppreciation(scaledGrade20);
      setGeneralFeedbackInput(suggested);
    }
  }, [scaledGrade20, isManualFeedbackEdit, studentIdx]);

  // Auto-save grade for an exercise on change & serialize line comments + version corriger
  const saveGradeTimeoutRef = useRef(null);

  const debouncedSaveProblemGrade = useCallback((targetProbId, numVal, updatedQuestionScores, delay = 500) => {
    if (saveGradeTimeoutRef.current) {
      clearTimeout(saveGradeTimeoutRef.current);
    }
    setSavingStatus('Enregistrement...');

    saveGradeTimeoutRef.current = setTimeout(async () => {
      if (!currentStudent || !targetProbId) return;

      const feedbackPayload = JSON.stringify({
        lineComments: activeLineComments,
        versionCorrige: correctedCodeInput
      });

      try {
        const res = await saveProblemGrade(examId, {
          studentId: currentStudent.id,
          problemId: targetProbId,
          manualScore: numVal,
          teacherFeedback: feedbackPayload,
          questionScores: updatedQuestionScores
        });

        // Update assignments & submissions in global state without resetting local inputs
        setData(prev => {
          if (!prev) return prev;
          const updatedSubmissions = [...prev.submissions];
          const existingIdx = updatedSubmissions.findIndex(
            s => s.studentId === currentStudent.id && s.problemId === targetProbId
          );
          if (existingIdx >= 0) updatedSubmissions[existingIdx] = res.submission;
          else updatedSubmissions.push(res.submission);

          const updatedAssignments = prev.assignments.map(a =>
            a.studentId === currentStudent.id
              ? { ...a, ...res.assignment, student: res.assignment?.student || a.student }
              : a
          );

          return { ...prev, submissions: updatedSubmissions, assignments: updatedAssignments };
        });

        setSavingStatus('Modifications enregistrées');
        setTimeout(() => setSavingStatus(''), 1500);
      } catch (err) {
        console.error('Save grade error:', err);
        setSavingStatus('Erreur de sauvegarde');
      }
    }, delay);
  }, [currentStudent, activeLineComments, correctedCodeInput, examId]);

  const handleSaveGrade = async (targetProbId, rawVal, updatedLineComments, updatedVersionCorrige, updatedQuestionScores) => {
    if (!currentStudent || !targetProbId) return;

    const val = rawVal !== undefined ? rawVal : exerciseScores[targetProbId];
    const numVal = val === '' || val === null || val === undefined ? null : parseFloat(val);

    const commentsToSave = updatedLineComments !== undefined ? updatedLineComments : activeLineComments;
    const versionToSave  = updatedVersionCorrige !== undefined ? updatedVersionCorrige : correctedCodeInput;
    const qScoresToSave  = updatedQuestionScores !== undefined ? updatedQuestionScores : subQuestionScores[targetProbId];

    const feedbackPayload = JSON.stringify({
      lineComments: commentsToSave,
      versionCorrige: versionToSave
    });

    setSavingStatus('Enregistrement...');

    try {
      const res = await saveProblemGrade(examId, {
        studentId: currentStudent.id,
        problemId: targetProbId,
        manualScore: numVal,
        teacherFeedback: feedbackPayload,
        questionScores: qScoresToSave
      });

      setData(prev => {
        if (!prev) return prev;
        const updatedSubmissions = [...prev.submissions];
        const existingIdx = updatedSubmissions.findIndex(
          s => s.studentId === currentStudent.id && s.problemId === targetProbId
        );
        if (existingIdx >= 0) updatedSubmissions[existingIdx] = res.submission;
        else updatedSubmissions.push(res.submission);

        const updatedAssignments = prev.assignments.map(a =>
          a.studentId === currentStudent.id
            ? { ...a, ...res.assignment, student: res.assignment?.student || a.student }
            : a
        );

        return { ...prev, submissions: updatedSubmissions, assignments: updatedAssignments };
      });

      setSavingStatus('Modifications enregistrées');
      setTimeout(() => setSavingStatus(''), 1500);
    } catch (err) {
      console.error(err);
      setSavingStatus('Erreur de sauvegarde');
    }
  };

  // Wrapper for score input changes (Immediate local update + Debounced persistence)
  const handleScoreChange = (probId, rawVal) => {
    const pMax = data?.problems?.find(p => p.id === probId)?.points || 100;
    setExerciseScores(prev => ({ ...prev, [probId]: rawVal }));

    if (rawVal === '' || rawVal === null) {
      debouncedSaveProblemGrade(probId, null, undefined, 500);
    } else {
      const parsed = parseFloat(rawVal);
      if (!isNaN(parsed)) {
        const rounded = roundToNextQuarterPoint(Math.min(pMax, Math.max(0, parsed)), pMax);
        debouncedSaveProblemGrade(probId, rounded, undefined, 500);
      }
    }
  };

  // Direct editing of individual question score in multi-question problem
  const handleSubQuestionScoreChange = (probId, qKey, rawVal, qMax) => {
    setSubQuestionScores(prev => {
      const probMap = { ...(prev[probId] || {}) };
      probMap[qKey] = rawVal;

      let sum = 0;
      const numScoresMap = {};
      Object.entries(probMap).forEach(([k, v]) => {
        const pNum = parseFloat(v);
        if (!isNaN(pNum)) {
          const roundedQ = roundToNextQuarterPoint(Math.min(qMax || 100, Math.max(0, pNum)), qMax);
          numScoresMap[k] = roundedQ;
          sum += roundedQ;
        }
      });

      const pMax = data?.problems?.find(p => p.id === probId)?.points || 20;
      const roundedTotal = roundToNextQuarterPoint(sum, pMax);

      setExerciseScores(prevScores => ({ ...prevScores, [probId]: rawVal === '' && sum === 0 ? '' : roundedTotal }));
      debouncedSaveProblemGrade(probId, roundedTotal, numScoresMap, 500);

      return { ...prev, [probId]: probMap };
    });
  };

  // Update line comments for active exercise
  const handleLineCommentsChange = (newComments) => {
    if (!currentProblem) return;
    const probId = currentProblem.id;
    setLineCommentsMapByProblem(prev => ({
      ...prev,
      [probId]: newComments
    }));
    handleSaveGrade(probId, undefined, newComments, undefined);
  };

  // Save Teacher Version Corrigée
  const handleSaveCorrectedCode = () => {
    handleSaveGrade(currentProblem?.id, undefined, undefined, correctedCodeInput);
    Swal.fire({
      icon: 'success',
      title: 'Version Corrigée Enregistrée !',
      text: 'La solution corrigée par l’enseignant a été sauvegardée pour cet exercice.',
      timer: 1500,
      showConfirmButton: false,
      background: '#111827', color: '#fff'
    });
  };

  const [isValidatingCopy, setIsValidatingCopy] = useState(false);

  // Single Validation Button: Mark student copy as GRADED
  const handleValidateStudentCopy = async () => {
    if (!currentStudent || isValidatingCopy) return;
    setIsValidatingCopy(true);
    const assignmentsList = data?.assignments || [];

    try {
      const res = await updateGeneralFeedback(examId, {
        studentId: currentAssignment?.studentId || currentStudent.id,
        generalFeedback: generalFeedbackInput,
        gradingStatus: 'GRADED'
      });

      setData(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          assignments: prev.assignments.map(a =>
            a.studentId === currentStudent.id ? res.assignment : a
          )
        };
      });

      const nameToDisplay = `Copie [${currentAssignment?.accessNumber || 'Anonyme'}]`;

      Swal.fire({
        icon: 'success',
        title: `${nameToDisplay} Validée !`,
        html: `Note Finale Scalée : <strong>${scaledGrade20} / 20</strong>`,
        timer: 1500,
        showConfirmButton: false,
        background: '#111827', color: '#fff'
      });

      if (studentIdx < assignmentsList.length - 1) {
        setStudentIdx(prev => prev + 1);
      }
    } catch (err) {
      console.error('Validation error:', err);
      Swal.fire({ icon: 'error', title: 'Erreur', text: err.data?.error || err.message || 'Erreur lors de la validation.', background: '#111827', color: '#fff' });
    } finally {
      setIsValidatingCopy(false);
    }
  };

  // Keyboard Shortcuts: Up/Down for Exercises, Shift+Up/Down or PageUp/PageDown for Students, Enter to Validate
  useEffect(() => {
    const handleKeyDown = (e) => {
      const activeEl = document.activeElement;
      const isInputFocused = activeEl && (
        ['INPUT', 'TEXTAREA', 'SELECT'].includes(activeEl.tagName) ||
        activeEl.isContentEditable
      );

      // Enter key (Ctrl+Enter or Enter when not inside a multi-line textarea) to trigger Validation
      if (e.key === 'Enter') {
        const isMultiLineTextarea = activeEl && activeEl.tagName === 'TEXTAREA';
        if (e.ctrlKey || !isMultiLineTextarea) {
          if (!isValidatingCopy && currentStudent) {
            e.preventDefault();
            handleValidateStudentCopy();
          }
          return;
        }
      }

      // If active focus is typing inside an input/textarea, do not trigger arrow navigation
      if (isInputFocused) return;

      const assignmentsCount = data?.assignments?.length || 0;
      const problemsCount    = data?.problems?.length || 0;

      // Left / Right arrows for Student switching
      if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        setStudentIdx(prev => Math.max(0, prev - 1));
      } else if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        e.preventDefault();
        setStudentIdx(prev => Math.min(assignmentsCount - 1, prev + 1));
      }
      // Up / Down arrows for Exercise switching
      else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setProblemIdx(prev => Math.max(0, prev - 1));
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setProblemIdx(prev => Math.min(problemsCount - 1, prev + 1));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [data, isValidatingCopy, currentStudent, handleValidateStudentCopy]);

  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  // Trigger PDF Generation & Streaming for current student copy
  const handleDownloadPDF = async () => {
    if (!currentStudent || isGeneratingPDF) return;
    setIsGeneratingPDF(true);
    try {
      const blob = await downloadStudentPDFBlob(examId, currentStudent.id);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const safeCode = (currentAssignment?.accessNumber || 'Anonyme').replace(/[^\w]/g, '_');
      a.download = `Copie_Anonyme_${safeCode}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      console.error('PDF download error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur PDF',
        text: 'Impossible de générer le document PDF.',
        background: '#111827', color: '#fff'
      });
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const [isGeneratingAllPDF, setIsGeneratingAllPDF] = useState(false);
  const [zipProgress, setZipProgress] = useState(null);

  const handleDownloadAllPDFs = async () => {
    if (isGeneratingAllPDF) return;
    setIsGeneratingAllPDF(true);
    setZipProgress({ done: 0, total: 0, studentName: '', status: 'start' });

    const socket = getSocket();
    joinExamRoom(examId, null, true);

    const onProgress = (payload) => {
      setZipProgress(payload);
      if (payload.status === 'done') socket.off('pdf_zip_progress', onProgress);
    };
    socket.on('pdf_zip_progress', onProgress);

    try {
      const blob = await downloadAllStudentPDFBlob(examId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Copies_' + (data?.exam?.title?.replace(/[^\w]/g, '_') || 'Examen') + '.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('All PDFs download error:', err);
      socket.off('pdf_zip_progress', onProgress);
      Swal.fire({ icon: 'error', title: 'Erreur ZIP', text: 'Impossible de générer l’archive ZIP.', background: '#111827', color: '#fff' });
    } finally {
      setIsGeneratingAllPDF(false);
      setTimeout(() => setZipProgress(null), 2500);
    }
  };

  const [isFinalizing, setIsFinalizing] = useState(false);

  // Finalize Correction & Unlock De-Anonymized Results
  const handleFinalizeCorrection = async () => {
    const assignmentsList = data?.assignments || [];
    const uncorrectedCount = assignmentsList.filter(a => a.gradingStatus !== 'GRADED').length;

    if (assignmentsList.length > 0 && uncorrectedCount > 0) {
      Swal.fire({
        icon: 'warning',
        title: 'Correction Incomplète',
        html: `
          <div style="text-align: left; font-size: 0.9rem; color: #cbd5e1; line-height: 1.5;">
            <p>Toutes les copies doivent être validées avant de pouvoir terminer la correction.</p>
            <div style="margin: 12px 0; padding: 10px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239,68,68,0.3); border-radius: 6px;">
              <p style="margin: 0; color: #f87171; font-weight: 700;">
                ⚠️ Il reste encore <strong>${uncorrectedCount} copie(s) non validée(s)</strong> (${gradedCount}/${assignmentsList.length} corrigées).
              </p>
            </div>
            <p style="font-size: 0.82rem; color: #94a3b8;">Parcourez chaque copie et cliquez sur <strong>« ✅ Valider cette Copie »</strong> pour confirmer sa note finale.</p>
          </div>
        `,
        confirmButtonText: 'Compris',
        confirmButtonColor: '#3b82f6',
        background: '#111827',
        color: '#fff'
      });
      return;
    }

    const result = await Swal.fire({
      title: '🔒 Clôturer la Correction ?',
      html: `
        <div style="text-align: left; font-size: 0.9rem; color: #cbd5e1; line-height: 1.5;">
          <p>Toutes les copies (<strong>${gradedCount} / ${assignmentsList.length}</strong>) ont été validées.</p>
          <p>Vous êtes sur le point de <strong>clôturer définitivement la correction</strong> de cet examen.</p>
          <p style="margin-top: 10px; color: #60a5fa;">🔓 Cette action dé-anonymisera les copies et vous redirigera vers la vue des <strong>Résultats Officiels</strong> (avec noms réels, matricules, export des notes et génération de tous les PDF/ZIP).</p>
        </div>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: '✅ Oui, Clôturer & Dé-anonymiser',
      cancelButtonText: 'Annuler',
      confirmButtonColor: '#10b981',
      cancelButtonColor: '#64748b',
      background: '#111827',
      color: '#fff'
    });

    if (!result.isConfirmed) return;

    setIsFinalizing(true);
    try {
      await finalizeExamCorrection(examId);
      Swal.fire({
        icon: 'success',
        title: 'Correction Clôturée !',
        text: 'Les résultats sont dé-anonymisés. Redirection vers la vue des résultats...',
        timer: 1800,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
      setTimeout(() => {
        if (onViewResults) {
          onViewResults();
        } else {
          onBack();
        }
      }, 1500);
    } catch (err) {
      console.error('Finalize correction error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur',
        text: err.data?.error || err.message || 'Impossible de clôturer la correction.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setIsFinalizing(false);
    }
  };

  // Export Encrypted Submission Bundle (Zero-prompt 1-click export using system vault key)
  const handleExportSubmissionBundle = async () => {
    try {
      const encryptedData = await exportExamBundle(examId);
      const jsonStr = JSON.stringify(encryptedData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Paquet_Soumissions_${(data?.exam?.title || 'Examen').replace(/[^\w]/g, '_')}.algobundle`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: '📦 Paquet Exporté !',
        text: 'Le fichier chiffré .algobundle a été téléchargé avec succès (Chiffrement AES-256-GCM automatique).',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export bundle error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Échec de l’exportation.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Open QR Authenticity Scanner & Verification Modal
  const handleOpenQRVerificationModal = async () => {
    const { value: text } = await Swal.fire({
      title: '🔒 Authentification de QR Code Officiel',
      input: 'textarea',
      inputLabel: 'Collez le contenu JSON du QR Code scanné :',
      inputPlaceholder: '{"institution":"ESI", "student":"...", "grade20":"18.5/20", "signature":"..."}',
      showCancelButton: true,
      confirmButtonText: 'Vérifier la Signature',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff'
    });

    if (text) {
      try {
        const res = await verifyQRCodePayload(text);
        if (res.valid) {
          Swal.fire({
            icon: 'success',
            title: '✅ DOCUMENT IMPRIMÉ AUTHENTIQUE !',
            html: `<div style="text-align:left; font-size:0.9rem; background:#064e3b; padding:12px; border-radius:6px; color:#ecfdf5;">
                     <p><strong>Établissement:</strong> ${res.payload.institution || 'ESI'}</p>
                     <p><strong>Étudiant:</strong> ${res.payload.student}</p>
                     <p><strong>Examen:</strong> ${res.payload.exam}</p>
                     <p><strong>Note Officielle:</strong> <span style="font-size:1.1rem; color:#34d399; font-weight:bold;">${res.payload.grade20}</span></p>
                     <p style="margin-top:6px; font-size:0.75rem; color:#a7f3d0;">Signature HMAC: ${res.payload.signature}</p>
                   </div>`,
            background: '#111827', color: '#fff'
          });
        } else {
          Swal.fire({
            icon: 'error',
            title: '❌ SIGNATURE INVALIDE OU ALTÉRÉE !',
            text: res.message || 'Le document a été modifié ou ne provient pas du serveur officiel.',
            background: '#111827', color: '#fff'
          });
        }
      } catch (err) {
        Swal.fire({ icon: 'error', title: 'Format Invalide', text: 'Format de payload QR code illisible.', background: '#111827', color: '#fff' });
      }
    }
  };

  // Active code string to evaluate/analyze (ORIGINAL or CORRECTED)
  const activeCodeToRun = useMemo(() => {
    if (activeCodeView === 'CORRECTED' && correctedCodeInput.trim()) {
      return correctedCodeInput;
    }
    return studentCode;
  }, [activeCodeView, correctedCodeInput, studentCode]);

  const handleToggleCodeView = (viewMode) => {
    setActiveCodeView(viewMode);
    if (viewMode === 'CORRECTED' && !correctedCodeInput.trim()) {
      setCorrectedCodeInput(studentCode);
    }
  };

  // Run syntax analysis assistant
  const handleAnalyzeSyntax = async () => {
    setAnalyzing(true);
    try {
      const res = await analyzeSubmissionSyntax(examId, activeCodeToRun);
      setSyntaxReport(res);
    } catch (err) {
      console.error(err);
    } finally {
      setAnalyzing(false);
    }
  };

  // Run single test in sandbox
  const handleRunSandbox = async (inputToRun) => {
    setExecutingSandbox(true);
    setSandboxOutput(null);
    const targetInput = inputToRun !== undefined ? inputToRun : sandboxInput;
    try {
      const res = await runTeacherSandboxCode(examId, activeCodeToRun, 'ALGO', targetInput);
      setSandboxOutput(res);
    } catch (err) {
      setSandboxOutput({ status: 'ERROR', stderr: err.data?.error || 'Erreur d’exécution' });
    } finally {
      setExecutingSandbox(false);
    }
  };

  // Run ALL Hidden & Public Test Cases & Auto-Update Student Score (via Server)
  const handleRunAllHiddenTests = async () => {
    if (!currentProblem?.testCases || currentProblem.testCases.length === 0) {
      Swal.fire({ icon: 'info', title: 'Aucun test', text: 'Aucun cas de test disponible pour cet exercice.', background: '#111827', color: '#fff' });
      return;
    }

    setExecutingSandbox(true);
    setSavingStatus('Exécution des tests et calcul...');

    try {
      const res = await calculateExerciseGrade(examId, {
        studentId: currentStudent.id,
        problemId: currentProblem.id,
        forceRunTests: true
      });

      setData(prev => {
        if (!prev) return prev;
        const updatedSubmissions = [...prev.submissions];
        const existingIdx = updatedSubmissions.findIndex(
          s => s.studentId === currentStudent.id && s.problemId === currentProblem.id
        );
        if (existingIdx >= 0) updatedSubmissions[existingIdx] = res.submission;
        else updatedSubmissions.push(res.submission);

        const updatedAssignments = prev.assignments.map(a =>
          a.studentId === currentStudent.id
            ? { ...a, ...res.assignment, student: res.assignment?.student || a.student }
            : a
        );

        return { ...prev, submissions: updatedSubmissions, assignments: updatedAssignments };
      });

      const breakdown = res.submission?.evaluationBreakdown;
      if (breakdown?.testResults) {
        setHiddenTestResults(breakdown.testResults);
      }

      setExerciseScores(prev => ({ ...prev, [currentProblem.id]: res.submission.manualScore }));
      setSavingStatus('Calcul effectué & enregistré');
      setTimeout(() => setSavingStatus(''), 1500);

      fetchAIEvaluation(true);

      const maxPoints = currentProblem.points || 20;
      const passedCount = breakdown?.passedTests || 0;
      const totalCount = breakdown?.totalTests || currentProblem.testCases.length;

      Swal.fire({
        icon: 'success',
        title: 'Exécution Terminée !',
        text: `${passedCount}/${totalCount} tests passés. Note attribuée : ${res.submission.manualScore} / ${maxPoints} pts`,
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Run all hidden tests error:', err);
      setSavingStatus('Erreur');
    } finally {
      setExecutingSandbox(false);
    }
  };

  if (loading) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '16px', background: '#0b0f19' }}>
        <RefreshCw size={36} color="#3b82f6" style={{ animation: 'spin 1s linear infinite' }} />
        <p style={{ color: 'var(--text-muted)' }}>Chargement de l'espace de correction...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '16px', background: '#0b0f19' }}>
        <AlertCircle size={48} color="#ef4444" />
        <h2 style={{ color: '#f87171' }}>Erreur de chargement</h2>
        <p style={{ color: 'var(--text-muted)' }}>{error}</p>
        <button className="btn btn-primary" onClick={onBack}><ArrowLeft size={16} /> Retour</button>
      </div>
    );
  }

  const { exam, problems, assignments } = data;
  const gradedCount = assignments.filter(a => a.gradingStatus === 'GRADED').length;
  const allGraded = assignments.length > 0 && gradedCount === assignments.length;

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#0b0f19', color: '#fff' }}>

      {/* ── ZIP PROGRESS OVERLAY ── */}
      {zipProgress && zipProgress.status !== 'done' && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 9999,
          background: 'linear-gradient(90deg, #1e293b 0%, #0f172a 100%)',
          borderBottom: '2px solid #3b82f6', padding: '10px 24px',
          display: 'flex', alignItems: 'center', gap: '16px', boxShadow: '0 4px 24px rgba(0,0,0,0.5)'
        }}>
          <div style={{ animation: 'spin 1s linear infinite', display: 'flex' }}>
            <RefreshCw size={18} color="#3b82f6" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
              <span>📦 Génération des copies PDF en cours…</span>
              <span style={{ color: '#60a5fa' }}>{zipProgress.done} / {zipProgress.total} copies</span>
            </div>
            <div style={{ height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{
                height: '100%', borderRadius: '4px',
                background: 'linear-gradient(90deg, #3b82f6 0%, #06b6d4 100%)',
                width: zipProgress.total > 0 ? `${Math.round((zipProgress.done / zipProgress.total) * 100)}%` : '5%',
                transition: 'width 0.4s ease'
              }} />
            </div>
            {zipProgress.studentName && (
              <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '3px' }}>
                Dernière copie générée : <strong style={{ color: '#a5b4fc' }}>{zipProgress.studentName}</strong>
              </div>
            )}
          </div>
          <span style={{ fontSize: '0.8rem', color: '#60a5fa', fontWeight: '700' }}>
            {zipProgress.total > 0 ? `${Math.round((zipProgress.done / zipProgress.total) * 100)}%` : '…'}
          </span>
        </div>
      )}

      {zipProgress?.status === 'done' && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 9999,
          background: 'linear-gradient(90deg, #064e3b, #065f46)',
          borderBottom: '2px solid #10b981', padding: '10px 24px',
          display: 'flex', alignItems: 'center', gap: '12px', boxShadow: '0 4px 24px rgba(0,0,0,0.5)'
        }}>
          <CheckCircle size={18} color="#10b981" />
          <span style={{ color: '#a7f3d0', fontWeight: '700', fontSize: '0.9rem' }}>
            ✅ {zipProgress.total} copies générées avec succès — téléchargement en cours…
          </span>
        </div>
      )}

      {/* ── TOP BAR: Return, Exercise Navigation (Right after Retour), Exam Title, Progress & PDF ── */}
      <header className="glass-panel" style={{ borderRadius: 0, padding: '10px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--panel-border)', flexShrink: 0, gap: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap', flex: 1 }}>
          <button className="btn btn-secondary" style={{ padding: '6px 12px', display: 'flex', alignItems: 'center', gap: '6px' }} onClick={onBack}>
            <ArrowLeft size={16} /> Retour
          </button>

          {/* Exercise navigation tabs placed directly after the retour button */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
            <button
              className="btn btn-secondary"
              style={{ padding: '5px 8px', borderRadius: '4px' }}
              disabled={problemIdx === 0}
              onClick={() => setProblemIdx(prev => Math.max(0, prev - 1))}
              title="Exercice Précédent (↑)"
            >
              <ChevronUp size={14} />
            </button>
            <button
              className="btn btn-secondary"
              style={{ padding: '5px 8px', borderRadius: '4px' }}
              disabled={problemIdx === problems.length - 1}
              onClick={() => setProblemIdx(prev => Math.min(problems.length - 1, prev + 1))}
              title="Exercice Suivant (↓)"
            >
              <ChevronDown size={14} />
            </button>

            {problems.map((p, i) => {
              const scoreVal = exerciseScores[p.id];
              const hasScore = scoreVal !== '' && scoreVal !== null && scoreVal !== undefined;

              return (
                <button
                  key={p.id}
                  onClick={() => setProblemIdx(i)}
                  style={{
                    padding: '6px 14px', borderRadius: '6px', border: 'none',
                    background: problemIdx === i ? 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)' : 'rgba(0,0,0,0.3)',
                    color: problemIdx === i ? '#fff' : 'var(--text-muted)',
                    borderBottom: problemIdx === i ? '2px solid #60a5fa' : '2px solid transparent',
                    fontSize: '0.84rem', fontWeight: '800', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px',
                    boxShadow: problemIdx === i ? '0 2px 8px rgba(59,130,246,0.35)' : 'none'
                  }}
                >
                  <span>EXO {i + 1}</span>
                  {hasScore && (
                    <span style={{ fontSize: '0.72rem', background: 'rgba(255,255,255,0.18)', color: '#fff', padding: '1px 5px', borderRadius: '4px', fontWeight: '700' }}>
                      {scoreVal}/{p.points}p
                    </span>
                  )}
                </button>
              );
            })}

            {/* Active Exercise Title Badge */}
            {currentProblem && (
              <div style={{ marginLeft: '6px', padding: '4px 10px', background: 'rgba(59,130,246,0.12)', border: '1px solid rgba(59,130,246,0.3)', borderRadius: '6px', fontSize: '0.82rem', fontWeight: '700', color: '#93c5fd', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span>📖 EXO {problemIdx + 1} : <strong style={{ color: '#fff' }}>{currentProblem.title}</strong> ({currentProblem.points || 20} pts)</span>
              </div>
            )}
          </div>
        </div>

        {/* Header Right: Progression, Bundle Export & Finalize Correction Action Buttons */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0, flexWrap: 'wrap' }}>
          {savingStatus && (
            <span style={{ fontSize: '0.8rem', color: '#fbbf24', fontWeight: '600', animation: 'pulse 1s infinite' }}>
              {savingStatus}
            </span>
          )}

          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textAlign: 'right' }}>
            Corrigées : <strong style={{ color: allGraded ? '#34d399' : '#fbbf24' }}>{gradedCount} / {assignments.length}</strong> ({Math.round((gradedCount / Math.max(1, assignments.length)) * 100)}%)
          </div>

          <button
            className="btn btn-secondary"
            onClick={handleExportSubmissionBundle}
            style={{ padding: '6px 12px', fontSize: '0.8rem', fontWeight: '700', background: 'rgba(30, 41, 59, 0.8)', border: '1px solid #334155', color: '#93c5fd', display: 'flex', alignItems: 'center', gap: '6px' }}
            title="Exporter un paquet chiffré des soumissions (.algobundle)"
          >
            <Package size={14} /> Exporter Paquet
          </button>

          <button
            className="btn btn-primary"
            onClick={handleDownloadPDF}
            disabled={isGeneratingPDF}
            style={{ padding: '6px 12px', fontSize: '0.8rem', fontWeight: '700', background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            {isGeneratingPDF ? (
              <span>⌛ Génération...</span>
            ) : (
              <><FileText size={14} /> Imprimer Copie</>
            )}
          </button>

          <button
            className="btn btn-success"
            onClick={handleFinalizeCorrection}
            disabled={isFinalizing || !allGraded}
            style={{
              padding: '6px 14px', fontSize: '0.82rem', fontWeight: '800',
              background: !allGraded
                ? 'rgba(51, 65, 85, 0.4)'
                : 'linear-gradient(135deg, #10b981 0%, #047857 100%)',
              color: !allGraded ? '#94a3b8' : '#fff',
              border: !allGraded ? '1px solid rgba(255,255,255,0.1)' : '1px solid #10b981',
              cursor: !allGraded ? 'not-allowed' : 'pointer',
              opacity: !allGraded ? 0.65 : 1,
              boxShadow: allGraded ? '0 4px 14px rgba(16,185,129,0.3)' : 'none',
              display: 'flex', alignItems: 'center', gap: '6px',
              transition: 'all 0.2s ease'
            }}
            title={
              !allGraded
                ? `Veuillez valider toutes les copies (${gradedCount}/${assignments.length} validées) avant de clôturer la correction.`
                : "Clôturer la correction et dé-anonymiser les résultats officiels"
            }
          >
            {isFinalizing ? (
              <span>⌛ Clôture...</span>
            ) : (
              <><Lock size={14} /> Terminer la Correction {!allGraded && assignments.length > 0 && `(${gradedCount}/${assignments.length})`}</>
            )}
          </button>
        </div>
      </header>

      {/* ── MAIN WORKSPACE GRID: THREE EVALUATION MODULES & SIDEBAR ── */}
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 380px', overflow: 'hidden' }}>

        {/* ── LEFT/CENTER PANE: 3 MODULES GRID & PLAGIARISM ANALYSIS ── */}
        <div style={{ overflowY: 'auto', padding: '20px', display: 'flex', flexDirection: 'column', gap: '24px', borderRight: '1px solid var(--panel-border)' }}>

          {/* ── 1. SIDE-BY-SIDE CODE VIEWER (CODE ÉTUDIANT ↕ SOLUTION REPÈRE ENSEIGNANT) ── */}
          <div className="glass-panel" style={{ padding: '16px', background: '#0b0f19', border: '1px solid #1e293b', borderRadius: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #1e293b', paddingBottom: '12px', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ display: 'flex', background: 'rgba(0,0,0,0.5)', padding: '3px', borderRadius: '8px', border: '1px solid var(--panel-border)' }}>
                  <button
                    onClick={() => handleToggleCodeView('ORIGINAL')}
                    style={{
                      padding: '4px 12px', borderRadius: '6px', fontSize: '0.78rem', fontWeight: '800', border: 'none', cursor: 'pointer',
                      background: activeCodeView === 'ORIGINAL' ? '#3b82f6' : 'transparent', color: activeCodeView === 'ORIGINAL' ? '#fff' : '#9ca3af'
                    }}>
                    📄 Code Étudiant
                  </button>
                  <button
                    onClick={() => handleToggleCodeView('CORRECTED')}
                    style={{
                      padding: '4px 12px', borderRadius: '6px', fontSize: '0.78rem', fontWeight: '800', border: 'none', cursor: 'pointer',
                      background: activeCodeView === 'CORRECTED' ? '#8b5cf6' : 'transparent', color: activeCodeView === 'CORRECTED' ? '#fff' : '#9ca3af'
                    }}>
                    ✏️ Version Corrigée
                  </button>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <button
                  className="btn btn-success"
                  onClick={handleRunAllHiddenTests}
                  disabled={executingSandbox}
                  style={{ padding: '6px 14px', fontSize: '0.8rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '6px' }}
                >
                  <Play size={14} /> {executingSandbox ? 'Exécution...' : '⚡ Exécuter les Tests'}
                </button>

                <button
                  className="btn btn-secondary"
                  onClick={() => setShowASTModal(true)}
                  style={{ padding: '6px 12px', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '6px' }}
                >
                  <Layers size={14} /> Arbre AST
                </button>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', minHeight: '340px' }}>
              {/* Left Box: Student Code / Corrected Version with Line Comments */}
              <div style={{ display: 'flex', flexDirection: 'column', background: '#05070d', borderRadius: '8px', border: '1px solid #1e293b', overflow: 'hidden' }}>
                <div style={{ padding: '8px 14px', background: (!isCustomCode || similarityRatio === 0) ? 'rgba(239,68,68,0.18)' : 'rgba(59,130,246,0.15)', color: (!isCustomCode || similarityRatio === 0) ? '#f87171' : '#60a5fa', fontSize: '0.8rem', fontWeight: '700', borderBottom: '1px solid #1e293b', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>📄 {activeCodeView === 'ORIGINAL' ? ( (!isCustomCode || similarityRatio === 0) ? '⚠️ Code Modèle Inchangé (Aucun code rédigé)' : 'Code Soumis par l\'Étudiant' ) : 'Version Corrigée par l\'Enseignant'}</span>
                  <span style={{ fontSize: '0.72rem', color: (!isCustomCode || similarityRatio === 0) ? '#fca5a5' : '#93c5fd' }}>Cliquer une ligne pour annoter 💬</span>
                </div>
                <div style={{ flex: 1, overflowY: 'auto' }}>
                  {activeCodeView === 'ORIGINAL' ? (
                    <AnnotatedCodeViewer
                      code={studentCode}
                      lineComments={activeLineComments}
                      onLineCommentsChange={handleLineCommentsChange}
                    />
                  ) : (
                    <textarea
                      value={correctedCodeInput}
                      onChange={e => setCorrectedCodeInput(e.target.value)}
                      placeholder="Saisissez la version corrigée..."
                      style={{
                        width: '100%', height: '100%', minHeight: '300px', background: 'transparent',
                        color: '#a78bfa', border: 'none', outline: 'none', padding: '14px',
                        fontFamily: 'var(--font-mono)', fontSize: '0.88rem', lineHeight: '1.5', resize: 'none'
                      }}
                    />
                  )}
                </div>
              </div>

              {/* Right Box: Reference Solution Enseignant */}
              <div style={{ display: 'flex', flexDirection: 'column', background: '#05070d', borderRadius: '8px', border: '1px solid #1e293b', overflow: 'hidden' }}>
                <div style={{ padding: '8px 14px', background: 'rgba(52,211,153,0.15)', color: '#34d399', fontSize: '0.8rem', fontWeight: '700', borderBottom: '1px solid #1e293b', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>💡 Solution Repère (Solution Modèle Enseignant)</span>
                  <span style={{ fontSize: '0.72rem', color: '#a7f3d0' }}>Référence Officielle</span>
                </div>
                <div style={{ flex: 1, padding: '14px', overflowY: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.85rem', color: '#e2e8f0', lineHeight: '1.5', whiteSpace: 'pre-wrap' }}>
                  {effectiveRefSolution || 'Aucune solution de référence définie pour cet exercice.'}
                </div>
              </div>
            </div>
          </div>

          {/* ── 2. EXECUTIVE SUMMARY CARD OF ALL 3 MODULES (SINGLE SOURCE OF TRUTH FROM SERVER) ── */}
          {(() => {
            const aiData = aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`];
            const isAIAvailable = !!aiData?.result?.module3_ai && !aiData?.error;
            const maxPts = currentProblem?.points || 20;

            const breakdown = currentSubmission?.evaluationBreakdown;

            const totalT = currentProblem?.testCases?.length || breakdown?.totalTests || 0;
            const hasTestCases = totalT > 0 && breakdown?.hasTests !== false;
            const passedT = breakdown?.passedTests ?? 0;
            const S1 = (hasTestCases && totalT > 0) ? (passedT / totalT) : 0;

            const isUntouched = breakdown?.isUntouched ?? (isUntouchedTemplateCode(studentCode, getStarterTemplateCode(currentProblem)));
            const wMod1 = (!hasTestCases || totalT === 0) ? 0 : (breakdown?.wTest ?? (currentProblem?.weightTest !== undefined ? currentProblem.weightTest / 100 : 0.40));
            const wMod2 = (!hasTestCases || totalT === 0) ? 1.0 : (breakdown?.wAST ?? (currentProblem?.weightAst !== undefined ? currentProblem.weightAst / 100 : 0.60));

            const m1Score = breakdown?.m1Score ?? (isUntouched || !hasTestCases ? 0 : roundToNextQuarterPoint(S1 * maxPts * wMod1, maxPts * wMod1));
            const m2Score = breakdown?.m2Score ?? (isUntouched ? 0 : roundToNextQuarterPoint(((breakdown?.astSimilarityRatio ?? similarityRatio) / 100) * maxPts * wMod2, maxPts * wMod2));
            const totalCalc = breakdown?.calculatedScore ?? (isUntouched ? 0 : roundToNextQuarterPoint(m1Score + m2Score, maxPts));
            const simRatio = breakdown?.astSimilarityRatio ?? similarityRatio;

            return (
              <div className="glass-panel" style={{ padding: '16px 20px', background: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)', borderRadius: '10px', border: '1px solid rgba(168, 85, 247, 0.4)', boxShadow: '0 4px 20px rgba(0,0,0,0.5)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <BarChart2 size={20} color="#c084fc" />
                    <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: '800', color: '#fff' }}>
                      📊 Synthèse de l'Évaluation
                    </h3>
                  </div>
                  <span style={{ fontSize: '0.82rem', color: '#cbd5e1', fontWeight: '700' }}>
                    Score Indicatif : <strong style={{ color: '#34d399', fontSize: '1.15rem' }}>{formatPts(totalCalc)} / {formatPts(maxPts)} pts</strong>
                  </span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px' }}>
                  {/* Summary Module 1 */}
                  <div style={{ padding: '12px 14px', borderRadius: '8px', background: hasTestCases ? 'rgba(16,185,129,0.12)' : 'rgba(148,163,184,0.12)', border: `1px solid ${hasTestCases ? 'rgba(16,185,129,0.3)' : 'rgba(148,163,184,0.3)'}`, display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <span style={{ fontSize: '0.78rem', fontWeight: '800', color: hasTestCases ? '#34d399' : '#94a3b8' }}>
                      Tests Automatiques {!hasTestCases ? '(Désactivé - 0 test)' : `(${Math.round(wMod1 * 100)}%)`}
                    </span>
                    <span style={{ fontSize: '1.3rem', fontWeight: '900', color: hasTestCases ? '#34d399' : '#94a3b8' }}>
                      {!hasTestCases ? '0 / 0 pts' : `${formatPts(m1Score)} / ${formatPts(maxPts * wMod1)} pts`}
                    </span>
                    <span style={{ fontSize: '0.74rem', color: hasTestCases ? '#a7f3d0' : '#cbd5e1' }}>
                      {!hasTestCases ? 'Aucun cas de test défini' : `${passedT}/${totalT} passés (${Math.round(S1 * 100)}%)`}
                    </span>
                  </div>

                  {/* Summary Module 2 */}
                  <div style={{ padding: '12px 14px', borderRadius: '8px', background: isUntouched ? 'rgba(239,68,68,0.12)' : 'rgba(168,85,247,0.12)', border: `1px solid ${isUntouched ? 'rgba(239,68,68,0.3)' : 'rgba(168,85,247,0.3)'}`, display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <span style={{ fontSize: '0.78rem', fontWeight: '800', color: isUntouched ? '#f87171' : '#c084fc' }}>
                      Analyse de Structure {!hasTestCases ? '(100%)' : `(${Math.round(wMod2 * 100)}%)`}
                    </span>
                    <span style={{ fontSize: '1.3rem', fontWeight: '900', color: isUntouched ? '#f87171' : '#c084fc' }}>
                      {isUntouched ? '0' : formatPts(m2Score)} / {formatPts(maxPts * wMod2)} pts
                    </span>
                    <span style={{ fontSize: '0.74rem', color: isUntouched ? '#fca5a5' : '#e9d5ff' }}>
                      {isUntouched ? '⚠️ Code Modèle Inchangé (0% rédigé)' : `Similarité Repère : ${simRatio}%`}
                    </span>
                    {breakdown?.isMultiQuestion && Array.isArray(breakdown.questionsBreakdown) && breakdown.questionsBreakdown.length > 1 && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '4px', paddingTop: '6px', borderTop: '1px dashed rgba(168,85,247,0.3)' }}>
                        {breakdown.questionsBreakdown.map((qb, qIdx) => (
                          <span key={qb.questionId || qIdx} style={{ fontSize: '0.72rem', fontWeight: '800', padding: '2px 8px', borderRadius: '4px', background: 'rgba(168,85,247,0.25)', color: '#d8b4fe', border: '1px solid rgba(168,85,247,0.4)' }}>
                            Q{qb.orderIndex} : {formatPts(qb.pointsAwarded)} / {formatPts(qb.maxPts)} pts ({qb.astSimilarityRatio}%)
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Summary Module 3 */}
                  <div style={{ padding: '12px 14px', borderRadius: '8px', background: isAIAvailable ? 'rgba(59,130,246,0.12)' : 'rgba(148,163,184,0.12)', border: `1px solid ${isAIAvailable ? 'rgba(59,130,246,0.3)' : 'rgba(148,163,184,0.3)'}`, display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <span style={{ fontSize: '0.78rem', fontWeight: '800', color: isAIAvailable ? '#60a5fa' : '#94a3b8' }}>
                      Évaluation IA {isAIAvailable ? '(0% - Informatif)' : '(Indisponible)'}
                    </span>
                    <span style={{ fontSize: '1.3rem', fontWeight: '900', color: isAIAvailable ? '#60a5fa' : '#94a3b8' }}>
                      0 / 0 pts
                    </span>
                    <span style={{ fontSize: '0.74rem', color: isAIAvailable ? '#93c5fd' : '#cbd5e1' }}>
                      {isAIAvailable ? `Score IA: ${aiData.result.module3_ai.scoreOut10 || '0'}/10 (Ignoré dans le score)` : 'Pondération 0% (Inactif)'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* ── 3. DETAILED EVALUATION GRID ── */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '18px' }}>

            {/* ── TESTS AUTOMATIQUES ── */}
            {(() => {
              const breakdown = currentSubmission?.evaluationBreakdown;
              const totalT = currentProblem?.testCases?.length || breakdown?.totalTests || 0;
              const hasTestCases = totalT > 0 && breakdown?.hasTests !== false;

              return (
                <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px', background: 'rgba(15, 23, 42, 0.95)', border: '1px solid #1e293b', borderRadius: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #334155', paddingBottom: '10px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <Terminal size={18} color="#34d399" />
                      <h4 style={{ margin: 0, fontSize: '0.95rem', fontWeight: '800', color: '#fff' }}>Tests Automatiques</h4>
                    </div>
                    {hasTestCases && totalT > 0 && testSummary && (
                      <span style={{
                        padding: '3px 10px', borderRadius: '12px', fontSize: '0.78rem', fontWeight: '800',
                        background: testSummary.allPassed ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)',
                        color: testSummary.allPassed ? '#34d399' : '#f87171',
                        border: `1px solid ${testSummary.allPassed ? '#10b981' : '#ef4444'}`
                      }}>
                        {testSummary.totalPassed}/{testSummary.totalCount} Passés
                      </span>
                    )}
                    {(!hasTestCases || totalT === 0) && (
                      <span style={{
                        padding: '3px 10px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: '800',
                        background: 'rgba(148,163,184,0.15)', color: '#94a3b8', border: '1px solid #475569'
                      }}>
                        Désactivé (0 test)
                      </span>
                    )}
                  </div>

                  {hasTestCases && totalT > 0 ? (
                    <>
                      <button
                        className="btn btn-success"
                        onClick={handleRunAllHiddenTests}
                        disabled={executingSandbox}
                        style={{ width: '100%', padding: '8px', fontSize: '0.82rem', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
                      >
                        <Play size={14} /> {executingSandbox ? 'Exécution des tests...' : 'Exécuter TOUS les Tests'}
                      </button>

                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', maxHeight: '380px', overflowY: 'auto' }}>
                        {currentProblem.testCases.map((tc, idx) => {
                          const testStatus = studentTestStatusMap[tc.id];
                          const resultObj = hiddenTestResults?.find(r => r.id === tc.id || r.index === idx + 1);
                          const isPassed = resultObj ? resultObj.passed : testStatus?.passed;
                          const actualOut = resultObj ? resultObj.actualOutput : testStatus?.actualOutput;

                          return (
                            <div key={tc.id || idx} style={{
                              padding: '8px 10px', borderRadius: '6px', fontSize: '0.78rem',
                              background: isPassed !== undefined ? (isPassed ? 'rgba(16,185,129,0.08)' : 'rgba(239,68,68,0.08)') : 'rgba(0,0,0,0.3)',
                              border: `1px solid ${isPassed !== undefined ? (isPassed ? 'rgba(16,185,129,0.25)' : 'rgba(239,68,68,0.25)') : '#1e293b'}`
                            }}>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                                <span style={{ fontWeight: '700', fontSize: '0.76rem', color: tc.isPublic ? '#60a5fa' : '#fbbf24' }}>
                                  {tc.isPublic ? 'Public' : 'Caché'} #{idx + 1}
                                </span>
                                {isPassed !== undefined && (
                                  <span style={{ fontWeight: '800', fontSize: '0.74rem', color: isPassed ? '#34d399' : '#f87171' }}>
                                    {isPassed ? '✅ SUCCÈS' : '❌ ÉCHEC'}
                                  </span>
                                )}
                              </div>
                              <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '2px 8px', color: '#cbd5e1', fontSize: '0.74rem', fontFamily: 'var(--font-mono)' }}>
                                <span style={{ color: '#94a3b8' }}>Entrée:</span>
                                <code>{tc.inputData?.replace(/\n/g, ' ↵ ') || '(vide)'}</code>
                                <span style={{ color: '#94a3b8' }}>Attendu:</span>
                                <code style={{ color: '#34d399' }}>{tc.expectedOutput}</code>
                                {actualOut !== undefined && (
                                  <>
                                    <span style={{ color: '#94a3b8' }}>Obtenu:</span>
                                    <code style={{ color: isPassed ? '#34d399' : '#f87171', fontWeight: '700' }}>
                                      {actualOut !== '' ? actualOut : '(Vide)'}
                                    </code>
                                  </>
                                )}
                              </div>
                              {(resultObj?.rawStderr || testStatus?.rawStderr) && (
                                <div style={{ color: '#fca5a5', fontSize: '0.72rem', fontFamily: 'var(--font-mono)', marginTop: '3px' }}>
                                  ⚠️ Log: <code>{resultObj?.rawStderr || testStatus?.rawStderr}</code>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </>
                  ) : (
                    <div style={{ padding: '24px 16px', textAlign: 'center', background: 'rgba(0,0,0,0.3)', borderRadius: '8px', border: '1px dashed #334155', color: '#94a3b8', fontSize: '0.85rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                      <AlertCircle size={26} color="#a78bfa" />
                      <span style={{ fontWeight: '700', color: '#e2e8f0' }}>Aucun cas de test pour cet exercice</span>
                      <span style={{ fontSize: '0.78rem', color: '#94a3b8' }}>
                        L'évaluation de cet exercice est effectuée à <strong>100% sur la Structure &amp; l'Arbre AST</strong>.
                      </span>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* ── STRUCTURE & AST ── */}
            <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px', background: 'rgba(15, 23, 42, 0.95)', border: '1px solid #1e293b', borderRadius: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #334155', paddingBottom: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <GitFork size={18} color="#c084fc" />
                  <h4 style={{ margin: 0, fontSize: '0.95rem', fontWeight: '800', color: '#fff' }}>Structure &amp; AST</h4>
                </div>
                <span style={{
                  padding: '3px 10px', borderRadius: '12px', fontSize: '0.78rem', fontWeight: '800',
                  background: similarityRatio > 70 ? 'rgba(16,185,129,0.2)' : 'rgba(59,130,246,0.2)',
                  color: similarityRatio > 70 ? '#34d399' : '#60a5fa',
                  border: `1px solid ${similarityRatio > 70 ? '#10b981' : '#3b82f6'}`
                }}>
                  Similarité: {similarityRatio}%
                </span>
              </div>

              {/* Interactive Question Cards (Click whole card to compare AST & Code) */}
              {(() => {
                const breakdown = currentSubmission?.evaluationBreakdown;
                const maxPts = currentProblem?.points || 20;
                const totalT = currentProblem?.testCases?.length || breakdown?.totalTests || 0;
                const hasTestCases = totalT > 0 && breakdown?.hasTests !== false;
                const isUntouched = breakdown?.isUntouched ?? (isUntouchedTemplateCode(studentCode, getStarterTemplateCode(currentProblem)));
                const wMod2 = (!hasTestCases || totalT === 0) ? 1.0 : (breakdown?.wAST ?? (currentProblem?.weightAst !== undefined ? currentProblem.weightAst / 100 : 0.60));
                const m2Score = breakdown?.m2Score ?? (isUntouched ? 0 : roundToNextQuarterPoint(((breakdown?.astSimilarityRatio ?? similarityRatio) / 100) * maxPts * wMod2, maxPts * wMod2));
                const isMulti = breakdown?.isMultiQuestion && Array.isArray(breakdown.questionsBreakdown) && breakdown.questionsBreakdown.length > 1;
                const sSlices = sliceCodeByQuestionMarkers(studentCode);
                const rSlices = sliceCodeByQuestionMarkers(effectiveRefSolution);

                if (isMulti) {
                  return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ fontSize: '0.78rem', fontWeight: '800', color: '#c4b5fd', display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <GitBranch size={14} color="#c084fc" />
                        <span>Détail par Sous-Question ({breakdown.questionsBreakdown.length}) — Édition &amp; Comparaison :</span>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                        {breakdown.questionsBreakdown.map((qb, qIdx) => {
                          const qNum = qb.orderIndex;
                          const qStudentCode = qb.studentSlice || sSlices[qNum] || studentCode;
                          const qRefCode = qb.refSlice || rSlices[qNum] || currentProblem?.referenceSolution;
                          const currentQScore = subQuestionScores[currentProblem?.id]?.[qb.questionId || qb.orderIndex] !== undefined
                            ? subQuestionScores[currentProblem?.id]?.[qb.questionId || qb.orderIndex]
                            : qb.pointsAwarded;

                          return (
                            <div
                              key={qb.questionId || qIdx}
                              onClick={() => {
                                setSelectedQuestionCompare({
                                  questionNum: qNum,
                                  studentCode: qStudentCode,
                                  refCode: qRefCode,
                                  similarityRatio: qb.astSimilarityRatio
                                });
                              }}
                              style={{
                                background: '#090d16',
                                padding: '12px 14px',
                                borderRadius: '8px',
                                border: '1px solid rgba(168, 85, 247, 0.35)',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '8px',
                                cursor: 'pointer',
                                transition: 'all 0.2s ease',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.3)'
                              }}
                              onMouseEnter={e => {
                                e.currentTarget.style.borderColor = 'rgba(168, 85, 247, 0.9)';
                                e.currentTarget.style.background = 'rgba(168, 85, 247, 0.12)';
                                e.currentTarget.style.transform = 'translateY(-2px)';
                              }}
                              onMouseLeave={e => {
                                e.currentTarget.style.borderColor = 'rgba(168, 85, 247, 0.35)';
                                e.currentTarget.style.background = '#090d16';
                                e.currentTarget.style.transform = 'none';
                              }}
                            >
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <span style={{ fontWeight: '800', color: '#e2e8f0', fontSize: '0.88rem' }}>
                                  <span style={{ background: 'rgba(168,85,247,0.25)', color: '#d8b4fe', padding: '3px 9px', borderRadius: '5px', fontSize: '0.78rem', fontWeight: '800' }}>
                                    Question {qb.orderIndex}
                                  </span>
                                </span>
                                
                                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }} onClick={e => e.stopPropagation()}>
                                  <span style={{ fontSize: '0.75rem', fontWeight: '700', color: '#94a3b8' }}>Note:</span>
                                  <input
                                    type="number"
                                    step="0.25"
                                    min="0"
                                    max={qb.maxPts}
                                    value={currentQScore ?? ''}
                                    onChange={e => handleSubQuestionScoreChange(currentProblem?.id, qb.questionId || qb.orderIndex, e.target.value, qb.maxPts)}
                                    onClick={e => e.stopPropagation()}
                                    style={{
                                      width: '60px',
                                      padding: '3px 6px',
                                      fontSize: '0.85rem',
                                      fontWeight: '800',
                                      textAlign: 'center',
                                      background: '#0f172a',
                                      color: '#34d399',
                                      border: '1px solid rgba(168, 85, 247, 0.5)',
                                      borderRadius: '6px',
                                      outline: 'none'
                                    }}
                                  />
                                  <span style={{ fontSize: '0.78rem', color: '#94a3b8', fontWeight: '700' }}>/ {formatPts(qb.maxPts)} pts</span>
                                </div>
                              </div>
                              
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.75rem', color: '#94a3b8' }}>
                                <span>Similarité AST : <strong style={{ color: qb.astSimilarityRatio >= 65 ? '#34d399' : (qb.astSimilarityRatio >= 35 ? '#fbbf24' : '#f87171') }}>{qb.astSimilarityRatio}%</strong></span>
                                <span style={{ fontSize: '0.72rem', color: '#c084fc', display: 'flex', alignItems: 'center', gap: '3px', fontWeight: '700' }}>
                                  🌳 Comparer AST &amp; Code <ChevronRight size={13} />
                                </span>
                              </div>

                              {/* Progress bar */}
                              <div style={{ width: '100%', height: '5px', borderRadius: '3px', background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                                <div style={{ width: `${qb.astSimilarityRatio}%`, height: '100%', background: qb.astSimilarityRatio >= 65 ? '#34d399' : (qb.astSimilarityRatio >= 35 ? '#fbbf24' : '#f87171'), transition: 'width 0.3s ease' }} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                }

                // Single question problem (1 question)
                return (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    <div
                      onClick={() => {
                        setSelectedQuestionCompare({
                          questionNum: 1,
                          studentCode: sSlices[1] || studentCode,
                          refCode: rSlices[1] || currentProblem?.referenceSolution,
                          similarityRatio: similarityRatio
                        });
                      }}
                      style={{
                        background: '#090d16',
                        padding: '14px 16px',
                        borderRadius: '8px',
                        border: '1px solid rgba(168, 85, 247, 0.4)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '10px',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.3)'
                      }}
                      onMouseEnter={e => {
                        e.currentTarget.style.borderColor = 'rgba(168, 85, 247, 0.9)';
                        e.currentTarget.style.background = 'rgba(168, 85, 247, 0.12)';
                        e.currentTarget.style.transform = 'translateY(-2px)';
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.borderColor = 'rgba(168, 85, 247, 0.4)';
                        e.currentTarget.style.background = '#090d16';
                        e.currentTarget.style.transform = 'none';
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontWeight: '800', color: '#e2e8f0', fontSize: '0.88rem' }}>
                          <span style={{ background: 'rgba(168,85,247,0.25)', color: '#d8b4fe', padding: '3px 9px', borderRadius: '5px', fontSize: '0.78rem', fontWeight: '800' }}>
                            Question 1 (Exercice Unique)
                          </span>
                        </span>
                        
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }} onClick={e => e.stopPropagation()}>
                          <span style={{ fontSize: '0.75rem', fontWeight: '700', color: '#94a3b8' }}>Note AST :</span>
                          <span style={{ fontSize: '0.92rem', fontWeight: '900', color: '#c084fc', background: 'rgba(168,85,247,0.15)', padding: '2px 8px', borderRadius: '5px', border: '1px solid rgba(168,85,247,0.3)' }}>
                            {formatPts(m2Score)} / {formatPts(maxPts * wMod2)} pts
                          </span>
                        </div>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.75rem', color: '#94a3b8' }}>
                        <span>Similarité AST : <strong style={{ color: similarityRatio >= 65 ? '#34d399' : (similarityRatio >= 35 ? '#fbbf24' : '#f87171') }}>{similarityRatio}%</strong></span>
                        <span style={{ fontSize: '0.72rem', color: '#c084fc', display: 'flex', alignItems: 'center', gap: '3px', fontWeight: '700' }}>
                          🌳 Comparer AST &amp; Code <ChevronRight size={13} />
                        </span>
                      </div>

                      {/* Progress bar */}
                      <div style={{ width: '100%', height: '5px', borderRadius: '3px', background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                        <div style={{ width: `${similarityRatio}%`, height: '100%', background: similarityRatio >= 65 ? '#34d399' : (similarityRatio >= 35 ? '#fbbf24' : '#f87171'), transition: 'width 0.3s ease' }} />
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* ── ÉVALUATION IA ── */}
            <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px', background: 'rgba(15, 23, 42, 0.95)', border: '1px solid #1e293b', borderRadius: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #334155', paddingBottom: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Cpu size={18} color="#60a5fa" />
                  <h4 style={{ margin: 0, fontSize: '0.95rem', fontWeight: '800', color: '#fff' }}>Évaluation IA</h4>
                </div>

                <button
                  className="btn btn-secondary"
                  onClick={() => fetchAIEvaluation(true)}
                  disabled={aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`]?.loading}
                  style={{ padding: '3px 8px', fontSize: '0.72rem', color: '#60a5fa', background: 'rgba(59,130,246,0.15)' }}
                >
                  <RefreshCw size={12} style={{ animation: aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`]?.loading ? 'spin 1s linear infinite' : 'none' }} /> Re-évaluer
                </button>
              </div>

              {aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`]?.loading ? (
                <div style={{ padding: '30px', textAlign: 'center', color: '#60a5fa', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px' }}>
                  <RefreshCw size={28} style={{ animation: 'spin 1s linear infinite' }} />
                  <span style={{ fontSize: '0.85rem', fontWeight: '700' }}>Évaluation du modèle IA local en cours...</span>
                </div>
              ) : aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`]?.error ? (
                <div style={{ padding: '14px', background: 'rgba(239,68,68,0.12)', borderRadius: '8px', border: '1px solid rgba(239,68,68,0.3)', color: '#f87171', fontSize: '0.8rem', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div style={{ fontWeight: '700', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <AlertTriangle size={15} /> ⚠️ Évaluation IA Non Disponible
                  </div>
                  <span>{aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`]?.error}</span>
                  <button className="btn btn-secondary" onClick={() => fetchAIEvaluation(true)} style={{ padding: '4px 10px', fontSize: '0.76rem', alignSelf: 'flex-start' }}>
                    🔄 Réessayer l’Évaluation IA
                  </button>
                </div>
              ) : aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`]?.result ? (
                (() => {
                  const res = aiEvaluationMap[`${currentStudent?.id}_${currentProblem?.id}`].result;
                  const aiEval = res.module3_ai?.evaluation || res.module3_ai?.evaluationDetails || {};
                  const aiScores = aiEval.scores || {};
                  const scoreOut10 = res.module3_ai?.scoreOut10 ?? aiEval.score_out_of_10 ?? (res.module3_ai?.score !== undefined ? (res.module3_ai.score / 10).toFixed(1) : '0');
                  const classification = aiEval.classification || (res.module3_ai?.score === 0 ? 'Copie Blanche' : 'Équivalent');
                  const feedbackFr = aiEval.feedback_fr || res.module3_ai?.feedback_fr || 'Solution conforme aux attentes algorithmiques.';
                  const strengths = aiEval.strengths || [];
                  const errors = aiEval.errors || [];

                  return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'rgba(59,130,246,0.1)', padding: '10px 14px', borderRadius: '8px', border: '1px solid rgba(59,130,246,0.25)' }}>
                        <div>
                          <div style={{ fontSize: '0.7rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: '700' }}>Score Proposé IA (Evidence)</div>
                          <div style={{ fontSize: '1.4rem', fontWeight: '900', color: '#60a5fa' }}>
                            {res.module3_ai?.score ?? 0} / 100 <span style={{ fontSize: '0.85rem', color: '#93c5fd' }}>({scoreOut10}/10)</span>
                          </div>
                        </div>
                        <span style={{ padding: '4px 10px', borderRadius: '12px', fontSize: '0.78rem', fontWeight: '800', background: res.module3_ai?.score === 0 ? 'rgba(239,68,68,0.2)' : 'rgba(16,185,129,0.2)', color: res.module3_ai?.score === 0 ? '#f87171' : '#34d399', border: `1px solid ${res.module3_ai?.score === 0 ? '#ef4444' : '#10b981'}` }}>
                          {classification}
                        </span>
                      </div>

                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '0.76rem' }}>
                        {[
                          { label: 'Compréhension Algorithmique', val: aiScores.algorithmic_correctness ?? res.module3_ai?.score ?? 0 },
                          { label: 'Correction Logique', val: aiScores.logical_correctness ?? res.module3_ai?.score ?? 0 },
                          { label: 'Équivalence Sémantique', val: aiScores.semantic_equivalence ?? res.module3_ai?.score ?? 0 },
                          { label: 'Compréhension Partielle', val: aiScores.core_idea ?? res.module3_ai?.score ?? 0 },
                          { label: 'Qualité Algorithmique', val: aiScores.error_impact ?? res.module3_ai?.score ?? 0 }
                        ].map((dim, dIdx) => (
                          <div key={dIdx} style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', color: '#cbd5e1' }}>
                              <span>{dim.label}</span>
                              <strong style={{ color: '#60a5fa' }}>{dim.val}%</strong>
                            </div>
                            <div style={{ height: '5px', background: 'rgba(255,255,255,0.08)', borderRadius: '3px', overflow: 'hidden' }}>
                              <div style={{ height: '100%', width: `${dim.val}%`, background: 'linear-gradient(90deg, #3b82f6, #34d399)', borderRadius: '3px' }} />
                            </div>
                          </div>
                        ))}
                      </div>

                      {strengths.length > 0 && (
                        <div style={{ fontSize: '0.76rem', color: '#a7f3d0' }}>
                          <strong style={{ color: '#34d399' }}>✓ Points Positifs :</strong>
                          {strengths.slice(0, 3).map((st, i) => (
                            <div key={i}>• {typeof st === 'object' ? st.description || JSON.stringify(st) : st}</div>
                          ))}
                        </div>
                      )}

                      {errors.length > 0 && (
                        <div style={{ fontSize: '0.76rem', color: '#fca5a5' }}>
                          <strong style={{ color: '#f87171' }}>⚠ Erreurs Détectées :</strong>
                          {errors.slice(0, 3).map((er, i) => (
                            <div key={i}>• {typeof er === 'object' ? er.description || JSON.stringify(er) : er}</div>
                          ))}
                        </div>
                      )}

                      <div style={{ padding: '8px 12px', background: 'rgba(0,0,0,0.4)', borderRadius: '6px', border: '1px solid #334155', fontSize: '0.78rem', color: '#e2e8f0' }}>
                        <strong style={{ color: '#c084fc', display: 'block', marginBottom: '2px' }}>💬 Commentaire Pédagogique (FR) :</strong>
                        <span>{feedbackFr}</span>
                      </div>
                    </div>
                  );
                })()
              ) : null}
            </div>

          </div>

          {/* ── PLAGIARISM / STUDENT SIMILARITY ANALYSIS SECTION ── */}
          <div className="glass-panel" style={{ padding: '20px', background: 'rgba(15, 23, 42, 0.95)', border: '1px solid #1e293b', borderRadius: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #334155', paddingBottom: '12px', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Users size={20} color="#f87171" />
                <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: '800', color: '#fff' }}>
                  ⚠️ Solutions Similaires (Intégrité)
                </h3>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.82rem', color: '#94a3b8' }}>
                <Sliders size={15} color="#94a3b8" />
                <span>Seuil de similarité :</span>
                <select
                  value={similarityThreshold}
                  onChange={e => setSimilarityThreshold(parseInt(e.target.value, 10))}
                  style={{ background: '#0f172a', color: '#fff', border: '1px solid #334155', borderRadius: '6px', padding: '4px 10px', fontWeight: '700', fontSize: '0.82rem' }}
                >
                  <option value={60}>60% (Large)</option>
                  <option value={70}>70% (Standard par défaut)</option>
                  <option value={80}>80% (Élevé)</option>
                  <option value={90}>90% (Quasi-Identique)</option>
                </select>
              </div>
            </div>

            {similarStudents.length > 0 && similarStudents.some(s => s.metrics.totalSim >= 85) && (
              <div style={{ padding: '12px 16px', background: 'rgba(239,68,68,0.15)', borderRadius: '8px', border: '1px solid rgba(239,68,68,0.4)', color: '#f87171', fontSize: '0.84rem', marginBottom: '14px', display: 'flex', alignItems: 'center', gap: '12px' }}>
                <AlertTriangle size={20} color="#f87171" />
                <div>
                  <strong>⚠️ {similarStudents.filter(s => s.metrics.totalSim >= 85).length} solution(s) fortement similaire(s) détectée(s)</strong> (Plus haute similarité: Anonyme [{similarStudents[0].accessNumber || 'N/A'}] — {similarStudents[0].metrics.totalSim}%).
                  <div style={{ fontSize: '0.75rem', color: '#fca5a5', marginTop: '2px', fontStyle: 'italic' }}>
                    Note : Il s'agit d'un indicateur d'intégrité académique. Inspectez le diff détaillé.
                  </div>
                </div>
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
              {similarStudents.length > 0 ? (
                similarStudents.map((item, idx) => (
                  <div key={idx} style={{ padding: '12px 14px', borderRadius: '8px', background: '#0f172a', border: `1px solid ${item.metrics.totalSim >= 85 ? '#ef4444' : '#334155'}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontWeight: '700', fontSize: '0.86rem', color: '#fff' }}>
                        👤 Anonyme [{item.accessNumber || 'N/A'}]
                      </div>
                      <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                        Code Anonyme: <strong style={{ color: '#93c5fd' }}>{item.accessNumber || 'N/A'}</strong>
                      </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '6px' }}>
                      <span style={{ padding: '2px 8px', borderRadius: '10px', fontSize: '0.78rem', fontWeight: '800', background: item.metrics.totalSim >= 85 ? 'rgba(239,68,68,0.2)' : 'rgba(245,158,11,0.2)', color: item.metrics.totalSim >= 85 ? '#f87171' : '#fbbf24' }}>
                        {item.metrics.totalSim}%
                      </span>
                      <button
                        className="btn btn-secondary"
                        onClick={() => setSimilarityCompareModal({ isOpen: true, targetStudent: item.student, targetCode: item.submissionCode, metrics: item.metrics })}
                        style={{ padding: '3px 8px', fontSize: '0.74rem', background: '#1e293b', color: '#a78bfa', border: '1px solid #334155' }}
                      >
                        🔍 Comparer
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div style={{ color: '#64748b', fontSize: '0.84rem', fontStyle: 'italic' }}>
                  Aucune solution similaire au-dessus du seuil de {similarityThreshold}% détectée.
                </div>
              )}
            </div>
          </div>

        </div>

        {/* ── RIGHT SIDEBAR: Student Navigation, Student Info, Exercise Scores, & Validation ── */}
        <div style={{ padding: '20px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '20px', background: 'rgba(11, 15, 25, 0.98)' }}>

          {/* Student Selector Navigation with Prev / Dropdown / Next */}
          <div className="glass-panel" style={{ padding: '10px 12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <button
              className="btn btn-secondary"
              style={{ padding: '6px 10px' }}
              disabled={studentIdx === 0}
              onClick={() => setStudentIdx(prev => Math.max(0, prev - 1))}
              title="Copie Précédente (←)"
            >
              <ArrowLeft size={14} />
            </button>

            <select
              value={studentIdx}
              onChange={e => setStudentIdx(parseInt(e.target.value, 10))}
              style={{
                flex: 1, minWidth: 0,
                background: '#111827', color: '#fff', border: '1px solid var(--panel-border)',
                borderRadius: '6px', padding: '6px 8px', fontSize: '0.82rem', fontWeight: '700'
              }}
            >
              {assignments.map((a, i) => {
                const isGraded = a.gradingStatus === 'GRADED';
                const name = `Anonyme #${a.accessNumber || (i + 1)} ${isGraded ? '✅ (Corrigé)' : '⏳ (Non validé)'}`;
                return (
                  <option key={a.id || i} value={i}>
                    {name}
                  </option>
                );
              })}
            </select>

            <button
              className="btn btn-secondary"
              style={{ padding: '6px 10px' }}
              disabled={studentIdx === assignments.length - 1}
              onClick={() => setStudentIdx(prev => Math.min(assignments.length - 1, prev + 1))}
              title="Copie Suivante (→)"
            >
              <ArrowRight size={14} />
            </button>
          </div>

          {/* Student Info Card */}
          <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '8px' }}>
              <h3 style={{ fontSize: '1.02rem', margin: 0, fontWeight: '800' }}>
                👤 Anonyme [{currentAssignment?.accessNumber || 'N/A'}]
              </h3>
              <span className={`badge ${currentAssignment?.gradingStatus === 'GRADED' ? 'badge-green' : 'badge-yellow'}`} style={{ whiteSpace: 'nowrap', flexShrink: 0, padding: '3px 8px', fontSize: '0.75rem', fontWeight: '700' }}>
                {currentAssignment?.gradingStatus === 'GRADED' ? '✅ Corrigé' : '⏳ Non corrigé'}
              </span>
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <span>Code Anonyme: <code style={{ color: '#60a5fa', fontWeight: '800', fontSize: '0.9rem' }}>{currentAssignment?.accessNumber}</code></span>
              <span>Statut Correction: <strong style={{ color: currentAssignment?.gradingStatus === 'GRADED' ? '#34d399' : '#fbbf24' }}>{currentAssignment?.gradingStatus === 'GRADED' ? 'Validé & Noté' : 'En attente de validation'}</strong></span>
            </div>

            <button
              className={`btn ${currentAssignment?.gradingStatus === 'GRADED' ? 'btn-secondary' : 'btn-primary'}`}
              onClick={handleValidateStudentCopy}
              disabled={isValidatingCopy}
              style={{
                width: '100%',
                padding: '7px 10px',
                fontSize: '0.8rem',
                fontWeight: '800',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                background: currentAssignment?.gradingStatus === 'GRADED' ? 'rgba(52,211,153,0.12)' : 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                color: currentAssignment?.gradingStatus === 'GRADED' ? '#34d399' : '#fff',
                borderColor: currentAssignment?.gradingStatus === 'GRADED' ? 'rgba(52,211,153,0.4)' : '#059669'
              }}
            >
              {currentAssignment?.gradingStatus === 'GRADED' ? (
                <><span>✓</span> Copie Validée (Re-valider)</>
              ) : (
                <><span>✅</span> Valider cette Copie (Marquer Corrigé)</>
              )}
            </button>
          </div>

          {/* Exercise Scores & Live Auto-Save List */}
          <div className="glass-panel" style={{ padding: '16px' }}>
            <div style={{ fontSize: '0.8rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '12px' }}>
              📝 Notes des Exercices :
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {problems.map((p, i) => {
                const sub = data?.submissions?.find(s => s.studentId === currentStudent?.id && s.problemId === p.id);
                const scoreVal = exerciseScores[p.id] !== undefined && exerciseScores[p.id] !== ''
                  ? exerciseScores[p.id]
                  : (sub?.manualScore !== null && sub?.manualScore !== undefined ? sub.manualScore : '');
                const isCurrentProb = i === problemIdx;

                return (
                  <div
                    key={p.id}
                    onClick={() => setProblemIdx(i)}
                    style={{
                      padding: '10px 12px', borderRadius: '8px', cursor: 'pointer',
                      background: isCurrentProb ? 'rgba(59, 130, 246, 0.18)' : 'rgba(0,0,0,0.25)',
                      border: `1px solid ${isCurrentProb ? '#3b82f6' : 'var(--panel-border)'}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px'
                    }}
                  >
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: '0.84rem', fontWeight: '800', color: isCurrentProb ? '#60a5fa' : '#fff' }}>
                        EXO {i + 1}
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }} onClick={e => e.stopPropagation()}>
                      {(() => {
                        const isGraded = sub && (sub.manualScore !== null || sub.status === 'GRADED');
                        return (
                          <button
                            className="btn btn-primary"
                            disabled={isCalculatingExercise}
                            onClick={() => handleCalculateExerciseScore(p.id)}
                            style={{
                              padding: '5px 8px',
                              fontSize: '0.75rem',
                              background: isGraded ? 'rgba(139, 92, 246, 0.2)' : 'rgba(59, 130, 246, 0.2)',
                              color: isGraded ? '#c084fc' : '#60a5fa',
                              border: '1px solid ' + (isGraded ? 'rgba(139, 92, 246, 0.4)' : 'rgba(59, 130, 246, 0.4)'),
                              fontWeight: '700',
                              cursor: isCalculatingExercise ? 'not-allowed' : 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                            title={isGraded ? "Recalculer la note de cet exercice" : "Calculer la note de cet exercice"}
                          >
                            {isGraded ? <RefreshCw size={13} /> : <Zap size={13} />}
                          </button>
                        );
                      })()}

                      <input
                        type="number"
                        step="0.25"
                        min="0"
                        max={p.points}
                        className="form-input"
                        placeholder="0"
                        value={scoreVal}
                        onChange={e => handleScoreChange(p.id, e.target.value)}
                        style={{ width: '55px', padding: '4px 6px', fontSize: '0.9rem', fontWeight: '700', textAlign: 'center' }}
                      />
                      <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>/ {p.points}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Scaled Grade Display Box /20 - Single Line */}
          <div style={{
            padding: '12px 18px', background: 'rgba(16,185,129,0.12)', borderRadius: '10px',
            border: '1px solid rgba(16,185,129,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
          }}>
            <div style={{ fontSize: '0.92rem', color: '#34d399', fontWeight: '800', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              🏆 Note Finale
            </div>
            <div style={{ fontSize: '1.7rem', fontWeight: '900', color: '#34d399', lineHeight: '1' }}>
              {scaledGrade20} <span style={{ fontSize: '1.05rem', color: '#93c5fd' }}>/ 20</span>
            </div>
          </div>

          {/* General Appreciation Note with 5 Random Variants */}
          <div className="glass-panel" style={{ padding: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <label style={{ fontSize: '0.8rem', fontWeight: '700', margin: 0, color: 'var(--text-muted)' }}>
                💬 Appréciation Globale:
              </label>
              <button
                className="btn btn-secondary"
                style={{ padding: '2px 8px', fontSize: '0.72rem', color: '#c084fc', background: 'rgba(168,85,247,0.15)' }}
                onClick={() => {
                  const suggested = getSuggestedAppreciation(scaledGrade20);
                  setGeneralFeedbackInput(suggested);
                  setIsManualFeedbackEdit(false);
                }}
                title="Tirer au sort une autre variante de l'appréciation pour cette note"
              >
                <Wand2 size={12} /> ✨ Régénérer
              </button>
            </div>
            <textarea
              className="form-input"
              rows={3}
              placeholder="Remarques globales pour l'étudiant..."
              value={generalFeedbackInput}
              onChange={e => {
                setGeneralFeedbackInput(e.target.value);
                setIsManualFeedbackEdit(true);
              }}
              style={{ fontSize: '0.82rem', resize: 'vertical' }}
            />
          </div>

          {/* Single Validation Button */}
          <button
            className="btn btn-success"
            onClick={handleValidateStudentCopy}
            disabled={isValidatingCopy}
            style={{
              width: '100%', padding: '12px', fontSize: '0.92rem', fontWeight: '800',
              background: isValidatingCopy ? 'rgba(16,185,129,0.5)' : 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
              boxShadow: '0 4px 14px rgba(16,185,129,0.3)',
              cursor: isValidatingCopy ? 'not-allowed' : 'pointer'
            }}
          >
            {isValidatingCopy ? (
              <span>⌛ Validation en cours...</span>
            ) : (
              <><CheckCircle size={18} /> Valider Copie ({scaledGrade20}/20) &amp; Suivant →</>
            )}
          </button>

        </div>
      </div>

      {/* ── REAL VISUAL AST TREE GRAPH MODAL ── */}
      {showASTModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '20px' }}>
          <div className="glass-panel" style={{ width: '92%', maxWidth: '1240px', height: '88vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', border: '1px solid var(--panel-border)' }}>
            <div style={{ padding: '14px 20px', background: 'rgba(17,24,39,0.95)', borderBottom: '1px solid var(--panel-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                <GitFork size={20} color="#a78bfa" />
                <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>
                  🌳 Arbre Syntaxique Abstrait (AST)
                </h3>
              </div>
              <button onClick={() => setShowASTModal(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={22} />
              </button>
            </div>

            <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', padding: '16px', overflow: 'hidden', background: '#05070d' }}>
              {/* Student Real AST Tree Graph */}
              <div style={{ display: 'flex', flexDirection: 'column', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--panel-border)', overflow: 'hidden' }}>
                <div style={{ padding: '8px 14px', background: 'rgba(59,130,246,0.15)', color: '#60a5fa', fontSize: '0.8rem', fontWeight: '700', borderBottom: '1px solid var(--panel-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>📄 Arbre AST Code Soumis (Anonyme [{currentAssignment?.accessNumber || 'N/A'}])</span>
                  <span style={{ fontSize: '0.72rem', color: '#93c5fd' }}>
                    {studentAST ? `${studentAST.body?.length || 0} instructions principal(es)` : 'Aucun arbre'}
                  </span>
                </div>
                <div style={{ flex: 1, padding: '16px', overflow: 'auto' }}>
                  {studentAST ? <RealASTTreeNodeGraph node={studentAST} /> : <div style={{ color: 'var(--text-muted)' }}>Arbre AST non disponible</div>}
                </div>
              </div>

              {/* Reference Solution Real AST Tree Graph */}
              <div style={{ display: 'flex', flexDirection: 'column', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', border: '1px solid var(--panel-border)', overflow: 'hidden' }}>
                <div style={{ padding: '8px 14px', background: 'rgba(52,211,153,0.15)', color: '#34d399', fontSize: '0.8rem', fontWeight: '700', borderBottom: '1px solid var(--panel-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>💡 Arbre AST Solution Repère ({currentProblem?.title || 'Solution Repère'})</span>
                  <span style={{ fontSize: '0.72rem', color: '#a7f3d0' }}>
                    {refAST ? `${refAST.body?.length || 0} instructions principal(es)` : 'Aucun arbre'}
                  </span>
                </div>
                <div style={{ flex: 1, padding: '16px', overflow: 'auto' }}>
                  {refAST ? <RealASTTreeNodeGraph node={refAST} /> : <div style={{ color: 'var(--text-muted)' }}>Arbre AST non disponible</div>}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── MODULE 2: INTERACTIVE SOLUTION & AST COMPARISON MODAL ── */}
      <CompareSolutionsModal
        isOpen={showCompareSolutionsModal}
        onClose={() => setShowCompareSolutionsModal(false)}
        studentCode={studentCode}
        referenceSolution={currentProblem?.referenceSolution}
        studentAST={studentAST}
        refAST={refAST}
        similarityRatio={similarityRatio}
      />

      {/* ── PLAGIARISM / SIMILARITY DIFF COMPARISON MODAL ── */}
      {similarityCompareModal.isOpen && (
        <CompareSimilarityModal
          isOpen={similarityCompareModal.isOpen}
          onClose={() => setSimilarityCompareModal({ isOpen: false, targetStudent: null, targetCode: '', metrics: null })}
          currentStudent={currentStudent}
          targetStudent={similarityCompareModal.targetStudent}
          currentCode={studentCode}
          targetCode={similarityCompareModal.targetCode}
          metrics={similarityCompareModal.metrics}
        />
      )}

      {/* ── SUB-QUESTION AST COMPARISON MODAL ── */}
      {selectedQuestionCompare && (
        <CompareSolutionsModal
          isOpen={!!selectedQuestionCompare}
          onClose={() => setSelectedQuestionCompare(null)}
          studentCode={selectedQuestionCompare.studentCode}
          referenceSolution={selectedQuestionCompare.refCode}
          similarityRatio={selectedQuestionCompare.similarityRatio}
          modalTitle={`Question ${selectedQuestionCompare.questionNum}`}
        />
      )}

    </div>
  );
}
