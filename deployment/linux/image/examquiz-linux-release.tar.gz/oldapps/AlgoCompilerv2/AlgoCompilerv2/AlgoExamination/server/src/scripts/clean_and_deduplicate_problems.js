const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

function normalizeTitle(t) {
  if (!t) return '';
  return t
    .replace(/\s*\(Final\s*\d+\)\s*/gi, '')
    .replace(/\s*\(v\d+\)\s*/gi, '')
    .trim();
}

// 12 Test Cases Generator Helper: 2 Public + 10 Hidden
function build12TestCases(probTitle) {
  const norm = (probTitle || '').toLowerCase();

  if (norm.includes('somme de deux entiers')) {
    return [
      // 2 Public
      { input: '5\n10', expectedOutput: '15', weight: 1, isHidden: false },
      { input: '0\n7', expectedOutput: '7', weight: 1, isHidden: false },
      // 10 Hidden
      { input: '-3\n8', expectedOutput: '5', weight: 1, isHidden: true },
      { input: '100\n200', expectedOutput: '300', weight: 1, isHidden: true },
      { input: '-50\n-20', expectedOutput: '-70', weight: 1, isHidden: true },
      { input: '999\n1', expectedOutput: '1000', weight: 1, isHidden: true },
      { input: '0\n0', expectedOutput: '0', weight: 1, isHidden: true },
      { input: '1234\n5678', expectedOutput: '6912', weight: 1, isHidden: true },
      { input: '-1000\n1000', expectedOutput: '0', weight: 1, isHidden: true },
      { input: '42\n58', expectedOutput: '100', weight: 1, isHidden: true },
      { input: '15\n-30', expectedOutput: '-15', weight: 1, isHidden: true },
      { input: '8888\n1112', expectedOutput: '10000', weight: 1, isHidden: true }
    ];
  }

  if (norm.includes('maximum d\'un tableau') || norm.includes('maximum d')) {
    return [
      // 2 Public
      { input: '5\n10 20 5 40 30', expectedOutput: '40', weight: 1, isHidden: false },
      { input: '3\n-5 -2 -10', expectedOutput: '-2', weight: 1, isHidden: false },
      // 10 Hidden
      { input: '1\n100', expectedOutput: '100', weight: 1, isHidden: true },
      { input: '4\n0 0 0 0', expectedOutput: '0', weight: 1, isHidden: true },
      { input: '6\n1 2 3 4 5 6', expectedOutput: '6', weight: 1, isHidden: true },
      { input: '6\n6 5 4 3 2 1', expectedOutput: '6', weight: 1, isHidden: true },
      { input: '5\n-100 50 -20 0 10', expectedOutput: '50', weight: 1, isHidden: true },
      { input: '4\n8 8 8 8', expectedOutput: '8', weight: 1, isHidden: true },
      { input: '7\n12 45 89 23 67 34 89', expectedOutput: '89', weight: 1, isHidden: true },
      { input: '5\n99 100 1 2 3', expectedOutput: '100', weight: 1, isHidden: true },
      { input: '3\n-1000 0 -500', expectedOutput: '0', weight: 1, isHidden: true },
      { input: '8\n5 12 7 99 2 4 80 1', expectedOutput: '99', weight: 1, isHidden: true }
    ];
  }

  if (norm.includes('tri à bulles') || norm.includes('tri par sélection') || norm.includes('tri par insertion') || norm.includes('tri')) {
    return [
      // 2 Public
      { input: '5\n5 3 1 4 2', expectedOutput: '1 2 3 4 5', weight: 1, isHidden: false },
      { input: '4\n10 20 30 40', expectedOutput: '10 20 30 40', weight: 1, isHidden: false },
      // 10 Hidden
      { input: '3\n3 2 1', expectedOutput: '1 2 3', weight: 1, isHidden: true },
      { input: '1\n42', expectedOutput: '42', weight: 1, isHidden: true },
      { input: '5\n-5 0 -10 15 2', expectedOutput: '-10 -5 0 2 15', weight: 1, isHidden: true },
      { input: '4\n5 5 5 5', expectedOutput: '5 5 5 5', weight: 1, isHidden: true },
      { input: '6\n100 1 50 25 75 0', expectedOutput: '0 1 25 50 75 100', weight: 1, isHidden: true },
      { input: '5\n9 8 7 6 5', expectedOutput: '5 6 7 8 9', weight: 1, isHidden: true },
      { input: '6\n12 2 45 3 100 1', expectedOutput: '1 2 3 12 45 100', weight: 1, isHidden: true },
      { input: '4\n-1 -2 -3 -4', expectedOutput: '-4 -3 -2 -1', weight: 1, isHidden: true },
      { input: '5\n0 10 0 5 0', expectedOutput: '0 0 0 5 10', weight: 1, isHidden: true },
      { input: '7\n4 2 6 1 5 3 7', expectedOutput: '1 2 3 4 5 6 7', weight: 1, isHidden: true }
    ];
  }

  if (norm.includes('voyelles')) {
    return [
      // 2 Public
      { input: 'algorithme', expectedOutput: '4', weight: 1, isHidden: false },
      { input: 'bonjour', expectedOutput: '3', weight: 1, isHidden: false },
      // 10 Hidden
      { input: 'php', expectedOutput: '0', weight: 1, isHidden: true },
      { input: 'aeiouy', expectedOutput: '6', weight: 1, isHidden: true },
      { input: 'EXAMEN', expectedOutput: '3', weight: 1, isHidden: true },
      { input: 'UNIVERSITE', expectedOutput: '5', weight: 1, isHidden: true },
      { input: 'bcdfg', expectedOutput: '0', weight: 1, isHidden: true },
      { input: 'a', expectedOutput: '1', weight: 1, isHidden: true },
      { input: 'z', expectedOutput: '0', weight: 1, isHidden: true },
      { input: 'programmation', expectedOutput: '5', weight: 1, isHidden: true },
      { input: 'ordinateur', expectedOutput: '5', weight: 1, isHidden: true },
      { input: 'abracadabra', expectedOutput: '5', weight: 1, isHidden: true }
    ];
  }

  if (norm.includes('factorielle')) {
    return [
      // 2 Public
      { input: '5', expectedOutput: '120', weight: 1, isHidden: false },
      { input: '0', expectedOutput: '1', weight: 1, isHidden: false },
      // 10 Hidden
      { input: '1', expectedOutput: '1', weight: 1, isHidden: true },
      { input: '3', expectedOutput: '6', weight: 1, isHidden: true },
      { input: '4', expectedOutput: '24', weight: 1, isHidden: true },
      { input: '6', expectedOutput: '720', weight: 1, isHidden: true },
      { input: '7', expectedOutput: '5040', weight: 1, isHidden: true },
      { input: '8', expectedOutput: '40320', weight: 1, isHidden: true },
      { input: '9', expectedOutput: '362880', weight: 1, isHidden: true },
      { input: '10', expectedOutput: '3628800', weight: 1, isHidden: true },
      { input: '2', expectedOutput: '2', weight: 1, isHidden: true },
      { input: '5', expectedOutput: '120', weight: 1, isHidden: true }
    ];
  }

  if (norm.includes('recherche dichotomique')) {
    return [
      // 2 Public
      { input: '5\n10 20 30 40 50\n30', expectedOutput: '3', weight: 1, isHidden: false },
      { input: '5\n10 20 30 40 50\n99', expectedOutput: '-1', weight: 1, isHidden: false },
      // 10 Hidden
      { input: '5\n10 20 30 40 50\n10', expectedOutput: '1', weight: 1, isHidden: true },
      { input: '5\n10 20 30 40 50\n50', expectedOutput: '5', weight: 1, isHidden: true },
      { input: '1\n42\n42', expectedOutput: '1', weight: 1, isHidden: true },
      { input: '1\n42\n100', expectedOutput: '-1', weight: 1, isHidden: true },
      { input: '6\n2 4 6 8 10 12\n8', expectedOutput: '4', weight: 1, isHidden: true },
      { input: '6\n2 4 6 8 10 12\n5', expectedOutput: '-1', weight: 1, isHidden: true },
      { input: '4\n-10 -5 0 5\n-5', expectedOutput: '2', weight: 1, isHidden: true },
      { input: '4\n-10 -5 0 5\n0', expectedOutput: '3', weight: 1, isHidden: true },
      { input: '5\n1 3 5 7 9\n1', expectedOutput: '1', weight: 1, isHidden: true },
      { input: '5\n1 3 5 7 9\n9', expectedOutput: '5', weight: 1, isHidden: true }
    ];
  }

  // Default 12 test cases fallback
  return [
    { input: '5\n1 2 3 4 5', expectedOutput: '15', weight: 1, isHidden: false },
    { input: '3\n10 20 30', expectedOutput: '60', weight: 1, isHidden: false },
    { input: '1\n5', expectedOutput: '5', weight: 1, isHidden: true },
    { input: '2\n0 0', expectedOutput: '0', weight: 1, isHidden: true },
    { input: '4\n-1 -2 -3 -4', expectedOutput: '-10', weight: 1, isHidden: true },
    { input: '3\n100 200 300', expectedOutput: '600', weight: 1, isHidden: true },
    { input: '5\n2 2 2 2 2', expectedOutput: '10', weight: 1, isHidden: true },
    { input: '4\n5 10 15 20', expectedOutput: '50', weight: 1, isHidden: true },
    { input: '3\n-50 50 100', expectedOutput: '100', weight: 1, isHidden: true },
    { input: '2\n42 58', expectedOutput: '100', weight: 1, isHidden: true },
    { input: '1\n0', expectedOutput: '0', weight: 1, isHidden: true },
    { input: '5\n10 10 10 10 10', expectedOutput: '50', weight: 1, isHidden: true }
  ];
}

// Chapter tags mapping helper
function buildAlgoChapterTags(probTitle) {
  const norm = (probTitle || '').toLowerCase();
  if (norm.includes('somme de deux entiers') || norm.includes('factorielle')) {
    return ["Chapitre 1: Introduction à l'Algorithmique", "Chapitre 5: Actions Paramétrées (Fonctions & Procédures)"];
  }
  if (norm.includes('tableau') || norm.includes('tri') || norm.includes('matrices') || norm.includes('dichotomique')) {
    return ["Chapitre 2: Tableaux et Matrices"];
  }
  if (norm.includes('voyelles') || norm.includes('chaîne') || norm.includes('chaine')) {
    return ["Chapitre 3: Chaînes de Caractères"];
  }
  return ["Chapitre 1: Introduction à l'Algorithmique"];
}

// Rich Markdown description builder helper
function buildRichMarkdownDescription(title, desc) {
  if (desc && desc.includes('## 🎯 Objectif')) {
    return desc;
  }
  return `## 🎯 Objectif
${desc || 'Écrire un algorithme permettant de résoudre le problème demandé en respectant la syntaxe ALGO.'}

### 📥 Entrées (STDIN)
- **Ligne 1** : \`N\` (ENTIER) — Taille ou données principales.
- **Lignes suivantes** : Valeurs saisies sur la sortie standard.

### 📤 Sorties Attendues (STDOUT)
- Afficher le résultat calculé sur la sortie standard.

### 💡 Exemple d'Exécution
**Entrée :**
\`\`\`
5
10 20 30 40 50
\`\`\`

**Sortie Attendue :**
\`\`\`
50
\`\`\`

### ⚠️ Contraintes & Remarques
- $1 \\le N \\le 1000$
- Respecter scrupuleusement la structure des blocs \`VAR\`, \`DEBUT\` et \`FIN.\`.`;
}

async function cleanDeduplicateAndEnrichProblems() {
  console.log('🧹 Starting DB Problems Cleanup, 12 Test Cases Generation & JSON Export...');

  try {
    const allProblems = await prisma.problem.findMany({
      orderBy: { createdAt: 'asc' }
    });

    console.log(`🔍 Total raw problems in DB: ${allProblems.length}`);

    const seenMap = new Map();
    const duplicatesToDelete = [];

    for (const prob of allProblems) {
      const cleanTitle = normalizeTitle(prob.title);
      const key = cleanTitle.toLowerCase();

      if (!seenMap.has(key)) {
        seenMap.set(key, prob);
      } else {
        const primaryProb = seenMap.get(key);
        duplicatesToDelete.push({ duplicate: prob, primary: primaryProb });
      }
    }

    console.log(`✨ Found ${seenMap.size} unique problems and ${duplicatesToDelete.length} duplicates to delete.`);

    // Delete duplicates cleanly
    for (const item of duplicatesToDelete) {
      const dupId = item.duplicate.id;
      const primaryId = item.primary.id;

      const examProbs = await prisma.examProblem.findMany({ where: { problemId: dupId } });
      for (const ep of examProbs) {
        const existingPrimaryLink = await prisma.examProblem.findUnique({
          where: { examId_problemId: { examId: ep.examId, problemId: primaryId } }
        });
        if (!existingPrimaryLink) {
          await prisma.examProblem.update({
            where: { id: ep.id },
            data: { problemId: primaryId }
          });
        } else {
          await prisma.examProblem.delete({ where: { id: ep.id } });
        }
      }

      await prisma.submission.updateMany({
        where: { problemId: dupId },
        data: { problemId: primaryId }
      });

      await prisma.problem.delete({ where: { id: dupId } });
      console.log(`  ❌ Deleted duplicate: "${item.duplicate.title}" (ID: ${dupId.slice(0, 8)})`);
    }

    // Now update all remaining unique problems with AlgoCompiler Chapter tags, rich Markdown, and 12 test cases
    const cleanProblems = await prisma.problem.findMany({
      orderBy: { createdAt: 'asc' }
    });

    for (const prob of cleanProblems) {
      const cleanTitle = normalizeTitle(prob.title);
      const chapterTags = buildAlgoChapterTags(cleanTitle);
      const richDesc = buildRichMarkdownDescription(cleanTitle, prob.description);
      const testSuite12 = build12TestCases(cleanTitle);

      // Delete existing relation test cases
      await prisma.testCase.deleteMany({ where: { problemId: prob.id } });

      await prisma.problem.update({
        where: { id: prob.id },
        data: {
          title: cleanTitle,
          description: richDesc,
          tags: chapterTags,
          testCases: {
            create: testSuite12.map(t => ({
              inputData: t.input,
              expectedOutput: t.expectedOutput,
              isPublic: !t.isHidden
            }))
          }
        }
      });
    }

    // Refresh directory JSON files
    const jsonDirs = [
      path.join(__dirname, '../../data/problems'),
      path.join(__dirname, '../../../client/public/problems')
    ];

    jsonDirs.forEach(dir => {
      if (fs.existsSync(dir)) {
        fs.readdirSync(dir).forEach(file => {
          if (file.endsWith('.json')) {
            fs.unlinkSync(path.join(dir, file));
          }
        });
      } else {
        fs.mkdirSync(dir, { recursive: true });
      }
    });

    // Re-fetch updated records and output JSON files
    const updatedProblems = await prisma.problem.findMany({
      include: { testCases: true },
      orderBy: { createdAt: 'asc' }
    });

    let count = 0;
    for (const prob of updatedProblems) {
      const slug = (prob.title || 'problem')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');

      const fileName = `Probleme_${slug}_${prob.id.slice(0, 8)}.json`;

      const formattedTestCases = (prob.testCases || []).map(tc => ({
        input: tc.inputData,
        expectedOutput: tc.expectedOutput,
        weight: 1,
        isHidden: !tc.isPublic
      }));

      const jsonPayload = {
        id: prob.id,
        title: prob.title,
        description: prob.description || '',
        difficulty: prob.difficulty || 'MOYEN',
        topic: prob.topic || 'ALGO',
        tags: prob.tags,
        points: prob.points || 10,
        timeLimitMs: prob.timeLimitMs || 2000,
        starterTemplate: prob.starterTemplate || (prob.templateCode && prob.templateCode.ALGO) || '',
        referenceSolution: prob.referenceSolution || '',
        testCases: formattedTestCases,
        createdAt: prob.createdAt
      };

      const jsonString = JSON.stringify(jsonPayload, null, 2);

      jsonDirs.forEach(dir => {
        fs.writeFileSync(path.join(dir, fileName), jsonString, 'utf8');
      });

      count++;
      console.log(`  [${count}/${updatedProblems.length}] Clean JSON saved: ${fileName} (${prob.tags.join(', ')} — 2 Public + 10 Hidden Tests)`);
    }

    console.log(`\n🎉 Success! All ${updatedProblems.length} problems updated with AlgoCompiler chapter tags, rich Markdown descriptions, and 12 test cases (2 public + 10 hidden)!`);
  } catch (err) {
    console.error('❌ Cleanup failed:', err);
  } finally {
    await prisma.$disconnect();
  }
}

cleanDeduplicateAndEnrichProblems();
