import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  listExams,
  getExamDetails,
  updateExamStatus,
  deleteExam,
  teacherEmergencyControl,
  getExamResults,
  autoGradeExam,
  resetExamScores,
  listStudents,
  exportExamTemplate,
  importExamTemplate,
  cloneExamAsTemplate,
  exportExamBundle,
  importExamBundles,
  exportExamResults,
  importExamResults
} from '../services/api';
import { getSocket, joinExamRoom } from '../services/socket';
import SystemSettingsModal, { getSystemVaultKey } from './SystemSettingsModal';
import FileDropZone from './FileDropZone';
import {
  Users, Play, Pause, Clock, ShieldAlert, Plus, RefreshCw,
  Lock, Unlock, Radio, FileSpreadsheet, BookOpen, ArrowLeft,
  CheckCircle, XCircle, AlertCircle, Wifi, WifiOff, Eye,
  BarChart2, Send, X, Zap, Square, TrendingUp, Download, Trophy, Trash2,
  Package, Upload, FileCode, Edit3, Building, RotateCcw, Settings, LogOut,
  MoreVertical
} from 'lucide-react';
import Swal from 'sweetalert2';
import ExamResults from './ExamResults';
import CorrectionWorkspace from './CorrectionWorkspace';
import ExamLauncher from './ExamLauncher';
import ExamMonitor from './ExamMonitor';
import ExamManager from './ExamManager';

/* ── Status meta ─────────────────────────────────────────── */
const EXAM_STATUS = {
  DRAFT:     { label: 'Modèle (Brouillon)', cls: 'badge-secondary', color: '#6b7280' },
  SCHEDULED: { label: 'Modèle (Planifié)',  cls: 'badge-yellow',    color: '#f59e0b' },
  WAITING:   { label: 'En Attente',         cls: 'badge-yellow',    color: '#f59e0b' },
  RUNNING:   { label: 'En Cours (LIVE)',    cls: 'badge-green',     color: '#10b981' },
  PAUSED:    { label: 'Suspendu',           cls: 'badge-yellow',    color: '#f59e0b' },
  FINISHED:  { label: 'Terminé',            cls: 'badge-blue',      color: '#60a5fa' },
  CLOSED:    { label: 'Clôturé',            cls: 'badge-secondary', color: '#6b7280' },
};

const STUDENT_STATUS = {
  NOT_ENTERED:  { label: 'Non commencé',       cls: 'badge-secondary', color: '#6b7280' },
  WAITING:      { label: 'En attente',         cls: 'badge-yellow',    color: '#f59e0b' },
  IN_EXAM:      { label: 'En épreuve',         cls: 'badge-green',     color: '#10b981' },
  PAUSED:       { label: 'Suspendu',           cls: 'badge-yellow',    color: '#f59e0b' },
  FINISHED:     { label: 'Terminé',            cls: 'badge-blue',      color: '#60a5fa' },
  KICKED_OUT:   { label: 'Exclu',              cls: 'badge-red',       color: '#ef4444' },
  ABSENT:       { label: 'Absent',             cls: 'badge-secondary', color: '#6b7280' },
};

/* ── Helpers ─────────────────────────────────────────────── */
const relativeTime = (dt) => {
  if (!dt) return '—';
  const s = Math.floor((Date.now() - new Date(dt)) / 1000);
  if (s < 5)  return 'à l\'instant';
  if (s < 60) return `il y a ${s}s`;
  if (s < 3600) return `il y a ${Math.floor(s/60)}min`;
  return new Date(dt).toLocaleTimeString('fr-FR');
};

/* ═══════════════════════════════════════════════════════════
   ROOT COMPONENT
═══════════════════════════════════════════════════════════ */
export default function TeacherDashboard({ onNavigate, onLogout }) {
  const [view, setView]                   = useState(() => localStorage.getItem('teacher_dashboard_view') || 'EXAM_LIST'); // EXAM_LIST | EXAM_LAUNCH | EXAM_MONITOR | EXAM_RESULTS | EXAM_CORRECTION
  const [selectedExam, setSelectedExam]   = useState(() => {
    try {
      const saved = localStorage.getItem('teacher_selected_exam');
      return saved ? JSON.parse(saved) : null;
    } catch (_) {
      return null;
    }
  });
  const [students, setStudents] = useState([]);

  useEffect(() => {
    localStorage.setItem('teacher_dashboard_view', view);
  }, [view]);

  useEffect(() => {
    if (selectedExam) {
      localStorage.setItem('teacher_selected_exam', JSON.stringify(selectedExam));
    } else {
      localStorage.removeItem('teacher_selected_exam');
    }
  }, [selectedExam]);

  useEffect(() => {
    listStudents().then(setStudents).catch(console.error);
  }, []);

  const [autoGradingExamId, setAutoGradingExamId] = useState(null);
  const [autoGradeProgress, setAutoGradeProgress] = useState(null);

  const handleViewCorrection = (exam) => {
    if (autoGradingExamId === exam.id) {
      Swal.fire({
        icon: 'warning',
        title: 'Correction en cours',
        text: 'La correction automatique de cet examen est en cours. L\'accès à la correction manuelle est désactivé jusqu\'à la fin du traitement.',
        background: '#111827',
        color: '#fff'
      });
      return;
    }
    setSelectedExam(exam);
    setView('EXAM_CORRECTION');
  };

  if (view === 'EXAM_LAUNCH' && selectedExam) {
    return (
      <ExamLauncher
        exam={selectedExam}
        students={students}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); }}
        onExamLaunched={(updatedExam) => {
          setSelectedExam(updatedExam);
          setView('EXAM_MONITOR');
        }}
      />
    );
  }

  if (view === 'EXAM_CORRECTION' && selectedExam) {
    return (
      <CorrectionWorkspace
        examId={selectedExam.id}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); }}
        onViewResults={() => setView('EXAM_RESULTS')}
      />
    );
  }

  if (view === 'EXAM_RESULTS' && selectedExam) {
    return (
      <ExamResults
        examId={selectedExam.id}
        examTitle={selectedExam.title}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); }}
      />
    );
  }

  if (view === 'EXAM_MONITOR' && selectedExam) {
    return (
      <ExamMonitor
        exam={selectedExam}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); }}
        onViewResults={() => setView('EXAM_RESULTS')}
        onViewCorrection={() => handleViewCorrection(selectedExam)}
        onNavigate={onNavigate}
        autoGradingExamId={autoGradingExamId}
      />
    );
  }

  if (view === 'EXAM_EDIT' && selectedExam) {
    return (
      <ExamManager
        initialEditingExam={selectedExam}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); }}
      />
    );
  }

  return (
    <ExamList
      onLaunchExam={(exam) => { setSelectedExam(exam); setView('EXAM_LAUNCH'); }}
      onEnterExam={(exam) => { setSelectedExam(exam); setView('EXAM_MONITOR'); }}
      onEditExam={(exam) => { setSelectedExam(exam); setView('EXAM_EDIT'); }}
      onViewResults={(exam) => { setSelectedExam(exam); setView('EXAM_RESULTS'); }}
      onViewCorrection={(exam) => handleViewCorrection(exam)}
      onNavigate={onNavigate}
      onLogout={onLogout}
      autoGradingExamId={autoGradingExamId}
      setAutoGradingExamId={setAutoGradingExamId}
      autoGradeProgress={autoGradeProgress}
      setAutoGradeProgress={setAutoGradeProgress}
    />
  );
}

/* ═══════════════════════════════════════════════════════════
   EXAM LIST  (main menu)
 ═══════════════════════════════════════════════════════════ */
function ExamList({
  onLaunchExam,
  onEnterExam,
  onEditExam,
  onViewResults,
  onViewCorrection,
  onNavigate,
  onLogout,
  autoGradingExamId,
  setAutoGradingExamId,
  autoGradeProgress,
  setAutoGradeProgress
}) {
  const [exams, setExams]             = useState([]);
  const [activeTab, setActiveTab]     = useState(() => {
    return localStorage.getItem('algo_teacher_active_tab') || 'EXAM_SUBJECTS';
  }); // 'EXAM_SUBJECTS' | 'EXAM_SESSIONS' | 'ALL'
  const [loading, setLoading]         = useState(true);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [openMenuExamId, setOpenMenuExamId] = useState(null);
  const pollRef                       = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!e.target.closest('.exam-actions-menu-container')) {
        setOpenMenuExamId(null);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const load = useCallback(async () => {
    try {
      const data = await listExams();
      setExams(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    load();
    pollRef.current = setInterval(load, 8000); // fast refresh every 8s
    return () => clearInterval(pollRef.current);
  }, [load]);

  const handleStatusChange = async (exam, newStatus) => {
    try {
      await updateExamStatus(exam.id, newStatus);
      load();
      Swal.fire({ icon: 'success', title: `Statut → ${EXAM_STATUS[newStatus]?.label || newStatus}`, timer: 1200, showConfirmButton: false, background: '#111827', color: '#fff' });
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Erreur', text: err.data?.error || err.message, background: '#111827', color: '#fff' });
    }
  };

  // Export Exam Template (.algoexam)
  const handleExportTemplate = async (examId, title) => {
    try {
      const examObj = exams.find(e => e.id === examId);
      const moduleName = (examObj?.module || 'ASD').replace(/[^\w]/g, '_');
      const safeTitle = (title || examObj?.title || 'Examen').replace(/[^\w]/g, '_');
      const examCode = (examObj?.examCode || '').replace(/[^\w]/g, '_');

      const templateData = await exportExamTemplate(examId);
      const jsonStr = JSON.stringify(templateData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Sujet_${moduleName}_${safeTitle}${examCode ? '_' + examCode : ''}.algoexam`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: 'Modèle Exporté !',
        text: 'Le fichier chiffré .algoexam a été téléchargé avec succès.',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export template error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Impossible d’exporter le modèle d’examen.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Clone/Duplicate Exam into a clean DRAFT Subject Template (.algoexam)
  const handleDuplicateAsTemplate = async (exam) => {
    try {
      const res = await cloneExamAsTemplate(exam.id);
      await load();
      Swal.fire({
        icon: 'success',
        title: 'Modèle de Sujet Créé !',
        text: `Le modèle "${res.exam?.title || exam.title}" est maintenant disponible dans vos sujets d'examen (.algoexam).`,
        background: '#111827',
        color: '#fff'
      });
      setActiveTab('EXAM_SUBJECTS');
    } catch (err) {
      console.error('Clone template error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur',
        text: err.data?.error || err.message || 'Impossible de cloner ce modèle.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Export Encrypted Submission Bundle (.algobundle)
  const handleExportBundle = async (examId, title) => {
    try {
      const examObj = exams.find(e => e.id === examId);
      const moduleName = (examObj?.module || 'ASD').replace(/[^\w]/g, '_');
      const safeTitle = (title || examObj?.title || 'Examen').replace(/[^\w]/g, '_');
      const roomStr = (examObj?.room || 'Salle').replace(/[^\w]/g, '_');
      const examCode = (examObj?.examCode || '').replace(/[^\w]/g, '_');

      const vaultKey = getSystemVaultKey();
      const encryptedData = await exportExamBundle(examId, vaultKey);
      const jsonStr = JSON.stringify(encryptedData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Copies_${moduleName}_${safeTitle}_${roomStr}${examCode ? '_' + examCode : ''}.algobundle`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: '📦 Paquet Exporté !',
        text: 'Le fichier chiffré .algobundle a été téléchargé avec succès.',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export bundle error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Impossible d’exporter le paquet.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Export Encrypted Results (.algoresults)
  const handleExportResults = async (examId, title) => {
    try {
      const examObj = exams.find(e => e.id === examId);
      const moduleName = (examObj?.module || 'ASD').replace(/[^\w]/g, '_');
      const safeTitle = (title || examObj?.title || 'Examen').replace(/[^\w]/g, '_');
      const examCode = (examObj?.examCode || '').replace(/[^\w]/g, '_');

      const vaultKey = getSystemVaultKey();
      const encryptedData = await exportExamResults(examId, vaultKey);
      const jsonStr = JSON.stringify(encryptedData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Resultats_Officiels_${moduleName}_${safeTitle}${examCode ? '_' + examCode : ''}.algoresults`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: '📊 Résultats Exportés !',
        text: 'Le fichier chiffré .algoresults a été téléchargé avec succès.',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export results error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Impossible d’exporter les résultats.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Import and Fuse Submission Bundles (.algobundle)
  const handleImportBundles = async (examId, title) => {
    const { value: formValues } = await Swal.fire({
      title: '📥 Fusionner des Paquets de Salles (.algobundle)',
      html: `
        <div style="text-align: left; font-size: 0.88rem; color: #cbd5e1; display: flex; flex-direction: column; gap: 12px;">
          <p style="margin: 0; color: #93c5fd;">Sélectionnez les fichiers .algobundle provenant d'autres salles pour fusionner les soumissions de cette épreuve.</p>
          <div>
            <label style="display: block; margin-bottom: 4px; font-weight: bold;">Fichiers .algobundle :</label>
            <input type="file" id="swal-bundles-files" multiple accept=".algobundle,.json" style="width: 100%; font-size: 0.82rem; background: #0f172a; padding: 8px; border: 1px solid #334155; border-radius: 4px; color: #fff;" />
          </div>
          <div>
            <label style="display: block; margin-bottom: 4px; font-size: 0.78rem; color: #94a3b8;">Mot de passe personnalisé (optionnel) :</label>
            <input type="password" id="swal-bundles-passphrase" placeholder="Optionnel (Déchiffrement auto)" style="width: 100%; font-size: 0.82rem; background: #0f172a; padding: 6px; border: 1px solid #334155; border-radius: 4px; color: #fff;" />
          </div>
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: 'Déchiffrer & Fusionner',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff',
      preConfirm: () => {
        const filesInput = document.getElementById('swal-bundles-files');
        const passInput = document.getElementById('swal-bundles-passphrase');
        if (!filesInput.files || filesInput.files.length === 0) {
          Swal.showValidationMessage('Veuillez sélectionner au moins un fichier .algobundle');
          return false;
        }
        return { files: filesInput.files, passphrase: passInput.value.trim() };
      }
    });

    if (!formValues) return;

    try {
      const vaultKey = getSystemVaultKey();
      const formData = new FormData();
      for (let i = 0; i < formValues.files.length; i++) {
        formData.append('bundles', formValues.files[i]);
      }
      formData.append('passphrase', formValues.passphrase || vaultKey);

      const res = await importExamBundles(examId, formData);
      Swal.fire({
        icon: 'success',
        title: 'Fusion Réussie !',
        html: `
          <div style="text-align: left; font-size: 0.9rem; color: #cbd5e1;">
            <p>${res.message}</p>
            <ul style="margin-top: 8px; padding-left: 20px; color: #93c5fd;">
              <li>Nouveaux étudiants : <strong>${res.totalStudentsImported}</strong></li>
              <li>Nouvelles soumissions : <strong>${res.totalSubmissionsImported}</strong></li>
              <li>Soumissions mises à jour : <strong>${res.totalSubmissionsUpdated}</strong></li>
            </ul>
          </div>
        `,
        background: '#111827',
        color: '#fff'
      });
      load();
    } catch (err) {
      console.error('Import bundles error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Fusion',
        text: err.message || 'Échec de la fusion des paquets.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const handleAutoGradeExam = async (exam) => {
    if (exam.status === 'CLOSED') {
      Swal.fire({
        icon: 'info',
        title: 'Examen Déjà Clôturé',
        text: "Cet examen est déjà clôturé et finalisé. La correction automatique n'est pas autorisée sur un examen terminé.",
        background: '#111827',
        color: '#fff'
      });
      return;
    }

    setAutoGradingExamId(exam.id);
    setAutoGradeProgress({ done: 0, total: exam._count?.assignments || 0, pct: 0, studentName: 'Initialisation...' });

    const socket = getSocket();
    joinExamRoom(exam.id, null, true);

    const onProgress = (data) => {
      setAutoGradeProgress(data);
    };

    if (socket) {
      socket.on('auto_grade_progress', onProgress);
    }

    try {
      const res = await autoGradeExam(exam.id);
      Swal.fire({
        icon: 'success',
        title: 'Correction Automatique Terminée !',
        text: res.message || `Toutes les copies (${res.gradedCount} étudiants) ont été corrigées avec attribution automatique des notes.`,
        background: '#111827',
        color: '#fff'
      });
      load();
    } catch (err) {
      console.error('autoGradeExam error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur',
        text: err.data?.error || err.message || 'Échec de la correction automatique.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      if (socket) {
        socket.off('auto_grade_progress', onProgress);
      }
      setAutoGradingExamId(null);
      setAutoGradeProgress(null);
    }
  };

  const handleResetExamScores = async (exam) => {
    const confirm = await Swal.fire({
      title: 'Effacer Toutes les Notes ?',
      text: `Êtes-vous sûr de vouloir réinitialiser toutes les notes pour l'examen "${exam.title}" ? Cette action est irréversible.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Oui, effacer les notes',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff'
    });

    if (confirm.isConfirmed) {
      try {
        const res = await resetExamScores(exam.id);
        Swal.fire({
          icon: 'success',
          title: 'Notes Réinitialisées !',
          text: res.message || 'Toutes les notes ont été effacées avec succès.',
          timer: 2000,
          showConfirmButton: false,
          background: '#111827',
          color: '#fff'
        });
        load();
      } catch (err) {
        Swal.fire({
          icon: 'error',
          title: 'Erreur',
          text: err.data?.error || err.message || 'Échec de la réinitialisation des notes.',
          background: '#111827',
          color: '#fff'
        });
      }
    }
  };

  const handleDeleteExam = async (exam) => {
    const confirm = await Swal.fire({
      title: '🗑️ Supprimer cette Épreuve ?',
      text: `Êtes-vous sûr de vouloir supprimer définitivement l'examen "${exam.title}" ? Cette action est irréversible.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Oui, supprimer',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff'
    });

    if (confirm.isConfirmed) {
      try {
        await deleteExam(exam.id);
        Swal.fire({
          icon: 'success',
          title: 'Examen Supprimé',
          text: 'L\'épreuve a été supprimée avec succès.',
          timer: 1500,
          showConfirmButton: false,
          background: '#111827',
          color: '#fff'
        });
        load();
      } catch (err) {
        Swal.fire({
          icon: 'error',
          title: 'Erreur',
          text: err.data?.error || err.message || 'Impossible de supprimer cet examen.',
          background: '#111827',
          color: '#fff'
        });
      }
    }
  };

  // Modals for Import
  const [isImportTemplateModalOpen, setIsImportTemplateModalOpen] = useState(false);
  const [templateFile, setTemplateFile] = useState(null);
  const [importingTemplate, setImportingTemplate] = useState(false);

  const [isImportBundleModalOpen, setIsImportBundleModalOpen] = useState(false);
  const [bundleFiles, setBundleFiles] = useState([]);
  const [importingBundles, setImportingBundles] = useState(false);
  const [targetExamForBundle, setTargetExamForBundle] = useState(null);

  const handleProcessImportTemplate = async () => {
    if (!templateFile) return;
    setImportingTemplate(true);
    try {
      const formData = new FormData();
      formData.append('template', templateFile);
      const res = await importExamTemplate(formData);
      setIsImportTemplateModalOpen(false);
      setTemplateFile(null);
      await load();
      Swal.fire({
        icon: 'success',
        title: 'Sujet Importé avec Succès !',
        text: `Le sujet "${res.exam?.title}" est prêt dans vos sujets d'examen.`,
        background: '#111827',
        color: '#fff'
      });
      setActiveTab('EXAM_SUBJECTS');
    } catch (err) {
      console.error('Import template error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Importation',
        text: err.data?.error || err.message || 'Fichier .algoexam invalide.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setImportingTemplate(false);
    }
  };

  const handleProcessImportBundles = async () => {
    if (!bundleFiles || bundleFiles.length === 0) return;
    setImportingBundles(true);
    try {
      const vaultKey = getSystemVaultKey();
      const formData = new FormData();
      for (const f of bundleFiles) {
        formData.append('bundles', f);
      }
      if (vaultKey) formData.append('passphrase', vaultKey);

      const targetId = targetExamForBundle?.id || null;
      const res = await importExamBundles(targetId, formData);
      setIsImportBundleModalOpen(false);
      setBundleFiles([]);
      setTargetExamForBundle(null);
      await load();

      Swal.fire({
        icon: 'success',
        title: 'Paquet de Copies Importé !',
        text: res.message || `${bundleFiles.length} paquet(s) de salle synchronisé(s). Prêt pour la correction.`,
        background: '#111827',
        color: '#fff'
      });
      setActiveTab('EXAM_SESSIONS');
    } catch (err) {
      console.error('Import bundles error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Fusion Paquets',
        text: err.data?.error || err.message || 'Impossible d\'importer ces paquets de copies.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setImportingBundles(false);
    }
  };

  const [isImportResultsModalOpen, setIsImportResultsModalOpen] = useState(false);
  const [resultsFiles, setResultsFiles] = useState([]);
  const [importingResults, setImportingResults] = useState(false);
  const [targetExamForResults, setTargetExamForResults] = useState(null);

  const handleProcessImportResults = async () => {
    if (!resultsFiles || resultsFiles.length === 0) return;
    setImportingResults(true);
    try {
      const vaultKey = getSystemVaultKey();
      const formData = new FormData();
      for (const f of resultsFiles) {
        formData.append('results', f);
      }
      if (vaultKey) formData.append('passphrase', vaultKey);

      const targetId = targetExamForResults?.id || null;
      const res = await importExamResults(targetId, formData);
      setIsImportResultsModalOpen(false);
      setResultsFiles([]);
      setTargetExamForResults(null);
      await load();

      Swal.fire({
        icon: 'success',
        title: 'Résultats Importés & Fusionnés !',
        text: res.message || `${resultsFiles.length} fichier(s) .algoresults fusionné(s) avec succès.`,
        background: '#111827',
        color: '#fff'
      });
      setActiveTab('EXAM_SESSIONS');
    } catch (err) {
      console.error('Import results error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Importation Résultats',
        text: err.data?.error || err.message || 'Impossible d\'importer les résultats.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setImportingResults(false);
    }
  };

  const handleSelectTab = (tab) => {
    setActiveTab(tab);
    localStorage.setItem('algo_teacher_active_tab', tab);
  };

  const launchedExams = exams.filter(e => ['RUNNING', 'WAITING', 'PAUSED', 'FINISHED', 'CLOSED'].includes(e.status));
  const subjectTemplates = exams.filter(e => ['DRAFT', 'SCHEDULED'].includes(e.status));

  const displayedExams = activeTab === 'EXAM_SESSIONS'
    ? launchedExams
    : activeTab === 'EXAM_SUBJECTS'
      ? subjectTemplates
      : exams;

  const stats = {
    total:    exams.length,
    running:  exams.filter(e => e.status === 'RUNNING').length,
    waiting:  exams.filter(e => e.status === 'WAITING').length,
    finished: exams.filter(e => e.status === 'FINISHED').length,
  };

  return (
    <div style={{ padding: '28px', maxWidth: '1380px', margin: '0 auto' }}>

      {/* ═══════════════════════════════════════════════════════════
          VARIANTE 3 : LINE 1 (TOP IDENTITY & GLOBAL SYSTEM TOOLS)
      ═══════════════════════════════════════════════════════════ */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '22px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ fontSize: '1.6rem' }}>👨‍🏫</span>
            <h1 style={{ fontSize: '1.65rem', fontWeight: '800', margin: 0, color: '#f8fafc', letterSpacing: '-0.5px' }}>
              Espace Enseignant & Pédagogie
            </h1>
            <span className="badge badge-blue" style={{ fontSize: '0.72rem', padding: '3px 8px' }}>ENSEIGNANT</span>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.86rem', margin: '4px 0 0 0' }}>
            Gestion des sujets d'examen (.algoexam), pilotage des épreuves en direct et correction des copies.
          </p>
        </div>

        {/* Global system actions */}
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' }}>
          <button className="btn btn-secondary" onClick={load} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <RefreshCw size={14} /> Actualiser
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('PROBLEM_BANK')} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <BookOpen size={14} /> Banque Problèmes
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('STUDENT_MGMT')} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <Users size={14} /> Roster Étudiants
          </button>
          <button className="btn btn-secondary" onClick={() => setIsSettingsOpen(true)} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <Settings size={14} /> Paramètres
          </button>
          {onLogout && (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onLogout}
              style={{ color: '#f87171', borderColor: 'rgba(239, 68, 68, 0.3)', display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 12px', fontSize: '0.84rem' }}
            >
              <LogOut size={14} /> Déconnexion
            </button>
          )}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════
          VARIANTE 3 : LINE 2 (LINEAR / GITHUB TABBED COMMAND BAR)
      ═══════════════════════════════════════════════════════════ */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
        marginBottom: '24px',
        paddingBottom: '0px',
        flexWrap: 'wrap',
        gap: '14px'
      }}>
        {/* Left: Underlined Clean Tabs */}
        <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
          <button
            onClick={() => handleSelectTab('EXAM_SUBJECTS')}
            style={{
              background: 'transparent',
              border: 'none',
              borderBottom: activeTab === 'EXAM_SUBJECTS' ? '2px solid #3b82f6' : '2px solid transparent',
              color: activeTab === 'EXAM_SUBJECTS' ? '#93c5fd' : 'var(--text-muted)',
              padding: '12px 18px',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '0.92rem',
              transition: 'all 0.15s ease'
            }}
          >
            <FileCode size={16} /> 📑 Sujets d'Examen (.algoexam)
            <span style={{
              fontSize: '0.75rem',
              padding: '2px 7px',
              borderRadius: '12px',
              background: activeTab === 'EXAM_SUBJECTS' ? 'rgba(59, 130, 246, 0.2)' : 'rgba(255,255,255,0.06)',
              color: activeTab === 'EXAM_SUBJECTS' ? '#93c5fd' : 'var(--text-muted)'
            }}>
              {subjectTemplates.length}
            </span>
          </button>

          <button
            onClick={() => handleSelectTab('EXAM_SESSIONS')}
            style={{
              background: 'transparent',
              border: 'none',
              borderBottom: activeTab === 'EXAM_SESSIONS' ? '2px solid #10b981' : '2px solid transparent',
              color: activeTab === 'EXAM_SESSIONS' ? '#34d399' : 'var(--text-muted)',
              padding: '12px 18px',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '0.92rem',
              transition: 'all 0.15s ease'
            }}
          >
            <FileSpreadsheet size={16} /> 🎓 Examens & Séances
            <span style={{
              fontSize: '0.75rem',
              padding: '2px 7px',
              borderRadius: '12px',
              background: activeTab === 'EXAM_SESSIONS' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.06)',
              color: activeTab === 'EXAM_SESSIONS' ? '#34d399' : 'var(--text-muted)'
            }}>
              {launchedExams.length}
            </span>
          </button>

          <button
            onClick={() => handleSelectTab('ALL')}
            style={{
              background: 'transparent',
              border: 'none',
              borderBottom: activeTab === 'ALL' ? '2px solid #94a3b8' : '2px solid transparent',
              color: activeTab === 'ALL' ? '#f8fafc' : 'var(--text-muted)',
              padding: '12px 16px',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '0.92rem',
              transition: 'all 0.15s ease'
            }}
          >
            <BookOpen size={16} /> Tous
            <span style={{
              fontSize: '0.75rem',
              padding: '2px 7px',
              borderRadius: '12px',
              background: 'rgba(255,255,255,0.06)',
              color: 'var(--text-muted)'
            }}>
              {exams.length}
            </span>
          </button>
        </div>

        {/* Right: Context-Specific Action Buttons */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', paddingBottom: '8px', marginLeft: 'auto', flexWrap: 'wrap' }}>
          {/* 1. Import Sujet .algoexam */}
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => setIsImportTemplateModalOpen(true)}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              padding: '8px 11px', fontSize: '0.85rem',
              borderColor: 'rgba(59, 130, 246, 0.4)', color: '#60a5fa',
              background: 'rgba(59, 130, 246, 0.08)'
            }}
            title="Importer un Sujet d'Examen (.algoexam)"
          >
            <Upload size={16} />
          </button>

          {/* 2. Import Copies .algobundle */}
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              setTargetExamForBundle(null);
              setBundleFiles([]);
              setIsImportBundleModalOpen(true);
            }}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              padding: '8px 11px', fontSize: '0.85rem',
              borderColor: 'rgba(168, 85, 247, 0.4)', color: '#c084fc',
              background: 'rgba(168, 85, 247, 0.08)'
            }}
            title="Importer les Copies d'Étudiants (.algobundle)"
          >
            <Package size={16} />
          </button>

          {/* 3. Import Résultats .algoresults */}
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              setTargetExamForResults(null);
              setResultsFiles([]);
              setIsImportResultsModalOpen(true);
            }}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              padding: '8px 11px', fontSize: '0.85rem',
              borderColor: 'rgba(245, 158, 11, 0.4)', color: '#fbbf24',
              background: 'rgba(245, 158, 11, 0.08)'
            }}
            title="Importer les Résultats & Notes Corrigées (.algoresults)"
          >
            <FileSpreadsheet size={16} />
          </button>

          {activeTab === 'EXAM_SUBJECTS' || activeTab === 'ALL' ? (
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => onNavigate('CREATE_EXAM')}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 14px', fontSize: '0.82rem', background: 'linear-gradient(135deg, #3b82f6, #6366f1)', border: 'none', fontWeight: '700' }}
            >
              <Plus size={14} /> ➕ Nouveau Sujet
            </button>
          ) : (
            <button
              type="button"
              className="btn btn-success"
              onClick={() => handleSelectTab('EXAM_SUBJECTS')}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 14px', fontSize: '0.82rem', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', fontWeight: '700' }}
            >
              <Play size={14} fill="#fff" /> 🚀 Lancer une Séance
            </button>
          )}
        </div>
      </div>

      {/* ── Stats Summary Row ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
        {[
          { label: 'Total Épreuves & Sujets', value: stats.total, color: '#60a5fa', icon: '📋' },
          { label: 'En Cours (LIVE)', value: stats.running, color: '#10b981', icon: '🟢' },
          { label: 'En Attente / Prêt', value: stats.waiting, color: '#f59e0b', icon: '⏳' },
          { label: 'Terminés & À Corriger', value: stats.finished, color: '#a78bfa', icon: '✅' },
        ].map(({ label, value, color, icon }) => (
          <div key={label} className="glass-panel" style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ fontSize: '1.8rem' }}>{icon}</div>
            <div>
              <div style={{ fontSize: '1.6rem', fontWeight: '800', color, lineHeight: 1.1 }}>{value}</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* ── Exam Cards & Empty States ── */}
      {loading ? (
        <div className="glass-panel" style={{ padding: '60px', textAlign: 'center', color: 'var(--text-muted)' }}>
          Chargement des examens...
        </div>
      ) : displayedExams.length === 0 ? (
        <div className="glass-panel" style={{ padding: '60px', textAlign: 'center', border: '1px dashed rgba(255,255,255,0.15)' }}>
          <div style={{ fontSize: '3.2rem', marginBottom: '16px' }}>
            {activeTab === 'EXAM_SUBJECTS' ? '📑' : '🎓'}
          </div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: '700', marginBottom: '6px' }}>
            {activeTab === 'EXAM_SUBJECTS'
              ? 'Aucun sujet d\'examen disponible'
              : 'Aucune séance d\'examen enregistrée'}
          </h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', maxWidth: '560px', margin: '0 auto 24px auto' }}>
            {activeTab === 'EXAM_SUBJECTS'
              ? (launchedExams.length > 0
                  ? `Vous avez ${launchedExams.length} séance(s) d'examen dans l'onglet « 🎓 Examens & Séances ». Vous pouvez créer un nouveau sujet, importer un fichier .algoexam, ou cloner une séance existante.`
                  : 'Créez un nouveau sujet avec ses exercices, barèmes et tests, ou importez un modèle .algoexam existant.')
              : 'Lancez une séance pour une salle à partir de vos sujets disponibles, ou importez un paquet de copies .algobundle rendu pour correction.'}
          </p>

          <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', flexWrap: 'wrap' }}>
            {activeTab === 'EXAM_SUBJECTS' ? (
              <>
                <button className="btn btn-primary" onClick={() => onNavigate('CREATE_EXAM')} style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Plus size={16} /> ➕ Nouveau Sujet d'Examen
                </button>
                <button className="btn btn-secondary" onClick={() => setIsImportTemplateModalOpen(true)} style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: '8px', borderColor: '#3b82f6', color: '#93c5fd' }}>
                  <Upload size={16} /> 📥 Importer un Sujet (.algoexam)
                </button>
                {launchedExams.length > 0 && (
                  <button className="btn btn-success" onClick={() => setActiveTab('EXAM_SESSIONS')} style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <FileSpreadsheet size={16} /> 🎓 Voir les ${launchedExams.length} Séances Existantes
                  </button>
                )}
              </>
            ) : (
              <>
                <button className="btn btn-primary" onClick={() => onNavigate('CREATE_EXAM')} style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Plus size={16} /> ➕ Nouveau Sujet
                </button>
                <button className="btn btn-secondary" onClick={() => setIsImportTemplateModalOpen(true)} style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: '8px', borderColor: '#3b82f6', color: '#93c5fd' }}>
                  <Upload size={16} /> 📥 Importer un Sujet (.algoexam)
                </button>
                <button className="btn btn-success" onClick={() => setActiveTab('EXAM_SUBJECTS')} style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Play size={16} fill="#fff" /> 🚀 Lancer une Séance
                </button>
                {launchedExams.length > 0 && (
                  <button
                    className="btn btn-secondary"
                    onClick={() => {
                      setTargetExamForBundle(launchedExams[0]);
                      setBundleFiles([]);
                      setIsImportBundleModalOpen(true);
                    }}
                    style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: '8px', borderColor: '#a78bfa', color: '#c084fc' }}
                  >
                    <Package size={16} /> 📥 Importer Paquet de Copies (.algobundle)
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {displayedExams.map(exam => {
            const si = EXAM_STATUS[exam.status] || EXAM_STATUS.DRAFT;
            const isModelNotLaunched = ['DRAFT', 'SCHEDULED'].includes(exam.status);
            const isRunningOrLive = ['RUNNING', 'WAITING', 'PAUSED'].includes(exam.status);
            const isFinished = ['FINISHED', 'CLOSED'].includes(exam.status);
            const isAutoGradingThisExam = autoGradingExamId === exam.id;

            const hasAssignments = (exam.assignments && exam.assignments.length > 0) || (exam._count?.assignments > 0);
            const isFullyGraded = exam.status === 'CLOSED';

            return (
              <div key={exam.id} className="glass-panel" style={{ padding: '22px 26px', display: 'flex', flexDirection: 'column', gap: '14px', borderLeft: `4px solid ${si.color}`, overflow: 'visible', position: 'relative', zIndex: openMenuExamId === exam.id ? 90 : 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '20px', justifyContent: 'space-between' }}>
                  {/* Left: info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px', flexWrap: 'wrap' }}>
                      <span className={`badge ${si.cls}`}>{si.label}</span>
                      {isFinished && (
                        isFullyGraded ? (
                          <span className="badge badge-green" style={{ fontSize: '0.75rem', fontWeight: '700', padding: '2px 8px' }}>
                            ✓ Corrigé
                          </span>
                        ) : (
                          <span className="badge badge-yellow" style={{ fontSize: '0.75rem', fontWeight: '700', padding: '2px 8px' }}>
                            ⏳ À Corriger
                          </span>
                        )
                      )}
                      {exam.examCode && (
                        <code style={{ fontSize: '0.8rem', color: '#a78bfa', background: 'rgba(167,139,250,0.1)', padding: '2px 8px', borderRadius: '4px', border: '1px solid rgba(167,139,250,0.3)' }}>
                          {exam.examCode}
                        </code>
                      )}
                      <span style={{ fontSize: '1.25rem', fontWeight: '800' }}>{exam.title}</span>
                    </div>

                    <div style={{ display: 'flex', gap: '20px', color: 'var(--text-muted)', fontSize: '0.83rem', flexWrap: 'wrap', alignItems: 'center' }}>
                      <span>📚 {exam.module || 'ASD'}</span>
                      <span>⏱ {exam.durationMinutes} min</span>
                      <span>👥 {exam._count?.assignments || 0} étudiant(s) inscrits</span>
                      <span>🧩 {exam._count?.problems || 0} exercice(s)</span>
                      {exam.distinctRooms && exam.distinctRooms.length > 1 ? (
                        <span style={{ background: 'rgba(52,211,153,0.1)', border: '1px solid rgba(52,211,153,0.3)', padding: '2px 8px', borderRadius: '4px' }}>
                          🏢 Salles ({exam.distinctRooms.length} fusionnées) : <strong style={{ color: '#34d399' }}>{exam.distinctRooms.join(', ')}</strong>
                        </span>
                      ) : (
                        (exam.room || (exam.distinctRooms && exam.distinctRooms[0])) && (
                          <span>🏢 Salle : <strong style={{ color: '#34d399' }}>{exam.distinctRooms?.[0] || exam.room}</strong></span>
                        )
                      )}
                    </div>
                  </div>

                  {/* Right: Actions depending on Exam State (Max 3 buttons + ⋮ menu) */}
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap', flexShrink: 0, position: 'relative', zIndex: openMenuExamId === exam.id ? 95 : 1 }}>
                    
                    {/* ── STATE 1: MODEL NOT YET LAUNCHED (DRAFT / SCHEDULED) ── */}
                    {isModelNotLaunched && (
                      <>
                        {/* 1. Lancer */}
                        <button
                          className="btn btn-success"
                          style={{ padding: '8px 14px', fontSize: '0.85rem', fontWeight: '800', display: 'inline-flex', alignItems: 'center', gap: '6px', background: 'linear-gradient(135deg, #10b981, #059669)', boxShadow: '0 4px 12px rgba(16,185,129,0.3)' }}
                          onClick={() => onLaunchExam(exam)}
                          title="Lancer cette épreuve pour une salle spécifique avec les étudiants"
                        >
                          <Play size={14} fill="#fff" /> Lancer
                        </button>

                        {/* 2. Modifier */}
                        <button
                          className="btn btn-secondary"
                          style={{ padding: '8px 12px', fontSize: '0.85rem', color: '#93c5fd', background: 'rgba(59,130,246,0.12)', border: '1px solid rgba(59,130,246,0.4)', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
                          onClick={() => onEditExam(exam)}
                          title="Modifier ce modèle de sujet (exercices, barèmes, configuration)"
                        >
                          <Edit3 size={14} /> Modifier
                        </button>

                        {/* 3. Exporter .algoexam */}
                        <button
                          className="btn btn-secondary"
                          style={{ padding: '8px 12px', fontSize: '0.85rem', color: '#38bdf8', background: 'rgba(30,41,59,0.8)', border: '1px solid #0284c7', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
                          onClick={() => handleExportTemplate(exam.id, exam.title)}
                          title="Exporter le modèle de sujet d'examen (.algoexam)"
                        >
                          <FileCode size={14} /> Modèle
                        </button>

                        {/* Overflow Menu ⋮ */}
                        <div className="exam-actions-menu-container" style={{ position: 'relative', zIndex: openMenuExamId === exam.id ? 99 : 1 }}>
                          <button
                            type="button"
                            className="btn btn-secondary"
                            style={{
                              padding: '8px 10px',
                              fontSize: '0.85rem',
                              color: openMenuExamId === exam.id ? '#38bdf8' : '#94a3b8',
                              background: openMenuExamId === exam.id ? 'rgba(51, 65, 85, 0.9)' : 'rgba(30, 41, 59, 0.8)',
                              border: '1px solid #334155',
                              display: 'inline-flex',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              setOpenMenuExamId(openMenuExamId === exam.id ? null : exam.id);
                            }}
                            title="Plus d'actions"
                          >
                            <MoreVertical size={16} />
                          </button>

                          {openMenuExamId === exam.id && (
                            <div
                              style={{
                                position: 'absolute',
                                right: 0,
                                top: 'calc(100% + 6px)',
                                background: '#0f172a',
                                border: '1px solid #334155',
                                borderRadius: '8px',
                                boxShadow: '0 16px 36px rgba(0, 0, 0, 0.85), 0 0 0 1px rgba(255, 255, 255, 0.05)',
                                zIndex: 9999,
                                minWidth: '230px',
                                padding: '6px',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '3px'
                              }}
                            >
                              <button
                                type="button"
                                style={{
                                  display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                  padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                  color: '#38bdf8', fontSize: '0.83rem', fontWeight: '600', textAlign: 'left', cursor: 'pointer'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(56, 189, 248, 0.12)'}
                                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                onMouseDown={(e) => e.stopPropagation()}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenMenuExamId(null);
                                  handleDuplicateAsTemplate(exam);
                                }}
                              >
                                <FileCode size={14} /> Dupliquer le modèle
                              </button>
                              <div style={{ height: '1px', background: '#334155', margin: '3px 0' }} />
                              <button
                                type="button"
                                style={{
                                  display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                  padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                  color: '#ef4444', fontSize: '0.83rem', fontWeight: '600', textAlign: 'left', cursor: 'pointer'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.15)'}
                                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                onMouseDown={(e) => e.stopPropagation()}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenMenuExamId(null);
                                  handleDeleteExam(exam);
                                }}
                              >
                                <Trash2 size={14} /> Supprimer le sujet
                              </button>
                            </div>
                          )}
                        </div>
                      </>
                    )}

                    {/* ── STATE 2: EXAM IS RUNNING / LIVE (RUNNING / WAITING / PAUSED) ── */}
                    {isRunningOrLive && (
                      <>
                        {/* 1. Surveiller */}
                        <button
                          className="btn btn-primary"
                          style={{ padding: '8px 14px', fontSize: '0.85rem', fontWeight: '800', display: 'inline-flex', alignItems: 'center', gap: '6px', background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)', boxShadow: '0 4px 14px rgba(59,130,246,0.4)' }}
                          onClick={() => onEnterExam(exam)}
                          title="Ouvrir la vue de surveillance en direct"
                        >
                          <Eye size={14} /> Surveiller
                        </button>

                        {/* 2. Pause / Reprendre */}
                        {exam.status === 'RUNNING' ? (
                          <button
                            className="btn btn-secondary"
                            style={{ padding: '8px 12px', fontSize: '0.85rem', color: '#f59e0b', background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.3)', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
                            onClick={() => handleStatusChange(exam, 'PAUSED')}
                            title="Suspendre l'épreuve temporairement"
                          >
                            <Pause size={14} /> Pause
                          </button>
                        ) : (
                          <button
                            className="btn btn-secondary"
                            style={{ padding: '8px 12px', fontSize: '0.85rem', color: '#10b981', background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.3)', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
                            onClick={() => handleStatusChange(exam, 'RUNNING')}
                            title="Reprendre le déroulement de l'épreuve"
                          >
                            <Play size={14} /> Reprendre
                          </button>
                        )}

                        {/* 3. Terminer */}
                        <button
                          className="btn btn-danger"
                          style={{ padding: '8px 12px', fontSize: '0.85rem', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
                          onClick={() => handleStatusChange(exam, 'FINISHED')}
                          title="Terminer l'épreuve pour tous les étudiants"
                        >
                          <Square size={14} /> Terminer
                        </button>

                        {/* Overflow Menu ⋮ */}
                        <div className="exam-actions-menu-container" style={{ position: 'relative', zIndex: openMenuExamId === exam.id ? 99 : 1 }}>
                          <button
                            type="button"
                            className="btn btn-secondary"
                            style={{
                              padding: '8px 10px',
                              fontSize: '0.85rem',
                              color: openMenuExamId === exam.id ? '#38bdf8' : '#94a3b8',
                              background: openMenuExamId === exam.id ? 'rgba(51, 65, 85, 0.9)' : 'rgba(30, 41, 59, 0.8)',
                              border: '1px solid #334155',
                              display: 'inline-flex',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              setOpenMenuExamId(openMenuExamId === exam.id ? null : exam.id);
                            }}
                            title="Plus d'actions"
                          >
                            <MoreVertical size={16} />
                          </button>

                          {openMenuExamId === exam.id && (
                            <div
                              style={{
                                position: 'absolute',
                                right: 0,
                                top: 'calc(100% + 6px)',
                                background: '#0f172a',
                                border: '1px solid #334155',
                                borderRadius: '8px',
                                boxShadow: '0 16px 36px rgba(0, 0, 0, 0.85), 0 0 0 1px rgba(255, 255, 255, 0.05)',
                                zIndex: 9999,
                                minWidth: '230px',
                                padding: '6px',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '3px'
                              }}
                            >
                              <button
                                type="button"
                                style={{
                                  display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                  padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                  color: '#93c5fd', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(59, 130, 246, 0.12)'}
                                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                onMouseDown={(e) => e.stopPropagation()}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenMenuExamId(null);
                                  handleExportBundle(exam.id, exam.title);
                                }}
                              >
                                <Package size={14} /> Paquet de secours (.algobundle)
                              </button>
                              <div style={{ height: '1px', background: '#334155', margin: '3px 0' }} />
                              <button
                                type="button"
                                style={{
                                  display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                  padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                  color: '#ef4444', fontSize: '0.83rem', fontWeight: '600', textAlign: 'left', cursor: 'pointer'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.15)'}
                                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                onMouseDown={(e) => e.stopPropagation()}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenMenuExamId(null);
                                  handleDeleteExam(exam);
                                }}
                              >
                                <Trash2 size={14} /> Supprimer l'épreuve
                              </button>
                            </div>
                          )}
                        </div>
                      </>
                    )}

                    {/* ── STATE 3: EXAM FINISHED / CLOSED (FINISHED / CLOSED) ── */}
                    {isFinished && (
                      <>
                        {!isFullyGraded ? (
                          /* ── 3A: FINISHED (À CORRIGER) ── */
                          <>
                            {/* 1. Corriger */}
                            <button
                              className="btn btn-secondary"
                              disabled={isAutoGradingThisExam}
                              style={{
                                padding: '8px 14px', fontSize: '0.85rem', fontWeight: '700',
                                background: 'rgba(168,85,247,0.18)', color: '#c084fc',
                                border: '1px solid rgba(168,85,247,0.45)', display: 'inline-flex', alignItems: 'center', gap: '6px'
                              }}
                              onClick={() => onViewCorrection(exam)}
                              title="Ouvrir l'espace de correction des copies"
                            >
                              <Edit3 size={14} /> Corriger
                            </button>

                            {/* 2. Auto-Correction */}
                            <button
                              className="btn btn-secondary"
                              disabled={isAutoGradingThisExam || !!autoGradingExamId}
                              style={{
                                padding: '8px 12px', fontSize: '0.85rem', fontWeight: '700',
                                color: '#38bdf8', background: 'rgba(56,189,248,0.12)',
                                border: '1px solid rgba(56,189,248,0.35)', display: 'inline-flex', alignItems: 'center', gap: '6px'
                              }}
                              onClick={() => handleAutoGradeExam(exam)}
                              title="Lancer la correction automatique intelligente (Tests unitaires + Similarité AST)"
                            >
                              <Zap size={14} /> Auto-Correction
                            </button>

                            {/* 3. Fusionner Paquets */}
                            <button
                              className="btn btn-secondary"
                              style={{
                                padding: '8px 12px', fontSize: '0.85rem', fontWeight: '600',
                                color: '#a78bfa', background: 'rgba(30,41,59,0.8)',
                                border: '1px solid #334155', display: 'inline-flex', alignItems: 'center', gap: '6px'
                              }}
                              onClick={() => handleImportBundles(exam.id, exam.title)}
                              title="Importer et fusionner les paquets de copies (.algobundle) d'autres salles"
                            >
                              <Upload size={14} /> Fusionner Paquets
                            </button>

                            {/* Overflow Menu ⋮ */}
                            <div className="exam-actions-menu-container" style={{ position: 'relative', zIndex: openMenuExamId === exam.id ? 99 : 1 }}>
                              <button
                                type="button"
                                className="btn btn-secondary"
                                style={{
                                  padding: '8px 10px',
                                  fontSize: '0.85rem',
                                  color: openMenuExamId === exam.id ? '#c084fc' : '#94a3b8',
                                  background: openMenuExamId === exam.id ? 'rgba(51, 65, 85, 0.9)' : 'rgba(30, 41, 59, 0.8)',
                                  border: '1px solid #334155',
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  justifyContent: 'center'
                                }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenMenuExamId(openMenuExamId === exam.id ? null : exam.id);
                                }}
                                title="Plus d'actions"
                              >
                                <MoreVertical size={16} />
                              </button>

                              {openMenuExamId === exam.id && (
                                <div
                                  style={{
                                    position: 'absolute',
                                    right: 0,
                                    top: 'calc(100% + 6px)',
                                    background: '#0f172a',
                                    border: '1px solid #334155',
                                    borderRadius: '8px',
                                    boxShadow: '0 16px 36px rgba(0, 0, 0, 0.85), 0 0 0 1px rgba(255, 255, 255, 0.05)',
                                    zIndex: 9999,
                                    minWidth: '260px',
                                    padding: '6px',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '3px'
                                  }}
                                >
                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#93c5fd', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(59, 130, 246, 0.12)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleExportBundle(exam.id, exam.title);
                                    }}
                                  >
                                    <Package size={14} color="#93c5fd" /> Télécharger paquet (.algobundle)
                                  </button>

                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#fbbf24', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(245, 158, 11, 0.12)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleResetExamScores(exam);
                                    }}
                                  >
                                    <RotateCcw size={14} color="#fbbf24" /> Effacer toutes les notes
                                  </button>

                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#38bdf8', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(56, 189, 248, 0.12)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleDuplicateAsTemplate(exam);
                                    }}
                                  >
                                    <FileCode size={14} color="#38bdf8" /> Dupliquer comme modèle (.algoexam)
                                  </button>

                                  <div style={{ height: '1px', background: '#334155', margin: '3px 0' }} />

                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#ef4444', fontSize: '0.83rem', fontWeight: '600', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.15)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleDeleteExam(exam);
                                    }}
                                  >
                                    <Trash2 size={14} color="#ef4444" /> Supprimer l'épreuve
                                  </button>
                                </div>
                              )}
                            </div>
                          </>
                        ) : (
                          /* ── 3B: CLOSED (CORRIGÉ & CLÔTURÉ) ── */
                          <>
                            {/* 1. Résultats & PV */}
                            <button
                              className="btn btn-success"
                              style={{
                                padding: '8px 14px', fontSize: '0.85rem', fontWeight: '800',
                                display: 'inline-flex', alignItems: 'center', gap: '6px',
                                background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none',
                                boxShadow: '0 4px 12px rgba(16,185,129,0.3)'
                              }}
                              onClick={() => onViewResults(exam)}
                              title="Consulter les résultats dé-anonymisés, générer les PV de notes et copies PDF"
                            >
                              <BarChart2 size={14} /> Résultats & PV
                            </button>

                            {/* 2. Revoir Copies */}
                            <button
                              className="btn btn-secondary"
                              style={{
                                padding: '8px 12px', fontSize: '0.85rem', fontWeight: '600',
                                background: 'rgba(168,85,247,0.12)', color: '#c084fc',
                                border: '1px solid rgba(168,85,247,0.3)', display: 'inline-flex', alignItems: 'center', gap: '6px'
                              }}
                              onClick={() => onViewCorrection(exam)}
                              title="Revoir l'espace de correction des copies"
                            >
                              <Edit3 size={14} /> Revoir Copies
                            </button>

                            {/* 3. Exporter Notes (.algoresults) */}
                            <button
                              className="btn btn-secondary"
                              style={{
                                padding: '8px 12px', fontSize: '0.85rem', fontWeight: '600',
                                color: '#f59e0b', background: 'rgba(245,158,11,0.1)',
                                border: '1px solid rgba(245,158,11,0.3)', display: 'inline-flex', alignItems: 'center', gap: '6px'
                              }}
                              onClick={() => handleExportResults(exam.id, exam.title)}
                              title="Télécharger les résultats corrigés chiffrés (.algoresults)"
                            >
                              <Download size={14} /> Exporter Notes
                            </button>

                            {/* Overflow Menu ⋮ */}
                            <div className="exam-actions-menu-container" style={{ position: 'relative', zIndex: openMenuExamId === exam.id ? 99 : 1 }}>
                              <button
                                type="button"
                                className="btn btn-secondary"
                                style={{
                                  padding: '8px 10px',
                                  fontSize: '0.85rem',
                                  color: openMenuExamId === exam.id ? '#10b981' : '#94a3b8',
                                  background: openMenuExamId === exam.id ? 'rgba(51, 65, 85, 0.9)' : 'rgba(30, 41, 59, 0.8)',
                                  border: '1px solid #334155',
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  justifyContent: 'center'
                                }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenMenuExamId(openMenuExamId === exam.id ? null : exam.id);
                                }}
                                title="Plus d'actions"
                              >
                                <MoreVertical size={16} />
                              </button>

                              {openMenuExamId === exam.id && (
                                <div
                                  style={{
                                    position: 'absolute',
                                    right: 0,
                                    top: 'calc(100% + 6px)',
                                    background: '#0f172a',
                                    border: '1px solid #334155',
                                    borderRadius: '8px',
                                    boxShadow: '0 16px 36px rgba(0, 0, 0, 0.85), 0 0 0 1px rgba(255, 255, 255, 0.05)',
                                    zIndex: 9999,
                                    minWidth: '270px',
                                    padding: '6px',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '3px'
                                  }}
                                >
                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#fbbf24', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(251, 191, 36, 0.12)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      setTargetExamForResults(exam);
                                      setResultsFiles([]);
                                      setIsImportResultsModalOpen(true);
                                    }}
                                  >
                                    <FileSpreadsheet size={14} color="#fbbf24" /> Fusionner notes (.algoresults)
                                  </button>

                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#93c5fd', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(59, 130, 246, 0.12)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleExportBundle(exam.id, exam.title);
                                    }}
                                  >
                                    <Package size={14} color="#93c5fd" /> Télécharger paquet brut (.algobundle)
                                  </button>

                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#38bdf8', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(56, 189, 248, 0.12)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleDuplicateAsTemplate(exam);
                                    }}
                                  >
                                    <FileCode size={14} color="#38bdf8" /> Dupliquer comme modèle (.algoexam)
                                  </button>

                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#f87171', fontSize: '0.83rem', fontWeight: '500', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.12)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleResetExamScores(exam);
                                    }}
                                  >
                                    <RotateCcw size={14} color="#f87171" /> Effacer les notes & rouvrir
                                  </button>

                                  <div style={{ height: '1px', background: '#334155', margin: '3px 0' }} />

                                  <button
                                    type="button"
                                    style={{
                                      display: 'flex', alignItems: 'center', gap: '10px', width: '100%',
                                      padding: '8px 12px', background: 'transparent', border: 'none', borderRadius: '6px',
                                      color: '#ef4444', fontSize: '0.83rem', fontWeight: '600', textAlign: 'left', cursor: 'pointer'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.15)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setOpenMenuExamId(null);
                                      handleDeleteExam(exam);
                                    }}
                                  >
                                    <Trash2 size={14} color="#ef4444" /> Supprimer l'épreuve
                                  </button>
                                </div>
                              )}
                            </div>
                          </>
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* ── INLINE AUTO-GRADE PROGRESS SECTION INSIDE EXAM CARD ── */}
                {isAutoGradingThisExam && autoGradeProgress && (
                  <div style={{
                    marginTop: '6px',
                    padding: '14px 18px',
                    borderRadius: '10px',
                    background: 'rgba(59, 130, 246, 0.1)',
                    border: '1px solid rgba(59, 130, 246, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.88rem' }}>
                      <span style={{ fontWeight: '700', color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <Zap size={16} style={{ animation: 'pulse 1s infinite' }} /> Correction Automatique en cours...
                      </span>
                      <span style={{ fontWeight: '800', color: '#34d399' }}>
                        Copie {autoGradeProgress.done} / {autoGradeProgress.total} ({autoGradeProgress.pct || 0}%)
                      </span>
                    </div>

                    {autoGradeProgress.studentName && (
                      <div style={{ fontSize: '0.82rem', color: '#cbd5e1', fontWeight: '600' }}>
                        👤 Traitement de : <span style={{ color: '#fff' }}>{autoGradeProgress.studentName}</span>
                      </div>
                    )}

                    <div style={{ width: '100%', height: '8px', background: 'rgba(255, 255, 255, 0.1)', borderRadius: '4px', overflow: 'hidden' }}>
                      <div style={{
                        height: '100%',
                        width: `${autoGradeProgress.pct || 0}%`,
                        background: 'linear-gradient(90deg, #3b82f6, #8b5cf6, #34d399)',
                        borderRadius: '4px',
                        transition: 'width 0.3s ease-out'
                      }} />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── Modal 1: Import Sujet .algoexam (Type 1) ── */}
      {isImportTemplateModalOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '560px', maxWidth: '90%', padding: '26px', background: '#0f172a', border: '1px solid #1e293b' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <FileCode size={20} color="#60a5fa" />
                <h3 style={{ margin: 0, fontSize: '1.2rem', fontWeight: '800' }}>Importer un Sujet d'Examen (.algoexam)</h3>
              </div>
              <button className="btn btn-secondary" onClick={() => { setIsImportTemplateModalOpen(false); setTemplateFile(null); }} style={{ padding: '4px 8px' }}>
                <X size={16} />
              </button>
            </div>

            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '16px', lineHeight: 1.5 }}>
              Importez un modèle de sujet d'examen contenant les énoncés, barèmes et jeux de tests (sans données d'étudiants).
            </p>

            <FileDropZone
              accept=".algoexam,.json"
              title="Déposez votre fichier .algoexam ici"
              subtitle="ou cliquez pour parcourir les dossiers"
              onFileSelect={(f) => setTemplateFile(f)}
              selectedFile={templateFile}
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => { setIsImportTemplateModalOpen(false); setTemplateFile(null); }}
                style={{ padding: '8px 16px' }}
              >
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleProcessImportTemplate}
                disabled={!templateFile || importingTemplate}
                style={{ padding: '8px 20px', background: 'linear-gradient(135deg, #3b82f6, #6366f1)', border: 'none', fontWeight: '700' }}
              >
                {importingTemplate ? 'Importation en cours...' : '📥 Importer le Sujet'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Modal 2: Import Paquet de Copies .algobundle (Type 3) ── */}
      {isImportBundleModalOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '600px', maxWidth: '90%', padding: '26px', background: '#0f172a', border: '1px solid #1e293b' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Package size={20} color="#a78bfa" />
                <h3 style={{ margin: 0, fontSize: '1.2rem', fontWeight: '800' }}>Importer un Paquet de Copies (.algobundle)</h3>
              </div>
              <button className="btn btn-secondary" onClick={() => { setIsImportBundleModalOpen(false); setBundleFiles([]); setTargetExamForBundle(null); }} style={{ padding: '4px 8px' }}>
                <X size={16} />
              </button>
            </div>

            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '14px', lineHeight: 1.5 }}>
              Sélectionnez les paquets de copies chiffrés récupérés auprès des surveillants {targetExamForBundle ? <>pour l'épreuve <strong style={{ color: '#93c5fd' }}>{targetExamForBundle.title}</strong></> : <span style={{ color: '#93c5fd' }}>(l'épreuve correspondante sera détectée ou créée automatiquement)</span>}.
            </p>

            <FileDropZone
              accept=".algobundle,.json"
              title="Déposez les fichiers .algobundle ici"
              subtitle="ou cliquez pour parcourir les paquets de salle"
              onFileSelect={(files) => {
                if (Array.isArray(files)) setBundleFiles(files);
                else if (files) setBundleFiles([files]);
              }}
              selectedFile={bundleFiles.length > 0 ? { name: `${bundleFiles.length} fichier(s) .algobundle sélectionné(s)` } : null}
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => { setIsImportBundleModalOpen(false); setBundleFiles([]); setTargetExamForBundle(null); }}
                style={{ padding: '8px 16px' }}
              >
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleProcessImportBundles}
                disabled={bundleFiles.length === 0 || importingBundles}
                style={{ padding: '8px 20px', background: 'linear-gradient(135deg, #a855f7, #6366f1)', border: 'none', fontWeight: '700' }}
              >
                {importingBundles ? 'Déchiffrement & Fusion...' : '📥 Déchiffrer & Fusionner les Copies'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Modal 3: Import Résultats .algoresults (Type 2) ── */}
      {isImportResultsModalOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '600px', maxWidth: '90%', padding: '26px', background: '#0f172a', border: '1px solid #1e293b' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <FileSpreadsheet size={20} color="#fbbf24" />
                <h3 style={{ margin: 0, fontSize: '1.2rem', fontWeight: '800' }}>Importer des Résultats (.algoresults)</h3>
              </div>
              <button className="btn btn-secondary" onClick={() => { setIsImportResultsModalOpen(false); setResultsFiles([]); setTargetExamForResults(null); }} style={{ padding: '4px 8px' }}>
                <X size={16} />
              </button>
            </div>

            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '14px', lineHeight: 1.5 }}>
              Sélectionnez les fichiers de résultats <code>.algoresults</code> (notes corrigées, évaluations) {targetExamForResults ? <>à synchroniser sur <strong style={{ color: '#fbbf24' }}>{targetExamForResults.title}</strong></> : <span style={{ color: '#fbbf24' }}>(synchronisation automatique sur l'épreuve correspondante)</span>}.
            </p>

            <FileDropZone
              accept=".algoresults,.json"
              title="Déposez les fichiers .algoresults ici"
              subtitle="ou cliquez pour parcourir les résultats"
              onFileSelect={(files) => {
                if (Array.isArray(files)) setResultsFiles(files);
                else if (files) setResultsFiles([files]);
              }}
              selectedFile={resultsFiles.length > 0 ? { name: `${resultsFiles.length} fichier(s) .algoresults sélectionné(s)` } : null}
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => { setIsImportResultsModalOpen(false); setResultsFiles([]); setTargetExamForResults(null); }}
                style={{ padding: '8px 16px' }}
              >
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleProcessImportResults}
                disabled={resultsFiles.length === 0 || importingResults}
                style={{ padding: '8px 20px', background: 'linear-gradient(135deg, #f59e0b, #d97706)', border: 'none', fontWeight: '700' }}
              >
                {importingResults ? 'Fusion en cours...' : '📥 Déchiffrer & Fusionner les Résultats'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* System Settings Modal */}
      <SystemSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
}
