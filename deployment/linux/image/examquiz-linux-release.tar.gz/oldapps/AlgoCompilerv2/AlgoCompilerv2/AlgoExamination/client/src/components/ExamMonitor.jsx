import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowLeft, RefreshCw, Zap, Clock, X, ShieldAlert, Pause, Play,
  Unlock, XCircle, BarChart2, Trash2, Radio, Square, Volume2, Package
} from 'lucide-react';
import Swal from 'sweetalert2';
import {
  getExamDetails, updateExamStatus, teacherEmergencyControl, resetExamScores, exportExamBundle
} from '../services/api';
import { getSocket, joinExamRoom } from '../services/socket';
import { getSystemVaultKey } from './SystemSettingsModal';

const EXAM_STATUS = {
  DRAFT:     { label: 'Modèle (Brouillon)', cls: 'badge-secondary', color: '#6b7280' },
  SCHEDULED: { label: 'Planifié',          cls: 'badge-yellow',    color: '#f59e0b' },
  WAITING:   { label: 'En Attente',         cls: 'badge-yellow',    color: '#f59e0b' },
  RUNNING:   { label: 'En Cours (LIVE)',    cls: 'badge-green',     color: '#10b981' },
  PAUSED:    { label: 'Suspendu',           cls: 'badge-red',       color: '#ef4444' },
  FINISHED:  { label: 'Terminé',            cls: 'badge-purple',    color: '#c084fc' },
  CLOSED:    { label: 'Clôturé',            cls: 'badge-secondary', color: '#6b7280' },
};

const EXAM_PROGRESS_STATUS = {
  NOT_ENTERED:  { label: 'Non commencé',     cls: 'badge-secondary', icon: '🕒' },
  WAITING:      { label: 'En attente',       cls: 'badge-yellow',    icon: '⏳' },
  IN_EXAM:      { label: 'En épreuve',       cls: 'badge-green',     icon: '💻' },
  PAUSED:       { label: 'Suspendu',         cls: 'badge-red',       icon: '⏸️' },
  FINISHED:     { label: 'Terminé',          cls: 'badge-purple',    icon: '✅' },
  KICKED_OUT:   { label: 'Exclu',            cls: 'badge-red',       icon: '🚫' },
  ABSENT:       { label: 'Absent',           cls: 'badge-secondary', icon: '❌' },
};

function getConnectionBadge(isOnline, lastSeenAt) {
  if (isOnline) {
    return (
      <span
        className="badge badge-green"
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px',
          padding: '4px 10px',
          fontSize: '0.78rem',
          fontWeight: '700'
        }}
        title="Connecté en direct à la plateforme"
      >
        <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#10b981', boxShadow: '0 0 6px #10b981', display: 'inline-block' }} />
        Connecté
      </span>
    );
  }
  return (
    <span
      className="badge badge-secondary"
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        padding: '4px 10px',
        fontSize: '0.78rem',
        opacity: 0.85,
        color: '#94a3b8',
        border: '1px solid rgba(148, 163, 184, 0.2)'
      }}
      title={lastSeenAt ? `Déconnecté (Dernière activité: ${relativeTime(lastSeenAt)})` : 'Jamais connecté'}
    >
      <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#64748b', display: 'inline-block' }} />
      Déconnecté
    </span>
  );
}

function getExamProgressDisplay(assignment, isOnline) {
  const status = assignment?.status;
  if (status === 'FINISHED') {
    return { label: 'Épreuve terminée', cls: 'badge-purple', icon: '✅' };
  }
  if (status === 'KICKED_OUT') {
    return { label: 'Exclu', cls: 'badge-red', icon: '🚫' };
  }
  if (status === 'ABSENT') {
    return { label: 'Absent', cls: 'badge-secondary', icon: '❌' };
  }
  if (status === 'PAUSED') {
    return {
      label: isOnline
        ? (assignment.pausedUntil ? 'Suspendu (5 min)' : 'Suspendu')
        : (assignment.pausedUntil ? 'Suspendu (5 min, Hors ligne)' : 'Suspendu (Hors ligne)'),
      cls: 'badge-red',
      icon: '⏸️'
    };
  }
  if (status === 'IN_EXAM') {
    if (isOnline) {
      return { label: 'En épreuve', cls: 'badge-green', icon: '💻' };
    } else {
      return { label: "A quitté l'épreuve", cls: 'badge-red', icon: '⚠️' };
    }
  }
  // WAITING or NOT_ENTERED or undefined
  if (isOnline) {
    return { label: 'En attente', cls: 'badge-yellow', icon: '⏳' };
  }
  return { label: 'Pas encore rejoint', cls: 'badge-secondary', icon: '🕒' };
}

function relativeTime(isoString) {
  if (!isoString) return '—';
  const diffSec = Math.floor((Date.now() - new Date(isoString).getTime()) / 1000);
  if (diffSec < 5) return 'À l\'instant';
  if (diffSec < 60) return `il y a ${diffSec}s`;
  const m = Math.floor(diffSec / 60);
  if (m < 60) return `il y a ${m} min`;
  return new Date(isoString).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

export default function ExamMonitor({
  exam: initialExam,
  onBack,
  onViewResults,
  onViewCorrection,
  onNavigate,
  autoGradingExamId
}) {
  const [examDetail, setExamDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [onlineMap, setOnlineMap] = useState({});
  const [alerts, setAlerts] = useState([]);
  const [liveLogs, setLiveLogs] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('ALL');
  const [connectionFilter, setConnectionFilter] = useState('ALL');
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(null);
  const pollRef = useRef(null);
  const alertIdRef = useRef(0);

  /* ── Timer Countdown Effect ── */
  useEffect(() => {
    if (!examDetail?.startTime || !examDetail?.durationMinutes || !['RUNNING', 'PAUSED'].includes(examDetail?.status)) {
      setTimeLeftSeconds(null);
      return;
    }

    const updateTimer = () => {
      if (examDetail?.status === 'PAUSED') {
        return; // Freeze countdown while exam is paused
      }
      const start = new Date(examDetail.startTime).getTime();
      const totalMs = examDetail.durationMinutes * 60 * 1000;
      const elapsed = Date.now() - start;
      const remainingMs = Math.max(0, totalMs - elapsed);
      setTimeLeftSeconds(Math.floor(remainingMs / 1000));
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [examDetail?.startTime, examDetail?.durationMinutes, examDetail?.status]);

  const formatTimer = (totalSecs) => {
    if (totalSecs === null || totalSecs < 0) return null;
    const h = Math.floor(totalSecs / 3600);
    const m = Math.floor((totalSecs % 3600) / 60);
    const s = totalSecs % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  /* ── Load exam detail ── */
  const loadDetail = useCallback(async () => {
    try {
      const data = await getExamDetails(initialExam.id);
      setExamDetail(data);
      const map = {};
      data.assignments.forEach(a => {
        map[a.studentId] = { isOnline: a.isOnline, lastSeenAt: a.lastSeenAt };
      });
      setOnlineMap(prev => ({ ...prev, ...map }));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [initialExam.id]);

  useEffect(() => {
    loadDetail();
    joinExamRoom(initialExam.id, null, true);
    pollRef.current = setInterval(loadDetail, 5000);
    return () => clearInterval(pollRef.current);
  }, [loadDetail, initialExam.id]);

  /* ── Socket listeners ── */
  useEffect(() => {
    const socket = getSocket();

    const addAlert = (msg, color = '#f87171') => {
      const id = ++alertIdRef.current;
      setAlerts(prev => [{ id, msg, color }, ...prev.slice(0, 4)]);
      setTimeout(() => setAlerts(prev => prev.filter(a => a.id !== id)), 12000);
    };

    const onStatusChanged = ({ studentId, status, studentName, isOnline, lastSeenAt, accessNumber, violations, fullscreenExits }) => {
      setExamDetail(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          assignments: prev.assignments.map(a =>
            (a.studentId === studentId || a.student?.id === studentId)
              ? {
                  ...a,
                  status,
                  ...(violations !== undefined ? { violations } : {}),
                  ...(fullscreenExits !== undefined ? { fullscreenExits } : {})
                }
              : a
          )
        };
      });
      if (isOnline !== undefined) {
        setOnlineMap(prev => ({ ...prev, [studentId]: { isOnline, lastSeenAt } }));
      }
    };

    const onOnlineChanged = ({ studentId, isOnline, lastSeenAt, studentName, accessNumber, status }) => {
      setOnlineMap(prev => ({ ...prev, [studentId]: { isOnline, lastSeenAt } }));
      if (!isOnline && status === 'DISCONNECTED') {
        addAlert(`⚠️ ${studentName || studentId} [${accessNumber || ''}] s'est déconnecté`, '#f59e0b');
      }
      onStatusChanged({ studentId, status, isOnline, lastSeenAt });
    };

    const onExamStatusChanged = ({ status, startTime }) => {
      setExamDetail(prev => prev ? { ...prev, status, startTime: startTime || prev.startTime } : prev);
    };

    const onLiveMonitoring = (event) => {
      setLiveLogs(prev => [event, ...prev.slice(0, 79)]);
      if (event.violations !== undefined) {
        setExamDetail(prev => {
          if (!prev) return prev;
          return {
            ...prev,
            assignments: prev.assignments.map(a =>
              (a.studentId === event.studentId || a.student?.id === event.studentId)
                ? { ...a, violations: event.violations }
                : a
            )
          };
        });
      }
      if (['FULLSCREEN_EXIT', 'TAB_SWITCH', 'KICKED_FULLSCREEN'].includes(event.eventType)) {
        const sev = event.eventType === 'KICKED_FULLSCREEN' ? '#ef4444' : '#f59e0b';
        addAlert(`🚨 ${event.studentName || event.studentId} — ${event.eventType}`, sev);
      }
    };

    const onStudentFinished = ({ studentId, studentName }) => {
      addAlert(`✅ ${studentName || studentId} a soumis son examen`, '#34d399');
    };

    const handleConnect = () => {
      joinExamRoom(initialExam.id, null, true);
    };

    if (socket) {
      socket.on('student_status_changed',  onStatusChanged);
      socket.on('student_online_changed',  onOnlineChanged);
      socket.on('exam_status_changed',     onExamStatusChanged);
      socket.on('live_monitoring_event',   onLiveMonitoring);
      socket.on('student_finished',        onStudentFinished);
      socket.on('connect',                handleConnect);
    }

    return () => {
      if (socket) {
        socket.off('student_status_changed',  onStatusChanged);
        socket.off('student_online_changed',  onOnlineChanged);
        socket.off('exam_status_changed',     onExamStatusChanged);
        socket.off('live_monitoring_event',   onLiveMonitoring);
        socket.off('student_finished',        onStudentFinished);
        socket.off('connect',                handleConnect);
      }
    };
  }, [initialExam.id]);

  /* ── Actions ── */
  const handleStatusChange = async (newStatus) => {
    try {
      await updateExamStatus(initialExam.id, newStatus);
      loadDetail();
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Erreur', text: err.data?.error, background: '#111827', color: '#fff' });
    }
  };

  const handleStudentAction = async (studentId, action, extra = {}) => {
    await teacherEmergencyControl(initialExam.id, { action, studentId, ...extra });
    loadDetail();
  };

  const handleExtendTime = async () => {
    const { value: mins } = await Swal.fire({
      title: 'Prolonger la durée (tous)',
      input: 'number', inputValue: 10,
      inputLabel: 'Minutes à ajouter:',
      showCancelButton: true, confirmButtonText: 'Ajouter',
      background: '#111827', color: '#fff', confirmButtonColor: '#10b981'
    });
    if (mins) {
      await teacherEmergencyControl(initialExam.id, { action: 'EXTEND_TIME_ALL', extensionMinutes: +mins });
      Swal.fire({ icon: 'success', title: `+${mins} min ajoutées`, timer: 1200, showConfirmButton: false, background: '#111827', color: '#fff' });
    }
  };

  const handleAnnouncement = async () => {
    const { value: msg } = await Swal.fire({
      title: 'Diffuser une Annonce',
      input: 'textarea', inputPlaceholder: 'Votre message...',
      showCancelButton: true, confirmButtonText: 'Envoyer',
      background: '#111827', color: '#fff', confirmButtonColor: '#3b82f6'
    });
    if (msg) {
      await teacherEmergencyControl(initialExam.id, { action: 'ANNOUNCEMENT', message: msg });
      Swal.fire({ icon: 'success', title: 'Annonce diffusée !', timer: 1200, showConfirmButton: false, background: '#111827', color: '#fff' });
    }
  };

  const handleExportBundle = async () => {
    try {
      const vaultKey = getSystemVaultKey();
      const encryptedData = await exportExamBundle(initialExam.id, vaultKey);
      const jsonStr = JSON.stringify(encryptedData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Paquet_Salle_${(examDetail?.title || initialExam.title || 'Examen').replace(/[^\w]/g, '_')}.algobundle`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: '📦 Paquet Exporté !',
        text: 'Le fichier chiffré .algobundle a été téléchargé avec succès.',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export bundle error:', err);
      Swal.fire({ icon: 'error', title: 'Erreur', text: err.data?.error || err.message, background: '#111827', color: '#fff' });
    }
  };

  /* ── Derived data ── */
  const assignments = examDetail?.assignments || [];

  const onlineCount = assignments.filter(a => {
    const p = onlineMap[a.studentId] || { isOnline: a.isOnline };
    return !!p.isOnline;
  }).length;

  const counts = {
    total:      assignments.length,
    online:     onlineCount,
    offline:    assignments.length - onlineCount,
    inExam:     assignments.filter(a => a.status === 'IN_EXAM' && !!(onlineMap[a.studentId]?.isOnline ?? a.isOnline)).length,
    leftExam:   assignments.filter(a => a.status === 'IN_EXAM' && !(onlineMap[a.studentId]?.isOnline ?? a.isOnline)).length,
    waiting:    assignments.filter(a => ['WAITING', 'NOT_ENTERED'].includes(a.status) && !!(onlineMap[a.studentId]?.isOnline ?? a.isOnline)).length,
    notJoined:  assignments.filter(a => ['WAITING', 'NOT_ENTERED'].includes(a.status) && !(onlineMap[a.studentId]?.isOnline ?? a.isOnline)).length,
    paused:     assignments.filter(a => a.status === 'PAUSED').length,
    finished:   assignments.filter(a => a.status === 'FINISHED').length,
    kicked:     assignments.filter(a => a.status === 'KICKED_OUT').length,
  };

  const filtered = assignments.filter(a => {
    const presence = onlineMap[a.studentId] || { isOnline: a.isOnline, lastSeenAt: a.lastSeenAt };
    const isOnline = !!presence.isOnline;

    const name = `${a.student?.firstName} ${a.student?.lastName} ${a.accessNumber} ${a.student?.studentId}`.toLowerCase();
    const matchSearch = name.includes(search.toLowerCase());

    let matchExamFilter = true;
    if (filter === 'IN_EXAM') {
      matchExamFilter = a.status === 'IN_EXAM' && isOnline;
    } else if (filter === 'LEFT_EXAM') {
      matchExamFilter = a.status === 'IN_EXAM' && !isOnline;
    } else if (filter === 'WAITING') {
      matchExamFilter = ['WAITING', 'NOT_ENTERED'].includes(a.status) && isOnline;
    } else if (filter === 'NOT_JOINED') {
      matchExamFilter = ['WAITING', 'NOT_ENTERED'].includes(a.status) && !isOnline;
    } else if (filter === 'PAUSED') {
      matchExamFilter = a.status === 'PAUSED';
    } else if (filter === 'FINISHED') {
      matchExamFilter = a.status === 'FINISHED';
    } else if (filter === 'KICKED_OUT') {
      matchExamFilter = a.status === 'KICKED_OUT';
    }

    const matchConnFilter = connectionFilter === 'ALL' || (connectionFilter === 'ONLINE' ? isOnline : !isOnline);

    return matchSearch && matchExamFilter && matchConnFilter;
  });

  if (loading) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '16px' }}>
        <Zap size={40} color="#3b82f6" style={{ animation: 'pulse 1s infinite' }} />
        <p>Chargement de la surveillance...</p>
      </div>
    );
  }

  const examStatus = examDetail?.status || initialExam.status;
  const si = EXAM_STATUS[examStatus] || EXAM_STATUS.DRAFT;

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#0b0f19' }}>

      {/* ── Top bar ── */}
      <header className="glass-panel" style={{ borderRadius: 0, padding: '12px 24px', display: 'flex', alignItems: 'center', gap: '16px', borderBottom: '1px solid var(--panel-border)', flexShrink: 0 }}>
        <button className="btn btn-secondary" style={{ padding: '6px 12px' }} onClick={onBack}>
          <ArrowLeft size={16} /> Retour
        </button>

        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
            <h2 style={{ fontSize: '1.1rem', margin: 0 }}>{examDetail?.title || initialExam.title}</h2>
            <span className={`badge ${si.cls}`}>{si.label}</span>
            {examStatus === 'RUNNING' && (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', color: '#10b981', fontSize: '0.78rem', fontWeight: '700' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#10b981', animation: 'pulse 1s infinite', display: 'inline-block' }} />
                LIVE — 5s
              </span>
            )}
            {formatTimer(timeLeftSeconds) && (
              <span style={{
                fontSize: '0.88rem', padding: '4px 12px',
                background: examDetail?.status === 'PAUSED' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(59, 130, 246, 0.15)',
                color: examDetail?.status === 'PAUSED' ? '#fbbf24' : '#60a5fa',
                border: `1px solid ${examDetail?.status === 'PAUSED' ? '#f59e0b' : 'rgba(59, 130, 246, 0.3)'}`,
                borderRadius: '20px', display: 'inline-flex', alignItems: 'center', gap: '6px', fontFamily: 'var(--font-mono)'
              }}>
                <Clock size={14} /> <strong>{examDetail?.status === 'PAUSED' ? `⏸ EN PAUSE (${formatTimer(timeLeftSeconds)})` : formatTimer(timeLeftSeconds)}</strong>
              </span>
            )}
          </div>
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {['FINISHED', 'CLOSED'].includes(examStatus) && (
            <button
              className="btn btn-primary"
              style={{ padding: '7px 14px', fontSize: '0.85rem', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: '700' }}
              onClick={handleExportBundle}
              title="Télécharger le paquet chiffré .algobundle des soumissions de cette salle"
            >
              <Package size={14} /> Exporter Paquet (.algobundle)
            </button>
          )}

          {['FINISHED', 'CLOSED'].includes(examStatus) && onViewCorrection && (
            <button
              className="btn btn-secondary"
              disabled={autoGradingExamId === (examDetail?.id || initialExam.id)}
              style={{
                padding: '7px 14px', fontSize: '0.85rem',
                background: 'rgba(168,85,247,0.15)', color: '#c084fc', border: '1px solid rgba(168,85,247,0.4)'
              }}
              onClick={onViewCorrection}
            >
              ✏️ Corriger
            </button>
          )}

          {['FINISHED', 'CLOSED'].includes(examStatus) && onViewResults && (
            <button
              className="btn btn-success"
              style={{ padding: '7px 14px', fontSize: '0.85rem', background: 'rgba(16,185,129,0.15)', color: '#34d399', border: '1px solid rgba(16,185,129,0.4)' }}
              onClick={onViewResults}
            >
              <BarChart2 size={14} /> Résultats
            </button>
          )}

          {examStatus !== 'RUNNING' && !['FINISHED', 'CLOSED'].includes(examStatus) && (
            <button className="btn btn-success" style={{ padding: '7px 14px', fontSize: '0.85rem' }} onClick={() => handleStatusChange('RUNNING')}>
              <Play size={14} /> Lancer l'Examen
            </button>
          )}
          {examStatus === 'RUNNING' && (
            <button className="btn btn-danger" style={{ padding: '7px 14px', fontSize: '0.85rem', background: 'rgba(245,158,11,0.15)', color: '#fbbf24', border: '1px solid rgba(245,158,11,0.4)' }} onClick={() => handleStatusChange('PAUSED')}>
              <Pause size={14} /> Suspendre
            </button>
          )}
          {!['FINISHED', 'CLOSED'].includes(examStatus) && (
            <button
              className="btn btn-danger"
              style={{ padding: '7px 14px', fontSize: '0.85rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '6px' }}
              onClick={async () => {
                const result = await Swal.fire({
                  title: '🛑 Arrêter l\'Examen ?',
                  html: `<p style="color:#fca5a5">Cette action va <strong>expulser immédiatement tous les étudiants</strong> encore connectés et clôturer l'épreuve définitivement.</p>`,
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonText: 'Oui, arrêter l\'examen',
                  cancelButtonText: 'Annuler',
                  confirmButtonColor: '#ef4444',
                  cancelButtonColor: '#6b7280',
                  background: '#111827', color: '#fff'
                });
                if (result.isConfirmed) {
                  await handleStatusChange('FINISHED');
                  const askBundle = await Swal.fire({
                    icon: 'success',
                    title: '🏁 Épreuve Terminée !',
                    text: 'Tous les étudiants ont été déconnectés. Souhaitez-vous télécharger le paquet chiffré .algobundle maintenant ?',
                    showCancelButton: true,
                    confirmButtonText: '📦 Télécharger le Paquet (.algobundle)',
                    cancelButtonText: 'Rester sur cette page',
                    confirmButtonColor: '#10b981',
                    cancelButtonColor: '#3b82f6',
                    background: '#111827',
                    color: '#fff'
                  });
                  if (askBundle.isConfirmed) {
                    await handleExportBundle();
                  }
                }
              }}
            >
              <Square size={14} /> Terminer l'Examen
            </button>
          )}
          <button className="btn btn-secondary" style={{ padding: '7px 12px' }} title="Prolonger le temps" onClick={handleExtendTime}>
            <Clock size={15} />
          </button>
          <button className="btn btn-secondary" style={{ padding: '7px 12px' }} title="Diffuser une annonce" onClick={handleAnnouncement}>
            <Radio size={15} color="#60a5fa" />
          </button>
          <button className="btn btn-secondary" style={{ padding: '7px 12px' }} title="Rafraîchir" onClick={loadDetail}>
            <RefreshCw size={15} />
          </button>
        </div>
      </header>

      {/* ── Floating Alert Toasts (Bottom-Right to avoid covering header action buttons) ── */}
      {alerts.length > 0 && (
        <div style={{
          position: 'fixed', bottom: '24px', right: '24px', zIndex: 99999,
          display: 'flex', flexDirection: 'column-reverse', gap: '8px',
          maxWidth: '380px', pointerEvents: 'none'
        }}>
          {alerts.map(alert => (
            <div key={alert.id} style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px',
              padding: '10px 16px', borderRadius: '10px',
              background: '#111827', border: `1px solid ${alert.color}`,
              boxShadow: '0 8px 30px rgba(0,0,0,0.6)',
              color: alert.color, fontSize: '0.85rem', fontWeight: '600',
              pointerEvents: 'auto'
            }}>
              <span>{alert.msg}</span>
              <button onClick={() => setAlerts(prev => prev.filter(a => a.id !== alert.id))}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'inherit', padding: '0 4px' }}>
                <X size={14} style={{ flexShrink: 0 }} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* ── Stat pills: Two clearly separated categories ── */}
      <div style={{ display: 'flex', gap: '8px', padding: '12px 24px', flexShrink: 0, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ padding: '5px 12px', borderRadius: '16px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', fontSize: '0.8rem', fontWeight: '700' }}>
          Total Inscrits : {counts.total}
        </div>

        <span style={{ color: 'rgba(255,255,255,0.2)', fontSize: '0.85rem', margin: '0 4px' }}>|</span>
        <span style={{ fontSize: '0.78rem', color: '#94a3b8', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Connexion :</span>

        <button
          onClick={() => setConnectionFilter(prev => prev === 'ONLINE' ? 'ALL' : 'ONLINE')}
          style={{
            padding: '5px 12px', borderRadius: '16px', cursor: 'pointer',
            background: connectionFilter === 'ONLINE' ? 'rgba(16, 185, 129, 0.3)' : 'rgba(16, 185, 129, 0.12)',
            border: `1px solid ${connectionFilter === 'ONLINE' ? '#10b981' : 'rgba(16, 185, 129, 0.3)'}`,
            color: '#34d399', fontSize: '0.8rem', fontWeight: '700', display: 'inline-flex', alignItems: 'center', gap: '6px'
          }}
          title="Cliquer pour filtrer : Candidats connectés"
        >
          <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#10b981', display: 'inline-block' }} />
          En ligne : {counts.online}
        </button>

        <button
          onClick={() => setConnectionFilter(prev => prev === 'OFFLINE' ? 'ALL' : 'OFFLINE')}
          style={{
            padding: '5px 12px', borderRadius: '16px', cursor: 'pointer',
            background: connectionFilter === 'OFFLINE' ? 'rgba(148, 163, 184, 0.25)' : 'rgba(148, 163, 184, 0.1)',
            border: `1px solid ${connectionFilter === 'OFFLINE' ? '#94a3b8' : 'rgba(148, 163, 184, 0.25)'}`,
            color: '#94a3b8', fontSize: '0.8rem', fontWeight: '700', display: 'inline-flex', alignItems: 'center', gap: '6px'
          }}
          title="Cliquer pour filtrer : Candidats hors ligne"
        >
          <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#64748b', display: 'inline-block' }} />
          Hors ligne : {counts.offline}
        </button>

        <span style={{ color: 'rgba(255,255,255,0.2)', fontSize: '0.85rem', margin: '0 4px' }}>|</span>
        <span style={{ fontSize: '0.78rem', color: '#94a3b8', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Statut Épreuve :</span>

        {[
          { key: 'IN_EXAM',    label: '💻 En épreuve',         value: counts.inExam,    color: '#3b82f6' },
          { key: 'LEFT_EXAM',  label: "⚠️ A quitté l'épreuve", value: counts.leftExam,  color: '#ef4444' },
          { key: 'NOT_JOINED', label: '🕒 Pas encore rejoint', value: counts.notJoined, color: '#6b7280' },
          { key: 'WAITING',    label: '⏳ En attente',         value: counts.waiting,   color: '#f59e0b' },
          { key: 'PAUSED',     label: '⏸️ Suspendu',           value: counts.paused,    color: '#ea580c' },
          { key: 'FINISHED',   label: '✅ Terminé',            value: counts.finished,  color: '#a855f7' },
          { key: 'KICKED_OUT', label: '🚫 Exclu',              value: counts.kicked,    color: '#dc2626' },
        ].map(({ key, label, value, color }) => (
          <button
            key={key}
            onClick={() => setFilter(prev => prev === key ? 'ALL' : key)}
            style={{
              padding: '5px 12px', borderRadius: '16px', cursor: 'pointer',
              background: filter === key ? `${color}44` : `${color}18`,
              border: `1px solid ${filter === key ? color : `${color}40`}`,
              color, fontSize: '0.8rem', fontWeight: '700'
            }}
          >
            {label} : {value}
          </button>
        ))}
      </div>

      {/* ── Main 2-column area ── */}
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 300px', gap: '0', overflow: 'hidden' }}>

        {/* Left: Student Table */}
        <div style={{ overflow: 'auto', padding: '0 24px 24px' }}>

          {/* Filters */}
          <div style={{ display: 'flex', gap: '10px', marginBottom: '14px', flexWrap: 'wrap', alignItems: 'center' }}>
            <input
              type="text"
              className="form-input"
              placeholder="🔍 Rechercher nom, matricule, N° accès..."
              style={{ width: '250px', padding: '7px 12px', fontSize: '0.85rem' }}
              value={search}
              onChange={e => setSearch(e.target.value)}
            />

            {/* Exam status filters */}
            <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
              {[
                { id: 'ALL',        label: 'Tous les statuts' },
                { id: 'IN_EXAM',    label: '💻 En épreuve' },
                { id: 'LEFT_EXAM',  label: "⚠️ A quitté l'épreuve" },
                { id: 'NOT_JOINED', label: '🕒 Pas encore rejoint' },
                { id: 'WAITING',    label: '⏳ En attente' },
                { id: 'PAUSED',     label: '⏸️ Suspendu' },
                { id: 'FINISHED',   label: '✅ Terminé' },
                { id: 'KICKED_OUT', label: '🚫 Exclu' },
              ].map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => setFilter(id)}
                  className={`btn ${filter === id ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ padding: '5px 12px', fontSize: '0.78rem' }}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Connection filter toggle */}
            <div style={{ display: 'flex', gap: '5px', marginLeft: 'auto' }}>
              {[
                { id: 'ALL',     label: 'Toutes connexions' },
                { id: 'ONLINE',  label: '🟢 En ligne' },
                { id: 'OFFLINE', label: '⚪ Hors ligne' },
              ].map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => setConnectionFilter(id)}
                  className={`btn ${connectionFilter === id ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ padding: '5px 12px', fontSize: '0.78rem' }}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Table */}
          <table className="data-table" style={{ fontSize: '0.85rem' }}>
            <thead>
              <tr>
                <th style={{ width: '120px' }}>Connexion</th>
                <th style={{ width: '160px' }}>Statut Épreuve</th>
                <th>N° Accès</th>
                <th>Étudiant</th>
                <th>Groupe</th>
                <th>Avert.</th>
                <th>Dernière activité</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '30px' }}>
                    Aucun étudiant trouvé pour ces critères de recherche.
                  </td>
                </tr>
              ) : filtered.map(a => {
                const presence = onlineMap[a.studentId] || { isOnline: a.isOnline, lastSeenAt: a.lastSeenAt };
                const display = getExamProgressDisplay(a, presence.isOnline);

                return (
                  <tr key={a.id} style={{ opacity: ['KICKED_OUT', 'ABSENT'].includes(a.status) ? 0.55 : 1 }}>
                    <td>
                      {getConnectionBadge(presence.isOnline, presence.lastSeenAt)}
                    </td>
                    <td>
                      <span className={`badge ${display.cls}`} style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', fontWeight: '700' }}>
                        <span>{display.icon}</span>
                        {display.label}
                      </span>
                    </td>
                    <td>
                      <code style={{ color: '#34d399', fontFamily: 'var(--font-mono)', fontWeight: '700' }}>
                        {a.accessNumber}
                      </code>
                    </td>
                    <td>
                      <strong>{a.student?.firstName} {a.student?.lastName}</strong>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{a.student?.studentId}</div>
                    </td>
                    <td style={{ color: 'var(--text-muted)' }}>{a.student?.group}</td>
                    <td>
                      <span style={{ color: a.violations > 0 ? (a.violations >= 4 ? '#ef4444' : '#f59e0b') : 'var(--text-main)', fontWeight: '700' }}>
                        {a.violations}
                      </span>
                      {a.fullscreenExits > 0 && (
                        <div style={{ fontSize: '0.7rem', color: '#f59e0b' }}>🖥 {a.fullscreenExits} FS exit</div>
                      )}
                    </td>
                    <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                      {relativeTime(presence.lastSeenAt || a.loginTime)}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        {a.status === 'PAUSED' ? (
                          <button
                            className="btn btn-success"
                            style={{ padding: '4px 10px', fontSize: '0.78rem', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
                            title="Débloquer l'étudiant immédiatement"
                            onClick={() => handleStudentAction(a.studentId, 'UNLOCK_STUDENT')}
                          >
                            <Unlock size={13} /> Reprendre
                          </button>
                        ) : !['FINISHED', 'KICKED_OUT', 'ABSENT'].includes(a.status) && (
                          <>
                            <button
                              className="btn btn-secondary"
                              style={{ padding: '4px 10px', fontSize: '0.78rem', background: 'rgba(245, 158, 11, 0.15)', color: '#fbbf24', border: '1px solid rgba(245, 158, 11, 0.4)', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
                              title="Suspendre l'étudiant indéfiniment"
                              onClick={() => handleStudentAction(a.studentId, 'LOCK_STUDENT')}
                            >
                              <Pause size={13} /> Suspendre
                            </button>
                            <button
                              className="btn btn-secondary"
                              style={{ padding: '4px 8px', fontSize: '0.75rem', background: 'rgba(59, 130, 246, 0.15)', color: '#60a5fa', border: '1px solid rgba(59, 130, 246, 0.3)', display: 'inline-flex', alignItems: 'center', gap: '3px' }}
                              title="Suspendre temporairement pour 5 minutes"
                              onClick={() => handleStudentAction(a.studentId, 'SUSPEND_STUDENT_TEMP', { durationMinutes: 5 })}
                            >
                              <Clock size={12} /> 5 min
                            </button>
                          </>
                        )}
                        {!['FINISHED', 'KICKED_OUT', 'ABSENT'].includes(a.status) && (
                          <button
                            className="btn btn-danger"
                            style={{ padding: '4px 10px', fontSize: '0.78rem', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
                            title="Exclure l'étudiant définitivement"
                            onClick={async () => {
                              const res = await Swal.fire({
                                title: '🛑 Exclure l\'Étudiant ?',
                                text: `Êtes-vous sûr de vouloir exclure définitivement ${a.student?.firstName} ${a.student?.lastName} ?`,
                                icon: 'warning',
                                showCancelButton: true,
                                confirmButtonText: 'Oui, Exclure',
                                cancelButtonText: 'Annuler',
                                background: '#111827', color: '#fff',
                                confirmButtonColor: '#ef4444'
                              });
                              if (res.isConfirmed) handleStudentAction(a.studentId, 'TERMINATE_STUDENT');
                            }}
                          >
                            <XCircle size={13} /> Exclure
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Right: Live Activity Feed */}
        <div style={{ borderLeft: '1px solid var(--panel-border)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '16px 16px 10px', borderBottom: '1px solid var(--panel-border)', flexShrink: 0 }}>
            <h3 style={{ fontSize: '0.95rem', margin: 0, display: 'flex', alignItems: 'center', gap: '7px' }}>
              <ShieldAlert size={16} color="#f87171" /> Journal en Direct
              <span style={{ marginLeft: 'auto', fontSize: '0.72rem', color: 'var(--text-muted)' }}>{liveLogs.length} événements</span>
            </h3>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '10px 14px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {liveLogs.length === 0 ? (
              <div style={{ color: 'var(--text-muted)', fontSize: '0.82rem', textAlign: 'center', marginTop: '20px' }}>
                Aucun événement détecté.
              </div>
            ) : liveLogs.map((log, idx) => {
              const isRed   = ['FULLSCREEN_EXIT', 'TAB_SWITCH', 'FOCUS_LOSS', 'KICKED_FULLSCREEN'].includes(log.eventType);
              const isGreen = ['FULLSCREEN_RETURN', 'CONNECTED', 'RE_ENTERED', 'SUBMITTED'].includes(log.eventType);
              const color   = isRed ? '#f87171' : isGreen ? '#34d399' : '#f59e0b';

              return (
                <div key={idx} style={{
                  padding: '8px 10px', borderRadius: '6px', fontSize: '0.78rem',
                  background: `${color}18`, border: `1px solid ${color}40`
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', color, fontWeight: '700', marginBottom: '3px' }}>
                    <span>{log.eventType}</span>
                    <span>{new Date(log.timestamp).toLocaleTimeString('fr-FR')}</span>
                  </div>
                  <div style={{ color: '#fff' }}>
                    <strong>{log.studentName || log.studentId}</strong>
                    {log.accessNumber && (
                      <code style={{ marginLeft: '6px', color: '#34d399', fontFamily: 'var(--font-mono)', fontSize: '0.72rem' }}>
                        {log.accessNumber}
                      </code>
                    )}
                  </div>
                  {log.violations > 0 && (
                    <div style={{ color: '#f59e0b', fontSize: '0.7rem', marginTop: '2px' }}>
                      Total: {log.violations} violations
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
