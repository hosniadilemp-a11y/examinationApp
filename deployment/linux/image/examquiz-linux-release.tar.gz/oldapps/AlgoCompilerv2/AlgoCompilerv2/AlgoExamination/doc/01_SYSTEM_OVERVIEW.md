# 01. AlgoExamination — System Overview & Requirements

## 📌 Executive Summary
**AlgoExamination** is a full-stack, real-time academic examination and automated algorithmic grading platform tailored for computer science education (e.g., École Nationale Supérieure d'Informatique). It enables educators to design custom pseudo-code exams, assign point allocations, enforce strict anti-cheating protocols, monitor students live in real-time, grade algorithmic solutions, and generate official B&W academic PDF copies with cryptographic QR code verification.

---

## 🛠️ Technology Stack

### Frontend
- **Framework**: React (Vite)
- **UI & Styling**: Vanilla CSS design system, Glassmorphism, HSL color tokens, dark mode palette (`#0b0f19`).
- **Icons**: Lucide React (`lucide-react`)
- **UI Alerts & Modals**: SweetAlert2 (`sweetalert2`)
- **Real-Time Client**: Socket.IO Client (`socket.io-client`)
- **Code Editor**: CodeMirror 6 environment (`ExamWorkspace.jsx`) featuring VS Code-inspired Intellisense autocompletion (`algo-language.js`), teacher-configurable Code Bricks, shortcut suppression, and dynamic font scaling. See [06_ALGO_COMPILER_SPECIFICATION.md](file:///home/adel/Documents/Coding%20and%20projects/AlgoCompilerv2/AlgoExamination/doc/06_ALGO_COMPILER_SPECIFICATION.md).

### Backend
- **Runtime & Server**: Node.js (v20) + Express.js
- **Database & ORM**: PostgreSQL (`algoexam_db`) + Prisma ORM (Schema: `exam`)
- **Real-Time Engine**: Socket.IO (`socket.io`)
- **PDF Generation**: PDFKit (`pdfkit`) — Pure Black & White academic styling
- **QR Code Generation**: `qrcode` library with SHA-256 HMAC cryptographic signatures
- **Archive System**: `archiver` (v5 CommonJS) for streaming bulk student PDF copies in `.zip` format
- **Code Execution Sandbox**: Node.js child process isolate runner for algorithmic pseudo-code execution & test case evaluation

---

## 📋 Core User Requirements & Features

### 1. Global Synchronized Exam Timer
- **Server Clock Synchronization**: When the teacher launches the exam (`RUNNING`), `exam.startTime` is recorded in PostgreSQL. Every student workspace calculates remaining time using `(startTime + durationMinutes + extendedTime) - now()`, ensuring a single global countdown shared by all students.

### 2. Anti-Cheat Violations & Suspension Protocol
- **Strict Anti-Cheat Limit Policy**: Anti-cheat limit breaches (3 fullscreen exits or max violation threshold) automatically trigger **Suspension (`PAUSED`)**, NOT Exclusion.
- **Teacher Exclusive Right to Exclude**: Only the teacher has the authority to manually click **🛑 Exclure** (`TERMINATE_STUDENT`).
- **10-Second Fullscreen Exit Grace Period**: If a student exits fullscreen, a live **10-second countdown** is displayed. If the student fails to re-enable fullscreen within 10 seconds, their session is automatically **suspended**.
- **Suspended State Visual Overlay**: Suspended students (`PAUSED`) remain in `ExamWorkspace.jsx` with a semi-transparent blurred backdrop overlay ("Session Suspendue"). Screen and code are visible underneath, but all typing and button clicks are locked.
- **Excluded State Action (`KICKED_OUT`)**: Excluded students are immediately logged out and redirected to the completed exam landing page.

### 3. Teacher Emergency & Control Panel (`TeacherDashboard.jsx`)
- **Explicit Action Controls**:
  - 🟠 **Suspendre**: Indefinite suspension (`LOCK_STUDENT`).
  - ⏳ **5 min**: Temporary 5-minute suspension (`SUSPEND_STUDENT_TEMP`) with automatic live countdown on student screen and auto-resume on expiry.
  - 🟢 **Reprendre**: Instant unlock (`UNLOCK_STUDENT`).
  - 🛑 **Exclure**: Permanent exclusion (`TERMINATE_STUDENT`) with confirmation prompt.
- **Floating Top-Right Toast Stream**: Suspicious activities (fullscreen exits, tab switches, disconnects) appear as sleek floating toasts in the top-right corner (`zIndex: 99999`) without pushing down interface elements.
