# AlgoExamination — Agent Documentation

## Purpose

This `doc/` directory is the persistent engineering reference for AI coding agents.

It should evolve with the application.

## Reading Order

1. `00_AGENT_START_HERE.md`
2. `01_ARCHITECTURE.md`
3. `02_ENGINEERING_RULES.md`
4. `16_DATABASE_DESIGN_RULES.md`
5. `17_ALGO_COMPILER_SPECIFICATION.md`
6. Task-specific document(s)
7. `13_COMMON_AGENT_MISTAKES.md`
8. `14_TASK_EXECUTION_PROTOCOL.md`
9. `12_VERIFICATION.md`

## Documentation Philosophy

These files are not generic programming advice.

They document project-specific:
- architecture
- contracts
- invariants
- known failure modes
- dependency constraints
- real-time behavior
- grading rules
- PDF rules
- anti-cheat rules
- verification commands

## Maintenance Rule

Whenever a bug is discovered that could reasonably happen again, add a short rule to:
- `02_ENGINEERING_RULES.md` if it is an invariant
- `13_COMMON_AGENT_MISTAKES.md` if it is an agent failure pattern
- the relevant specialized file if it is domain-specific

Do not let important project knowledge remain only inside chat history.

## Important Documentation Discipline

Documentation must describe the actual repository.

If code and documentation disagree:
1. inspect the implementation
2. identify which behavior is intentional
3. update documentation after resolving the discrepancy

Never invent a feature merely because it appears in documentation.
