import React, { useState, useEffect } from 'react';
import {
  FileText, Users, Download, Upload, Search, CheckCircle, RefreshCw,
  Award, TrendingUp, AlertTriangle, Printer, ArrowLeft, Eye, ShieldCheck,
  BarChart2, BarChart3, FileSpreadsheet, Building, Settings, LogOut, BookOpen, Clock, Package, Trash2
} from 'lucide-react';
import Swal from 'sweetalert2';
import {
  listExams, getExamDetails, getExamResults, importExamResults,
  downloadAllStudentPDFBlob, downloadStudentPDFBlob,
  exportExamBundle, importExamBundles, deleteExam
} from '../services/api';
import SystemSettingsModal, { getSystemVaultKey } from './SystemSettingsModal';
import ExamResults from './ExamResults';
import FileDropZone from './FileDropZone';

export default function AdminDashboard({ onLogout }) {
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedExam, setSelectedExam] = useState(null);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isResultsModalOpen, setIsResultsModalOpen] = useState(false);
  const [isBundleModalOpen, setIsBundleModalOpen] = useState(false);
  const [targetExamId, setTargetExamId] = useState(null);
  const [resultsFiles, setResultsFiles] = useState([]);
  const [bundleFiles, setBundleFiles] = useState([]);
  const [importingResults, setImportingResults] = useState(false);
  const [importingBundle, setImportingBundle] = useState(false);

  const loadExams = async () => {
    try {
      setLoading(true);
      const data = await listExams();
      setExams(data);
    } catch (err) {
      console.error('Failed to load exams for admin:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExams();
  }, []);

  // Export Encrypted Submission Bundle (.algobundle)
  const handleExportBundle = async (examId, title) => {
    try {
      const vaultKey = getSystemVaultKey();
      const res = await exportExamBundle(examId, vaultKey);
      const blob = new Blob([JSON.stringify(res, null, 2)], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Paquet_Soumissions_${(title || 'Examen').replace(/[^\w]/g, '_')}.algobundle`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      Swal.fire({
        icon: 'success',
        title: 'Paquet Téléchargé !',
        text: 'Le fichier chiffré .algobundle a été téléchargé avec succès.',
        timer: 1800,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export bundle error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Téléchargement',
        text: 'Impossible d\'exporter le paquet chiffré.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Import and Fuse Submission Bundles (.algobundle) into an Exam
  const handleImportBundles = async (examId, title) => {
    setTargetExamId(examId);
    setBundleFiles([]);
    setIsBundleModalOpen(true);
  };

  const handleProcessImportBundle = async () => {
    if (!bundleFiles || bundleFiles.length === 0 || !targetExamId) return;
    setImportingBundle(true);

    try {
      const vaultKey = getSystemVaultKey();
      const formData = new FormData();
      for (const file of bundleFiles) {
        formData.append('bundles', file);
      }
      if (vaultKey) formData.append('passphrase', vaultKey);

      const res = await importExamBundles(targetExamId, formData);
      setIsBundleModalOpen(false);
      setBundleFiles([]);

      Swal.fire({
        icon: 'success',
        title: 'Fusion Réussie !',
        html: `
          <div style="text-align: left; font-size: 0.9rem; color: #cbd5e1;">
            <p>${res.message}</p>
            <ul style="margin-top: 8px; padding-left: 20px; color: #93c5fd;">
              <li>Nouveaux étudiants importés : <strong>${res.totalStudentsImported}</strong></li>
              <li>Nouvelles soumissions : <strong>${res.totalSubmissionsImported}</strong></li>
              <li>Soumissions mises à jour : <strong>${res.totalSubmissionsUpdated}</strong></li>
            </ul>
          </div>
        `,
        background: '#111827',
        color: '#fff'
      });
      loadExams();
    } catch (err) {
      console.error('Import bundles error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Fusion',
        text: err.data?.error || err.message || 'Impossible de fusionner ces paquets.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setImportingBundle(false);
    }
  };

  // Open Drag & Drop Modal for importing results
  const handleImportResultsForExam = (examId) => {
    setTargetExamId(examId);
    setResultsFiles([]);
    setIsResultsModalOpen(true);
  };

  const handleProcessImportResults = async () => {
    if (!resultsFiles || resultsFiles.length === 0) return;
    setImportingResults(true);

    try {
      const vaultKey = getSystemVaultKey();
      const formData = new FormData();
      for (const file of resultsFiles) {
        formData.append('results', file);
      }
      if (vaultKey) formData.append('passphrase', vaultKey);

      const res = await importExamResults(targetExamId || null, formData);
      setIsResultsModalOpen(false);
      setResultsFiles([]);
      setTargetExamId(null);

      Swal.fire({
        icon: 'success',
        title: 'Résultats Importés !',
        text: res.message || `${resultsFiles.length} fichier(s) de résultats synchronisé(s) avec succès.`,
        background: '#111827',
        color: '#fff'
      });
      loadExams();
    } catch (err) {
      console.error('Import results error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Importation',
        text: err.data?.error || err.message || 'Impossible d\'importer ces fichiers de résultats.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setImportingResults(false);
    }
  };

  // Download All Copies PDF with Recourse Section
  const handleDownloadAllPDF = async (exam) => {
    try {
      Swal.fire({
        title: 'Génération du Recueil des Copies PDF...',
        html: '<div style="color: #94a3b8; font-size: 0.88rem;">Compilation des copies corrigées avec section recours officielle en en-tête.</div>',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading(),
        background: '#111827',
        color: '#fff'
      });

      const blob = await downloadAllStudentPDFBlob(exam.id);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Recueil_Copies_${(exam?.title || 'Examen').replace(/[^\w]/g, '_')}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => window.URL.revokeObjectURL(url), 1000);
      Swal.close();
    } catch (err) {
      console.error('PDF error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur PDF',
        text: 'Impossible de générer le recueil des copies.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const handleDeleteExam = async (examId, title) => {
    const result = await Swal.fire({
      title: 'Supprimer cet examen ?',
      html: `Êtes-vous sûr de vouloir supprimer définitivement <strong>"${title}"</strong> ?<br/><small style="color: #ef4444;">Cette action supprimera également toutes les assignations et copies associées.</small>`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Oui, supprimer',
      cancelButtonText: 'Annuler',
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#64748b',
      background: '#111827',
      color: '#fff'
    });

    if (!result.isConfirmed) return;

    try {
      await deleteExam(examId);
      Swal.fire({
        icon: 'success',
        title: 'Examen Supprimé',
        text: 'L\'examen a été supprimé avec succès.',
        timer: 1500,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
      loadExams();
    } catch (err) {
      console.error('Delete exam error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur',
        text: err.data?.error || err.message || 'Impossible de supprimer cet examen.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const filteredExams = exams.filter(e => {
    const matchSearch =
      !search.trim() ||
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      (e.module && e.module.toLowerCase().includes(search.toLowerCase())) ||
      (e.examCode && e.examCode.toLowerCase().includes(search.toLowerCase()));

    if (!matchSearch) return false;

    if (filterStatus === 'FINISHED') {
      return e.status === 'FINISHED' || e.status === 'CLOSED';
    }
    if (filterStatus === 'RUNNING') {
      return e.status === 'RUNNING' || e.status === 'WAITING' || e.status === 'PAUSED';
    }
    return true;
  });

  return (
    <div style={{ padding: '28px', maxWidth: '1380px', margin: '0 auto' }}>
      {/* ═══════════════════════════════════════════════════════════
          VARIANTE 3 : LINE 1 (TOP IDENTITY & GLOBAL SYSTEM TOOLS)
      ═══════════════════════════════════════════════════════════ */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '22px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ fontSize: '1.6rem' }}>🏛️</span>
            <h1 style={{ fontSize: '1.65rem', fontWeight: '800', margin: 0, color: '#f8fafc', letterSpacing: '-0.5px' }}>
              Espace Administration & Scolarité
            </h1>
            <span className="badge badge-yellow" style={{ fontSize: '0.72rem', padding: '3px 8px' }}>ADMINISTRATION</span>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.86rem', margin: '4px 0 0 0' }}>
            Relevés de notes officiels, statistiques complètes, dé-anonymisation et recueil des copies d'examen.
          </p>
        </div>

        {/* Global system actions */}
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' }}>
          <button
            className="btn btn-secondary"
            onClick={() => {
              setTargetExamId(null);
              setResultsFiles([]);
              setIsResultsModalOpen(true);
            }}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              padding: '8px 11px', fontSize: '0.85rem',
              color: '#fbbf24', borderColor: 'rgba(245, 158, 11, 0.4)',
              background: 'rgba(245, 158, 11, 0.08)'
            }}
            title="Importer les Résultats & Notes Corrigées (.algoresults)"
          >
            <FileSpreadsheet size={16} />
          </button>
          <button className="btn btn-secondary" onClick={loadExams} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <RefreshCw size={14} /> Actualiser
          </button>
          <button className="btn btn-secondary" onClick={() => setIsSettingsOpen(true)} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <Settings size={14} /> Paramètres
          </button>
          {onLogout && (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onLogout}
              style={{ color: '#f87171', borderColor: 'rgba(239, 68, 68, 0.3)', display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 12px', fontSize: '0.84rem' }}
            >
              <LogOut size={14} /> Déconnexion
            </button>
          )}
        </div>
      </div>

      {/* System Settings Modal */}
      <SystemSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* ── Main Administration Content ── */}
      <div>
        {selectedExam ? (
          /* ── Level 2: Full Exam Results & De-anonymized View with all Statistics ── */
          <div>
            <div style={{ marginBottom: '16px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => {
                  setSelectedExam(null);
                  loadExams();
                }}
                style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem' }}
              >
                <ArrowLeft size={16} /> Retour à la Liste des Examens
              </button>
            </div>

            <ExamResults
              examId={selectedExam.id}
              examTitle={selectedExam.title}
              onBack={() => {
                setSelectedExam(null);
                loadExams();
              }}
            />
          </div>
        ) : (
          /* ── Level 1: Exam List View for Administration ── */
          <div>
            {/* ═══════════════════════════════════════════════════════════
                VARIANTE 3 : LINE 2 (LINEAR / GITHUB TABBED COMMAND BAR)
            ═══════════════════════════════════════════════════════════ */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
              marginBottom: '24px',
              paddingBottom: '0px',
              flexWrap: 'wrap',
              gap: '14px'
            }}>
              {/* Left: Underlined Clean Tabs */}
              <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                <button
                  onClick={() => setFilterStatus('ALL')}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    borderBottom: filterStatus === 'ALL' ? '2px solid #f59e0b' : '2px solid transparent',
                    color: filterStatus === 'ALL' ? '#fbbf24' : 'var(--text-muted)',
                    padding: '12px 18px',
                    fontWeight: '700',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '0.92rem',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <BarChart2 size={16} /> 📊 Tous les Examens
                  <span style={{
                    fontSize: '0.75rem',
                    padding: '2px 7px',
                    borderRadius: '12px',
                    background: filterStatus === 'ALL' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(255,255,255,0.06)',
                    color: filterStatus === 'ALL' ? '#fbbf24' : 'var(--text-muted)'
                  }}>
                    {exams.length}
                  </span>
                </button>

                <button
                  onClick={() => setFilterStatus('FINISHED')}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    borderBottom: filterStatus === 'FINISHED' ? '2px solid #34d399' : '2px solid transparent',
                    color: filterStatus === 'FINISHED' ? '#34d399' : 'var(--text-muted)',
                    padding: '12px 18px',
                    fontWeight: '700',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '0.92rem',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <CheckCircle size={16} /> ✅ Terminés & Résultats Prêts
                  <span style={{
                    fontSize: '0.75rem',
                    padding: '2px 7px',
                    borderRadius: '12px',
                    background: filterStatus === 'FINISHED' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.06)',
                    color: filterStatus === 'FINISHED' ? '#34d399' : 'var(--text-muted)'
                  }}>
                    {exams.filter(e => e.status === 'FINISHED' || e.status === 'CLOSED').length}
                  </span>
                </button>

                <button
                  onClick={() => setFilterStatus('RUNNING')}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    borderBottom: filterStatus === 'RUNNING' ? '2px solid #60a5fa' : '2px solid transparent',
                    color: filterStatus === 'RUNNING' ? '#60a5fa' : 'var(--text-muted)',
                    padding: '12px 18px',
                    fontWeight: '700',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '0.92rem',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <Clock size={16} /> ⏳ En Cours / En Attente
                  <span style={{
                    fontSize: '0.75rem',
                    padding: '2px 7px',
                    borderRadius: '12px',
                    background: filterStatus === 'RUNNING' ? 'rgba(59, 130, 246, 0.2)' : 'rgba(255,255,255,0.06)',
                    color: filterStatus === 'RUNNING' ? '#60a5fa' : 'var(--text-muted)'
                  }}>
                    {exams.filter(e => e.status === 'RUNNING' || e.status === 'WAITING' || e.status === 'PAUSED').length}
                  </span>
                </button>
              </div>

              {/* Right: Search Box */}
              <div style={{ position: 'relative', width: '320px', paddingBottom: '8px' }}>
                <Search size={15} style={{ position: 'absolute', left: '12px', top: '45%', transform: 'translateY(-50%)', color: '#64748b' }} />
                <input
                  type="text"
                  className="form-input"
                  placeholder="Filtrer les épreuves..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  style={{ paddingLeft: '36px', paddingRight: '12px', paddingBottom: '6px', paddingTop: '6px', fontSize: '0.84rem' }}
                />
              </div>
            </div>

            {/* Exam Cards Grid */}
            {loading ? (
              <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
                <RefreshCw size={24} className="spin" style={{ marginBottom: '10px' }} />
                <div>Chargement des examens pour l'administration...</div>
              </div>
            ) : filteredExams.length === 0 ? (
              <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
                Aucun examen trouvé.
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))', gap: '20px' }}>
                {filteredExams.map(exam => {
                  const isFinished = exam.status === 'FINISHED' || exam.status === 'CLOSED';
                  const isRunning = exam.status === 'RUNNING';

                  return (
                    <div
                      key={exam.id}
                      className="glass-panel"
                      style={{
                        padding: '24px',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        border: isFinished ? '1px solid rgba(245, 158, 11, 0.35)' : '1px solid var(--panel-border)'
                      }}
                    >
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                          <span className={`badge ${isFinished ? 'badge-blue' : isRunning ? 'badge-green' : 'badge-yellow'}`}>
                            {exam.status}
                          </span>
                          <span style={{ fontSize: '0.8rem', color: '#a78bfa', fontWeight: '800' }}>
                            {exam.examCode || 'ALGO2026'}
                          </span>
                        </div>

                        <h3 style={{ fontSize: '1.2rem', fontWeight: '800', color: '#f8fafc', margin: '0 0 10px 0' }}>
                          {exam.title}
                        </h3>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '0.82rem', color: '#cbd5e1', marginBottom: '18px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <BookOpen size={14} color="#60a5fa" />
                            <span>Module : <strong>{exam.module || 'ASD'}</strong></span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <Clock size={14} color="#34d399" />
                            <span>Durée : <strong>{exam.durationMinutes} min</strong></span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <Users size={14} color="#a78bfa" />
                            <span>Inscrits : <strong>{exam._count?.assignments || 0} étudiants</strong></span>
                          </div>
                        </div>
                      </div>

                      {/* Admin Card Action Buttons */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingTop: '14px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                        <button
                          type="button"
                          className="btn btn-primary"
                          onClick={() => setSelectedExam(exam)}
                          style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', fontWeight: '800', fontSize: '0.88rem', background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)' }}
                        >
                          <Eye size={16} /> 👁️ Voir Résultats & Statistiques
                        </button>

                        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                          <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={() => handleImportResultsForExam(exam.id)}
                            style={{ flex: 1, minWidth: '130px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', padding: '6px 10px', fontSize: '0.78rem', color: '#fbbf24', borderColor: 'rgba(245,158,11,0.3)' }}
                            title="Importer ou synchroniser un paquet corrigé .algoresults pour cet examen"
                          >
                            <Upload size={13} /> 📥 Synchroniser .algoresults
                          </button>

                          <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={() => handleDownloadAllPDF(exam)}
                            style={{ padding: '6px 12px', fontSize: '0.78rem', display: 'flex', alignItems: 'center', gap: '4px' }}
                            title="Télécharger toutes les copies PDF (avec section recours)"
                          >
                            <Printer size={13} /> PDF
                          </button>

                          <button
                            type="button"
                            className="btn btn-danger"
                            onClick={() => handleDeleteExam(exam.id, exam.title)}
                            style={{ padding: '6px 10px', fontSize: '0.78rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                            title="Supprimer définitivement cet examen"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── DRAG & DROP MODAL: IMPORT / FUSE COPIES (.algobundle) ── */}
      {isBundleModalOpen && (
        <div className="fullscreen-overlay" style={{ background: 'rgba(0,0,0,0.8)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '100%', maxWidth: '540px', padding: '30px' }}>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '1.25rem', fontWeight: '800', color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Package size={20} /> Importer / Fusionner des Paquets de Copies (.algobundle)
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '18px' }}>
              Glissez & déposez un ou plusieurs fichiers <code>.algobundle</code> provenant des surveillants de salle pour fusionner les copies.
            </p>

            <FileDropZone
              accept=".algobundle,.json"
              multiple={true}
              selectedFiles={bundleFiles}
              onFileSelect={(files) => setBundleFiles(Array.isArray(files) ? files : [files])}
              onClear={() => setBundleFiles([])}
              label="Glissez & déposez les fichiers .algobundle ici"
              hint="ou cliquez pour sélectionner plusieurs fichiers"
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => { setIsBundleModalOpen(false); setBundleFiles([]); }}
                disabled={importingBundle}
              >
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleProcessImportBundle}
                disabled={bundleFiles.length === 0 || importingBundle}
                style={{ background: 'linear-gradient(135deg, #3b82f6, #2563eb)' }}
              >
                {importingBundle ? 'Fusion en cours...' : `Déchiffrer & Fusionner (${bundleFiles.length} fichier(s))`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── DRAG & DROP MODAL: IMPORT / FUSE RESULTS (.algoresults) ── */}
      {isResultsModalOpen && (
        <div className="fullscreen-overlay" style={{ background: 'rgba(0,0,0,0.8)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '100%', maxWidth: '540px', padding: '30px' }}>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '1.25rem', fontWeight: '800', color: '#f59e0b', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Upload size={20} /> Importer / Fusionner les Résultats (.algoresults)
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '18px' }}>
              Glissez & déposez un ou plusieurs fichiers <code>.algoresults</code> (provenant de différents enseignants ou jurys) pour agréger les résultats.
            </p>

            <FileDropZone
              accept=".algoresults,.json"
              multiple={true}
              selectedFiles={resultsFiles}
              onFileSelect={(files) => setResultsFiles(Array.isArray(files) ? files : [files])}
              onClear={() => setResultsFiles([])}
              label="Glissez & déposez les fichiers .algoresults ici"
              hint="ou cliquez pour sélectionner plusieurs fichiers"
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => { setIsResultsModalOpen(false); setResultsFiles([]); }}
                disabled={importingResults}
              >
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleProcessImportResults}
                disabled={resultsFiles.length === 0 || importingResults}
                style={{ background: 'linear-gradient(135deg, #f59e0b, #d97706)' }}
              >
                {importingResults ? 'Fusion en cours...' : `Déchiffrer & Fusionner (${resultsFiles.length} fichier(s))`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
