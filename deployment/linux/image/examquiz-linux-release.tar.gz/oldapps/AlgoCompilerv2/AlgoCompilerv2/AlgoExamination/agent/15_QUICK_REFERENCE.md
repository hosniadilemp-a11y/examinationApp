# AlgoExamination — Quick Reference Card

## Critical Paths

```text
Exam authoring:
ExamManager.jsx
→ exam.controller.js
→ Prisma Exam / ExamProblem / ExamAssignment

Student:
StudentLogin
→ WaitingRoom
→ ExamWorkspace
→ student.controller.js

Monitoring:
ExamWorkspace
→ violation handling
→ exam.socket.js
→ TeacherDashboard

Grading:
CorrectionWorkspace
→ grading.controller.js
→ Prisma
→ pdf.service.js

Execution:
ExamWorkspace
→ code-execution.service.js
→ isolated child process
```

## Critical Rooms

```text
exam_${examId}
student_${studentId}
```

## Critical Events

```text
exam_status_changed
exam_started
exam_force_ended
student_status_changed
live_monitoring_event
pdf_zip_progress
student_locked
student_unlocked
student_terminated
student_fullscreen_warning
```

## Critical Versions

```text
Node.js: 20
archiver: 5.3.2
```

## Critical Commands

```bash
cd client && /home/adel/.cache/ms-playwright-go/1.57.0/node ./node_modules/vite/bin/vite.js build

cd server && PATH=/home/adel/.local/node-v20/bin:$PATH node -e "require('./src/controllers/exam.controller.js'); require('./src/controllers/grading.controller.js'); console.log('Syntax OK');"

cd server && PATH=/home/adel/.local/node-v20/bin:$PATH npx prisma validate
```

## Never Forget

```text
Date/time → parse safely
Socket status → target + teacher broadcast
Points → preserve existing values
PDF → white/black
archiver → 5.3.2 CommonJS
Critical state → server authoritative
Sockets → keep reliability fallback
Code execution → isolate untrusted code
Verification → actually run it
```
