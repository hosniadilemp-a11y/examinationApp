import React, { useState, useRef } from 'react';
import { 
  ArrowLeft, ArrowRight, Save, Play, Plus, Trash2, Download, Upload, 
  FileText, Code, CheckCircle, XCircle, Eye, EyeOff, Layers, Sparkles,
  Bold, Italic, Heading, Code2, List, FileCheck, Terminal,
  Search, Strikethrough, Table, Quote, Minus, BookOpen, Sliders, ChevronDown, ChevronUp, ChevronRight, ChevronLeft, Pencil,
  Tag, MoveUp, MoveDown, HelpCircle
} from 'lucide-react';
import Swal from 'sweetalert2';
import CodeMirror from '@uiw/react-codemirror';
import { search } from '@codemirror/search';
import { createProblem, updateProblem, runSampleCode } from '../services/api';
import { algoExtension } from '../utils/algo-language';
import { ALGO_CHAPTERS, COMPREHENSIVE_CODE_BRICKS, MARKDOWN_TEMPLATES } from '../utils/algo-constants';
import { formatAlgoCode } from '../utils/algo-formatter';
import { renderMarkdownHTML, formatOutputText } from '../utils/markdown';

export { ALGO_CHAPTERS, COMPREHENSIVE_CODE_BRICKS, MARKDOWN_TEMPLATES };

export function validateQuestionMarkersClient(codeStr, questionCount) {
  if (!codeStr || typeof codeStr !== 'string') return { valid: true };

  const startRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:starts|commence|d[ée]bute?)\s*(?:here|ici)?|(?:d[ée]but)\s+question\s+(\d+))\s*$/gim;
  const endRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:ends|se\s+termine|termine|fin)\s*(?:here|ici)?|(?:fin)\s+question\s+(\d+))\s*$/gim;

  const starts = [];
  const ends = [];

  let match;
  while ((match = startRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    starts.push({ qNum, index: match.index });
  }
  while ((match = endRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    ends.push({ qNum, index: match.index });
  }

  if (starts.length === 0 && ends.length === 0) {
    return { valid: true };
  }

  const startMap = {};
  for (const s of starts) {
    if (s.qNum < 1 || s.qNum > questionCount) {
      return { valid: false, error: `Le marqueur "// question ${s.qNum} commence ici" fait référence à une question inexistante (max: ${questionCount}).` };
    }
    if (startMap[s.qNum]) {
      return { valid: false, error: `Marqueur de début dupliqué pour la question ${s.qNum}.` };
    }
    startMap[s.qNum] = s;
  }

  const endMap = {};
  for (const e of ends) {
    if (e.qNum < 1 || e.qNum > questionCount) {
      return { valid: false, error: `Le marqueur "// question ${e.qNum} se termine ici" fait référence à une question inexistante (max: ${questionCount}).` };
    }
    if (endMap[e.qNum]) {
      return { valid: false, error: `Marqueur de fin dupliqué pour la question ${e.qNum}.` };
    }
    endMap[e.qNum] = e;
  }

  for (const qNum of Object.keys(startMap)) {
    if (!endMap[qNum]) {
      return { valid: false, error: `Marqueur de fin manquant pour la question ${qNum} (attendu: // question ${qNum} ends here).` };
    }
    if (startMap[qNum].index >= endMap[qNum].index) {
      return { valid: false, error: `Le marqueur "// question ${qNum} ends here" apparaît avant le marqueur starts here.` };
    }
  }

  for (const qNum of Object.keys(endMap)) {
    if (!startMap[qNum]) {
      return { valid: false, error: `Marqueur de début manquant pour la question ${qNum} (attendu: // question ${qNum} starts here).` };
    }
  }

  return { valid: true };
}

const DEFAULT_TEMPLATE = `ALGORITHME Exercice_Nouveau
VAR
   // Déclarez vos variables ici (ex: i, n : ENTIER;)
DEBUT
   // Saisissez votre code algorithmique
FIN.`;

const DEFAULT_SOLUTION = `ALGORITHME Exercice_Nouveau
VAR
   a, b, s : ENTIER;
DEBUT
   LIRE(a);
   LIRE(b);
   s := a + b;
   ECRIRE(s);
FIN.`;

export default function ProblemStudio({ initialProblem = null, onBack, onClose, onSaveSuccess }) {
  const handleBack = onBack || onClose;
  const [title, setTitle] = useState(initialProblem?.title || '');
  const [description, setDescription] = useState(initialProblem?.description || '');
  const [difficulty, setDifficulty] = useState(initialProblem?.difficulty || 'MOYEN');

  // Sub-questions state (supports 1 or N questions per problem)
  const [questions, setQuestions] = useState(() => {
    if (Array.isArray(initialProblem?.questions) && initialProblem.questions.length > 0) {
      return initialProblem.questions.map((q, idx) => ({
        id: q.id || `q_${Date.now()}_${idx}`,
        orderIndex: q.orderIndex || (idx + 1),
        statement: q.statement || ''
      }));
    }
    return [
      { id: `q_${Date.now()}_1`, orderIndex: 1, statement: initialProblem?.description || '' }
    ];
  });

  // Collapsible Steps State for Studio
  const [collapsedSteps, setCollapsedSteps] = useState({
    step1: false,
    step2: false,
    step3: false,
    step4: false
  });

  const toggleStep = (stepKey) => {
    setCollapsedSteps(prev => ({ ...prev, [stepKey]: !prev[stepKey] }));
  };

  const toggleAllSteps = (collapse) => {
    setCollapsedSteps({
      step1: collapse,
      step2: collapse,
      step3: collapse,
      step4: collapse
    });
  };

  // Validation Errors State for Red Border Highlighting
  const [validationErrors, setValidationErrors] = useState({
    title: false,
    description: false,
    chapters: false
  });

  // Ref for description textarea to support text selection formatting
  const descriptionRef = useRef(null);

  // Selected Chapter Tags from AlgoCompiler
  const [selectedChapters, setSelectedChapters] = useState(() => {
    if (initialProblem?.chapterId) {
      const match = ALGO_CHAPTERS.find(ch => ch.id === initialProblem.chapterId);
      if (match) return [match.title];
    }
    if (Array.isArray(initialProblem?.tags) && initialProblem.tags.length > 0) {
      return initialProblem.tags;
    }
    if (typeof initialProblem?.tags === 'string' && initialProblem.tags.trim()) {
      return initialProblem.tags.split(',').map(t => t.trim()).filter(Boolean);
    }
    if (typeof initialProblem?.topic === 'string' && initialProblem.topic.trim()) {
      return initialProblem.topic.split(',').map(t => t.trim()).filter(Boolean);
    }
    return [ALGO_CHAPTERS[0].title];
  });

  // Code Tab state inside the code editor block: 'STARTER' | 'SOLUTION'
  const [codeEditorTab, setCodeEditorTab] = useState('STARTER');

  const getInitialStarterCode = () => {
    if (typeof initialProblem?.starterTemplate === 'string' && initialProblem.starterTemplate.trim()) {
      return initialProblem.starterTemplate;
    }
    if (typeof initialProblem?.templateCode === 'string' && initialProblem.templateCode.trim()) {
      return initialProblem.templateCode;
    }
    if (initialProblem?.templateCode && typeof initialProblem.templateCode === 'object') {
      return initialProblem.templateCode.ALGO || initialProblem.templateCode.algo || DEFAULT_TEMPLATE;
    }
    return DEFAULT_TEMPLATE;
  };

  const [templateCode, setTemplateCode] = useState(getInitialStarterCode);
  const [referenceSolution, setReferenceSolution] = useState(initialProblem?.referenceSolution || DEFAULT_SOLUTION);

  // Editor Font Size State
  const [fontSize, setFontSize] = useState(15);

  // CodeMirror View References for Cursor-Position Insertion & Editor Actions
  const starterViewRef = useRef(null);
  const solutionViewRef = useRef(null);

  // Active View helper
  const getActiveView = () => (codeEditorTab === 'SOLUTION' ? solutionViewRef.current : starterViewRef.current);

  // Selected Bricks Chapter & Search for Toolbar
  const [selectedBrickChapter, setSelectedBrickChapter] = useState(() => {
    if (initialProblem?.chapterId) return initialProblem.chapterId;
    if (initialProblem?.tags && Array.isArray(initialProblem.tags)) {
      const found = ALGO_CHAPTERS.find(ch => initialProblem.tags.includes(ch.title) || initialProblem.tags.includes(ch.id));
      if (found) return found.id;
    }
    return 'CH1';
  });
  const [brickSearchQuery, setBrickSearchQuery] = useState('');

  // Quick Sandbox Test Runner State (Step 3)
  const [sandboxInput, setSandboxInput] = useState('5\n10 20 30 40 50');
  const [sandboxOutput, setSandboxOutput] = useState(null);
  const [isRunningSandbox, setIsRunningSandbox] = useState(false);

  // Test suite cases (Step 4)
  const [testCases, setTestCases] = useState(() => {
    if (Array.isArray(initialProblem?.testCases) && initialProblem.testCases.length > 0) {
      return initialProblem.testCases.map(tc => ({
        id: tc.id,
        input: tc.input !== undefined ? tc.input : (tc.inputData !== undefined ? tc.inputData : ''),
        expectedOutput: tc.expectedOutput !== undefined ? tc.expectedOutput : '',
        weight: tc.weight !== undefined ? tc.weight : 1,
        isHidden: tc.isHidden !== undefined ? tc.isHidden : (tc.isPublic !== undefined ? !tc.isPublic : false)
      }));
    }
    return [
      { input: '5\n10', expectedOutput: '15', weight: 1, isHidden: false },
      { input: '0\n7', expectedOutput: '7', weight: 1, isHidden: true }
    ];
  });

  const [isTestingSolution, setIsTestingSolution] = useState(false);
  const [testResults, setTestResults] = useState([]);
  const [isSaving, setIsSaving] = useState(false);

  const fileInputRef = useRef(null);

  // Toggle chapter selection
  const handleToggleChapter = (chapterTitle) => {
    let updated;
    if (selectedChapters.includes(chapterTitle)) {
      if (selectedChapters.length === 1) return;
      updated = selectedChapters.filter(c => c !== chapterTitle);
    } else {
      updated = [...selectedChapters, chapterTitle];
    }
    setSelectedChapters(updated);
    if (updated.length > 0) {
      setValidationErrors(prev => ({ ...prev, chapters: false }));
    }
  };

  // Markdown Selection Helper
  const handleInsertMarkdownSyntax = (prefix, suffix = '', defaultText = 'Texte') => {
    const textarea = descriptionRef.current;
    if (!textarea) {
      setDescription(prev => prev + '\n' + prefix + defaultText + (suffix || prefix));
      return;
    }

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentVal = description;

    if (start !== undefined && end !== undefined && start !== end) {
      const selectedText = currentVal.substring(start, end);
      const closeTag = suffix || prefix;
      const updated = currentVal.substring(0, start) + prefix + selectedText + closeTag + currentVal.substring(end);
      setDescription(updated);

      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + prefix.length, end + prefix.length);
      }, 0);
    } else {
      const closeTag = suffix || prefix;
      const inserted = `${prefix}${defaultText}${closeTag}`;
      const updated = currentVal.substring(0, start) + inserted + currentVal.substring(end);
      setDescription(updated);

      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + prefix.length, start + prefix.length + defaultText.length);
      }, 0);
    }
    setValidationErrors(prev => ({ ...prev, description: false }));
  };



  const handleAddTestCase = () => {
    setTestCases([
      ...testCases,
      { input: '', expectedOutput: '', weight: 1, isHidden: false }
    ]);
  };

  const handleRemoveTestCase = (index) => {
    setTestCases(testCases.filter((_, idx) => idx !== index));
  };

  const handleUpdateTestCase = (index, field, value) => {
    const updated = [...testCases];
    updated[index] = { ...updated[index], [field]: value };
    setTestCases(updated);
  };

  const handleInsertBrickAtCursor = (snippet) => {
    const view = getActiveView();
    if (view) {
      const mainSelection = view.state.selection.main;
      view.dispatch({
        changes: { from: mainSelection.from, to: mainSelection.to, insert: snippet },
        selection: { anchor: mainSelection.from + snippet.length }
      });
      view.focus();
    } else {
      if (codeEditorTab === 'SOLUTION') {
        setReferenceSolution(prev => prev + '\n' + snippet);
      } else {
        setTemplateCode(prev => prev + '\n' + snippet);
      }
    }

    Swal.fire({
      icon: 'success',
      title: 'Brique Insérée !',
      text: 'Le code a été inséré à la position exacte de votre curseur.',
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1400,
      background: '#0f172a',
      color: '#fff'
    });
  };

  // Accurate AlgoCompiler Code Formatting
  const handleFormatCode = () => {
    const view = getActiveView();
    const currentCode = codeEditorTab === 'SOLUTION' ? referenceSolution : templateCode;
    if (!currentCode) return;

    const formatted = formatAlgoCode(currentCode);

    if (codeEditorTab === 'SOLUTION') setReferenceSolution(formatted);
    else setTemplateCode(formatted);

    if (view) {
      view.dispatch({
        changes: { from: 0, to: view.state.doc.length, insert: formatted }
      });
    }

    Swal.fire({
      icon: 'success', title: 'Code Reformaté selon la Syntaxe AlgoCompiler !', toast: true, position: 'top-end',
      showConfirmButton: false, timer: 1200, background: '#0f172a', color: '#fff'
    });
  };

  const handleToggleComment = (uncommentOnly = false) => {
    const view = getActiveView();
    if (!view) return;

    const { state } = view;
    const selection = state.selection.main;
    const startLine = state.doc.lineAt(selection.from);
    const endLine = state.doc.lineAt(selection.to);
    
    let lines = [];
    for (let l = startLine.number; l <= endLine.number; l++) {
      lines.push(state.doc.line(l));
    }

    const allCommented = lines.every(line => line.text.trim() === '' || /^\s*\/\//.test(line.text));
    const shouldUncomment = uncommentOnly || allCommented;

    const changes = [];
    lines.forEach(line => {
      const text = line.text;
      if (shouldUncomment) {
        const match = text.match(/^(\s*)\/\/\s?/);
        if (match) {
          const startPos = line.from + match[1].length;
          const len = match[0].length - match[1].length;
          changes.push({ from: startPos, to: startPos + len, insert: '' });
        }
      } else {
        if (text.trim() !== '') {
          const indentMatch = text.match(/^(\s*)/);
          const insertPos = line.from + (indentMatch ? indentMatch[1].length : 0);
          changes.push({ from: insertPos, insert: '// ' });
        }
      }
    });

    if (changes.length > 0) {
      view.dispatch({ changes });
      const updated = view.state.doc.toString();
      if (codeEditorTab === 'SOLUTION') setReferenceSolution(updated);
      else setTemplateCode(updated);
    }
  };

  const handleRunSandbox = async () => {
    const codeToRun = codeEditorTab === 'SOLUTION' ? referenceSolution : templateCode;
    if (!codeToRun.trim()) {
      Swal.fire({ icon: 'warning', title: 'Code vide', text: 'Veuillez saisir du code avant de tester.', background: '#111827', color: '#fff' });
      return;
    }

    setIsRunningSandbox(true);
    setSandboxOutput(null);
    try {
      const res = await runSampleCode(codeToRun, 'ALGO', sandboxInput);
      setSandboxOutput({
        output: res.output || res.stdout || '(Aucune sortie STDOUT)',
        error: res.error || res.stderr || null,
        executionTimeMs: res.executionMs || res.executionTimeMs || 0
      });
    } catch (err) {
      setSandboxOutput({
        output: '',
        error: err.data?.error || err.message,
        executionTimeMs: 0
      });
    } finally {
      setIsRunningSandbox(false);
    }
  };

  const handleRunSingleTestCase = async (idx) => {
    const tc = testCases[idx];
    if (!referenceSolution.trim()) {
      Swal.fire({ icon: 'warning', title: 'Solution vide', text: 'Veuillez rédiger une solution de référence avant de tester.', background: '#111827', color: '#fff' });
      return;
    }

    try {
      const res = await runSampleCode(referenceSolution, 'ALGO', tc.input || '');
      const output = (res.output || res.stdout || '').trim();
      const expected = (tc.expectedOutput || '').trim();
      const passed = output === expected;

      Swal.fire({
        icon: passed ? 'success' : 'error',
        title: `Cas de Test #${idx + 1} ${passed ? 'VALIDÉ' : 'ÉCHOUÉ'}`,
        html: `
          <div style="text-align: left; font-family: monospace; font-size: 0.85rem; line-height: 1.6;">
            <div><strong>Entrée:</strong> ${tc.input || '(Vide)'}</div>
            <div><strong>Attendu:</strong> ${expected || '(Vide)'}</div>
            <div><strong>Obtenu:</strong> ${output || res.error || res.stderr || '(Vide)'}</div>
          </div>
        `,
        background: '#111827', color: '#fff'
      });
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Erreur d’exécution', text: err.data?.error || err.message, background: '#111827', color: '#fff' });
    }
  };

  const handleTestReferenceSolution = async () => {
    if (!referenceSolution.trim()) {
      Swal.fire({ icon: 'warning', title: 'Solution vide', text: 'Veuillez rédiger une solution de référence avant de tester.', background: '#111827', color: '#fff' });
      return;
    }
    if (testCases.length === 0) {
      Swal.fire({ icon: 'warning', title: 'Aucun test', text: 'Aucun cas de test n\'est présent.', background: '#111827', color: '#fff' });
      return;
    }

    setIsTestingSolution(true);
    setTestResults([]);
    const results = [];

    try {
      for (let i = 0; i < testCases.length; i++) {
        const tc = testCases[i];
        try {
          const res = await runSampleCode(referenceSolution, 'ALGO', tc.input || '');
          const output = (res.output || res.stdout || '').trim();
          const expected = (tc.expectedOutput || '').trim();
          const passed = output === expected;
          results.push({
            testIndex: i + 1,
            passed,
            input: tc.input,
            expected,
            actual: output,
            error: res.error || res.stderr || null
          });
        } catch (err) {
          results.push({
            testIndex: i + 1,
            passed: false,
            input: tc.input,
            expected: tc.expectedOutput,
            actual: '',
            error: err.data?.error || err.message
          });
        }
      }
      setTestResults(results);
      const passedCount = results.filter(r => r.passed).length;
      if (passedCount === testCases.length) {
        Swal.fire({ icon: 'success', title: 'Tous les tests sont VALIDÉS ! 🎉', text: `${passedCount} / ${testCases.length} cas de tests réussis.`, background: '#111827', color: '#fff' });
      } else {
        Swal.fire({ icon: 'error', title: 'Échec de certains tests', text: `${passedCount} / ${testCases.length} cas de tests réussis.`, background: '#111827', color: '#fff' });
      }
    } finally {
      setIsTestingSolution(false);
    }
  };

  const handleExportJSON = () => {
    const payload = {
      id: initialProblem?.id || undefined,
      title: title.trim(),
      description: description.trim(),
      difficulty,
      topic: selectedChapters.join(', ') || 'Algorithmique Général',
      tags: selectedChapters,
      starterTemplate: templateCode,
      templateCode: { ALGO: templateCode, PYTHON: '' },
      referenceSolution,
      testCases
    };

    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(payload, null, 2))}`;
    const downloadAnchor = document.createElement('a');
    const fileName = `Probleme_${(title || 'sans_titre').replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`;
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute('download', fileName);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJSON = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const rawText = (event.target.result || '').replace(/^\uFEFF+/, '').trim();
        const data = JSON.parse(rawText);
        if (data.title) setTitle(data.title);
        if (data.description) setDescription(data.description);
        if (data.difficulty) setDifficulty(data.difficulty);
        if (data.tags || data.topic) {
          const tags = data.tags || (typeof data.topic === 'string' ? data.topic.split(',').map(t => t.trim()) : []);
          if (tags.length > 0) setSelectedChapters(tags);
        }
        if (data.starterTemplate || data.templateCode) {
          const st = typeof data.starterTemplate === 'string' ? data.starterTemplate : (data.templateCode?.ALGO || data.templateCode || '');
          if (st) setTemplateCode(st);
        }
        if (data.referenceSolution) setReferenceSolution(data.referenceSolution);
        if (Array.isArray(data.testCases)) setTestCases(data.testCases);

        setValidationErrors({ title: false, description: false, chapters: false });
        Swal.fire({ icon: 'success', title: 'Fichier JSON Importé !', timer: 1500, showConfirmButton: false, background: '#111827', color: '#fff' });
      } catch (err) {
        Swal.fire({ icon: 'error', title: 'Erreur JSON', text: 'Fichier JSON invalide ou corrompu.', background: '#111827', color: '#fff' });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Question Management Helpers
  const handleAddQuestion = () => {
    const nextIdx = questions.length + 1;
    setQuestions(prev => [
      ...prev,
      { id: `q_${Date.now()}_${nextIdx}`, orderIndex: nextIdx, statement: `Énoncé de la question ${nextIdx}...` }
    ]);
  };

  const handleRemoveQuestion = async (qIndex) => {
    const targetQ = questions[qIndex];
    if (!targetQ) return;
    const qNum = targetQ.orderIndex;

    // Check for orphaned markers in code
    const markerTag = `// question ${qNum} starts here`;
    if (templateCode.includes(markerTag) || referenceSolution.includes(markerTag)) {
      const confirm = await Swal.fire({
        title: 'Marqueurs détectés dans le code !',
        text: `Le code modèle ou la solution contient encore "${markerTag}". Supprimer cette question laissera des marqueurs orphelins. Confirmer la suppression ?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Supprimer quand même',
        cancelButtonText: 'Annuler',
        background: '#111827',
        color: '#fff',
        confirmButtonColor: '#ef4444'
      });
      if (!confirm.isConfirmed) return;
    }

    setQuestions(prev => {
      const filtered = prev.filter((_, idx) => idx !== qIndex);
      return filtered.map((q, idx) => ({ ...q, orderIndex: idx + 1 }));
    });
  };

  const handleMoveQuestion = (index, direction) => {
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= questions.length) return;
    setQuestions(prev => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIndex];
      copy[targetIndex] = temp;
      return copy.map((q, idx) => ({ ...q, orderIndex: idx + 1 }));
    });
  };

  const handleUpdateQuestionStatement = (index, val) => {
    setQuestions(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], statement: val };
      return copy;
    });
  };

  // Marker Insertion Tool for CodeMirror
  const handleInsertQuestionMarker = async () => {
    let selectedNum = 1;
    if (questions.length > 1) {
      const inputOptions = {};
      questions.forEach((q, idx) => {
        inputOptions[q.orderIndex] = `Question ${q.orderIndex} (Sous-question ${idx + 1})`;
      });

      const { value: chosen } = await Swal.fire({
        title: '🏷️ Insérer un Marqueur de Question',
        text: 'Sélectionnez la question à délimiter dans le code :',
        input: 'select',
        inputOptions,
        inputValue: 1,
        showCancelButton: true,
        confirmButtonText: 'Insérer',
        cancelButtonText: 'Annuler',
        background: '#111827',
        color: '#fff'
      });

      if (!chosen) return;
      selectedNum = parseInt(chosen, 10);
    }

    const snippet = `// question ${selectedNum} commence ici\n\n// question ${selectedNum} se termine ici\n`;
    handleInsertBrickAtCursor(snippet);
  };

  // Save Problem Action with Marker Validation
  const handleSaveProblem = async () => {
    const isTitleMissing = !title.trim();
    const isDescriptionMissing = !description.trim() && (!questions[0]?.statement || !questions[0].statement.trim());
    const isChaptersMissing = selectedChapters.length === 0;

    setValidationErrors({
      title: isTitleMissing,
      description: isDescriptionMissing,
      chapters: isChaptersMissing
    });

    if (isTitleMissing || isDescriptionMissing || isChaptersMissing) {
      const missingFields = [];
      if (isTitleMissing) missingFields.push('Titre du problème (Étape 1)');
      if (isChaptersMissing) missingFields.push('Au moins un Chapitre / Tag (Étape 1)');
      if (isDescriptionMissing) missingFields.push('Énoncé du problème (Étape 2)');

      Swal.fire({
        icon: 'error',
        title: 'Champs Obligatoires Manquants !',
        html: `
          <div style="text-align: left; font-size: 0.9rem; line-height: 1.6; color: #f87171;">
            Veuillez remplir les champs suivants surlignés en <strong style="color: #ef4444;">ROUGE</strong> :
            <ul style="margin-top: 8px; margin-left: 20px;">
              ${missingFields.map(f => `<li><strong>${f}</strong></li>`).join('')}
            </ul>
          </div>
        `,
        background: '#111827',
        color: '#fff'
      });

      if (isTitleMissing || isChaptersMissing) {
        document.getElementById('step-1')?.scrollIntoView({ behavior: 'smooth' });
      } else if (isDescriptionMissing) {
        document.getElementById('step-2')?.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    // Validate Question Markers
    const markerVal = validateQuestionMarkersClient(templateCode, questions.length);
    if (!markerVal.valid) {
      Swal.fire({
        icon: 'error',
        title: 'Marqueurs de Questions Invalides',
        text: markerVal.error,
        background: '#111827',
        color: '#fff'
      });
      document.getElementById('step-3')?.scrollIntoView({ behavior: 'smooth' });
      return;
    }

    const payload = {
      title: title.trim(),
      description: description.trim() || questions[0]?.statement || '',
      topic: selectedChapters.join(', ') || 'Algorithmique Général',
      difficulty,
      tags: selectedChapters,
      starterTemplate: templateCode,
      templateCode: { ALGO: templateCode, PYTHON: '' },
      referenceSolution,
      testCases: testCases.map(tc => ({
        inputData: tc.input !== undefined ? tc.input : (tc.inputData || ''),
        expectedOutput: tc.expectedOutput || '',
        isPublic: tc.isHidden !== undefined ? !tc.isHidden : (tc.isPublic !== undefined ? tc.isPublic : true),
        weight: tc.weight || 1
      })),
      questions: questions.map((q, idx) => ({
        orderIndex: q.orderIndex !== undefined ? q.orderIndex : (idx + 1),
        statement: q.statement || description
      }))
    };

    setIsSaving(true);
    try {
      let saved;
      if (initialProblem?.id) {
        saved = await updateProblem(initialProblem.id, payload);
      } else {
        saved = await createProblem(payload);
      }

      setValidationErrors({ title: false, description: false, chapters: false });
      Swal.fire({ icon: 'success', title: 'Problème Enregistré avec Succès !', timer: 1500, showConfirmButton: false, background: '#111827', color: '#fff' });
      if (onSaveSuccess) onSaveSuccess(saved);
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Erreur d’enregistrement', text: err.data?.error || err.message, background: '#111827', color: '#fff' });
    } finally {
      setIsSaving(false);
    }
  };

  // Filter Active Bricks by Selected Chapter & Search Filter
  const activeChapterBricks = COMPREHENSIVE_CODE_BRICKS.filter(b => {
    const matchChapter = b.chapterId === selectedBrickChapter;
    const matchSearch = !brickSearchQuery.trim() ||
      b.label.toLowerCase().includes(brickSearchQuery.toLowerCase()) ||
      b.snippet.toLowerCase().includes(brickSearchQuery.toLowerCase());
    return matchChapter && matchSearch;
  });

  const areAllStepsCollapsed = Object.values(collapsedSteps).every(Boolean);

  return (
    <div style={{ padding: '30px', maxWidth: '1440px', margin: '0 auto', color: '#ffffff' }}>
      
      {/* ── Studio Header Toolbar ── */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        marginBottom: '25px', position: 'sticky', top: 0, zIndex: 1000,
        background: 'rgba(5, 7, 13, 0.96)', backdropFilter: 'blur(10px)',
        padding: '14px 20px', borderRadius: '12px', border: '1px solid var(--panel-border)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          {handleBack && (
            <button className="btn btn-secondary" onClick={handleBack} style={{ padding: '8px 14px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <ArrowLeft size={18} /> Retour à la Banque
            </button>
          )}
          <div>
            <h2 style={{ fontSize: '1.6rem', fontWeight: '800', margin: 0, color: '#f8fafc', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Sparkles size={24} color="#a78bfa" />
              {initialProblem ? 'Modification du Problème' : 'Studio de Création d\'Exercice'}
            </h2>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Édition enrichie, colorations syntaxiques ALGO, briques 10 chapitres & étapes réductibles
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <button
            className="btn btn-secondary"
            onClick={() => toggleAllSteps(!areAllStepsCollapsed)}
            style={{ padding: '8px 14px', fontSize: '0.82rem', borderColor: '#a78bfa', color: '#c4b5fd' }}
          >
            {areAllStepsCollapsed ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
            {areAllStepsCollapsed ? 'Tout Déplier les Étapes' : 'Tout Réduire'}
          </button>

          <button className="btn btn-secondary" onClick={handleExportJSON} title="Exporter le problème en fichier .json">
            <Download size={15} color="#34d399" /> Exporter JSON
          </button>

          <button className="btn btn-secondary" onClick={() => fileInputRef.current?.click()}>
            <Upload size={15} color="#a78bfa" /> Importer JSON
          </button>
          <input type="file" ref={fileInputRef} accept=".json" style={{ display: 'none' }} onChange={handleImportJSON} />

          <button className="btn btn-primary" onClick={handleSaveProblem} disabled={isSaving} style={{ padding: '10px 22px', fontWeight: '700' }}>
            <Save size={16} /> {isSaving ? 'Enregistrement...' : 'Enregistrer le Problème'}
          </button>
        </div>
      </div>

      {/* ── VERTICAL STEP-BY-STEP FLOW (ALL STEPS COLLAPSIBLE WITH SUMMARY BADGES) ── */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        
        {/* ── ÉTAPE 1: 🎯 Identité & Chapitres ── */}
        <div id="step-1" className="glass-panel" style={{ padding: '20px 26px' }}>
          <div 
            onClick={() => toggleStep('step1')}
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span className="badge badge-purple" style={{ fontSize: '0.9rem', padding: '6px 12px' }}>Étape 1</span>
              <h3 style={{ fontSize: '1.2rem', margin: 0, color: '#60a5fa' }}>🎯 Identité & Chapitres du Cours AlgoCompiler</h3>
              
              {/* Header Summary Pill when Collapsed */}
              {collapsedSteps.step1 && (
                <span style={{ fontSize: '0.8rem', color: '#60a5fa', background: 'rgba(96,165,250,0.12)', padding: '4px 12px', borderRadius: '12px', border: '1px solid rgba(96,165,250,0.3)', fontWeight: '600' }}>
                  📌 {title || 'Titre non défini'} • {difficulty} • {selectedChapters.length} Chapitre(s)
                </span>
              )}
            </div>
            {collapsedSteps.step1 ? <ChevronRight size={18} color="#60a5fa" /> : <ChevronDown size={18} color="#60a5fa" />}
          </div>

          {!collapsedSteps.step1 && (
            <div style={{ marginTop: '20px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '3fr 1fr', gap: '20px', marginBottom: '22px' }}>
                <div className="form-group" style={{ margin: 0 }}>
                  <label style={{ fontSize: '0.88rem', fontWeight: '700', marginBottom: '6px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span>Titre Officiel du Problème <span style={{ color: '#ef4444' }}>*</span></span>
                    {validationErrors.title && <span style={{ color: '#ef4444', fontSize: '0.78rem', fontWeight: '700' }}>⚠️ Titre requis !</span>}
                  </label>
                  <input 
                    className="form-input" 
                    placeholder="ex: Somme de Deux Entiers ou Recherche de l'Élément Maximum" 
                    value={title} 
                    onChange={e => {
                      setTitle(e.target.value);
                      if (e.target.value.trim()) setValidationErrors(prev => ({ ...prev, title: false }));
                    }}
                    style={{
                      border: validationErrors.title ? '2px solid #ef4444' : '1px solid var(--panel-border)',
                      background: validationErrors.title ? 'rgba(239, 68, 68, 0.08)' : undefined
                    }}
                  />
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label style={{ fontSize: '0.88rem', fontWeight: '700', marginBottom: '6px', display: 'block' }}>
                    Niveau de Difficulté
                  </label>
                  <select className="form-input" value={difficulty} onChange={e => setDifficulty(e.target.value)}>
                    <option value="FACILE">FACILE</option>
                    <option value="MOYEN">MOYEN</option>
                    <option value="DIFFICILE">DIFFICILE</option>
                  </select>
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.88rem', fontWeight: '700', marginBottom: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#c084fc' }}>
                  <span>📚 Chapitres Associés du Cours AlgoCompiler (Sélectionnez un ou plusieurs chapitres) <span style={{ color: '#ef4444' }}>*</span> :</span>
                  {validationErrors.chapters && <span style={{ color: '#ef4444', fontSize: '0.78rem', fontWeight: '700' }}>⚠️ Sélectionnez au moins un chapitre !</span>}
                </label>
                <div style={{
                  display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px',
                  padding: validationErrors.chapters ? '10px' : undefined,
                  border: validationErrors.chapters ? '2px solid #ef4444' : 'none',
                  borderRadius: validationErrors.chapters ? '10px' : undefined,
                  background: validationErrors.chapters ? 'rgba(239, 68, 68, 0.05)' : undefined
                }}>
                  {ALGO_CHAPTERS.map(ch => {
                    const isSelected = selectedChapters.includes(ch.title);
                    return (
                      <div
                        key={ch.id}
                        onClick={() => handleToggleChapter(ch.title)}
                        style={{
                          padding: '12px 16px',
                          borderRadius: '8px',
                          cursor: 'pointer',
                          border: isSelected ? '1px solid #8b5cf6' : '1px solid rgba(255,255,255,0.1)',
                          background: isSelected ? 'rgba(139, 92, 246, 0.16)' : 'rgba(0,0,0,0.2)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: '12px',
                          transition: 'all 0.15s ease'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <input type="checkbox" checked={isSelected} onChange={() => {}} style={{ width: '16px', height: '16px', cursor: 'pointer' }} />
                          <span style={{ fontSize: '0.88rem', fontWeight: isSelected ? '700' : '500', color: isSelected ? '#ddd6fe' : 'var(--text-muted)' }}>
                            {ch.title}
                          </span>
                        </div>
                        <span className="badge badge-blue" style={{ fontSize: '0.75rem' }}>{ch.badge}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ── ÉTAPE 2: 📝 Énoncé du Sujet & Gestion des Sous-Questions ── */}
        <div id="step-2" className="glass-panel" style={{ padding: '20px 26px' }}>
          <div 
            onClick={() => toggleStep('step2')}
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
              <span className="badge badge-purple" style={{ fontSize: '0.9rem', padding: '6px 12px' }}>Étape 2</span>
              <h3 style={{ fontSize: '1.2rem', margin: 0, color: '#a78bfa' }}>📝 Énoncé du Sujet & Sous-Questions</h3>
              
              {/* Question Count Badge */}
              <span className="badge badge-blue" style={{ fontSize: '0.8rem', padding: '4px 10px' }}>
                {questions.length === 1 ? '1 Question Unique' : `${questions.length} Sous-Questions`}
              </span>

              {/* Header Summary Pill when Collapsed */}
              {collapsedSteps.step2 && (
                <span style={{ fontSize: '0.8rem', color: '#a78bfa', background: 'rgba(167,139,250,0.12)', padding: '4px 12px', borderRadius: '12px', border: '1px solid rgba(167,139,250,0.3)', fontWeight: '600' }}>
                  📄 Énoncé ({description ? description.length : 0} car.) • {questions.length} Question(s)
                </span>
              )}
            </div>
            {collapsedSteps.step2 ? <ChevronRight size={18} color="#a78bfa" /> : <ChevronDown size={18} color="#a78bfa" />}
          </div>

          {!collapsedSteps.step2 && (
            <div style={{ marginTop: '20px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              
              {/* Top Controls: Templates + Add Question */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <button
                    type="button"
                    className="btn btn-primary"
                    style={{ padding: '6px 14px', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: '6px' }}
                    onClick={handleAddQuestion}
                  >
                    <Plus size={14} /> Ajouter une Sous-Question ({questions.length + 1})
                  </button>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    {questions.length > 1 ? 'Multi-questions avec découpage AST indépendant' : 'Question simple globale'}
                  </span>
                </div>

                <select
                  className="form-input"
                  style={{ fontSize: '0.82rem', padding: '4px 10px', background: '#0f172a', borderColor: '#a78bfa', color: '#c4b5fd', width: 'auto' }}
                  onChange={e => {
                    const t = MARKDOWN_TEMPLATES.find(tmpl => tmpl.id === e.target.value);
                    if (t) {
                      setDescription(t.template);
                      setValidationErrors(prev => ({ ...prev, description: false }));
                    }
                  }}
                  defaultValue=""
                >
                  <option value="" disabled>📋 Insérer un Modèle d'Énoncé...</option>
                  {MARKDOWN_TEMPLATES.map(t => (
                    <option key={t.id} value={t.id}>{t.label}</option>
                  ))}
                </select>
              </div>

              {/* Main 2-Column Layout: Left Editors, Right Combined Preview */}
              <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: '20px' }}>
                
                {/* Left Column: Intro Description + Questions List */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {/* General Problem Intro */}
                  <div style={{ background: '#0b0f19', padding: '14px', borderRadius: '8px', border: '1px solid #1e293b' }}>
                    <label style={{ fontSize: '0.84rem', fontWeight: '800', color: '#60a5fa', marginBottom: '8px', display: 'block' }}>
                      📌 Contexte Général / Introduction du Problème (Markdown) :
                    </label>
                    <textarea
                      ref={descriptionRef}
                      className="form-textarea"
                      style={{
                        height: '140px',
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.88rem',
                        lineHeight: '1.5',
                        border: validationErrors.description ? '2px solid #ef4444' : '1px solid rgba(255,255,255,0.1)',
                        background: validationErrors.description ? 'rgba(239, 68, 68, 0.05)' : undefined
                      }}
                      placeholder="Contexte général, définitions des structures, etc..."
                      value={description}
                      onChange={e => {
                        setDescription(e.target.value);
                        if (e.target.value.trim()) setValidationErrors(prev => ({ ...prev, description: false }));
                      }}
                    />
                  </div>

                  {/* List of Questions */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {questions.map((q, idx) => (
                      <div key={q.id || idx} style={{ background: '#0f172a', padding: '14px', borderRadius: '8px', border: '1px solid rgba(167, 139, 250, 0.3)', position: 'relative' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <span className="badge badge-purple" style={{ fontSize: '0.8rem', fontWeight: '800' }}>
                              Question {q.orderIndex}
                            </span>
                            <span style={{ fontSize: '0.78rem', color: '#cbd5e1' }}>
                              (Zone de code : <code>// question {q.orderIndex} starts here</code>)
                            </span>
                          </div>

                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <button
                              type="button"
                              className="btn btn-secondary"
                              style={{ padding: '3px 8px' }}
                              disabled={idx === 0}
                              onClick={() => handleMoveQuestion(idx, -1)}
                              title="Monter"
                            >
                              <MoveUp size={12} />
                            </button>
                            <button
                              type="button"
                              className="btn btn-secondary"
                              style={{ padding: '3px 8px' }}
                              disabled={idx === questions.length - 1}
                              onClick={() => handleMoveQuestion(idx, 1)}
                              title="Descendre"
                            >
                              <MoveDown size={12} />
                            </button>
                            {questions.length > 1 && (
                              <button
                                type="button"
                                className="btn btn-secondary"
                                style={{ padding: '3px 8px', color: '#f87171' }}
                                onClick={() => handleRemoveQuestion(idx)}
                                title="Supprimer cette sous-question"
                              >
                                <Trash2 size={12} />
                              </button>
                            )}
                          </div>
                        </div>

                        <textarea
                          className="form-textarea"
                          style={{
                            height: '110px',
                            fontFamily: 'var(--font-mono)',
                            fontSize: '0.86rem',
                            lineHeight: '1.4'
                          }}
                          placeholder={`Énoncé de la question ${q.orderIndex}...`}
                          value={q.statement}
                          onChange={e => handleUpdateQuestionStatement(idx, e.target.value)}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right Column: Combined Live Markdown Preview */}
                <div>
                  <label style={{ fontSize: '0.85rem', fontWeight: '700', marginBottom: '8px', display: 'block', color: '#34d399' }}>
                    👁️ Aperçu du Sujet Complet (Rendu Étudiant)
                  </label>
                  <div 
                    className="glass-panel" 
                    style={{ 
                      height: '520px', 
                      padding: '18px', 
                      overflowY: 'auto', 
                      background: 'rgba(15, 23, 42, 0.6)', 
                      border: '1px solid rgba(255,255,255,0.08)' 
                    }}
                    dangerouslySetInnerHTML={{
                      __html: renderMarkdownHTML(
                        (description ? `${description}\n\n---\n\n` : '') +
                        questions.map((q, idx) => `### Question ${q.orderIndex} :\n${q.statement || '_Aucun énoncé saisi._'}`).join('\n\n')
                      )
                    }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ── ÉTAPE 3: 💻 Éditeur de Code Professionnel ── */}
        <div id="step-3" className="glass-panel" style={{ padding: '20px 26px' }}>
          <div 
            onClick={() => toggleStep('step3')}
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span className="badge badge-purple" style={{ fontSize: '0.9rem', padding: '6px 12px' }}>Étape 3</span>
              <h3 style={{ fontSize: '1.2rem', margin: 0, color: '#c084fc' }}>💻 Éditeur de Code Professionnel & Briques Algorithmiques</h3>
              
              {/* Header Summary Pill when Collapsed */}
              {collapsedSteps.step3 && (
                <span style={{ fontSize: '0.8rem', color: '#c084fc', background: 'rgba(192,132,252,0.12)', padding: '4px 12px', borderRadius: '12px', border: '1px solid rgba(192,132,252,0.3)', fontWeight: '600' }}>
                  💻 Modèle: {templateCode.split('\n').length} l. | Solution: {referenceSolution.split('\n').length} l.
                </span>
              )}
            </div>
            {collapsedSteps.step3 ? <ChevronRight size={18} color="#c084fc" /> : <ChevronDown size={18} color="#c084fc" />}
          </div>

          {!collapsedSteps.step3 && (
            <div style={{ marginTop: '20px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '14px' }}>
                <div style={{ display: 'flex', gap: '4px', background: 'rgba(0,0,0,0.3)', padding: '4px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)' }}>
                  <button
                    type="button"
                    onClick={() => setCodeEditorTab('STARTER')}
                    style={{
                      padding: '8px 16px',
                      background: codeEditorTab === 'STARTER' ? 'rgba(99,102,241,0.3)' : 'transparent',
                      color: codeEditorTab === 'STARTER' ? '#818cf8' : 'var(--text-muted)',
                      border: 'none',
                      borderRadius: '6px',
                      fontWeight: codeEditorTab === 'STARTER' ? '700' : '500',
                      cursor: 'pointer',
                      fontSize: '0.85rem'
                    }}
                  >
                    💻 Modèle Starter (Élève)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCodeEditorTab('SOLUTION')}
                    style={{
                      padding: '8px 16px',
                      background: codeEditorTab === 'SOLUTION' ? 'rgba(16,185,129,0.3)' : 'transparent',
                      color: codeEditorTab === 'SOLUTION' ? '#34d399' : 'var(--text-muted)',
                      border: 'none',
                      borderRadius: '6px',
                      fontWeight: codeEditorTab === 'SOLUTION' ? '700' : '500',
                      cursor: 'pointer',
                      fontSize: '0.85rem'
                    }}
                  >
                    🎯 Solution de Référence
                  </button>
                </div>
              </div>

              {/* Enhanced Interactive Code Bricks Toolbar Header */}
              <div style={{
                padding: '12px 16px', 
                background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.98), rgba(30, 41, 59, 0.95))', 
                border: '1px solid rgba(244, 63, 94, 0.3)',
                borderRadius: '10px 10px 0 0', 
                display: 'flex', 
                flexDirection: 'column',
                gap: '12px', 
                boxShadow: '0 4px 15px rgba(0,0,0,0.3)'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
                  <span style={{ fontSize: '0.88rem', fontWeight: '800', color: '#f43f5e', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    🧱 Catalogue des Briques (10 Chapitres) :
                  </span>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, maxWidth: '350px' }}>
                    <Search size={14} color="#f43f5e" />
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Filtrer une brique par nom ou code..."
                      style={{ padding: '4px 10px', fontSize: '0.8rem', background: '#090d16', borderColor: 'rgba(244,63,94,0.3)' }}
                      value={brickSearchQuery}
                      onChange={e => setBrickSearchQuery(e.target.value)}
                    />
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                  <button
                      type="button"
                      className="btn btn-secondary"
                      style={{ padding: '4px 10px', fontSize: '0.8rem', fontWeight: '700', color: '#34d399', borderColor: 'rgba(52,211,153,0.3)', display: 'flex', alignItems: 'center', gap: '5px' }}
                      onClick={handleInsertQuestionMarker}
                      title="Insérer un délimiteur de zone de question pour l'évaluation AST"
                    >
                      <Tag size={13} color="#34d399" /> 🏷️ Insérer Marqueur Question
                    </button>     <button
                      type="button"
                      className="btn btn-secondary"
                      style={{ padding: '5px 10px', fontSize: '0.78rem', color: '#60a5fa', borderColor: 'rgba(96,165,250,0.3)', fontWeight: '600' }}
                      onClick={handleFormatCode}
                      title="Reformater selon la syntaxe AlgoCompiler"
                    >
                      🧹 Reformater
                    </button>

                    <button
                      type="button"
                      className="btn btn-secondary"
                      style={{ padding: '5px 10px', fontSize: '0.78rem', color: '#34d399', borderColor: 'rgba(52,211,153,0.3)', fontWeight: '600' }}
                      onClick={() => handleToggleComment(false)}
                      title="Commenter les lignes"
                    >
                      💬 Commenter
                    </button>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '2px', background: '#1e293b', borderRadius: '6px', padding: '2px 8px', border: '1px solid rgba(255,255,255,0.1)' }}>
                      <button type="button" onClick={() => setFontSize(f => Math.max(12, f - 1))} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '800' }}>-</button>
                      <span style={{ fontSize: '0.75rem', color: '#e2e8f0', minWidth: '28px', textAlign: 'center', fontWeight: '700' }}>{fontSize}px</span>
                      <button type="button" onClick={() => setFontSize(f => Math.min(22, f + 1))} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '800' }}>+</button>
                    </div>
                  </div>
                </div>

                {/* Chapter Pill Selector Tabs */}
                <div style={{ display: 'flex', gap: '6px', overflowX: 'auto', paddingBottom: '4px' }}>
                  {ALGO_CHAPTERS.map(ch => {
                    const isChActive = selectedBrickChapter === ch.id;
                    return (
                      <button
                        key={ch.id}
                        type="button"
                        onClick={() => setSelectedBrickChapter(ch.id)}
                        style={{
                          padding: '4px 12px',
                          borderRadius: '16px',
                          fontSize: '0.76rem',
                          fontWeight: '700',
                          border: isChActive ? '1px solid #f43f5e' : '1px solid rgba(255,255,255,0.1)',
                          background: isChActive ? 'rgba(244,63,94,0.25)' : 'rgba(0,0,0,0.3)',
                          color: isChActive ? '#ffffff' : 'var(--text-muted)',
                          cursor: 'pointer',
                          whiteSpace: 'nowrap',
                          transition: 'all 0.15s ease'
                        }}
                      >
                        {ch.badge}
                      </button>
                    );
                  })}
                </div>

                {/* Brick Picker Buttons for Active Chapter */}
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {activeChapterBricks.length === 0 ? (
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontStyle: 'italic' }}>Aucune brique ne correspond au filtre.</span>
                  ) : (
                    activeChapterBricks.map(b => (
                      <button
                        key={b.id}
                        type="button"
                        className="btn"
                        style={{
                          padding: '5px 12px',
                          fontSize: '0.78rem',
                          fontWeight: '700',
                          border: '1px solid rgba(244, 63, 94, 0.35)',
                          color: '#ffffff',
                          background: 'linear-gradient(135deg, rgba(244, 63, 94, 0.2), rgba(15, 23, 42, 0.8))',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          transition: 'all 0.15s ease'
                        }}
                        onClick={() => handleInsertBrickAtCursor(b.snippet)}
                        title={`Insérer au curseur:\n${b.snippet}`}
                      >
                        ➕ {b.label}
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* CodeMirror Code Editor */}
              <div style={{ border: '1px solid rgba(255,255,255,0.1)', borderTop: 'none', borderRadius: '0 0 8px 8px', overflow: 'hidden' }}>
                {codeEditorTab === 'STARTER' ? (
                  <CodeMirror
                    value={templateCode}
                    height="450px"
                    extensions={[...algoExtension(), search({ top: true })]}
                    onCreateEditor={(view) => { starterViewRef.current = view; }}
                    onChange={value => setTemplateCode(value)}
                    style={{ fontSize: `${fontSize}px` }}
                  />
                ) : (
                  <CodeMirror
                    value={referenceSolution}
                    height="450px"
                    extensions={[...algoExtension(), search({ top: true })]}
                    onCreateEditor={(view) => { solutionViewRef.current = view; }}
                    onChange={value => setReferenceSolution(value)}
                    style={{ fontSize: `${fontSize}px` }}
                  />
                )}
              </div>

              {/* Live Sandbox Test Execution Panel */}
              <div style={{ marginTop: '16px', background: 'rgba(15, 23, 42, 0.7)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', padding: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <span style={{ fontSize: '0.88rem', fontWeight: '700', color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Terminal size={16} /> Console Sandbox ({codeEditorTab === 'STARTER' ? 'Code Modèle' : 'Solution de Référence'})
                  </span>
                  <button
                    type="button"
                    className="btn btn-success"
                    style={{ padding: '6px 14px', fontSize: '0.82rem', fontWeight: '700' }}
                    onClick={handleRunSandbox}
                    disabled={isRunningSandbox}
                  >
                    <Play size={14} /> {isRunningSandbox ? 'Exécution...' : '▶️ Tester le Code'}
                  </button>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Entrée (STDIN)</label>
                    <textarea className="form-textarea" rows={3} style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }} value={sandboxInput} onChange={e => setSandboxInput(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Sortie (STDOUT / STDERR)</label>
                    <div style={{ height: '74px', padding: '8px 12px', background: '#090d16', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '6px', fontFamily: 'var(--font-mono)', fontSize: '0.82rem', overflowY: 'auto' }}>
                      {isRunningSandbox ? <span style={{ color: '#f59e0b' }}>⌛ Exécution du code...</span> : sandboxOutput ? (
                        <div>{sandboxOutput.error ? <div style={{ color: '#f87171' }}>Erreur : {sandboxOutput.error}</div> : <pre style={{ margin: 0, fontFamily: 'inherit', whiteSpace: 'pre-wrap', color: '#34d399' }}>{sandboxOutput.output}</pre>}</div>
                      ) : <span style={{ color: 'var(--text-muted)', fontStyle: 'italic' }}>Cliquez sur "Tester le Code" pour exécuter.</span>}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ── ÉTAPE 4: 🧪 Suite de Tests Unitaires ── */}
        <div id="step-4" className="glass-panel" style={{ padding: '20px 26px' }}>
          <div 
            onClick={() => toggleStep('step4')}
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span className="badge badge-purple" style={{ fontSize: '0.9rem', padding: '6px 12px' }}>Étape 4</span>
              <h3 style={{ fontSize: '1.2rem', margin: 0, color: '#34d399' }}>
                {testCases.length === 0
                  ? 'Suite de Tests Unitaires (Aucun test configuré)'
                  : `Suite de Tests Unitaires (${testCases.length} tests : ${testCases.filter(t => !t.isHidden).length} Publics, ${testCases.filter(t => t.isHidden).length} Masqués)`}
              </h3>
              
              {/* Header Summary Pill when Collapsed */}
              {collapsedSteps.step4 && (
                <span style={{ fontSize: '0.8rem', color: '#34d399', background: 'rgba(52,211,153,0.12)', padding: '4px 12px', borderRadius: '12px', border: '1px solid rgba(52,211,153,0.3)', fontWeight: '600' }}>
                  🧪 {testCases.length} Test(s) ({testCases.filter(t => !t.isHidden).length} Publics, {testCases.filter(t => t.isHidden).length} Masqués)
                </span>
              )}
            </div>
            {collapsedSteps.step4 ? <ChevronRight size={18} color="#34d399" /> : <ChevronDown size={18} color="#34d399" />}
          </div>

          {!collapsedSteps.step4 && (
            <div style={{ marginTop: '20px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginBottom: '16px' }}>
                {testCases.length > 0 && (
                  <button className="btn btn-success" onClick={handleTestReferenceSolution} disabled={isTestingSolution} style={{ fontWeight: '700' }}>
                    <Play size={15} /> {isTestingSolution ? 'Exécution des tests...' : `🧪 Valider les ${testCases.length} Tests`}
                  </button>
                )}
                <button className="btn btn-primary" onClick={handleAddTestCase} style={{ fontSize: '0.85rem' }}>
                  <Plus size={15} /> Ajouter un Cas de Test
                </button>
              </div>

              {testCases.length === 0 ? (
                <div className="glass-panel" style={{ padding: '22px', background: 'rgba(245, 158, 11, 0.1)', border: '1px solid #f59e0b', borderRadius: '10px' }}>
                  <h4 style={{ color: '#fbbf24', fontSize: '1.05rem', margin: '0 0 8px 0', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <FileText size={20} /> Évaluation Sans Tests Automatiques
                  </h4>
                  <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
                    Aucun cas de test n'est configuré pour ce problème. Les élèves pourront exécuter leur code avec leur propre entrée (STDIN), et la note de l'exercice sera attribuée manuellement.
                  </p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  {testCases.map((tc, idx) => (
                    <div key={idx} className="glass-panel" style={{ padding: '16px', border: '1px solid rgba(255,255,255,0.08)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                        <span style={{ fontWeight: '700', color: '#60a5fa', fontSize: '0.9rem' }}>Cas de Test #{idx + 1}</span>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <button type="button" className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '0.78rem', color: '#60a5fa' }} onClick={() => handleRunSingleTestCase(idx)}>
                            <Play size={13} /> Tester ce Cas
                          </button>
                          <button type="button" className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '0.78rem' }} onClick={() => handleUpdateTestCase(idx, 'isHidden', !tc.isHidden)}>
                            {tc.isHidden ? <><EyeOff size={14} color="#f59e0b" /> Masqué</> : <><Eye size={14} color="#34d399" /> Visible</>}
                          </button>
                          <button type="button" className="btn btn-danger" style={{ padding: '4px 8px' }} onClick={() => handleRemoveTestCase(idx)}>
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>

                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 120px', gap: '14px' }}>
                        <div>
                          <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Entrée (STDIN)</label>
                          <textarea className="form-textarea" rows={2} style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }} value={tc.input !== undefined ? tc.input : (tc.inputData || '')} onChange={e => handleUpdateTestCase(idx, 'input', e.target.value)} />
                        </div>
                        <div>
                          <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Sortie Attendue (STDOUT)</label>
                          <textarea className="form-textarea" rows={2} style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }} value={tc.expectedOutput || ''} onChange={e => handleUpdateTestCase(idx, 'expectedOutput', e.target.value)} />
                        </div>
                        <div>
                          <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Pondération (Pts)</label>
                          <input type="number" className="form-input" value={tc.weight} onChange={e => handleUpdateTestCase(idx, 'weight', parseFloat(e.target.value) || 1)} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {testResults.length > 0 && (
                <div className="glass-panel" style={{ padding: '20px', marginTop: '20px', background: 'rgba(15, 23, 42, 0.95)' }}>
                  <h4 style={{ fontSize: '1rem', marginBottom: '14px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    Bilan de Validation ({testResults.filter(r => r.passed).length} / {testResults.length} cas de tests réussis)
                  </h4>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    {testResults.map((res, idx) => (
                      <div key={idx} style={{ padding: '14px', borderRadius: '8px', background: res.passed ? 'rgba(16, 185, 129, 0.12)' : 'rgba(244, 63, 94, 0.12)', border: `1px solid ${res.passed ? '#10b981' : '#f43f5e'}` }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: '700', fontSize: '0.88rem', marginBottom: '8px' }}>
                          <span style={{ color: res.passed ? '#34d399' : '#f87171', display: 'flex', alignItems: 'center', gap: '6px' }}>
                            {res.passed ? <CheckCircle size={16} /> : <XCircle size={16} />} Cas de Test #{res.testIndex} {res.passed ? '— VALIDÉ' : '— ÉCHEC'}
                          </span>
                        </div>
                        <div style={{ fontSize: '0.82rem', fontFamily: 'var(--font-mono)', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
                          <div><strong>Entrée:</strong> {res.input || '(Vide)'}</div>
                          <div><strong>Attendu:</strong> {res.expected || '(Vide)'}</div>
                          <div><strong>Obtenu:</strong> {res.error ? <span style={{ color: '#f87171' }}>{res.error}</span> : res.actual}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
