const os = require('os');

class QueueSaturationError extends Error {
  constructor(message = 'Le serveur est actuellement saturé, réessayez dans quelques secondes') {
    super(message);
    this.name = 'QueueSaturationError';
    this.statusCode = 429;
  }
}

class ExecutionConcurrencyQueue {
  constructor() {
    const cpus = os.cpus()?.length || 4;
    this.concurrencyLimit = process.env.EXECUTION_CONCURRENCY_LIMIT
      ? parseInt(process.env.EXECUTION_CONCURRENCY_LIMIT, 10)
      : Math.max(2, cpus - 1);

    this.maxQueueDepth = process.env.EXECUTION_QUEUE_MAX_DEPTH
      ? parseInt(process.env.EXECUTION_QUEUE_MAX_DEPTH, 10)
      : 100;

    this.activeCount = 0;
    this.queue = [];
  }

  get queuedCount() {
    return this.queue.length;
  }

  get totalPending() {
    return this.activeCount + this.queue.length;
  }

  enqueue(fn, metadata = {}) {
    if (this.totalPending >= this.maxQueueDepth) {
      console.warn(`[EXEC_QUEUE] REJECTED (Saturated): active=${this.activeCount}, queued=${this.queue.length}, max=${this.maxQueueDepth}`);
      return Promise.reject(new QueueSaturationError());
    }

    return new Promise((resolve, reject) => {
      const item = {
        fn,
        resolve,
        reject,
        enqueuedAt: Date.now(),
        metadata
      };
      this.queue.push(item);
      this._processNext();
    });
  }

  _processNext() {
    if (this.activeCount >= this.concurrencyLimit || this.queue.length === 0) {
      return;
    }

    const item = this.queue.shift();
    this.activeCount++;

    const queueWaitMs = Date.now() - item.enqueuedAt;
    const startTime = Date.now();

    Promise.resolve()
      .then(() => item.fn({ queueWaitMs }))
      .then((result) => {
        const execMs = Date.now() - startTime;
        const totalMs = queueWaitMs + execMs;
        console.log(`[EXEC_QUEUE] SUCCESS fileId=${item.metadata.fileId || 'N/A'} queueWaitMs=${queueWaitMs}ms execMs=${execMs}ms totalMs=${totalMs}ms (running=${this.activeCount - 1}, queued=${this.queue.length})`);
        item.resolve(result);
      })
      .catch((err) => {
        const execMs = Date.now() - startTime;
        const totalMs = queueWaitMs + execMs;
        console.error(`[EXEC_QUEUE] ERROR fileId=${item.metadata.fileId || 'N/A'} queueWaitMs=${queueWaitMs}ms execMs=${execMs}ms totalMs=${totalMs}ms (running=${this.activeCount - 1}, queued=${this.queue.length}):`, err.message || err);
        item.reject(err);
      })
      .finally(() => {
        this.activeCount--;
        this._processNext();
      });
  }
}

const globalExecutionQueue = new ExecutionConcurrencyQueue();

module.exports = {
  ExecutionConcurrencyQueue,
  globalExecutionQueue,
  QueueSaturationError
};
