const prisma = require('../prisma');
const { withRetry } = require('../prisma');
const { runCodeSingle, evaluateSubmission, validateSyntax } = require('../runner/code-execution.service');

// Get active exam workspace data for student
async function getStudentExamWorkspace(req, res) {
  try {
    const { assignmentId, studentId, examId } = req.studentExamSession;

    const assignment = await prisma.examAssignment.findUnique({
      where: { id: assignmentId },
      include: {
        student: true,
        exam: {
          include: {
            problems: {
              include: {
                problem: {
                  include: {
                    testCases: true,
                    questions: { orderBy: { orderIndex: 'asc' } }
                  }
                }
              },
              orderBy: { orderIndex: 'asc' }
            },
            announcements: { orderBy: { createdAt: 'desc' } }
          }
        }
      }
    });

    if (!assignment) {
      return res.status(404).json({ error: 'Assignment session not found' });
    }

    // Auto-resume if temporary suspension timer has expired
    if (assignment.status === 'PAUSED' && assignment.pausedUntil && new Date() >= new Date(assignment.pausedUntil)) {
      assignment = await prisma.examAssignment.update({
        where: { id: assignment.id },
        data: { status: 'IN_EXAM', pausedUntil: null },
        include: {
          student: true,
          exam: {
            include: {
              announcements: { orderBy: { createdAt: 'desc' } },
              problems: {
                orderBy: { orderIndex: 'asc' },
                include: { problem: { include: { testCases: true, questions: { orderBy: { orderIndex: 'asc' } } } } }
              }
            }
          }
        }
      });
      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_unlocked');
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: assignment.accessNumber,
          studentName: `${assignment.student.firstName} ${assignment.student.lastName}`,
          status: 'IN_EXAM',
          pausedUntil: null,
          isOnline: assignment.isOnline
        });
      }
    }

    if (['KICKED_OUT', 'ABSENT'].includes(assignment.status)) {
      return res.status(403).json({ error: 'STUDENT_KICKED_OUT', message: 'Votre session a été fermée. Accès refusé.' });
    }

    if (assignment.exam.status !== 'RUNNING' && assignment.exam.status !== 'PAUSED' && assignment.status !== 'FINISHED') {
      return res.status(403).json({ error: 'EXAM_NOT_STARTED', message: 'L\'examen n\'a pas encore été démarré par l\'enseignant.' });
    }

    // Prepare problem data for student (hiding hidden test cases)
    const problems = assignment.exam.problems.map(ep => ({
      id: ep.problem.id,
      title: ep.problem.title,
      description: ep.problem.description,
      topic: ep.problem.topic,
      difficulty: ep.problem.difficulty,
      points: ep.points || 10,
      weightTest: ep.weightTest ?? 40,
      weightAst: ep.weightAst ?? 60,
      weightAi: ep.weightAi ?? 0,
      questionPoints: ep.questionPoints || {},
      questions: ep.problem.questions || [],
      timeLimitMs: ep.problem.timeLimitMs,
      templateCode: ep.problem.templateCode,
      publicTestCases: ep.problem.testCases
        .filter(tc => tc.isPublic)
        .map(tc => ({ id: tc.id, inputData: tc.inputData, expectedOutput: tc.expectedOutput }))
    }));

    // Fetch existing submissions for this student in this exam
    const submissions = await prisma.submission.findMany({
      where: { examId, studentId },
      orderBy: { createdAt: 'desc' }
    });

    // Calculate total time allocated including extension
    const durationMs = assignment.exam.durationMinutes * 60 * 1000;
    const totalTimeMs = durationMs + (assignment.timeExtendedMs || 0);

    return res.json({
      student: {
        id: assignment.student.id,
        studentId: assignment.student.studentId,
        firstName: assignment.student.firstName,
        lastName: assignment.student.lastName,
        group: assignment.student.group,
        speciality: assignment.student.speciality,
        accessNumber: assignment.accessNumber
      },
      exam: {
        id: assignment.exam.id,
        title: assignment.exam.title,
        description: assignment.exam.description,
        status: assignment.exam.status,
        startTime: assignment.exam.startTime,
        durationMinutes: assignment.exam.durationMinutes,
        totalTimeMs,
        maxViolationsAllowed: assignment.exam.maxViolationsAllowed,
        copyDisabled: assignment.exam.copyDisabled,
        pasteDisabled: assignment.exam.pasteDisabled,
        fullscreenRequired: assignment.exam.fullscreenRequired,
        allowCodeBricks: assignment.exam.allowCodeBricks,
        allowedBricks: assignment.exam.allowedBricks,
        allowedLanguages: assignment.exam.allowedLanguages,
        announcements: assignment.exam.announcements
      },
      assignmentStatus: assignment.status,
      pausedUntil: assignment.pausedUntil,
      assignment: {
        status: assignment.status,
        pausedUntil: assignment.pausedUntil
      },
      currentCodeMap: assignment.currentCodeMap || {},
      violationsCount: assignment.violations,
      problems,
      submissions
    });
  } catch (err) {
    console.error('getStudentExamWorkspace error:', err);
    return res.status(500).json({ error: 'Failed to fetch exam workspace' });
  }
}

// Autosave student code per problem or batch map
async function autosaveCode(req, res) {
  try {
    const { assignmentId } = req.studentExamSession;
    const { problemId, code, language, fullCodeMap } = req.body;

    const assignment = await withRetry(() => prisma.examAssignment.findUnique({
      where: { id: assignmentId },
      include: { exam: true }
    }));

    if (!assignment || ['FINISHED', 'KICKED_OUT', 'ABSENT', 'PAUSED', 'COMPLETED', 'SUBMITTED'].includes(assignment.status) || ['FINISHED', 'COMPLETED', 'ARCHIVED'].includes(assignment.exam?.status)) {
      return res.status(403).json({ error: 'EXAM_INACTIVE', message: 'Session terminée, inactive ou suspendue. Action refusée.' });
    }

    let existingMap = (assignment.currentCodeMap && typeof assignment.currentCodeMap === 'object')
      ? { ...assignment.currentCodeMap }
      : {};

    // If batch map provided, update all problems
    if (fullCodeMap && typeof fullCodeMap === 'object') {
      Object.keys(fullCodeMap).forEach(pId => {
        const item = fullCodeMap[pId];
        let codeStr = '';
        if (typeof item === 'string') codeStr = item;
        else if (item && typeof item === 'object' && item.code) codeStr = item.code;

        if (codeStr !== undefined) {
          existingMap[pId] = {
            code: codeStr,
            language: language || 'ALGO',
            savedAt: new Date().toISOString()
          };
        }
      });
      console.log(`📝 [STUDENT BATCH AUTOSAVE] Assignment: ${assignmentId} | Problems Saved: ${Object.keys(fullCodeMap).length}`);
    } else if (problemId && code !== undefined) {
      existingMap[problemId] = {
        code,
        language: language || 'ALGO',
        savedAt: new Date().toISOString()
      };
      console.log(`📝 [STUDENT CODE AUTOSAVED] Assignment: ${assignmentId} | Problem: ${problemId}`);
    }

    await withRetry(() => prisma.examAssignment.update({
      where: { id: assignmentId },
      data: { currentCodeMap: existingMap }
    }));

    return res.json({ success: true, savedAt: new Date().toISOString() });
  } catch (err) {
    console.error('autosaveCode error:', err);
    return res.status(500).json({ error: 'Autosave failed' });
  }
}

// Run sample code against public test cases
async function runSampleCode(req, res) {
  try {
    const { sourceCode, language, inputData } = req.body;

    if (!sourceCode) {
      return res.status(400).json({ error: 'sourceCode is required' });
    }

    // Check student session active status if running within student exam context
    if (req.studentExamSession?.assignmentId) {
      const { assignmentId } = req.studentExamSession;
      const assignment = await prisma.examAssignment.findUnique({ where: { id: assignmentId } });
      if (!assignment || ['FINISHED', 'KICKED_OUT', 'ABSENT', 'PAUSED'].includes(assignment.status)) {
        return res.status(403).json({ error: 'EXAM_INACTIVE', message: 'Session inactive ou suspendue. Execution refusée.' });
      }
    }

    const result = await runCodeSingle(sourceCode, language || 'ALGO', inputData || '', 3000);
    return res.json(result);
  } catch (err) {
    console.error('runSampleCode error:', err);
    return res.status(500).json({ error: 'Code execution error' });
  }
}

// Submit solution for a problem
async function submitSolution(req, res) {
  try {
    const { studentId, examId, assignmentId } = req.studentExamSession;
    const { problemId, language, sourceCode } = req.body;

    if (!problemId || !sourceCode) {
      return res.status(400).json({ error: 'problemId and sourceCode are required' });
    }

    const assignment = await prisma.examAssignment.findUnique({
      where: { id: assignmentId },
      include: { exam: true }
    });

    if (!assignment || ['FINISHED', 'KICKED_OUT', 'ABSENT', 'PAUSED'].includes(assignment.status)) {
      return res.status(403).json({ error: 'Cannot submit. Exam session is inactive, suspended, or closed.' });
    }

    // Fetch problem test cases
    const problem = await prisma.problem.findUnique({
      where: { id: problemId },
      include: { testCases: true }
    });

    if (!problem) {
      return res.status(404).json({ error: 'Problem not found' });
    }

    // Evaluate code against all test cases
    const evalResult = await evaluateSubmission(
      sourceCode,
      language || 'ALGO',
      problem.testCases,
      problem.timeLimitMs || 2000
    );

    // Record submission
    const submission = await prisma.submission.create({
      data: {
        examId,
        studentId,
        problemId,
        language: language || 'ALGO',
        sourceCode,
        status: evalResult.status,
        score: evalResult.score,
        passedTests: evalResult.passedTests,
        totalTests: evalResult.totalTests,
        executionMs: evalResult.executionMs,
        stderr: evalResult.stderr
      }
    });

    // Broadcast live submission event via socket
    if (req.io) {
      req.io.to(`exam_${examId}`).emit('student_submitted', {
        studentId,
        problemId,
        status: evalResult.status,
        score: evalResult.score,
        timestamp: new Date()
      });
    }

    return res.json(submission);
  } catch (err) {
    console.error('submitSolution error:', err);
    return res.status(500).json({ error: 'Submission failed' });
  }
}

// Log anti-cheating monitoring violation event
async function logMonitoringEvent(req, res) {
  try {
    const { studentId, examId, assignmentId } = req.studentExamSession;
    const { eventType, severity, problemId, metadata } = req.body;

    if (!eventType) {
      return res.status(400).json({ error: 'eventType is required' });
    }

    // Log event
    const event = await prisma.monitoringEvent.create({
      data: {
        examId,
        studentId,
        eventType,
        severity: severity || 'MEDIUM',
        problemId: problemId || null,
        metadata: metadata || {}
      }
    });

    const isFsExit = (eventType === 'FULLSCREEN_EXIT');
    const updateData = {};
    if (['MEDIUM', 'HIGH', 'CRITICAL'].includes(severity || 'MEDIUM')) {
      updateData.violations = { increment: 1 };
    }
    if (isFsExit) {
      updateData.fullscreenExits = { increment: 1 };
    }

    let assignment = null;
    if (Object.keys(updateData).length > 0) {
      assignment = await prisma.examAssignment.update({
        where: { id: assignmentId },
        data: updateData,
        include: { student: true, exam: true }
      });
    } else {
      assignment = await prisma.examAssignment.findUnique({
        where: { id: assignmentId },
        include: { student: true, exam: true }
      });
    }

    // ── 3-strike auto-suspend on FULLSCREEN_EXIT ──
    if (isFsExit && assignment.fullscreenExits >= 3 && assignment.status === 'IN_EXAM') {
      assignment = await prisma.examAssignment.update({
        where: { id: assignmentId },
        data: { status: 'PAUSED' },
        include: { student: true, exam: true }
      });

      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_locked', {
          reason: 'Session suspendue : vous avez quitté le plein écran 3 fois (limite max : 3). Attendez l\'enseignant.'
        });
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: assignment.accessNumber,
          studentName: `${assignment.student.firstName} ${assignment.student.lastName}`,
          status: 'PAUSED',
          isOnline: assignment.isOnline,
          eventType: 'FS_EXITS_EXCEEDED'
        });
      }
    }

    // ── Auto-suspend at 4 warnings threshold (and every 4 warnings: 4, 8, 12...) ──
    if (assignment.violations >= 4 && assignment.violations % 4 === 0 && assignment.status === 'IN_EXAM') {
      assignment = await prisma.examAssignment.update({
        where: { id: assignmentId },
        data: { status: 'PAUSED' },
        include: { student: true, exam: true }
      });

      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_locked', {
          reason: `Votre session a été suspendue automatiquement après ${assignment.violations} avertissements. Contactez l'enseignant pour être débloqué.`
        });
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: assignment.accessNumber,
          studentName: `${assignment.student.firstName} ${assignment.student.lastName}`,
          status: 'PAUSED',
          isOnline: assignment.isOnline
        });
      }
    }

    // Broadcast live monitoring event to teacher socket room
    if (req.io && assignment) {
      req.io.to(`exam_${examId}`).emit('live_monitoring_event', {
        studentId,
        studentName: `${assignment.student.firstName} ${assignment.student.lastName}`,
        accessNumber: assignment.accessNumber,
        eventType,
        severity: severity || 'MEDIUM',
        problemId,
        violations: assignment.violations,
        fullscreenExits: assignment.fullscreenExits,
        timestamp: new Date()
      });

      // Also send status update so teacher UI updates violation count immediately
      req.io.to(`exam_${examId}`).emit('student_status_changed', {
        studentId,
        accessNumber: assignment.accessNumber,
        studentName: `${assignment.student.firstName} ${assignment.student.lastName}`,
        status: assignment.status,
        isOnline: assignment.isOnline,
        violations: assignment.violations,
        fullscreenExits: assignment.fullscreenExits
      });
    }

    return res.json(event);
  } catch (err) {
    console.error('logMonitoringEvent error:', err);
    return res.status(500).json({ error: 'Failed to log monitoring event' });
  }
}

// Finalize student exam submission — clears online presence, signals client to invalidate token
async function finalizeExam(req, res) {
  try {
    const { assignmentId, studentId, examId } = req.studentExamSession;

    const assignment = await prisma.examAssignment.findUnique({
      where: { id: assignmentId },
      include: { student: true }
    });

    if (!assignment) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    // Idempotent — already finished
    if (assignment.status === 'FINISHED') {
      return res.json({ success: true, finishedAt: assignment.finishedAt, invalidateToken: true });
    }

    // Persist & Evaluate all autosaved code from currentCodeMap into Submission table for every problem
    if (assignment.currentCodeMap && typeof assignment.currentCodeMap === 'object') {
      const examProblems = await prisma.examProblem.findMany({
        where: { examId },
        include: { problem: { include: { testCases: true } } }
      });

      for (const ep of examProblems) {
        const prob = ep.problem;
        const problemId = prob.id;
        const codeData = assignment.currentCodeMap[problemId];
        let code = '';
        if (typeof codeData === 'string') code = codeData;
        else if (codeData && typeof codeData === 'object' && codeData.code) code = codeData.code;

        if (code && code.trim()) {
          console.log(`✅ [EXAM FINALIZED - SAVED SOLUTION] Student: ${studentId} | Problem: ${problemId}\n${code}`);

          let evalRes = { status: 'SUBMITTED', score: 0, passedTests: 0, totalTests: prob.testCases?.length || 0 };
          if (prob.testCases && prob.testCases.length > 0) {
            try {
              evalRes = await evaluateSubmission(code, 'ALGO', prob.testCases, prob.timeLimitMs || 2000);
            } catch (e) {
              console.error('Eval error during finalizeExam:', e);
            }
          }

          const existingSub = await prisma.submission.findFirst({
            where: { examId, studentId, problemId }
          });

          if (!existingSub) {
            await prisma.submission.create({
              data: {
                examId,
                studentId,
                problemId,
                language: 'ALGO',
                sourceCode: code,
                status: evalRes.status,
                score: evalRes.score,
                passedTests: evalRes.passedTests,
                totalTests: evalRes.totalTests
              }
            });
          } else {
            await prisma.submission.update({
              where: { id: existingSub.id },
              data: {
                sourceCode: code,
                status: evalRes.status,
                score: evalRes.score,
                passedTests: evalRes.passedTests,
                totalTests: evalRes.totalTests
              }
            });
          }
        }
      }
    }

    const updated = await prisma.examAssignment.update({
      where: { id: assignmentId },
      data: {
        status:     'FINISHED',
        finishedAt: new Date(),
        isOnline:   false
      }
    });

    // Persist SUBMITTED event
    await prisma.monitoringEvent.create({
      data: {
        examId,
        studentId,
        eventType: 'SUBMITTED',
        severity:  'LOW',
        metadata:  { finishedAt: updated.finishedAt }
      }
    });

    if (req.io) {
      const studentName = `${assignment.student.firstName} ${assignment.student.lastName}`;

      // Notify teacher monitoring table
      req.io.to(`exam_${examId}`).emit('student_status_changed', {
        studentId,
        accessNumber: assignment.accessNumber,
        studentName,
        status:    'FINISHED',
        isOnline:  false,
        lastSeenAt: updated.finishedAt
      });

      req.io.to(`exam_${examId}`).emit('student_finished', {
        studentId,
        studentName,
        finishedAt: updated.finishedAt
      });
    }

    // Signal client to remove JWT — prevents re-entry
    return res.json({ success: true, finishedAt: updated.finishedAt, invalidateToken: true });
  } catch (err) {
    console.error('finalizeExam error:', err);
    return res.status(500).json({ error: 'Failed to finalize exam' });
  }
}

async function validateCodeSyntax(req, res) {
  try {
    const { sourceCode } = req.body;
    const result = await validateSyntax(sourceCode || '');
    return res.json(result);
  } catch (_) {
    return res.json({ errors: [] });
  }
}

module.exports = {
  getStudentExamWorkspace,
  autosaveCode,
  runSampleCode,
  submitSolution,
  logMonitoringEvent,
  finalizeExam,
  validateCodeSyntax
};
