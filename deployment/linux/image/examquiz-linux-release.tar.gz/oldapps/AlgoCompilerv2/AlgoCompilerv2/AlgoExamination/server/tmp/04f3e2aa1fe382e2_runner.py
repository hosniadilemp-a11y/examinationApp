
import sys, os, builtins, io

# Apply OS process limits (CPU limit, memory limit, process limit)
try:
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (3, 4))
    resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_NPROC, (20, 20))
except Exception:
    pass

_raw_stdin = sys.stdin.read()
sys.stdin = io.StringIO(_raw_stdin)

sys.path.insert(0, '/home/adel/Documents/Coding and projects/AlgoCompilerv2/AlgoCompiler/src')
sys.path.insert(0, '/home/adel/Documents/Coding and projects/AlgoCompilerv2/AlgoExamination/server/src/runner')
from compiler.parser import compile_algo
from french_exception_translator import translate_exception

with open('/home/adel/Documents/Coding and projects/AlgoCompilerv2/AlgoExamination/server/tmp/04f3e2aa1fe382e2.algo', 'r', encoding='utf-8') as f:
    code = f.read()

res = compile_algo(code)
if isinstance(res, tuple):
    py_code, errors = res
    if errors:
        formatted_errs = []
        for e in errors:
            if isinstance(e, dict):
                line = e.get('line', 1)
                col = e.get('column', 1)
                msg = e.get('message', 'Erreur de syntaxe')
                err_code = e.get('error_code', 'E2.1')
                formatted_errs.append(f"Ligne {line}, Colonne {col} [{err_code}] : {msg}")
            else:
                formatted_errs.append(str(e))
        sys.stderr.write('\n'.join(formatted_errs) + '\n')
        sys.exit(1)
else:
    py_code = res

if not py_code:
    sys.stderr.write('Erreur de syntaxe algorithmique\n')
    sys.exit(1)

try:
    exec(py_code, globals())
except Exception as e:
    french_err = translate_exception(e, py_code, code)
    sys.stderr.write(french_err + '\n')
    sys.exit(1)
