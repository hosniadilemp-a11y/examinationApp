import React, { useState, useEffect } from 'react';
import { listStudents, createStudent, importStudentsCSV } from '../services/api';
import { Users, Upload, Plus, FileSpreadsheet, ArrowLeft, Download, Printer } from 'lucide-react';
import Swal from 'sweetalert2';
import FileDropZone from './FileDropZone';

export default function StudentManager({ onBack }) {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [csvText, setCsvText] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newStudent, setNewStudent] = useState({
    studentId: '',
    firstName: '',
    lastName: '',
    group: 'G1',
    speciality: 'Computer Science'
  });

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const data = await listStudents();
      setStudents(data);
    } catch (err) {
      console.error('fetchStudents error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCSVImport = async () => {
    if (!csvText.trim()) return;
    try {
      const res = await importStudentsCSV(csvText);
      Swal.fire({
        icon: 'success',
        title: 'Importation Réussie',
        text: res.message,
        background: '#111827',
        color: '#ffffff'
      });
      setCsvText('');
      fetchStudents();
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Erreur', text: err.data?.error || 'Échec de l’importation CSV', background: '#111827', color: '#ffffff' });
    }
  };

  const handleAddStudent = async (e) => {
    e.preventDefault();
    try {
      await createStudent(newStudent);
      setShowAddModal(false);
      setNewStudent({ studentId: '', firstName: '', lastName: '', group: 'G1', speciality: 'Computer Science' });
      fetchStudents();
      Swal.fire({ icon: 'success', title: 'Étudiant ajouté !', timer: 1500, showConfirmButton: false, background: '#111827', color: '#ffffff' });
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Erreur', text: err.data?.error || 'Échec de la création', background: '#111827', color: '#ffffff' });
    }
  };

  return (
    <div style={{ padding: '30px', maxWidth: '1200px', margin: '0 auto' }}>
      <button className="btn btn-secondary" onClick={onBack} style={{ marginBottom: '20px' }}>
        <ArrowLeft size={16} /> Retour au Dashboard
      </button>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' }}>
        <div>
          <h2>Gestion des Étudiants</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
            Importation par fichier CSV ou inscription manuelle.
          </p>
        </div>

        <button className="btn btn-primary" onClick={() => setShowAddModal(true)}>
          <Plus size={16} /> Ajouter un Étudiant
        </button>
      </div>

      {/* CSV Import Panel */}
      <div className="glass-panel" style={{ padding: '20px', marginBottom: '25px' }}>
        <h3 style={{ fontSize: '1.1rem', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Upload size={18} color="#60a5fa" /> Importation Massives par Fichier ou Texte CSV
        </h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '12px' }}>
          Colonnes recommandées: <code>StudentID, FirstName, LastName, Group, Speciality, AcademicYear</code>
        </p>

        <FileDropZone
          accept=".csv,.txt"
          label="Glissez & déposez votre fichier CSV ici"
          hint="ou collez votre texte ci-dessous"
          onFileSelect={(file) => {
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (e) => setCsvText((e.target.result || '').replace(/^\uFEFF+/, ''));
            reader.readAsText(file);
          }}
          style={{ marginBottom: '14px' }}
        />

        <textarea
          className="form-textarea"
          rows={3}
          placeholder={"StudentID,FirstName,LastName,Group,Speciality,AcademicYear\n2026001,Ahmed,BENALI,G1,Computer Science,2026\n2026002,Sara,KHELIFI,G1,Computer Science,2026"}
          value={csvText}
          onChange={(e) => setCsvText(e.target.value)}
        />

        <button className="btn btn-success" onClick={handleCSVImport} style={{ marginTop: '10px' }}>
          <FileSpreadsheet size={16} /> Importer les Données CSV
        </button>
      </div>

      {/* Student List Table */}
      <div className="glass-panel" style={{ padding: '24px' }}>
        <h3>Liste des Étudiants Inscrits ({students.length})</h3>

        <table className="data-table">
          <thead>
            <tr>
              <th>ID Étudiant</th>
              <th>Nom & Prénom</th>
              <th>Groupe</th>
              <th>Spécialité</th>
              <th>Année Scolaire</th>
              <th>Date Inscription</th>
            </tr>
          </thead>
          <tbody>
            {students.map(s => (
              <tr key={s.id}>
                <td><code style={{ color: '#34d399', fontWeight: '700', fontFamily: 'var(--font-mono)' }}>{s.studentId}</code></td>
                <td><strong>{s.lastName} {s.firstName}</strong></td>
                <td>{s.group}</td>
                <td>{s.speciality}</td>
                <td><span className="badge badge-info">{s.academicYear || 2026}</span></td>
                <td>{new Date(s.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Student Modal */}
      {showAddModal && (
        <div className="fullscreen-overlay" style={{ background: 'rgba(0,0,0,0.8)' }}>
          <div className="glass-panel" style={{ width: '100%', maxWidth: '440px', padding: '30px' }}>
            <h3 style={{ marginBottom: '20px' }}>Ajouter un Étudiant</h3>
            <form onSubmit={handleAddStudent}>
              <div className="form-group">
                <label>ID / N° Carte Étudiant</label>
                <input className="form-input" required value={newStudent.studentId} onChange={e => setNewStudent({ ...newStudent, studentId: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Prénom</label>
                <input className="form-input" required value={newStudent.firstName} onChange={e => setNewStudent({ ...newStudent, firstName: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Nom</label>
                <input className="form-input" required value={newStudent.lastName} onChange={e => setNewStudent({ ...newStudent, lastName: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Groupe</label>
                <input className="form-input" required value={newStudent.group} onChange={e => setNewStudent({ ...newStudent, group: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Spécialité</label>
                <input className="form-input" required value={newStudent.speciality} onChange={e => setNewStudent({ ...newStudent, speciality: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Année Scolaire (ex: 2026)</label>
                <input className="form-input" type="number" value={newStudent.academicYear || ''} placeholder="Auto (ex: 2026)" onChange={e => setNewStudent({ ...newStudent, academicYear: e.target.value })} />
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)} style={{ flex: 1 }}>Annuler</button>
                <button type="submit" className="btn btn-primary" style={{ flex: 1 }}>Enregistrer</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
