# AlgoExamination — Pseudo-Code Execution Rules

## Service

`server/src/runner/code-execution.service.js`

## Purpose

The runner translates supported pseudo-code into executable JavaScript and evaluates test cases.

Current keyword family includes:

```text
ALGORITHME
VARIABLES
DEBUT
FIN
SI
POUR
TANTQUE
ECRIRE
LIRE
```

## Security Principle

Student code is untrusted input.

Never execute generated student code directly inside the main Express process.

The current architecture uses a child-process based execution mechanism.

## Resource Limits

When changing the runner, consider:
- execution timeout
- memory use
- output size
- process count
- infinite loops
- recursive behavior
- malformed syntax

A student algorithm must not be able to permanently block the server.

## Translation Rules

Pseudo-code translation must be deterministic.

Do not perform unsafe global replacements that alter:
- variable names
- strings
- comments
- substrings

Example of a dangerous strategy:

```text
replace every occurrence of "SI"
```

because a variable or string may contain those letters.

Prefer token-aware processing.

## Test Runner

A test case should distinguish:
- syntax failure
- execution timeout
- runtime error
- wrong output
- correct output

Do not report every failure as "wrong answer."

## Backward Compatibility

Existing student algorithms may depend on currently supported syntax.

When adding syntax:
- preserve old syntax
- add tests
- avoid breaking existing keywords
