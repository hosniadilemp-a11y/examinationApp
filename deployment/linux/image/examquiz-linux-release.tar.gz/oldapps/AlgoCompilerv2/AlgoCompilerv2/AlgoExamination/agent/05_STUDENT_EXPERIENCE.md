# AlgoExamination — Student Experience

## Components

- `StudentLogin.jsx`
- `StudentDashboard.jsx`
- `WaitingRoom.jsx`
- `ExamWorkspace.jsx`
- `ExamCompleted.jsx`

## Student Flow

```text
Login
  ↓
Student Dashboard
  ↓
Available Exam
  ↓
Waiting Room
  ↓
Fullscreen Gate
  ↓
Teacher Launch
  ↓
Exam Workspace
  ↓
Autosave
  ↓
Submit / Time Expiry / Teacher Force Finish
  ↓
Exam Completed
```

## WaitingRoom Reliability

WaitingRoom uses:
- fullscreen validation
- Socket.IO
- approximately 3-second polling fallback
- reconnect handling

Do not remove polling simply because sockets work in development.

The polling exists to recover from missed socket events.

## Exam Workspace

Responsibilities:
- problem tabs
- pseudo-code editor
- template loading
- sample execution
- test cases
- countdown
- autosave
- anti-cheat
- teacher commands

## Autosave

Autosave must be:
- periodic
- associated with the correct assignment
- associated with problem IDs
- resilient to transient network errors

Do not overwrite the entire code map with stale local state.

When implementing autosave changes, inspect race conditions between:
- typing
- timer
- save request
- reconnect
- teacher termination

## Timer

The browser timer is for display and UX.

It must not be the sole authority for exam completion.

Server state/time must remain authoritative.

## Teacher Commands

Student workspace must react to:
- `student_locked`
- `student_unlocked`
- `student_terminated`
- `exam_force_ended`

Termination must not depend solely on the student clicking something.

## Student Identity

The student's name must remain visible wherever the current UI requires it.

Never replace a real student identity with:
- generic "Student"
- access number only
- stale cached name

without a deliberate fallback.

## Failure Cases to Preserve

Test:
- socket disconnect
- browser refresh
- missed `exam_started`
- missed termination event
- temporary API failure
- fullscreen exit
- time expiry
- teacher pause/resume
