# 08. Spécification Multi-Questions, Zones Verrouillées & Évaluation AST Pondérée

Ce document résume l'extension fonctionnelle complète de la plateforme AlgoExamination définie dans `extensions.txt`.

---

## 📑 Index des Plans Détaillés

1. [Plan 1 : Architecture Système & Modélisation des Données](file:///home/adel/Documents/Coding%20and%20projects/AlgoCompilerv2/AlgoExamination/doc/PLAN_ARCHITECTURE_AND_MODELS.md)
2. [Plan 2 : Feuille de Route d'Implémentation par Phases](file:///home/adel/Documents/Coding%20and%20projects/AlgoCompilerv2/AlgoExamination/doc/PLAN_PHASED_IMPLEMENTATION_ROADMAP.md)
3. [Plan 3 : Matrice de Vérification, Cas Limites & Sécurité](file:///home/adel/Documents/Coding%20and%20projects/AlgoCompilerv2/AlgoExamination/doc/PLAN_VERIFICATION_AND_SAFETY_MATRIX.md)

---

## 🎯 Résumé des 8 Piliers de l'Extension

| # | Pilier Fonctionnel | Description Clé | Composants Touchés |
| :---: | :--- | :--- | :--- |
| **0** | **Importation en Masse** | Import et découpage automatique des ~62 exemples de `AlgoCompiler/examples`. | `import_examples.js` |
| **1** | **Entité `ProblemQuestion`** | Modélisation des sous-questions ($N$ questions par problème) avec backfill idempotent. | `schema.prisma`, `prisma.js` |
| **2** | **Problem Studio Multi-Questions** | Gestion des questions ($1$ vs $N$), édition Markdown par question, badges d'état. | `ProblemStudio.jsx`, `ProblemBank.jsx` |
| **3** | **Outil d'Insertion des Marqueurs** | Insertion manuelle dans l'éditeur de code des balises `// question N starts/ends here`. | `ProblemStudio.jsx` |
| **4** | **Verrouillage Côté Étudiant** | Lignes de marqueurs non supprimables et protégées dans CodeMirror 6 + sécurité serveur. | `ExamWorkspace.jsx`, `student.controller.js` |
| **5** | **Barème par Sous-Question** | Répartition des points par question sans réinitialisation des points existants. | `ExamManager.jsx`, `exam.controller.js` |
| **6** | **Pondérations Tripartites** | Configuration uniforme par problème : **Tests (40%) / AST (60%) / IA (0%)** (Somme = 100%). | `ExamManager.jsx`, `grading.controller.js` |
| **7** | **AST Slicing & Notation Indépendante** | Découpage du code par question et calcul AST isolé, agrégé par moyenne pondérée. | `ast-similarity.service.js`, `CorrectionWorkspace.jsx` |
