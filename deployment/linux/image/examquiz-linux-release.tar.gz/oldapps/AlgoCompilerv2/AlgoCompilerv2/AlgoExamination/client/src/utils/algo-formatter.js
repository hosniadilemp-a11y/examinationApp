/**
 * AlgoCompiler-Compliant Pseudo-Code Formatter
 * Formats French Algorithmic code according to AlgoCompiler grammar rules.
 */
export function formatAlgoCode(code) {
  if (!code || typeof code !== 'string') return '';

  const lines = code.split(/\r?\n/);
  let indentLevel = 0;

  const formattedLines = lines.map(rawLine => {
    const trimmed = rawLine.trim();
    if (!trimmed) return '';

    const codePart = trimmed.replace(/\/\/.*$/, '').replace(/\/\*[\s\S]*?\*\//, '').trim();
    const upper = codePart.toUpperCase();

    // Check block closers
    const isFinDot = /^FIN\.$/i.test(codePart);
    const isFinGeneral = /^(FIN|FINSI|FSI|FIN_POUR|FINPOUR|FIN_TANT_QUE|FINTANTQUE|JUSQUA|FINSTRUCTURE|FINPROCEDURE|FINFONCTION)(?:;|\s|$)/i.test(upper);
    const isDebut = /^(DEBUT)(?:;|\s|$)/i.test(upper);
    const isSinon = /^(SINON)(?:;|\s|$)/i.test(upper);

    if (isFinDot) {
      indentLevel = 0;
    } else if (isDebut) {
      indentLevel = 0; // DEBUT aligns with ALGORITHME at level 0
    } else if (isFinGeneral) {
      indentLevel = Math.max(0, indentLevel - 1);
    }

    const currentLineIndent = isSinon ? Math.max(0, indentLevel - 1) : indentLevel;
    const indentedLine = '   '.repeat(currentLineIndent) + trimmed;

    // Check block openers
    const isVar = /^(VAR|VARIABLES)(?:;|\s|$)/i.test(upper);
    const isBlockOpener = /^(POUR|TANT_QUE|TANTQUE|SI|REPETER|FONCTION|PROCEDURE)(?:\s|;|\(|$)/i.test(upper) ||
                          /=(?:\s*)ENREGISTREMENT/i.test(upper);

    if (isDebut || isVar || isBlockOpener) {
      indentLevel++;
    }

    return indentedLine;
  });

  return formattedLines.join('\n');
}
