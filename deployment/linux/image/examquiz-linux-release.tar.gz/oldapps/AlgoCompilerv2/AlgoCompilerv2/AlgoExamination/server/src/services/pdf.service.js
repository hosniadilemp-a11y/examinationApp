const PDFDocument = require('pdfkit');
const QRCode = require('qrcode');
const crypto = require('crypto');
const {
  sliceCodeByQuestionMarkers,
  computeMultiQuestionExerciseScore,
  calculateCodeSimilarity,
  isUntouchedTemplateCode
} = require('../runner/ast-similarity.service');

const JWT_SECRET = process.env.JWT_SECRET || 'algoexamination_secret_jwt_key_2026_super_secure';

function formatPts(val) {
  if (val === null || val === undefined || isNaN(parseFloat(val))) return '0';
  const num = parseFloat(val);
  return Number.isInteger(num) ? String(num) : String(Math.round(num * 100) / 100);
}

function computeAuthenticitySignature(assignmentId, studentId, score20) {
  const dataToSign = `${assignmentId}|${studentId}|${score20}`;
  return crypto.createHmac('sha256', JWT_SECRET).update(dataToSign).digest('hex');
}

function verifyQRPayload(payloadStr) {
  try {
    let payload = payloadStr;
    if (typeof payloadStr === 'string') {
      payload = JSON.parse(payloadStr);
    }
    const { assignmentId, studentId, grade20, signature } = payload;
    if (!assignmentId || !studentId || !grade20 || !signature) {
      return { valid: false, message: 'Structure du QR code incomplète ou invalide.' };
    }

    const expected = computeAuthenticitySignature(assignmentId, studentId, grade20);
    if (signature === expected) {
      return {
        valid: true,
        message: 'Authenticité vérifiée ! Le document est officiel et conforme.',
        payload
      };
    } else {
      return { valid: false, message: 'Signature invalide ! Le document a été altéré ou falsifié.' };
    }
  } catch (err) {
    return { valid: false, message: 'Format du QR code illisible.' };
  }
}

function getAppreciation(score20) {
  const val = parseFloat(score20);
  if (isNaN(val)) return { text: 'Non évalué', mention: 'N/A' };
  if (val >= 18) return { text: 'Excellent travail, parfaite maîtrise des algorithmes.', mention: 'Très Bien' };
  if (val >= 16) return { text: 'Très bon résultat, code bien structuré.', mention: 'Très Bien' };
  if (val >= 14) return { text: 'Bonne prestation d\'ensemble.', mention: 'Bien' };
  if (val >= 12) return { text: 'Travail satisfaisant.', mention: 'Assez Bien' };
  if (val >= 10) return { text: 'Niveau moyen, quelques lacunes à corriger.', mention: 'Passable' };
  return { text: 'Résultats insuffisants, révisions requises.', mention: 'Ajourné' };
}

async function drawHeaderAndSummary(doc, { exam, assignment, student, grade20, mention, appreciation, signature, copyIndex, totalCopies }) {
  // Top Outer Border Box
  doc.rect(40, 32, 515, 108).lineWidth(1).strokeColor('#000000').stroke();

  // University & Module Header Titles in distinct clear lines
  const uniName = (exam.university || 'ÉCOLE NATIONALE SUPÉRIEURE D\'INFORMATIQUE').toUpperCase();
  const moduleInfo = exam.module ? `Module : ${exam.module}` : 'Module : Algorithmique et Structure de Données';
  const sessionInfo = exam.session ? ` — ${exam.session}` : '';

  doc.fillColor('#000000').fontSize(10).font('Helvetica-Bold').text(uniName, 50, 40, { width: 400 });
  doc.fillColor('#1e293b').fontSize(9).font('Helvetica-Bold').text(moduleInfo, 50, 54, { width: 400 });
  doc.fillColor('#000000').fontSize(11).font('Helvetica-Bold').text(`${exam.title}${sessionInfo}`, 50, 68, { width: 400 });
  doc.fillColor('#475569').fontSize(7.5).font('Helvetica').text(`Durée: ${exam.durationMinutes || 120} min | Date: ${exam.date ? new Date(exam.date).toLocaleDateString('fr-FR') : new Date(exam.createdAt || Date.now()).toLocaleDateString('fr-FR')}${copyIndex ? ` | Copie N° ${copyIndex} / ${totalCopies}` : ''}${exam.room ? ` | Salle: ${exam.room}` : ''}`, 50, 83, { width: 400 });

  // Student Info Line
  const isExamClosed = exam.status === 'CLOSED';
  const studentName = (isExamClosed && student)
    ? `${(student.lastName || '').toUpperCase()} ${student.firstName || ''}`
    : `Anonyme [${assignment.accessNumber || 'N/A'}]`;
  const matricule = isExamClosed ? (student?.studentId || 'N/A') : 'Anonyme';
  const group = isExamClosed ? (student?.group || 'N/A') : (assignment.room || 'Salle Examen');
  const accessCode = assignment.accessNumber || '—';

  doc.fillColor('#000000').fontSize(9).font('Helvetica-Bold').text(`Nom & Prénom : ${studentName}`, 50, 97, { width: 400 });
  doc.fillColor('#334155').fontSize(8).font('Helvetica').text(`Matricule : ${matricule}   |   Groupe : ${group}   |   Code Anonyme : ${accessCode}`, 50, 111, { width: 400 });
  doc.fillColor('#64748b').fontSize(7.5).font('Helvetica-Oblique').text(`Spécialité : ${isExamClosed ? (student?.speciality || 'Informatique') : 'Informatique'}   |   Statut : ${assignment.gradingStatus === 'GRADED' ? 'Corrigé & Validé' : 'En attente de validation'}`, 50, 124, { width: 400 });

  // QR Code Generation
  const qrDataObj = {
    institution: "Ecole Nationale Superieure d'Informatique (ESI)",
    exam: exam.title,
    student: studentName,
    studentId: matricule,
    accessNumber: accessCode,
    grade20: `${grade20}/20`,
    date: new Date().toLocaleDateString('fr-FR'),
    assignmentId: assignment.id,
    signature
  };
  const qrDataString = JSON.stringify(qrDataObj);
  const qrDataUrl = await QRCode.toDataURL(qrDataString, { errorCorrectionLevel: 'M', margin: 1, width: 95 });
  const qrBuffer = Buffer.from(qrDataUrl.split(',')[1], 'base64');
  doc.image(qrBuffer, 462, 38, { width: 85, height: 85 });

  // Score Summary Box
  doc.rect(40, 144, 515, 36).lineWidth(1).strokeColor('#000000').stroke();
  doc.fillColor('#000000').fontSize(8).font('Helvetica-Bold').text('NOTE OFFICIELLE ET APPRÉCIATION GÉNÉRALE :', 48, 149);
  doc.fillColor('#000000').fontSize(12).font('Helvetica-Bold').text(`NOTE FINALE : ${grade20} / 20`, 48, 161);
  doc.fillColor('#000000').fontSize(8.5).font('Helvetica-Bold').text(`Mention : ${mention}`, 215, 163);
  doc.fillColor('#334155').fontSize(7.5).font('Helvetica-Oblique').text(`"${appreciation}"`, 305, 163);
}

function drawRecoursSection(doc, startY) {
  let currentY = startY;

  // Header Box for Recours Section
  doc.rect(40, currentY, 515, 18).lineWidth(1).strokeColor('#000000').stroke();
  doc.fillColor('#000000').fontSize(8.5).font('Helvetica-Bold').text('SECTION RECOURS : DEMANDE DE RÉVISION ET DEUXIÈME CORRECTION', 48, currentY + 5);
  currentY += 21;

  // Enlarged Student Appeal Remark Box with ample ruled space
  doc.rect(40, currentY, 515, 75).lineWidth(0.8).strokeColor('#000000').stroke();
  doc.fillColor('#000000').fontSize(8).font('Helvetica-Bold').text('Motif du recours & Remarques formulées par l\'étudiant :', 46, currentY + 5);

  // 4 Ruled horizontal lines for comfortable student writing
  doc.moveTo(46, currentY + 22).lineTo(545, currentY + 22).lineWidth(0.4).strokeColor('#cbd5e1').stroke();
  doc.moveTo(46, currentY + 37).lineTo(545, currentY + 37).lineWidth(0.4).strokeColor('#cbd5e1').stroke();
  doc.moveTo(46, currentY + 52).lineTo(545, currentY + 52).lineWidth(0.4).strokeColor('#cbd5e1').stroke();
  doc.moveTo(46, currentY + 67).lineTo(545, currentY + 67).lineWidth(0.4).strokeColor('#cbd5e1').stroke();
  currentY += 79;

  // Teachers Regrading Table (Structured without text overlapping)
  doc.rect(40, currentY, 515, 54).lineWidth(0.8).strokeColor('#000000').stroke();

  // Teacher 1 row
  doc.fillColor('#000000').fontSize(8).font('Helvetica-Bold').text('1. Correcteur 1 :', 46, currentY + 6);
  doc.fillColor('#334155').fontSize(7.5).font('Helvetica').text('Nom : _________________________', 125, currentY + 6);
  doc.fillColor('#000000').fontSize(8).font('Helvetica-Bold').text('Note révisée : [  ____  / 20 ]', 315, currentY + 6);
  doc.fillColor('#334155').fontSize(7.5).font('Helvetica').text('Signature : ___________', 452, currentY + 6);

  // Teacher 2 row
  doc.fillColor('#000000').fontSize(8).font('Helvetica-Bold').text('2. Correcteur 2 :', 46, currentY + 22);
  doc.fillColor('#334155').fontSize(7.5).font('Helvetica').text('Nom : _________________________', 125, currentY + 22);
  doc.fillColor('#000000').fontSize(8).font('Helvetica-Bold').text('Note révisée : [  ____  / 20 ]', 315, currentY + 22);
  doc.fillColor('#334155').fontSize(7.5).font('Helvetica').text('Signature : ___________', 452, currentY + 22);

  // Commission Final Verdict Line
  doc.moveTo(40, currentY + 36).lineTo(555, currentY + 36).lineWidth(0.5).strokeColor('#64748b').stroke();
  doc.fillColor('#000000').fontSize(8).font('Helvetica-Bold').text('Décision Finale Commission :', 46, currentY + 41);
  doc.fillColor('#334155').fontSize(7.5).font('Helvetica').text('[   ] Note Maintenue     [   ] Note Modifiée   ->   NOTE DÉFINITIVE : [  _____  / 20 ]', 175, currentY + 41);

  currentY += 60;
  return currentY;
}

function drawExercises(doc, { problems, submissions, assignment, startY }) {
  let currentY = startY;

  for (let idx = 0; idx < problems.length; idx++) {
    const ep = problems[idx];
    const p = ep.problem;
    const sub = (submissions || []).find(s => s.problemId === p.id && (!s.studentId || s.studentId === assignment?.studentId || s.studentId === assignment?.student?.id))
      || (submissions || []).find(s => s.problemId === p.id);

    if (currentY > 640) {
      doc.addPage();
      currentY = 42;
    }

    // Bold Separation Line between Exercises
    if (idx > 0) {
      doc.moveTo(40, currentY).lineTo(555, currentY).lineWidth(1.2).strokeColor('#000000').stroke();
      currentY += 12;
    }

    const exMaxPts = ep.points || p.points || 1;
    const exScore = sub?.manualScore !== null && sub?.manualScore !== undefined
      ? parseFloat(sub.manualScore)
      : (sub?.score ? Math.round((sub.score / 100) * exMaxPts * 10) / 10 : 0);

    // Exercise Header Box
    doc.rect(40, currentY, 515, 22).lineWidth(0.8).strokeColor('#000000').stroke();
    doc.fillColor('#000000').fontSize(9.5).font('Helvetica-Bold').text(`EXERCICE ${idx + 1} : ${p.title.toUpperCase()} (${formatPts(exMaxPts)} PTS)`, 48, currentY + 6);
    doc.fillColor('#000000').fontSize(9.5).font('Helvetica-Bold').text(`Note Exercice : ${formatPts(exScore)} / ${formatPts(exMaxPts)} pts`, 385, currentY + 6);
    currentY += 28;

    // Resolve student source code (from submission or currentCodeMap)
    let submittedCode = sub?.sourceCode?.trim() || sub?.code?.trim();
    if (!submittedCode && assignment?.currentCodeMap) {
      let map = assignment.currentCodeMap;
      if (typeof map === 'string') {
        try { map = JSON.parse(map); } catch (_) {}
      }
      if (map && typeof map === 'object') {
        const val = map[p.id] || map[String(p.id)] || map[p.title];
        if (typeof val === 'string') submittedCode = val.trim();
        else if (val && typeof val === 'object' && val.code) submittedCode = val.code.trim();
      }
    }

    const hasSubmitted = !!(submittedCode && submittedCode.length > 0);
    const fullStudentCode = hasSubmitted ? submittedCode : '// Aucun code soumis par l\'étudiant pour cet exercice.';

    // Teacher line comments
    let lineComments = {};
    if (sub?.teacherFeedback) {
      try {
        const parsed = JSON.parse(sub.teacherFeedback);
        if (parsed.lineComments) lineComments = parsed.lineComments;
      } catch (e) {}
    }

    // Question slicing & AST calculation
    const hasMultiQuestions = Array.isArray(p.questions) && p.questions.length > 1;
    const studentSlices = sliceCodeByQuestionMarkers(fullStudentCode);

    // Compute multi-question / AST evaluation
    let evalBreakdown = null;
    try {
      evalBreakdown = computeMultiQuestionExerciseScore({
        studentCode: fullStudentCode,
        referenceSolution: p.referenceSolution || '',
        starterTemplate: p.starterTemplate || '',
        problemPoints: exMaxPts,
        totalTests: (p.testCases?.length || p.publicTestCases?.length || 0),
        passedTests: sub?.passedTests ?? sub?.testCasesPassed ?? 0,
        questions: p.questions || [],
        questionPoints: p.questionPoints || {},
        weightTest: ep.weightTest ?? 40,
        weightAst: ep.weightAst ?? 60,
        weightAi: ep.weightAi ?? 0,
        aiScore: sub?.aiScore || 0
      });
    } catch (e) {
      evalBreakdown = null;
    }

    if (hasMultiQuestions) {
      // Draw question-by-question solution and clean scores
      p.questions.forEach((q, qIdx) => {
        const qNum = q.orderIndex || (qIdx + 1);
        const qId = q.id || qNum;
        const qMaxPts = (p.questionPoints && (p.questionPoints[qId] ?? p.questionPoints[qNum])) || Math.max(1, exMaxPts / p.questions.length);
        const qBreakdown = evalBreakdown?.questionsBreakdown?.find(qb => qb.orderIndex === qNum) || evalBreakdown?.questionsBreakdown?.[qIdx];
        const qAwardedPts = qBreakdown?.pointsAwarded ?? (sub?.manualScore != null ? (exScore / p.questions.length) : 0);

        if (currentY > 640) {
          doc.addPage();
          currentY = 42;
        }

        const qSliceCode = studentSlices[qNum] || fullStudentCode;
        const qLines = qSliceCode.split('\n');

        // Question header bar
        doc.rect(40, currentY, 515, 18).lineWidth(0.5).strokeColor('#475569').stroke();
        doc.fillColor('#000000').fontSize(8.5).font('Helvetica-Bold').text(`Question ${qNum} : ${q.statement?.substring(0, 75) || `Sous-problème ${qNum}`} (${formatPts(qMaxPts)} pts)`, 46, currentY + 5);
        doc.fillColor('#1e293b').fontSize(8.5).font('Helvetica-Bold').text(`Note : ${formatPts(qAwardedPts)} / ${formatPts(qMaxPts)} pts`, 405, currentY + 5);
        currentY += 22;

        // Question Code Box
        const codeBoxHeight = Math.min(260, Math.max(35, qLines.length * 12 + 10));
        doc.rect(40, currentY, 515, codeBoxHeight).lineWidth(0.6).strokeColor('#94a3b8').stroke();
        let lineY = currentY + 5;

        qLines.forEach((line, lIdx) => {
          if (lineY > currentY + codeBoxHeight - 11) return;
          const lineNum = lIdx + 1;
          doc.fillColor('#64748b').fontSize(8).font('Courier').text(String(lineNum).padStart(2, ' '), 46, lineY);
          doc.fillColor('#000000').fontSize(8).font('Courier').text(line, 68, lineY);
          lineY += 12;

          if (lineComments[lineNum]) {
            doc.fillColor('#0f172a').fontSize(7.5).font('Helvetica-Bold').text(`   >> Remarque Enseignant : ${lineComments[lineNum]}`, 68, lineY);
            lineY += 13;
          }
        });

        currentY += codeBoxHeight + 8;
      });
    } else {
      // Single question exercise display (Clean header with code and note)
      doc.fillColor('#000000').fontSize(8.5).font('Helvetica-Bold').text(`Code source rédigé par l'étudiant :`, 46, currentY);
      doc.fillColor('#000000').fontSize(8.5).font('Helvetica-Bold').text(`Note : ${formatPts(exScore)} / ${formatPts(exMaxPts)} pts`, 405, currentY);
      currentY += 13;

      const codeLines = fullStudentCode.split('\n');
      const codeBoxHeight = Math.min(300, Math.max(45, codeLines.length * 12 + Object.keys(lineComments).length * 14 + 10));

      doc.rect(40, currentY, 515, codeBoxHeight).lineWidth(0.8).strokeColor('#000000').stroke();
      let lineY = currentY + 5;

      codeLines.forEach((line, lIdx) => {
        if (lineY > currentY + codeBoxHeight - 11) return;
        const lineNum = lIdx + 1;
        doc.fillColor('#64748b').fontSize(8).font('Courier').text(String(lineNum).padStart(2, ' '), 46, lineY);
        doc.fillColor('#000000').fontSize(8).font('Courier').text(line, 68, lineY);
        lineY += 12;

        if (lineComments[lineNum]) {
          doc.fillColor('#0f172a').fontSize(7.5).font('Helvetica-Bold').text(`   >> Remarque Enseignant : ${lineComments[lineNum]}`, 68, lineY);
          lineY += 14;
        }
      });

      currentY += codeBoxHeight + 10;
    }
  }

  return currentY;
}

// Single Student Copy PDF Generator
async function generateStudentCopyPDFData({ exam, assignment, student, problems, submissions }) {
  return new Promise(async (resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 40, size: 'A4' });
      const buffers = [];
      doc.on('data', b => buffers.push(b));
      doc.on('end', () => resolve(Buffer.concat(buffers)));

      let totalRawEarned = 0;
      let totalMaxPoints = 0;
      problems.forEach(ep => {
        const p = ep.problem;
        totalMaxPoints += (ep.points || p.points || 0);
        const sub = (submissions || []).find(s => s.problemId === p.id);
        if (sub && sub.manualScore !== null && sub.manualScore !== undefined) {
          totalRawEarned += parseFloat(sub.manualScore) || 0;
        } else if (sub && sub.score > 0) {
          totalRawEarned += (sub.score / 100) * (ep.points || p.points || 0);
        }
      });

      const grade20 = totalMaxPoints > 0 ? ((totalRawEarned / totalMaxPoints) * 20).toFixed(2) : '0.00';
      const { text: appreciation, mention } = getAppreciation(grade20);
      const signature = computeAuthenticitySignature(assignment.id, student?.id || assignment.accessNumber, grade20);

      await drawHeaderAndSummary(doc, { exam, assignment, student, grade20, mention, appreciation, signature });
      const afterRecoursY = drawRecoursSection(doc, 185);
      drawExercises(doc, { problems, submissions, assignment, startY: afterRecoursY });

      doc.moveTo(40, 785).lineTo(555, 785).lineWidth(0.5).strokeColor('#cbd5e1').stroke();
      doc.fillColor('#475569').fontSize(7.5).font('Helvetica-Oblique').text(`Document officiel d'évaluation - École Nationale Supérieure d'Informatique (ESI) - Signature HMAC: ${signature.substring(0, 20)}...`, 40, 792, { align: 'center' });

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

// Master All Student Copies PDF Generator
async function generateAllStudentCopiesPDFData({ exam, assignments, problems, submissions }) {
  return new Promise(async (resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 40, size: 'A4' });
      const buffers = [];
      doc.on('data', b => buffers.push(b));
      doc.on('end', () => resolve(Buffer.concat(buffers)));

      for (let aIdx = 0; aIdx < assignments.length; aIdx++) {
        const assignment = assignments[aIdx];
        const student = assignment.student;

        if (aIdx > 0) doc.addPage();

        const studentSubmissions = (submissions || []).filter(s => (s.studentId === student?.id || s.studentId === assignment.studentId));

        let totalRawEarned = 0;
        let totalMaxPoints = 0;
        problems.forEach(ep => {
          const p = ep.problem;
          totalMaxPoints += (ep.points || p.points || 0);
          const sub = studentSubmissions.find(s => s.problemId === p.id);
          if (sub && sub.manualScore !== null && sub.manualScore !== undefined) {
            totalRawEarned += parseFloat(sub.manualScore) || 0;
          } else if (sub && sub.score > 0) {
            totalRawEarned += (sub.score / 100) * (ep.points || p.points || 0);
          }
        });

        const grade20 = totalMaxPoints > 0 ? ((totalRawEarned / totalMaxPoints) * 20).toFixed(2) : '0.00';
        const { text: appreciation, mention } = getAppreciation(grade20);
        const signature = computeAuthenticitySignature(assignment.id, student?.id || assignment.accessNumber, grade20);

        await drawHeaderAndSummary(doc, { exam, assignment, student, grade20, mention, appreciation, signature, copyIndex: aIdx + 1, totalCopies: assignments.length });
        const afterRecoursY = drawRecoursSection(doc, 185);
        drawExercises(doc, { problems, submissions: studentSubmissions, assignment, startY: afterRecoursY });

        doc.moveTo(40, 785).lineTo(555, 785).lineWidth(0.5).strokeColor('#cbd5e1').stroke();
        doc.fillColor('#475569').fontSize(7.5).font('Helvetica-Oblique').text(`Document officiel d'évaluation - École Nationale Supérieure d'Informatique (ESI) - Signature HMAC: ${signature.substring(0, 20)}...`, 40, 792, { align: 'center' });
      }

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = {
  generateStudentCopyPDFData,
  generateAllStudentCopiesPDFData,
  verifyQRPayload,
  computeAuthenticitySignature
};
