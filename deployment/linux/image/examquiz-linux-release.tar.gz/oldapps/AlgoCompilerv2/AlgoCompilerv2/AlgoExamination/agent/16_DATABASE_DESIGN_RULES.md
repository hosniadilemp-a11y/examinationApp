# AlgoExamination — Database Design Rules for AI Agents

## Purpose

This document contains mandatory rules for any AI agent modifying, extending, reviewing, or creating the AlgoExamination database.

The objective is to keep the database:

* normalized
* relational
* consistent
* maintainable
* scalable
* migration-safe
* resistant to duplicate data
* resistant to orphan records
* suitable for academic examination history
* independent from frontend/UI implementation details

> **Do not design the database around what is easiest for the current React component. Design it around the real business/domain entities.**

---

# 1. READ THE EXISTING DATABASE FIRST

Before changing `schema.prisma`, the agent MUST:

1. Read the existing Prisma schema.
2. Inspect all affected models.
3. Search the repository for every affected field/model.
4. Inspect existing controllers and services.
5. Inspect frontend API usage if the database response is consumed by the frontend.
6. Check existing relationships.
7. Check existing unique constraints.
8. Check existing indexes.
9. Consider existing database data.
10. Only then propose a schema change.

Never assume that the documentation is more accurate than the actual repository.

If documentation and implementation disagree:

```text
inspect code
→ understand actual behavior
→ determine intended behavior
→ update documentation if necessary
```

---

# 2. NORMALIZATION IS THE DEFAULT

The default database design target is approximately **Third Normal Form (3NF)**.

Store each fact in the table/entity where that fact belongs.

## Example

BAD:

```text
ExamAssignment
    studentId
    studentName
    studentMatricule
    studentGroup
```

Student information belongs to `Student`.

BETTER:

```text
Student
    id
    name
    matricule
    groupId

ExamAssignment
    id
    examId
    studentId
```

The assignment references the student.

---

# 3. DO NOT CREATE A "GOD TABLE"

Never put unrelated concepts into one huge table.

BAD:

```text
Exam
    student1
    student2
    student3
    problem1
    problem2
    problem3
    score1
    score2
    score3
```

Instead identify the entities and relationships:

```text
Student
Exam
Problem
ExamAssignment
ExamProblem
Grade
```

Each table should have a clear responsibility.

---

# 4. NEVER USE REPEATED COLUMNS

Never create:

```text
exercise1
exercise2
exercise3
exercise4
```

or:

```text
student1
student2
student3
```

or:

```text
scoreExercise1
scoreExercise2
scoreExercise3
```

The number of exercises/students is variable.

Use relational rows.

Example:

```text
Exam
  │
  └── ExamProblem
          ├── Problem A
          ├── Problem B
          └── Problem C
```

For grading:

```text
ExamAssignment
      │
      └── Grade
            ├── Exercise A
            ├── Exercise B
            └── Exercise C
```

---

# 5. NEVER STORE RELATIONSHIPS AS STRINGS

BAD:

```text
studentIds = "101,102,103"
```

BAD:

```text
problemIds = "p1,p2,p3"
```

BAD:

```text
students = "Ahmed;Ali;Sara"
```

Use foreign keys and relation tables.

For example:

```text
Exam
Student
ExamAssignment
```

represents:

```text
Exam N ←→ N Student
```

through `ExamAssignment`.

---

# 6. USE JSON ONLY WHEN JSON IS ACTUALLY APPROPRIATE

Do not use JSON to avoid creating proper relational tables.

BAD:

```json
{
  "students": [...],
  "problems": [...],
  "grades": [...]
}
```

This makes:

* constraints difficult
* queries difficult
* indexing difficult
* referential integrity impossible
* duplicate data likely

JSON can be appropriate for genuinely flexible/document data.

For example, the existing:

```text
currentCodeMap
```

can reasonably remain JSON if it represents temporary editor state.

But students, exams, problems, grades, and assignments should normally be relational entities.

---

# 7. EVERY RELATIONSHIP MUST BE EXPLICIT

For every relationship determine its cardinality.

Ask:

```text
1 → 1?
1 → N?
N → M?
```

Example:

```text
Teacher 1 ─── N Exam
Exam 1 ─── N ExamAssignment
Student 1 ─── N ExamAssignment
Exam N ─── M Problem
```

The N:M relationship should use an association model:

```text
ExamProblem
```

---

# 8. ASSOCIATION TABLES SHOULD CONTAIN RELATIONSHIP DATA

An association table is not just a technical bridge.

It should contain attributes belonging to that relationship.

For AlgoExamination:

```text
ExamProblem
    examId
    problemId
    orderIndex
    points
```

`points` belongs to:

> this problem in this exam

not necessarily to the global `Problem`.

Likewise:

```text
ExamAssignment
    examId
    studentId
    accessNumber
    status
    startedAt
    finishedAt
    timeExtendedMs
```

These values belong to:

> this student's participation in this exam.

---

# 9. IDENTIFY THE SOURCE OF TRUTH

Every important fact must have one authoritative source.

Avoid:

```text
Grade.score
ExamAssignment.score
Exam.totalScore
```

if all three can independently change.

Instead determine:

```text
Authoritative data
        ↓
Derived/cached values
```

For example:

```text
Grade
  ↓
calculated final score
```

If `ExamAssignment.finalScore` is stored for performance, document it as a derived/cache value.

Never create duplicate values without defining which one is authoritative.

---

# 10. DERIVED DATA SHOULD NOT AUTOMATICALLY BE STORED

Ask:

> Can this value be calculated from existing data?

Example:

```text
Exam total points
```

can be calculated from:

```text
ExamProblem.points
```

Therefore, do not automatically create:

```text
Exam.totalPoints
```

unless there is a deliberate reason.

If a value is cached, clearly document:

```text
source of truth
cache
synchronization rule
```

---

# 11. USE PRIMARY KEYS CORRECTLY

Every entity needs a stable primary key.

Do not use:

```text
studentName
examTitle
problemTitle
groupName
```

as primary keys.

A natural identifier can still be unique.

Example:

```text
Student
    id
    matricule UNIQUE
```

---

# 12. USE UNIQUE CONSTRAINTS FOR BUSINESS RULES

Application validation is not enough.

If the business rule says:

> A student can only have one assignment for an exam.

enforce it in the database:

```text
UNIQUE(examId, studentId)
```

Similarly, if an exam cannot contain the same problem twice:

```text
UNIQUE(examId, problemId)
```

if that matches the application's business rule.

Do not rely only on React validation.

---

# 13. FOREIGN KEYS ARE REQUIRED

Do not store IDs without actual relational constraints when a relationship exists.

BAD:

```text
ExamAssignment
    studentId String
```

with no actual relation.

BETTER:

```text
studentId
→ Student.id
```

Foreign keys protect against orphan records.

---

# 14. THINK ABOUT DELETE BEHAVIOR

Never blindly add:

```text
onDelete: Cascade
```

to every relation.

Before choosing cascade, ask:

> If this parent is deleted, should this historical child really disappear?

For academic data, the answer is often **no**.

For example, deleting a student should not automatically destroy:

```text
exam assignments
grades
submissions
incidents
```

Historical academic records are important.

Prefer deactivation where appropriate:

```text
Student.isActive = false
```

rather than deleting the student.

---

# 15. PROTECT HISTORICAL EXAM DATA

AlgoExamination is an academic examination system.

Historical exams must remain reproducible.

Be careful with mutable:

```text
Problem
Exam
Student
Grade
```

Example:

A problem is used in an exam.

Later the teacher edits the problem statement.

If the completed exam now displays the new statement, the historical exam has changed.

Possible solutions include:

```text
Problem
    ↓
ProblemVersion
    ↓
ExamProblem
```

or deliberate exam snapshots.

Do not implement versioning/snapshots automatically, but recognize when they are required.

---

# 16. SEPARATE CURRENT STATE FROM HISTORY

Current state:

```text
violations
fullscreenExits
isOnline
lastSeenAt
status
```

is different from historical events.

If auditing is required, use an event model such as:

```text
Incident
    id
    assignmentId
    type
    createdAt
    metadata
```

Do not continuously add counters such as:

```text
copyAttempts
pasteAttempts
fullscreenExits
tabSwitches
blurCount
...
```

if the application needs to know the complete event history.

Counters can be useful as cached/current values, but they should not replace required audit history.

---

# 17. SEPARATE LIVE AUTOSAVE FROM OFFICIAL SUBMISSION

This is especially important for AlgoExamination.

Current editor state:

```text
currentCodeMap
```

is live working data.

Official submitted work is a different concept.

For a mature examination system, consider:

```text
ExamAssignment
      │
      └── Submission
              │
              └── SubmissionAnswer
                         │
                         └── ExamProblem
```

This prevents later autosaves from accidentally changing the official submitted answer.

Do not automatically implement this if it is outside the requested task, but do not confuse these concepts when designing new database features.

---

# 18. GRADES SHOULD BE RELATIONAL

Never create:

```text
exercise1Score
exercise2Score
exercise3Score
exercise4Score
```

Use something like:

```text
Grade
    assignmentId
    examProblemId
    pointsAwarded
    feedback
    correctedCode
```

This allows an exam to contain any number of exercises.

A uniqueness rule may be appropriate:

```text
UNIQUE(assignmentId, examProblemId)
```

if there can only be one final grade per student/exercise.

---

# 19. DO NOT DUPLICATE STUDENT INFORMATION

Avoid:

```text
Student.name
ExamAssignment.studentName
Grade.studentName
Incident.studentName
```

Use:

```text
studentId
```

and relationships.

Exception:

A historical snapshot may deliberately contain a copied value, but it must be explicitly named/documented as a snapshot.

---

# 20. INDEX WITH PURPOSE

Do not create indexes on every column.

Indexes should support actual queries.

Potentially important indexes may include:

```text
Exam.teacherId
Exam.status
Exam.date

ExamAssignment.examId
ExamAssignment.studentId
ExamAssignment.accessNumber
ExamAssignment.status

ExamProblem.examId
ExamProblem.problemId

Incident.assignmentId
Incident.createdAt
```

The actual indexes must be based on real query patterns.

Every index has a cost:

* storage
* insert/update cost
* maintenance

---

# 21. DO NOT DESIGN THE DATABASE FOR REACT STATE

A React state variable does not automatically deserve a database column.

Ask:

> Is this a real business/domain fact, or just temporary UI state?

Do not store:

* modal visibility
* selected tab
* temporary filter
* UI sorting
* temporary form state

in PostgreSQL unless there is a genuine persistence requirement.

---

# 22. DATABASE SCHEMA CHANGES MUST BE MIGRATION-SAFE

Before adding a unique constraint:

```text
check existing duplicates
```

Before adding a foreign key:

```text
check orphan records
```

Before making a field required:

```text
check existing NULL values
```

Before deleting a column:

```text
find every application usage
```

Before renaming:

```text
preserve existing data
```

Never assume the database is empty.

---

# 23. DO NOT DESTROY DATA TO FIX A MIGRATION

Never solve a migration problem by casually:

```text
DROP TABLE
```

or deleting existing rows.

Especially never destroy:

```text
students
exams
assignments
submissions
grades
incidents
```

just to make Prisma validation succeed.

---

# 24. ENUMS MUST BE TREATED AS BUSINESS CONTRACTS

Current important states include:

```text
ExamStatus
DRAFT
SCHEDULED
WAITING
RUNNING
PAUSED
FINISHED
CLOSED
```

and:

```text
StudentExamStatus
NOT_ENTERED
WAITING
IN_EXAM
DISCONNECTED
PAUSED
FINISHED
KICKED_OUT
ABSENT
```

Do not rename/remove enum values without checking:

* database records
* backend logic
* frontend logic
* Socket.IO
* reports
* exports

---

# 25. DATABASE CHANGES MUST CONSIDER THE WHOLE APPLICATION

A database change can affect:

```text
Prisma schema
    ↓
controllers
    ↓
services
    ↓
REST API
    ↓
Socket.IO
    ↓
React state
    ↓
PDF
    ↓
CSV
```

Never change the schema in isolation.

Search for all usages before changing a field.

---

# 26. DO NOT CREATE TABLES JUST BECAUSE THEY SOUND PROFESSIONAL

More tables does not automatically mean better normalization.

Create a table when it represents:

* an entity
* a relationship
* an event
* a historical record
* an independently managed concept

Do not create meaningless tables solely to make the schema look sophisticated.

---

# 27. DO NOT OVERUSE CASCADE

Cascade is appropriate when the child has no independent meaning.

Example:

```text
ExamProblem
```

may potentially depend entirely on an exam relationship.

But academic records such as:

```text
Grade
Submission
Incident
```

may need deliberate retention.

Choose delete behavior according to domain semantics.

---

# 28. DATABASE REVIEW QUESTIONS

Before approving a schema, answer:

### Entity

> What real-world thing does this table represent?

### Ownership

> Which entity owns this information?

### Cardinality

> Is this 1:1, 1:N, or N:M?

### Duplication

> Is this fact already stored somewhere else?

### Source of truth

> Which table is authoritative?

### History

> Must this information remain unchanged after the exam?

### Integrity

> What prevents invalid references?

### Uniqueness

> What prevents duplicates?

### Deletion

> What happens if the parent is deleted?

### Performance

> Which real queries require an index?

### Migration

> What happens to existing records?

If these questions cannot be answered, do not implement the schema change yet.

---

# 29. AI AGENT DATABASE WORKFLOW

For every database task:

```text
1. Read this document
        ↓
2. Inspect schema.prisma
        ↓
3. Search affected models/fields
        ↓
4. Understand current relationships
        ↓
5. Identify domain entity
        ↓
6. Determine cardinality
        ↓
7. Check normalization
        ↓
8. Identify source of truth
        ↓
9. Check historical requirements
        ↓
10. Check existing data
        ↓
11. Design constraints/indexes
        ↓
12. Make the smallest safe schema change
        ↓
13. Review affected backend/frontend code
        ↓
14. Validate Prisma
        ↓
15. Test application behavior
```

---

# 30. FINAL DATABASE RULE

Before creating a new table or field, ask:

> **Am I storing a real domain fact, or am I storing something because it is convenient for the current code?**

If it is only convenient for the current UI, do not put it in the database.

And always prefer:

```text
normalized relational model
+
foreign keys
+
unique constraints
+
deliberate indexes
+
clear source of truth
+
historical integrity
```

over:

```text
large JSON objects
+
duplicated fields
+
repeated columns
+
comma-separated IDs
+
missing constraints
+
UI-driven schema
```

**The database must remain correct even if the frontend is completely replaced tomorrow.**
