# AlgoExamination — Anti-Cheat and Monitoring Rules

## Purpose

Anti-cheat behavior is part of the examination integrity model.

Treat it as critical functionality, not optional UI behavior.

## Tracked Events

Current mechanisms include:
- fullscreen exit
- copy
- paste
- keyboard shortcuts
- tab switching
- window blur
- context menu
- F12
- Escape
- Alt+Tab-related browser/window visibility behavior where detectable

Browser APIs cannot guarantee detection of every operating-system-level action. Do not claim perfect anti-cheat coverage.

## Violation Model

There are two important counters:
- `violations`
- `fullscreenExits`

Do not merge them unless explicitly designed.

Fullscreen exits have a 3-strike auto-exclusion rule in the current requirements.

Maximum violation threshold can trigger `PAUSED`.

## Three-Strike Fullscreen Rule

Conceptually:

```text
fullscreen exit
  → increment fullscreenExits
  → report event
  → update teacher
  → if threshold reached:
       KICKED_OUT
       terminate student
```

The threshold logic must be atomic enough to prevent duplicate kicks from concurrent events.

## Status Synchronization

On lock:

```text
student_${studentId}
  → student_locked

exam_${examId}
  → student_status_changed
```

On unlock:

```text
student_${studentId}
  → student_unlocked

exam_${examId}
  → student_status_changed
```

On termination:

```text
student_${studentId}
  → student_terminated

exam_${examId}
  → student_status_changed
```

## Teacher Dashboard

Teacher should see:
- online/offline
- last seen
- violations
- fullscreen exits
- student status
- real-time incident stream

Polling fallback must remain unless deliberately replaced.

## Anti-Cheat UX

Do not:
- create infinite warning loops
- block the entire UI because of one harmless render issue
- reset counters on page refresh
- trust counters stored only in React state
- let the student browser decide that they are no longer terminated

## Important Limitation

Browser anti-cheat is inherently limited.

Avoid implementing unsafe claims such as:
- "the application detects every Alt+Tab"
- "internet is technically blocked" when only a warning banner exists
- "copy is impossible" when browser controls can be bypassed

Describe controls according to what the application actually enforces.
