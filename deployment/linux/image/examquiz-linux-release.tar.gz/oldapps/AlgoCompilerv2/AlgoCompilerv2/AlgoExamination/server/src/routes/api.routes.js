const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage() });

const authController = require('../controllers/auth.controller');
const examController = require('../controllers/exam.controller');
const studentController = require('../controllers/student.controller');
const problemController = require('../controllers/problem.controller');
const studentMgmtController = require('../controllers/student-mgmt.controller');
const gradingController = require('../controllers/grading.controller');
const { authenticateTeacher, authenticateStudent } = require('../middleware/auth.middleware');

// --- Auth Routes ---
router.post('/auth/student/login', authController.studentLogin);
router.post('/auth/teacher/login', authController.teacherLogin);

// --- Student Exam Routes (Student Session Auth) ---
router.get('/student/workspace', authenticateStudent, studentController.getStudentExamWorkspace);
router.post('/student/autosave', authenticateStudent, studentController.autosaveCode);
router.post('/student/run', authenticateStudent, studentController.runSampleCode);
router.post('/student/submit', authenticateStudent, studentController.submitSolution);
router.post('/student/violation', authenticateStudent, studentController.logMonitoringEvent);
router.post('/student/finalize', authenticateStudent, studentController.finalizeExam);
router.post('/validate', studentController.validateCodeSyntax);
router.post('/problems/run-sample', studentController.runSampleCode);

// --- Teacher Exam Routes (Teacher Auth) ---
router.post('/teacher/run', authenticateTeacher, studentController.runSampleCode);
router.get('/exams', authenticateTeacher, examController.listExams);
router.post('/exams', authenticateTeacher, examController.createExam);
router.get('/exams/export-template/:id', authenticateTeacher, examController.exportExamTemplate);
router.get('/exams/:id/export-template', authenticateTeacher, examController.exportExamTemplate);
router.post('/exams/import-template', authenticateTeacher, upload.any(), examController.importExamTemplate);
router.post('/exams/:id/clone-template', authenticateTeacher, examController.cloneExamAsTemplate);
router.post('/exams/:id/launch-room', authenticateTeacher, upload.any(), examController.launchExamWithRoom);
router.get('/exams/:id', authenticateTeacher, examController.getExamDetails);
router.put('/exams/:id', authenticateTeacher, examController.updateExam);
router.delete('/exams/:id', authenticateTeacher, examController.deleteExam);
router.patch('/exams/:id/status', authenticateTeacher, examController.updateExamStatus);
router.post('/exams/:id/emergency', authenticateTeacher, examController.teacherEmergencyControl);
router.get('/exams/:id/results', authenticateTeacher, examController.getExamResults);
router.get('/exams/:examId/access-cards', authenticateTeacher, studentMgmtController.generateExamAccessSheet);

// --- Teacher Correction & Manual Grading Routes ---
router.get('/exams/:id/grading', authenticateTeacher, gradingController.getExamGradingData);
router.post('/exams/:id/calculate-exercise', authenticateTeacher, gradingController.calculateExerciseGrade);
router.post('/exams/:id/recalculate-all', authenticateTeacher, gradingController.recalculateAllExamGrades);
router.post('/exams/:id/grade-submission', authenticateTeacher, gradingController.saveProblemGrade);
router.post('/exams/:id/general-feedback', authenticateTeacher, gradingController.updateGeneralFeedback);
router.post('/exams/:id/analyze-syntax', authenticateTeacher, gradingController.analyzeSubmission);
router.post('/exams/:id/run-sandbox', authenticateTeacher, gradingController.runTeacherSandboxCode);
router.post('/exams/:id/auto-grade', authenticateTeacher, gradingController.autoGradeExam);
router.post('/exams/:id/reset-scores', authenticateTeacher, gradingController.resetExamScores);
router.post('/exams/:id/finalize-correction', authenticateTeacher, gradingController.finalizeExamCorrection);
router.get('/exams/:id/students/:studentId/pdf', authenticateTeacher, gradingController.downloadStudentCopyPDF);
router.get('/exams/:id/all-pdf', authenticateTeacher, gradingController.downloadAllStudentCopiesPDF);
router.post('/grading/verify-qr', authenticateTeacher, gradingController.verifyQRAuthenticity);

// --- Exam Submissions & Results Bundling Routes (Encrypted / Multi-Room) ---
router.post('/exams/:id/export-bundle', authenticateTeacher, examController.exportSubmissionBundle);
router.post('/exams/:id/import-bundles', authenticateTeacher, upload.any(), examController.importSubmissionBundles);
router.post('/exams/import-bundles', authenticateTeacher, upload.any(), examController.importSubmissionBundles);
router.post('/exams/import-bundles-direct', authenticateTeacher, upload.any(), examController.importSubmissionBundles);
router.post('/exams/:id/export-results', authenticateTeacher, examController.exportCorrectedResults);
router.post('/exams/:id/import-results', authenticateTeacher, upload.any(), examController.importCorrectedResults);
router.post('/exams/import-results', authenticateTeacher, upload.any(), examController.importCorrectedResults);
router.post('/exams/import-results-direct', authenticateTeacher, upload.any(), examController.importCorrectedResults);

// --- Problem Bank Routes (Teacher Auth) ---
router.get('/problems', authenticateTeacher, problemController.listProblems);
router.post('/problems', authenticateTeacher, problemController.createProblem);
router.get('/problems/:id', authenticateTeacher, problemController.getProblemDetails);
router.put('/problems/:id', authenticateTeacher, problemController.updateProblem);
router.delete('/problems/:id', authenticateTeacher, problemController.deleteProblem);

// --- Student Management Routes (Teacher Auth) ---
router.get('/students', authenticateTeacher, studentMgmtController.listStudents);
router.post('/students', authenticateTeacher, studentMgmtController.createStudent);
router.post('/students/import-csv', authenticateTeacher, upload.any(), studentMgmtController.importStudentsCSV);

// --- Standalone Prototype Evaluator Routes (Isolated Test Lab) ---
const prototypeController = require('../controllers/prototype.controller');
router.get('/prototype/problems', prototypeController.getPrototypeProblems);
router.post('/prototype/evaluate', prototypeController.evaluatePrototypeCode);
router.post('/prototype/benchmark', prototypeController.getBenchmarkData);

module.exports = router;
