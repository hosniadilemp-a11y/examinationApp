# AlgoExamination — Engineering Rules and Anti-Mistake Rules

## Rule 1 — Date and Time

NEVER do:

```js
new Date("14:00")
```

NEVER pass a raw `"HH:MM"` string to Prisma DateTime fields.

Use the existing `parseSafeDate(dateVal, timeVal)` pattern in `exam.controller.js`.

Expected behavior:
- valid date + time → valid Date
- missing optional value → `null`
- invalid input → handled safely, not silently converted into `Invalid Date`

## Rule 2 — archiver

The server is CommonJS.

Keep:

```text
archiver@5.3.2
```

Do not upgrade to archiver 6+ unless the entire server module strategy is intentionally migrated.

Avoid creating:

```text
ERR_REQUIRE_ESM
```

## Rule 3 — Lucide Icons

Do not use:

```jsx
<AlertTriangle flexShrink={0} />
```

Use:

```jsx
<AlertTriangle style={{ flexShrink: 0 }} />
```

SVG layout properties belong in `style` where required.

## Rule 4 — Student Status Dual Reporting

For status-changing operations, always perform BOTH:

### Target command

```text
student_${studentId}
```

Examples:
- `student_locked`
- `student_unlocked`
- `student_terminated`

### Teacher broadcast

```text
exam_${examId}
```

Event:

```text
student_status_changed
```

A fix that updates only the student or only the teacher dashboard is incomplete.

## Rule 5 — PDF Theme

Official PDFs must remain:
- white background
- black text
- black borders
- print-safe
- academic

Never introduce dark UI backgrounds into the PDF.

Do not use:

```js
doc.rect(...).fill("#111827")
```

## Rule 6 — PDF Identity

Official PDF headers must dynamically use:
- university
- module
- title
- session
- student name
- group
- matricule
- date

Do not hard-code institutional identity.

## Rule 7 — Exercise Points

When adding an exercise:

```text
remaining = max(0, 20 - sum(existing points))
```

Assign remaining points to the new exercise.

Never redistribute or reset points of existing exercises.

## Rule 8 — Existing Behavior Preservation

Do not "clean up" unrelated code during a feature fix.

Avoid:
- unrelated refactors
- renaming public API fields
- changing socket event names
- changing database enums
- replacing working libraries
- changing styling globally

unless explicitly required.

## Rule 9 — State Machine Awareness

Exam status and student status are state machines.

Do not directly assign arbitrary states without checking legal transitions.

Exam statuses:

```text
DRAFT
SCHEDULED
WAITING
RUNNING
PAUSED
FINISHED
CLOSED
```

Student statuses:

```text
NOT_ENTERED
WAITING
IN_EXAM
DISCONNECTED
PAUSED
FINISHED
KICKED_OUT
ABSENT
```

## Rule 10 — Identity

Student identity must remain consistent across:
- access number
- student ID
- assignment ID
- name
- matricule
- exam assignment

Never use a display name as a database identity.

## Rule 11 — Critical State Must Be Server-Authoritative

The browser can display state, but critical exam state must come from the backend.

Do not rely exclusively on:
- React state
- localStorage
- timers
- Socket.IO delivery

for authoritative grading/exam status.

## Rule 12 — Real-Time Does Not Mean Socket-Only

Socket.IO is the primary real-time channel.

Existing polling fallbacks are intentional:
- WaitingRoom: approximately 3 seconds
- TeacherDashboard: approximately 5 seconds

Do not remove them without replacing the reliability guarantee.

## Rule 13 — Error Handling

Never swallow errors silently.

Bad:

```js
try {
  await save();
} catch {}
```

Prefer logging and user-safe recovery.

## Rule 14 — API Compatibility

Before changing an API:
1. Find every frontend caller.
2. Find every backend caller.
3. Check payload shape.
4. Check response shape.
5. Check socket side effects.
6. Update all consumers coherently.

## Rule 15 — Security

Never expose:
- JWT secrets
- HMAC secrets
- database credentials
- server environment secrets
- internal filesystem paths

in frontend code or PDFs.

## Rule 16 — Minimal Change

Prefer:

```text
smallest change → verified → documented
```

over:

```text
large refactor → assumptions → unverified behavior
```
