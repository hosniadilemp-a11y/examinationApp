import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const isStaff = process.argv.includes('5175') || process.env.VITE_PORTAL === 'staff';
  return {
    cacheDir: isStaff ? 'node_modules/.vite_staff' : 'node_modules/.vite_student',
    plugins: [react()],
    server: {
      port: isStaff ? 5175 : 5174,
      proxy: {
        '/api': {
          target: 'http://localhost:4000',
          changeOrigin: true
        },
        '/socket.io': {
          target: 'http://localhost:4000',
          ws: true,
          changeOrigin: true
        }
      }
    }
  };
});

