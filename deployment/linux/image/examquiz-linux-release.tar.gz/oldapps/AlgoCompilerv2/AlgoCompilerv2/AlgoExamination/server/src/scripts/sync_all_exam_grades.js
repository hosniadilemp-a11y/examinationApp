const prisma = require('../prisma');
const { runCodeSingle, isTestOutputMatching, normalizeOutput } = require('../runner/code-execution.service');
const { calculateCodeSimilarity, computeCanonicalExerciseScore, isUntouchedTemplateCode } = require('../runner/ast-similarity.service');

function getProblemStarterTemplate(prob) {
  if (!prob) return '';
  let tCode = prob.templateCode;
  if (typeof tCode === 'string' && tCode.trim()) {
    try {
      const parsed = JSON.parse(tCode);
      if (parsed && typeof parsed === 'object') tCode = parsed;
    } catch (e) {}
  }
  if (typeof tCode === 'object' && tCode !== null) {
    return tCode.ALGO || tCode.code || tCode.PYTHON || '';
  }
  if (typeof tCode === 'string') return tCode;
  return prob.starterTemplate || '';
}

function getProblemReferenceSolution(prob) {
  if (!prob) return '';
  const safeTitle = (prob.title || 'Exercice').trim();
  let defaultRef = prob.referenceSolution;
  if (defaultRef && defaultRef.trim()) return defaultRef.trim();

  const lower = safeTitle.toLowerCase();
  if (lower.includes('somme') || lower.includes('add')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   A, B, Somme : Entier\nDEBUT\n   Lire(A);\n   Lire(B);\n   Somme := A + B;\n   Ecrire(Somme);\nFIN.`;
  } else if (lower.includes('max') || lower.includes('grand')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   N, i, Val, MaxVal : Entier\nDEBUT\n   Lire(N);\n   Lire(MaxVal);\n   Pour i := 2 a N Faire\n      Lire(Val);\n      Si (Val > MaxVal) Alors\n         MaxVal := Val;\n      FinSi;\n   FinPour;\n   Ecrire(MaxVal);\nFIN.`;
  } else if (lower.includes('tri') || lower.includes('bulle')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   T : Tableau [1..100] de Entier\n   N, i, j, Temp : Entier\nDEBUT\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]) FinPour;\n   Pour i := 1 a N-1 Faire\n      Pour j := 1 a N-i Faire\n         Si (T[j] > T[j+1]) Alors\n            Temp := T[j]; T[j] := T[j+1]; T[j+1] := Temp;\n         FinSi;\n      FinPour;\n   FinPour;\nFIN.`;
  } else if (lower.includes('factorielle') || lower.includes('fact')) {
    return `ALGORITHME Solution_Factorielle\nVARIABLES\n   N, i, Fact : Entier\nDEBUT\n   Lire(N);\n   Fact := 1;\n   Pour i := 1 a N Faire\n      Fact := Fact * i;\n   FinPour;\n   Ecrire(Fact);\nFIN.`;
  } else {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   N, Val_${safeTitle.replace(/\s+/g, '')} : Entier\nDEBUT\n   Lire(N);\n   Val_${safeTitle.replace(/\s+/g, '')} := N * 2;\n   Ecrire(Val_${safeTitle.replace(/\s+/g, '')});\nFIN.`;
  }
}

async function syncAllGrades() {
  console.log('=== Starting Full Database Grading Sync ===');
  const exams = await prisma.exam.findMany({
    include: {
      problems: {
        orderBy: { orderIndex: 'asc' },
        include: {
          problem: {
            include: {
              testCases: { select: { id: true, inputData: true, expectedOutput: true, isPublic: true } }
            }
          }
        }
      },
      assignments: {
        include: { student: true }
      }
    }
  });

  console.log(`Found ${exams.length} exams.`);

  for (const exam of exams) {
    console.log(`\nProcessing Exam: ${exam.title} (${exam.id}) with ${exam.assignments.length} assignments and ${exam.problems.length} problems`);

    for (const asgn of exam.assignments) {
      let codeMap = asgn.currentCodeMap;
      if (typeof codeMap === 'string') {
        try { codeMap = JSON.parse(codeMap); } catch (e) {}
      }

      let totalEarned = 0;
      let totalMax = 0;

      for (const ep of exam.problems) {
        const prob = ep.problem;
        const maxPts = ep.points || prob.points || 20;
        totalMax += maxPts;

        const starterTpl = getProblemStarterTemplate(prob);
        const refSol = getProblemReferenceSolution(prob);

        let sub = await prisma.submission.findFirst({
          where: { examId: exam.id, studentId: asgn.studentId, problemId: prob.id }
        });

        let code = sub?.sourceCode || '';
        if (!code || !code.trim()) {
          if (codeMap && typeof codeMap === 'object') {
            const val = codeMap[prob.id];
            if (typeof val === 'string') code = val;
            else if (val && typeof val === 'object' && val.code) code = val.code;
          }
        }

        if (!code || !code.trim()) {
          code = starterTpl || '// Aucun code soumis';
        }

        const isUntouched = isUntouchedTemplateCode(code, starterTpl);
        const testCases = prob.testCases || [];
        let passedTests = 0;

        if (!isUntouched && testCases.length > 0) {
          for (const tc of testCases) {
            try {
              const res = await runCodeSingle(code, 'ALGO', tc.inputData || '', 2000);
              const passed = isTestOutputMatching(res.stdout || '', tc.expectedOutput || '');
              if (passed) passedTests++;
            } catch (e) {}
          }
        }

        const canonical = computeCanonicalExerciseScore(
          code,
          starterTpl,
          refSol,
          passedTests,
          testCases.length,
          maxPts
        );

        const calculatedScore = canonical.calculatedScore;
        totalEarned += calculatedScore;

        const scorePct = testCases.length > 0 ? Math.round((passedTests / testCases.length) * 100) : 0;

        if (sub) {
          await prisma.submission.update({
            where: { id: sub.id },
            data: {
              sourceCode: code,
              manualScore: calculatedScore,
              score: scorePct,
              passedTests,
              totalTests: testCases.length,
              status: 'GRADED',
              gradedAt: new Date()
            }
          });
        } else {
          await prisma.submission.create({
            data: {
              examId: exam.id,
              studentId: asgn.studentId,
              problemId: prob.id,
              language: 'ALGO',
              sourceCode: code,
              manualScore: calculatedScore,
              score: scorePct,
              passedTests,
              totalTests: testCases.length,
              status: 'GRADED',
              gradedAt: new Date()
            }
          });
        }

        console.log(`  [${asgn.accessNumber}] P${ep.orderIndex} "${prob.title}": score=${calculatedScore}/${maxPts} (tests: ${passedTests}/${testCases.length}, AST: ${canonical.astSimilarityRatio}%, m1=${canonical.m1Score}, m2=${canonical.m2Score})`);
      }

      totalEarned = Math.round(totalEarned * 100) / 100;
      const finalScore20 = totalMax > 0 ? parseFloat(((totalEarned / totalMax) * 20).toFixed(2)) : 0;

      await prisma.examAssignment.update({
        where: { id: asgn.id },
        data: {
          finalScore: finalScore20,
          gradingStatus: 'GRADED'
        }
      });

      console.log(`  => Student [${asgn.accessNumber}] Total: ${totalEarned}/${totalMax} pts => Final Grade: ${finalScore20}/20`);
    }
  }

  console.log('\n=== Full Database Grading Sync Complete ===');
}

syncAllGrades()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
