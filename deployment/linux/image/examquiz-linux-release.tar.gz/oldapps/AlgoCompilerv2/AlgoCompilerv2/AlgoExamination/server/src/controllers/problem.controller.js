const fs = require('fs');
const path = require('path');
const prisma = require('../prisma');
const { withRetry } = require('../prisma');

// Helper to seed/sync JSON problems from server/data/problems if DB is empty
async function syncJSONProblemsIfEmpty() {
  try {
    const count = await prisma.problem.count();
    if (count > 0) return;

    const problemsDir = path.join(__dirname, '../../data/problems');
    if (!fs.existsSync(problemsDir)) return;

    const files = fs.readdirSync(problemsDir).filter(f => f.endsWith('.json'));
    console.log(`📦 DB problems empty. Auto-seeding ${files.length} JSON problems...`);

    for (const file of files) {
      try {
        const raw = fs.readFileSync(path.join(problemsDir, file), 'utf8');
        const json = JSON.parse(raw);

        const topicVal = json.topic || (Array.isArray(json.tags) ? json.tags.join(', ') : json.tags) || 'Algorithmique Général';
        const finalTemplateCode = typeof json.starterTemplate === 'string'
          ? { ALGO: json.starterTemplate, PYTHON: '' }
          : (json.templateCode || { ALGO: '', PYTHON: '' });

        const created = await prisma.problem.create({
          data: {
            id: json.id || undefined,
            title: json.title,
            description: json.description || '',
            topic: topicVal,
            difficulty: json.difficulty || 'MOYEN',
            referenceSolution: json.referenceSolution || '',
            timeLimitMs: json.timeLimitMs ? parseInt(json.timeLimitMs, 10) : 2000,
            memoryLimitMb: json.memoryLimitMb ? parseInt(json.memoryLimitMb, 10) : 128,
            templateCode: finalTemplateCode
          }
        });

        if (Array.isArray(json.testCases) && json.testCases.length > 0) {
          for (const tc of json.testCases) {
            await prisma.testCase.create({
              data: {
                problemId: created.id,
                inputData: tc.inputData ?? tc.input ?? '',
                expectedOutput: tc.expectedOutput ?? tc.expected ?? '',
                isPublic: tc.isPublic != null ? !!tc.isPublic : (tc.isHidden != null ? !tc.isHidden : true)
              }
            });
          }
        }
      } catch (fErr) {
        console.error(`Error loading JSON problem file ${file}:`, fErr.message);
      }
    }
  } catch (err) {
    console.error('syncJSONProblemsIfEmpty error:', err);
  }
}

function validateQuestionMarkers(codeStr, questionCount) {
  if (!codeStr || typeof codeStr !== 'string') return { valid: true };

  const startRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:starts|commence|d[ée]bute?)\s*(?:here|ici)?|(?:d[ée]but)\s+question\s+(\d+))\s*$/gim;
  const endRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:ends|se\s+termine|termine|fin)\s*(?:here|ici)?|(?:fin)\s+question\s+(\d+))\s*$/gim;

  const starts = [];
  const ends = [];

  let match;
  while ((match = startRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    starts.push({ qNum, index: match.index });
  }
  while ((match = endRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    ends.push({ qNum, index: match.index });
  }

  // Check matched pairs
  const startMap = {};
  for (const s of starts) {
    if (s.qNum < 1 || s.qNum > questionCount) {
      return { valid: false, error: `Le marqueur "// question ${s.qNum} commence ici" fait référence à une question inexistante (max: ${questionCount}).` };
    }
    if (startMap[s.qNum]) {
      return { valid: false, error: `Marqueur de début dupliqué pour la question ${s.qNum}.` };
    }
    startMap[s.qNum] = s;
  }

  const endMap = {};
  for (const e of ends) {
    if (e.qNum < 1 || e.qNum > questionCount) {
      return { valid: false, error: `Le marqueur "// question ${e.qNum} se termine ici" fait référence à une question inexistante (max: ${questionCount}).` };
    }
    if (endMap[e.qNum]) {
      return { valid: false, error: `Marqueur de fin dupliqué pour la question ${e.qNum}.` };
    }
    endMap[e.qNum] = e;
  }

  for (const qNum of Object.keys(startMap)) {
    if (!endMap[qNum]) {
      return { valid: false, error: `Marqueur de fin manquant pour la question ${qNum} (attendu: // question ${qNum} se termine ici).` };
    }
    if (startMap[qNum].index >= endMap[qNum].index) {
      return { valid: false, error: `Le marqueur de fin pour la question ${qNum} apparaît avant le marqueur de début.` };
    }
  }

  for (const qNum of Object.keys(endMap)) {
    if (!startMap[qNum]) {
      return { valid: false, error: `Marqueur de début manquant pour la question ${qNum} (attendu: // question ${qNum} commence ici).` };
    }
  }

  return { valid: true };
}

// List reusable problems in problem bank
async function listProblems(req, res) {
  try {
    const { topic, difficulty, search } = req.query;
    const where = {};

    if (topic) where.topic = topic;
    if (difficulty) where.difficulty = difficulty;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ];
    }

    const problems = await withRetry(() => prisma.problem.findMany({
      where,
      include: {
        testCases: true,
        questions: { orderBy: { orderIndex: 'asc' } },
        _count: { select: { examProblems: true } }
      },
      orderBy: { createdAt: 'desc' }
    }));

    return res.json(problems);
  } catch (err) {
    console.error('listProblems error:', err);
    return res.status(500).json({ error: 'Failed to fetch problems' });
  }
}

// Get single problem details
async function getProblemDetails(req, res) {
  try {
    const { id } = req.params;
    const problem = await prisma.problem.findUnique({
      where: { id },
      include: {
        testCases: true,
        questions: { orderBy: { orderIndex: 'asc' } }
      }
    });

    if (!problem) return res.status(404).json({ error: 'Problem not found' });
    return res.json(problem);
  } catch (err) {
    console.error('getProblemDetails error:', err);
    return res.status(500).json({ error: 'Failed to fetch problem' });
  }
}

async function createProblem(req, res) {
  try {
    const {
      title,
      description,
      topic,
      difficulty,
      points,
      timeLimitMs,
      memoryLimitMb,
      templateCode,
      referenceSolution,
      testCases,
      questions
    } = req.body;

    const topicVal = topic || (Array.isArray(req.body.tags) ? req.body.tags.join(', ') : req.body.tags) || 'Algorithmique Général';
    const finalTemplateCode = typeof req.body.starterTemplate === 'string'
      ? { ALGO: req.body.starterTemplate, PYTHON: '' }
      : (templateCode || { ALGO: '', PYTHON: '' });

    if (!title || !description) {
      return res.status(400).json({ error: 'Title and description are required' });
    }

    // Determine questions list
    const questionsList = (Array.isArray(questions) && questions.length > 0)
      ? questions
      : [{ orderIndex: 1, statement: description }];

    // Validate markers if code present
    const algoCode = finalTemplateCode?.ALGO || '';
    const markerVal = validateQuestionMarkers(algoCode, questionsList.length);
    if (!markerVal.valid) {
      return res.status(400).json({ error: markerVal.error });
    }

    const problem = await prisma.problem.create({
      data: {
        title,
        description,
        topic: topicVal,
        difficulty: difficulty || 'MOYEN',
        referenceSolution: referenceSolution || req.body.solution || '',
        timeLimitMs: timeLimitMs ? parseInt(timeLimitMs, 10) : 2000,
        memoryLimitMb: memoryLimitMb ? parseInt(memoryLimitMb, 10) : 128,
        templateCode: finalTemplateCode
      }
    });

    // Create questions
    for (let idx = 0; idx < questionsList.length; idx++) {
      const q = questionsList[idx];
      await prisma.problemQuestion.create({
        data: {
          problemId: problem.id,
          orderIndex: q.orderIndex !== undefined ? q.orderIndex : (idx + 1),
          statement: q.statement || description
        }
      });
    }

    // Add test cases with flexible input / inputData & isPublic / isHidden mapping
    if (Array.isArray(testCases) && testCases.length > 0) {
      for (const tc of testCases) {
        await prisma.testCase.create({
          data: {
            problemId: problem.id,
            inputData: tc.inputData ?? tc.input ?? '',
            expectedOutput: tc.expectedOutput ?? tc.expected ?? '',
            isPublic: tc.isPublic != null ? !!tc.isPublic : (tc.isHidden != null ? !tc.isHidden : true)
          }
        });
      }
    }

    const full = await prisma.problem.findUnique({
      where: { id: problem.id },
      include: {
        testCases: true,
        questions: { orderBy: { orderIndex: 'asc' } }
      }
    });

    return res.status(201).json(full);
  } catch (err) {
    console.error('createProblem error:', err);
    return res.status(500).json({ error: 'Failed to create problem' });
  }
}

// Update Problem
async function updateProblem(req, res) {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      topic,
      difficulty,
      points,
      timeLimitMs,
      memoryLimitMb,
      templateCode,
      referenceSolution,
      testCases,
      questions
    } = req.body;

    const topicVal = topic || (Array.isArray(req.body.tags) ? req.body.tags.join(', ') : req.body.tags) || 'Algorithmique Général';
    const finalTemplateCode = typeof req.body.starterTemplate === 'string'
      ? { ALGO: req.body.starterTemplate, PYTHON: '' }
      : (templateCode || undefined);

    const questionsList = (Array.isArray(questions) && questions.length > 0)
      ? questions
      : undefined;

    if (finalTemplateCode?.ALGO && questionsList) {
      const markerVal = validateQuestionMarkers(finalTemplateCode.ALGO, questionsList.length);
      if (!markerVal.valid) {
        return res.status(400).json({ error: markerVal.error });
      }
    }

    const updated = await prisma.problem.update({
      where: { id },
      data: {
        title,
        description,
        topic: topicVal,
        difficulty,
        referenceSolution: referenceSolution !== undefined ? (referenceSolution || '') : undefined,
        timeLimitMs: timeLimitMs ? parseInt(timeLimitMs, 10) : undefined,
        memoryLimitMb: memoryLimitMb ? parseInt(memoryLimitMb, 10) : undefined,
        templateCode: finalTemplateCode
      }
    });

    // Update questions if provided
    if (questionsList) {
      await prisma.problemQuestion.deleteMany({ where: { problemId: id } });
      for (let idx = 0; idx < questionsList.length; idx++) {
        const q = questionsList[idx];
        await prisma.problemQuestion.create({
          data: {
            problemId: id,
            orderIndex: q.orderIndex !== undefined ? q.orderIndex : (idx + 1),
            statement: q.statement || (description || updated.description)
          }
        });
      }
    }

    // Replace test cases if provided
    if (Array.isArray(testCases)) {
      await prisma.testCase.deleteMany({ where: { problemId: id } });
      for (const tc of testCases) {
        await prisma.testCase.create({
          data: {
            problemId: id,
            inputData: tc.inputData ?? tc.input ?? '',
            expectedOutput: tc.expectedOutput ?? tc.expected ?? '',
            isPublic: tc.isPublic != null ? !!tc.isPublic : (tc.isHidden != null ? !tc.isHidden : true)
          }
        });
      }
    }

    const full = await prisma.problem.findUnique({
      where: { id },
      include: {
        testCases: true,
        questions: { orderBy: { orderIndex: 'asc' } }
      }
    });

    return res.json(full);
  } catch (err) {
    console.error('updateProblem error:', err);
    return res.status(500).json({ error: 'Failed to update problem' });
  }
}

// Delete Problem
async function deleteProblem(req, res) {
  try {
    const { id } = req.params;
    await prisma.problem.delete({ where: { id } });
    return res.json({ message: 'Problem deleted' });
  } catch (err) {
    console.error('deleteProblem error:', err);
    return res.status(500).json({ error: 'Failed to delete problem' });
  }
}

module.exports = {
  validateQuestionMarkers,
  listProblems,
  getProblemDetails,
  createProblem,
  updateProblem,
  deleteProblem
};
