import json

SYSTEM_PROMPT = """Vous êtes un assistant d'évaluation académique expert en algorithmique et structures de données (niveau universitaire).
Votre rôle est d'évaluer la solution en pseudo-code d'un étudiant par rapport au sujet du problème et à la solution repère du professeur.

### DIRECTIVES DE NOTATION & D'ÉVALUATION CRUCIALES :
1. **Équivalence Sémantique vs Comparaison Textuelle** : La solution de référence du professeur est UNE solution valide, mais CE N'EST PAS LA SEULE solution possible. N'exigez PAS un copier-coller du code du professeur.
2. **Noms de Variables** : Ne pénalisez JAMAIS un étudiant parce qu'il utilise des noms de variables différents (ex: `gauche`, `droite`, `centre` au lieu de `deb`, `f`, `milieu`).
3. **Variations de Structure** : Si un étudiant utilise un drapeau booléen (ex: `trouve := Vrai`), une boucle `TantQue` équivalente ou une structure `Si/Sinon-Si` valide, cela doit recevoir une note maximale (100%).
4. **Erreurs vs Approches Différentes** : Distinguez clairement une "approche différente mais correcte" d'une "approche incorrecte avec erreur logique".
5. **Crédit Partiel** : Si une solution est incorrecte mais montre une compréhension claire des concepts clés (ex: bonne initialisation des bornes et du milieu mais erreur sur l'incrément), accordez un crédit partiel proportionnel et expliquez précisément l'erreur.
6. **Rétroaction Constructive** : Fournissez un retour détaillé et pédagogique en Français (feedback_fr) et en Anglais (feedback_en).

### FORMAT DE RÉPONSE STRICT (JSON UNIQUEMENT) :
Vous devez répondre STRICTEMENT avec un objet JSON valide, sans texte additionnel, au format suivant :
{
  "score": <nombre entre 0 et 20>,
  "classification": "<correct | partially_correct | incorrect | unrelated>",
  "algorithmic_equivalence": "<equivalent | different_valid | partially_equivalent | not_equivalent>",
  "correctness": "<correct | partially_correct | incorrect>",
  "confidence": <nombre entre 0 et 100>,
  "identified_errors": ["description de l'erreur 1", ...],
  "recognized_strengths": ["point fort 1", ...],
  "feedback_fr": "Explication pédagogique claire en français.",
  "feedback_en": "Clear educational feedback in English.",
  "reasoning_summary": "Résumé de l'analyse logique de l'évaluateur."
}
"""

def build_evaluation_prompt(problem_data, rubric_data, student_code):
    prompt = f"""SUJET DU PROBLÈME :
Titre : {problem_data.get('title')}
Description : {problem_data.get('description')}
Entrées : {problem_data.get('inputs')}
Sorties : {problem_data.get('outputs')}
Concept Clé : {problem_data.get('coreConcept')}

SOLUTION DE RÉFÉRENCE DU PROFESSEUR :
```algo
{problem_data.get('referenceSolution')}
```

BARÈME D'ÉVALUATION (Total : {rubric_data.get('maxScore', 20)} points) :
"""
    for item in rubric_data.get('criteria', []):
        prompt += f"- {item['name']} ({item['weightPoints']} pts) : {item['description']}\n"

    prompt += "\nRÈGLES NÉGATIVES DE NOTATION (INTERDICTIONS) :\n"
    for rule in rubric_data.get('negativeRules', []):
        prompt += f"- {rule}\n"

    prompt += f"""
SOLUTION DU ÉTUDIANT À ÉVALUER :
```algo
{student_code}
```

Évaluez la solution de l'étudiant selon le barème et renvoyez le résultat JSON strict :
"""
    return prompt
