const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const TMP_DIR = path.join(__dirname, '../../tmp');
if (!fs.existsSync(TMP_DIR)) {
  fs.mkdirSync(TMP_DIR, { recursive: true });
}

const VENV_PYTHON = process.env.VENV_PYTHON || path.resolve(__dirname, '../../../../AlgoCompiler/venv/bin/python');
const ALGO_COMPILER_SRC_PATH = process.env.ALGO_COMPILER_SRC_PATH || path.resolve(__dirname, '../../../../AlgoCompiler/src');

const { globalExecutionQueue, QueueSaturationError } = require('./concurrency-queue');

/**
 * Execute code safely with timeouts
 * @param {string} sourceCode 
 * @param {string} language - 'ALGO'
 * @param {string} inputData 
 * @param {number} timeLimitMs 
 * @returns {Promise<{stdout: string, stderr: string, executionMs: number, status: string, queueWaitMs?: number, isQueued?: boolean}>}
 */
async function runCodeSingle(sourceCode, language = 'ALGO', inputData = '', timeLimitMs = 2000) {
  const fileId = crypto.randomBytes(8).toString('hex');
  const lang = (language || 'ALGO').toUpperCase();

  try {
    return await globalExecutionQueue.enqueue(async ({ queueWaitMs }) => {
      const startTime = Date.now();
      let cmd = '';
      let args = [];
      let sourceFilePath = '';
      let binaryPath = '';

      try {
        if (lang === 'ALGO') {
          // Algorithmic Pseudocode -> Translate & run via AlgoCompiler python runner
          sourceFilePath = path.join(TMP_DIR, `${fileId}.algo`);
          fs.writeFileSync(sourceFilePath, sourceCode, 'utf8');
          
          const runnerScript = `
import sys, os, builtins, io

# Apply OS process limits (CPU limit, memory limit, process limit)
try:
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (3, 4))
    resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_NPROC, (20, 20))
except Exception:
    pass

_raw_stdin = sys.stdin.read()
sys.stdin = io.StringIO(_raw_stdin)

sys.path.insert(0, '${ALGO_COMPILER_SRC_PATH}')
sys.path.insert(0, '${path.resolve(__dirname)}')
from compiler.parser import compile_algo
from french_exception_translator import translate_exception

with open('${sourceFilePath}', 'r', encoding='utf-8') as f:
    code = f.read()

res = compile_algo(code)
if isinstance(res, tuple):
    py_code, errors = res
    if errors:
        formatted_errs = []
        for e in errors:
            if isinstance(e, dict):
                line = e.get('line', 1)
                col = e.get('column', 1)
                msg = e.get('message', 'Erreur de syntaxe')
                err_code = e.get('error_code', 'E2.1')
                formatted_errs.append(f"Ligne {line}, Colonne {col} [{err_code}] : {msg}")
            else:
                formatted_errs.append(str(e))
        sys.stderr.write('\\n'.join(formatted_errs) + '\\n')
        sys.exit(1)
else:
    py_code = res

if not py_code:
    sys.stderr.write('Erreur de syntaxe algorithmique\\n')
    sys.exit(1)

try:
    exec(py_code, globals())
except Exception as e:
    french_err = translate_exception(e, py_code, code)
    sys.stderr.write(french_err + '\\n')
    sys.exit(1)
`;
          const pyRunnerPath = path.join(TMP_DIR, `${fileId}_runner.py`);
          fs.writeFileSync(pyRunnerPath, runnerScript, 'utf8');
          
          cmd = fs.existsSync(VENV_PYTHON) ? VENV_PYTHON : 'python3';
          args = [pyRunnerPath];
        } else if (lang === 'PYTHON') {
          sourceFilePath = path.join(TMP_DIR, `${fileId}.py`);
          fs.writeFileSync(sourceFilePath, sourceCode, 'utf8');
          cmd = 'python3';
          args = [sourceFilePath];
        } else if (lang === 'CPP') {
          sourceFilePath = path.join(TMP_DIR, `${fileId}.cpp`);
          binaryPath = path.join(TMP_DIR, `${fileId}.out`);
          fs.writeFileSync(sourceFilePath, sourceCode, 'utf8');

          const compileRes = await execCommand('g++', ['-O2', sourceFilePath, '-o', binaryPath], '', 5000);
          if (compileRes.exitCode !== 0) {
            return {
              stdout: '',
              stderr: compileRes.stderr || 'Compilation Error',
              executionMs: Date.now() - startTime,
              queueWaitMs,
              status: 'COMPILE_ERROR'
            };
          }
          cmd = binaryPath;
          args = [];
        } else if (lang === 'C') {
          sourceFilePath = path.join(TMP_DIR, `${fileId}.c`);
          binaryPath = path.join(TMP_DIR, `${fileId}.out`);
          fs.writeFileSync(sourceFilePath, sourceCode, 'utf8');

          const compileRes = await execCommand('gcc', ['-O2', sourceFilePath, '-o', binaryPath], '', 5000);
          if (compileRes.exitCode !== 0) {
            return {
              stdout: '',
              stderr: compileRes.stderr || 'Compilation Error',
              executionMs: Date.now() - startTime,
              queueWaitMs,
              status: 'COMPILE_ERROR'
            };
          }
          cmd = binaryPath;
          args = [];
        } else if (lang === 'JAVA') {
          sourceFilePath = path.join(TMP_DIR, `Solution_${fileId}.java`);
          fs.writeFileSync(sourceFilePath, sourceCode.replace(/public\s+class\s+\w+/, `public class Solution_${fileId}`), 'utf8');

          const compileRes = await execCommand('javac', [sourceFilePath], '', 5000);
          if (compileRes.exitCode !== 0) {
            return {
              stdout: '',
              stderr: compileRes.stderr || 'Compilation Error',
              executionMs: Date.now() - startTime,
              queueWaitMs,
              status: 'COMPILE_ERROR'
            };
          }
          cmd = 'java';
          args = ['-cp', TMP_DIR, `Solution_${fileId}`];
        } else {
          return { stdout: '', stderr: `Unsupported language: ${lang}`, executionMs: 0, queueWaitMs, status: 'COMPILE_ERROR' };
        }

        const execRes = await execCommand(cmd, args, inputData, timeLimitMs);
        const executionMs = Date.now() - startTime;

        if (execRes.timedOut) {
          return { stdout: execRes.stdout, stderr: 'Time Limit Exceeded', executionMs: timeLimitMs, queueWaitMs, status: 'TIME_LIMIT' };
        }

        if (execRes.exitCode !== 0) {
          return { stdout: execRes.stdout, stderr: execRes.stderr, executionMs, queueWaitMs, status: 'RUNTIME_ERROR' };
        }

        return {
          stdout: execRes.stdout.trim(),
          stderr: execRes.stderr.trim(),
          executionMs,
          queueWaitMs,
          isQueued: queueWaitMs > 50,
          status: 'SUCCESS'
        };
      } finally {
        safeUnlink(sourceFilePath);
        safeUnlink(binaryPath);
        safeUnlink(path.join(TMP_DIR, `${fileId}_runner.py`));
        safeUnlink(path.join(TMP_DIR, `Solution_${fileId}.class`));
      }
    }, { fileId });
  } catch (err) {
    if (err instanceof QueueSaturationError || err.name === 'QueueSaturationError') {
      return {
        stdout: '',
        stderr: err.message || 'Le serveur est actuellement saturé, réessayez dans quelques secondes',
        executionMs: 0,
        queueWaitMs: 0,
        status: 'QUEUE_SATURATED'
      };
    }
    throw err;
  }
}

function isTestOutputMatching(actual, expected) {
  const normActual = normalizeOutput(actual);
  const normExpected = normalizeOutput(expected);
  return normActual === normExpected;
}

/**
 * Run code against multiple test cases and evaluate results
 */
async function evaluateSubmission(sourceCode, language, testCases, timeLimitMs = 2000) {
  let passedTests = 0;
  let totalTests = testCases.length;
  let maxExecutionMs = 0;
  let finalStatus = 'ACCEPTED';
  let stderrOutput = '';

  for (const tc of testCases) {
    const res = await runCodeSingle(sourceCode, language, tc.inputData, timeLimitMs);
    maxExecutionMs = Math.max(maxExecutionMs, res.executionMs);

    if (res.status === 'COMPILE_ERROR') {
      return {
        status: 'COMPILE_ERROR',
        passedTests: 0,
        totalTests,
        score: 0,
        executionMs: res.executionMs,
        stderr: res.stderr
      };
    }

    if (res.status === 'TIME_LIMIT') {
      finalStatus = 'TIME_LIMIT';
      stderrOutput = res.stderr;
      break;
    }

    if (res.status === 'RUNTIME_ERROR') {
      finalStatus = 'RUNTIME_ERROR';
      stderrOutput = res.stderr;
      break;
    }

    const matched = isTestOutputMatching(res.stdout, tc.expectedOutput);

    if (matched) {
      passedTests++;
    } else {
      if (finalStatus === 'ACCEPTED') {
        finalStatus = 'WRONG_ANSWER';
        stderrOutput = `Test Case Failed.\nInput:\n${tc.inputData}\nExpected:\n${tc.expectedOutput}\nActual:\n${res.stdout}`;
      }
    }
  }

  const score = totalTests > 0 ? (passedTests / totalTests) * 100 : 0;

  return {
    status: passedTests === totalTests ? 'ACCEPTED' : finalStatus,
    passedTests,
    totalTests,
    score: Math.round(score * 100) / 100,
    executionMs: maxExecutionMs,
    stderr: stderrOutput
  };
}

function execCommand(cmd, args, inputData, timeoutMs) {
  return new Promise((resolve) => {
    let stdout = '';
    let stderr = '';
    let timedOut = false;

    const child = spawn(cmd, args, { stdio: ['pipe', 'pipe', 'pipe'] });

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, timeoutMs);

    if (inputData) {
      child.stdin.write(inputData);
    }
    child.stdin.end();

    child.stdout.on('data', (d) => { stdout += d.toString(); });
    child.stderr.on('data', (d) => { stderr += d.toString(); });

    child.on('close', (exitCode) => {
      clearTimeout(timer);
      resolve({ exitCode: exitCode ?? 1, stdout, stderr, timedOut });
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      resolve({ exitCode: 1, stdout, stderr: err.message, timedOut: false });
    });
  });
}

function normalizeOutput(str) {
  if (!str) return '';
  return str
    .replace(/\r\n/g, ' ')
    .replace(/[\n\r\t]+/g, ' ')
    .trim()
    .replace(/[ \t]+/g, ' ');
}

function safeUnlink(p) {
  if (p && fs.existsSync(p)) {
    try { fs.unlinkSync(p); } catch (e) {}
  }
}

/**
 * Fast syntax validation running Lexer + Parser only
 * @param {string} sourceCode
 * @returns {Promise<{errors: Array<{line: number, column: number, message: string, severity: string}>}>}
 */
async function validateSyntax(sourceCode) {
  if (!sourceCode || !sourceCode.trim()) {
    return { errors: [] };
  }

  const fileId = crypto.randomBytes(8).toString('hex');
  const sourceFilePath = path.join(TMP_DIR, `${fileId}_val.algo`);
  const pyRunnerPath = path.join(TMP_DIR, `${fileId}_val.py`);

  try {
    fs.writeFileSync(sourceFilePath, sourceCode, 'utf8');

    const validatorScript = `
import sys, json
sys.path.insert(0, '${ALGO_COMPILER_SRC_PATH}')
from compiler.parser import compile_algo

with open('${sourceFilePath}', 'r', encoding='utf-8') as f:
    code = f.read()

res, errors = compile_algo(code)
clean_errors = []
for e in (errors or []):
    line = e.get('line', 1)
    col = e.get('column', 1)
    msg = e.get('message', 'Erreur de syntaxe')
    clean_errors.append({'line': line, 'column': col, 'message': msg, 'severity': 'error'})

print(json.dumps({'errors': clean_errors}))
`;
    fs.writeFileSync(pyRunnerPath, validatorScript, 'utf8');

    const pythonCmd = fs.existsSync(VENV_PYTHON) ? VENV_PYTHON : 'python3';
    const execRes = await execCommand(pythonCmd, [pyRunnerPath], '', 2000);

    if (execRes.exitCode === 0 && execRes.stdout) {
      try {
        const parsed = JSON.parse(execRes.stdout);
        return parsed;
      } catch (_) {}
    }
    return { errors: [] };
  } catch (err) {
    return { errors: [] };
  } finally {
    safeUnlink(sourceFilePath);
    safeUnlink(pyRunnerPath);
  }
}

module.exports = {
  runCodeSingle,
  evaluateSubmission,
  validateSyntax,
  normalizeOutput,
  isTestOutputMatching
};
