import React, { useState } from 'react';
import { studentLogin } from '../services/api';
import { KeyRound, ShieldAlert, LogIn } from 'lucide-react';
import Swal from 'sweetalert2';

export default function StudentLogin({ onLoginSuccess, switchToTeacher }) {
  const [accessNumber, setAccessNumber] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!accessNumber.trim()) return;

    setLoading(true);
    try {
      const data = await studentLogin(accessNumber);
      localStorage.setItem('token', data.token);
      localStorage.setItem('userRole', 'STUDENT');
      onLoginSuccess(data);
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Accès refusé',
        text: err.data?.error || 'Numéro d’accès invalide ou non attribué.',
        background: '#111827',
        color: '#ffffff',
        confirmButtonColor: '#ef4444'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
      <div className="glass-panel" style={{ width: '100%', maxWidth: '440px', padding: '40px' }}>
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <div style={{ width: '64px', height: '64px', borderRadius: '16px', background: 'rgba(59, 130, 246, 0.15)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: '15px', border: '1px solid rgba(59, 130, 246, 0.3)' }}>
            <KeyRound size={32} color="#60a5fa" />
          </div>
          <h2>Espace Examen Étudiant</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: '6px' }}>
            Entrez votre numéro d’accès individuel pour rejoindre votre session.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="accessNumber">Numéro d’Accès</label>
            <input
              id="accessNumber"
              type="text"
              className="form-input"
              placeholder="ex: AL20260001"
              value={accessNumber}
              onChange={(e) => setAccessNumber(e.target.value.toUpperCase())}
              style={{ fontSize: '1.2rem', textAlign: 'center', letterSpacing: '2px', fontFamily: 'var(--font-mono)' }}
              autoFocus
              required
            />
          </div>

          <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px', marginTop: '10px' }} disabled={loading}>
            {loading ? <span className="fas fa-spinner fa-spin">Connexion...</span> : <><LogIn size={18} /> Entrer en Salle d’Examen</>}
          </button>
        </form>
      </div>
    </div>
  );
}
