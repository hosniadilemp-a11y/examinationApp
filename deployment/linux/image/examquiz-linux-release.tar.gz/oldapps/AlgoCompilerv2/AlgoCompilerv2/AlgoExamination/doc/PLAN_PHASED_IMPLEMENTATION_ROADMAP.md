# Plan 2 : Feuille de Route d'Implémentation par Phases (Phased Roadmap)

Ce plan découpe l'implémentation de la spécification `extensions.txt` en 6 étapes incrémentales et isolées.

---

## Phase 0 : Schéma Prisma & Migration Idempotente
- **Fichiers :** `server/prisma/schema.prisma`, `server/src/scripts/backfill_problem_questions.js`
- **Actions :**
  1. Ajouter le modèle `ProblemQuestion`.
  2. Étendre `ExamProblem` (`weightTest`, `weightAst`, `weightAi`, `questionPoints`).
  3. Mettre à jour `Grade` (`questionId`).
  4. Exécuter `npx prisma db push` / migration.
  5. Exécuter le script de backfill idempotent pour créer la `ProblemQuestion` 1 par défaut sur tous les problèmes existants.

---

## Phase 1 : Problem Studio & Outil d'Insertion des Marqueurs
- **Fichiers :** `client/src/components/ProblemStudio.jsx`, `server/src/controllers/problem.controller.js`
- **Actions :**
  1. Ajouter la gestion des sous-questions dans le Studio (Ajout, suppression, réordonnancement `orderIndex`, éditeur Markdown par question).
  2. Ajouter le bouton CodeMirror **"🏷️ Insérer Marqueur Question"** qui insère à la position du curseur :
     ```algo
     // question N starts here
     
     // question N ends here
     ```
  3. Ajouter la validation à l'enregistrement : chaque balise ouvrante `// question N starts here` doit avoir sa balise fermante exacte `// question N ends here`, et `N` doit exister dans les questions du problème.
  4. Avertir l'enseignant en cas de suppression d'une question ayant des marqueurs orphelins dans le code modèle.

---

## Phase 2 : Verrouillage des Zones Côté Étudiant (`ExamWorkspace.jsx`)
- **Fichiers :** `client/src/components/ExamWorkspace.jsx`, `server/src/controllers/student.controller.js`
- **Actions :**
  1. Dans CodeMirror 6, configurer un filtre de modification (`EditorState.changeFilter` / extensions de plages en lecture seule) :
     - Les lignes de marqueurs `// question N starts here` et `// question N ends here` sont **strictement non éditables et non supprimables**.
     - Les zones **entre** les marqueurs sont totalement libres d'édition (ajouts, modifications, suppressions).
  2. Intercepter le copier-coller pour empêcher l'écrasement global qui supprimerait les balises.
  3. **Filet de sécurité serveur** : dans `autosaveCode` et `finalizeExam`, vérifier la présence et l'intégrité des balises de marqueurs. Si altérées, marquer la copie pour révision enseignant.

---

## Phase 3 : Barème et Pondérations dans `ExamManager.jsx`
- **Fichiers :** `client/src/components/ExamManager.jsx`, `server/src/controllers/exam.controller.js`
- **Actions :**
  1. Lorsque le problème a $N$ sous-questions, le champ des points de l'exercice se déploie en $N$ sous-champs dont la somme égale la note de l'exercice.
  2. Respecter la règle d'or : **ne jamais réinitialiser ou redistribuer les points existants** lors de l'ajout d'une nouvelle question.
  3. Ajouter les champs de pondération (`Tests %`, `AST %`, `IA %`) par problème, avec les valeurs par défaut **40% / 60% / 0%** (ou **100% AST** si problème multi-questions sans tests unitaires globaux).
  4. Valider `weightTest + weightAst + weightAi === 100` côté client et côté serveur.

---

## Phase 4 : Découpage AST & Évaluation Multi-Questions
- **Fichiers :** `server/src/runner/ast-similarity.service.js`, `server/src/controllers/grading.controller.js`, `client/src/components/CorrectionWorkspace.jsx`
- **Actions :**
  1. Extraire les blocs de code étudiant et de solution repère pour chaque question $N$ selon les délimiteurs.
  2. Calculer l'arbre AST et le score de similarité de manière indépendante pour chaque sous-question.
  3. Agréger la note par question :  
     $$\text{Score}_Q = \frac{\text{Test} \times W_{\text{test}} + \text{AST} \times W_{\text{ast}} + \text{IA} \times W_{\text{ia}}}{100}$$
     *(L'appel IA est totalement court-circuité si $W_{\text{ia}} = 0$ pour éviter tout coût).*
  4. Calculer la note globale de l'exercice par moyenne pondérée des points des questions.
  5. Afficher la décomposition détaillée par sous-question dans l'interface `CorrectionWorkspace.jsx`.

---

## Phase 5 : Import en Masse depuis `AlgoCompiler/examples`
- **Fichiers :** `server/src/scripts/import_examples_to_problem_bank.js`
- **Actions :**
  1. Parcourir les ~62 fichiers `.algo` classés dans `AlgoCompiler/examples/`.
  2. Détecter automatiquement :
     - Problème à fonction unique $\rightarrow$ 1 `Problem`, 1 `ProblemQuestion`.
     - Problème multi-fonctions $\rightarrow$ Découpage en sous-questions avec insertion automatique des marqueurs `// question N starts/ends here`.
  3. Créer les entrées via le contrôleur officiel `problem.controller.js` pour garantir les validations.
  4. Mode *Dry Run* préalable pour valider l'intégrité avant insertion réelle.
