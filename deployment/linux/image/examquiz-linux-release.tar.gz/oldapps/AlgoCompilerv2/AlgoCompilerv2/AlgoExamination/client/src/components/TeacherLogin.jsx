import React, { useState } from 'react';
import { teacherLogin } from '../services/api';
import { ShieldCheck, LogIn, GraduationCap, Eye, Building, Lock } from 'lucide-react';
import Swal from 'sweetalert2';

const STAFF_ROLES = [
  {
    id: 'TEACHER',
    label: 'Enseignant',
    icon: GraduationCap,
    email: 'teacher@esi.dz',
    color: '#3b82f6',
    desc: 'Création d’épreuves, gestion des modèles, correction anonyme & attribution des notes.'
  },
  {
    id: 'PROCTOR',
    label: 'Surveillant',
    icon: Eye,
    email: 'surveillance@esi.dz',
    color: '#10b981',
    desc: 'Lancement de salle, suivi en temps réel des présences, anti-triche & export .algobundle.'
  },
  {
    id: 'ADMIN',
    label: 'Administration',
    icon: Building,
    email: 'admin@esi.dz',
    color: '#f59e0b',
    desc: 'Service Scolarité : résultats dé-anonymisés, PVs officiels, statistiques & recours PDF.'
  }
];

export default function TeacherLogin({ onLoginSuccess }) {
  const getInitialRole = () => {
    const port = window.location.port;
    const path = window.location.pathname.toLowerCase();
    if (port === '5176' || path.startsWith('/surveillance')) return 'PROCTOR';
    if (port === '5177' || path.startsWith('/admin')) return 'ADMIN';
    return 'TEACHER';
  };

  const initialRole = getInitialRole();
  const initialRoleObj = STAFF_ROLES.find(r => r.id === initialRole) || STAFF_ROLES[0];

  const [selectedRole, setSelectedRole] = useState(initialRole);
  const [email, setEmail] = useState(initialRoleObj.email);
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);

  const handleRoleSelect = (role) => {
    setSelectedRole(role.id);
    setEmail(role.email);
    setPassword('admin123');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await teacherLogin(email, password);
      const userRole = data.teacher?.role || selectedRole;
      localStorage.setItem('token', data.token);
      localStorage.setItem('userRole', userRole);
      localStorage.setItem('userName', data.teacher?.name || 'Utilisateur');

      // Seamless redirect depending on role
      if (userRole === 'PROCTOR') {
        window.history.replaceState({}, '', '/surveillance');
      } else if (userRole === 'ADMIN') {
        window.history.replaceState({}, '', '/admin');
      } else {
        window.history.replaceState({}, '', '/teacher');
      }

      onLoginSuccess(data);
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Authentification échouée',
        text: err.data?.error || 'Email ou mot de passe incorrect.',
        background: '#111827',
        color: '#ffffff',
        confirmButtonColor: '#ef4444'
      });
    } finally {
      setLoading(false);
    }
  };

  const activeRoleObj = STAFF_ROLES.find(r => r.id === selectedRole) || STAFF_ROLES[0];

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', background: 'var(--bg-color)' }}>
      <div className="glass-panel" style={{ width: '100%', maxWidth: '520px', padding: '36px', border: `1px solid ${activeRoleObj.color}40`, boxShadow: `0 8px 32px ${activeRoleObj.color}15` }}>
        
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{
            width: '60px', height: '60px', borderRadius: '16px',
            background: `${activeRoleObj.color}20`,
            border: `1px solid ${activeRoleObj.color}60`,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: '12px'
          }}>
            <activeRoleObj.icon size={30} color={activeRoleObj.color} />
          </div>
          <h2 style={{ margin: '0 0 6px 0', fontSize: '1.5rem', fontWeight: '800', color: '#f8fafc' }}>
            Portail Pédagogique & Personnel
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', margin: 0 }}>
            {activeRoleObj.desc}
          </p>
        </div>

        {/* Role Switcher Tabs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', marginBottom: '24px' }}>
          {STAFF_ROLES.map((role) => {
            const isSelected = selectedRole === role.id;
            const Icon = role.icon;
            return (
              <button
                key={role.id}
                type="button"
                onClick={() => handleRoleSelect(role)}
                style={{
                  padding: '10px 8px',
                  borderRadius: '8px',
                  border: isSelected ? `2px solid ${role.color}` : '1px solid #334155',
                  background: isSelected ? `${role.color}20` : 'rgba(15, 23, 42, 0.6)',
                  color: isSelected ? '#fff' : '#94a3b8',
                  fontWeight: isSelected ? '800' : '600',
                  fontSize: '0.82rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '6px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
              >
                <Icon size={18} color={isSelected ? role.color : '#94a3b8'} />
                <span>{role.label}</span>
              </button>
            );
          })}
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit}>
          <div className="form-group" style={{ marginBottom: '16px' }}>
            <label htmlFor="staffEmail" style={{ fontSize: '0.84rem', color: '#cbd5e1', marginBottom: '6px', display: 'block' }}>
              Adresse E-mail ({activeRoleObj.label})
            </label>
            <input
              id="staffEmail"
              type="email"
              className="form-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{ fontSize: '0.9rem', padding: '10px 14px' }}
            />
          </div>

          <div className="form-group" style={{ marginBottom: '22px' }}>
            <label htmlFor="staffPassword" style={{ fontSize: '0.84rem', color: '#cbd5e1', marginBottom: '6px', display: 'block' }}>
              Mot de passe
            </label>
            <input
              id="staffPassword"
              type="password"
              className="form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{ fontSize: '0.9rem', padding: '10px 14px' }}
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            style={{
              width: '100%',
              padding: '12px',
              fontSize: '0.92rem',
              fontWeight: '800',
              background: `linear-gradient(135deg, ${activeRoleObj.color} 0%, ${activeRoleObj.color}cc 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px'
            }}
            disabled={loading}
          >
            {loading ? (
              'Connexion en cours...'
            ) : (
              <>
                <LogIn size={18} /> Se Connecter en tant que {activeRoleObj.label}
              </>
            )}
          </button>
        </form>

        {/* Quick Credentials Info Box */}
        <div style={{
          marginTop: '20px',
          padding: '12px',
          borderRadius: '8px',
          background: 'rgba(30, 41, 59, 0.5)',
          border: '1px solid rgba(255, 255, 255, 0.05)',
          fontSize: '0.78rem',
          color: '#94a3b8',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            Compte : <strong style={{ color: '#fff' }}>{email}</strong>
          </div>
          <div>
            MdP : <strong style={{ color: '#34d399' }}>admin123</strong>
          </div>
        </div>
      </div>
    </div>
  );
}
