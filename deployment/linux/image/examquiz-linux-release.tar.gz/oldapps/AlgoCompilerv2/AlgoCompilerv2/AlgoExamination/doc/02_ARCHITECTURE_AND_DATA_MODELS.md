# 02. System Architecture & Data Models

## 🏗️ Architecture & Directory Layout

```
AlgoExamination/
├── client/                     # Frontend Application (React + Vite)
│   ├── src/
│   │   ├── components/         # Page & Feature Components
│   │   │   ├── CorrectionWorkspace.jsx   # Interactive Grading & Master PDF/ZIP
│   │   │   ├── ExamCompleted.jsx         # Post-Exam Confirmation Page
│   │   │   ├── ExamManager.jsx           # Single-Page Exam Creation & Barème Form
│   │   │   ├── ExamResults.jsx           # Exam Results Table & CSV Exporter
│   │   │   ├── ExamWorkspace.jsx         # Student Algorithmic Editor & Runner
│   │   │   ├── ProblemBank.jsx           # Problem & Test Case Repository
│   │   │   ├── StudentDashboard.jsx      # Student Portal
│   │   │   ├── StudentLogin.jsx          # Student Access Number Login
│   │   │   ├── StudentManager.jsx        # Roster & Student Account Management
│   │   │   ├── TeacherDashboard.jsx      # Live Anti-Cheat Monitoring & Control
│   │   │   ├── TeacherLogin.jsx          # Teacher Authentication
│   │   │   └── WaitingRoom.jsx           # Student Pre-Exam Gate & Socket Sync
│   │   ├── services/
│   │   │   ├── api.js                    # Fetch Wrapper for REST Endpoints
│   │   │   └── socket.js                 # Socket.IO Singleton Client Instance
│   │   └── utils/
│   │       └── algo-language.js          # Algorithmic Language Tokens & Syntax Rules
│   └── package.json
│
├── server/                     # Backend Application (Node.js + Express)
│   ├── prisma/
│   │   └── schema.prisma         # Prisma Schema Definition (schema: "exam")
│   ├── src/
│   │   ├── controllers/
│   │   │   ├── auth.controller.js        # Student & Teacher Login Handlers
│   │   │   ├── exam.controller.js        # Exam CRUD, Scheduling & Status Handlers
│   │   │   ├── grading.controller.js     # Grading, Syntax Analyzer & PDF/ZIP Handlers
│   │   │   ├── problem.controller.js     # Problem Bank CRUD
│   │   │   ├── student-mgmt.controller.js# Roster Management
│   │   │   └── student.controller.js    # Student Workspace, Autosave & Violation Log
│   │   ├── middleware/
│   │   │   └── auth.middleware.js       # JWT Verification for Teacher & Student
│   │   ├── runner/
│   │   │   └── code-execution.service.js# Child Process Sandbox Pseudo-code Evaluator
│   │   ├── services/
│   │   │   └── pdf.service.js           # PDFKit B&W Document & HMAC QR Engine
│   │   ├── sockets/
│   │   │   └── exam.socket.js           # Socket.IO Event Handlers & Room Broadcasts
│   │   ├── index.js                     # Express Server & Socket.IO Entry Point
│   │   └── prisma.js                    # Prisma Client Connection Singleton
│   └── package.json
└── doc/                        # System Documentation for LLM Agents
```

---

## 🗄️ Database Schema Summary (`schema.prisma`)

```prisma
model Exam {
  id                   String           @id @default(uuid())
  title                String
  description          String?
  university           String?          // e.g. "École Nationale Supérieure d'Informatique"
  module               String?          // e.g. "Algorithmique et Structure de Données"
  session              String?          // e.g. "2025/2026 — Semestre 1"
  date                 DateTime?
  startTime            DateTime?
  durationMinutes      Int
  status               ExamStatus       @default(DRAFT) // DRAFT, SCHEDULED, WAITING, RUNNING, PAUSED, FINISHED, CLOSED
  teacherId            String
  prefix               String           @default("AL")
  maxViolationsAllowed Int              @default(4)
  copyDisabled         Boolean          @default(true)
  pasteDisabled        Boolean          @default(true)
  fullscreenRequired   Boolean          @default(true)
  internetWarning      Boolean          @default(true)
  allowedLanguages     String[]         @default(["ALGO"])

  problems             ExamProblem[]
  assignments          ExamAssignment[]
  announcements        Announcement[]
  incidents            Incident[]
  createdAt            DateTime         @default(now())
  updatedAt            DateTime         @updatedAt
}

model ExamAssignment {
  id               String            @id @default(uuid())
  examId           String
  studentId        String
  accessNumber     String            // e.g. "AL202601"
  status           StudentExamStatus @default(NOT_ENTERED) // NOT_ENTERED, WAITING, IN_EXAM, DISCONNECTED, PAUSED, FINISHED, KICKED_OUT, ABSENT
  loginTime        DateTime?
  startedAt        DateTime?
  finishedAt       DateTime?
  timeExtendedMs   Int               @default(0)
  currentCodeMap   Json?             // Autosaved code per problem ID
  violations       Int               @default(0)
  fullscreenExits  Int               @default(0)  // 3-strike counter
  isOnline         Boolean           @default(false)
  lastSeenAt       DateTime?
  finalScore       Float?            // Scaled score out of /20
  gradingStatus    GradingStatus     @default(UNGRADED) // UNGRADED, IN_PROGRESS, GRADED
  generalFeedback  String?
}

model ExamProblem {
  id         String   @id @default(uuid())
  examId     String
  problemId  String
  orderIndex Int
  points     Int?     // Override points for this specific exam
}
```

---

## ⚡ Socket.IO Event Reference

### Channels & Rooms
- **Teacher Room**: `exam_${examId}` — Receives all student status changes, monitoring events, and submissions.
- **Student Individual Room**: `student_${studentId}` — Receives target commands (`student_locked`, `student_unlocked`, `student_terminated`, `student_fullscreen_warning`).

### Server Emission Events

| Event Name | Room | Payload Description |
|---|---|---|
| `exam_status_changed` | `exam_${examId}` | Broadcasts exam status updates (`WAITING`, `RUNNING`, `PAUSED`, `FINISHED`, `CLOSED`). |
| `exam_started` | `exam_${examId}` | Triggers student workspace transition when teacher launches exam. |
| `exam_force_ended` | `exam_${examId}` | Redirects all active students to completion page. |
| `student_status_changed` | `exam_${examId}` | Broadcasts student state, online status, violations, and fullscreen exits. |
| `live_monitoring_event` | `exam_${examId}` | Emits real-time anti-cheat violation event to teacher monitoring panel. |
| `pdf_zip_progress` | `exam_${examId}` | Streams master ZIP export progress `{ done, total, studentName, status }`. |
| `student_locked` | `student_${studentId}` | Locks student workspace when suspended. |
| `student_unlocked` | `student_${studentId}` | Unlocks student workspace when teacher resumes student. |
| `student_terminated` | `student_${studentId}` | Forces student session to end on exclusion or 3-strike fullscreen exit. |
