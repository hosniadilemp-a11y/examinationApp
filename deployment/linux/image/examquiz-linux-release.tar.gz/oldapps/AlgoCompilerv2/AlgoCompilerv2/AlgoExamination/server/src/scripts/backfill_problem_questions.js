const prisma = require('../prisma');

async function backfillProblemQuestions() {
  console.log('🔄 Starting idempotent backfill for ProblemQuestion...');
  try {
    const problems = await prisma.problem.findMany({
      include: {
        questions: true
      }
    });

    console.log(`Found ${problems.length} total problems.`);
    let createdCount = 0;
    let skippedCount = 0;

    for (const p of problems) {
      if (p.questions && p.questions.length > 0) {
        skippedCount++;
        continue;
      }

      // Create Question 1 with existing statement
      await prisma.problemQuestion.create({
        data: {
          problemId: p.id,
          orderIndex: 1,
          statement: p.description || p.title
        }
      });
      createdCount++;
    }

    console.log(`✅ Backfill complete! Created: ${createdCount}, Already had questions: ${skippedCount}`);
  } catch (err) {
    console.error('❌ Backfill failed:', err);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

if (require.main === module) {
  backfillProblemQuestions();
}

module.exports = { backfillProblemQuestions };
