# Plan 3 : Matrice de Vérification, Cas Limites & Sécurité

Ce document définit les cas de test, protections anti-triche et vérifications de sécurité requises par `extensions.txt`.

---

## 1. Matrice des Cas Limites (Edge Cases)

| Composant | Scénario Testé | Comportement Attendu |
| :--- | :--- | :--- |
| **Problem Studio** | Marqueurs asymétriques (ex: `start 1` sans `end 1`) | ❌ Refus d'enregistrement avec message explicite (`Marqueur // question 1 ends here manquant`). |
| **Problem Studio** | Marqueur pour une question inexistante (ex: `question 5` alors qu'il n'y a que 2 questions) | ❌ Refus d'enregistrement (`L'index de question 5 n'existe pas`). |
| **Problem Studio** | Suppression d'une question avec marqueurs encore présents dans le code | ⚠️ Alerte de confirmation signalant des marqueurs orphelins. |
| **Exam Workspace** | Étudiant tente d'effacer la ligne du marqueur (Touche Retour / Suppr) | 🛡️ Action bloquée : le curseur saute ou la frappe est ignorée. |
| **Exam Workspace** | Étudiant sélectionne tout (`Ctrl+A`) et appuie sur Suppr | 🛡️ Seul le contenu entre les marqueurs est vidé ; les lignes de marqueurs restent intactes. |
| **Exam Workspace** | Étudiant colle (`Ctrl+V`) un gros bloc écrasant les marqueurs | 🛡️ Filtrage du collage : insertion effectuée uniquement dans la zone active sans altérer les balises. |
| **Exam Manager** | Pondérations dont la somme $\neq 100\%$ (ex: 40 + 50 + 0 = 90%) | ❌ Blocage client et rejet HTTP 400 côté serveur. |
| **Grading Controller** | Correction d'un problème avec `weightAi = 0` | ⚡ Aucun appel API LLM/Ollama n'est déclenché (coût = 0, latence minimale). |
| **Grading Controller** | Code étudiant avec balises corrompues ou contournées | 🚩 Marqué `FLAGGED_FOR_REVIEW` pour inspection manuelle de l'enseignant. |
| **Migration DB** | Ré-exécution du script de backfill sur une base déjà migrée | 🔄 Idempotent : 0 doublon créé, base inchangée. |

---

## 2. Procédure de Test et Commandes de Validation

### A. Validation de la Base de Données
```bash
# 1. Tester la migration Prisma
npx prisma db push

# 2. Exécuter le test de backfill idempotent
node server/src/scripts/backfill_problem_questions.js --dry-run
node server/src/scripts/backfill_problem_questions.js
```

### B. Validation du Moteur de Scoring AST Découpé
```bash
# Tester le découpage et le calcul de similarité AST par question
node server/tests/test_ast_slicing_multi_question.js
```

### C. Validation Frontend (Vite)
```bash
cd client
PATH="/home/adel/.local/node-v20/bin:$PATH" npm run build
```

---

## 3. Checklist de Validation Finale

- [ ] Migration Prisma appliquée proprement sur les données existantes.
- [ ] Lignes de marqueurs impossibles à supprimer dans l'éditeur étudiant `ExamWorkspace.jsx`.
- [ ] Formulaire de pondération refuse toute somme différente de 100%.
- [ ] Aucun appel IA effectué si `weightAi === 0`.
- [ ] La répartition automatique des points préserve les notes existantes sans réinitialisation.
- [ ] L'import en masse des ~62 exemples de `AlgoCompiler/examples` s'exécute sans erreur.
