const prisma = require('./prisma');

async function seed10AlgoCompilerProblems() {
  console.log('Cleaning redundant problems and seeding 10 AlgoCompiler problems with 12+ test cases each...');

  const problemsData = [
    {
      title: 'Somme de Deux Entiers',
      topic: 'Basics',
      difficulty: 'Easy',
      points: 10,
      description: `### Objectif\nÉcrire un algorithme qui lit deux entiers \`A\` et \`B\` puis affiche leur somme.\n\n#### Format d'entrée\n- Ligne 1: \`A\`\n- Ligne 2: \`B\`\n\n#### Format de sortie\n- La somme \`A + B\``,
      templateCode: {
        ALGO: `Algorithme SommeDeuxEntiers;\nVar\n    A, B, S : Entier;\nDebut\n    Lire(A);\n    Lire(B);\n    S := A + B;\n    Ecrire(S);\nFin.`
      },
      referenceSolution: `Algorithme Solution_Somme_de_Deux_Entiers;\nVar\n   A, B, Somme : Entier;\nDebut\n   Lire(A);\n   Lire(B);\n   Somme := A + B;\n   Ecrire(Somme);\nFin.`,
      testCases: [
        { inputData: '5\n10', expectedOutput: '15', isPublic: true },
        { inputData: '-3\n7', expectedOutput: '4', isPublic: true },
        { inputData: '0\n0', expectedOutput: '0', isPublic: false },
        { inputData: '100\n200', expectedOutput: '300', isPublic: false },
        { inputData: '-50\n-50', expectedOutput: '-100', isPublic: false },
        { inputData: '999\n1', expectedOutput: '1000', isPublic: false },
        { inputData: '1234\n5678', expectedOutput: '6912', isPublic: false },
        { inputData: '-123\n456', expectedOutput: '333', isPublic: false },
        { inputData: '88\n-88', expectedOutput: '0', isPublic: false },
        { inputData: '1\n-99', expectedOutput: '-98', isPublic: false },
        { inputData: '42\n42', expectedOutput: '84', isPublic: false },
        { inputData: '100000\n200000', expectedOutput: '300000', isPublic: false }
      ]
    },
    {
      title: 'Maximum d\'un Tableau',
      topic: 'Arrays',
      difficulty: 'Medium',
      points: 20,
      description: `### Objectif\nÉcrire un algorithme qui lit la taille \`N\` puis \`N\` entiers et affiche la valeur maximale.\n\n#### Format d'entrée\n- Ligne 1: \`N\`\n- Lignes suivantes: \`N\` entiers`,
      templateCode: {
        ALGO: `Algorithme MaxTableau;\nVar\n    N, i, val, maxVal : Entier;\nDebut\n    Lire(N);\n    Lire(maxVal);\n    Pour i := 2 a N Faire\n        Lire(val);\n        Si (val > maxVal) Alors\n            maxVal := val;\n        FinSi;\n    FinPour;\n    Ecrire(maxVal);\nFin.`
      },
      referenceSolution: `Algorithme Solution_Max_Tableau;\nVar\n   N, i, val, maxVal : Entier;\nDebut\n   Lire(N);\n   Lire(maxVal);\n   Pour i := 2 a N Faire\n      Lire(val);\n      Si (val > maxVal) Alors\n         maxVal := val;\n      FinSi;\n   FinPour;\n   Ecrire(maxVal);\nFin.`,
      testCases: [
        { inputData: '4\n12\n5\n28\n14', expectedOutput: '28', isPublic: true },
        { inputData: '3\n-5\n-1\n-10', expectedOutput: '-1', isPublic: true },
        { inputData: '1\n42', expectedOutput: '42', isPublic: false },
        { inputData: '5\n1\n2\n3\n4\n5', expectedOutput: '5', isPublic: false },
        { inputData: '5\n5\n4\n3\n2\n1', expectedOutput: '5', isPublic: false },
        { inputData: '6\n-10\n-20\n-5\n-30\n-50\n-2', expectedOutput: '-2', isPublic: false },
        { inputData: '4\n100\n100\n100\n100', expectedOutput: '100', isPublic: false },
        { inputData: '3\n0\n0\n0', expectedOutput: '0', isPublic: false },
        { inputData: '7\n10\n20\n30\n40\n50\n60\n70', expectedOutput: '70', isPublic: false },
        { inputData: '5\n99\n1\n2\n3\n4', expectedOutput: '99', isPublic: false },
        { inputData: '4\n-100\n0\n-200\n50', expectedOutput: '50', isPublic: false },
        { inputData: '6\n7\n8\n9\n10\n11\n12', expectedOutput: '12', isPublic: false }
      ]
    },
    {
      title: 'Tri à Bulles',
      topic: 'Sorting',
      difficulty: 'Medium',
      points: 20,
      description: `### Objectif\nTrier un tableau de \`N\` entiers par ordre croissant avec l'algorithme du Tri à Bulles.\n\n#### Format de sortie\n- Les éléments triés séparés par un espace.`,
      templateCode: {
        ALGO: `Algorithme TriABulles;\nVar\n    N, i, j, temp : Entier;\n    T[100] : Entier;\nDebut\n    Lire(N);\n    Pour i := 1 a N Faire\n        Lire(T[i]);\n    FinPour;\n    Pour i := 1 a N - 1 Faire\n        Pour j := 1 a N - i Faire\n            Si (T[j] > T[j+1]) Alors\n                temp := T[j];\n                T[j] := T[j+1];\n                T[j+1] := temp;\n            FinSi;\n        FinPour;\n    FinPour;\n    Pour i := 1 a N Faire\n        Ecrire(T[i], " ");\n    FinPour;\nFin.`
      },
      referenceSolution: `Algorithme Solution_Tri_A_Bulles;\nVar\n   N, i, j, temp : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 1 a N - 1 Faire\n      Pour j := 1 a N - i Faire\n         Si (T[j] > T[j+1]) Alors\n            temp := T[j];\n            T[j] := T[j+1];\n            T[j+1] := temp;\n         FinSi;\n      FinPour;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.`,
      testCases: [
        { inputData: '4\n5\n2\n8\n1', expectedOutput: '1 2 5 8', isPublic: true },
        { inputData: '3\n9\n3\n6', expectedOutput: '3 6 9', isPublic: true },
        { inputData: '1\n42', expectedOutput: '42', isPublic: false },
        { inputData: '5\n5\n4\n3\n2\n1', expectedOutput: '1 2 3 4 5', isPublic: false },
        { inputData: '5\n1\n2\n3\n4\n5', expectedOutput: '1 2 3 4 5', isPublic: false },
        { inputData: '4\n-3\n0\n-10\n5', expectedOutput: '-10 -3 0 5', isPublic: false },
        { inputData: '6\n12\n5\n9\n1\n7\n3', expectedOutput: '1 3 5 7 9 12', isPublic: false },
        { inputData: '2\n20\n10', expectedOutput: '10 20', isPublic: false },
        { inputData: '5\n100\n-100\n0\n50\n-50', expectedOutput: '-100 -50 0 50 100', isPublic: false },
        { inputData: '3\n7\n7\n7', expectedOutput: '7 7 7', isPublic: false },
        { inputData: '4\n15\n2\n8\n10', expectedOutput: '2 8 10 15', isPublic: false },
        { inputData: '6\n4\n2\n6\n1\n5\n3', expectedOutput: '1 2 3 4 5 6', isPublic: false }
      ]
    },
    {
      title: 'Inversion d\'un Tableau',
      topic: 'Arrays',
      difficulty: 'Easy',
      points: 15,
      description: `### Objectif\nInverser les éléments d'un tableau de \`N\` entiers sur place.`,
      templateCode: {
        ALGO: `Algorithme InversionTableau;\nVar\n    N, i, temp : Entier;\n    T[100] : Entier;\nDebut\n    Lire(N);\n    Pour i := 1 a N Faire\n        Lire(T[i]);\n    FinPour;\n    Pour i := 1 a N / 2 Faire\n        temp := T[i];\n        T[i] := T[N - i + 1];\n        T[N - i + 1] := temp;\n    FinPour;\n    Pour i := 1 a N Faire\n        Ecrire(T[i], " ");\n    FinPour;\nFin.`
      },
      referenceSolution: `Algorithme Solution_Inversion_Tableau;\nVar\n   N, i, temp : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 1 a N / 2 Faire\n      temp := T[i];\n      T[i] := T[N - i + 1];\n      T[N - i + 1] := temp;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.`,
      testCases: [
        { inputData: '4\n1\n2\n3\n4', expectedOutput: '4 3 2 1', isPublic: true },
        { inputData: '3\n10\n20\n30', expectedOutput: '30 20 10', isPublic: true },
        { inputData: '1\n99', expectedOutput: '99', isPublic: false },
        { inputData: '5\n5\n4\n3\n2\n1', expectedOutput: '1 2 3 4 5', isPublic: false },
        { inputData: '2\n7\n8', expectedOutput: '8 7', isPublic: false },
        { inputData: '6\n1\n2\n3\n4\n5\n6', expectedOutput: '6 5 4 3 2 1', isPublic: false },
        { inputData: '4\n-1\n-2\n-3\n-4', expectedOutput: '-4 -3 -2 -1', isPublic: false },
        { inputData: '5\n100\n200\n300\n400\n500', expectedOutput: '500 400 300 200 100', isPublic: false },
        { inputData: '3\n0\n0\n1', expectedOutput: '1 0 0', isPublic: false },
        { inputData: '4\n5\n10\n15\n20', expectedOutput: '20 15 10 5', isPublic: false },
        { inputData: '5\n1\n1\n2\n2\n3', expectedOutput: '3 2 2 1 1', isPublic: false },
        { inputData: '6\n9\n8\n7\n6\n5\n4', expectedOutput: '4 5 6 7 8 9', isPublic: false }
      ]
    },
    {
      title: 'Recherche Dichotomique',
      topic: 'Arrays',
      difficulty: 'Hard',
      points: 25,
      description: `### Objectif\nRechercher la position d'une valeur cible \`X\` dans un tableau trié de \`N\` entiers (ou -1 si absente).`,
      templateCode: {
        ALGO: `Algorithme RechercheDichotomique;\nVar\n    N, X, deb, f, milieu, pos, i : Entier;\n    T[100] : Entier;\nDebut\n    Lire(N);\n    Lire(X);\n    Pour i := 1 a N Faire\n        Lire(T[i]);\n    FinPour;\n    deb := 1;\n    f := N;\n    pos := -1;\n    TantQue (deb <= f Et pos = -1) Faire\n        milieu := (deb + f) / 2;\n        Si (T[milieu] = X) Alors\n            pos := milieu;\n        Sinon\n            Si (T[milieu] < X) Alors\n                deb := milieu + 1;\n            Sinon\n                f := milieu - 1;\n            FinSi;\n        FinSi;\n    FinTantQue;\n    Ecrire(pos);\nFin.`
      },
      referenceSolution: `Algorithme Solution_Recherche_Dichotomique;\nVar\n   N, X, deb, f, milieu, pos, i : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Lire(X);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   deb := 1;\n   f := N;\n   pos := -1;\n   TantQue (deb <= f Et pos = -1) Faire\n      milieu := (deb + f) / 2;\n      Si (T[milieu] = X) Alors\n         pos := milieu;\n      Sinon\n         Si (T[milieu] < X) Alors deb := milieu + 1;\n         Sinon f := milieu - 1;\n         FinSi;\n      FinSi;\n   FinTantQue;\n   Ecrire(pos);\nFin.`,
      testCases: [
        { inputData: '5\n7\n1\n3\n5\n7\n9', expectedOutput: '4', isPublic: true },
        { inputData: '4\n10\n2\n4\n6\n8', expectedOutput: '-1', isPublic: true },
        { inputData: '1\n5\n5', expectedOutput: '1', isPublic: false },
        { inputData: '1\n3\n5', expectedOutput: '-1', isPublic: false },
        { inputData: '5\n1\n1\n3\n5\n7\n9', expectedOutput: '1', isPublic: false },
        { inputData: '5\n9\n1\n3\n5\n7\n9', expectedOutput: '5', isPublic: false },
        { inputData: '6\n4\n1\n2\n3\n4\n5\n6', expectedOutput: '4', isPublic: false },
        { inputData: '6\n0\n1\n2\n3\n4\n5\n6', expectedOutput: '-1', isPublic: false },
        { inputData: '6\n7\n1\n2\n3\n4\n5\n6', expectedOutput: '-1', isPublic: false },
        { inputData: '5\n20\n10\n20\n30\n40\n50', expectedOutput: '2', isPublic: false },
        { inputData: '4\n-5\n-10\n-5\n0\n5', expectedOutput: '2', isPublic: false },
        { inputData: '5\n50\n10\n20\n30\n40\n50', expectedOutput: '5', isPublic: false }
      ]
    },
    {
      title: 'Tri par Sélection',
      topic: 'Sorting',
      difficulty: 'Medium',
      points: 20,
      description: `### Objectif\nTrier un tableau de \`N\` entiers par sélection du minimum.`,
      templateCode: {
        ALGO: `Algorithme TriSelection;\nVar\n    N, i, j, minIdx, temp : Entier;\n    T[100] : Entier;\nDebut\n    Lire(N);\n    Pour i := 1 a N Faire\n        Lire(T[i]);\n    FinPour;\n    Pour i := 1 a N - 1 Faire\n        minIdx := i;\n        Pour j := i + 1 a N Faire\n            Si (T[j] < T[minIdx]) Alors\n                minIdx := j;\n            FinSi;\n        FinPour;\n        temp := T[i];\n        T[i] := T[minIdx];\n        T[minIdx] := temp;\n    FinPour;\n    Pour i := 1 a N Faire\n        Ecrire(T[i], " ");\n    FinPour;\nFin.`
      },
      referenceSolution: `Algorithme Solution_Tri_Selection;\nVar\n   N, i, j, minIdx, temp : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 1 a N - 1 Faire\n      minIdx := i;\n      Pour j := i + 1 a N Faire\n         Si (T[j] < T[minIdx]) Alors minIdx := j; FinSi;\n      FinPour;\n      temp := T[i]; T[i] := T[minIdx]; T[minIdx] := temp;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.`,
      testCases: [
        { inputData: '4\n4\n1\n3\n2', expectedOutput: '1 2 3 4', isPublic: true },
        { inputData: '3\n30\n10\n20', expectedOutput: '10 20 30', isPublic: true },
        { inputData: '1\n7', expectedOutput: '7', isPublic: false },
        { inputData: '5\n50\n40\n30\n20\n10', expectedOutput: '10 20 30 40 50', isPublic: false },
        { inputData: '5\n10\n20\n30\n40\n50', expectedOutput: '10 20 30 40 50', isPublic: false },
        { inputData: '4\n-5\n2\n-1\n0', expectedOutput: '-5 -1 0 2', isPublic: false },
        { inputData: '6\n8\n3\n1\n7\n4\n2', expectedOutput: '1 2 3 4 7 8', isPublic: false },
        { inputData: '2\n9\n1', expectedOutput: '1 9', isPublic: false },
        { inputData: '5\n3\n1\n4\n1\n5', expectedOutput: '1 1 3 4 5', isPublic: false },
        { inputData: '4\n100\n25\n75\n50', expectedOutput: '25 50 75 100', isPublic: false },
        { inputData: '3\n-10\n-30\n-20', expectedOutput: '-30 -20 -10', isPublic: false },
        { inputData: '6\n6\n5\n4\n3\n2\n1', expectedOutput: '1 2 3 4 5 6', isPublic: false }
      ]
    },
    {
      title: 'Tri par Insertion',
      topic: 'Sorting',
      difficulty: 'Medium',
      points: 20,
      description: `### Objectif\nTrier un tableau de \`N\` entiers par insertion d'élément dans la sous-partie triée.`,
      templateCode: {
        ALGO: `Algorithme TriInsertion;\nVar\n    N, i, j, cle : Entier;\n    T[100] : Entier;\nDebut\n    Lire(N);\n    Pour i := 1 a N Faire\n        Lire(T[i]);\n    FinPour;\n    Pour i := 2 a N Faire\n        cle := T[i];\n        j := i - 1;\n        TantQue (j >= 1 Et T[j] > cle) Faire\n            T[j+1] := T[j];\n            j := j - 1;\n        FinTantQue;\n        T[j+1] := cle;\n    FinPour;\n    Pour i := 1 a N Faire\n        Ecrire(T[i], " ");\n    FinPour;\nFin.`
      },
      referenceSolution: `Algorithme Solution_Tri_Insertion;\nVar\n   N, i, j, cle : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 2 a N Faire\n      cle := T[i]; j := i - 1;\n      TantQue (j >= 1 Et T[j] > cle) Faire\n         T[j+1] := T[j]; j := j - 1;\n      FinTantQue;\n      T[j+1] := cle;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.`,
      testCases: [
        { inputData: '3\n9\n2\n5', expectedOutput: '2 5 9', isPublic: true },
        { inputData: '4\n12\n11\n13\n5', expectedOutput: '5 11 12 13', isPublic: true },
        { inputData: '1\n100', expectedOutput: '100', isPublic: false },
        { inputData: '5\n5\n4\n3\n2\n1', expectedOutput: '1 2 3 4 5', isPublic: false },
        { inputData: '5\n1\n2\n3\n4\n5', expectedOutput: '1 2 3 4 5', isPublic: false },
        { inputData: '4\n-2\n-5\n10\n0', expectedOutput: '-5 -2 0 10', isPublic: false },
        { inputData: '6\n7\n2\n9\n1\n5\n4', expectedOutput: '1 2 4 5 7 9', isPublic: false },
        { inputData: '2\n50\n25', expectedOutput: '25 50', isPublic: false },
        { inputData: '5\n10\n10\n5\n5\n0', expectedOutput: '0 5 5 10 10', isPublic: false },
        { inputData: '4\n8\n3\n6\n1', expectedOutput: '1 3 6 8', isPublic: false },
        { inputData: '3\n-1\n-5\n-3', expectedOutput: '-5 -3 -1', isPublic: false },
        { inputData: '6\n100\n90\n80\n70\n60\n50', expectedOutput: '50 60 70 80 90 100', isPublic: false }
      ]
    },
    {
      title: 'Comptage des Voyelles',
      topic: 'Strings',
      difficulty: 'Easy',
      points: 15,
      description: `### Objectif\nCompter le nombre de voyelles (a, e, i, o, u, y) dans une chaîne de caractères.`,
      templateCode: {
        ALGO: `Algorithme CompterVoyelles;\nVar\n    str[100] : Chaine;\n    i, count, len : Entier;\n    c : Caractere;\nDebut\n    Lire(str);\n    count := 0;\n    len := Longueur(str);\n    Pour i := 0 a len - 1 Faire\n        c := str[i];\n        Si (c = 'a') Ou (c = 'e') Ou (c = 'i') Ou (c = 'o') Ou (c = 'u') Ou (c = 'y') Ou (c = 'A') Ou (c = 'E') Ou (c = 'I') Ou (c = 'O') Ou (c = 'U') Ou (c = 'Y') Alors\n            count := count + 1;\n        FinSi;\n    FinPour;\n    Ecrire(count);\nFin.`
      },
      referenceSolution: `Algorithme Solution_Compter_Voyelles;\nVar\n   str[100] : Chaine;\n   i, count, len : Entier;\n   c : Caractere;\nDebut\n   Lire(str);\n   count := 0;\n   len := Longueur(str);\n   Pour i := 0 a len - 1 Faire\n      c := str[i];\n      Si (c = 'a') Ou (c = 'e') Ou (c = 'i') Ou (c = 'o') Ou (c = 'u') Ou (c = 'y') Ou (c = 'A') Ou (c = 'E') Ou (c = 'I') Ou (c = 'O') Ou (c = 'U') Ou (c = 'Y') Alors\n         count := count + 1;\n      FinSi;\n   FinPour;\n   Ecrire(count);\nFin.`,
      testCases: [
        { inputData: 'algorithme', expectedOutput: '4', isPublic: true },
        { inputData: 'Bonjour', expectedOutput: '3', isPublic: true },
        { inputData: 'a', expectedOutput: '1', isPublic: false },
        { inputData: 'xyz', expectedOutput: '1', isPublic: false },
        { inputData: 'aeiouy', expectedOutput: '6', isPublic: false },
        { inputData: 'AEIOUY', expectedOutput: '6', isPublic: false },
        { inputData: 'Python', expectedOutput: '2', isPublic: false },
        { inputData: 'Exam', expectedOutput: '2', isPublic: false },
        { inputData: 'Informatique', expectedOutput: '6', isPublic: false },
        { inputData: 'bcdfghjklmnpqrstvwxz', expectedOutput: '0', isPublic: false },
        { inputData: 'AlgoCompiler', expectedOutput: '5', isPublic: false },
        { inputData: 'Etudiant', expectedOutput: '4', isPublic: false }
      ]
    },
    {
      title: 'Calcul de la Factorielle',
      topic: 'Basics',
      difficulty: 'Easy',
      points: 15,
      description: `### Objectif\nCalculer la factorielle \`N!\` pour un nombre entier \`N >= 0\`.`,
      templateCode: {
        ALGO: `Algorithme Factorielle;\nVar\n    N, i, fact : Entier;\nDebut\n    Lire(N);\n    fact := 1;\n    Pour i := 1 a N Faire\n        fact := fact * i;\n    FinPour;\n    Ecrire(fact);\nFin.`
      },
      referenceSolution: `Algorithme Solution_Factorielle;\nVar\n   N, i, fact : Entier;\nDebut\n   Lire(N);\n   fact := 1;\n   Pour i := 1 a N Faire\n      fact := fact * i;\n   FinPour;\n   Ecrire(fact);\nFin.`,
      testCases: [
        { inputData: '5', expectedOutput: '120', isPublic: true },
        { inputData: '0', expectedOutput: '1', isPublic: true },
        { inputData: '1', expectedOutput: '1', isPublic: false },
        { inputData: '2', expectedOutput: '2', isPublic: false },
        { inputData: '3', expectedOutput: '6', isPublic: false },
        { inputData: '4', expectedOutput: '24', isPublic: false },
        { inputData: '6', expectedOutput: '720', isPublic: false },
        { inputData: '7', expectedOutput: '5040', isPublic: false },
        { inputData: '8', expectedOutput: '40320', isPublic: false },
        { inputData: '9', expectedOutput: '362880', isPublic: false },
        { inputData: '10', expectedOutput: '3628800', isPublic: false },
        { inputData: '11', expectedOutput: '39916800', isPublic: false }
      ]
    },
    {
      title: 'Somme de Deux Matrices 2D',
      topic: 'Arrays',
      difficulty: 'Hard',
      points: 30,
      description: `### Objectif\nCalculer la somme de deux matrices carrées de dimension \`N x N\`.`,
      templateCode: {
        ALGO: `Algorithme SommeMatrices;\nVar\n    N, i, j : Entier;\n    A[50][50] : Entier;\n    B[50][50] : Entier;\n    C[50][50] : Entier;\nDebut\n    Lire(N);\n    Pour i := 1 a N Faire\n        Pour j := 1 a N Faire\n            Lire(A[i][j]);\n        FinPour;\n    FinPour;\n    Pour i := 1 a N Faire\n        Pour j := 1 a N Faire\n            Lire(B[i][j]);\n        FinPour;\n    FinPour;\n    Pour i := 1 a N Faire\n        Pour j := 1 a N Faire\n            C[i][j] := A[i][j] + B[i][j];\n            Ecrire(C[i][j], " ");\n        FinPour;\n    FinPour;\nFin.`
      },
      referenceSolution: `Algorithme Solution_Somme_Matrices;\nVar\n   N, i, j : Entier;\n   A[50][50] : Entier;\n   B[50][50] : Entier;\n   C[50][50] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire\n      Pour j := 1 a N Faire\n         Lire(A[i][j]);\n      FinPour;\n   FinPour;\n   Pour i := 1 a N Faire\n      Pour j := 1 a N Faire\n         Lire(B[i][j]);\n      FinPour;\n   FinPour;\n   Pour i := 1 a N Faire\n      Pour j := 1 a N Faire\n         C[i][j] := A[i][j] + B[i][j];\n         Ecrire(C[i][j], " ");\n      FinPour;\n   FinPour;\nFin.`,
      testCases: [
        { inputData: '2\n1\n2\n3\n4\n5\n6\n7\n8', expectedOutput: '6 8 10 12', isPublic: true },
        { inputData: '1\n5\n10', expectedOutput: '15', isPublic: true },
        { inputData: '2\n0\n0\n0\n0\n0\n0\n0\n0', expectedOutput: '0 0 0 0', isPublic: false },
        { inputData: '2\n1\n0\n0\n1\n1\n0\n0\n1', expectedOutput: '2 0 0 2', isPublic: false },
        { inputData: '2\n-1\n-2\n-3\n-4\n1\n2\n3\n4', expectedOutput: '0 0 0 0', isPublic: false },
        { inputData: '2\n10\n20\n30\n40\n5\n5\n5\n5', expectedOutput: '15 25 35 45', isPublic: false },
        { inputData: '3\n1\n2\n3\n4\n5\n6\n7\n8\n9\n9\n8\n7\n6\n5\n4\n3\n2\n1', expectedOutput: '10 10 10 10 10 10 10 10 10', isPublic: false },
        { inputData: '2\n100\n200\n300\n400\n100\n200\n300\n400', expectedOutput: '200 400 600 800', isPublic: false },
        { inputData: '2\n-5\n5\n-10\n10\n-5\n5\n-10\n10', expectedOutput: '-10 10 -20 20', isPublic: false },
        { inputData: '1\n999\n1', expectedOutput: '1000', isPublic: false },
        { inputData: '3\n1\n0\n0\n0\n1\n0\n0\n0\n1\n2\n0\n0\n0\n2\n0\n0\n0\n2', expectedOutput: '3 0 0 0 3 0 0 0 3', isPublic: false },
        { inputData: '2\n7\n3\n2\n9\n1\n4\n8\n2', expectedOutput: '8 7 10 11', isPublic: false }
      ]
    }
  ];

  // Deduplicate existing problems with identical titles
  for (const prob of problemsData) {
    const matches = await prisma.problem.findMany({
      where: { title: prob.title },
      orderBy: { createdAt: 'asc' }
    });

    if (matches.length > 1) {
      console.log(`Found ${matches.length} duplicates for "${prob.title}". Cleaning up...`);
      const [primary, ...duplicates] = matches;
      for (const dup of duplicates) {
        await prisma.testCase.deleteMany({ where: { problemId: dup.id } });
        await prisma.submission.deleteMany({ where: { problemId: dup.id } });
        await prisma.examProblem.deleteMany({ where: { problemId: dup.id } });
        await prisma.problem.delete({ where: { id: dup.id } });
      }
    }
  }

  for (const prob of problemsData) {
    const existing = await prisma.problem.findFirst({
      where: { title: prob.title }
    });

    if (existing) {
      await prisma.problem.update({
        where: { id: existing.id },
        data: {
          topic: prob.topic,
          difficulty: prob.difficulty,
          points: prob.points,
          description: prob.description,
          templateCode: prob.templateCode,
          referenceSolution: prob.referenceSolution
        }
      });

      // Update test cases for existing problem
      await prisma.testCase.deleteMany({ where: { problemId: existing.id } });
      if (prob.testCases) {
        await prisma.testCase.createMany({
          data: prob.testCases.map(tc => ({ ...tc, problemId: existing.id }))
        });
      }
      console.log(`Updated problem: "${prob.title}" (${prob.testCases.length} test cases)`);
    } else {
      await prisma.problem.create({
        data: {
          title: prob.title,
          topic: prob.topic,
          difficulty: prob.difficulty,
          points: prob.points,
          description: prob.description,
          templateCode: prob.templateCode,
          referenceSolution: prob.referenceSolution,
          testCases: {
            create: prob.testCases
          }
        }
      });
      console.log(`Created problem: "${prob.title}" (${prob.testCases.length} test cases)`);
    }
  }

  console.log('Seeding of 10 AlgoCompiler problems finished!');
}

if (require.main === module) {
  seed10AlgoCompilerProblems()
    .catch(console.error)
    .finally(() => prisma.$disconnect());
}

module.exports = { seed10AlgoCompilerProblems };
