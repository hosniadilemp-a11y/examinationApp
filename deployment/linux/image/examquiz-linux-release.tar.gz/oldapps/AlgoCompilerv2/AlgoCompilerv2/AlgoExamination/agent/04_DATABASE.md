# AlgoExamination — Database and Prisma Rules

## ORM

Prisma ORM.

Database:
- PostgreSQL
- database name: `algoexam_db`
- Prisma schema: `exam`

## Important Models

### Exam

Contains:
- identity
- academic metadata
- schedule
- lifecycle status
- teacher ownership
- anti-cheat configuration

### ExamAssignment

Connects:
- one exam
- one student
- access number
- exam status
- timestamps
- autosaved code
- violations
- score
- grading state
- feedback

### ExamProblem

Connects:
- exam
- problem
- order
- points override

## Data Integrity Rules

### Assignment identity

`ExamAssignment.id` is the assignment identity.

Do not confuse:
- assignment ID
- exam ID
- student ID
- access number

### Score

`finalScore` is scaled out of 20.

Do not change the scoring scale without updating:
- UI
- grading
- PDF
- CSV
- QR signature

### currentCodeMap

`currentCodeMap` is JSON containing code organized by problem.

Never assume problem order equals problem ID.

Use problem IDs as keys.

### timestamps

Maintain semantic differences:
- `loginTime`: login
- `startedAt`: actual exam start
- `finishedAt`: completion/end
- `lastSeenAt`: connectivity presence

Do not overwrite one timestamp to represent another event.

## Schema Changes

Before modifying Prisma:
1. Search all usages of the field/model.
2. Check controllers.
3. Check frontend payloads.
4. Check socket payloads.
5. Check exports.
6. Run Prisma validation.
7. Consider migration/data compatibility.

## Enum Changes

Treat enum changes as breaking changes.

Never rename/remove a status casually.

## Prisma Verification

Run:

```bash
cd server
PATH=/home/adel/.local/node-v20/bin:$PATH npx prisma validate
```

If schema changes are made, inspect the generated migration/data implications before considering the task complete.
