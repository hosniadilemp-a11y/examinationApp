import { io } from 'socket.io-client';

let socket = null;

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:4000';

export function getSocket() {
  if (!socket) {
    socket = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      autoConnect: true,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000
    });

    socket.on('connect', () => {
      console.log('Socket connected:', socket.id);
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
    });
  }
  return socket;
}

export function joinExamRoom(examId, studentId = null, isTeacher = false) {
  const s = getSocket();
  s.emit('join_exam_room', { examId, studentId, isTeacher });
}

export function sendStudentViolation(examId, studentId, eventType, severity = 'MEDIUM', problemId = null, metadata = {}) {
  const s = getSocket();
  s.emit('student_violation', { examId, studentId, eventType, severity, problemId, metadata });
}

export function sendStudentSwitchProblem(examId, studentId, problemId) {
  const s = getSocket();
  s.emit('student_switch_problem', { examId, studentId, problemId });
}

export function leaveExamRoom(examId) {
  const s = getSocket();
  s.emit('leave_exam_room', { examId });
}
