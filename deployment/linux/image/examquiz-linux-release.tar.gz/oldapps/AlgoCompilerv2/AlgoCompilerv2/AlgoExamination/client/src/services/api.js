const API_BASE = '/api';

export async function request(endpoint, options = {}) {
  const token = localStorage.getItem('token');

  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    if (response.status === 401 && !endpoint.includes('/auth/')) {
      localStorage.removeItem('token');
      localStorage.removeItem('userRole');
      window.dispatchEvent(new Event('auth_unauthorized'));
    }
    const error = new Error(data.error || `HTTP error ${response.status}`);
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}

// --- Auth Endpoints ---
export const studentLogin = (accessNumber) => request('/auth/student/login', { method: 'POST', body: JSON.stringify({ accessNumber }) });
export const teacherLogin = (email, password) => request('/auth/teacher/login', { method: 'POST', body: JSON.stringify({ email, password }) });

// --- Student Exam Endpoints ---
export const getStudentWorkspace = () => request('/student/workspace');
export const autosaveCode = (problemId, code, language, fullCodeMap) => request('/student/autosave', { method: 'POST', body: JSON.stringify({ problemId, code, language, fullCodeMap }) });
export const runSampleCode = (sourceCode, language, inputData) => {
  const isTeacher = localStorage.getItem('userRole') === 'TEACHER';
  const endpoint = isTeacher ? '/teacher/run' : '/student/run';
  return request(endpoint, { method: 'POST', body: JSON.stringify({ sourceCode, language, inputData }) });
};
export const submitSolution = (problemId, language, sourceCode) => request('/student/submit', { method: 'POST', body: JSON.stringify({ problemId, language, sourceCode }) });
export const logMonitoringEvent = (eventType, severity, problemId, metadata) => request('/student/violation', { method: 'POST', body: JSON.stringify({ eventType, severity, problemId, metadata }) });
export const finalizeExam = () => request('/student/finalize', { method: 'POST' });
export const validateCodeSyntax = (sourceCode) => request('/validate', { method: 'POST', body: JSON.stringify({ sourceCode }) });

// --- Teacher Exam Endpoints ---
export const listExams = () => request('/exams');
export const createExam = (payload) => request('/exams', { method: 'POST', body: JSON.stringify(payload) });
export const getExamDetails = (id) => request(`/exams/${id}`);
export const updateExamStatus = (id, status) => request(`/exams/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
export const updateExam = (id, payload) => request(`/exams/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
export const deleteExam = (id) => request(`/exams/${id}`, { method: 'DELETE' });
export const teacherEmergencyControl = (id, payload) => request(`/exams/${id}/emergency`, { method: 'POST', body: JSON.stringify(payload) });
export const getExamAccessSheet = (examId) => request(`/exams/${examId}/access-cards`);
export const getExamResults = (examId) => request(`/exams/${examId}/results`);
export const getExamGradingData = (examId) => request(`/exams/${examId}/grading`);
export const calculateExerciseGrade = (examId, payload) => request(`/exams/${examId}/calculate-exercise`, { method: 'POST', body: JSON.stringify(payload) });
export const recalculateAllExamGrades = (examId) => request(`/exams/${examId}/recalculate-all`, { method: 'POST' });
export const saveProblemGrade = (examId, payload) => request(`/exams/${examId}/grade-submission`, { method: 'POST', body: JSON.stringify(payload) });
export const updateGeneralFeedback = (examId, payload) => request(`/exams/${examId}/general-feedback`, { method: 'POST', body: JSON.stringify(payload) });
export const analyzeSubmissionSyntax = (examId, code) => request(`/exams/${examId}/analyze-syntax`, { method: 'POST', body: JSON.stringify({ code }) });
export const runTeacherSandboxCode = (examId, sourceCode, language, inputData) => request(`/exams/${examId}/run-sandbox`, { method: 'POST', body: JSON.stringify({ sourceCode, language, inputData }) });
export const autoGradeExam = (examId) => request(`/exams/${examId}/auto-grade`, { method: 'POST' });
export const resetExamScores = (examId) => request(`/exams/${examId}/reset-scores`, { method: 'POST' });
export const finalizeExamCorrection = (examId) => request(`/exams/${examId}/finalize-correction`, { method: 'POST' });
export const exportExamBundle = (examId, passphrase) => request(`/exams/${examId}/export-bundle`, { method: 'POST', body: JSON.stringify({ passphrase }) });
export const importExamBundles = async (examId, formData) => {
  const token = localStorage.getItem('token');
  const endpoint = examId ? `/api/exams/${examId}/import-bundles` : `/api/exams/import-bundles`;
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'Erreur lors de l’importation des paquets');
    error.data = data;
    error.status = response.status;
    throw error;
  }
  return data;
};
export const exportExamResults = (examId, passphrase) => request(`/exams/${examId}/export-results`, { method: 'POST', body: JSON.stringify({ passphrase }) });
export const importExamResults = async (examId, formData) => {
  const token = localStorage.getItem('token');
  const endpoint = examId ? `/api/exams/${examId}/import-results` : `/api/exams/import-results`;
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'Erreur lors de l’importation des résultats');
    error.data = data;
    error.status = response.status;
    throw error;
  }
  return data;
};

// --- Exam Template (.algoexam) & Room Launch Endpoints ---
export const exportExamTemplate = (examId) => request(`/exams/${examId}/export-template`);
export const cloneExamAsTemplate = (examId) => request(`/exams/${examId}/clone-template`, { method: 'POST' });
export const importExamTemplate = async (formData) => {
  const token = localStorage.getItem('token');
  const response = await fetch(`/api/exams/import-template`, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'Erreur lors de l’importation du modèle d’examen');
    error.data = data;
    error.status = response.status;
    throw error;
  }
  return data;
};
export const launchExamWithRoom = async (examId, formData) => {
  const token = localStorage.getItem('token');
  const response = await fetch(`/api/exams/${examId}/launch-room`, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'Erreur lors du lancement de l’examen pour la salle');
    error.data = data;
    error.status = response.status;
    throw error;
  }
  return data;
};
export const downloadStudentPDFBlob = async (examId, studentId) => {
  const token = localStorage.getItem('token');
  const response = await fetch(`/api/exams/${examId}/students/${studentId}/pdf`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
  if (!response.ok) throw new Error('Erreur lors du téléchargement du PDF');
  return await response.blob();
};
export const downloadAllStudentPDFBlob = async (examId) => {
  const token = localStorage.getItem('token');
  const response = await fetch(`/api/exams/${examId}/all-pdf`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
  if (!response.ok) throw new Error('Erreur lors du téléchargement de l’ensemble des PDF');
  return await response.blob();
};
export const verifyQRCodePayload = (qrPayload) => request('/grading/verify-qr', { method: 'POST', body: JSON.stringify({ qrPayload }) });
export const evaluateAIModule = (problemId, studentCode, weights, selectedModel) => request('/prototype/evaluate', { method: 'POST', body: JSON.stringify({ problemId, studentCode, weights, selectedModel }) });

// --- Problem Bank Endpoints ---
export const listProblems = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return request(`/problems${query ? `?${query}` : ''}`);
};
export const createProblem = (payload) => request('/problems', { method: 'POST', body: JSON.stringify(payload) });
export const updateProblem = (id, payload) => request(`/problems/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
export const deleteProblem = (id) => request(`/problems/${id}`, { method: 'DELETE' });

// --- Student Management Endpoints ---
export const listStudents = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return request(`/students${query ? `?${query}` : ''}`);
};
export const createStudent = (payload) => request('/students', { method: 'POST', body: JSON.stringify(payload) });
export const importStudentsCSV = (csvText) => request('/students/import-csv', { method: 'POST', body: JSON.stringify({ csvText }) });
