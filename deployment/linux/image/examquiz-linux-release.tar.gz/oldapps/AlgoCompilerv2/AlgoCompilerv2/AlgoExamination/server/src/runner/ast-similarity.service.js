// ── Server-Side AST Parser & Structural Semantic Similarity Engine ──

function parsePseudoCodeAST(code) {
  if (!code || typeof code !== 'string') return { type: 'Program', name: 'Empty', variables: [], body: [] };

  const lines = code.split('\n');
  let programName = 'Algorithme';
  const variables = [];
  const rootBody = [];
  const stack = [{ nodeType: 'Program', body: rootBody, variables: variables }];

  let inVarSection = false;

  lines.forEach((lineText, idx) => {
    const lineNum = idx + 1;
    const clean = lineText.replace(/\/\/.*$/, '').replace(/\/\*[\s\S]*?\*\//, '').trim();
    if (!clean) return;

    // 1. Program Header
    const algoHead = clean.match(/^ALGORITHME\s+([a-zA-Z0-9_]+)/i);
    if (algoHead) {
      programName = algoHead[1];
      return;
    }

    // 2. Variables Section Keyword
    if (/^(VARIABLES|VAR)\b/i.test(clean)) {
      inVarSection = true;
      return;
    }

    // 3. Function Declaration: Fonction Nom(p: Type) : RetType;
    const funcMatch = clean.match(/^(?:FONCTION|FUNCTION)\s+([a-zA-Z0-9_]+)\s*(?:\((.*?)\))?\s*(?::\s*([a-zA-Z0-9_\[\]\.]+))?;?/i);
    if (funcMatch) {
      inVarSection = false;
      const rawParams = funcMatch[2] ? funcMatch[2].split(',').map(p => {
        const parts = p.split(':');
        return { name: parts[0]?.trim(), type: parts[1]?.trim() || 'Inconnu' };
      }) : [];
      const funcNode = {
        type: 'FunctionDeclaration',
        name: funcMatch[1],
        params: rawParams,
        returnType: funcMatch[3] ? funcMatch[3].trim() : 'Entier',
        variables: [],
        body: [],
        line: lineNum
      };
      const currentParent = stack[stack.length - 1];
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(funcNode);
      stack.push({ nodeType: 'FunctionDeclaration', body: funcNode.body, variables: funcNode.variables });
      return;
    }

    // 4. Procedure Declaration: Procedure Nom(p: Type);
    const procMatch = clean.match(/^(?:PROCEDURE)\s+([a-zA-Z0-9_]+)\s*(?:\((.*?)\))?;?/i);
    if (procMatch) {
      inVarSection = false;
      const rawParams = procMatch[2] ? procMatch[2].split(',').map(p => {
        const parts = p.split(':');
        return { name: parts[0]?.trim(), type: parts[1]?.trim() || 'Inconnu' };
      }) : [];
      const procNode = {
        type: 'ProcedureDeclaration',
        name: procMatch[1],
        params: rawParams,
        variables: [],
        body: [],
        line: lineNum
      };
      const currentParent = stack[stack.length - 1];
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(procNode);
      stack.push({ nodeType: 'ProcedureDeclaration', body: procNode.body, variables: procNode.variables });
      return;
    }

    // 5. DEBUT
    if (/^DEBUT\b/i.test(clean)) {
      inVarSection = false;
      return;
    }

    // 6. Variable Declarations
    if (inVarSection) {
      const varDecl = clean.match(/^([a-zA-Z0-9_,\s]+)\s*:\s*([a-zA-Z0-9_\[\]\.]+);?/i);
      if (varDecl) {
        const names = varDecl[1].split(',').map(n => n.trim()).filter(Boolean);
        const typeStr = varDecl[2].trim();
        const currentParent = stack[stack.length - 1];
        const targetVars = currentParent.variables || variables;
        names.forEach(n => targetVars.push({ name: n, type: typeStr }));
      }
      return;
    }

    const currentParent = stack[stack.length - 1];

    // 7. Closures: FINSI, FINPOUR, FINTANTQUE, FIN;
    if (/^FIN\s*SI\b|^FINSI\b/i.test(clean)) {
      if (stack.length > 1 && stack[stack.length - 1].nodeType === 'IfStatement') stack.pop();
      return;
    }
    if (/^FIN\s*POUR\b|^FINPOUR\b/i.test(clean)) {
      if (stack.length > 1 && stack[stack.length - 1].nodeType === 'ForLoopStatement') stack.pop();
      return;
    }
    if (/^FIN\s*TANTQUE\b|^FINTANTQUE\b/i.test(clean)) {
      if (stack.length > 1 && stack[stack.length - 1].nodeType === 'WhileLoopStatement') stack.pop();
      return;
    }
    if (/^FIN\b|^FIN;/i.test(clean)) {
      if (stack.length > 1) {
        stack.pop();
      }
      return;
    }

    // 8. SINON
    if (/^SINON\b/i.test(clean)) {
      if (currentParent.nodeType === 'IfStatement') currentParent.inAlternate = true;
      return;
    }

    // 9. Return Statement: Retourner / Renvoyer / Return
    const retMatch = clean.match(/^(?:RETOURNER|RENVOYER|RETURN)\s+(.*?);?$/i);
    if (retMatch) {
      const retNode = {
        type: 'ReturnStatement',
        argument: retMatch[1].trim(),
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(retNode);
      return;
    }

    // 10. If Statement
    const ifMatch = clean.match(/^SI\s+(.*?)\s+ALORS/i);
    if (ifMatch) {
      const ifNode = {
        type: 'IfStatement',
        nodeType: 'IfStatement',
        condition: ifMatch[1].trim(),
        consequent: [],
        alternate: [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(ifNode);
      stack.push({ nodeType: 'IfStatement', consequent: ifNode.consequent, alternate: ifNode.alternate, inAlternate: false });
      return;
    }

    // 11. For Loop
    const forMatch = clean.match(/^POUR\s+([a-zA-Z0-9_]+)\s*(?::=|=|<-)\s*(.*?)\s+A\s+(.*?)\s+FAIRE/i);
    if (forMatch) {
      const forNode = {
        type: 'ForLoopStatement',
        nodeType: 'ForLoopStatement',
        iterator: forMatch[1].trim(),
        start: forMatch[2].trim(),
        end: forMatch[3].trim(),
        body: [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(forNode);
      stack.push({ nodeType: 'ForLoopStatement', body: forNode.body });
      return;
    }

    // 12. While Loop
    const whileMatch = clean.match(/^TANTQUE\s+\(?(.*?)\)?\s+FAIRE/i);
    if (whileMatch) {
      const whileNode = {
        type: 'WhileLoopStatement',
        nodeType: 'WhileLoopStatement',
        condition: whileMatch[1].trim(),
        body: [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(whileNode);
      stack.push({ nodeType: 'WhileLoopStatement', body: whileNode.body });
      return;
    }

    // 13. Call Expression: Ecrire, Lire, or any function/procedure call
    const callMatch = clean.match(/^([a-zA-Z0-9_]+)\s*\((.*?)\);?$/i);
    if (callMatch && !/^(SI|POUR|TANTQUE|VAR|VARIABLES|DEBUT|FIN|ALGORITHME|FONCTION|PROCEDURE|RETOURNER)$/i.test(callMatch[1])) {
      const callNode = {
        type: 'CallExpression',
        callee: callMatch[1],
        args: callMatch[2] ? callMatch[2].split(',').map(a => a.trim()).filter(Boolean) : [],
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(callNode);
      return;
    }

    // 14. Assignment Statement
    const assignMatch = clean.match(/^([a-zA-Z0-9_\[\]\.]+)\s*(?::=|=|<-)\s*(.*?);?$/);
    if (assignMatch) {
      const assignNode = {
        type: 'AssignmentStatement',
        target: assignMatch[1].trim(),
        expression: assignMatch[2].trim(),
        line: lineNum
      };
      const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
      if (targetArray) targetArray.push(assignNode);
      return;
    }

    // 15. Generic Expression
    const genericNode = {
      type: 'ExpressionStatement',
      code: clean,
      line: lineNum
    };
    const targetArray = currentParent.inAlternate ? currentParent.alternate : (currentParent.body || currentParent.consequent);
    if (targetArray) targetArray.push(genericNode);
  });

  return {
    type: 'Program',
    name: programName,
    variables,
    body: rootBody
  };
}

/**
 * Helper to determine if two AST nodes represent the same boilerplate structure.
 */
function isSameASTNode(n1, n2) {
  if (!n1 || !n2 || n1.type !== n2.type) return false;
  if (n1.type === 'CallExpression') {
    return (n1.callee || '').toLowerCase() === (n2.callee || '').toLowerCase() &&
           JSON.stringify(n1.args) === JSON.stringify(n2.args);
  }
  if (n1.type === 'AssignmentStatement') {
    return n1.target === n2.target && n1.expression === n2.expression;
  }
  if (n1.type === 'IfStatement') {
    return n1.condition === n2.condition;
  }
  if (n1.type === 'ForLoopStatement') {
    return n1.iterator === n2.iterator && n1.start === n2.start && n1.end === n2.end;
  }
  if (n1.type === 'WhileLoopStatement') {
    return n1.condition === n2.condition;
  }
  return false;
}

/**
 * Extracts AST Delta (removes boilerplate nodes present in starter template).
 * Also performs Template Hole-Filling credit by inspecting inner bodies of container nodes.
 */
function extractASTDelta(astBody = [], templateBody = []) {
  if (!templateBody || !templateBody.length) return astBody;

  const delta = [];
  astBody.forEach(node => {
    // Check if node exists directly in template
    const isBoilerplate = templateBody.some(tplNode => isSameASTNode(node, tplNode));
    
    if (!isBoilerplate) {
      // Node is unique student logic!
      const cloned = { ...node };
      if (cloned.consequent || cloned.alternate) {
        cloned.consequent = extractASTDelta(cloned.consequent, templateBody);
        cloned.alternate = extractASTDelta(cloned.alternate, templateBody);
      } else if (cloned.body) {
        cloned.body = extractASTDelta(cloned.body, templateBody);
      }
      delta.push(cloned);
    } else if (node.type === 'IfStatement' || node.type === 'ForLoopStatement' || node.type === 'WhileLoopStatement') {
      // Boilerplate container: check if student filled inner code inside this container (Hole-filling credit)
      const innerBody = node.body || node.consequent || [];
      const innerDelta = extractASTDelta(innerBody, templateBody);
      if (innerDelta.length > 0) {
        const containerClone = { ...node };
        if (containerClone.body) containerClone.body = innerDelta;
        if (containerClone.consequent) containerClone.consequent = innerDelta;
        delta.push(containerClone);
      }
    }
  });

  return delta;
}

/**
 * Calculates AST similarity taking into consideration the starter template boilerplate.
/**
 * Helper to check if student code is empty or identical to the starter template.
 */
function isUntouchedTemplateCode(studentCode, starterTemplate) {
  if (!studentCode || typeof studentCode !== 'string') return true;

  const sanitize = (str) => {
    if (!str || typeof str !== 'string') return '';
    return str
      .replace(/\/\/.*$/gm, '')
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/;/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const cleanCode = sanitize(studentCode);
  if (!cleanCode) return true;

  if (starterTemplate) {
    let tplStr = '';
    if (typeof starterTemplate === 'string') {
      const trimmed = starterTemplate.trim();
      if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
        try {
          const parsed = JSON.parse(trimmed);
          if (parsed && typeof parsed === 'object') {
            tplStr = parsed.ALGO || parsed.code || parsed.PYTHON || '';
          }
        } catch (e) {
          tplStr = starterTemplate;
        }
      } else {
        tplStr = starterTemplate;
      }
    } else if (typeof starterTemplate === 'object' && starterTemplate !== null) {
      tplStr = starterTemplate.ALGO || starterTemplate.code || starterTemplate.PYTHON || '';
    }

    if (typeof tplStr === 'string' && tplStr.trim()) {
      const cleanTpl = sanitize(tplStr);
      const hasPlaceholderMarkers = /(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo|code\s+mod[èe]le)/i.test(tplStr);
      if (hasPlaceholderMarkers && cleanCode.toLowerCase() === cleanTpl.toLowerCase()) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Main function to compare student code against a reference solution, taking into account starter template boilerplate.
 * @param {string} studentCode 
 * @param {string} referenceSolution 
 * @param {string|object} starterTemplate 
 * @returns {number} 0-100 similarity score
 */
function calculateCodeSimilarity(studentCode, referenceSolution, starterTemplate = '') {
  if (!studentCode || !referenceSolution) return 0;

  // 1. Untouched Template Detection:
  if (isUntouchedTemplateCode(studentCode, starterTemplate)) {
    return 0;
  }

  const sanitize = (str) => {
    if (!str || typeof str !== 'string') return '';
    return str
      .replace(/\/\/.*$/gm, '')
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/;/g, '')
      .trim();
  };

  let tplStr = starterTemplate;
  if (typeof starterTemplate === 'object' && starterTemplate !== null) {
    tplStr = starterTemplate.ALGO || starterTemplate.code || '';
  }

  const code1 = sanitize(studentCode);
  const code2 = sanitize(referenceSolution);
  const codeTpl = sanitize(tplStr);

  if (!code1 || !code2) return 0;

  const ast1 = parsePseudoCodeAST(code1);
  const ast2 = parsePseudoCodeAST(code2);
  const hasPlaceholderMarkers = /(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo|code\s+mod[èe]le)/i.test(tplStr || '');
  const astTpl = (codeTpl && hasPlaceholderMarkers) ? parsePseudoCodeAST(codeTpl) : null;

  // 2. AST Delta Extraction: Strip boilerplate nodes present in starter template
  const delta1 = astTpl ? extractASTDelta(ast1 && ast1.body, astTpl && astTpl.body) : (ast1 && ast1.body || []);
  const delta2 = astTpl ? extractASTDelta(ast2 && ast2.body, astTpl && astTpl.body) : (ast2 && ast2.body || []);

  // Untouched Template Check at AST level: If student added 0 unique AST nodes, return 0!
  if (astTpl && (!delta1 || delta1.length === 0)) {
    return 0;
  }

  const compareASTBodies = (body1 = [], body2 = []) => {
    if (!body1.length && !body2.length) return 1;
    if (!body1.length || !body2.length) return 0;

    let totalMatches = 0;
    const maxLen = Math.max(body1.length, body2.length);
    const varMap = new Map();
    let varCounter = 1;

    const canonicalExpr = (expr) => {
      if (!expr) return '';
      return expr
        .replace(/[0-9]+/g, ' NUM ')
        .replace(/([^a-z0-9_\u00C0-\u00FF])/gi, ' $1 ')
        .split(/\s+/)
        .filter(Boolean)
        .map(tok => {
          const lower = tok.toLowerCase();
          if (['+', '-', '*', '/', '(', ')', 'num'].includes(lower)) return lower;
          if (!varMap.has(lower)) varMap.set(lower, `VAR_${varCounter++}`);
          return varMap.get(lower);
        })
        .join(' ');
    };

    for (let i = 0; i < maxLen; i++) {
      const n1 = body1[i];
      const n2 = body2[i];

      if (!n1 || !n2) continue;

      if (n1.type !== n2.type) {
        totalMatches += 0.1;
        continue;
      }

      if (n1.type === 'CallExpression') {
        const sameCallee = (n1.callee || '').toLowerCase() === (n2.callee || '').toLowerCase();
        const sameArgCount = (n1.args || []).length === (n2.args || []).length;
        if (sameCallee && sameArgCount) totalMatches += 1.0;
        else if (sameCallee) totalMatches += 0.7;
        else totalMatches += 0.2;
      } else if (n1.type === 'AssignmentStatement') {
        const expr1 = canonicalExpr(n1.expression);
        const expr2 = canonicalExpr(n2.expression);

        if (expr1 === expr2) {
          totalMatches += 1.0;
        } else {
          const set1 = new Set(expr1.split(' '));
          const set2 = new Set(expr2.split(' '));
          let intersect = 0;
          set1.forEach(t => { if (set2.has(t)) intersect++; });
          const union = new Set([...set1, ...set2]).size;
          const overlap = union > 0 ? (intersect / union) : 0;
          totalMatches += 0.3 + 0.6 * overlap;
        }
      } else if (n1.type === 'FunctionDeclaration' || n1.type === 'ProcedureDeclaration') {
        const sameParamCount = (n1.params || []).length === (n2.params || []).length;
        const sameName = (n1.name || '').toLowerCase() === (n2.name || '').toLowerCase();
        const subBody = compareASTBodies(n1.body, n2.body);
        const headerScore = (sameName ? 0.2 : 0.1) + (sameParamCount ? 0.2 : 0.05);
        totalMatches += headerScore + 0.6 * subBody;
      } else if (n1.type === 'ReturnStatement') {
        const expr1 = canonicalExpr(n1.argument);
        const expr2 = canonicalExpr(n2.argument);
        if (expr1 === expr2) {
          totalMatches += 1.0;
        } else {
          const set1 = new Set(expr1.split(' '));
          const set2 = new Set(expr2.split(' '));
          let intersect = 0;
          set1.forEach(t => { if (set2.has(t)) intersect++; });
          const union = new Set([...set1, ...set2]).size;
          const overlap = union > 0 ? (intersect / union) : 0;
          totalMatches += 0.4 + 0.6 * overlap;
        }
      } else if (n1.type === 'IfStatement') {
        const subConsequent = compareASTBodies(n1.consequent, n2.consequent);
        const subAlternate = compareASTBodies(n1.alternate, n2.alternate);
        totalMatches += 0.5 * subConsequent + 0.5 * subAlternate;
      } else if (n1.type === 'ForLoopStatement' || n1.type === 'WhileLoopStatement') {
        const subBody = compareASTBodies(n1.body, n2.body);
        totalMatches += subBody;
      } else {
        totalMatches += 0.8;
      }
    }

    return totalMatches / maxLen;
  };

  // Compare Student Delta AST against Reference Delta AST (or Reference AST if delta2 is empty)
  const targetReferenceBody = (delta2 && delta2.length > 0) ? delta2 : (ast2 && ast2.body);
  const astSimilarity = compareASTBodies(delta1, targetReferenceBody);

  const canonicalizeTokens = (str) => {
    const keywords = new Set([
      'algorithme', 'variables', 'var', 'debut', 'fin', 'entier', 'reel', 'chaine',
      'booleen', 'tableau', 'de', 'lire', 'ecrire', 'si', 'alors', 'sinon',
      'finsi', 'pour', 'a', 'faire', 'finpour', 'tantque', 'fintantque', 'retourner'
    ]);

    const vMap = new Map();
    let counter = 1;

    return str.toLowerCase()
      .replace(/[0-9]+/g, ' NUM ')
      .replace(/([^a-z0-9_\u00C0-\u00FF])/gi, ' $1 ')
      .split(/\s+/)
      .filter(Boolean)
      .map(tok => {
        if (keywords.has(tok) || /^[^a-z0-9_]$/i.test(tok) || tok === 'NUM') return tok;
        if (!vMap.has(tok)) vMap.set(tok, `VAR_${counter++}`);
        return vMap.get(tok);
      });
  };

  const normTokens1 = canonicalizeTokens(code1);
  const normTokens2 = canonicalizeTokens(code2);

  const getNGrams = (tokens, n = 3) => {
    const grams = new Set();
    for (let i = 0; i <= tokens.length - n; i++) grams.add(tokens.slice(i, i + n).join(' '));
    return grams;
  };

  const grams1 = getNGrams(normTokens1, 3);
  const grams2 = getNGrams(normTokens2, 3);
  let gramIntersect = 0;
  grams1.forEach(g => { if (grams2.has(g)) gramIntersect++; });
  const gramUnion = new Set([...grams1, ...grams2]).size;
  const nGramSim = gramUnion > 0 ? (gramIntersect / gramUnion) : 0;

  const finalScore = Math.round((0.60 * astSimilarity + 0.25 * nGramSim + 0.15 * Math.min(1, normTokens1.length / Math.max(1, normTokens2.length))) * 100);

  return Math.min(100, Math.max(0, finalScore));
}

/**
 * Rounds score up to the nearest quarter-point (0.25 ceiling).
 * e.g. 1.1 -> 1.25, 1.2 -> 1.25, 2.2 -> 2.25, 4.8 -> 5.0, 0.0 -> 0.0
 */
function roundToNextQuarterPoint(val, maxVal) {
  if (val === null || val === undefined || isNaN(parseFloat(val)) || parseFloat(val) <= 0) return 0;
  const num = parseFloat(val);
  const rounded = Math.round((Math.ceil(num * 4) / 4) * 100) / 100;
  const cleanMax = maxVal !== undefined ? Math.round(parseFloat(maxVal) * 100) / 100 : undefined;
  return cleanMax !== undefined ? Math.min(cleanMax, rounded) : rounded;
}

const roundToNextHalfPoint = roundToNextQuarterPoint;

/**
 * Deterministic Hybrid Grading Weighting Formula:
 * - If no test cases exist (hasTests === false): 100% score for AST structural similarity S2.
 * - If 100% tests pass (passedTests === totalTests && totalTests > 0): 80% Tests (S1) + 20% AST (S2).
 * - Otherwise (not all tests pass): 20% Tests (S1) + 80% AST (S2).
 */
function compute3ModuleScore(maxPts, S1, S2, S3 = 0, isAIAvailable = false, hasTests = true, passedTests = 0, totalTests = 0) {
  if (!hasTests || totalTests === 0) {
    // If no test cases exist for this problem, grade purely on AST structural similarity S2 (100%)
    const scoreFrac = Math.max(0, Math.min(1, S2));
    return roundToNextHalfPoint(scoreFrac * maxPts, maxPts);
  }

  const safeS1 = Math.max(0, Math.min(1, S1 || 0));
  const safeS2 = Math.max(0, Math.min(1, S2 || 0));

  const allTestsPassed = totalTests > 0 && passedTests > 0 && passedTests === totalTests;
  const wTest = allTestsPassed ? 0.80 : 0.20;
  const wAST = allTestsPassed ? 0.20 : 0.80;

  const scoreFrac = (safeS1 * wTest) + (safeS2 * wAST);
  return roundToNextHalfPoint(scoreFrac * maxPts, maxPts);
}

/**
 * Single Canonical Scoring Algorithm for student exercise submission.
 */
function computeCanonicalExerciseScore(studentCode, starterTemplate, referenceSolution, passedTests = 0, totalTests = 0, maxPts = 10) {
  if (isUntouchedTemplateCode(studentCode, starterTemplate)) {
    return {
      isUntouched: true,
      astSimilarityRatio: 0,
      hasTests: totalTests > 0,
      totalTests: totalTests || 0,
      passedTests: 0,
      m1Score: 0,
      m2Score: 0,
      m3Score: 0,
      calculatedScore: 0
    };
  }

  const astSimRatio = calculateCodeSimilarity(studentCode, referenceSolution || '', starterTemplate);
  const hasTests = totalTests > 0;
  const S1 = hasTests ? (passedTests / totalTests) : 0;
  const S2 = astSimRatio / 100;

  const allTestsPassed = hasTests && totalTests > 0 && passedTests > 0 && passedTests === totalTests;
  const wTest = !hasTests ? 0 : (allTestsPassed ? 0.80 : 0.20);
  const wAST = !hasTests ? 1.0 : (allTestsPassed ? 0.20 : 0.80);

  const m1Score = !hasTests ? 0 : roundToNextHalfPoint(S1 * maxPts * wTest, maxPts * wTest);
  const m2Score = roundToNextHalfPoint(S2 * maxPts * wAST, maxPts * wAST);
  const calculatedScore = compute3ModuleScore(maxPts, S1, S2, 0, false, hasTests, passedTests, totalTests);

  return {
    isUntouched: false,
    astSimilarityRatio: astSimRatio,
    hasTests,
    totalTests,
    passedTests,
    wTest,
    wAST,
    m1Score,
    m2Score,
    m3Score: 0,
    calculatedScore
  };
}

/**
 * Slices code by question markers:
 * // question N starts here
 * ... code ...
 * // question N ends here
 * Returns an object mapping questionIndex -> slicedCodeString.
 * If no markers exist, returns { 1: code }.
 */
function sliceCodeByQuestionMarkers(codeStr) {
  if (!codeStr || typeof codeStr !== 'string') return {};

  const startRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:starts|commence|d[ée]bute?)\s*(?:here|ici)?|(?:d[ée]but)\s+question\s+(\d+))\s*$/gim;
  const endRegex = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:ends|se\s+termine|termine|fin)\s*(?:here|ici)?|(?:fin)\s+question\s+(\d+))\s*$/gim;

  const starts = {};
  const ends = {};

  let match;
  while ((match = startRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    starts[qNum] = match.index + match[0].length;
  }
  while ((match = endRegex.exec(codeStr)) !== null) {
    const qNum = parseInt(match[1] || match[2], 10);
    ends[qNum] = match.index;
  }

  const slices = {};
  const sortedQNums = Object.keys(starts).map(Number).sort((a, b) => a - b);

  if (sortedQNums.length === 0) {
    // No markers found, entire code belongs to question 1
    slices[1] = codeStr.trim();
    return slices;
  }

  for (let i = 0; i < sortedQNums.length; i++) {
    const qNum = sortedQNums[i];
    const startPos = starts[qNum];
    let endPos = ends[qNum];

    if (endPos === undefined || endPos < startPos) {
      if (i + 1 < sortedQNums.length) {
        endPos = starts[sortedQNums[i + 1]] - 25;
        if (endPos < startPos) endPos = starts[sortedQNums[i + 1]];
      } else {
        endPos = codeStr.length;
      }
    }

    slices[qNum] = codeStr.substring(startPos, endPos).trim();
  }

  return slices;
}

/**
 * Multi-Question Weighted Scoring Engine.
 * Evaluates each question independently with AST slicing and aggregates with tripartite weights.
 */
function computeMultiQuestionExerciseScore({
  studentCode,
  starterTemplate,
  referenceSolution,
  passedTests = 0,
  totalTests = 0,
  problemPoints = 10,
  questions = [],
  questionPoints = {},
  weightTest = 40,
  weightAst = 60,
  weightAi = 0,
  aiScore = 0
}) {
  const studentSlices = sliceCodeByQuestionMarkers(studentCode);
  const refSlices = sliceCodeByQuestionMarkers(referenceSolution);
  const templateSlices = sliceCodeByQuestionMarkers(starterTemplate);

  const hasRefMarkers = Object.keys(refSlices).length > 1;
  const hasQuestions = Array.isArray(questions) && questions.length > 1 && hasRefMarkers;

  const hasTests = totalTests > 0;
  const testScoreRatio = hasTests ? (passedTests / totalTests) : 0;
  
  // When no test cases exist, automatically reallocate test weight to AST (100% AST)
  const wTest = hasTests ? ((weightTest !== undefined ? weightTest : 40) / 100) : 0;
  const wAst = hasTests ? ((weightAst !== undefined ? weightAst : 60) / 100) : (1.0 - ((weightAi || 0) / 100));
  const wAi = (weightAi !== undefined ? weightAi : 0) / 100;

  let qPointsMap = questionPoints;
  if (typeof qPointsMap === 'string') {
    try { qPointsMap = JSON.parse(qPointsMap); } catch (e) { qPointsMap = {}; }
  }
  if (!qPointsMap || typeof qPointsMap !== 'object') qPointsMap = {};

  if (!hasQuestions) {
    // Single question or reference solution without question markers: evaluate full code
    const isUntouched = isUntouchedTemplateCode(studentCode, starterTemplate);
    const astSimRatio = isUntouched ? 0 : calculateCodeSimilarity(studentCode, referenceSolution || '', starterTemplate);
    const astScoreRatio = astSimRatio / 100;
    const aiScoreRatio = (aiScore || 0) / 100;

    const combinedRatio = (testScoreRatio * wTest) + (astScoreRatio * wAst) + (aiScoreRatio * wAi);
    const rawScore = problemPoints * combinedRatio;
    const calculatedScore = roundToNextHalfPoint(rawScore, problemPoints);

    const questionsList = (Array.isArray(questions) && questions.length > 0)
      ? questions
      : [{ id: 'q1', orderIndex: 1, statement: 'Question 1' }];

    const mapKeys = Object.keys(qPointsMap);
    const mapValues = Object.values(qPointsMap);

    const breakdown = questionsList.map((q, idx) => {
      const qIndex = q.orderIndex || (idx + 1);
      const qId = q.id || qIndex;
      let rawMax = qPointsMap[qId] ?? qPointsMap[String(qId)] ?? qPointsMap[qIndex] ?? qPointsMap[String(qIndex)] ?? qPointsMap[idx + 1] ?? qPointsMap[String(idx + 1)];
      if (rawMax == null && q.points != null && !isNaN(Number(q.points))) {
        rawMax = Number(q.points);
      }
      if (rawMax == null && mapValues.length === questionsList.length && !isNaN(Number(mapValues[idx]))) {
        rawMax = Number(mapValues[idx]);
      }
      if (rawMax == null) {
        rawMax = problemPoints / questionsList.length;
      }
      const qMaxPts = Math.round(Number(rawMax) * 100) / 100;
      const qAwarded = Math.round(roundToNextHalfPoint(qMaxPts * combinedRatio, qMaxPts) * 100) / 100;
      return {
        questionId: q.id,
        orderIndex: qIndex,
        statement: q.statement,
        maxPts: qMaxPts,
        testScore: Math.round(testScoreRatio * 100),
        astScore: Math.round(astScoreRatio * 100),
        aiScore: Math.round(aiScoreRatio * 100),
        astSimilarityRatio: astSimRatio,
        pointsAwarded: qAwarded
      };
    });

    return {
      isMultiQuestion: questionsList.length > 1,
      calculatedScore,
      astSimilarityRatio: astSimRatio,
      hasTests,
      totalTests: totalTests || 0,
      passedTests: passedTests || 0,
      testScoreRatio,
      astScoreRatio,
      aiScoreRatio,
      weights: {
        weightTest: Math.round(wTest * 100),
        weightAst: Math.round(wAst * 100),
        weightAi: Math.round(wAi * 100)
      },
      wTest,
      wAST: wAst,
      m1Score: roundToNextHalfPoint(problemPoints * (testScoreRatio * wTest), problemPoints * wTest),
      m2Score: roundToNextHalfPoint(problemPoints * (astScoreRatio * wAst), problemPoints * wAst),
      m3Score: roundToNextHalfPoint(problemPoints * (aiScoreRatio * wAi), problemPoints * wAi),
      questionsBreakdown: breakdown
    };
  }

  // Multi-question breakdown with explicit reference markers
  let totalScore = 0;
  const mapValues = Object.values(qPointsMap);
  const questionsBreakdown = questions.map((q, idx) => {
    const qIndex = q.orderIndex || (idx + 1);
    const qId = q.id || qIndex;
    
    let rawMax = qPointsMap[qId] ?? qPointsMap[String(qId)] ?? qPointsMap[qIndex] ?? qPointsMap[String(qIndex)] ?? qPointsMap[idx + 1] ?? qPointsMap[String(idx + 1)];
    if (rawMax == null && q.points != null && !isNaN(Number(q.points))) {
      rawMax = Number(q.points);
    }
    if (rawMax == null && mapValues.length === questions.length && !isNaN(Number(mapValues[idx]))) {
      rawMax = Number(mapValues[idx]);
    }
    if (rawMax == null) {
      rawMax = problemPoints / questions.length;
    }
    const qMaxPts = Math.round(Number(rawMax) * 100) / 100;

    let sSlice = studentSlices[qIndex] || '';
    let rSlice = refSlices[qIndex] || '';
    let tSlice = templateSlices[qIndex] || '';

    if (!sSlice && questions.length === 1) sSlice = studentCode;
    if (!rSlice && questions.length === 1) rSlice = referenceSolution;
    if (!tSlice && questions.length === 1) tSlice = starterTemplate;

    const isUntouched = isUntouchedTemplateCode(sSlice, tSlice);
    const qAstSimRatio = isUntouched ? 0 : calculateCodeSimilarity(sSlice, rSlice, tSlice);
    const qAstScoreRatio = qAstSimRatio / 100;
    const qAiScoreRatio = (aiScore || 0) / 100;

    const qCombinedRatio = (testScoreRatio * wTest) + (qAstScoreRatio * wAst) + (qAiScoreRatio * wAi);
    const rawPoints = qMaxPts * qCombinedRatio;
    const qPointsAwarded = Math.round(roundToNextHalfPoint(rawPoints, qMaxPts) * 100) / 100;
    totalScore += qPointsAwarded;

    return {
      questionId: q.id,
      orderIndex: qIndex,
      statement: q.statement,
      maxPts: qMaxPts,
      astSimilarityRatio: qAstSimRatio,
      testScore: Math.round(testScoreRatio * 100),
      astScore: Math.round(qAstScoreRatio * 100),
      aiScore: Math.round(qAiScoreRatio * 100),
      pointsAwarded: qPointsAwarded,
      studentSlice: sSlice,
      refSlice: rSlice
    };
  });

  const finalCalculatedScore = Math.min(problemPoints, roundToNextHalfPoint(totalScore, problemPoints));

  return {
    isMultiQuestion: true,
    calculatedScore: finalCalculatedScore,
    astSimilarityRatio: Math.round(questionsBreakdown.reduce((a, b) => a + b.astSimilarityRatio, 0) / questionsBreakdown.length),
    hasTests,
    totalTests: totalTests || 0,
    passedTests: passedTests || 0,
    weights: {
      weightTest: Math.round(wTest * 100),
      weightAst: Math.round(wAst * 100),
      weightAi: Math.round(wAi * 100)
    },
    wTest,
    wAST: wAst,
    m1Score: roundToNextHalfPoint(totalScore * (testScoreRatio * wTest)),
    m2Score: roundToNextHalfPoint(totalScore * (1 - (testScoreRatio * wTest))),
    m3Score: 0,
    questionsBreakdown
  };
}

module.exports = {
  parsePseudoCodeAST,
  extractASTDelta,
  isUntouchedTemplateCode,
  calculateCodeSimilarity,
  roundToNextQuarterPoint,
  roundToNextHalfPoint,
  compute3ModuleScore,
  computeCanonicalExerciseScore,
  sliceCodeByQuestionMarkers,
  computeMultiQuestionExerciseScore
};

