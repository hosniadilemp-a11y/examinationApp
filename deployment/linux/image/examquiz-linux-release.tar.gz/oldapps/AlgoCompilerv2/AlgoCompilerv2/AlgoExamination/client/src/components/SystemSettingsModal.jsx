import React, { useState, useEffect } from 'react';
import { Settings, KeyRound, Shield, Save, RotateCcw, X, Check, Lock } from 'lucide-react';
import Swal from 'sweetalert2';

export const DEFAULT_VAULT_KEY = 'ALGO_EXAM_SYSTEM_VAULT_KEY_2026_@ESI';

export function getSystemVaultKey() {
  return localStorage.getItem('algo_system_vault_key') || DEFAULT_VAULT_KEY;
}

export default function SystemSettingsModal({ isOpen, onClose }) {
  const [vaultKey, setVaultKey] = useState(getSystemVaultKey());
  const [showKey, setShowKey] = useState(false);
  const [defaultDuration, setDefaultDuration] = useState(() => localStorage.getItem('algo_default_duration') || '90');
  const [defaultViolations, setDefaultViolations] = useState(() => localStorage.getItem('algo_default_violations') || '4');

  useEffect(() => {
    if (isOpen) {
      setVaultKey(getSystemVaultKey());
      setDefaultDuration(localStorage.getItem('algo_default_duration') || '90');
      setDefaultViolations(localStorage.getItem('algo_default_violations') || '4');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    const cleanKey = vaultKey.trim() || DEFAULT_VAULT_KEY;
    localStorage.setItem('algo_system_vault_key', cleanKey);
    localStorage.setItem('algo_default_duration', defaultDuration);
    localStorage.setItem('algo_default_violations', defaultViolations);

    Swal.fire({
      icon: 'success',
      title: 'Paramètres Enregistrés !',
      text: 'La configuration du coffre-fort et les préférences ont été mises à jour.',
      timer: 1500,
      showConfirmButton: false,
      background: '#111827',
      color: '#fff'
    });
    onClose();
  };

  const handleResetDefaults = () => {
    setVaultKey(DEFAULT_VAULT_KEY);
    setDefaultDuration('90');
    setDefaultViolations('4');
    localStorage.removeItem('algo_system_vault_key');
    localStorage.removeItem('algo_default_duration');
    localStorage.removeItem('algo_default_violations');

    Swal.fire({
      icon: 'info',
      title: 'Paramètres Réinitialisés',
      text: 'Les paramètres par défaut du système ont été restaurés.',
      timer: 1500,
      showConfirmButton: false,
      background: '#111827',
      color: '#fff'
    });
  };

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      zIndex: 9999,
      background: 'rgba(0, 0, 0, 0.75)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }}>
      <div style={{
        background: '#0f172a',
        border: '1px solid rgba(59, 130, 246, 0.3)',
        borderRadius: '14px',
        width: '100%',
        maxWidth: '560px',
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.8)',
        color: '#f8fafc',
        overflow: 'hidden'
      }}>
        {/* Header */}
        <div style={{
          padding: '18px 24px',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, transparent 100%)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Settings size={20} color="#60a5fa" />
            <h3 style={{ margin: 0, fontSize: '1.15rem', fontWeight: '800' }}>
              Paramètres Système & Sécurité
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              color: '#94a3b8',
              cursor: 'pointer',
              padding: '4px',
              borderRadius: '6px'
            }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Encryption Key Section */}
          <div style={{
            background: 'rgba(30, 41, 59, 0.6)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            borderRadius: '10px',
            padding: '16px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <KeyRound size={16} color="#a78bfa" />
              <label style={{ fontSize: '0.9rem', fontWeight: '700', color: '#e2e8f0' }}>
                Clé de Chiffrement du Coffre-Fort Système (AES-256) :
              </label>
            </div>
            <p style={{ fontSize: '0.78rem', color: '#94a3b8', margin: '0 0 10px 0', lineHeight: 1.5 }}>
              Cette clé est utilisée automatiquement pour chiffrer et déchiffrer les paquets d'examen (<code>.algobundle</code>) et les résultats corrigés (<code>.algoresults</code>) sans exiger de saisie manuelle.
            </p>
            <div style={{ position: 'relative' }}>
              <input
                type={showKey ? 'text' : 'password'}
                className="form-input"
                value={vaultKey}
                onChange={e => setVaultKey(e.target.value)}
                placeholder="Clé maître du système..."
                style={{
                  paddingRight: '80px',
                  fontSize: '0.88rem',
                  fontFamily: 'monospace',
                  background: '#090d16',
                  color: '#c4b5fd',
                  border: '1px solid rgba(167, 139, 250, 0.3)'
                }}
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                style={{
                  position: 'absolute',
                  right: '8px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'rgba(255, 255, 255, 0.08)',
                  border: 'none',
                  color: '#cbd5e1',
                  fontSize: '0.75rem',
                  padding: '4px 8px',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                {showKey ? 'Masquer' : 'Afficher'}
              </button>
            </div>
            {vaultKey !== DEFAULT_VAULT_KEY && (
              <div style={{ marginTop: '8px', fontSize: '0.75rem', color: '#fbbf24' }}>
                ⚠️ Clé personnalisée active. Assurez-vous que toutes les instances de l'école utilisent la même clé pour fusionner les paquets.
              </div>
            )}
          </div>

          {/* Exam Defaults Section */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: '700', color: '#cbd5e1', marginBottom: '6px' }}>
                Durée par défaut (Minutes) :
              </label>
              <input
                type="number"
                className="form-input"
                min="10"
                max="360"
                value={defaultDuration}
                onChange={e => setDefaultDuration(e.target.value)}
                style={{ fontSize: '0.88rem' }}
              />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: '700', color: '#cbd5e1', marginBottom: '6px' }}>
                Max Sorties Plein Écran :
              </label>
              <input
                type="number"
                className="form-input"
                min="1"
                max="10"
                value={defaultViolations}
                onChange={e => setDefaultViolations(e.target.value)}
                style={{ fontSize: '0.88rem' }}
              />
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div style={{
          padding: '16px 24px',
          borderTop: '1px solid rgba(255, 255, 255, 0.1)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          background: 'rgba(0, 0, 0, 0.2)'
        }}>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={handleResetDefaults}
            style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.82rem', padding: '8px 14px' }}
          >
            <RotateCcw size={14} /> Restaurer Défauts
          </button>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onClose}
              style={{ fontSize: '0.85rem', padding: '8px 16px' }}
            >
              Annuler
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={handleSave}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', fontWeight: '700', padding: '8px 20px' }}
            >
              <Save size={15} /> Enregistrer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
