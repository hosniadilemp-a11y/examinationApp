const fs = require('fs');
const path = require('path');
const { runCodeSingle } = require('../src/runner/code-execution.service');
const { globalExecutionQueue } = require('../src/runner/concurrency-queue');

function getAllAlgoFiles(dirPath, arrayOfFiles = []) {
  const files = fs.readdirSync(dirPath);

  files.forEach(file => {
    const fullPath = path.join(dirPath, file);
    if (fs.statSync(fullPath).isDirectory()) {
      arrayOfFiles = getAllAlgoFiles(fullPath, arrayOfFiles);
    } else if (file.endsWith('.algo')) {
      arrayOfFiles.push(fullPath);
    }
  });

  return arrayOfFiles;
}

async function runLoadTest102() {
  const examplesDir = path.resolve(__dirname, '../../../AlgoCompiler/examples');
  console.log('=====================================================');
  console.log('  Starting 102-Concurrent Load Test on Example Code  ');
  console.log(`  Target Directory: ${examplesDir}`);
  console.log(`  Queue Concurrency Limit: ${globalExecutionQueue.concurrencyLimit}`);
  console.log(`  Queue Max Depth:         ${globalExecutionQueue.maxQueueDepth}`);
  console.log('=====================================================');

  const algoFiles = getAllAlgoFiles(examplesDir);
  console.log(`[LOAD_TEST] Discovered ${algoFiles.length} unique example .algo files.`);

  // Select 51 files to duplicate x2 = 102 concurrent requests (or use all)
  const selectedFiles = algoFiles.slice(0, 51);
  const requests = [];

  selectedFiles.forEach((filePath, idx) => {
    const code = fs.readFileSync(filePath, 'utf8');
    const relName = path.relative(examplesDir, filePath);

    // Request 1
    requests.push({
      id: `${relName}_Run1`,
      code
    });
    // Request 2 (duplicate concurrent execution)
    requests.push({
      id: `${relName}_Run2`,
      code
    });
  });

  console.log(`[LOAD_TEST] Dispatching ${requests.length} concurrent execution sub-processes...`);
  const startTime = Date.now();

  const promises = requests.map((req, i) =>
    runCodeSingle(req.code, 'ALGO', '', 4000)
      .then(res => ({ reqId: req.id, index: i + 1, ok: true, res }))
      .catch(err => ({ reqId: req.id, index: i + 1, ok: false, err }))
  );

  const results = await Promise.all(promises);
  const totalMs = Date.now() - startTime;

  const successful = results.filter(r => r.ok && (r.res.status === 'SUCCESS' || r.res.status === 'RUNTIME_ERROR' || r.res.status === 'COMPILE_ERROR'));
  const saturated = results.filter(r => r.ok && r.res.status === 'QUEUE_SATURATED');
  const failed = results.filter(r => !r.ok || (r.res.status === 'QUEUE_SATURATED' ? false : !['SUCCESS', 'RUNTIME_ERROR', 'COMPILE_ERROR', 'TIME_LIMIT'].includes(r.res.status)));

  console.log('\n=====================================================');
  console.log('  102-Concurrent Load Test Results Summary           ');
  console.log('=====================================================');
  console.log(`  Total Dispatched Promises: ${results.length}`);
  console.log(`  Completed Executions:     ${successful.length}`);
  console.log(`  Saturated (HTTP 429):      ${saturated.length}`);
  console.log(`  Uncaught / Failed:         ${failed.length}`);
  console.log(`  Total Wall Clock Time:     ${totalMs} ms`);
  console.log('=====================================================\n');

  if (failed.length > 0) {
    console.error('FAIL: Load test encountered unhandled errors or process crashes:', failed);
    process.exit(1);
  } else {
    console.log('PASS: 102-Concurrent Load Test completed successfully with 0 process crashes!');
    process.exit(0);
  }
}

runLoadTest102();
