const prisma = require('../prisma');
const { withRetry } = require('../prisma');
const csvParser = require('csv-parser');
const { Readable } = require('stream');

function getDefaultAcademicYear() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  return month >= 9 ? year + 1 : year;
}

// List students
async function listStudents(req, res) {
  try {
    const { group, speciality, academicYear, search } = req.query;
    const where = {};

    if (group) where.group = group;
    if (speciality) where.speciality = speciality;
    if (academicYear) where.academicYear = parseInt(academicYear, 10);
    if (search) {
      where.OR = [
        { studentId: { contains: search, mode: 'insensitive' } },
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } }
      ];
    }

    const students = await withRetry(() => prisma.student.findMany({
      where,
      orderBy: [{ group: 'asc' }, { lastName: 'asc' }]
    }));

    return res.json(students);
  } catch (err) {
    console.error('listStudents error:', err);
    return res.status(500).json({ error: 'Failed to fetch students' });
  }
}

// Add single student manually
async function createStudent(req, res) {
  try {
    const { studentId, firstName, lastName, group, speciality, academicYear } = req.body;
    if (!studentId || !firstName || !lastName || !group || !speciality) {
      return res.status(400).json({ error: 'studentId, firstName, lastName, group, and speciality are required' });
    }

    const yearVal = academicYear ? parseInt(academicYear, 10) : getDefaultAcademicYear();

    const student = await prisma.student.create({
      data: {
        studentId: String(studentId).trim(),
        firstName: String(firstName).trim(),
        lastName: String(lastName).trim(),
        group: String(group).trim(),
        speciality: String(speciality).trim(),
        academicYear: isNaN(yearVal) ? getDefaultAcademicYear() : yearVal
      }
    });

    return res.status(201).json(student);
  } catch (err) {
    if (err.code === 'P2002') {
      return res.status(409).json({ error: 'Student ID already exists' });
    }
    console.error('createStudent error:', err);
    return res.status(500).json({ error: 'Failed to create student' });
  }
}

// Import students via CSV payload (raw text or file upload)
async function importStudentsCSV(req, res) {
  try {
    let csvData = req.body.csvText;
    const uploadedCSVFile = req.file || (req.files && Array.isArray(req.files) && req.files.length > 0 ? req.files[0] : null);
    if (!csvData && uploadedCSVFile) {
      csvData = uploadedCSVFile.buffer.toString('utf8');
    }
    if (csvData && typeof csvData === 'string') {
      csvData = csvData.replace(/^\uFEFF+/, '');
    }

    if (!csvData || !csvData.trim()) {
      return res.status(400).json({ error: 'No CSV data provided' });
    }

    const results = [];
    const stream = Readable.from([csvData]);

    stream
      .pipe(csvParser())
      .on('data', (data) => results.push(data))
      .on('end', async () => {
        let created = 0;
        let skipped = 0;
        const errors = [];

        for (const row of results) {
          const sId = row.StudentID || row.student_id || row.studentId || row.ID || row['Student ID'];
          const fName = row.FirstName || row.first_name || row.firstName || row['First Name'];
          const lName = row.LastName || row.last_name || row.lastName || row['Last Name'];
          const grp = row.Group || row.group || 'G1';
          const spec = row.Speciality || row.speciality || row.Major || 'Computer Science';
          const rawYear = row.AcademicYear || row.academic_year || row.academicYear || row.Year || row.year;
          const yrVal = rawYear ? parseInt(rawYear, 10) : getDefaultAcademicYear();
          const finalYear = isNaN(yrVal) ? getDefaultAcademicYear() : yrVal;

          if (!sId || !fName || !lName) {
            skipped++;
            continue;
          }

          try {
            await prisma.student.upsert({
              where: { studentId: String(sId).trim() },
              update: {
                firstName: String(fName).trim(),
                lastName: String(lName).trim(),
                group: String(grp).trim(),
                speciality: String(spec).trim(),
                academicYear: finalYear
              },
              create: {
                studentId: String(sId).trim(),
                firstName: String(fName).trim(),
                lastName: String(lName).trim(),
                group: String(grp).trim(),
                speciality: String(spec).trim(),
                academicYear: finalYear
              }
            });
            created++;
          } catch (e) {
            errors.push(`Row ${sId}: ${e.message}`);
            skipped++;
          }
        }

        return res.json({
          message: `Successfully processed ${results.length} records.`,
          created,
          skipped,
          errors
        });
      });
  } catch (err) {
    console.error('importStudentsCSV error:', err);
    return res.status(500).json({ error: 'Failed to process CSV import' });
  }
}

// Generate Access Number sheets for an Exam
async function generateExamAccessSheet(req, res) {
  try {
    const { examId } = req.params;

    const exam = await prisma.exam.findUnique({
      where: { id: examId },
      include: {
        assignments: {
          include: { student: true },
          orderBy: [{ student: { group: 'asc' } }, { accessNumber: 'asc' }]
        }
      }
    });

    if (!exam) return res.status(404).json({ error: 'Exam not found' });

    const cards = exam.assignments.map(a => ({
      accessNumber: a.accessNumber,
      studentId: a.student.studentId,
      fullName: `${a.student.firstName} ${a.student.lastName}`,
      group: a.student.group,
      speciality: a.student.speciality,
      examTitle: exam.title,
      durationMinutes: exam.durationMinutes
    }));

    return res.json({
      examTitle: exam.title,
      totalStudents: cards.length,
      cards
    });
  } catch (err) {
    console.error('generateExamAccessSheet error:', err);
    return res.status(500).json({ error: 'Failed to generate access card sheet' });
  }
}

module.exports = {
  listStudents,
  createStudent,
  importStudentsCSV,
  generateExamAccessSheet
};
