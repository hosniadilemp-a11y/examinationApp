# Solution Blueprint: AI-Assisted Exam Correction Engine (Teacher Solution Aide)

## 📌 Executive Overview
The **Teacher Solution Aide for Exam Correction** in **AlgoExamination** is a fast, accurate, and easy-to-use grading assistant designed for computer science educators. It empowers professors to correct full student exam cohorts in minutes by combining:
1. **Local AI Integration** (Ollama / Local OpenAI-compatible API) with zero cloud dependency.
2. **Deterministic AlgoCompiler Execution & AST Analyzer** fallback for 100% offline reliability.
3. **Batch Auto-Correction & Smart Review Grid** with real-time Socket.IO streaming.
4. **4-Criterion Academic Rubric Breakdown** (Syntax, Structure, Core Logic, Test Cases).
5. **AST Pattern Grouping & Plagiarism Detection** to group similar solutions and flag code sharing.

---

## 🏗️ Architecture & Component Design

```
                     ┌──────────────────────────────────────────────┐
                     │          Teacher Correction Workspace        │
                     │         (React + Visual Side-by-Side)        │
                     └──────────────────────┬───────────────────────┘
                                            │
                                  Socket.IO / REST API
                                            │
                     ┌──────────────────────▼───────────────────────┐
                     │     Server Correction Engine Orchestrator    │
                     │       (grading.controller.js & Service)      │
                     └──────┬───────────────────┬───────────────────┘
                            │                   │
         ┌──────────────────┴──┐             ┌──┴──────────────────┐
         │ Local AI Adapter    │             │ AlgoCompiler Engine │
         │ (Ollama HTTP /      │             │ (Python Sandbox &   │
         │  OpenAI-Compatible) │             │  AST AST-Analyzer)  │
         └─────────────────────┘             └─────────────────────┘
```

---

## 🎯 Key Architectural Components

### 1. Hybrid Tri-Engine Grading Pipeline
- **Sandbox Test Execution (15% - 30%)**: Runs student code inside the Node.js child process isolate runner against test cases defined in the Problem Bank.
- **Static AST & Syntax Analyzer (20% - 30%)**: Checks header balance (`ALGORITHME`), variable section (`VAR`), block pairings (`SI...FINSI`, `POUR...FINPOUR`), and syntax correctness.
- **Local AI Logic & Rubric Evaluator (35% - 50%)**: Calls the local LLM model (e.g. Qwen2.5-Coder / DeepSeek-Coder via Ollama) to compare student pseudo-code logic against the reference solution, generating score proposals and constructive feedback in French/English.
- **Offline Fallback**: If the Local AI service is offline, the system seamlessly falls back to pure AST structural scoring + sandbox test case execution without throwing errors.

---

### 2. Local AI Adapter (`server/src/services/local-ai.service.js`)
- **Protocol**: Standard HTTP REST client connecting to `http://localhost:11434/api/generate` (Ollama) or any local OpenAI-compatible endpoint (`http://localhost:1234/v1`).
- **Prompt Engineering Template**:
  - Task: Grade pseudo-code student submission against Reference Solution and Rubric.
  - Output format: Strict JSON `{ score, rubricBreakdown, feedback, confidenceScore, keyDifferences }`.
  - Zero hallucination guardrails enforced via JSON schema response mode.

---

### 3. Teacher UI & Batch Review Grid (`CorrectionWorkspace.jsx`)
- **"⚡ Auto-Corriger Tout l'Examen"**: Single-click bulk evaluation. Launches server-side async worker with live Socket.IO progress bar (`pdf_zip_progress` style channel).
- **Color-Coded Confidence Grid**:
  - 🟢 **High Confidence (90-100%)**: Auto-approved score proposal, 1-click batch validation.
  - 🟡 **Needs Review (50-89%)**: Highlights specific lines where student pseudo-code diverged from reference solution.
  - 🔴 **Execution / Syntax Error (0-49%)**: Immediate error badge displaying compiler error message.
- **Visual Side-by-Side Viewer**:
  - Left Panel: Student Code with highlighted syntax & logic discrepancies.
  - Right Panel: Teacher Reference Solution + AST Structure tree.
  - Bottom Panel: 4-Criterion Rubric sliders/checkboxes + Editable AI feedback text box + Save & Next button.

---

### 4. 4-Criterion Dynamic Academic Rubric
Each exercise total points (e.g., /10 or /20) are automatically distributed across 4 transparent criteria:
1. **Syntax & Variable Declarations (20%)**: Correct header, variable declarations, types, `DEBUT...FIN`.
2. **Control Flow & Structure (30%)**: Appropriate choice of loops (`POUR`, `TANT QUE`), `SI/FINSI` conditions, indentation.
3. **Core Logic Equivalence (35%)**: Algorithmic correctness, handling of main task logic compared to Reference Solution.
4. **Test Case Sandbox Execution (15%)**: Passing public and hidden test cases in sandbox execution.

---

### 5. AST Pattern Grouping & Plagiarism Detection
- **Pattern Clustering**: Groups student submissions with identical AST structure (even if variable names like `i`, `j`, `counter` differ). Allows the teacher to grade 1 representative copy and apply the score to all matching students.
- **Similarity Matrix**: Compares AST trees across all students in the exam session. Submissions with >85% structural similarity trigger a 🚨 **Alerte de Similitude** badge on the teacher dashboard with a direct line-by-line diff comparison between suspect student pairs.

---

## 🧪 Verification & Demonstration Plan

### Automated Checks
- Validate API endpoint `/api/grading/exams/:id/auto-grade` for single & batch student evaluation.
- Run local AI service adapter connection test (`Ollama` fallback check).
- Verify Prisma database updates for `ExamAssignment` and `Submission` score models.

### Manual Verification
- Perform a simulated exam correction on sample pseudo-code submissions (correct code, syntax error code, logical mistake code).
- Test single-click batch auto-correction with visual progress update.
- Verify side-by-side code visual diff and score override functionality.

---
