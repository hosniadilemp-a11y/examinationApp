# 03. Component & Service Specifications

## 🖥️ Frontend Components (`client/src/components/`)

### 1. `ExamManager.jsx`
- **Purpose**: Authoring and editing exam sessions.
- **Key Features**:
  - Unified single scrollable form layout with 5 distinct sections.
  - Defaults: Module = *"Algorithmique et Structure de Données"*, Title = *"Partiel 01"*, Session = Dynamic Academic Semester based on current month (Aug–Dec $\rightarrow$ S1, Jan–Jul $\rightarrow$ S2).
  - Date pre-filled to today's date (`YYYY-MM-DD`), Start Time pre-filled to current time + 2 mins (`HH:MM`).
  - Auto-allocates remaining points to hit 20 pts when adding new exercises without resetting points on existing exercises.
  - Live total points indicator with warning badge if total $\neq 20$ pts.
  - Group dropdown filtering, student search, CSV matricule importer, and pre-selection of all students by default.

### 2. `WaitingRoom.jsx`
- **Purpose**: Pre-exam waiting area for students prior to teacher launch.
- **Key Features**:
  - Fullscreen gate modal ensuring students remain in fullscreen before launch.
  - Listens to `exam_started` and `exam_status_changed` socket events.
  - Fast 3-second background polling via `getStudentWorkspace()` to handle dropped socket messages.
  - Auto-reconnect listener re-subscribing to socket room on network drops.

### 3. `ExamWorkspace.jsx`
- **Purpose**: Interactive pseudo-code editor for students during an active exam.
- **Key Features**:
  - Problem tabs, template code loader, pseudo-code sample runner.
  - Background autosave sending code per problem to `POST /student/autosave`.
  - Anti-cheat handlers for window blur, tab switch, context menu, copy/paste, and fullscreen exit.
  - Socket listeners for `student_locked`, `student_unlocked`, `student_terminated`, `exam_force_ended`.

### 4. `TeacherDashboard.jsx`
- **Purpose**: Real-time live monitoring dashboard for teachers.
- **Key Features**:
  - Active student table with live online dots, violation count, and fullscreen exit counters.
  - Emergency control buttons: Suspend (`LOCK_STUDENT`), Resume (`UNLOCK_STUDENT`), Exclude (`TERMINATE_STUDENT`), Extend Time (`EXTEND_TIME_ALL`).
  - Toast alert stream for real-time violations (`FULLSCREEN_EXIT`, `TAB_SWITCH`, `KICKED_FULLSCREEN`).
  - Fast 5-second HTTP polling fallback alongside Socket.IO listeners.

### 5. `CorrectionWorkspace.jsx`
- **Purpose**: Post-exam teacher grading workspace and bulk export center.
- **Key Features**:
  - Displays student code vs teacher reference solution with diff view.
  - Algorithmic AST/regex syntax analyzer checking pseudo-code structures.
  - Student navigation bar: Up/Down for student copies, Left/Right for exercises.
  - **Master ZIP Export**: Triggers streaming `.zip` generation on backend, displaying a real-time progress modal reacting to `pdf_zip_progress` socket events.

---

## ⚙️ Core Services (`server/src/services/` & `server/src/controllers/`)

### 1. `pdf.service.js`
- **Purpose**: PDFKit document generation for official student copies.
- **Styling**: Strict Black & White theme (white background, crisp black borders, high-contrast typography) to guarantee 0% black page rendering issues.
- **Header**: Renders `exam.university`, `exam.module`, `exam.title`, `exam.session`, student name, group, matricule, and date.
- **Authentic QR Engine**: Encodes cryptographic SHA-256 HMAC signature calculated from assignment ID, student ID, and score out of 20.

### 2. `grading.controller.js`
- **Purpose**: Handles grading API endpoints, syntax analysis, single PDF download, and Master ZIP export.
- **Master ZIP Stream (`downloadAllStudentCopiesPDF`)**: Uses `archiver@5.3.2` (CommonJS compatible) to stream a `.zip` archive containing all graded student PDFs. Emits `pdf_zip_progress` socket events per generated copy.

### 3. `exam.controller.js`
- **Purpose**: Handles exam creation, updates, status transitions, and emergency actions.
- **Date Handling**: Uses `parseSafeDate` to convert date/time strings cleanly without causing Prisma `Invalid Date` crashes.
- **Teacher Resolution**: Validates `teacherId` in JWT token and falls back to active teacher in DB if token ID is outdated due to database re-seeding.

### 4. `code-execution.service.js`
- **Purpose**: Sandbox execution environment for pseudo-code algorithms. Translates pseudo-code keywords (`ALGORITHME`, `VARIABLES`, `SI`, `POUR`, `TANTQUE`, `ECRIRE`, `LIRE`) into runnable JavaScript in an isolated process.
