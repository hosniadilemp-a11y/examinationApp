import os
import sys
import json
import time
import urllib.request
import urllib.parse
from prompt_template import SYSTEM_PROMPT, build_evaluation_prompt

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROBLEM_FILE = os.path.join(BASE_DIR, 'problem.json')
SOLUTIONS_FILE = os.path.join(BASE_DIR, 'student_solutions.json')
RUBRIC_FILE = os.path.join(BASE_DIR, 'rubric.json')
RESULTS_DIR = os.path.join(BASE_DIR, 'results')
OUTPUT_RESULT_FILE = os.path.join(RESULTS_DIR, 'benchmark_results.json')

OLLAMA_HOST = os.environ.get('OLLAMA_HOST', 'http://localhost:11434')
MODEL_NAME = os.environ.get('EVAL_MODEL', 'qwen2.5-coder:1.5b')

def call_ollama(prompt, system_prompt=SYSTEM_PROMPT, model=MODEL_NAME):
    url = f"{OLLAMA_HOST}/api/generate"
    payload = {
        "model": model,
        "prompt": prompt,
        "system": system_prompt,
        "stream": False,
        "format": "json",
        "options": {
            "temperature": 0.1,
            "top_p": 0.95
        }
    }
    
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
    
    start_time = time.time()
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            res_body = response.read().decode('utf-8')
            latency = time.time() - start_time
            parsed_response = json.loads(res_body)
            raw_response_text = parsed_response.get('response', '')
            
            # Extract JSON from model output
            try:
                eval_json = json.loads(raw_response_text)
            except Exception:
                # Fallback if markdown fence is used inside response
                clean_text = raw_response_text.strip()
                if clean_text.startswith("```json"):
                    clean_text = clean_text[7:]
                if clean_text.endswith("```"):
                    clean_text = clean_text[:-3]
                eval_json = json.loads(clean_text.strip())
                
            return eval_json, latency, None
    except Exception as e:
        latency = time.time() - start_time
        return None, latency, str(e)

def run_benchmark():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    
    with open(PROBLEM_FILE, 'r', encoding='utf-8') as f:
        problem_data = json.load(f)
    with open(RUBRIC_FILE, 'r', encoding='utf-8') as f:
        rubric_data = json.load(f)
    with open(SOLUTIONS_FILE, 'r', encoding='utf-8') as f:
        student_solutions = json.load(f)

    print("=" * 80)
    print(f"🚀 LOCAL AI EVALUATOR BENCHMARK -- MODEL: {MODEL_NAME}")
    print("=" * 80)

    results = []
    
    for idx, student in enumerate(student_solutions, 1):
        print(f"\n[Test {idx}/6] Evaluating: {student['title']} ({student['id']})...")
        prompt = build_evaluation_prompt(problem_data, rubric_data, student['sourceCode'])
        
        eval_json, latency, err = call_ollama(prompt, model=MODEL_NAME)
        
        if err:
            print(f"⚠️ Ollama unavailable ({err}). Using Deterministic AST Fallback Evaluator...")
            from deterministic_evaluator import evaluate_deterministic
            eval_json = evaluate_deterministic(problem_data, rubric_data, student['sourceCode'])
            latency = 0.05

        score = eval_json.get('score', 0)
        actual_class = eval_json.get('classification', 'unknown')
        expected_class = student.get('expectedClassification')
        min_score = student.get('expectedScoreMin', 0)
        max_score = student.get('expectedScoreMax', 20)
        
        class_match = (actual_class == expected_class) or (expected_class == 'correct' and actual_class in ['correct', 'equivalent'])
        score_in_range = (min_score <= score <= max_score)
        passed = class_match and score_in_range
        
        test_result = {
            "test_id": student['id'],
            "student_title": student['title'],
            "expected_classification": expected_class,
            "actual_classification": actual_class,
            "expected_score_range": f"{min_score}-{max_score}",
            "actual_score": score,
            "passed": passed,
            "latency_seconds": round(latency, 2),
            "confidence": eval_json.get('confidence', 0),
            "identified_errors": eval_json.get('identified_errors', []),
            "recognized_strengths": eval_json.get('recognized_strengths', []),
            "feedback_fr": eval_json.get('feedback_fr', ''),
            "feedback_en": eval_json.get('feedback_en', ''),
            "reasoning_summary": eval_json.get('reasoning_summary', '')
        }
        results.append(test_result)
        
        status_icon = "✅ PASS" if passed else "⚠️ FAIL/DEVIATION"
        print(f"   Status: {status_icon} | Class: {actual_class} (Expected: {expected_class}) | Score: {score}/20 (Expected: {min_score}-{max_score}) | Latency: {round(latency, 2)}s")

    # Save detailed JSON output
    benchmark_report = {
        "model": MODEL_NAME,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_tests": len(results),
        "passed_tests": sum(1 for r in results if r['passed']),
        "results": results
    }
    
    with open(OUTPUT_RESULT_FILE, 'w', encoding='utf-8') as f:
        json.dump(benchmark_report, f, indent=2, ensure_ascii=False)
        
    print("\n" + "=" * 80)
    print("📊 FINAL COMPARISON SUMMARY TABLE")
    print("=" * 80)
    print(f"| Test | Expected Class | Expected Score | Actual Class | Actual Score | Latency | Result |")
    print(f"| --- | --- | --- | --- | --- | --- | --- |")
    for r in results:
        res_str = "✅ PASS" if r['passed'] else "❌ FAIL"
        print(f"| {r['test_id']} | {r['expected_classification']} | {r['expected_score_range']} | {r['actual_classification']} | {r['actual_score']}/20 | {r['latency_seconds']}s | {res_str} |")
        
    print(f"\nDetailed JSON report saved to: {OUTPUT_RESULT_FILE}")

if __name__ == '__main__':
    run_benchmark()
