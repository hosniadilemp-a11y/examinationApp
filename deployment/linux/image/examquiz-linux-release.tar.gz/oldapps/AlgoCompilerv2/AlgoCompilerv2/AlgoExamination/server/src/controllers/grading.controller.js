const prisma = require('../prisma');
const { withRetry } = require('../prisma');
const { evaluateSubmission, runCodeSingle, isTestOutputMatching, normalizeOutput } = require('../runner/code-execution.service');
const { calculateCodeSimilarity, compute3ModuleScore, isUntouchedTemplateCode, computeCanonicalExerciseScore, computeMultiQuestionExerciseScore, sliceCodeByQuestionMarkers, roundToNextQuarterPoint, roundToNextHalfPoint } = require('../runner/ast-similarity.service');
const { evaluateAIForSubmission } = require('../runner/ai-rubric.service');
const archiver = require('archiver');

// ── Pseudo-code Syntax & Structure Analyzer ──────────────────────────────
function analyzeAlgorithmicSyntax(code) {
  if (!code || typeof code !== 'string') {
    return { valid: false, errors: ['Code vide ou non fourni.'], warnings: [], structure: {} };
  }

  const lines = code.split('\n');
  const errors = [];
  const warnings = [];

  const hasAlgorithme = /ALGORITHME\s+\w+/i.test(code);
  const hasVariables  = /\b(VAR|VARIABLES)\b/i.test(code);
  const hasDebut      = /\bDEBUT\b/i.test(code);
  const hasFin        = /\bFIN\b\.?/i.test(code);

  if (!hasAlgorithme) warnings.push('En-tête "ALGORITHME <nom>" manquant.');
  if (!hasVariables)  warnings.push('Section "VAR" / "VARIABLES" non explicitée.');
  if (!hasDebut)      errors.push('Bloc "DEBUT" manquant.');
  if (!hasFin)        errors.push('Mot-clé "FIN" de clôture manquant.');

  // Control block balance counters
  let siCount       = 0;
  let finSiCount    = 0;
  let pourCount     = 0;
  let finPourCount  = 0;
  let tantQueCount  = 0;
  let finTantQueCount = 0;

  lines.forEach((line, idx) => {
    const lineNum = idx + 1;
    const clean = line.trim();
    if (!clean || clean.startsWith('//')) return;

    const isFinSi = /\bFIN\s*SI\b|\bFINSI\b/i.test(clean);
    const isFinPour = /\bFIN\s*POUR\b|\bFINPOUR\b/i.test(clean);
    const isFinTantQue = /\bFIN\s*TANT\s*QUE\b|\bFIN\s*TANTQUE\b|\bFINTANTQUE\b/i.test(clean);

    if (/\bSI\b/i.test(clean) && !isFinSi) siCount++;
    if (isFinSi) finSiCount++;

    if (/\bPOUR\b/i.test(clean) && !isFinPour) pourCount++;
    if (isFinPour) finPourCount++;

    if (/\bTANT\s*QUE\b|\bTANTQUE\b/i.test(clean) && !isFinTantQue) tantQueCount++;
    if (isFinTantQue) finTantQueCount++;

    // Assignment check (:= or <- in algorithmic language)
    if (clean.includes('=') && !clean.includes(':=') && !clean.includes('<-') && !clean.includes('==') && !clean.includes('<=') && !clean.includes('>=')) {
      warnings.push(`Ligne ${lineNum}: Utilisation de "=" au lieu de ":=" ou "<-" pour l'affectation.`);
    }
  });

  if (siCount !== finSiCount) {
    errors.push(`Déséquilibre de structure IF: ${siCount} "SI" vs ${finSiCount} "FINSI".`);
  }
  if (pourCount !== finPourCount) {
    errors.push(`Déséquilibre de boucle POUR: ${pourCount} "POUR" vs ${finPourCount} "FINPOUR".`);
  }
  if (tantQueCount !== finTantQueCount) {
    errors.push(`Déséquilibre de boucle TANT QUE: ${tantQueCount} "TANT QUE" vs ${finTantQueCount} "FIN TANT QUE".`);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    structure: { hasAlgorithme, hasVariables, hasDebut, hasFin }
  };
}

// ── Helpers to extract Template & Reference Code ──────────────────────────
function getProblemStarterTemplate(prob) {
  if (!prob) return '';
  let tCode = prob.templateCode;
  if (typeof tCode === 'string' && tCode.trim()) {
    try {
      const parsed = JSON.parse(tCode);
      if (parsed && typeof parsed === 'object') tCode = parsed;
    } catch (e) {}
  }
  if (typeof tCode === 'object' && tCode !== null) {
    return tCode.ALGO || tCode.code || tCode.PYTHON || '';
  }
  if (typeof tCode === 'string') return tCode;
  return prob.starterTemplate || '';
}

function getProblemReferenceSolution(prob) {
  if (!prob) return '';
  const safeTitle = (prob.title || 'Exercice').trim();
  let defaultRef = prob.referenceSolution;
  if (defaultRef && defaultRef.trim()) return defaultRef.trim();

  const tpl = getProblemStarterTemplate(prob);
  if (tpl && tpl.trim() && !/(?:r[ée]digez|indiquez|compl[ée]tez|votre\s+code|votre\s+solution|todo)/i.test(tpl)) {
    return tpl.trim();
  }

  const lower = safeTitle.toLowerCase();
  if (lower.includes('somme') || lower.includes('add')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   A, B, Somme : Entier\nDEBUT\n   // Solution Repère : Somme de deux entiers\n   Lire(A);\n   Lire(B);\n   Somme := A + B;\n   Ecrire(Somme);\nFIN.`;
  } else if (lower.includes('max') || lower.includes('grand')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   N, i, Val, MaxVal : Entier\nDEBUT\n   // Solution Repère : Recherche du Maximum\n   Lire(N);\n   Lire(MaxVal);\n   Pour i := 2 a N Faire\n      Lire(Val);\n      Si (Val > MaxVal) Alors\n         MaxVal := Val;\n      FinSi;\n   FinPour;\n   Ecrire(MaxVal);\nFIN.`;
  } else if (lower.includes('tri') || lower.includes('bulle')) {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   T : Tableau [1..100] de Entier\n   N, i, j, Temp : Entier\nDEBUT\n   // Solution Repère : Tri à Bulles\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]) FinPour;\n   Pour i := 1 a N-1 Faire\n      Pour j := 1 a N-i Faire\n         Si (T[j] > T[j+1]) Alors\n            Temp := T[j]; T[j] := T[j+1]; T[j+1] := Temp;\n         FinSi;\n      FinPour;\n   FinPour;\nFIN.`;
  } else if (lower.includes('factorielle') || lower.includes('fact')) {
    return `ALGORITHME Solution_Factorielle\nVARIABLES\n   N, i, Fact : Entier\nDEBUT\n   Lire(N);\n   Fact := 1;\n   Pour i := 1 a N Faire\n      Fact := Fact * i;\n   FinPour;\n   Ecrire(Fact);\nFIN.`;
  } else {
    return `ALGORITHME Solution_${safeTitle.replace(/\s+/g, '_')}\nVARIABLES\n   N, Val_${safeTitle.replace(/\s+/g, '')} : Entier\nDEBUT\n   // Solution Repère pour ${safeTitle}\n   Lire(N);\n   Val_${safeTitle.replace(/\s+/g, '')} := N * 2;\n   Ecrire(Val_${safeTitle.replace(/\s+/g, '')});\nFIN.`;
  }
}

// ── Core Evaluator for a Single Submission (Server-side Execution) ────────
async function evaluateSingleSubmission(examId, studentId, problemId, overrideManualScore = null, forceRunTests = false) {
  const exam = await prisma.exam.findUnique({
    where: { id: examId },
    include: {
      problems: {
        orderBy: { orderIndex: 'asc' },
        include: {
          problem: {
            include: {
              questions: { orderBy: { orderIndex: 'asc' } },
              testCases: { select: { id: true, inputData: true, expectedOutput: true, isPublic: true } }
            }
          }
        }
      }
    }
  });

  if (!exam) throw new Error('Examen non trouvé');

  const epObj = exam.problems.find(ep => ep.problemId === problemId);
  const prob = epObj?.problem;
  if (!prob) throw new Error('Problème non trouvé dans cet examen');

  const maxPts = epObj?.points || prob.points || 20;
  const starterTpl = getProblemStarterTemplate(prob);
  const refSol = getProblemReferenceSolution(prob);

  let sub = await prisma.submission.findFirst({
    where: { examId, studentId, problemId },
    orderBy: { createdAt: 'desc' }
  });

  const assignment = await prisma.examAssignment.findUnique({
    where: { examId_studentId: { examId, studentId } }
  });
  let codeMap = assignment?.currentCodeMap;
  if (typeof codeMap === 'string') {
    try { codeMap = JSON.parse(codeMap); } catch (e) {}
  }
  let assignmentCode = '';
  if (codeMap && typeof codeMap === 'object') {
    const val = codeMap[problemId];
    if (typeof val === 'string') assignmentCode = val;
    else if (val && typeof val === 'object' && val.code) assignmentCode = val.code;
  }

  let code = (assignmentCode && assignmentCode.trim()) || sub?.sourceCode || '';
  if (!code || !code.trim()) {
    code = starterTpl || '// Aucun code soumis';
  }

  const isUntouched = isUntouchedTemplateCode(code, starterTpl);
  const testCases = prob.testCases || [];
  const totalTests = testCases.length;

  let passedTests = sub?.passedTests || 0;
  let testResults = [];

  const shouldRunTests = totalTests > 0 && forceRunTests === true && !isUntouched;

  if (shouldRunTests) {
    passedTests = 0;
    for (let i = 0; i < testCases.length; i++) {
      const tc = testCases[i];
      try {
        const res = await runCodeSingle(code, 'ALGO', tc.inputData || '', 2000);
        const actualOut = normalizeOutput(res.stdout || '');
        const expectedOut = normalizeOutput(tc.expectedOutput || '');
        const passed = isTestOutputMatching(res.stdout || '', tc.expectedOutput || '');
        if (passed) passedTests++;

        testResults.push({
          id: tc.id,
          index: i + 1,
          isPublic: tc.isPublic,
          inputData: tc.inputData,
          expectedOutput: expectedOut,
          actualOutput: actualOut,
          passed,
          rawStdout: res.stdout,
          rawStderr: res.stderr
        });
      } catch (err) {
        testResults.push({
          id: tc.id,
          index: i + 1,
          isPublic: tc.isPublic,
          inputData: tc.inputData,
          expectedOutput: tc.expectedOutput,
          actualOutput: err.message,
          passed: false,
          rawStdout: '',
          rawStderr: err.message
        });
      }
    }
  } else if (isUntouched) {
    passedTests = 0;
  }

  const canonical = computeMultiQuestionExerciseScore({
    studentCode: code,
    starterTemplate: starterTpl,
    referenceSolution: refSol,
    passedTests,
    totalTests,
    problemPoints: maxPts,
    questions: prob.questions || [],
    questionPoints: epObj?.questionPoints || {},
    weightTest: epObj?.weightTest ?? 40,
    weightAst: epObj?.weightAst ?? 60,
    weightAi: epObj?.weightAi ?? 0,
    aiScore: sub?.aiScore || 0
  });

  let activeManualScore;
  if (overrideManualScore !== null && overrideManualScore !== undefined && !isNaN(parseFloat(overrideManualScore))) {
    activeManualScore = Math.min(maxPts, Math.max(0, parseFloat(overrideManualScore)));
  } else if (sub?.manualScore !== null && sub?.manualScore !== undefined && !forceRunTests) {
    activeManualScore = sub.manualScore;
  } else {
    activeManualScore = canonical.calculatedScore;
  }

  const scorePct = totalTests > 0 ? Math.round((passedTests / totalTests) * 100) : 0;

  if (sub) {
    sub = await prisma.submission.update({
      where: { id: sub.id },
      data: {
        sourceCode: code,
        manualScore: activeManualScore,
        score: scorePct,
        passedTests,
        totalTests,
        status: 'GRADED',
        gradedAt: new Date()
      }
    });
  } else {
    sub = await prisma.submission.create({
      data: {
        examId,
        studentId,
        problemId,
        language: 'ALGO',
        sourceCode: code,
        manualScore: activeManualScore,
        score: scorePct,
        passedTests,
        totalTests,
        status: 'GRADED',
        gradedAt: new Date()
      }
    });
  }

  // Persist / Update per-question Grade records
  let questionsBreakdownResult = canonical.questionsBreakdown || [];

  if (assignment && epObj?.id && Array.isArray(canonical.questionsBreakdown)) {
    const existingGrades = await prisma.grade.findMany({
      where: { assignmentId: assignment.id, examProblemId: epObj.id }
    });

    questionsBreakdownResult = canonical.questionsBreakdown.map(qb => {
      const existingG = existingGrades.find(g => g.questionId === qb.questionId);
      const pts = (existingG && existingG.pointsAwarded !== null && existingG.pointsAwarded !== undefined && !forceRunTests)
        ? existingG.pointsAwarded
        : qb.pointsAwarded;
      return { ...qb, pointsAwarded: pts };
    });

    for (const qb of questionsBreakdownResult) {
      const validQ = (prob.questions || []).find(q => q.id === qb.questionId);
      if (validQ && validQ.id) {
        try {
          await prisma.grade.upsert({
            where: {
              assignmentId_examProblemId_questionId: {
                assignmentId: assignment.id,
                examProblemId: epObj.id,
                questionId: validQ.id
              }
            },
            update: {
              testScore: qb.testScore,
              astScore: qb.astScore,
              aiScore: qb.aiScore,
              pointsAwarded: qb.pointsAwarded
            },
            create: {
              assignmentId: assignment.id,
              examProblemId: epObj.id,
              questionId: validQ.id,
              testScore: qb.testScore,
              astScore: qb.astScore,
              aiScore: qb.aiScore,
              pointsAwarded: qb.pointsAwarded
            }
          });
        } catch (errGrade) {
          console.warn('[Grade.upsert] Non-fatal grade persistence warning:', errGrade.message);
        }
      }
    }
  }

  return {
    ...sub,
    manualScore: activeManualScore,
    evaluationBreakdown: {
      ...canonical,
      questionsBreakdown: questionsBreakdownResult,
      manualScore: activeManualScore,
      testResults
    }
  };
}

// ── Recalculate Student Assignment Total and Scaled Final Score /20 ───────
async function recalculateStudentAssignmentFinalScore(examId, studentId, explicitGradingStatus = null) {
  const exam = await prisma.exam.findUnique({
    where: { id: examId },
    include: {
      problems: {
        orderBy: { orderIndex: 'asc' },
        include: { problem: true }
      }
    }
  });

  if (!exam) return null;

  const submissions = await prisma.submission.findMany({
    where: { examId, studentId }
  });

  let totalRawEarned = 0;
  let totalExamMaxPoints = 0;

  let hasAnyGrade = false;
  exam.problems.forEach(ep => {
    const prob = ep.problem;
    const pts = ep.points || prob?.points || 20;
    totalExamMaxPoints += pts;

    const sub = submissions.find(s => s.problemId === ep.problemId);
    if (sub) {
      if (sub.manualScore !== null && sub.manualScore !== undefined) {
        totalRawEarned += parseFloat(sub.manualScore) || 0;
        hasAnyGrade = true;
      } else if (sub.score !== null && sub.score !== undefined) {
        totalRawEarned += ((parseFloat(sub.score) || 0) / 100) * pts;
        hasAnyGrade = true;
      }
    }
  });

  totalRawEarned = roundToNextQuarterPoint(totalRawEarned, totalExamMaxPoints);

  const scaledScore20 = hasAnyGrade && totalExamMaxPoints > 0
    ? roundToNextQuarterPoint((totalRawEarned / totalExamMaxPoints) * 20, 20)
    : null;

  const currentAssignment = await prisma.examAssignment.findUnique({
    where: { examId_studentId: { examId, studentId } },
    select: { gradingStatus: true }
  });

  const nextGradingStatus = explicitGradingStatus !== null && explicitGradingStatus !== undefined
    ? explicitGradingStatus
    : (currentAssignment ? currentAssignment.gradingStatus : 'UNGRADED');

  const assignment = await prisma.examAssignment.update({
    where: { examId_studentId: { examId, studentId } },
    data: {
      finalScore: scaledScore20,
      gradingStatus: nextGradingStatus
    },
    include: {
      student: { select: { id: true, studentId: true, firstName: true, lastName: true, group: true } }
    }
  });

  return {
    assignment,
    totalRawEarned,
    totalExamMaxPoints,
    scaledScore20
  };
}

// ── GET Exam Grading Data (SERVER SINGLE SOURCE OF TRUTH) ─────────────────
async function getExamGradingData(req, res) {
  try {
    const { id: examId } = req.params;

    const exam = await withRetry(() => prisma.exam.findUnique({
      where: { id: examId },
      include: {
        problems: {
          orderBy: { orderIndex: 'asc' },
          include: {
            problem: {
              select: {
                id: true,
                title: true,
                description: true,
                type: true,
                referenceSolution: true,
                templateCode: true,
                rubricConfig: true,
                timeLimitMs: true,
                questions: { orderBy: { orderIndex: 'asc' } },
                testCases: { select: { id: true, inputData: true, expectedOutput: true, isPublic: true } }
              }
            }
          }
        },
        assignments: {
          include: {
            student: { select: { id: true, studentId: true, firstName: true, lastName: true, group: true } }
          },
          orderBy: { student: { lastName: 'asc' } }
        }
      }
    }));

    if (!exam) return res.status(404).json({ error: 'Examen non trouvé' });

    // 1. Ensure submissions exist for all assigned students without re-running heavy subprocess tests on GET
    for (const asgn of exam.assignments) {
      for (const ep of exam.problems) {
        const prob = ep.problem;
        const pId = prob.id;
        try {
          const existingSub = await prisma.submission.findFirst({
            where: { examId, studentId: asgn.studentId, problemId: pId }
          });
          if (!existingSub) {
            await evaluateSingleSubmission(examId, asgn.studentId, pId, null, false);
          }
        } catch (err) {
          console.error(`[getExamGradingData] Error ensuring submission student=${asgn.studentId} problem=${pId}:`, err);
        }
      }
    }

    // 2. Fetch all updated submissions for this exam
    const submissions = await prisma.submission.findMany({
      where: { examId },
      orderBy: { createdAt: 'asc' }
    });

    const enrichedProblems = exam.problems.map(ep => {
      const p = ep.problem;
      const refSol = getProblemReferenceSolution(p);
      return {
        ...p,
        points: ep.points || 10,
        weightTest: ep.weightTest ?? 40,
        weightAst: ep.weightAst ?? 60,
        weightAi: ep.weightAi ?? 0,
        questionPoints: ep.questionPoints || {},
        questions: p.questions || [],
        referenceSolution: refSol
      };
    });

    // 3. Attach Canonical Multi-Question Evaluation Breakdown for every submission
    const enrichedSubmissions = [];
    for (let sub of submissions) {
      const epObj = exam.problems.find(ep => ep.problemId === sub.problemId);
      const prob = epObj?.problem;
      if (!prob) {
        enrichedSubmissions.push(sub);
        continue;
      }

      const maxPts = epObj?.points || prob.points || 20;
      const starterTpl = getProblemStarterTemplate(prob);
      const refSol = getProblemReferenceSolution(prob);
      const totalTests = prob.testCases ? prob.testCases.length : (sub.totalTests || 0);
      const passedTests = sub.passedTests || 0;

      const evalData = computeMultiQuestionExerciseScore({
        studentCode: sub.sourceCode,
        starterTemplate: starterTpl,
        referenceSolution: refSol,
        passedTests,
        totalTests,
        problemPoints: maxPts,
        questions: prob.questions || [],
        questionPoints: epObj?.questionPoints || {},
        weightTest: epObj?.weightTest ?? 40,
        weightAst: epObj?.weightAst ?? 60,
        weightAi: epObj?.weightAi ?? 0,
        aiScore: sub.aiScore || 0
      });

      const activeManualScore = sub.manualScore !== null && sub.manualScore !== undefined
        ? roundToNextQuarterPoint(sub.manualScore, maxPts)
        : evalData.calculatedScore;

      enrichedSubmissions.push({
        ...sub,
        manualScore: activeManualScore,
        evaluationBreakdown: {
          ...evalData,
          manualScore: activeManualScore
        }
      });
    }

    // 4. Ensure each assignment has its canonical finalScore updated in DB and strictly mask student identity
    const updatedAssignments = [];
    for (const asgn of exam.assignments) {
      const resCalc = await recalculateStudentAssignmentFinalScore(examId, asgn.studentId);
      const activeAsgn = resCalc ? resCalc.assignment : asgn;
      updatedAssignments.push({
        ...activeAsgn,
        student: {
          id: activeAsgn.studentId,
          studentId: activeAsgn.accessNumber || 'ANO',
          firstName: activeAsgn.accessNumber || 'Anonyme',
          lastName: 'Étudiant',
          group: '***',
          speciality: '***',
          academicYear: activeAsgn.student ? activeAsgn.student.academicYear : 2026
        }
      });
    }

    return res.json({
      exam: {
        id: exam.id,
        title: exam.title,
        status: exam.status,
        durationMinutes: exam.durationMinutes
      },
      problems: enrichedProblems,
      assignments: updatedAssignments,
      submissions: enrichedSubmissions
    });
  } catch (err) {
    console.error('getExamGradingData error:', err);
    return res.status(500).json({ error: 'Erreur lors du chargement des données de correction' });
  }
}

// ── Calculate/Recalculate Single Exercise Score (Server-Side) ─────────────
async function calculateExerciseGrade(req, res) {
  try {
    const { id: examId } = req.params;
    const { studentId, problemId, manualScore, forceRunTests = true } = req.body;

    if (!studentId || !problemId) {
      return res.status(400).json({ error: 'studentId et problemId sont requis.' });
    }

    const enrichedSub = await evaluateSingleSubmission(examId, studentId, problemId, manualScore, forceRunTests);
    const resCalc = await recalculateStudentAssignmentFinalScore(examId, studentId);

    return res.json({
      success: true,
      submission: enrichedSub,
      assignment: resCalc?.assignment,
      totalRawEarned: resCalc?.totalRawEarned,
      scaledScore20: resCalc?.scaledScore20
    });
  } catch (err) {
    console.error('calculateExerciseGrade error:', err);
    return res.status(500).json({ error: err.message || 'Erreur lors du calcul de la note de l\'exercice' });
  }
}

// ── Recalculate ALL Exam Grades (Server-Side) ─────────────────────────────
async function recalculateAllExamGrades(req, res) {
  try {
    const { id: examId } = req.params;

    const exam = await prisma.exam.findUnique({
      where: { id: examId },
      include: {
        problems: { include: { problem: true } },
        assignments: true
      }
    });

    if (!exam) return res.status(404).json({ error: 'Examen non trouvé' });

    for (const asgn of exam.assignments) {
      for (const ep of exam.problems) {
        await evaluateSingleSubmission(examId, asgn.studentId, ep.problemId, null, true);
      }
      await recalculateStudentAssignmentFinalScore(examId, asgn.studentId);
    }

    return res.json({
      success: true,
      message: 'Toutes les notes de cet examen ont été recalculées côté serveur avec succès.'
    });
  } catch (err) {
    console.error('recalculateAllExamGrades error:', err);
    return res.status(500).json({ error: 'Erreur lors du recalcul général des notes' });
  }
}

// ── Save/Update Grade for a Problem Submission ───────────────────────────
async function saveProblemGrade(req, res) {
  try {
    const { id: examId } = req.params;
    const { studentId, problemId, manualScore, teacherFeedback, rubricScores, questionScores } = req.body;

    if (!studentId || !problemId) {
      return res.status(400).json({ error: 'studentId et problemId sont requis' });
    }

    const exam = await prisma.exam.findUnique({
      where: { id: examId },
      include: {
        problems: { include: { problem: { include: { questions: { orderBy: { orderIndex: 'asc' } } } } } }
      }
    });

    if (!exam) return res.status(404).json({ error: 'Examen non trouvé' });

    const epObj = exam.problems.find(ep => ep.problemId === problemId);
    const targetProblem = epObj?.problem;
    if (!targetProblem) return res.status(404).json({ error: 'Problème non trouvé dans cet examen' });

    const maxPts = epObj?.points || targetProblem.points || 20;

    let numericScore = manualScore !== undefined && manualScore !== null ? parseFloat(manualScore) : null;
    
    // Handle per-question manual scores if provided
    if (questionScores && typeof questionScores === 'object') {
      const assignment = await prisma.examAssignment.findUnique({
        where: { examId_studentId: { examId, studentId } }
      });

      const questions = targetProblem.questions || [];
      if (assignment && questions.length > 0) {
        let qTotal = 0;
        for (const q of questions) {
          const rawQVal = parseFloat(questionScores[q.id] ?? questionScores[q.orderIndex]);
          const qMax = (epObj.questionPoints && epObj.questionPoints[q.id]) || Math.max(1, maxPts / questions.length);
          const validQVal = !isNaN(rawQVal) ? Math.min(qMax, Math.max(0, rawQVal)) : 0;
          const roundedQVal = roundToNextQuarterPoint(validQVal, qMax);
          qTotal += roundedQVal;

          if (q.id) {
            await prisma.grade.upsert({
              where: {
                assignmentId_examProblemId_questionId: {
                  assignmentId: assignment.id,
                  examProblemId: epObj.id,
                  questionId: q.id
                }
              },
              create: {
                assignmentId: assignment.id,
                examProblemId: epObj.id,
                questionId: q.id,
                pointsAwarded: roundedQVal
              },
              update: {
                pointsAwarded: roundedQVal
              }
            });
          }
        }
        numericScore = Math.min(maxPts, roundToNextQuarterPoint(qTotal, maxPts));
      }
    }

    if (numericScore !== null && !isNaN(numericScore)) {
      numericScore = Math.min(maxPts, Math.max(0, roundToNextQuarterPoint(numericScore, maxPts)));
    }

    const enrichedSub = await evaluateSingleSubmission(examId, studentId, problemId, numericScore, false);

    if (teacherFeedback !== undefined || rubricScores !== undefined) {
      await prisma.submission.update({
        where: { id: enrichedSub.id },
        data: {
          teacherFeedback: teacherFeedback !== undefined ? teacherFeedback : undefined,
          rubricScores: rubricScores !== undefined ? rubricScores : undefined,
          gradedAt: new Date(),
          gradedBy: req.user?.id || 'TEACHER'
        }
      });
      enrichedSub.teacherFeedback = teacherFeedback;
      enrichedSub.rubricScores = rubricScores;
    }

    const resCalc = await recalculateStudentAssignmentFinalScore(examId, studentId);

    return res.json({
      success: true,
      submission: enrichedSub,
      assignment: resCalc?.assignment,
      totalRawEarned: resCalc?.totalRawEarned,
      scaledScore20: resCalc?.scaledScore20
    });
  } catch (err) {
    console.error('saveProblemGrade error:', err);
    return res.status(500).json({ error: 'Erreur lors de l\'enregistrement de la note' });
  }
}

// ── Update General Feedback / Finalize Student Grading ─────────────────────
async function updateGeneralFeedback(req, res) {
  try {
    const { id: examId } = req.params;
    const { studentId, generalFeedback, gradingStatus } = req.body;

    if (!studentId) {
      return res.status(400).json({ error: 'studentId est requis.' });
    }

    const resCalc = await recalculateStudentAssignmentFinalScore(examId, studentId);
    const finalScore20 = resCalc?.scaledScore20 ?? 0;

    const assignment = await prisma.examAssignment.update({
      where: { examId_studentId: { examId, studentId } },
      data: {
        generalFeedback: generalFeedback || '',
        gradingStatus: gradingStatus || 'GRADED',
        finalScore: finalScore20
      },
      include: {
        student: { select: { id: true, studentId: true, firstName: true, lastName: true, group: true } }
      }
    });

    return res.json({ success: true, assignment, totalRawEarned: resCalc?.totalRawEarned });
  } catch (err) {
    console.error('updateGeneralFeedback error:', err);
    return res.status(500).json({ error: 'Erreur lors de la mise à jour des remarques' });
  }
}

// ── Analyze Submission Syntax ────────────────────────────────────────────
async function analyzeSubmission(req, res) {
  try {
    const { code } = req.body;
    const analysis = analyzeAlgorithmicSyntax(code);
    return res.json(analysis);
  } catch (err) {
    return res.status(500).json({ error: 'Erreur d\'analyse syntaxique' });
  }
}

// ── Teacher Sandbox Code Runner ──────────────────────────────────────────
async function runTeacherSandboxCode(req, res) {
  try {
    const { sourceCode, language, inputData } = req.body;
    if (!sourceCode) {
      return res.status(400).json({ error: 'sourceCode est requis.' });
    }
    const result = await runCodeSingle(sourceCode, language || 'ALGO', inputData || '', 3000);
    return res.json(result);
  } catch (err) {
    console.error('runTeacherSandboxCode error:', err);
    return res.status(500).json({ error: 'Erreur lors de l execution du code.' });
  }
}

// ── Reset Exam Scores Controller ──────────────────────────────────────────
async function resetExamScores(req, res) {
  try {
    const { id: examId } = req.params;

    const subRes = await prisma.submission.updateMany({
      where: { examId },
      data: {
        score: 0,
        manualScore: null,
        passedTests: 0,
        status: 'PENDING_MANUAL',
        gradedAt: null,
        gradedBy: null,
        teacherFeedback: null,
        rubricScores: null
      }
    });

    const asgnRes = await prisma.examAssignment.updateMany({
      where: { examId },
      data: {
        finalScore: null,
        gradingStatus: 'UNGRADED',
        generalFeedback: null
      }
    });

    // Reopen exam status to FINISHED if it was CLOSED (unseal correction)
    const currentExam = await prisma.exam.findUnique({
      where: { id: examId },
      select: { status: true }
    });

    if (currentExam && currentExam.status === 'CLOSED') {
      await prisma.exam.update({
        where: { id: examId },
        data: { status: 'FINISHED' }
      });
    }

    const io = req.io || req.app?.get('io');
    if (io) {
      io.to(`exam_${examId}`).emit('scores_reset', { examId });
      io.emit('exam_status_changed', { examId, status: 'FINISHED' });
    }

    return res.json({
      message: 'Toutes les notes de cet examen ont été réinitialisées avec succès.',
      submissionsReset: subRes.count,
      assignmentsReset: asgnRes.count
    });
  } catch (err) {
    console.error('resetExamScores error:', err);
    return res.status(500).json({ error: 'Erreur lors de la réinitialisation des notes.' });
  }
}

// ── PDF Export Controllers ──────────────────────────────────────────────────
const {
  generateStudentCopyPDFData,
  verifyQRPayload
} = require('../services/pdf.service');

// Single student PDF
async function downloadStudentCopyPDF(req, res) {
  try {
    const { id: examId, studentId } = req.params;

    const exam = await withRetry(() => prisma.exam.findUnique({
      where: { id: examId },
      include: {
        problems: { orderBy: { orderIndex: 'asc' }, include: { problem: true } }
      }
    }));

    if (!exam) return res.status(404).json({ error: 'Examen non trouve' });

    const assignment = await withRetry(() => prisma.examAssignment.findUnique({
      where: { examId_studentId: { examId, studentId } },
      include: { student: true }
    }));

    if (!assignment) return res.status(404).json({ error: 'Session etudiant non trouvee' });

    const submissions = await withRetry(() => prisma.submission.findMany({
      where: { examId, studentId }
    }));

    const pdfBuffer = await generateStudentCopyPDFData({
      exam,
      assignment,
      student: assignment.student,
      problems: exam.problems,
      submissions
    });

    const isExamClosed = exam.status === 'CLOSED';
    const safeFileName = isExamClosed
      ? ('Copie_' + ((assignment.student && assignment.student.lastName) || 'Etudiant').replace(/[^\w]/g, '_') + '.pdf')
      : ('Copie_Anonyme_' + (assignment.accessNumber || 'N_A') + '.pdf');

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline; filename=' + safeFileName);
    return res.send(pdfBuffer);
  } catch (err) {
    console.error('downloadStudentCopyPDF error:', err);
    return res.status(500).json({ error: 'Erreur lors de la generation du PDF.' });
  }
}

// All students ZIP export with Socket.IO progress events
async function downloadAllStudentCopiesPDF(req, res) {
  try {
    const { id: examId } = req.params;
    const io = req.io;

    const exam = await withRetry(() => prisma.exam.findUnique({
      where: { id: examId },
      include: {
        problems: { orderBy: { orderIndex: 'asc' }, include: { problem: true } },
        assignments: { include: { student: true }, orderBy: { student: { lastName: 'asc' } } }
      }
    }));

    if (!exam) return res.status(404).json({ error: 'Examen non trouve' });

    const submissions = await withRetry(() => prisma.submission.findMany({ where: { examId } }));

    const validAssignments = exam.assignments.filter(a => a.student);
    const total = validAssignments.length;

    const progressRoom = 'exam_' + examId;
    if (io) io.to(progressRoom).emit('pdf_zip_progress', { done: 0, total, status: 'start' });

    const safeTitle = exam.title.replace(/[^\w]/g, '_').substring(0, 60);
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename=Copies_' + safeTitle + '.zip');

    const archive = archiver('zip', { zlib: { level: 6 } });
    archive.on('error', err => { throw err; });
    archive.pipe(res);

    const isExamClosed = exam.status === 'CLOSED';
    for (let i = 0; i < validAssignments.length; i++) {
      const assignment = validAssignments[i];
      const student = assignment.student;
      const studentSubmissions = submissions.filter(s => s.studentId === student.id);

      const pdfBuffer = await generateStudentCopyPDFData({
        exam, assignment, student,
        problems: exam.problems,
        submissions: studentSubmissions
      });

      const safeName = isExamClosed
        ? ((student.lastName || 'ETUDIANT').replace(/[^\w]/g, '_') + '_' + (student.firstName || '').replace(/[^\w]/g, '_')).substring(0, 60)
        : `Anonyme_${assignment.accessNumber || (i + 1)}`;
      const fileName = isExamClosed
        ? ('Copie_' + String(i + 1).padStart(2, '0') + '_' + safeName + '.pdf')
        : ('Copie_Anonyme_' + String(i + 1).padStart(2, '0') + '_' + safeName + '.pdf');
      archive.append(pdfBuffer, { name: fileName });

      const displayName = isExamClosed
        ? (student.lastName + ' ' + student.firstName)
        : `Anonyme [${assignment.accessNumber || `Copie ${i + 1}`}]`;

      if (io) io.to(progressRoom).emit('pdf_zip_progress', {
        done: i + 1, total,
        studentName: displayName,
        status: 'progress'
      });
    }

    await archive.finalize();
    if (io) io.to(progressRoom).emit('pdf_zip_progress', { done: total, total, status: 'done' });
  } catch (err) {
    console.error('downloadAllStudentCopiesPDF error:', err);
    if (!res.headersSent) {
      return res.status(500).json({ error: 'Erreur lors de la generation du ZIP.' });
    }
  }
}

// Auto-grade all student copies in an exam
async function autoGradeExam(req, res) {
  try {
    const { id: examId } = req.params;

    const exam = await prisma.exam.findUnique({
      where: { id: examId },
      include: {
        problems: { orderBy: { orderIndex: 'asc' }, include: { problem: { include: { testCases: true } } } },
        assignments: { include: { student: true } }
      }
    });

    if (!exam) return res.status(404).json({ error: 'Examen non trouvé' });

    if (exam.status === 'CLOSED') {
      return res.status(400).json({ error: "Cet examen est déjà clôturé et finalisé. La correction automatique n'est pas autorisée sur un examen terminé." });
    }

    const io = req.io || req.app?.get('io');
    const totalStudents = exam.assignments.length;
    const progressRoom = 'exam_' + examId;
    let gradedCount = 0;

    if (io) {
      const startPayload = { done: 0, total: totalStudents, pct: 0, status: 'start' };
      io.to(progressRoom).emit('auto_grade_progress', startPayload);
      io.emit('auto_grade_progress', startPayload);
    }

    for (const asgn of exam.assignments) {
      const studentName = `Anonyme [${asgn.accessNumber || `Copie ${gradedCount + 1}`}]`;

      if (io) {
        const stepPayload = {
          done: gradedCount,
          total: totalStudents,
          pct: totalStudents > 0 ? Math.round((gradedCount / totalStudents) * 100) : 0,
          studentName,
          status: 'progress'
        };
        io.to(progressRoom).emit('auto_grade_progress', stepPayload);
        io.emit('auto_grade_progress', stepPayload);
      }

      for (const ep of exam.problems) {
        await evaluateSingleSubmission(examId, asgn.studentId, ep.problemId, null, true);
      }

      await recalculateStudentAssignmentFinalScore(examId, asgn.studentId);
      gradedCount++;

      if (io) {
        const payload = {
          done: gradedCount,
          total: totalStudents,
          pct: Math.round((gradedCount / totalStudents) * 100),
          studentName,
          status: 'progress'
        };
        io.to(progressRoom).emit('auto_grade_progress', payload);
        io.emit('auto_grade_progress', payload);
      }

      await new Promise(resolve => setTimeout(resolve, 80));
    }

    if (io) {
      const donePayload = { done: gradedCount, total: totalStudents, pct: 100, status: 'done' };
      io.to(progressRoom).emit('auto_grade_progress', donePayload);
      io.emit('auto_grade_progress', donePayload);
    }

    return res.json({ success: true, gradedCount, message: `Correction automatique effectuée pour ${gradedCount} étudiants.` });
  } catch (err) {
    console.error('autoGradeExam error:', err);
    return res.status(500).json({ error: 'Erreur lors de la correction automatique.' });
  }
}

// ── Finalize Exam Correction (Lock grading & unlock De-anonymized Results) ──
async function finalizeExamCorrection(req, res) {
  try {
    const { id: examId } = req.params;

    const exam = await prisma.exam.findUnique({
      where: { id: examId },
      include: { assignments: true }
    });

    if (!exam) return res.status(404).json({ error: 'Examen non trouvé' });

    // Verify that ALL assignments are GRADED before allowing finalization
    const uncorrectedAssignments = (exam.assignments || []).filter(a => a.gradingStatus !== 'GRADED');
    if (uncorrectedAssignments.length > 0) {
      return res.status(400).json({
        error: `Impossible de clôturer la correction : il reste ${uncorrectedAssignments.length} copie(s) non validée(s). Vous devez valider l'ensemble des copies avant de terminer la correction.`
      });
    }

    // Recalculate final scores for all students
    for (const asgn of exam.assignments) {
      await recalculateStudentAssignmentFinalScore(examId, asgn.studentId, 'GRADED');
    }

    // Mark exam as CLOSED (fully corrected and finalized)
    const updatedExam = await prisma.exam.update({
      where: { id: examId },
      data: { status: 'CLOSED' }
    });

    // Mark all assignments as GRADED
    await prisma.examAssignment.updateMany({
      where: { examId },
      data: { gradingStatus: 'GRADED' }
    });

    const io = req.io || req.app?.get('io');
    if (io) {
      io.to(`exam_${examId}`).emit('correction_finalized', { examId });
      io.emit('exam_status_changed', { examId, status: 'CLOSED' });
    }

    return res.json({
      success: true,
      message: 'Correction clôturée avec succès. Les résultats dé-anonymisés sont maintenant disponibles.',
      exam: updatedExam
    });
  } catch (err) {
    console.error('finalizeExamCorrection error:', err);
    return res.status(500).json({ error: 'Erreur lors de la clôture de la correction' });
  }
}

// QR Code Authenticity Verification
async function verifyQRAuthenticity(req, res) {
  try {
    const { qrPayload } = req.body;
    if (!qrPayload) return res.status(400).json({ error: 'qrPayload est requis' });
    const result = verifyQRPayload(qrPayload);
    return res.json(result);
  } catch (err) {
    return res.status(500).json({ error: 'Erreur lors de la verification du QR Code' });
  }
}

module.exports = {
  getExamGradingData,
  saveProblemGrade,
  calculateExerciseGrade,
  recalculateAllExamGrades,
  updateGeneralFeedback,
  analyzeSubmission,
  runTeacherSandboxCode,
  autoGradeExam,
  resetExamScores,
  downloadStudentCopyPDF,
  downloadAllStudentCopiesPDF,
  verifyQRAuthenticity,
  finalizeExamCorrection
};
