import React, { useEffect, useState, useRef } from 'react';
import { getSocket, joinExamRoom, sendStudentViolation } from '../services/socket';
import { getStudentWorkspace } from '../services/api';
import { LogOut, Radio, FileText, Maximize, Play } from 'lucide-react';

export default function WaitingRoom({ studentData, onExamStarted, onLogout }) {
  const { student, exam } = studentData;
  const [examStatus, setExamStatus] = useState(exam.status);
  const [isFullscreen, setIsFullscreen] = useState(!!(document.fullscreenElement || document.webkitFullscreenElement));
  const isStartedRef = useRef(false);

  useEffect(() => {
    const handleFsChange = () => {
      const inFs = !!(document.fullscreenElement || document.webkitFullscreenElement);
      setIsFullscreen(inFs);
      if (!inFs) {
        sendStudentViolation(exam.id, student.id, 'FULLSCREEN_EXIT', 'MEDIUM', null, { context: 'WAITING_ROOM' });
      } else {
        sendStudentViolation(exam.id, student.id, 'FULLSCREEN_RETURN', 'LOW', null, { context: 'WAITING_ROOM' });
      }
    };

    document.addEventListener('fullscreenchange', handleFsChange);
    document.addEventListener('webkitfullscreenchange', handleFsChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFsChange);
      document.removeEventListener('webkitfullscreenchange', handleFsChange);
    };
  }, [exam.id, student.id]);

  useEffect(() => {
    // Join exam socket room for live launch signal
    joinExamRoom(exam.id, student.id, false);

    const socket = getSocket();

    const triggerExamLaunch = () => {
      if (isStartedRef.current) return;
      isStartedRef.current = true;
      setExamStatus('RUNNING');
      onExamStarted();
    };

    const handleExamStarted = () => {
      console.log('Exam started event received!');
      triggerExamLaunch();
    };

    const handleStatusChanged = ({ status }) => {
      setExamStatus(status);
      if (status === 'RUNNING') {
        triggerExamLaunch();
      } else if (['FINISHED', 'CLOSED'].includes(status)) {
        onLogout();
      }
    };

    const handleForceEnded = () => {
      onLogout();
    };

    const handleTerminated = () => {
      onLogout();
    };

    const handleConnect = () => {
      // Re-join room on socket reconnect
      joinExamRoom(exam.id, student.id, false);
    };

    socket.on('exam_started',          handleExamStarted);
    socket.on('exam_status_changed',    handleStatusChanged);
    socket.on('exam_force_ended',       handleForceEnded);
    socket.on('student_terminated',     handleTerminated);
    socket.on('connect',                handleConnect);

    // Fast polling fallback (every 3s) in case socket message is dropped
    const pollInterval = setInterval(async () => {
      try {
        const data = await getStudentWorkspace();
        if (data?.exam?.status === 'RUNNING') {
          triggerExamLaunch();
        } else if (['FINISHED', 'CLOSED'].includes(data?.exam?.status) || ['FINISHED', 'KICKED_OUT'].includes(data?.assignmentStatus)) {
          onLogout();
        }
      } catch (err) {
        if (err.data?.error === 'EXAM_ALREADY_FINISHED' || err.data?.error === 'STUDENT_KICKED_OUT') {
          onLogout();
        }
      }
    }, 3000);

    return () => {
      clearInterval(pollInterval);
      socket.off('exam_started',          handleExamStarted);
      socket.off('exam_status_changed',    handleStatusChanged);
      socket.off('exam_force_ended',       handleForceEnded);
      socket.off('student_terminated',     handleTerminated);
      socket.off('connect',                handleConnect);
    };
  }, [exam.id, student.id, onExamStarted, onLogout]);

  const requestFullscreen = () => {
    const element = document.documentElement;
    if (element.requestFullscreen) {
      element.requestFullscreen().catch(() => {});
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', background: 'var(--bg-color)', position: 'relative' }}>
      {/* Fullscreen Overlay Gate in Waiting Room */}
      {!isFullscreen && (
        <div className="fullscreen-overlay">
          <div className="fullscreen-box">
            <div className="warning-icon">🔒</div>
            <h2>Mode Plein Écran Exigé</h2>
            <p style={{ color: 'var(--text-muted)', margin: '15px 0' }}>
              Pour être prêt à démarrer l’épreuve, vous devez rester en mode plein écran dans la salle d’attente.
            </p>
            <button className="btn btn-primary" onClick={requestFullscreen} style={{ width: '100%', padding: '12px' }}>
              <Maximize size={18} /> Activer le Mode Plein Écran
            </button>
          </div>
        </div>
      )}

      <div className="glass-panel" style={{ width: '100%', maxWidth: '580px', padding: '40px', textAlign: 'center' }}>
        {/* Animated Radio / Radar Icon */}
        <div style={{ width: '84px', height: '84px', borderRadius: '50%', background: 'rgba(59, 130, 246, 0.15)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: '20px', border: '1px solid rgba(59, 130, 246, 0.3)', position: 'relative' }}>
          <Radio size={40} color="#60a5fa" style={{ animation: 'pulse 1.5s infinite alternate' }} />
        </div>

        <h2 style={{ fontSize: '1.7rem', marginBottom: '8px' }}>Salle d’Attente Pré-Examen</h2>

        {examStatus === 'RUNNING' ? (
          <div style={{ marginBottom: '20px' }}>
            <p style={{ color: '#34d399', fontWeight: '700', fontSize: '1.1rem', marginBottom: '15px' }}>
              ⚡ L'enseignant a lancé l'épreuve !
            </p>
            <button className="btn btn-success" onClick={onExamStarted} style={{ width: '100%', padding: '14px', fontSize: '1.1rem' }}>
              <Play size={20} /> Entrer en Salle d’Examen
            </button>
          </div>
        ) : (
          <p style={{ color: '#34d399', fontWeight: '600', fontSize: '1rem', marginBottom: '25px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#34d399', display: 'inline-block', animation: 'pulse 1s infinite' }}></span>
            En attente du lancement par l’enseignant...
          </p>
        )}

        {/* Exam Summary Info */}
        <div style={{ background: 'rgba(0,0,0,0.3)', padding: '20px', borderRadius: '12px', textAlign: 'left', marginBottom: '25px', border: '1px solid var(--panel-border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
            <FileText color="#60a5fa" size={20} />
            <h3 style={{ fontSize: '1.2rem' }}>{exam.title}</h3>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', fontSize: '0.88rem', color: 'var(--text-muted)' }}>
            <div>Étudiant: <strong style={{ color: '#ffffff' }}>{student.firstName} {student.lastName}</strong></div>
            <div>Groupe: <strong style={{ color: '#ffffff' }}>{student.group}</strong></div>
            <div>N° Accès: <code style={{ color: '#34d399', fontFamily: 'var(--font-mono)' }}>{student.accessNumber}</code></div>
            <div>Durée de l'Épreuve: <strong style={{ color: '#60a5fa' }}>{exam.durationMinutes} min</strong></div>
          </div>
        </div>

        <div style={{ padding: '12px', background: 'rgba(255, 255, 255, 0.05)', borderRadius: '8px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '25px' }}>
          💡 Maintenez le mode plein écran. Votre épreuve s'ouvrira dès que l'enseignant aura validé le départ.
        </div>

        <button className="btn btn-secondary" onClick={onLogout} style={{ width: '100%', padding: '12px' }}>
          <LogOut size={16} /> Déconnexion
        </button>
      </div>
    </div>
  );
}
