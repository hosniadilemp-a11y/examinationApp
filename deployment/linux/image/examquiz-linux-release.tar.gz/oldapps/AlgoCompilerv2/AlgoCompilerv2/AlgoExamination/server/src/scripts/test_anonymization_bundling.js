const {
  encryptData,
  decryptData,
  BUNDLE_MAGIC,
  RESULTS_MAGIC
} = require('../services/bundle-crypto.service');

async function runTests() {
  console.log('🧪 Starting Anonymization & Multi-Room Bundling Verification Suite...\n');

  // Test 1: AES-256-GCM Encryption / Decryption with Passphrase
  console.log('--- Test 1: AES-256-GCM Bundle Crypto Roundtrip ---');
  const sampleBundle = {
    bundleType: 'SUBMISSION_BUNDLE',
    examId: 'exam-test-123',
    submissions: [
      {
        studentId: 'st-01',
        accessNumber: 'AL-001',
        problemId: 'prob-1',
        sourceCode: 'Algorithme Test1;\nDebut\n  Ecrire("Hello");\nFin.',
        createdAt: '2026-08-31T08:00:00.000Z'
      }
    ]
  };

  const passphrase = 'MyExamSecurePassphrase2026!';
  const encryptedEnvelope = encryptData(sampleBundle, passphrase, BUNDLE_MAGIC);
  console.log('✔ Encrypted Envelope Magic:', encryptedEnvelope.magic);
  console.log('✔ Salt (hex):', encryptedEnvelope.salt);
  console.log('✔ AuthTag (hex):', encryptedEnvelope.authTag);
  console.log('✔ Checksum (SHA-256):', encryptedEnvelope.checksum);

  const decryptedBundle = decryptData(encryptedEnvelope, passphrase);
  console.log('✔ Decrypted Bundle Match:', JSON.stringify(decryptedBundle) === JSON.stringify(sampleBundle));

  // Test 2: Tamper Resistance
  console.log('\n--- Test 2: Cryptographic Tampering Rejection ---');
  let tamperedEnvelope = { ...encryptedEnvelope, ciphertext: encryptedEnvelope.ciphertext.slice(0, -4) + 'AAAA' };
  try {
    decryptData(tamperedEnvelope, passphrase);
    console.error('❌ Failed: Tampered envelope was accepted!');
  } catch (err) {
    console.log('✔ Correctly rejected tampered payload:', err.message);
  }

  // Test 3: Wrong Passphrase Rejection
  console.log('\n--- Test 3: Wrong Passphrase Rejection ---');
  try {
    decryptData(encryptedEnvelope, 'WrongPassword123');
    console.error('❌ Failed: Wrong password was accepted!');
  } catch (err) {
    console.log('✔ Correctly rejected wrong passphrase:', err.message);
  }

  // Test 4: Multi-Room Deduplication and Conflict Resolution Logic Simulation
  console.log('\n--- Test 4: Multi-Room Merging & Conflict Resolution (Latest Timestamp Wins) ---');
  const room1Bundle = {
    bundleType: 'SUBMISSION_BUNDLE',
    assignments: [
      { accessNumber: 'AL-001', student: { studentId: '2026001', lastName: 'BENALI', firstName: 'Adel' } },
      { accessNumber: 'AL-002', student: { studentId: '2026002', lastName: 'KHELIFI', firstName: 'Sara' } }
    ],
    submissions: [
      {
        accessNumber: 'AL-001',
        problemId: 'P1',
        sourceCode: '// Room 1 version (Early)\nAlgorithme R1;\nDebut\nFin.',
        createdAt: '2026-08-31T09:00:00.000Z'
      }
    ]
  };

  const room2Bundle = {
    bundleType: 'SUBMISSION_BUNDLE',
    assignments: [
      { accessNumber: 'AL-001', student: { studentId: '2026001', lastName: 'BENALI', firstName: 'Adel' } },
      { accessNumber: 'AL-003', student: { studentId: '2026003', lastName: 'MEZIANE', firstName: 'Karim' } }
    ],
    submissions: [
      {
        accessNumber: 'AL-001',
        problemId: 'P1',
        sourceCode: '// Room 2 version (Later final submit)\nAlgorithme R2_Final;\nDebut\nFin.',
        createdAt: '2026-08-31T09:30:00.000Z'
      },
      {
        accessNumber: 'AL-003',
        problemId: 'P1',
        sourceCode: '// Karim submission\nAlgorithme R2_Karim;\nDebut\nFin.',
        createdAt: '2026-08-31T09:15:00.000Z'
      }
    ]
  };

  // Simulate in-memory merge logic
  const mergedMap = new Map();
  const allSubmissions = [...room1Bundle.submissions, ...room2Bundle.submissions];

  for (const sub of allSubmissions) {
    const key = `${sub.accessNumber}_${sub.problemId}`;
    const existing = mergedMap.get(key);
    if (!existing || new Date(sub.createdAt) >= new Date(existing.createdAt)) {
      mergedMap.set(key, sub);
    }
  }

  const mergedList = Array.from(mergedMap.values());
  console.log('✔ Total Merged Submissions Count:', mergedList.length, '(Expected 2: AL-001 and AL-003)');
  const al001Winner = mergedMap.get('AL-001_P1');
  console.log('✔ AL-001 Resolved Winner Code:', al001Winner.sourceCode.includes('R2_Final') ? 'R2_Final (Latest Timestamp Wins)' : 'Error');

  console.log('\n🎉 ALL VERIFICATION SUITE CHECKS PASSED SUCCESSFULLY!\n');
}

runTests().catch(console.error);
