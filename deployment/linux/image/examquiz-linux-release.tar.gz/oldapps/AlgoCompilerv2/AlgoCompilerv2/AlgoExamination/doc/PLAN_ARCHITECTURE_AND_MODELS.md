# Plan 1 : Architecture Système & Modélisation des Données (Multi-Question & Weighted AST)

**Document de référence :** `extensions.txt`  
**Conformité :** `04_LLM_PROMPT_GUIDELINES.md` & `05_DATABASE_DESIGN_RULES.md`

---

## 1. Vue d'Ensemble Architecturale

Cette extension introduit le support natif des **problèmes algorithmiques multi-questions / multi-fonctions**, avec :
1. Découpage d'un problème en sous-questions (`ProblemQuestion`).
2. Zones de code balisées et verrouillées côté étudiant (`// question N starts here` ... `// question N ends here`).
3. Barème indépendant par sous-question dans l'épreuve (`ExamProblem`).
4. Configuration pondérée tripartite (**Tests 40% / AST 60% / IA 0%** par défaut).
5. Évaluation AST par découpage ciblé (AST Slicing) sans impacter le code hors zone.

```mermaid
graph TD
    Exam[Exam] --> ExamProblem[ExamProblem: Points, weightTest 40%, weightAst 60%, weightAi 0%]
    Problem[Problem: Titre, Sujet Général] --> ProblemQuestion1[ProblemQuestion 1: orderIndex 1, statement]
    Problem[Problem] --> ProblemQuestion2[ProblemQuestion 2: orderIndex 2, statement]
    ExamProblem --> Problem
    
    StudentCode[Code Étudiant Soumis] --> MarkerParser[Découpeur de Marqueurs de Questions]
    MarkerParser --> SliceQ1[Zone Question 1]
    MarkerParser --> SliceQ2[Zone Question 2]
    
    SliceQ1 --> AST1[AST Generator & Similarity Q1]
    SliceQ2 --> AST2[AST Generator & Similarity Q2]
    
    AST1 --> GradeQ1[Grade: Q1 AST + Tests + IA]
    AST2 --> GradeQ2[Grade: Q2 AST + Tests + IA]
    
    GradeQ1 --> FinalProblemScore[Score Final Problème / Points]
    GradeQ2 --> FinalProblemScore
```

---

## 2. Évolution du Schéma Prisma (`schema.prisma`)

### A. Nouvelle Entité `ProblemQuestion`
```prisma
model ProblemQuestion {
  id          String   @id @default(uuid())
  problemId   String
  problem     Problem  @relation(fields: [problemId], references: [id], onDelete: Cascade)
  orderIndex  Int
  statement   String   // Markdown spécifique à la sous-question
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  grades      Grade[]

  @@unique([problemId, orderIndex])
  @@schema("exam")
}
```

### B. Extension de `ExamProblem` (Pondérations & Barème par Question)
```prisma
model ExamProblem {
  id              String   @id @default(uuid())
  examId          String
  problemId       String
  orderIndex      Int      @default(0)
  points          Float    @default(10)
  
  // NOUVEAU: Pondérations des 3 modules (Somme = 100%)
  weightTest      Int      @default(40)  // %
  weightAst       Int      @default(60)  // %
  weightAi        Int      @default(0)   // %
  
  // NOUVEAU: Répartition des points par question en JSON ex: { "q1_id": 4, "q2_id": 6 }
  questionPoints  Json?    @default("{}")

  exam            Exam     @relation(fields: [examId], references: [id], onDelete: Cascade)
  problem         Problem  @relation(fields: [problemId], references: [id], onDelete: Cascade)
  grades          Grade[]

  @@unique([examId, problemId])
  @@schema("exam")
}
```

### C. Extension de `Grade` (Traçabilité par Sous-Question)
```prisma
model Grade {
  id              String           @id @default(uuid())
  assignmentId    String
  examProblemId   String
  questionId      String?          // Nullable pour rétrocompatibilité historique
  testScore       Float?
  astScore        Float?
  aiScore         Float?
  pointsAwarded   Float?
  feedback        String?
  correctedCode   String?
  createdAt       DateTime         @default(now())
  updatedAt       DateTime         @updatedAt

  assignment      ExamAssignment   @relation(fields: [assignmentId], references: [id], onDelete: Cascade)
  examProblem     ExamProblem      @relation(fields: [examProblemId], references: [id], onDelete: Cascade)
  question        ProblemQuestion? @relation(fields: [questionId], references: [id], onDelete: SetNull)

  @@unique([assignmentId, examProblemId, questionId])
  @@schema("exam")
}
```

---

## 3. Stratégie de Rétrocompatibilité & Backfill Idempotent

1. **Règle d'or :** Tout problème existant sans sous-question recevra automatiquement exactement **une** ligne `ProblemQuestion` (`orderIndex: 1`, `statement = problem.description`).
2. **Script de Migration Idempotent :**
   ```javascript
   // Vérifie l'existence avant insertion pour ne jamais dupliquer
   const existing = await prisma.problemQuestion.findFirst({ where: { problemId: p.id } });
   if (!existing) {
     await prisma.problemQuestion.create({
       data: {
         problemId: p.id,
         orderIndex: 1,
         statement: p.description || p.title
       }
     });
   }
   ```
3. `Problem.description` reste le texte d'introduction global du problème affiché au-dessus des sous-questions.
