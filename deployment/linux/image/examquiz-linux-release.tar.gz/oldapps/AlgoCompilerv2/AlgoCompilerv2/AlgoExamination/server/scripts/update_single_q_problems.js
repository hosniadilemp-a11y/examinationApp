const prisma = require('../src/prisma');
const { runCodeSingle } = require('../src/runner/code-execution.service');

// Map of algorithmic problems to update with clean reference solutions and clean test inputs
const ALGO_PROBLEMS_UPDATES = {
  // 1. Somme de Deux Entiers
  'de0708a0-8d52-4e0b-b6a3-1bf79798a322': {
    title: 'Somme de Deux Entiers',
    refSol: `// question 1 commence ici
Algorithme SommeDeuxEntiers;
Var
    a, b, s : Entier;
Debut
    Lire(a);
    Lire(b);
    s := a + b;
    Ecrire(s);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme SommeDeuxEntiers;
Var
    a, b, s : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n10', isPub: true },
      { in: '0\n7', isPub: true },
      { in: '-5\n15', isPub: false },
      { in: '-10\n-20', isPub: false },
      { in: '100\n250', isPub: false },
      { in: '42\n0', isPub: false },
      { in: '-99\n99', isPub: false },
      { in: '1000\n2000', isPub: false },
      { in: '1\n1', isPub: false },
      { in: '-1\n1', isPub: false },
      { in: '123\n456', isPub: false },
      { in: '-50\n-50', isPub: false }
    ]
  },

  // 2. Echange Valeurs
  '008a1df9-95a9-413d-8dcb-d68f7cb77dcb': {
    title: 'Echange Valeurs',
    refSol: `// question 1 commence ici
Algorithme EchangeValeurs;
Var
    a, b, temp : Entier;
Debut
    Lire(a);
    Lire(b);
    temp := a;
    a := b;
    b := temp;
    Ecrire(a, " ", b);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme EchangeValeurs;
Var
    a, b, temp : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n4', isPub: true },
      { in: '10\n99', isPub: true },
      { in: '0\n1', isPub: false },
      { in: '-5\n15', isPub: false },
      { in: '7\n7', isPub: false },
      { in: '-100\n-200', isPub: false },
      { in: '42\n0', isPub: false },
      { in: '12\n34', isPub: false },
      { in: '1\n-1', isPub: false },
      { in: '999\n111', isPub: false },
      { in: '8\n2', isPub: false },
      { in: '-50\n50', isPub: false }
    ]
  },

  // 3. Echange Valeurs Pointeurs
  'da90b1aa-4f78-458f-99f7-8a15e0707a02': {
    title: 'Echange Valeurs Pointeurs',
    refSol: `// question 1 commence ici
Algorithme EchangeValeursPointeurs;
Var
    a, b : Entier;
    p1, p2 : ^Entier;
    temp : Entier;
Debut
    Lire(a);
    Lire(b);
    p1 := &a;
    p2 := &b;
    temp := p1^;
    p1^ := p2^;
    p2^ := temp;
    Ecrire(a, " ", b);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme EchangeValeursPointeurs;
Var
    a, b : Entier;
    p1, p2 : ^Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n4', isPub: true },
      { in: '10\n99', isPub: true },
      { in: '0\n1', isPub: false },
      { in: '-5\n15', isPub: false },
      { in: '7\n7', isPub: false },
      { in: '-100\n-200', isPub: false },
      { in: '42\n0', isPub: false },
      { in: '12\n34', isPub: false },
      { in: '1\n-1', isPub: false },
      { in: '999\n111', isPub: false },
      { in: '8\n2', isPub: false },
      { in: '-50\n50', isPub: false }
    ]
  },

  // 4. Calcul de la Factorielle
  'f5cb36d2-e7c0-4d9c-b8d8-351ec505bd79': {
    title: 'Calcul de la Factorielle',
    refSol: `// question 1 commence ici
Algorithme Factorielle;
Var
    n, i, fact : Entier;
Debut
    Lire(n);
    fact := 1;
    Pour i := 1 a n Faire
        fact := fact * i;
    FinPour;
    Ecrire(fact);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme Factorielle;
Var
    n, i, fact : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5', isPub: true },
      { in: '0', isPub: true },
      { in: '1', isPub: false },
      { in: '2', isPub: false },
      { in: '3', isPub: false },
      { in: '4', isPub: false },
      { in: '6', isPub: false },
      { in: '7', isPub: false },
      { in: '8', isPub: false },
      { in: '9', isPub: false },
      { in: '10', isPub: false },
      { in: '12', isPub: false }
    ]
  },

  // 5. Factorielle (Second problem)
  '4baec747-5ddb-478a-82e1-50b443e19723': {
    title: 'Factorielle',
    refSol: `// question 1 commence ici
Algorithme Factorielle;
Var
    n, i, fact : Entier;
Debut
    Lire(n);
    fact := 1;
    Pour i := 1 a n Faire
        fact := fact * i;
    FinPour;
    Ecrire(fact);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme Factorielle;
Var
    n, i, fact : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5', isPub: true },
      { in: '0', isPub: true },
      { in: '1', isPub: false },
      { in: '2', isPub: false },
      { in: '3', isPub: false },
      { in: '4', isPub: false },
      { in: '6', isPub: false },
      { in: '7', isPub: false },
      { in: '8', isPub: false },
      { in: '9', isPub: false },
      { in: '10', isPub: false },
      { in: '12', isPub: false }
    ]
  },

  // 6. Factorielle Recursive
  '58abb5ba-4da1-441a-9e1e-c175b9cfe542': {
    title: 'Factorielle Recursive',
    refSol: `// question 1 commence ici
Algorithme FactorielleRecursive;
Fonction Fact(n : Entier) : Entier;
Debut
    Si n <= 1 Alors
        Retourner 1;
    Sinon
        Retourner n * Fact(n - 1);
    FinSi;
Fin;
Var
    n : Entier;
Debut
    Lire(n);
    Ecrire(Fact(n));
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme FactorielleRecursive;
Fonction Fact(n : Entier) : Entier;
Debut
    // Rédigez la fonction récursive ici
Fin;
Var
    n : Entier;
Debut
    // Rédigez votre programme principal ici
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5', isPub: true },
      { in: '0', isPub: true },
      { in: '1', isPub: false },
      { in: '2', isPub: false },
      { in: '3', isPub: false },
      { in: '4', isPub: false },
      { in: '6', isPub: false },
      { in: '7', isPub: false },
      { in: '8', isPub: false },
      { in: '9', isPub: false },
      { in: '10', isPub: false },
      { in: '12', isPub: false }
    ]
  },

  // 7. Calcul Puissance
  '403b8882-ae63-4633-809d-fd4dc488b793': {
    title: 'Calcul Puissance',
    refSol: `// question 1 commence ici
Algorithme CalculPuissance;
Var
    x, n, i, res : Entier;
Debut
    Lire(x);
    Lire(n);
    res := 1;
    Pour i := 1 a n Faire
        res := res * x;
    FinPour;
    Ecrire(res);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme CalculPuissance;
Var
    x, n, i, res : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '2\n3', isPub: true },
      { in: '5\n0', isPub: true },
      { in: '2\n10', isPub: false },
      { in: '3\n4', isPub: false },
      { in: '10\n3', isPub: false },
      { in: '7\n1', isPub: false },
      { in: '2\n0', isPub: false },
      { in: '4\n3', isPub: false },
      { in: '1\n20', isPub: false },
      { in: '3\n3', isPub: false },
      { in: '5\n3', isPub: false },
      { in: '2\n8', isPub: false }
    ]
  },

  // 8. Nombre Premier
  '07a32d49-0568-4186-bc68-6192fba83b8d': {
    title: 'Nombre Premier',
    refSol: `// question 1 commence ici
Algorithme NombrePremier;
Var
    n, i : Entier;
    est_premier : Booleen;
Debut
    Lire(n);
    est_premier := Vrai;
    Si n <= 1 Alors
        est_premier := Faux;
    Sinon
        Pour i := 2 a (n div 2) Faire
            Si n mod i = 0 Alors
                est_premier := Faux;
            FinSi;
        FinPour;
    FinSi;
    Si est_premier Alors
        Ecrire("PREMIER");
    Sinon
        Ecrire("NON PREMIER");
    FinSi;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme NombrePremier;
Var
    n, i : Entier;
    est_premier : Booleen;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '7', isPub: true },
      { in: '4', isPub: true },
      { in: '2', isPub: false },
      { in: '1', isPub: false },
      { in: '13', isPub: false },
      { in: '15', isPub: false },
      { in: '19', isPub: false },
      { in: '25', isPub: false },
      { in: '29', isPub: false },
      { in: '100', isPub: false },
      { in: '97', isPub: false },
      { in: '49', isPub: false }
    ]
  },

  // 9. Suite Fibonacci
  'd5a09a83-3234-4140-91f8-774b643ffea5': {
    title: 'Suite Fibonacci',
    refSol: `// question 1 commence ici
Algorithme Fibonacci;
Var
    n, i, a, b, c : Entier;
Debut
    Lire(n);
    Si n = 0 Alors
        Ecrire(0);
    Sinon
        Si n = 1 Alors
            Ecrire(1);
        Sinon
            a := 0;
            b := 1;
            Pour i := 2 a n Faire
                c := a + b;
                a := b;
                b := c;
            FinPour;
            Ecrire(b);
        FinSi;
    FinSi;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme Fibonacci;
Var
    n, i, a, b, c : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '0', isPub: true },
      { in: '1', isPub: true },
      { in: '2', isPub: false },
      { in: '3', isPub: false },
      { in: '4', isPub: false },
      { in: '5', isPub: false },
      { in: '6', isPub: false },
      { in: '7', isPub: false },
      { in: '8', isPub: false },
      { in: '9', isPub: false },
      { in: '10', isPub: false },
      { in: '12', isPub: false }
    ]
  },

  // 10. Maximum d'un Tableau
  '8ed9174d-2a06-4cd0-90e5-7b273405d228': {
    title: "Maximum d'un Tableau",
    refSol: `// question 1 commence ici
Algorithme MaxTableau;
Var
    t[100] : Entier;
    n, i, maxVal : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    maxVal := t[0];
    Pour i := 1 a n - 1 Faire
        Si t[i] > maxVal Alors
            maxVal := t[i];
        FinSi;
    FinPour;
    Ecrire(maxVal);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme MaxTableau;
Var
    t[100] : Entier;
    n, i, maxVal : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n10 20 5 40 15', isPub: true },
      { in: '3\n7 7 7', isPub: true },
      { in: '4\n-10 -5 -20 -1', isPub: false },
      { in: '1\n42', isPub: false },
      { in: '6\n1 2 3 4 5 6', isPub: false },
      { in: '5\n99 12 34 56 1', isPub: false },
      { in: '4\n-5 0 5 -10', isPub: false },
      { in: '5\n3 14 1 59 26', isPub: false },
      { in: '3\n100 500 200', isPub: false },
      { in: '4\n8 12 4 16', isPub: false },
      { in: '5\n-100 -200 -50 -300 -150', isPub: false },
      { in: '2\n10 20', isPub: false }
    ]
  },

  // 11. Inversion Tableau
  '9c4d3717-ce7a-44c5-b21e-13ad4f3f2f52': {
    title: 'Inversion Tableau',
    refSol: `// question 1 commence ici
Algorithme InversionTableau;
Var
    t[100] : Entier;
    n, i : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    Pour i := 0 a n - 1 Faire
        Ecrire(t[n - 1 - i], " ");
    FinPour;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme InversionTableau;
Var
    t[100] : Entier;
    n, i : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n1 2 3 4 5', isPub: true },
      { in: '3\n10 20 30', isPub: true },
      { in: '1\n42', isPub: false },
      { in: '4\n9 8 7 6', isPub: false },
      { in: '2\n100 200', isPub: false },
      { in: '5\n-5 -4 -3 -2 -1', isPub: false },
      { in: '6\n0 1 0 1 0 1', isPub: false },
      { in: '4\n12 34 56 78', isPub: false },
      { in: '3\n-10 0 10', isPub: false },
      { in: '5\n7 7 7 7 7', isPub: false },
      { in: '2\n-1 1', isPub: false },
      { in: '4\n5 15 25 35', isPub: false }
    ]
  },

  // 12. Tri a Bulles / Tri à Bulles
  '55b375f0-abba-44bb-98b7-6c10acbc6744': {
    title: 'Tri à Bulles',
    refSol: `// question 1 commence ici
Algorithme TriBulles;
Var
    t[100] : Entier;
    n, i, j, temp : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    Pour i := 0 a n - 2 Faire
        Pour j := 0 a n - 2 - i Faire
            Si t[j] > t[j + 1] Alors
                temp := t[j];
                t[j] := t[j + 1];
                t[j + 1] := temp;
            FinSi;
        FinPour;
    FinPour;
    Pour i := 0 a n - 1 Faire
        Ecrire(t[i], " ");
    FinPour;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme TriBulles;
Var
    t[100] : Entier;
    n, i, j, temp : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n5 2 9 1 4', isPub: true },
      { in: '4\n4 3 2 1', isPub: true },
      { in: '3\n1 2 3', isPub: false },
      { in: '1\n10', isPub: false },
      { in: '5\n-5 10 -20 0 15', isPub: false },
      { in: '4\n7 7 7 7', isPub: false },
      { in: '6\n100 50 200 150 25 300', isPub: false },
      { in: '5\n8 3 5 1 9', isPub: false },
      { in: '2\n20 10', isPub: false },
      { in: '4\n-1 -4 -2 -3', isPub: false },
      { in: '5\n12 5 23 8 1', isPub: false },
      { in: '3\n0 -5 5', isPub: false }
    ]
  },

  'fd9c82b5-221e-424e-8df4-92abf2f16fe9': {
    title: 'Tri a Bulles',
    refSol: `// question 1 commence ici
Algorithme TriBulles;
Var
    t[100] : Entier;
    n, i, j, temp : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    Pour i := 0 a n - 2 Faire
        Pour j := 0 a n - 2 - i Faire
            Si t[j] > t[j + 1] Alors
                temp := t[j];
                t[j] := t[j + 1];
                t[j + 1] := temp;
            FinSi;
        FinPour;
    FinPour;
    Pour i := 0 a n - 1 Faire
        Ecrire(t[i], " ");
    FinPour;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme TriBulles;
Var
    t[100] : Entier;
    n, i, j, temp : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n5 2 9 1 4', isPub: true },
      { in: '4\n4 3 2 1', isPub: true },
      { in: '3\n1 2 3', isPub: false },
      { in: '1\n10', isPub: false },
      { in: '5\n-5 10 -20 0 15', isPub: false },
      { in: '4\n7 7 7 7', isPub: false },
      { in: '6\n100 50 200 150 25 300', isPub: false },
      { in: '5\n8 3 5 1 9', isPub: false },
      { in: '2\n20 10', isPub: false },
      { in: '4\n-1 -4 -2 -3', isPub: false },
      { in: '5\n12 5 23 8 1', isPub: false },
      { in: '3\n0 -5 5', isPub: false }
    ]
  },

  // 13. Tri Insertion
  '05c3f225-21bd-4079-af5b-d38fcb329c3f': {
    title: 'Tri Insertion',
    refSol: `// question 1 commence ici
Algorithme TriInsertion;
Var
    t[100] : Entier;
    n, i, j, cle : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    Pour i := 1 a n - 1 Faire
        cle := t[i];
        j := i - 1;
        TantQue (j >= 0) Et (t[j] > cle) Faire
            t[j + 1] := t[j];
            j := j - 1;
        FinTantQue;
        t[j + 1] := cle;
    FinPour;
    Pour i := 0 a n - 1 Faire
        Ecrire(t[i], " ");
    FinPour;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme TriInsertion;
Var
    t[100] : Entier;
    n, i, j, cle : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n5 2 9 1 4', isPub: true },
      { in: '4\n4 3 2 1', isPub: true },
      { in: '3\n1 2 3', isPub: false },
      { in: '1\n10', isPub: false },
      { in: '5\n-5 10 -20 0 15', isPub: false },
      { in: '4\n7 7 7 7', isPub: false },
      { in: '6\n100 50 200 150 25 300', isPub: false },
      { in: '5\n8 3 5 1 9', isPub: false },
      { in: '2\n20 10', isPub: false },
      { in: '4\n-1 -4 -2 -3', isPub: false },
      { in: '5\n12 5 23 8 1', isPub: false },
      { in: '3\n0 -5 5', isPub: false }
    ]
  },

  // 14. Tri Selection
  'c320dc11-8a74-4e4c-acd5-9c43501589de': {
    title: 'Tri Selection',
    refSol: `// question 1 commence ici
Algorithme TriSelection;
Var
    t[100] : Entier;
    n, i, j, minIdx, temp : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    Pour i := 0 a n - 2 Faire
        minIdx := i;
        Pour j := i + 1 a n - 1 Faire
            Si t[j] < t[minIdx] Alors
                minIdx := j;
            FinSi;
        FinPour;
        temp := t[i];
        t[i] := t[minIdx];
        t[minIdx] := temp;
    FinPour;
    Pour i := 0 a n - 1 Faire
        Ecrire(t[i], " ");
    FinPour;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme TriSelection;
Var
    t[100] : Entier;
    n, i, j, minIdx, temp : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n5 2 9 1 4', isPub: true },
      { in: '4\n4 3 2 1', isPub: true },
      { in: '3\n1 2 3', isPub: false },
      { in: '1\n10', isPub: false },
      { in: '5\n-5 10 -20 0 15', isPub: false },
      { in: '4\n7 7 7 7', isPub: false },
      { in: '6\n100 50 200 150 25 300', isPub: false },
      { in: '5\n8 3 5 1 9', isPub: false },
      { in: '2\n20 10', isPub: false },
      { in: '4\n-1 -4 -2 -3', isPub: false },
      { in: '5\n12 5 23 8 1', isPub: false },
      { in: '3\n0 -5 5', isPub: false }
    ]
  },

  // 15. Recherche Dichotomique
  'ddce1ddc-386f-4081-9ec7-69bff7fbe804': {
    title: 'Recherche Dichotomique',
    refSol: `// question 1 commence ici
Algorithme RechercheDichotomique;
Var
    t[100] : Entier;
    n, valCherchee, i : Entier;
    debutIdx, finIdx, milieu, resIdx : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    Lire(valCherchee);
    
    debutIdx := 0;
    finIdx := n - 1;
    resIdx := -1;
    
    TantQue debutIdx <= finIdx Faire
        milieu := (debutIdx + finIdx) div 2;
        Si t[milieu] = valCherchee Alors
            resIdx := milieu;
            debutIdx := finIdx + 1; // Sortir
        Sinon
            Si t[milieu] < valCherchee Alors
                debutIdx := milieu + 1;
            Sinon
                finIdx := milieu - 1;
            FinSi;
        FinSi;
    FinTantQue;
    
    Ecrire(resIdx);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme RechercheDichotomique;
Var
    t[100] : Entier;
    n, valCherchee, i : Entier;
    debutIdx, finIdx, milieu, resIdx : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n10 20 30 40 50\n30', isPub: true },
      { in: '5\n10 20 30 40 50\n99', isPub: true },
      { in: '1\n42\n42', isPub: false },
      { in: '1\n42\n10', isPub: false },
      { in: '4\n1 3 5 7\n1', isPub: false },
      { in: '4\n1 3 5 7\n7', isPub: false },
      { in: '6\n2 4 6 8 10 12\n8', isPub: false },
      { in: '6\n2 4 6 8 10 12\n5', isPub: false },
      { in: '5\n-10 -5 0 5 10\n-5', isPub: false },
      { in: '5\n-10 -5 0 5 10\n0', isPub: false },
      { in: '3\n100 200 300\n200', isPub: false },
      { in: '3\n100 200 300\n400', isPub: false }
    ]
  },

  // 16. Filtrage Pairs
  '07adc4e0-ce70-4921-8c47-6671f7906538': {
    title: 'Filtrage Pairs',
    refSol: `// question 1 commence ici
Algorithme FiltragePairs;
Var
    t[100] : Entier;
    n, i : Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    Pour i := 0 a n - 1 Faire
        Si t[i] mod 2 = 0 Alors
            Ecrire(t[i], " ");
        FinSi;
    FinPour;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme FiltragePairs;
Var
    t[100] : Entier;
    n, i : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n1 2 3 4 5', isPub: true },
      { in: '4\n10 20 30 40', isPub: true },
      { in: '3\n1 3 5', isPub: false },
      { in: '1\n8', isPub: false },
      { in: '6\n0 7 12 15 22 31', isPub: false },
      { in: '4\n-4 -3 -2 -1', isPub: false },
      { in: '5\n100 101 102 103 104', isPub: false },
      { in: '2\n2 4', isPub: false },
      { in: '3\n9 9 9', isPub: false },
      { in: '4\n24 13 8 7', isPub: false },
      { in: '5\n-10 -7 0 7 10', isPub: false },
      { in: '1\n3', isPub: false }
    ]
  },

  // 17. MinMax Arithmetique
  'bb96d0a8-2ae6-4dc4-9efd-0dc2db55b9e7': {
    title: 'MinMax Arithmetique',
    refSol: `// question 1 commence ici
Algorithme MinMaxPointeurs;
Var
    t[100] : Entier;
    n, i, minVal, maxVal : Entier;
    ptr : ^Entier;
Debut
    Lire(n);
    Pour i := 0 a n - 1 Faire
        Lire(t[i]);
    FinPour;
    ptr := &t[0];
    minVal := ptr^;
    maxVal := ptr^;
    Pour i := 1 a n - 1 Faire
        ptr := &t[i];
        Si ptr^ < minVal Alors
            minVal := ptr^;
        FinSi;
        Si ptr^ > maxVal Alors
            maxVal := ptr^;
        FinSi;
    FinPour;
    Ecrire(minVal, " ", maxVal);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme MinMaxPointeurs;
Var
    t[100] : Entier;
    n, i, minVal, maxVal : Entier;
    ptr : ^Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: '5\n5 89 12 3 45', isPub: true },
      { in: '3\n10 20 30', isPub: true },
      { in: '1\n42', isPub: false },
      { in: '4\n-10 -5 -20 -1', isPub: false },
      { in: '5\n7 7 7 7 7', isPub: false },
      { in: '6\n100 50 200 150 25 300', isPub: false },
      { in: '4\n-5 0 5 -10', isPub: false },
      { in: '5\n3 14 1 59 26', isPub: false },
      { in: '2\n100 200', isPub: false },
      { in: '4\n8 12 4 16', isPub: false },
      { in: '5\n-100 -200 -50 -300 -150', isPub: false },
      { in: '2\n20 10', isPub: false }
    ]
  },

  // 18. Compteur Voyelles & Comptage des Voyelles
  '5d2798b0-2e93-4812-a6d0-6920fbabf8c2': {
    title: 'Compteur Voyelles',
    refSol: `// question 1 commence ici
Algorithme CompteurVoyelles;
Var
    phrase[100] : Chaine;
    i, n, nb : Entier;
    c : Caractere;
Debut
    Lire(phrase);
    n := Longueur(phrase);
    nb := 0;
    Pour i := 0 a n - 1 Faire
        c := phrase[i];
        Si (c = 'a') Ou (c = 'e') Ou (c = 'i') Ou (c = 'o') Ou (c = 'u') Ou (c = 'y') Ou
           (c = 'A') Ou (c = 'E') Ou (c = 'I') Ou (c = 'O') Ou (c = 'U') Ou (c = 'Y') Alors
            nb := nb + 1;
        FinSi;
    FinPour;
    Ecrire(nb);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme CompteurVoyelles;
Var
    phrase[100] : Chaine;
    i, n, nb : Entier;
    c : Caractere;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: 'bonjour', isPub: true },
      { in: 'algorithme', isPub: true },
      { in: 'xyz', isPub: false },
      { in: 'bcd', isPub: false },
      { in: 'AEIOUY', isPub: false },
      { in: 'test', isPub: false },
      { in: 'informatique', isPub: false },
      { in: 'antigravity', isPub: false },
      { in: 'programmation', isPub: false },
      { in: 'compilateur', isPub: false },
      { in: 'a', isPub: false },
      { in: 'b', isPub: false }
    ]
  },

  '17a8e871-fa60-445d-80bc-3cb45195308e': {
    title: 'Comptage des Voyelles',
    refSol: `// question 1 commence ici
Algorithme CompteurVoyelles;
Var
    phrase[100] : Chaine;
    i, n, nb : Entier;
    c : Caractere;
Debut
    Lire(phrase);
    n := Longueur(phrase);
    nb := 0;
    Pour i := 0 a n - 1 Faire
        c := phrase[i];
        Si (c = 'a') Ou (c = 'e') Ou (c = 'i') Ou (c = 'o') Ou (c = 'u') Ou (c = 'y') Ou
           (c = 'A') Ou (c = 'E') Ou (c = 'I') Ou (c = 'O') Ou (c = 'U') Ou (c = 'Y') Alors
            nb := nb + 1;
        FinSi;
    FinPour;
    Ecrire(nb);
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme CompteurVoyelles;
Var
    phrase[100] : Chaine;
    i, n, nb : Entier;
    c : Caractere;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: 'bonjour', isPub: true },
      { in: 'algorithme', isPub: true },
      { in: 'xyz', isPub: false },
      { in: 'bcd', isPub: false },
      { in: 'AEIOUY', isPub: false },
      { in: 'test', isPub: false },
      { in: 'informatique', isPub: false },
      { in: 'antigravity', isPub: false },
      { in: 'programmation', isPub: false },
      { in: 'compilateur', isPub: false },
      { in: 'a', isPub: false },
      { in: 'b', isPub: false }
    ]
  },

  // 19. Inversion Chaine
  '076aaef0-658a-463e-a4b5-0f628edc2247': {
    title: 'Inversion Chaine',
    refSol: `// question 1 commence ici
Algorithme InversionChaine;
Var
    s[100] : Chaine;
    i, n : Entier;
Debut
    Lire(s);
    n := Longueur(s);
    Pour i := 0 a n - 1 Faire
        Ecrire(s[n - 1 - i]);
    FinPour;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme InversionChaine;
Var
    s[100] : Chaine;
    i, n : Entier;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: 'bonjour', isPub: true },
      { in: 'radar', isPub: true },
      { in: 'algo', isPub: false },
      { in: '12345', isPub: false },
      { in: 'a', isPub: false },
      { in: 'ab', isPub: false },
      { in: 'compiler', isPub: false },
      { in: 'examen', isPub: false },
      { in: 'pascal', isPub: false },
      { in: 'python', isPub: false },
      { in: 'test', isPub: false },
      { in: 'hello', isPub: false }
    ]
  },

  // 20. Palindrome
  'dd5ca3f8-54d0-4dbc-976a-2828da5e0a63': {
    title: 'Palindrome',
    refSol: `// question 1 commence ici
Algorithme Palindrome;
Var
    mot[100] : Chaine;
    i, n : Entier;
    est_pal : Booleen;
Debut
    Lire(mot);
    n := Longueur(mot);
    est_pal := Vrai;
    Pour i := 0 a (n div 2) - 1 Faire
        Si mot[i] <> mot[n - 1 - i] Alors
            est_pal := Faux;
        FinSi;
    FinPour;
    Si est_pal Alors
        Ecrire("PALINDROME");
    Sinon
        Ecrire("NON PALINDROME");
    FinSi;
Fin.
// question 1 se termine ici`,
    starter: `// question 1 commence ici
Algorithme Palindrome;
Var
    mot[100] : Chaine;
    i, n : Entier;
    est_pal : Booleen;
Debut
    // Rédigez votre solution ici
    
Fin.
// question 1 se termine ici`,
    testInputs: [
      { in: 'radar', isPub: true },
      { in: 'bonjour', isPub: true },
      { in: 'kayak', isPub: false },
      { in: 'level', isPub: false },
      { in: 'algo', isPub: false },
      { in: 'a', isPub: false },
      { in: 'aa', isPub: false },
      { in: 'ab', isPub: false },
      { in: 'laval', isPub: false },
      { in: 'informatique', isPub: false },
      { in: 'noon', isPub: false },
      { in: 'test', isPub: false }
    ]
  }
};

// IDs of Tutorial, Demonstration, and Compiler Internal Test problems (Impossible to test via standard I/O)
const IMPOSSIBLE_OR_TUTORIAL_PROBLEM_IDS = [
  '47c9f4a2-054b-4035-9adb-8a29010b1907', // problem with no tests
  '1c42e329-e3f2-4437-9249-d0d252900a1a', // Tutoriel Bases
  '49be4526-fcc1-41de-812e-2d643571c906', // Introduction Operateurs
  '64ded529-79f1-4e6e-b869-73f778439c23', // Tutoriel Tableaux
  'bc89183c-012a-47aa-a169-9bc9f36e2ac4', // Bases Tableaux 1D
  'b62c1f9a-ed52-43ee-b5b0-7248395ffc77', // Bases Tableaux 2D
  '2303dbe2-c3f3-4864-af1e-8be47fe84462', // Tutoriel Chaines
  '9b7cf468-bce9-4208-8443-371cb74fefcf', // Bases Chaines
  '6a5d3650-ca42-4f1d-b207-b71a01078a80', // Tutoriel Pointeurs
  '0ab46f1c-e21e-49c6-aa30-2ec8fe181a9e', // Bases Pointeurs
  '8b3f4853-a9fc-485b-a63d-bfb7adedc534', // Analyse Chaine Pointeur
  '84d9cb43-9fdd-4cdc-8949-8ae0dc9d65b5', // Tutoriel Allocation Dynamique
  '43f582a8-268f-4eb2-929e-a6b3cdbac576', // Bases Allocation
  '8db9c06e-34a5-49a5-b13a-e9028357fb51', // Redimensionnement
  '3315f34f-c3a5-47dc-bbbd-76e9672f4ecd', // Test Allocation
  '5c0d693b-8d4e-4138-87bf-d7b082e7aeed', // Exemple Simple (Listes Chaînées)
  '005f0cd8-ac51-44d1-b06a-ce60eca507dc', // SolvedIssues
  '2225049f-b4b5-4629-91e4-e418c65f6daf', // TestAscii
  '9a0f62bf-cdec-42f0-80c6-791e75063b35', // TestDecay
  'b4e18ca6-7ed5-4f6b-bf21-374abbb7d957'  // TestNIL
];

async function updateAllSingleQProblems() {
  console.log('=== STARTING BATCH PROBLEM UPDATE & TEST SUITE VALIDATION ===\n');

  // 1. Process Algorithmic Problems
  for (const [probId, conf] of Object.entries(ALGO_PROBLEMS_UPDATES)) {
    console.log(`\n▶ Processing Problem: "${conf.title}" [${probId}]`);

    // Verify reference solution with all test inputs
    const generatedTestCases = [];

    for (let i = 0; i < conf.testInputs.length; i++) {
      const tc = conf.testInputs[i];
      const runRes = await runCodeSingle(conf.refSol, 'ALGO', tc.in);

      if (runRes.status !== 'SUCCESS') {
        console.error(`  ❌ FAILED execution for TC #${i + 1}: in="${tc.in}", stderr="${runRes.stderr}"`);
        throw new Error(`Execution error for problem ${conf.title}`);
      }

      const expectedOut = runRes.stdout.trim();
      generatedTestCases.push({
        problemId: probId,
        inputData: tc.in,
        expectedOutput: expectedOut,
        isPublic: tc.isPub
      });

      if (i < 2) {
        console.log(`   ✓ TC #${i + 1} (${tc.isPub ? 'Public' : 'Hidden'}): in=${JSON.stringify(tc.in)} -> expected=${JSON.stringify(expectedOut)}`);
      }
    }

    console.log(`   ✓ All ${generatedTestCases.length} TestCases computed & verified!`);

    // Update Problem in DB
    await prisma.problem.update({
      where: { id: probId },
      data: {
        referenceSolution: conf.refSol,
        templateCode: conf.starter
      }
    });

    // Replace test cases
    await prisma.testCase.deleteMany({ where: { problemId: probId } });
    await prisma.testCase.createMany({ data: generatedTestCases });

    console.log(`   💾 Database updated successfully for "${conf.title}"!`);
  }

  // 2. Process Impossible / Tutorial problems (Wipe test cases -> 100% AST structure)
  console.log('\n=============================================================');
  console.log('▶ Processing Impossible / Demonstration / Compiler Problems:');
  console.log('=============================================================');

  for (const probId of IMPOSSIBLE_OR_TUTORIAL_PROBLEM_IDS) {
    const p = await prisma.problem.findUnique({ where: { id: probId } });
    if (p) {
      await prisma.testCase.deleteMany({ where: { problemId: probId } });
      console.log(`   ✓ Cleared test cases for [${p.id}] "${p.title}" (Mode: 100% AST & Structure)`);
    }
  }

  console.log('\n🎉 ALL PROBLEMS AND TEST SUITES SUCCESSFULLY UPDATED & VERIFIED!');
}

updateAllSingleQProblems()
  .catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
