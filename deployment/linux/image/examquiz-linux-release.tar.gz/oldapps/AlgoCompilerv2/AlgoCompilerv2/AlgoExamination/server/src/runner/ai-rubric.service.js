// Circuit Breaker for local LLM inference to prevent worker queue stalls
const circuitBreaker = {
  failures: 0,
  maxFailures: 2,
  cooldownMs: 60000,
  lastFailureTime: 0,
  isOpen() {
    if (this.failures >= this.maxFailures) {
      if (Date.now() - this.lastFailureTime < this.cooldownMs) {
        return true;
      }
      this.failures = 0;
    }
    return false;
  },
  recordFailure() {
    this.failures++;
    this.lastFailureTime = Date.now();
  },
  recordSuccess() {
    this.failures = 0;
  }
};

/**
 * Reusable Module 3 AI & AST Rubric Evaluator
 * Tries local Ollama LLM if online/available, falls back to AST Rubric Engine.
 */
async function evaluateAIForSubmission(problem, studentCode, targetModel = 'qwen1_5b') {
  if (!studentCode || !studentCode.trim()) {
    return {
      scoreOut10: 0,
      scorePct: 0,
      evaluationDetails: {
        classification: 'Aucun code rédigé',
        criteria: [],
        strengths: [],
        errors: [{ description: 'Aucune réponse rédigée.', severity: 'critical' }]
      }
    };
  }

  const systemPrompt = `Vous êtes un professeur expert en Algorithmique et Structures de Données. Votre rôle est d'évaluer le code pseudo-code de l'étudiant par rapport au problème et à la solution de référence.
Répondez UNIQUEMENT sous forme d'un objet JSON strict avec le schéma suivant :
{
  "scoreOut10": number (0 à 10),
  "scorePct": number (0 à 100),
  "evaluationDetails": {
    "classification": string ("Équivalent Référence", "Partiellement Correct", "Erreur Majeure", "Non Fonctionnel"),
    "strengths": Array<string>,
    "errors": Array<{ "description": string, "severity": "low"|"medium"|"high"|"critical" }>
  }
}`;

  const userPrompt = `PROBLÈME : ${problem.title}\nDESCRIPTION : ${problem.description || ''}\n\nSOLUTION DE RÉFÉRENCE :\n\`\`\`algo\n${problem.referenceSolution || ''}\n\`\`\`\n\nSOLUTION ÉTUDIANT :\n\`\`\`algo\n${studentCode}\n\`\`\``;

  let llmResult = null;

  const OLLAMA_MODEL_MAP = {
    'qwen1_5b': 'qwen2.5-coder:1.5b',
    'qwen2.5-coder:1.5b': 'qwen2.5-coder:1.5b',
    'qwen3b': 'qwen2.5-coder:3b',
    'deepseek': 'deepseek-r1:1.5b'
  };
  const resolvedModel = OLLAMA_MODEL_MAP[targetModel] || targetModel;

  if (!circuitBreaker.isOpen()) {
    try {
      const ollamaRes = await new Promise((resolve, reject) => {
        const postData = JSON.stringify({
          model: resolvedModel,
          prompt: userPrompt,
          system: systemPrompt,
          stream: false,
          format: 'json',
          keep_alive: '10m',
          options: { temperature: 0.1, top_p: 0.9, num_predict: 300 }
        });

        const reqOllama = http.request('http://127.0.0.1:11434/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData) },
          timeout: 2000
        }, (resOllama) => {
          let body = '';
          resOllama.on('data', chunk => body += chunk);
          resOllama.on('end', () => resolve(body));
        });

        reqOllama.on('error', reject);
        reqOllama.on('timeout', () => { reqOllama.destroy(); reject(new Error('Timeout')); });
        reqOllama.write(postData);
        reqOllama.end();
      });

      const parsedOllama = JSON.parse(ollamaRes);
      if (parsedOllama.response) {
        llmResult = JSON.parse(parsedOllama.response);
        circuitBreaker.recordSuccess();
      }
    } catch (err) {
      circuitBreaker.recordFailure();
    }
  }

  // AST Rubric Fallback Engine if LLM is offline or non-responsive
  if (!llmResult) {
    let scorePct = 0;
    let errors = [], strengths = [];
    const code = studentCode || '';
    const titleLower = (problem.title || '').toLowerCase();

    // Check if code has actual instructions inside DEBUT...FIN
    const matchBody = code.match(/DEBUT\s*([\s\S]*?)\s*FIN/i);
    const bodyContent = matchBody ? matchBody[1].replace(/\/\/.*$/gm, '').trim() : code.replace(/ALGORITHME.*$/im, '').replace(/DEBUT/i, '').replace(/FIN\.?/i, '').trim();

    const hasInstructions = /\b(Lire|Ecrire|Pour|Si|TantQue|Répéter)\b|:=|<-|=|\+|-|\*|\//i.test(bodyContent);

    if (!hasInstructions || bodyContent.length < 2) {
      scorePct = 0;
      errors.push({ description: "Le corps de l'algorithme entre DEBUT et FIN est vide (aucune instruction rédigée).", severity: "critical" });
    } else if (titleLower.includes('somme') || titleLower.includes('add')) {
      const hasAdd = code.includes('+');
      const hasAssign = /:=\s*|\s*<-\s*|=/i.test(code);
      const hasWrite = /\bEcrire\b/i.test(code);
      if (!hasAdd || !hasAssign) {
        scorePct = 20;
        errors.push({ description: "Calcul de la somme manquant (ex: Somme := A + B).", severity: "critical" });
      } else if (!hasWrite) {
        scorePct = 70;
        errors.push({ description: "Instruction d'affichage 'Ecrire' manquante.", severity: "medium" });
      } else {
        scorePct = 100;
        strengths.push("Addition et affichage corrects.");
      }
    } else if (titleLower.includes('tri') || titleLower.includes('bulle')) {
      const hasLoops = (code.match(/Pour|TantQue/gi) || []).length >= 2;
      const hasTemp = /temp|aux/i.test(code);
      if (!hasTemp) {
        scorePct = 30;
        errors.push({ description: "Variable temporaire d'échange manquante.", severity: "high" });
      } else if (!hasLoops) {
        scorePct = 20;
        errors.push({ description: "Boucles imbriquées manquant pour le tri.", severity: "critical" });
      } else {
        scorePct = 100;
        strengths.push("Algorithme de tri fonctionnel.");
      }
    } else {
      const hasDebut = /\bDEBUT\b/i.test(code);
      const hasFin = /\bFIN\b/i.test(code);
      if (!hasDebut || !hasFin) {
        scorePct = 20;
        errors.push({ description: "Structure DEBUT...FIN incomplète.", severity: "medium" });
      } else {
        scorePct = 50;
        strengths.push("Structure de base présente.");
      }
    }

    const scoreOut10 = Math.round((scorePct / 10) * 10) / 10;
    const classification = scorePct >= 80 ? 'Équivalent Référence' : scorePct >= 50 ? 'Partiellement Correct' : 'Erreur Majeure';

    llmResult = {
      scoreOut10,
      scorePct,
      evaluationDetails: {
        classification,
        strengths,
        errors
      }
    };
  }

  return llmResult;
}

module.exports = {
  evaluateAIForSubmission
};
