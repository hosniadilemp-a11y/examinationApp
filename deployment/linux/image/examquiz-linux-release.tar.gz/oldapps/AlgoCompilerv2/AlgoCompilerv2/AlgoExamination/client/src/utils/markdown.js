import katex from 'katex';
import 'katex/dist/katex.min.css';

/**
 * Clean output text formatter to prevent raw JSON strings from appearing in consoles.
 */
export const formatOutputText = (val) => {
  if (!val) return '';
  if (typeof val === 'object') {
    if (val.message) return val.message;
    if (val.error) return val.error;
    if (val.stdout || val.stderr) return val.stdout || val.stderr;
    return JSON.stringify(val, null, 2);
  }
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (trimmed.startsWith('{')) {
      if (trimmed.includes("'line':") || trimmed.includes('"line":')) {
        const lineMatch = trimmed.match(/['"]line['"]:\s*(\d+)/);
        const colMatch = trimmed.match(/['"]column['"]:\s*(\d+)/);
        const msgMatch = trimmed.match(/['"]message['"]:\s*['"]([^'"]+)['"]/);
        const codeMatch = trimmed.match(/['"]error_code['"]:\s*['"]([^'"]+)['"]/);

        const line = lineMatch ? lineMatch[1] : '1';
        const col = colMatch ? colMatch[1] : '1';
        const msg = msgMatch ? msgMatch[1] : 'Erreur de syntaxe';
        const codeStr = codeMatch ? codeMatch[1] : 'E2.1';

        return `Ligne ${line}, Colonne ${col} [${codeStr}] : ${msg}`;
      }
      try {
        const parsed = JSON.parse(trimmed);
        if (parsed.message) return parsed.message;
        if (parsed.error) return parsed.error;
        if (Array.isArray(parsed.errors)) {
          return parsed.errors.map(e => e.message || `Ligne ${e.line} : Erreur`).join('\n');
        }
      } catch (_) {}
    }
  }
  return String(val);
};

/**
 * Robust Markdown HTML Converter with KaTeX LaTeX Support
 */
export const renderMarkdownHTML = (text) => {
  if (!text) return '<p style="color: var(--text-muted); font-style: italic;">Aucun contenu rédigé.</p>';

  // Preserve Code Blocks
  const codeBlocks = [];
  let processed = text.replace(/```(\w*)\r?\n([\s\S]*?)```/g, (_, lang, code) => {
    const idx = codeBlocks.length;
    const cleanCode = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    codeBlocks.push(`
      <div style="margin: 12px 0; background: #090d16; border: 1px solid rgba(255,255,255,0.15); border-radius: 8px; overflow: hidden; font-family: var(--font-mono);">
        ${lang ? `<div style="background: rgba(255,255,255,0.05); padding: 4px 12px; font-size: 0.75rem; color: #60a5fa; font-weight: 700; border-bottom: 1px solid rgba(255,255,255,0.1); text-transform: uppercase;">${lang}</div>` : ''}
        <pre style="margin: 0; padding: 12px 16px; color: #34d399; font-size: 0.88rem; line-height: 1.5; white-space: pre-wrap; overflow-x: auto;"><code>${cleanCode}</code></pre>
      </div>
    `);
    return `___CODE_BLOCK_${idx}___`;
  });

  // Render LaTeX Display Math ($$...$$)
  processed = processed.replace(/\$\$(.*?)\$\$/gs, (_, mathStr) => {
    try {
      const rendered = katex.renderToString(mathStr.trim(), { displayMode: true, throwOnError: false });
      return `<div style="text-align: center; margin: 14px 0; padding: 10px; background: rgba(15,23,42,0.8); border: 1px solid rgba(167,139,250,0.3); border-radius: 8px;">${rendered}</div>`;
    } catch (_) {
      return `$$${mathStr}$$`;
    }
  });

  // Render LaTeX Inline Math ($...$)
  processed = processed.replace(/\$([^\$\n]+)\$/g, (_, mathStr) => {
    try {
      const rendered = katex.renderToString(mathStr.trim(), { displayMode: false, throwOnError: false });
      return `<span style="display: inline-block; padding: 0 4px;">${rendered}</span>`;
    } catch (_) {
      return `$${mathStr}$`;
    }
  });

  // Formatting headers, bold, code, linebreaks
  processed = processed
    .replace(/^### (.*?)( ###)?$/gim, '<h3 style="color: #60a5fa; margin-top: 18px; margin-bottom: 8px; font-weight: 700;">$1</h3>')
    .replace(/^## (.*?)( ##)?$/gim, '<h2 style="color: #a78bfa; margin-top: 22px; margin-bottom: 10px; font-weight: 800; border-bottom: 1px solid rgba(167,139,250,0.2); padding-bottom: 6px;">$1</h2>')
    .replace(/^# (.*?)( #)?$/gim, '<h1 style="color: #f43f5e; margin-top: 24px; margin-bottom: 12px; font-weight: 800;">$1</h1>')
    .replace(/\*\*(.*?)\*\*/g, '<strong style="color: #f8fafc; font-weight: 700;">$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/~~(.*?)~~/g, '<del>$1</del>')
    .replace(/`([^`]+)`/g, '<code style="background: rgba(255,255,255,0.1); color: #34d399; padding: 2px 6px; border-radius: 4px; font-family: var(--font-mono); font-size: 0.88rem;">$1</code>')
    .replace(/\n\n/g, '</p><p style="margin-bottom: 12px;">')
    .replace(/\n/g, '<br/>');

  codeBlocks.forEach((blockHtml, idx) => {
    processed = processed.replace(`___CODE_BLOCK_${idx}___`, blockHtml);
  });

  return `<div style="line-height: 1.6; font-size: 0.95rem;">${processed}</div>`;
};
