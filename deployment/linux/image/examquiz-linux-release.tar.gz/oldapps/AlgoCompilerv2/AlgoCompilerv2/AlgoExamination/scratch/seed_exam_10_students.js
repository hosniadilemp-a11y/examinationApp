const prisma = require('../server/src/prisma');

async function seedExam10Students() {
  console.log('🌱 Creating Exam with 4 Exercises & 10 Student Profiles (12 Tests/Problem, Ungraded)...');

  // 1. Ensure Teacher exists
  let teacher = await prisma.teacher.findFirst();
  if (!teacher) {
    teacher = await prisma.teacher.create({
      data: {
        email: 'teacher@algoexam.edu',
        passwordHash: '$2b$10$wU0M6h7vYg7/bU.PzL.h6.s0lD.7pQ2H.uG.qJ.xG.y.u.v.w.x',
        firstName: 'Professeur',
        lastName: 'EXAMINATEUR'
      }
    });
  }

  // 2. Create 5 New Students (total 10 students)
  const studentList = [
    { studentId: '2026001', firstName: 'Ahmed', lastName: 'BENALI', group: 'G01', speciality: '1CP' },
    { studentId: '2026002', firstName: 'Sara', lastName: 'KHELIFI', group: 'G01', speciality: '1CP' },
    { studentId: '2026003', firstName: 'Ali', lastName: 'AMRANE', group: 'G01', speciality: '1CP' },
    { studentId: '2026004', firstName: 'Yasmine', lastName: 'BOUMEDIENE', group: 'G01', speciality: '1CP' },
    { studentId: '2026005', firstName: 'Karim', lastName: 'HAMDI', group: 'G01', speciality: '1CP' },
    { studentId: '2026006', firstName: 'Ryad', lastName: 'SAIDI', group: 'G02', speciality: '1CP' },
    { studentId: '2026007', firstName: 'Lyna', lastName: 'BELKACEM', group: 'G02', speciality: '1CP' },
    { studentId: '2026008', firstName: 'Yassine', lastName: 'MEFTAH', group: 'G02', speciality: '1CP' },
    { studentId: '2026009', firstName: 'Amina', lastName: 'TOUATI', group: 'G02', speciality: '1CP' },
    { studentId: '2026010', firstName: 'Oumar', lastName: 'CHERIF', group: 'G02', speciality: '1CP' }
  ];

  const dbStudents = [];
  for (const st of studentList) {
    const s = await prisma.student.upsert({
      where: { studentId: st.studentId },
      update: {},
      create: st
    });
    dbStudents.push(s);
  }

  console.log(`✅ Loaded ${dbStudents.length} Students.`);

  // Delete older exam with same title if exists to ensure clean state
  const existingExams = await prisma.exam.findMany({ where: { prefix: 'EXAM2026-FINAL' } });
  for (const ex of existingExams) {
    await prisma.submission.deleteMany({ where: { examId: ex.id } });
    await prisma.examAssignment.deleteMany({ where: { examId: ex.id } });
    await prisma.examProblem.deleteMany({ where: { examId: ex.id } });
    await prisma.exam.delete({ where: { id: ex.id } });
  }

  // 3. Create 4 Problems with 2 Public + 10 Hidden Tests (12 Test Cases per Problem)
  const p1 = await prisma.problem.create({
    data: {
      title: `Somme de Deux Matrices 2D (Final ${Date.now()})`,
      description: 'Écrire un algorithme qui lit la taille N d\'une matrice carrée, puis deux matrices M1 et M2 de taille N x N, puis affiche la matrice somme S = M1 + M2.',
      topic: 'MATRICES',
      difficulty: 'MEDIUM',
      points: 5,
      referenceSolution: `Algorithme SommeMatrices;\nVar N, i, j, M1[10][10], M2[10][10], S[10][10] : Entier;\nDebut\n  Lire(N);\n  Pour i := 1 a N Faire\n    Pour j := 1 a N Faire Lire(M1[i][j]); Fin Pour;\n  Fin Pour;\n  Pour i := 1 a N Faire\n    Pour j := 1 a N Faire Lire(M2[i][j]); Fin Pour;\n  Fin Pour;\n  Pour i := 1 a N Faire\n    Pour j := 1 a N Faire\n      S[i][j] := M1[i][j] + M2[i][j];\n      Ecrire(S[i][j]);\n    Fin Pour;\n  Fin Pour;\nFin.`,
      templateCode: { ALGO: `ALGORITHME Somme_de_Deux_Matrices_2D\nVARIABLES\n   // [Code Modèle de Départ]\nDEBUT\n   // Indiquez votre algorithme ici\nFIN.` },
      testCases: {
        create: [
          // 2 Public Tests
          { isPublic: true, inputData: "2\n1\n2\n3\n4\n5\n6\n7\n8", expectedOutput: "6 8 10 12" },
          { isPublic: true, inputData: "1\n5\n10", expectedOutput: "15" },
          // 10 Hidden Tests
          { isPublic: false, inputData: "2\n0\n0\n0\n0\n0\n0\n0\n0", expectedOutput: "0 0 0 0" },
          { isPublic: false, inputData: "2\n1\n0\n0\n1\n1\n0\n0\n1", expectedOutput: "2 0 0 2" },
          { isPublic: false, inputData: "2\n-1\n-2\n-3\n-4\n1\n2\n3\n4", expectedOutput: "0 0 0 0" },
          { isPublic: false, inputData: "2\n10\n20\n30\n40\n5\n5\n5\n5", expectedOutput: "15 25 35 45" },
          { isPublic: false, inputData: "3\n1\n2\n3\n4\n5\n6\n7\n8\n9\n9\n8\n7\n6\n5\n4\n3\n2\n1", expectedOutput: "10 10 10 10 10 10 10 10 10" },
          { isPublic: false, inputData: "2\n100\n200\n300\n400\n100\n200\n300\n400", expectedOutput: "200 400 600 800" },
          { isPublic: false, inputData: "2\n-5\n5\n-10\n10\n-5\n5\n-10\n10", expectedOutput: "-10 10 -20 20" },
          { isPublic: false, inputData: "1\n999\n1", expectedOutput: "1000" },
          { isPublic: false, inputData: "3\n1\n0\n0\n0\n1\n0\n0\n0\n1\n2\n0\n0\n0\n2\n0\n0\n0\n2", expectedOutput: "3 0 0 0 3 0 0 0 3" },
          { isPublic: false, inputData: "2\n7\n3\n2\n9\n1\n4\n8\n2", expectedOutput: "8 7 10 11" }
        ]
      }
    }
  });

  const p2 = await prisma.problem.create({
    data: {
      title: `Tri à Bulles par Ordre Croissant (Final ${Date.now()})`,
      description: 'Écrire un algorithme qui trie un tableau T de N entiers par ordre croissant en utilisant le tri à bulles.',
      topic: 'TRI',
      difficulty: 'MEDIUM',
      points: 5,
      referenceSolution: `Algorithme TriBulles;\nVar N, i, j, temp, T[100] : Entier;\nDebut\n  Lire(N);\n  Pour i := 1 a N Faire Lire(T[i]); Fin Pour;\n  Pour i := 1 a N - 1 Faire\n    Pour j := 1 a N - i Faire\n      Si T[j] > T[j+1] Alors\n        temp := T[j];\n        T[j] := T[j+1];\n        T[j+1] := temp;\n      Fin Si;\n    Fin Pour;\n  Fin Pour;\n  Pour i := 1 a N Faire Ecrire(T[i]); Fin Pour;\nFin.`,
      templateCode: { ALGO: `ALGORITHME Tri_Bulles\nVARIABLES\nDEBUT\nFIN.` },
      testCases: {
        create: [
          // 2 Public Tests
          { isPublic: true, inputData: "5\n5 2 8 1 9", expectedOutput: "1 2 5 8 9" },
          { isPublic: true, inputData: "4\n10 -2 0 4", expectedOutput: "-2 0 4 10" },
          // 10 Hidden Tests
          { isPublic: false, inputData: "3\n3 2 1", expectedOutput: "1 2 3" },
          { isPublic: false, inputData: "6\n4 4 2 1 5 3", expectedOutput: "1 2 3 4 4 5" },
          { isPublic: false, inputData: "5\n9 8 5 2 1", expectedOutput: "1 2 5 8 9" },
          { isPublic: false, inputData: "3\n1 2 3", expectedOutput: "1 2 3" },
          { isPublic: false, inputData: "1\n42", expectedOutput: "42" },
          { isPublic: false, inputData: "5\n-5 -10 0 5 -2", expectedOutput: "-10 -5 -2 0 5" },
          { isPublic: false, inputData: "4\n7 7 7 7", expectedOutput: "7 7 7 7" },
          { isPublic: false, inputData: "6\n100 20 50 10 30 40", expectedOutput: "10 20 30 40 50 100" },
          { isPublic: false, inputData: "2\n2 1", expectedOutput: "1 2" },
          { isPublic: false, inputData: "5\n0 0 1 0 0", expectedOutput: "0 0 0 0 1" }
        ]
      }
    }
  });

  const p3 = await prisma.problem.create({
    data: {
      title: `Recherche Dichotomique dans un Tableau Trié (Final ${Date.now()})`,
      description: 'Rechercher la position de l\'élément Val dans un tableau trié T de N éléments. Retourner -1 si absent.',
      topic: 'RECHERCHE',
      difficulty: 'HARD',
      points: 5,
      referenceSolution: `Algorithme RechercheDicho;\nVar N, Val, inf, sup, milieu, pos, T[100] : Entier;\nDebut\n  Lire(N); Lire(Val);\n  Pour inf := 1 a N Faire Lire(T[inf]); Fin Pour;\n  inf := 1; sup := N; pos := -1;\n  TantQue (inf <= sup) Et (pos = -1) Faire\n    milieu := (inf + sup) Div 2;\n    Si T[milieu] = Val Alors\n      pos := milieu;\n    Sinon\n      Si Val < T[milieu] Alors sup := milieu - 1; Sinon inf := milieu + 1; Fin Si;\n    Fin Si;\n  Fin TantQue;\n  Ecrire(pos);\nFin.`,
      templateCode: { ALGO: `ALGORITHME Recherche_Dichotomique\nVARIABLES\nDEBUT\nFIN.` },
      testCases: {
        create: [
          // 2 Public Tests
          { isPublic: true, inputData: "5\n20\n10 20 30 40 50", expectedOutput: "2" },
          { isPublic: true, inputData: "5\n99\n10 20 30 40 50", expectedOutput: "-1" },
          // 10 Hidden Tests
          { isPublic: false, inputData: "1\n5\n5", expectedOutput: "1" },
          { isPublic: false, inputData: "1\n3\n5", expectedOutput: "-1" },
          { isPublic: false, inputData: "4\n10\n10 20 30 40", expectedOutput: "1" },
          { isPublic: false, inputData: "4\n40\n10 20 30 40", expectedOutput: "4" },
          { isPublic: false, inputData: "6\n35\n10 20 30 40 50 60", expectedOutput: "-1" },
          { isPublic: false, inputData: "3\n-5\n-10 -5 0", expectedOutput: "2" },
          { isPublic: false, inputData: "3\n-15\n-10 -5 0", expectedOutput: "-1" },
          { isPublic: false, inputData: "5\n1\n1 2 3 4 5", expectedOutput: "1" },
          { isPublic: false, inputData: "5\n5\n1 2 3 4 5", expectedOutput: "5" },
          { isPublic: false, inputData: "5\n3\n1 2 3 4 5", expectedOutput: "3" }
        ]
      }
    }
  });

  const p4 = await prisma.problem.create({
    data: {
      title: `Comptage des Voyelles dans une Chaîne (Final ${Date.now()})`,
      description: 'Compter le nombre total de voyelles (a, e, i, o, u) dans une chaîne de caractères.',
      topic: 'CHAINE',
      difficulty: 'EASY',
      points: 5,
      referenceSolution: `Algorithme CompterVoyelles;\nVar i, count, n : Entier; c : Caractere; S : Chaine;\nDebut\n  Lire(S);\n  count := 0;\n  n := Longueur(S);\n  Pour i := 1 a n Faire\n    c := S[i];\n    Si c = 'a' Ou c = 'e' Ou c = 'i' Ou c = 'o' Ou c = 'u' Alors\n      count := count + 1;\n    Fin Si;\n  Fin Pour;\n  Ecrire(count);\nFin.`,
      templateCode: { ALGO: `ALGORITHME Compter_Voyelles\nVARIABLES\nDEBUT\nFIN.` },
      testCases: {
        create: [
          // 2 Public Tests
          { isPublic: true, inputData: "bonjour", expectedOutput: "3" },
          { isPublic: true, inputData: "algo", expectedOutput: "2" },
          // 10 Hidden Tests
          { isPublic: false, inputData: "informatique", expectedOutput: "6" },
          { isPublic: false, inputData: "examen", expectedOutput: "3" },
          { isPublic: false, inputData: "xyz", expectedOutput: "0" },
          { isPublic: false, inputData: "aeiou", expectedOutput: "5" },
          { isPublic: false, inputData: "a", expectedOutput: "1" },
          { isPublic: false, inputData: "b", expectedOutput: "0" },
          { isPublic: false, inputData: "algorithmique", expectedOutput: "5" },
          { isPublic: false, inputData: "universite", expectedOutput: "5" },
          { isPublic: false, inputData: "etudiant", expectedOutput: "4" },
          { isPublic: false, inputData: "ordinateur", expectedOutput: "5" }
        ]
      }
    }
  });

  const problems = [p1, p2, p3, p4];

  // 4. Create Exam with Status FINISHED (Ungraded)
  const exam = await prisma.exam.create({
    data: {
      title: 'Examen Final Synthèse — Algorithmique (10 Étudiants, 4 Exercices)',
      prefix: 'EXAM2026-FINAL',
      status: 'FINISHED',
      durationMinutes: 120,
      teacherId: teacher.id,
      problems: {
        create: problems.map((p, idx) => ({
          problemId: p.id,
          orderIndex: idx + 1,
          points: 5
        }))
      }
    }
  });

  console.log(`✅ Exam Created: ${exam.title} (ID: ${exam.id})`);

  // 5. Code Submissions Profiles for 10 Students (10 diverse code profiles)
  const studentCodeProfiles = [
    // Student 1: BENALI Ahmed — 100% Perfect Code across all 4 exercises
    {
      [p1.id]: p1.referenceSolution,
      [p2.id]: p2.referenceSolution,
      [p3.id]: p3.referenceSolution,
      [p4.id]: p4.referenceSolution
    },

    // Student 2: KHELIFI Sara — Erreur d'opérateur (* au lieu de +) & Swap sans variable temporaire
    {
      [p1.id]: `Algorithme SommeMatrices;\nVar N, i, j, M1[10][10], M2[10][10], S[10][10] : Entier;\nDebut\n  Lire(N);\n  Pour i := 1 a N Faire Pour j := 1 a N Faire Lire(M1[i][j]); Fin Pour; Fin Pour;\n  Pour i := 1 a N Faire Pour j := 1 a N Faire Lire(M2[i][j]); Fin Pour; Fin Pour;\n  Pour i := 1 a N Faire Pour j := 1 a N Faire S[i][j] := M1[i][j] * M2[i][j]; Ecrire(S[i][j]); Fin Pour; Fin Pour;\nFin.`,
      [p2.id]: `Algorithme Tri;\nVar N, i, j, T[100] : Entier;\nDebut\n  Lire(N);\n  Pour i := 1 a N Faire Lire(T[i]); Fin Pour;\n  Pour i := 1 a N - 1 Faire\n    Pour j := 1 a N - i Faire\n      Si T[j] > T[j+1] Alors T[j] := T[j+1]; T[j+1] := T[j]; Fin Si;\n    Fin Pour;\n  Fin Pour;\n  Pour i := 1 a N Faire Ecrire(T[i]); Fin Pour;\nFin.`,
      [p3.id]: `Algorithme Dicho;\nVar N, Val, T[100] : Entier;\nDebut\n  Lire(N); Lire(Val);\n  Ecrire(-1);\nFin.`,
      [p4.id]: p4.referenceSolution
    },

    // Student 3: AMRANE Ali — Affichage Ecrire omis & Condition de tri inversée (< au lieu de >)
    {
      [p1.id]: `Algorithme SommeMatrices;\nVar N, i, j, M1[10][10], M2[10][10], S[10][10] : Entier;\nDebut\n  Lire(N);\n  Pour i := 1 a N Faire Pour j := 1 a N Faire Lire(M1[i][j]); Fin Pour; Fin Pour;\n  Pour i := 1 a N Faire Pour j := 1 a N Faire Lire(M2[i][j]); Fin Pour; Fin Pour;\n  Pour i := 1 a N Faire Pour j := 1 a N Faire S[i][j] := M1[i][j] + M2[i][j]; Fin Pour; Fin Pour;\nFin.`,
      [p2.id]: `Algorithme Tri;\nVar N, i, j, temp, T[100] : Entier;\nDebut\n  Lire(N);\n  Pour i := 1 a N Faire Lire(T[i]); Fin Pour;\n  Pour i := 1 a N - 1 Faire\n    Pour j := 1 a N - i Faire\n      Si T[j] < T[j+1] Alors temp := T[j]; T[j] := T[j+1]; T[j+1] := temp; Fin Si;\n    Fin Pour;\n  Fin Pour;\n  Pour i := 1 a N Faire Ecrire(T[i]); Fin Pour;\nFin.`,
      [p3.id]: p3.referenceSolution,
      [p4.id]: `Algorithme CompterVoy;\nVar i, count, n : Entier; c : Caractere; S : Chaine;\nDebut\n  Lire(S); count := 0; n := Longueur(S);\n  Pour i := 1 a n Faire c := S[i]; Si c = 'a' Ou c = 'e' Alors count := count + 1; Fin Si; Fin Pour;\n  Ecrire(count);\nFin.`
    },

    // Student 4: BOUMEDIENE Yasmine — Partial Code (Syntax Errors)
    {
      [p1.id]: `Algorithme Somme;\nVar N, i, j, M1[10][10], M2[10][10] : Entier;\nDebut\n  Lire(N);\nFin.`,
      [p2.id]: p2.referenceSolution,
      [p3.id]: `Algorithme Dicho;\nVar N : Entier;\nDebut\n  Lire(N);\nFin.`,
      [p4.id]: p4.referenceSolution
    },

    // Student 5: HAMDI Karim — Copie Blanche (Starter Template)
    {
      [p1.id]: p1.templateCode.ALGO,
      [p2.id]: p2.templateCode.ALGO,
      [p3.id]: p3.templateCode.ALGO,
      [p4.id]: p4.templateCode.ALGO
    },

    // Student 6: SAIDI Ryad — Very High Quality (100% on 3 problems)
    {
      [p1.id]: p1.referenceSolution,
      [p2.id]: p2.referenceSolution,
      [p3.id]: p3.referenceSolution,
      [p4.id]: `Algorithme CompterVoy;\nVar i, count, n : Entier; c : Caractere; S : Chaine;\nDebut\n  Lire(S); count := 0; n := Longueur(S);\n  Pour i := 1 a n Faire c := S[i]; Si c = 'a' Ou c = 'e' Ou c = 'i' Ou c = 'o' Ou c = 'u' Alors count := count + 1; Fin Si; Fin Pour;\n  Ecrire(count);\nFin.`
    },

    // Student 7: BELKACEM Lyna — Alternative TantQue Loop Structure
    {
      [p1.id]: `Algorithme SommeMatrices;\nVar N, i, j, M1[10][10], M2[10][10], S[10][10] : Entier;\nDebut\n  Lire(N);\n  i := 1;\n  TantQue i <= N Faire\n    j := 1;\n    TantQue j <= N Faire Lire(M1[i][j]); j := j + 1; Fin TantQue;\n    i := i + 1;\n  Fin TantQue;\n  i := 1;\n  TantQue i <= N Faire\n    j := 1;\n    TantQue j <= N Faire Lire(M2[i][j]); j := j + 1; Fin TantQue;\n    i := i + 1;\n  Fin TantQue;\n  i := 1;\n  TantQue i <= N Faire\n    j := 1;\n    TantQue j <= N Faire S[i][j] := M1[i][j] + M2[i][j]; Ecrire(S[i][j]); j := j + 1; Fin TantQue;\n    i := i + 1;\n  Fin TantQue;\nFin.`,
      [p2.id]: p2.referenceSolution,
      [p3.id]: p3.referenceSolution,
      [p4.id]: p4.referenceSolution
    },

    // Student 8: MEFTAH Yassine — Condition Logic Error ("Et" au lieu de "Ou")
    {
      [p1.id]: p1.referenceSolution,
      [p2.id]: p2.referenceSolution,
      [p3.id]: `Algorithme Dicho;\nVar N : Entier;\nDebut\n  Lire(N);\nFin.`,
      [p4.id]: `Algorithme CompterVoy;\nVar i, count, n : Entier; c : Caractere; S : Chaine;\nDebut\n  Lire(S); count := 0; n := Longueur(S);\n  Pour i := 1 a n Faire\n    c := S[i];\n    Si c = 'a' Et c = 'e' Et c = 'i' Alors count := count + 1; Fin Si;\n  Fin Pour;\n  Ecrire(count);\nFin.`
    },

    // Student 9: TOUATI Amina — Off-by-one Loop Bounds (0 à N au lieu de 1 à N)
    {
      [p1.id]: `Algorithme SommeMatrices;\nVar N, i, j, M1[10][10], M2[10][10], S[10][10] : Entier;\nDebut\n  Lire(N);\n  Pour i := 0 a N Faire Pour j := 0 a N Faire Lire(M1[i][j]); Fin Pour; Fin Pour;\n  Pour i := 0 a N Faire Pour j := 0 a N Faire Lire(M2[i][j]); Fin Pour; Fin Pour;\n  Pour i := 0 a N Faire Pour j := 0 a N Faire S[i][j] := M1[i][j] + M2[i][j]; Ecrire(S[i][j]); Fin Pour; Fin Pour;\nFin.`,
      [p2.id]: p2.referenceSolution,
      [p3.id]: p3.referenceSolution,
      [p4.id]: p4.referenceSolution
    },

    // Student 10: CHERIF Oumar — Copie Blanche (Starter Template)
    {
      [p1.id]: p1.templateCode.ALGO,
      [p2.id]: p2.templateCode.ALGO,
      [p3.id]: p3.templateCode.ALGO,
      [p4.id]: p4.templateCode.ALGO
    }
  ];

  // 6. Assign Exam to 10 Students with currentCodeMap & UNGRADED status
  for (let i = 0; i < dbStudents.length; i++) {
    const student = dbStudents[i];
    const codeMap = studentCodeProfiles[i] || studentCodeProfiles[4];

    await prisma.examAssignment.create({
      data: {
        examId: exam.id,
        studentId: student.id,
        accessNumber: `ESI-${100 + i + 1}`,
        status: 'FINISHED',
        gradingStatus: 'UNGRADED',
        finalScore: null,
        currentCodeMap: codeMap
      }
    });

    console.log(`📌 Student #${i + 1} (${student.lastName} ${student.firstName}) assigned (Status: UNGRADED).`);
  }

  console.log('🎉 Exam with 10 Students, 4 Exercises & 12 Tests/Problem successfully generated!');
}

seedExam10Students()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
