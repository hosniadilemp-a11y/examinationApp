# Listes d'Étudiants CSV pour AlgoExamination

Ce dossier contient des fichiers CSV prêts à être importés dans la plateforme **AlgoExamination** :
1. Soit dans l'**Espace Enseignant** (`/teacher` $\rightarrow$ *Bouton « Étudiants »* $\rightarrow$ *Importer CSV*).
2. Soit lors du **Lancement d'un Examen par Salle** (Option *« Téléverser un fichier CSV pour cette salle »*).

---

## 📁 Fichiers Disponibles

| Fichier | Salle / Contexte | Effectif | Groupes |
|---|---|---|---|
| [`salle_101_groupe_G1.csv`](./salle_101_groupe_G1.csv) | Salle 101 | 15 étudiants | `G01` |
| [`salle_102_groupe_G2.csv`](./salle_102_groupe_G2.csv) | Salle 102 | 15 étudiants | `G02` |
| [`amphi_A_promotion_complete.csv`](./amphi_A_promotion_complete.csv) | Amphi A (Promotion Complète) | 30 étudiants | `G01` + `G02` |

---

## 📋 Format des Colonnes

Le système accepte automatiquement les séparateurs virgule (`,`) ou point-virgule (`;`) avec les en-têtes suivants :

- `StudentID` : Numéro d'inscription / Matricule unique de l'étudiant (ex: `20260001`).
- `FirstName` : Prénom de l'étudiant.
- `LastName` : Nom de famille de l'étudiant.
- `Group` : Groupe de TD / TP (ex: `G01`, `G02`).
- `Speciality` : Spécialité ou filière (ex: `Informatique (ASD)`).
- `AcademicYear` : Année académique (ex: `2026`).
