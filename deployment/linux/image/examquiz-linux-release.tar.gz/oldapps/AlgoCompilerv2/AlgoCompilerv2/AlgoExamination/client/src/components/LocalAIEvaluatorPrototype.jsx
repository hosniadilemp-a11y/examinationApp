import React, { useState, useEffect } from 'react';
import { 
  Play, RefreshCw, Trash2, CheckCircle2, AlertTriangle, XCircle, HelpCircle, 
  Sparkles, Code2, Layers, Cpu, Clock, History, FileText, ChevronDown, ChevronUp, ArrowLeft,
  Terminal, GitBranch, Sliders, ShieldAlert, Award
} from 'lucide-react';
import Swal from 'sweetalert2';

const DEFAULT_SUITE_DATA = {
  problems: [
    {
      id: "somme_deux_entiers",
      title: "Somme de Deux Entiers",
      description: "Lire deux entiers A et B, calculer leur somme et afficher le résultat.",
      referenceSolution: `Algorithme Solution_Somme;\nVar\n   A, B, Somme : Entier;\nDebut\n   Lire(A);\n   Lire(B);\n   Somme := A + B;\n   Ecrire(Somme);\nFin.`,
      students: [
        { id: "p1_s1", title: "Student 1 — Identical", sourceCode: `Algorithme Somme_Etudiant1;\nVar\n   A, B, Somme : Entier;\nDebut\n   Lire(A);\n   Lire(B);\n   Somme := A + B;\n   Ecrire(Somme);\nFin.` },
        { id: "p1_s2", title: "Student 2 — Equivalent Structure", sourceCode: `Algorithme Somme_Etudiant2;\nVar\n   x, y, res : Entier;\nDebut\n   Lire(x, y);\n   res := x + y;\n   Ecrire("La somme est : ", res);\nFin.` },
        { id: "p1_s3", title: "Student 3 — Renamed Variables", sourceCode: `Algorithme Somme_Etudiant3;\nVar\n   premierNombre, secondNombre, totalSomme : Entier;\nDebut\n   Lire(premierNombre);\n   Lire(secondNombre);\n   totalSomme := premierNombre + secondNombre;\n   Ecrire(totalSomme);\nFin.` },
        { id: "p1_s4", title: "Student 4 — Incorrect Operator Bug", sourceCode: `Algorithme Somme_Etudiant4;\nVar\n   A, B, Somme : Entier;\nDebut\n   Lire(A);\n   Lire(B);\n   Somme := A * B;\n   Ecrire(Somme);\nFin.` },
        { id: "p1_s5", title: "Student 5 — Partial Credit (Missing Output)", sourceCode: `Algorithme Somme_Etudiant5;\nVar\n   A, B, Somme : Entier;\nDebut\n   Lire(A);\n   Lire(B);\n   Somme := A + B;\nFin.` },
        { id: "p1_s6", title: "Student 6 — Unrelated Code", sourceCode: `Algorithme Somme_Etudiant6;\nVar\n   msg : Chaine;\nDebut\n   msg := "Bonjour tout le monde";\n   Ecrire(msg);\nFin.` }
      ]
    },
    {
      id: "tri_a_bulles",
      title: "Tri à Bulles (Bubble Sort)",
      description: "Trier un tableau T de N entiers par ordre croissant en utilisant l'algorithme du Tri à Bulles.",
      referenceSolution: `Algorithme Solution_Tri_Bulles;\nVar\n   N, i, j, temp : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 1 a N - 1 Faire\n      Pour j := 1 a N - i Faire\n         Si (T[j] > T[j+1]) Alors\n            temp := T[j]; T[j] := T[j+1]; T[j+1] := temp;\n         FinSi;\n      FinPour;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.`,
      students: [
        { id: "p2_s1", title: "Student 1 — Identical", sourceCode: `Algorithme TriBulles_Etudiant1;\nVar\n   N, i, j, temp : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 1 a N - 1 Faire\n      Pour j := 1 a N - i Faire\n         Si (T[j] > T[j+1]) Alors\n            temp := T[j]; T[j] := T[j+1]; T[j+1] := temp;\n         FinSi;\n      FinPour;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.` },
        { id: "p2_s2", title: "Student 2 — Equivalent (Boolean Swap Flag)", sourceCode: `Algorithme TriBulles_Etudiant2;\nVar\n   N, i, temp : Entier;\n   echange : Booleen;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Répéter\n      echange := Faux;\n      Pour i := 1 a N - 1 Faire\n         Si (T[i] > T[i+1]) Alors\n            temp := T[i]; T[i] := T[i+1]; T[i+1] := temp;\n            echange := Vrai;\n         FinSi;\n      FinPour;\n   Jusqu'à (Non echange);\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.` },
        { id: "p2_s3", title: "Student 3 — Renamed Variables", sourceCode: `Algorithme TriBulles_Etudiant3;\nVar\n   taille, p, q, valTemp : Entier;\n   TableauEntiers[100] : Entier;\nDebut\n   Lire(taille);\n   Pour p := 1 a taille Faire Lire(TableauEntiers[p]); FinPour;\n   Pour p := 1 a taille - 1 Faire\n      Pour q := 1 a taille - p Faire\n         Si (TableauEntiers[q] > TableauEntiers[q+1]) Alors\n            valTemp := TableauEntiers[q];\n            TableauEntiers[q] := TableauEntiers[q+1];\n            TableauEntiers[q+1] := valTemp;\n         FinSi;\n      FinPour;\n   FinPour;\n   Pour p := 1 a taille Faire Ecrire(TableauEntiers[p], " "); FinPour;\nFin.` },
        { id: "p2_s4", title: "Student 4 — Incorrect Swap Bug", sourceCode: `Algorithme TriBulles_Etudiant4;\nVar\n   N, i, j, temp : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 1 a N - 1 Faire\n      Pour j := 1 a N - i Faire\n         Si (T[j] > T[j+1]) Alors\n            temp := T[j]; T[j+1] := temp; T[j] := T[j+1];\n         FinSi;\n      FinPour;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.` },
        { id: "p2_s5", title: "Student 5 — Partial Credit (Outer Loop Bound Off-by-one)", sourceCode: `Algorithme TriBulles_Etudiant5;\nVar\n   N, i, j, temp : Entier;\n   T[100] : Entier;\nDebut\n   Lire(N);\n   Pour i := 1 a N Faire Lire(T[i]); FinPour;\n   Pour i := 1 a N Faire\n      Pour j := 1 a N Faire\n         Si (T[j] > T[j+1]) Alors\n            temp := T[j]; T[j] := T[j+1]; T[j+1] := temp;\n         FinSi;\n      FinPour;\n   FinPour;\n   Pour i := 1 a N Faire Ecrire(T[i], " "); FinPour;\nFin.` },
        { id: "p2_s6", title: "Student 6 — Unrelated Code", sourceCode: `Algorithme TriBulles_Etudiant6;\nVar\n   N, fact, i : Entier;\nDebut\n   Lire(N);\n   fact := 1;\n   Pour i := 1 a N Faire fact := fact * i; FinPour;\n   Ecrire(fact);\nFin.` }
      ]
    },
    {
      id: "compter_voyelles",
      title: "Compter le Nombre de Voyelles",
      description: "Compter et afficher le nombre total de voyelles (a, e, i, o, u, y) contenues dans une chaîne de caractères str.",
      referenceSolution: `Algorithme Solution_Compter_Voyelles;\nVar\n   str : Chaine;\n   i, count, len : Entier;\n   c : Caractere;\nDebut\n   Lire(str);\n   count := 0;\n   len := Longueur(str);\n   Pour i := 1 a len Faire\n      c := str[i];\n      Si (c = 'a') Ou (c = 'e') Ou (c = 'i') Ou (c = 'o') Ou (c = 'u') Ou (c = 'y') Alors\n         count := count + 1;\n      FinSi;\n   FinPour;\n   Ecrire(count);\nFin.`,
      students: [
        { id: "p3_s1", title: "Student 1 — Identical", sourceCode: `Algorithme Voyelles_Etudiant1;\nVar\n   str : Chaine;\n   i, count, len : Entier;\n   c : Caractere;\nDebut\n   Lire(str);\n   count := 0;\n   len := Longueur(str);\n   Pour i := 1 a len Faire\n      c := str[i];\n      Si (c = 'a') Ou (c = 'e') Ou (c = 'i') Ou (c = 'o') Ou (c = 'u') Ou (c = 'y') Alors\n         count := count + 1;\n      FinSi;\n   FinPour;\n   Ecrire(count);\nFin.` },
        { id: "p3_s2", title: "Student 2 — Equivalent (Selon/Case)", sourceCode: `Algorithme Voyelles_Etudiant2;\nVar\n   chaineSaisie : Chaine;\n   idx, nbVoyelles : Entier;\nDebut\n   Lire(chaineSaisie);\n   nbVoyelles := 0;\n   Pour idx := 1 a Longueur(chaineSaisie) Faire\n      Selon (chaineSaisie[idx]) Faire\n         Cas 'a', 'e', 'i', 'o', 'u', 'y', 'A', 'E', 'I', 'O', 'U', 'Y':\n            nbVoyelles := nbVoyelles + 1;\n      FinSelon;\n   FinPour;\n   Ecrire(nbVoyelles);\nFin.` },
        { id: "p3_s3", title: "Student 3 — Renamed Variables", sourceCode: `Algorithme Voyelles_Etudiant3;\nVar\n   texteEntree : Chaine;\n   k, totalVoyelles, tailleTexte : Entier;\n   caractereCourant : Caractere;\nDebut\n   Lire(texteEntree);\n   totalVoyelles := 0;\n   tailleTexte := Longueur(texteEntree);\n   Pour k := 1 a tailleTexte Faire\n      caractereCourant := texteEntree[k];\n      Si (caractereCourant = 'a') Ou (caractereCourant = 'e') Ou (caractereCourant = 'i') Ou (caractereCourant = 'o') Ou (caractereCourant = 'u') Ou (caractereCourant = 'y') Alors\n         totalVoyelles := totalVoyelles + 1;\n      FinSi;\n   FinPour;\n   Ecrire(totalVoyelles);\nFin.` },
        { id: "p3_s4", title: "Student 4 — Incorrect Condition Bug", sourceCode: `Algorithme Voyelles_Etudiant4;\nVar\n   str : Chaine;\n   i, count : Entier;\n   c : Caractere;\nDebut\n   Lire(str);\n   count := 0;\n   Pour i := 1 a Longueur(str) Faire\n      c := str[i];\n      Si (c = 'a') Et (c = 'e') Et (c = 'i') Et (c = 'o') Et (c = 'u') Alors\n         count := count + 1;\n      FinSi;\n   FinPour;\n   Ecrire(count);\nFin.` },
        { id: "p3_s5", title: "Student 5 — Partial Credit (Missed vowels)", sourceCode: `Algorithme Voyelles_Etudiant5;\nVar\n   str : Chaine;\n   i, count : Entier;\n   c : Caractere;\nDebut\n   Lire(str);\n   count := 0;\n   Pour i := 1 a Longueur(str) Faire\n      c := str[i];\n      Si (c = 'a') Ou (c = 'e') Ou (c = 'i') Ou (c = 'o') Alors\n         count := count + 1;\n      FinSi;\n   FinPour;\n   Ecrire(count);\nFin.` },
        { id: "p3_s6", title: "Student 6 — Unrelated Code", sourceCode: `Algorithme Voyelles_Etudiant6;\nVar\n   val, i : Entier;\nDebut\n   Lire(val);\n   Pour i := 1 a 10 Faire\n      Ecrire(val * i);\n   FinPour;\nFin.` }
      ]
    }
  ]
};

export default function LocalAIEvaluatorPrototype({ onBack }) {
  const [problemsData, setProblemsData] = useState(DEFAULT_SUITE_DATA);
  const [selectedProblemId, setSelectedProblemId] = useState('somme_deux_entiers');
  const [studentCode, setStudentCode] = useState(DEFAULT_SUITE_DATA.problems[0].students[0].sourceCode);
  const [loading, setLoading] = useState(false);
  const [evalProgressStep, setEvalProgressStep] = useState('');
  const [evaluationResult, setEvaluationResult] = useState(null);
  const [activeLangTab, setActiveLangTab] = useState('FR');
  const [history, setHistory] = useState([]);
  const [historyOpen, setHistoryOpen] = useState(true);

  // Dynamic Module Weight Sliders State (Defaults: Sandbox=50%, AST=25%, AI=25%)
  const [weightSandbox, setWeightSandbox] = useState(50);
  const [weightAst, setWeightAst] = useState(25);
  const [weightAi, setWeightAi] = useState(25);
  const [selectedModel, setSelectedModel] = useState('qwen2.5-coder:1.5b');

  // Benchmark Tab & Cohort Matrix State
  const [activeTab, setActiveTab] = useState('lab'); // 'lab' | 'benchmark'
  const [benchmarkData, setBenchmarkData] = useState(null);
  const [benchmarkLoading, setBenchmarkLoading] = useState(false);
  const [aiVariantMode, setAiVariantMode] = useState('ponderation'); // 'ponderation' | 'max' | 'min'
  const [customExpectedGrades, setCustomExpectedGrades] = useState({});

  const fetchBenchmarkData = async (probId = selectedProblemId, variantMode = aiVariantMode) => {
    setBenchmarkLoading(true);
    try {
      const res = await fetch('/api/prototype/benchmark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problemId: probId,
          weights: {
            sandbox: weightSandbox,
            ast: weightAst,
            ai: weightAi
          },
          aiVariantMode: variantMode
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch benchmark');
      setBenchmarkData(data);
    } catch (err) {
      console.error('Benchmark fetch error:', err);
    } finally {
      setBenchmarkLoading(false);
    }
  };

  // Load problems from API on mount
  useEffect(() => {
    fetch('/api/prototype/problems')
      .then(res => res.json())
      .then(data => {
        if (data && data.problems && data.problems.length > 0) {
          setProblemsData(data);
        }
      })
      .catch(err => {
        console.warn('Using default suite fallback:', err);
      });
  }, []);

  const currentProblem = problemsData?.problems?.find(p => p.id === selectedProblemId) || problemsData?.problems?.[0];

  const handleSelectProblem = (id) => {
    setSelectedProblemId(id);
    const p = problemsData?.problems?.find(prob => prob.id === id);
    if (p && p.students && p.students.length > 0) {
      setStudentCode(p.students[0].sourceCode);
    } else {
      setStudentCode('');
    }
    setEvaluationResult(null);
  };

  const handleLoadStudentTest = (studentTest) => {
    setStudentCode(studentTest.sourceCode);
  };

  const handleEvaluate = async () => {
    if (!studentCode || !studentCode.trim()) {
      Swal.fire('Code Vide', 'Veuillez saisir ou coller un algorithme à évaluer.', 'warning');
      return;
    }

    setLoading(true);
    setEvaluationResult(null);

    const steps = [
      '⚡ Exécution des cas de test en Sandbox AlgoCompiler (Module 1)...',
      '🌳 Analyseur Syntaxique & Arbre AST (Module 2)...',
      `🧠 Évaluation Logique (${selectedModel}) & Barème (Module 3)...`,
      '📊 Calcul de la Similitude & Clustering AST (Module 4)...'
    ];

    for (let i = 0; i < steps.length; i++) {
      setEvalProgressStep(steps[i]);
      await new Promise(r => setTimeout(r, 450));
    }

    try {
      const res = await fetch('/api/prototype/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problemId: selectedProblemId,
          studentCode,
          selectedModel,
          weights: {
            sandbox: weightSandbox,
            ast: weightAst,
            ai: weightAi
          }
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Evaluation failed');

      setEvaluationResult(data);

      // Add to session history
      const historyItem = {
        id: Date.now(),
        problemTitle: currentProblem?.title || selectedProblemId,
        compositeScore: data.compositeScore.scorePct,
        timestamp: new Date().toLocaleTimeString(),
        data
      };
      setHistory(prev => [historyItem, ...prev]);
    } catch (err) {
      Swal.fire('Erreur d\'Évaluation', err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const getClassificationBadge = (cls) => {
    switch (cls) {
      case 'correct': return <span style={badgeStyle('#10b981', '#064e3b')}><CheckCircle2 size={15} /> Correct</span>;
      case 'partially_correct': return <span style={badgeStyle('#f59e0b', '#78350f')}><AlertTriangle size={15} /> Partiellement Correct</span>;
      case 'incorrect': return <span style={badgeStyle('#ef4444', '#7f1d1d')}><XCircle size={15} /> Incorrect</span>;
      default: return <span style={badgeStyle('#6b7280', '#1f2937')}><HelpCircle size={15} /> Hors-Sujet</span>;
    }
  };

  // Live Recalculate Composite Score on Slider Change
  const recalculatedComposite = evaluationResult ? Math.round(
    (evaluationResult.module1_sandbox.score * (weightSandbox / 100)) +
    (evaluationResult.module2_ast.score * (weightAst / 100)) +
    (evaluationResult.module3_ai.score * (weightAi / 100))
  ) : 0;

  return (
    <div style={{ padding: '24px', maxWidth: '1450px', margin: '0 auto', fontFamily: 'Inter, system-ui, sans-serif', color: '#f3f4f6' }}>
      
      {/* Top Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', background: 'linear-gradient(135deg, #1e293b, #0f172a)', padding: '20px', borderRadius: '16px', border: '1px solid #334155', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'linear-gradient(135deg, #6366f1, #3b82f6)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 12px rgba(99,102,241,0.4)' }}>
            <Sparkles size={26} color="#fff" />
          </div>
          <div>
            <h1 style={{ margin: 0, fontSize: '22px', fontWeight: '700', letterSpacing: '-0.5px' }}>
              🧪 Hybrid Tri-Engine Exam Correction Lab <span style={{ fontSize: '13px', background: '#3b82f6', padding: '2px 10px', borderRadius: '20px', marginLeft: '8px' }}>FULL MULTI-MODULE</span>
            </h1>
            <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: '#94a3b8' }}>
              Module 1 (Sandbox Execution) + Module 2 (AST Analyzer) + Module 3 (Local AI Logic) + Module 4 (Similarity Cluster)
            </p>
          </div>
        </div>

        {onBack && (
          <button onClick={onBack} style={btnSecondaryStyle}>
            <ArrowLeft size={16} /> Retour Dashboard
          </button>
        )}
      </div>

      {/* VIEW SWITCHER TABS: LAB VS COHORT BENCHMARK */}
      <div style={{ display: 'flex', gap: '16px', marginBottom: '24px' }}>
        <button
          onClick={() => setActiveTab('lab')}
          style={{
            flex: 1,
            padding: '14px 24px',
            borderRadius: '14px',
            fontSize: '15px',
            fontWeight: '700',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '10px',
            transition: 'all 0.2s',
            background: activeTab === 'lab' ? 'linear-gradient(135deg, #6366f1, #3b82f6)' : '#1e293b',
            color: '#fff',
            border: activeTab === 'lab' ? '2px solid #818cf8' : '1px solid #334155',
            boxShadow: activeTab === 'lab' ? '0 6px 20px rgba(99,102,241,0.4)' : 'none'
          }}
        >
          <Code2 size={20} /> 🧪 Laboratoire d'Évaluation (Vue Individuelle)
        </button>

        <button
          onClick={() => {
            setActiveTab('benchmark');
            fetchBenchmarkData(selectedProblemId);
          }}
          style={{
            flex: 1,
            padding: '14px 24px',
            borderRadius: '14px',
            fontSize: '15px',
            fontWeight: '700',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '10px',
            transition: 'all 0.2s',
            background: activeTab === 'benchmark' ? 'linear-gradient(135deg, #ec4899, #8b5cf6)' : '#1e293b',
            color: '#fff',
            border: activeTab === 'benchmark' ? '2px solid #f472b6' : '1px solid #334155',
            boxShadow: activeTab === 'benchmark' ? '0 6px 20px rgba(236,72,153,0.4)' : 'none'
          }}
        >
          <Award size={20} /> 📊 Tableau Comparatif de la Cohorte & 4 Modèles IA
        </button>
      </div>

      {/* Dynamic Weighting Sliders Control Bar */}
      <div style={{ ...cardStyle, marginBottom: '24px', borderColor: '#6366f1', background: 'linear-gradient(135deg, #1e1b4b, #0f172a)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
          <span style={{ fontSize: '14px', fontWeight: '700', color: '#a5b4fc', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Sliders size={18} /> Réglage Dynamique des Poids des 3 Moteurs de Correction :
          </span>
          <span style={{ fontSize: '12px', background: '#312e81', color: '#c7d2fe', padding: '4px 12px', borderRadius: '20px' }}>
            Total Poids : {weightSandbox + weightAst + weightAi}%
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
          {/* Module 1 Slider */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
              <span style={{ color: '#60a5fa' }}>🏃 Module 1 (Sandbox Tests)</span>
              <span style={{ fontWeight: '700', color: '#60a5fa' }}>{weightSandbox}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={weightSandbox}
              onChange={(e) => setWeightSandbox(Number(e.target.value))}
              style={{ width: '100%', accentColor: '#3b82f6' }}
            />
          </div>

          {/* Module 2 Slider */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
              <span style={{ color: '#a78bfa' }}>🌳 Module 2 (Analyseur AST)</span>
              <span style={{ fontWeight: '700', color: '#a78bfa' }}>{weightAst}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={weightAst}
              onChange={(e) => setWeightAst(Number(e.target.value))}
              style={{ width: '100%', accentColor: '#8b5cf6' }}
            />
          </div>

          {/* Module 3 Slider */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
              <span style={{ color: '#f472b6' }}>🧠 Module 3 (IA Logique)</span>
              <span style={{ fontWeight: '700', color: '#f472b6' }}>{weightAi}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={weightAi}
              onChange={(e) => setWeightAi(Number(e.target.value))}
              style={{ width: '100%', accentColor: '#ec4899' }}
            />
          </div>
        </div>

        {/* Local LLM Model Selector Row */}
        <div style={{ marginTop: '16px', paddingTop: '14px', borderTop: '1px solid #312e81', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Cpu size={18} color="#38bdf8" />
            <span style={{ fontSize: '13px', fontWeight: '600', color: '#38bdf8' }}>
              🤖 Sélection du Modèle LLM Local (Ollama) :
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              style={{
                background: '#0f172a',
                color: '#38bdf8',
                border: '1px solid #38bdf8',
                padding: '6px 14px',
                borderRadius: '8px',
                fontSize: '13px',
                fontWeight: '600',
                outline: 'none',
                cursor: 'pointer'
              }}
            >
              <option value="qwen2.5-coder:1.5b">⚡ Qwen2.5-Coder 1.5B (Fast — ~1.0 GB RAM)</option>
              <option value="qwen2.5-coder:3b">🧠 Qwen2.5-Coder 3B (Recommandé — ~2.2 GB RAM)</option>
              <option value="deepseek-coder:1.3b">🔍 DeepSeek-Coder 1.3B (~1.1 GB RAM)</option>
              <option value="phi3:mini">⚡ Phi-3-Mini 3.8B (~2.6 GB RAM)</option>
            </select>
            <span style={{ fontSize: '11px', color: '#94a3b8' }}>
              Footprint RAM optimisé pour 8 Go RAM
            </span>
          </div>
        </div>
      </div>

      {/* TAB 1: INDIVIDUAL LAB TESTING GRID */}
      {activeTab === 'lab' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          
          {/* Left Column: Problem & Teacher Solution & Quick Tests */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            
            {/* Problem Selector Card */}
            <div style={cardStyle}>
              <label style={{ fontSize: '14px', fontWeight: '600', color: '#93c5fd', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                <Layers size={18} /> Sélectionner un Problème d'Examen :
              </label>
              
              <select
                value={selectedProblemId}
                onChange={(e) => handleSelectProblem(e.target.value)}
                style={selectStyle}
              >
                {problemsData?.problems?.map(p => (
                  <option key={p.id} value={p.id} style={{ background: '#1e293b' }}>
                    📌 {p.title} ({p.id})
                  </option>
                ))}
              </select>

              {currentProblem && (
                <div style={{ marginTop: '16px', background: '#0f172a', padding: '16px', borderRadius: '12px', border: '1px solid #1e293b' }}>
                  <h3 style={{ margin: '0 0 8px 0', fontSize: '16px', color: '#60a5fa' }}>{currentProblem.title}</h3>
                  <p style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#cbd5e1', lineHeight: '1.5' }}>{currentProblem.description}</p>
                </div>
              )}
            </div>

            {/* Teacher Reference Solution Card */}
            <div style={cardStyle}>
              <h3 style={{ margin: '0 0 12px 0', fontSize: '15px', color: '#34d399', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <FileText size={18} /> Solution Repère Enseignant (Référence) :
              </h3>
              
              <div style={codeBoxStyle}>
                <pre style={{ margin: 0, fontFamily: 'Fira Code, monospace', fontSize: '13px', lineHeight: '1.6', color: '#a7f3d0' }}>
                  {currentProblem?.referenceSolution}
                </pre>
              </div>
            </div>

            {/* Quick Predefined Test Generators */}
            <div style={cardStyle}>
              <h4 style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#c084fc', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Sparkles size={16} /> Charger un Exemple de Soumission Étudiant (6 Cas) :
              </h4>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                {currentProblem?.students?.map((sTest, idx) => (
                  <button
                    key={sTest.id}
                    onClick={() => handleLoadStudentTest(sTest)}
                    style={sTestBtnStyle}
                  >
                    ⚡ Test {idx + 1}: {sTest.title.split('—')[1] || sTest.title}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Code Editor & Multi-Module Output Cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            
            {/* Student Editor Card */}
            <div style={cardStyle}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                <h3 style={{ margin: 0, fontSize: '15px', color: '#93c5fd', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Code2 size={18} /> Pseudo-Code Étudiant à Évaluer :
                </h3>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button onClick={() => setStudentCode('')} style={smallBtnStyle}>
                    <Trash2 size={14} /> Effacer
                  </button>
                  <button onClick={() => handleSelectProblem(selectedProblemId)} style={smallBtnStyle}>
                    <RefreshCw size={14} /> Réinitialiser
                  </button>
                </div>
              </div>

              <textarea
                value={studentCode}
                onChange={(e) => setStudentCode(e.target.value)}
                placeholder="Saisissez ou collez l'algorithme en pseudo-code ici..."
                style={textareaStyle}
              />

              <div style={{ marginTop: '16px', display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  onClick={handleEvaluate}
                  disabled={loading}
                  style={btnPrimaryStyle}
                >
                  {loading ? <RefreshCw size={18} className="animate-spin" /> : <Play size={18} />}
                  {loading ? 'Évaluation des 4 Moteurs...' : 'Lancer la Correction Multi-Moteurs'}
                </button>
              </div>

              {loading && (
                <div style={{ marginTop: '16px', background: '#0f172a', padding: '16px', borderRadius: '12px', border: '1px solid #3b82f6' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#60a5fa', fontSize: '14px', fontWeight: '500' }}>
                    <Sparkles className="animate-spin" size={18} />
                    <span>{evalProgressStep}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Results: Multi-Module Score Summary & Output Display */}
            {evaluationResult && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                
                {/* MASTER HYBRID SCORE SUMMARY HEADER */}
                <div style={{ ...cardStyle, border: '2px solid #3b82f6', background: 'linear-gradient(135deg, #1e293b, #090d16)', boxShadow: '0 0 25px rgba(59,130,246,0.3)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', paddingBottom: '16px', borderBottom: '1px solid #334155' }}>
                    <div>
                      <span style={{ fontSize: '12px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '1px' }}>
                        🏆 Note Finale Composée Hybride
                      </span>
                      <div style={{ fontSize: '38px', fontWeight: '800', color: '#60a5fa', display: 'flex', alignItems: 'baseline', gap: '8px' }}>
                        {recalculatedComposite}%
                        <span style={{ fontSize: '20px', color: '#94a3b8', fontWeight: '500' }}>
                          ({(recalculatedComposite / 10).toFixed(1)}/10)
                        </span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px' }}>
                      {getClassificationBadge(evaluationResult.module3_ai.evaluation.classification)}
                      <span style={{ fontSize: '12px', color: '#a78bfa', background: '#2e1065', padding: '4px 10px', borderRadius: '6px', border: '1px solid #5b21b6' }}>
                        🔗 Cluster : {evaluationResult.module4_similarity.astClusterId}
                      </span>
                    </div>
                  </div>

                  {/* 3 INDIVIDUAL MODULE SCORES SIDE-BY-SIDE */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px' }}>
                    {/* Module 1 Box */}
                    <div style={{ background: '#0f172a', padding: '14px', borderRadius: '10px', border: '1px solid #3b82f6', textAlign: 'center' }}>
                      <span style={{ fontSize: '12px', color: '#60a5fa', fontWeight: '600' }}>🏃 Tests Automatiques</span>
                      <div style={{ fontSize: '24px', fontWeight: '800', color: '#93c5fd', margin: '4px 0' }}>
                        {evaluationResult.module1_sandbox.score}%
                      </div>
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>
                        {evaluationResult.module1_sandbox.passedRatio} Cas Passés ({weightSandbox}%)
                      </span>
                    </div>

                    {/* Module 2 Box */}
                    <div style={{ background: '#0f172a', padding: '14px', borderRadius: '10px', border: '1px solid #8b5cf6', textAlign: 'center' }}>
                      <span style={{ fontSize: '12px', color: '#c084fc', fontWeight: '600' }}>🌳 Structure AST</span>
                      <div style={{ fontSize: '24px', fontWeight: '800', color: '#e9d5ff', margin: '4px 0' }}>
                        {evaluationResult.module2_ast.score}% <span style={{ fontSize: '16px', color: '#c084fc' }}>({(evaluationResult.module2_ast.score / 10.0).toFixed(1)}/10)</span>
                      </div>
                      <span style={{ fontSize: '10px', color: '#a78bfa', display: 'block', marginBottom: '2px' }}>
                        Score AST Rééchelonné
                      </span>
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>
                        Brut AST: {evaluationResult.module2_ast.rawScore}% ({weightAst}%)
                      </span>
                    </div>

                    {/* Module 3 Box */}
                    <div style={{ background: '#0f172a', padding: '14px', borderRadius: '10px', border: '1px solid #ec4899', textAlign: 'center' }}>
                      <span style={{ fontSize: '12px', color: '#f472b6', fontWeight: '600' }}>🧠 Évaluation IA</span>
                      <div style={{ fontSize: '24px', fontWeight: '800', color: '#fbcfe8', margin: '4px 0' }}>
                        {evaluationResult.module3_ai.score}% <span style={{ fontSize: '16px', color: '#f472b6' }}>({(evaluationResult.module3_ai.score / 10.0).toFixed(1)}/10)</span>
                      </div>
                      <span style={{ fontSize: '10px', color: '#f472b6', display: 'block', marginBottom: '2px' }}>
                        Score IA Rééchelonné
                      </span>
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>
                        Brut IA: {evaluationResult.module3_ai.rawScore}% ({weightAi}%)
                      </span>
                    </div>
                  </div>
                </div>

                {/* MODULE 1 CARD: INTERACTIVE SANDBOX TEST MATRIX */}
                <div style={{ ...cardStyle, borderColor: '#3b82f6' }}>
                  <h4 style={{ margin: '0 0 14px 0', fontSize: '15px', color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Terminal size={18} /> Tests Automatiques (Score : {evaluationResult.module1_sandbox.score}%)
                  </h4>

                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px' }}>
                      <thead>
                        <tr style={{ background: '#0f172a', color: '#94a3b8', textAlign: 'left' }}>
                          <th style={{ padding: '10px' }}>Cas #</th>
                          <th style={{ padding: '10px' }}>Visibilité</th>
                          <th style={{ padding: '10px' }}>Entrée</th>
                          <th style={{ padding: '10px' }}>Sortie Attendue</th>
                          <th style={{ padding: '10px' }}>Sortie Obtenue</th>
                          <th style={{ padding: '10px' }}>Temps</th>
                          <th style={{ padding: '10px' }}>Statut</th>
                        </tr>
                      </thead>
                      <tbody>
                        {evaluationResult.module1_sandbox.testResults.map((tr) => (
                          <tr key={tr.id} style={{ borderBottom: '1px solid #1e293b' }}>
                            <td style={{ padding: '10px', fontWeight: '600' }}>Test #{tr.id}</td>
                            <td style={{ padding: '10px' }}>
                              {tr.isHidden ? (
                                <span style={badgeStyle('#7c3aed', '#f3e8ff')}>🔒 Caché</span>
                              ) : (
                                <span style={badgeStyle('#0284c7', '#e0f2fe')}>👁️ Public</span>
                              )}
                            </td>
                            <td style={{ padding: '10px', fontFamily: 'monospace', color: '#cbd5e1' }}>{tr.input}</td>
                            <td style={{ padding: '10px', fontFamily: 'monospace', color: '#34d399' }}>{tr.expected}</td>
                            <td style={{ padding: '10px', fontFamily: 'monospace', color: tr.status === 'PASS' ? '#34d399' : '#fca5a5' }}>{tr.actual}</td>
                            <td style={{ padding: '10px', color: '#94a3b8' }}>{tr.executionMs} ms</td>
                            <td style={{ padding: '10px' }}>
                              {tr.status === 'PASS' ? (
                                <span style={badgeStyle('#10b981', '#064e3b')}>PASS</span>
                              ) : (
                                <span style={badgeStyle('#ef4444', '#7f1d1d')}>{tr.status}</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* MODULE 2 CARD: STATIC AST & SYNTAX ANALYZER */}
                <div style={{ ...cardStyle, borderColor: '#8b5cf6' }}>
                  <h4 style={{ margin: '0 0 14px 0', fontSize: '15px', color: '#c084fc', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <GitBranch size={18} /> Structure AST (Score : {evaluationResult.module2_ast.score}%)
                  </h4>

                  {evaluationResult.module2_ast.rescaledNotice && (
                    <div style={{ fontSize: '11px', background: '#3b0764', color: '#e9d5ff', padding: '6px 12px', borderRadius: '6px', marginBottom: '12px', border: '1px solid #7e22ce' }}>
                      ℹ️ {evaluationResult.module2_ast.rescaledNotice}
                    </div>
                  )}

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '14px' }}>
                    <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px' }}>
                      <span style={{ fontSize: '12px', color: '#94a3b8' }}>Vérifications Structurales :</span>
                      <div style={{ display: 'flex', gap: '10px', marginTop: '6px', fontSize: '12px' }}>
                        <span style={{ color: evaluationResult.module2_ast.hasHeader ? '#34d399' : '#f87171' }}>
                          {evaluationResult.module2_ast.hasHeader ? '✓' : '✗'} En-tête ALGORITHME
                        </span>
                        <span style={{ color: evaluationResult.module2_ast.hasDebut ? '#34d399' : '#f87171' }}>
                          {evaluationResult.module2_ast.hasDebut ? '✓' : '✗'} DEBUT
                        </span>
                        <span style={{ color: evaluationResult.module2_ast.hasFin ? '#34d399' : '#f87171' }}>
                          {evaluationResult.module2_ast.hasFin ? '✓' : '✗'} FIN
                        </span>
                      </div>
                    </div>

                    <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px' }}>
                      <span style={{ fontSize: '12px', color: '#94a3b8' }}>Structures de Contrôle :</span>
                      <div style={{ display: 'flex', gap: '14px', marginTop: '6px', fontSize: '12px', color: '#cbd5e1' }}>
                        <span>Boucles POUR : {evaluationResult.module2_ast.nodes.loops}</span>
                        <span>Conditions SI : {evaluationResult.module2_ast.nodes.conditions}</span>
                      </div>
                    </div>
                  </div>

                  {evaluationResult.module2_ast.issues && evaluationResult.module2_ast.issues.length > 0 && (
                    <div style={{ background: '#451a03', border: '1px solid #b45309', padding: '12px', borderRadius: '8px', color: '#fcd34d', fontSize: '12px' }}>
                      <div style={{ fontWeight: '700', marginBottom: '4px' }}>Anomalies AST Détectées :</div>
                      <ul style={{ margin: 0, paddingLeft: '18px' }}>
                        {evaluationResult.module2_ast.issues.map((iss, i) => (
                          <li key={i}>{typeof iss === 'object' ? JSON.stringify(iss) : iss}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* MODULE 3 CARD: LOCAL AI RUBRIC ENGINE */}
                <div style={{ ...cardStyle, borderColor: '#ec4899' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                    <h4 style={{ margin: 0, fontSize: '15px', color: '#f472b6', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <BrainIcon size={18} /> Évaluation IA (Score : {evaluationResult.module3_ai.score}%)
                    </h4>

                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button onClick={() => setActiveLangTab('FR')} style={langTabStyle(activeLangTab === 'FR')}>🇫🇷 Français</button>
                      <button onClick={() => setActiveLangTab('EN')} style={langTabStyle(activeLangTab === 'EN')}>🇬🇧 English</button>
                    </div>
                  </div>

                  {/* 4-CRITERION RUBRIC BREAKDOWN BARS */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '16px', background: '#0f172a', padding: '16px', borderRadius: '12px' }}>
                    {dimensionBar('Correctitude Algorithmique (30%)', evaluationResult.module3_ai.evaluation.scores.algorithmic_correctness, '#60a5fa')}
                    {dimensionBar('Compréhension Idée Clé (25%)', evaluationResult.module3_ai.evaluation.scores.core_idea, '#a78bfa')}
                    {dimensionBar('Exactitude Logique & Flux (25%)', evaluationResult.module3_ai.evaluation.scores.logical_correctness, '#f472b6')}
                    {dimensionBar('Équivalence Sémantique (10%)', evaluationResult.module3_ai.evaluation.scores.semantic_equivalence, '#34d399')}
                  </div>

                  {/* FEEDBACK CARD */}
                  <div style={{ background: '#0f172a', padding: '16px', borderRadius: '12px', border: '1px solid #334155', marginBottom: '14px' }}>
                    <h5 style={{ margin: '0 0 8px 0', fontSize: '13px', color: '#f472b6' }}>💬 Appréciation & Feedback Pédagogique :</h5>
                    <p style={{ margin: 0, fontSize: '13px', color: '#e2e8f0', lineHeight: '1.6' }}>
                      {activeLangTab === 'FR' ? evaluationResult.module3_ai.evaluation.feedback_fr : evaluationResult.module3_ai.evaluation.feedback_en}
                    </p>
                  </div>

                  {/* DETECTED ERRORS LIST */}
                  {evaluationResult.module3_ai.evaluation.errors && evaluationResult.module3_ai.evaluation.errors.length > 0 && (
                    <div style={{ background: '#450a0a', border: '1px solid #991b1b', padding: '14px', borderRadius: '10px', color: '#fca5a5', fontSize: '13px' }}>
                      <h5 style={{ margin: '0 0 8px 0', fontSize: '13px', color: '#f87171', display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <ShieldAlert size={16} /> Erreurs Pédagogiques Identifiées ({evaluationResult.module3_ai.evaluation.errors.length}) :
                      </h5>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {evaluationResult.module3_ai.evaluation.errors.map((err, i) => (
                          <div key={i} style={{ background: '#7f1d1d', padding: '10px', borderRadius: '8px', fontSize: '12px' }}>
                            <div style={{ fontWeight: '700', color: '#fef2f2' }}>{err.description}</div>
                            <div style={{ color: '#fecaca', marginTop: '2px' }}>Impact: {err.impact} (Lieu: {err.location})</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* MODULE 4 CARD: SIMILARITY & PLAGIARISM CLUSTER */}
                <div style={{ ...cardStyle, borderColor: '#10b981' }}>
                  <h4 style={{ margin: '0 0 14px 0', fontSize: '15px', color: '#34d399', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Layers size={18} /> Module 4 : Groupement AST & Détection de Similitude (Score : {evaluationResult.module4_similarity.similarityPct}%)
                  </h4>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px', textCenter: 'center' }}>
                    <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px', textAlign: 'center' }}>
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>Similitude AST</span>
                      <div style={{ fontSize: '20px', fontWeight: '800', color: '#34d399' }}>
                        {evaluationResult.module4_similarity.similarityPct}%
                      </div>
                    </div>

                    <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px', textAlign: 'center' }}>
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>Identifiant du Cluster</span>
                      <div style={{ fontSize: '14px', fontWeight: '700', color: '#a78bfa', marginTop: '4px' }}>
                        {evaluationResult.module4_similarity.astClusterId}
                      </div>
                    </div>

                    <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px', textAlign: 'center' }}>
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>Niveau de Risque</span>
                      <div style={{ fontSize: '14px', fontWeight: '700', color: '#f59e0b', marginTop: '4px' }}>
                        {evaluationResult.module4_similarity.plagiarismRisk}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* History Panel */}
            {history.length > 0 && (
              <div style={cardStyle}>
                <div onClick={() => setHistoryOpen(!historyOpen)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}>
                  <h4 style={{ margin: 0, fontSize: '14px', color: '#cbd5e1', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <History size={16} /> Historique des Évaluations de la Session ({history.length})
                  </h4>
                  {historyOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </div>

                {historyOpen && (
                  <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '8px', maxHeight: '200px', overflowY: 'auto' }}>
                    {history.map((hItem) => (
                      <div key={hItem.id} onClick={() => setEvaluationResult(hItem.data)} style={historyItemStyle}>
                        <div style={{ fontWeight: '500', color: '#f3f4f6' }}>{hItem.problemTitle}</div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '12px' }}>
                          <span style={{ color: '#60a5fa', fontWeight: '700' }}>Note Composite : {hItem.compositeScore}%</span>
                          <span style={{ color: '#94a3b8' }}>{hItem.timestamp}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      )}

      {/* TAB 2: COHORT COMPARISON & 4 AI MODELS BENCHMARK MATRIX VIEW */}
      {activeTab === 'benchmark' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* Problem Selector & Summary Bar */}
          <div style={{ ...cardStyle, borderColor: '#ec4899', background: 'linear-gradient(135deg, #1f112e, #0f172a)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Layers size={24} color="#f472b6" />
                <h2 style={{ margin: 0, fontSize: '18px', color: '#f472b6', fontWeight: '700' }}>
                  📊 Tableau Comparatif de la Cohorte & 4 Modèles IA
                </h2>
              </div>

              <button
                onClick={() => fetchBenchmarkData(selectedProblemId)}
                disabled={benchmarkLoading}
                style={btnPrimaryStyle}
              >
                <RefreshCw size={16} className={benchmarkLoading ? "animate-spin" : ""} />
                {benchmarkLoading ? 'Calcul...' : 'Actualiser les Données'}
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: '16px', alignItems: 'center' }}>
              <div>
                <label style={{ fontSize: '13px', fontWeight: '600', color: '#cbd5e1', marginBottom: '6px', display: 'block' }}>
                  📌 Sélectionner un Problème d'Examen à Comparer :
                </label>
                <select
                  value={selectedProblemId}
                  onChange={(e) => {
                    setSelectedProblemId(e.target.value);
                    fetchBenchmarkData(e.target.value);
                  }}
                  style={selectStyle}
                >
                  {problemsData?.problems?.map(p => (
                    <option key={p.id} value={p.id} style={{ background: '#1e293b' }}>
                      📌 {p.title} ({p.id})
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ background: '#0f172a', padding: '12px', borderRadius: '10px', textAlign: 'center', border: '1px solid #334155' }}>
                <span style={{ fontSize: '11px', color: '#94a3b8' }}>Soumissions Étudiants</span>
                <div style={{ fontSize: '20px', fontWeight: '800', color: '#60a5fa' }}>10 Variations</div>
              </div>

              <div style={{ background: '#0f172a', padding: '12px', borderRadius: '10px', textAlign: 'center', border: '1px solid #334155' }}>
                <span style={{ fontSize: '11px', color: '#94a3b8' }}>Modèles LLM Comparés</span>
                <div style={{ fontSize: '20px', fontWeight: '800', color: '#c084fc' }}>4 Modèles IA</div>
              </div>

              <div style={{ background: '#0f172a', padding: '12px', borderRadius: '10px', textAlign: 'center', border: '1px solid #ef4444' }}>
                <span style={{ fontSize: '11px', color: '#fca5a5' }}>Seuil Grand Écart (Rouge)</span>
                <div style={{ fontSize: '20px', fontWeight: '800', color: '#ef4444' }}>Δ ≥ 2.5 pts</div>
              </div>
            </div>

            {/* Rescaling Rules Banner Notice */}
            <div style={{ background: '#0f172a', padding: '12px 18px', borderRadius: '10px', border: '1px solid #3b82f6', marginTop: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '12px' }}>
              <span style={{ color: '#93c5fd', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Layers size={16} /> 📏 Règles d'Échelle de Conversion en Notes (/10) :
              </span>
              <div style={{ display: 'flex', gap: '20px', color: '#cbd5e1' }}>
                <span>🌳 <b>Module 2 (AST)</b> : ≤30% brut ➔ <b>0.0 / 10</b> | 100% brut ➔ <b>10.0 / 10</b></span>
                <span>🧠 <b>Module 3 (IA)</b> : ≤20% brut ➔ <b>0.0 / 10</b> | 100% brut ➔ <b>10.0 / 10</b></span>
              </div>
            </div>
          </div>

          {/* Benchmark Grid Table */}
          {benchmarkLoading ? (
            <div style={{ ...cardStyle, textAlign: 'center', padding: '40px' }}>
              <RefreshCw size={32} className="animate-spin" color="#ec4899" style={{ margin: '0 auto 16px auto' }} />
              <h3 style={{ color: '#f472b6', margin: 0 }}>Génération et Calcul du Benchmark de la Cohorte...</h3>
              <p style={{ color: '#94a3b8', fontSize: '13px', marginTop: '6px' }}>Évaluation des 10 soumissions étudiants sur les 10 cas de test sandbox et les 4 modèles IA...</p>
            </div>
          ) : benchmarkData ? (
            <div style={{ ...cardStyle, borderColor: '#ec4899' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                <h3 style={{ margin: 0, fontSize: '16px', color: '#f472b6', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  📊 Matrice Interactive des Notes par Modèle IA (Problème : {benchmarkData.problemTitle})
                </h3>
                
                {/* AI Variant Mode Selector Buttons */}
                <div style={{ display: 'flex', gap: '8px', background: '#0f172a', padding: '4px', borderRadius: '10px', border: '1px solid #334155' }}>
                  <button
                    onClick={() => setAiVariantMode('ponderation')}
                    style={{
                      padding: '6px 12px',
                      borderRadius: '6px',
                      fontSize: '12px',
                      fontWeight: '700',
                      border: 'none',
                      cursor: 'pointer',
                      background: aiVariantMode === 'ponderation' ? '#3b82f6' : 'transparent',
                      color: aiVariantMode === 'ponderation' ? '#fff' : '#94a3b8'
                    }}
                  >
                    ⚖️ Pondération (Moyenne)
                  </button>
                  <button
                    onClick={() => setAiVariantMode('max')}
                    style={{
                      padding: '6px 12px',
                      borderRadius: '6px',
                      fontSize: '12px',
                      fontWeight: '700',
                      border: 'none',
                      cursor: 'pointer',
                      background: aiVariantMode === 'max' ? '#10b981' : 'transparent',
                      color: aiVariantMode === 'max' ? '#fff' : '#94a3b8'
                    }}
                  >
                    🚀 MAX (Optimiste)
                  </button>
                  <button
                    onClick={() => setAiVariantMode('min')}
                    style={{
                      padding: '6px 12px',
                      borderRadius: '6px',
                      fontSize: '12px',
                      fontWeight: '700',
                      border: 'none',
                      cursor: 'pointer',
                      background: aiVariantMode === 'min' ? '#ef4444' : 'transparent',
                      color: aiVariantMode === 'min' ? '#fff' : '#94a3b8'
                    }}
                  >
                    🔒 MIN (Stricte)
                  </button>
                </div>
              </div>

              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px', textAlign: 'center' }}>
                  <thead>
                    <tr style={{ background: '#0f172a', color: '#94a3b8', borderBottom: '2px solid #334155' }}>
                      <th style={{ padding: '12px', textAlign: 'left' }}>Étudiant & Variation Code</th>
                      <th style={{ padding: '12px' }}>🎯 Note Attendue</th>
                      <th style={{ padding: '12px', color: '#60a5fa' }}>🏃 Mod 1 (Sandbox)</th>
                      <th style={{ padding: '12px', color: '#c084fc' }}>🌳 Mod 2 (AST)</th>
                      <th style={{ padding: '12px', color: '#38bdf8' }}>🤖 Qwen 1.5B</th>
                      <th style={{ padding: '12px', color: '#38bdf8' }}>🤖 Qwen 3B</th>
                      <th style={{ padding: '12px', color: '#a78bfa' }}>🤖 DeepSeek 1.3B</th>
                      <th style={{ padding: '12px', color: '#f472b6' }}>🤖 Phi-3 3.8B</th>
                      <th style={{ padding: '12px', color: '#f59e0b' }}>🧠 Score IA ({aiVariantMode.toUpperCase()})</th>
                      <th style={{ padding: '12px', color: '#38bdf8' }}>🏆 Note Finale (/10)</th>
                      <th style={{ padding: '12px' }}>🚨 Écart / Discrépance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {benchmarkData.rows.map((row) => {
                      const activeExpectedGrade = customExpectedGrades[row.studentId] !== undefined
                        ? customExpectedGrades[row.studentId]
                        : row.expectedGradeOut10;

                      const activeAi = row.aiVariants[aiVariantMode] || row.aiVariants.ponderation;
                      const activeAiScorePct = activeAi.scorePct;

                      // Dynamic Client-side Composite Grade Calculation
                      const dynamicCompositeScorePct = Math.round(
                        (row.sandbox.scorePct * (weightSandbox / 100.0)) +
                        (row.ast.scorePct * (weightAst / 100.0)) +
                        (activeAiScorePct * (weightAi / 100.0))
                      );
                      const dynamicCompositeGradeOut10 = parseFloat((dynamicCompositeScorePct / 10.0).toFixed(1));

                      const dynamicDelta = parseFloat(Math.abs(dynamicCompositeGradeOut10 - activeExpectedGrade).toFixed(1));
                      const isRed = dynamicDelta >= 2.5;

                      return (
                        <tr key={row.studentId} style={{ borderBottom: '1px solid #1e293b', background: isRed ? 'rgba(239, 68, 68, 0.08)' : 'transparent' }}>
                          {/* Student Title */}
                          <td style={{ padding: '12px', textAlign: 'left', fontWeight: '600', color: isRed ? '#fca5a5' : '#f3f4f6' }}>
                            {row.studentTitle}
                          </td>

                          {/* Editable Expected Grade */}
                          <td style={{ padding: '12px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                              <input
                                type="number"
                                min="0"
                                max="10"
                                step="0.5"
                                value={activeExpectedGrade}
                                onChange={(e) => {
                                  const val = parseFloat(e.target.value) || 0;
                                  setCustomExpectedGrades(prev => ({ ...prev, [row.studentId]: val }));
                                }}
                                style={{
                                  width: '55px',
                                  padding: '4px 6px',
                                  borderRadius: '6px',
                                  background: '#0f172a',
                                  border: '1px solid #3b82f6',
                                  color: '#fbbf24',
                                  fontWeight: '800',
                                  fontSize: '13px',
                                  textAlign: 'center'
                                }}
                              />
                              <span style={{ fontSize: '11px', color: '#cbd5e1', fontWeight: '600' }}>/10</span>
                            </div>
                          </td>

                          {/* Sandbox: % + score/10 */}
                          <td style={{ padding: '12px' }}>
                            <div style={{ fontWeight: '700', color: row.sandbox.scorePct === 100 ? '#34d399' : (row.sandbox.scorePct > 0 ? '#fbbf24' : '#f87171') }}>
                              {row.sandbox.scorePct}% ({row.sandbox.scoreOut10}/10)
                            </div>
                            <span style={{ fontSize: '10px', color: '#94a3b8' }}>
                              {row.sandbox.passedRatio} cas passés
                            </span>
                          </td>

                          {/* AST: % + score/10 */}
                          <td style={{ padding: '12px' }}>
                            <div style={{ fontWeight: '700', color: row.ast.scorePct === 100 ? '#34d399' : (row.ast.scorePct > 0 ? '#c084fc' : '#f87171') }}>
                              {row.ast.scorePct}% ({row.ast.scoreOut10}/10)
                            </div>
                            <span style={{ fontSize: '10px', color: '#94a3b8' }}>
                              Brut: {row.ast.rawScore}%
                            </span>
                          </td>

                          {/* Model 1: Qwen 1.5B */}
                          <td style={{ padding: '12px', fontWeight: '600', color: '#38bdf8' }}>
                            {row.models.qwen1_5b.scoreOut10} / 10
                          </td>

                          {/* Model 2: Qwen 3B */}
                          <td style={{ padding: '12px', fontWeight: '600', color: '#38bdf8' }}>
                            {row.models.qwen3b.scoreOut10} / 10
                          </td>

                          {/* Model 3: DeepSeek 1.3B */}
                          <td style={{ padding: '12px', fontWeight: '600', color: '#a78bfa' }}>
                            {row.models.deepseek.scoreOut10} / 10
                          </td>

                          {/* Model 4: Phi-3 3.8B */}
                          <td style={{ padding: '12px', fontWeight: '600', color: '#f472b6' }}>
                            {row.models.phi3.scoreOut10} / 10
                          </td>

                          {/* Active AI Variant Score */}
                          <td style={{ padding: '12px' }}>
                            <span style={badgeStyle('#7c3aed', '#f3e8ff')}>
                              {activeAi.scorePct}% ({activeAi.scoreOut10}/10)
                            </span>
                          </td>

                          {/* Composite Final Grade */}
                          <td style={{ padding: '12px', fontSize: '14px', fontWeight: '800', color: isRed ? '#ef4444' : '#60a5fa' }}>
                            {dynamicCompositeGradeOut10} / 10
                          </td>

                          {/* Discrepancy Highlight */}
                          <td style={{ padding: '12px' }}>
                            {isRed ? (
                              <span style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '6px',
                                padding: '6px 12px',
                                borderRadius: '8px',
                                background: 'rgba(239, 68, 68, 0.25)',
                                color: '#fca5a5',
                                border: '1px solid #ef4444',
                                fontWeight: '800',
                                fontSize: '12px'
                              }}>
                                <AlertTriangle size={14} color="#ef4444" />
                                🚨 GRAND ÉCART (Δ {dynamicDelta})
                              </span>
                            ) : (
                              <span style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '6px',
                                padding: '6px 12px',
                                borderRadius: '8px',
                                background: 'rgba(16, 185, 129, 0.15)',
                                color: '#6ee7b7',
                                border: '1px solid #10b981',
                                fontWeight: '600',
                                fontSize: '12px'
                              }}>
                                <CheckCircle2 size={14} color="#10b981" />
                                Conforme (Δ {dynamicDelta})
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}

// Subcomponent helper for brain icon
function BrainIcon({ size }) {
  return <Sparkles size={size} />;
}

// Subcomponent helper for dimension progress bars
function dimensionBar(title, val, color) {
  const scoreVal = typeof val === 'number' ? val : 0;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#cbd5e1', marginBottom: '4px' }}>
        <span>{title}</span>
        <span style={{ fontWeight: '600', color }}>{scoreVal}%</span>
      </div>
      <div style={{ height: '8px', width: '100%', background: '#0f172a', borderRadius: '4px', overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${scoreVal}%`, background: color, borderRadius: '4px', transition: 'width 0.5s ease-in-out' }} />
      </div>
    </div>
  );
}

// Styling Utility Tokens
const cardStyle = {
  background: '#1e293b',
  padding: '20px',
  borderRadius: '16px',
  border: '1px solid #334155',
  boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
};

const selectStyle = {
  width: '100%',
  padding: '12px 16px',
  borderRadius: '10px',
  background: '#0f172a',
  border: '1px solid #3b82f6',
  color: '#fff',
  fontSize: '14px',
  outline: 'none',
  cursor: 'pointer'
};

const codeBoxStyle = {
  background: '#0f172a',
  padding: '16px',
  borderRadius: '12px',
  border: '1px solid #1e293b',
  maxHeight: '240px',
  overflowY: 'auto'
};

const textareaStyle = {
  width: '100%',
  height: '240px',
  background: '#0f172a',
  border: '1px solid #334155',
  borderRadius: '12px',
  padding: '16px',
  color: '#f3f4f6',
  fontFamily: 'Fira Code, monospace',
  fontSize: '13px',
  lineHeight: '1.6',
  outline: 'none',
  resize: 'vertical',
  boxSizing: 'border-box'
};

const btnPrimaryStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  padding: '12px 24px',
  borderRadius: '10px',
  background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
  color: '#fff',
  border: 'none',
  fontWeight: '600',
  fontSize: '14px',
  cursor: 'pointer',
  boxShadow: '0 4px 12px rgba(59,130,246,0.4)',
  transition: 'all 0.2s'
};

const btnSecondaryStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  padding: '8px 16px',
  borderRadius: '8px',
  background: '#334155',
  color: '#fff',
  border: 'none',
  fontSize: '13px',
  cursor: 'pointer'
};

const smallBtnStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
  padding: '6px 12px',
  borderRadius: '6px',
  background: '#334155',
  color: '#cbd5e1',
  border: 'none',
  fontSize: '12px',
  cursor: 'pointer'
};

const sTestBtnStyle = {
  padding: '10px',
  borderRadius: '8px',
  background: '#0f172a',
  border: '1px solid #334155',
  color: '#e2e8f0',
  fontSize: '12px',
  cursor: 'pointer',
  textAlign: 'left'
};

const historyItemStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 14px',
  background: '#0f172a',
  borderRadius: '8px',
  border: '1px solid #334155',
  cursor: 'pointer'
};

const langTabStyle = (active) => ({
  padding: '8px 16px',
  background: active ? '#3b82f6' : 'transparent',
  color: active ? '#fff' : '#94a3b8',
  border: 'none',
  borderRadius: '6px 6px 0 0',
  cursor: 'pointer',
  fontSize: '13px',
  fontWeight: '500'
});

const badgeStyle = (bgColor, textColor) => ({
  background: bgColor,
  color: textColor,
  padding: '4px 12px',
  borderRadius: '20px',
  fontSize: '12px',
  fontWeight: '700',
  display: 'inline-flex',
  alignItems: 'center',
  gap: '6px'
});
