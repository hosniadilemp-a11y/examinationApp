const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function exportAllProblemsToJSON() {
  console.log('🚀 Starting DB Problems JSON Export...');

  try {
    const problems = await prisma.problem.findMany({
      orderBy: { createdAt: 'asc' }
    });

    console.log(`📦 Found ${problems.length} problems in database.`);

    const outputDirs = [
      path.join(__dirname, '../../data/problems'),
      path.join(__dirname, '../../../client/public/problems')
    ];

    outputDirs.forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });

    let count = 0;
    for (const prob of problems) {
      const slug = (prob.title || 'problem')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');
      
      const fileName = `Probleme_${slug}_${prob.id.slice(0, 8)}.json`;

      const jsonPayload = {
        id: prob.id,
        title: prob.title,
        description: prob.description || '',
        difficulty: prob.difficulty || 'MOYEN',
        topic: prob.topic || 'ALGO',
        tags: Array.isArray(prob.tags) ? prob.tags : (prob.topic ? [prob.topic] : ['Algorithmique']),
        points: prob.points || 10,
        timeLimitMs: prob.timeLimitMs || 2000,
        starterTemplate: prob.starterTemplate || prob.templateCode?.ALGO || '',
        referenceSolution: prob.referenceSolution || '',
        testCases: prob.testCases || [],
        createdAt: prob.createdAt
      };

      const jsonString = JSON.stringify(jsonPayload, null, 2);

      outputDirs.forEach(dir => {
        const filePath = path.join(dir, fileName);
        fs.writeFileSync(filePath, jsonString, 'utf8');
      });

      count++;
      console.log(`  [${count}/${problems.length}] Exported: ${fileName}`);
    }

    console.log(`\n✅ Successfully exported ${count} problem JSON files to server/data/problems/ and client/public/problems/!`);
  } catch (err) {
    console.error('❌ Export failed:', err);
  } finally {
    await prisma.$disconnect();
  }
}

exportAllProblemsToJSON();
