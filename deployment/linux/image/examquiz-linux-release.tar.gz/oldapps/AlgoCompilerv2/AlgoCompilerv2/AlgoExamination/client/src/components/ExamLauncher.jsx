import React, { useState, useMemo } from 'react';
import {
  ArrowLeft, Play, Users, Building, ShieldAlert, BookOpen, Clock, Upload,
  Search, CheckCircle2, AlertCircle, Sparkles, FileText, Check, ChevronDown,
  Hash, KeyRound
} from 'lucide-react';
import Swal from 'sweetalert2';
import { launchExamWithRoom } from '../services/api';

import FileDropZone from './FileDropZone';

// Helper: Generate Default Exam Code (e.g. ALGO31082026)
function generateDefaultExamCode(date = new Date()) {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `ALGO${day}${month}${year}`;
}

// Helper: Sanitize Room Name to a clean short prefix (e.g. "Salle 101" -> "S101", "Amphi B" -> "AMPHIB")
function sanitizeRoomCode(room) {
  if (!room || typeof room !== 'string') return '';
  let clean = room.toUpperCase().trim();
  clean = clean.replace(/SALLE\s*/gi, 'S');
  clean = clean.replace(/AMPHI\s*/gi, 'AMPHI');
  clean = clean.replace(/LABO\s*/gi, 'LAB');
  clean = clean.replace(/[^A-Z0-9]/g, '');
  return clean || 'S1';
}

export default function ExamLauncher({ exam, students = [], onBack, onExamLaunched }) {
  const [roomName, setRoomName] = useState(exam.room || 'Salle 101');
  const [examCode, setExamCode] = useState(exam.examCode || generateDefaultExamCode(exam.date || new Date()));
  const [prefix, setPrefix] = useState(exam.prefix || 'AL');
  const [randomizeOrder, setRandomizeOrder] = useState(true);
  const [assignmentMode, setAssignmentMode] = useState('ROSTER'); // 'ROSTER' | 'CSV'

  // Date, Time and Duration
  const getExamDateAndTimeString = () => {
    let dStr = '';
    let tStr = '';
    if (exam.startTime) {
      const dt = new Date(exam.startTime);
      const year = dt.getFullYear();
      const month = String(dt.getMonth() + 1).padStart(2, '0');
      const day = String(dt.getDate()).padStart(2, '0');
      dStr = `${year}-${month}-${day}`;
      const hours = String(dt.getHours()).padStart(2, '0');
      const mins = String(dt.getMinutes()).padStart(2, '0');
      tStr = `${hours}:${mins}`;
    } else if (exam.date) {
      const dt = new Date(exam.date);
      const year = dt.getFullYear();
      const month = String(dt.getMonth() + 1).padStart(2, '0');
      const day = String(dt.getDate()).padStart(2, '0');
      dStr = `${year}-${month}-${day}`;
    }
    if (!dStr) {
      const now = new Date();
      dStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    }
    if (!tStr) {
      const now = new Date();
      tStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    }
    return { dStr, tStr };
  };

  const { dStr: defaultDateStr, tStr: defaultTimeStr } = useMemo(() => getExamDateAndTimeString(), [exam]);
  const [examDate, setExamDate] = useState(defaultDateStr);
  const [examStartTime, setExamStartTime] = useState(defaultTimeStr);
  const [durationMinutes, setDurationMinutes] = useState(exam.durationMinutes || 90);

  // Roster selection state
  const [selectedStudentIds, setSelectedStudentIds] = useState(() => students.map(s => s.id));
  const [studentSearch, setStudentSearch] = useState('');
  const [selectedGroupFilter, setSelectedGroupFilter] = useState('ALL');

  // CSV file & parsed rows state
  const [csvFile, setCsvFile] = useState(null);
  const [csvPreviewRows, setCsvPreviewRows] = useState([]);
  const [selectedCsvIndices, setSelectedCsvIndices] = useState(new Set());
  const [isLaunching, setIsLaunching] = useState(false);

  const cleanRoomCode = useMemo(() => sanitizeRoomCode(roomName), [roomName]);

  // Available groups
  const availableGroups = useMemo(() => {
    const set = new Set(students.map(s => s.group).filter(Boolean));
    return Array.from(set).sort();
  }, [students]);

  // Filtered students for Roster mode
  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      const matchSearch = !studentSearch.trim() ||
        (s.firstName && s.firstName.toLowerCase().includes(studentSearch.toLowerCase())) ||
        (s.lastName && s.lastName.toLowerCase().includes(studentSearch.toLowerCase())) ||
        (s.studentId && s.studentId.toLowerCase().includes(studentSearch.toLowerCase()));

      const matchGroup = selectedGroupFilter === 'ALL' || s.group === selectedGroupFilter;

      return matchSearch && matchGroup;
    });
  }, [students, studentSearch, selectedGroupFilter]);

  const handleToggleStudent = (id) => {
    setSelectedStudentIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSelectAllFiltered = () => {
    const allFilteredSelected = filteredStudents.length > 0 && filteredStudents.every(s => selectedStudentIds.includes(s.id));
    if (allFilteredSelected) {
      const filteredIdsSet = new Set(filteredStudents.map(s => s.id));
      setSelectedStudentIds(prev => prev.filter(id => !filteredIdsSet.has(id)));
    } else {
      const newIds = new Set([...selectedStudentIds, ...filteredStudents.map(s => s.id)]);
      setSelectedStudentIds(Array.from(newIds));
    }
  };

  const handleToggleSelectAllCsv = () => {
    if (selectedCsvIndices.size === csvPreviewRows.length) {
      setSelectedCsvIndices(new Set());
    } else {
      setSelectedCsvIndices(new Set(csvPreviewRows.map((_, i) => i)));
    }
  };

  const handleToggleCsvRow = (idx) => {
    setSelectedCsvIndices(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const handleCSVFileSelect = (file) => {
    if (!file) {
      setCsvFile(null);
      setCsvPreviewRows([]);
      setSelectedCsvIndices(new Set());
      return;
    }
    setCsvFile(file);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = (event.target.result || '').replace(/^\uFEFF+/, '');
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      const parsed = [];
      let headerMap = null;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const parts = line.split(/[,;\t]/).map(p => p.trim());
        if (parts.length >= 1) {
          if (i === 0 && /^student|^matricule|^id|^code|^nom/i.test(parts[0])) {
            headerMap = {};
            parts.forEach((col, cIdx) => {
              const lower = col.toLowerCase();
              if (/code_anonyme|codeanonyme|anonym|code/i.test(lower)) headerMap.code = cIdx;
              else if (/matricule|student_id|studentid|id/i.test(lower)) headerMap.id = cIdx;
              else if (/prenom|firstname/i.test(lower)) headerMap.firstName = cIdx;
              else if (/nom|lastname/i.test(lower)) headerMap.lastName = cIdx;
              else if (/group|groupe/i.test(lower)) headerMap.group = cIdx;
            });
            continue;
          }

          let studentId = '';
          let firstName = 'Étudiant';
          let lastName = '';
          let group = 'G01';
          let customCode = '';

          if (headerMap && headerMap.id !== undefined) {
            studentId = parts[headerMap.id] || '';
            if (headerMap.code !== undefined) customCode = parts[headerMap.code] || '';
            if (headerMap.firstName !== undefined) firstName = parts[headerMap.firstName] || firstName;
            if (headerMap.lastName !== undefined) lastName = parts[headerMap.lastName] || lastName;
            if (headerMap.group !== undefined) group = parts[headerMap.group] || group;
          } else {
            studentId = parts[0];
            firstName = parts[1] || 'Étudiant';
            lastName = parts[2] || parts[0];
            group = parts[3] || 'G01';
            if (parts[4]) customCode = parts[4];
          }

          if (studentId) {
            parsed.push({ studentId, firstName, lastName, group, customCode });
          }
        }
      }
      setCsvPreviewRows(parsed);
      setSelectedCsvIndices(new Set(parsed.map((_, i) => i)));
    };
    reader.readAsText(file);
  };

  const handleLaunch = async (targetStatus = 'RUNNING') => {
    if (!roomName.trim()) {
      Swal.fire({
        icon: 'warning',
        title: 'Salle Requise',
        text: 'Veuillez indiquer la salle ou l\'amphi dans lequel se déroule cette session d\'examen.',
        background: '#111827',
        color: '#fff'
      });
      return;
    }

    if (assignmentMode === 'ROSTER' && selectedStudentIds.length === 0) {
      Swal.fire({
        icon: 'warning',
        title: 'Aucun Étudiant Sélectionné',
        text: 'Veuillez sélectionner au moins un étudiant dans la liste pour cette salle.',
        background: '#111827',
        color: '#fff'
      });
      return;
    }

    if (assignmentMode === 'CSV') {
      if (!csvFile || csvPreviewRows.length === 0) {
        Swal.fire({
          icon: 'warning',
          title: 'Fichier CSV Requis',
          text: 'Veuillez importer un fichier CSV valide contenant la liste des étudiants de cette salle.',
          background: '#111827',
          color: '#fff'
        });
        return;
      }
      if (selectedCsvIndices.size === 0) {
        Swal.fire({
          icon: 'warning',
          title: 'Aucun Étudiant Sélectionné',
          text: 'Veuillez sélectionner au moins un étudiant dans la liste CSV pour cette salle.',
          background: '#111827',
          color: '#fff'
        });
        return;
      }
    }

    const studentCount = assignmentMode === 'ROSTER' ? selectedStudentIds.length : selectedCsvIndices.size;
    const finalExamCode = (examCode && examCode.trim()) || generateDefaultExamCode(new Date());

    const isLive = targetStatus === 'RUNNING';

    const confirmRes = await Swal.fire({
      title: isLive ? '🚀 Démarrer l\'Épreuve Immédiatement (LIVE) ?' : '📅 Préparer la Salle (En Attente / Prêt) ?',
      html: `
        <div style="text-align: left; font-size: 0.9rem; color: #cbd5e1;">
          <p>${isLive ? 'Vous êtes sur le point de lancer l\'épreuve en direct :' : 'Vous êtes sur le point de préparer la salle :'}</p>
          <ul style="margin: 8px 0 12px 16px; color: #93c5fd; line-height: 1.6;">
            <li>Épreuve : <strong>${exam.title}</strong></li>
            <li>Code Unique : <strong style="color: #a78bfa;">${finalExamCode}</strong></li>
            <li>Salle / Amphi : <strong>${roomName.trim()}</strong> (Préfixe: <code>${cleanRoomCode}</code>)</li>
            <li>Date & Heure : <strong>${examDate} à ${examStartTime}</strong></li>
            <li>Durée : <strong>${durationMinutes} minutes</strong></li>
            <li>Nombre d'étudiants : <strong>${studentCount}</strong></li>
            <li>Codes Anonymes : <strong>${cleanRoomCode}-${prefix}-001 à ${cleanRoomCode}-${prefix}-${String(studentCount).padStart(3, '0')}</strong></li>
          </ul>
          <p style="color: ${isLive ? '#34d399' : '#fbbf24'};">
            ${isLive
              ? 'L\'épreuve démarre immédiatement et les étudiants peuvent coder.'
              : 'La salle sera configurée avec ses codes et passera en statut « En Attente ». Vous pourrez démarrer le live au moment voulu.'}
          </p>
        </div>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: isLive ? '🚀 Démarrer le Live' : '📅 Valider & Mettre en Attente',
      cancelButtonText: 'Annuler',
      confirmButtonColor: isLive ? '#10b981' : '#f59e0b',
      cancelButtonColor: '#64748b',
      background: '#111827',
      color: '#fff'
    });

    if (!confirmRes.isConfirmed) return;

    setIsLaunching(true);
    try {
      const formData = new FormData();
      formData.append('room', roomName.trim());
      formData.append('examCode', finalExamCode);
      formData.append('prefix', prefix.trim() || 'AL');
      formData.append('randomizeOrder', String(randomizeOrder));
      formData.append('targetStatus', targetStatus || 'RUNNING');
      formData.append('date', examDate);
      formData.append('startTime', examStartTime);
      formData.append('durationMinutes', String(durationMinutes));

      if (assignmentMode === 'CSV' && csvFile) {
        const filteredRows = csvPreviewRows.filter((_, idx) => selectedCsvIndices.has(idx));
        const csvString = "matricule,prenom,nom,groupe,code\n" + filteredRows.map(r => `${r.studentId},${r.firstName},${r.lastName},${r.group},${r.customCode || ''}`).join('\n');
        const filteredBlob = new Blob([csvString], { type: 'text/csv' });
        formData.append('studentsCSV', filteredBlob, csvFile.name || 'students.csv');
      } else {
        formData.append('studentIds', JSON.stringify(selectedStudentIds));
      }

      const res = await launchExamWithRoom(exam.id, formData);

      Swal.fire({
        icon: 'success',
        title: isLive ? '🚀 Épreuve Démarrée !' : '📅 Salle Préparée (En Attente)',
        text: res.message || 'Configuration enregistrée avec succès.',
        timer: 1800,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });

      setTimeout(() => {
        if (onExamLaunched) {
          onExamLaunched(res.exam || exam);
        } else {
          onBack();
        }
      }, 1500);
    } catch (err) {
      console.error('Launch error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur',
        text: err.data?.error || err.message || 'Impossible de configurer la salle.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setIsLaunching(false);
    }
  };

  const totalPoints = exam.problems?.reduce((sum, ep) => sum + (ep.points || ep.problem?.points || 0), 0) || 20;

  return (
    <div style={{ padding: '30px', maxWidth: '1280px', margin: '0 auto', color: 'var(--text-main)' }}>
      {/* ── HEADER ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <button type="button" className="btn btn-secondary" onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <ArrowLeft size={16} /> Retour au Tableau de Bord
        </button>
        <span className="badge badge-yellow" style={{ fontSize: '0.85rem', padding: '6px 14px' }}>
          Prêt pour le Lancement
        </span>
      </div>

      <div style={{
        background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(15, 23, 42, 0.8) 100%)',
        border: '1px solid rgba(16, 185, 129, 0.3)',
        borderRadius: '12px',
        padding: '24px 30px',
        marginBottom: '28px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '20px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
            <span style={{ fontSize: '1.6rem' }}>🚀</span>
            <h1 style={{ fontSize: '1.6rem', fontWeight: '800', margin: 0, color: '#f8fafc' }}>
              Lancement de l'Épreuve : {exam.title}
            </h1>
          </div>
          <div style={{ display: 'flex', gap: '16px', fontSize: '0.85rem', color: '#94a3b8', flexWrap: 'wrap' }}>
            <span><strong>Code Épreuve :</strong> <code style={{ color: '#a78bfa', fontWeight: '700' }}>{examCode}</code></span>
            <span><strong>Module :</strong> {exam.module || 'Algorithmique et Structure de Données'}</span>
            <span><strong>Session :</strong> {exam.session || '2025/2026'}</span>
            <span><strong>Durée :</strong> {exam.durationMinutes} min</span>
            <span><strong>Barème :</strong> {totalPoints} pts</span>
          </div>
        </div>
      </div>

      {/* ── MAIN 2-COLUMN GRID ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', gap: '24px', alignItems: 'start' }}>

        {/* ── LEFT PANE: EXAM DETAILS & PROBLEMS ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          {/* Problem List Card */}
          <div className="glass-panel" style={{ padding: '20px' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: '700', margin: '0 0 14px 0', display: 'flex', alignItems: 'center', gap: '8px', color: '#60a5fa' }}>
              <BookOpen size={16} /> Sujet & Exercices ({exam.problems?.length || 0})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {exam.problems?.map((ep, idx) => (
                <div key={ep.id || idx} style={{
                  background: 'rgba(15, 23, 42, 0.6)',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  padding: '10px 14px',
                  borderRadius: '8px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <div>
                    <strong style={{ fontSize: '0.88rem', color: '#f1f5f9', display: 'block' }}>
                      {idx + 1}. {ep.problem?.title || `Exercice #${idx + 1}`}
                    </strong>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      {ep.problem?.topic || 'Algorithmique'} • Tests: {ep.weightTest ?? 40}% | AST: {ep.weightAst ?? 60}%
                    </span>
                  </div>
                  <span style={{ fontSize: '0.85rem', fontWeight: '800', color: '#34d399', background: 'rgba(52,211,153,0.15)', padding: '3px 8px', borderRadius: '4px' }}>
                    {ep.points || ep.problem?.points || 5} pts
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Anti-Cheat Settings Card */}
          <div className="glass-panel" style={{ padding: '20px' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: '700', margin: '0 0 14px 0', display: 'flex', alignItems: 'center', gap: '8px', color: '#ef4444' }}>
              <ShieldAlert size={16} /> Règles & Surveillance
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '0.82rem', color: '#cbd5e1' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Plein Écran Obligatoire :</span>
                <strong style={{ color: exam.fullscreenRequired !== false ? '#34d399' : '#ef4444' }}>
                  {exam.fullscreenRequired !== false ? '✓ Activé' : '✕ Désactivé'}
                </strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Blocage Copier / Coller :</span>
                <strong style={{ color: exam.copyDisabled ? '#34d399' : '#94a3b8' }}>
                  {exam.copyDisabled ? '✓ Verrouillé' : 'Libre'}
                </strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Briques de Code :</span>
                <strong style={{ color: exam.allowCodeBricks !== false ? '#34d399' : '#ef4444' }}>
                  {exam.allowCodeBricks !== false ? '✓ Autorisées' : '✕ Bloquées'}
                </strong>
              </div>
            </div>
          </div>
        </div>

        {/* ── RIGHT PANE: ROOM CONFIGURATION & STUDENT ASSIGNMENT ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          
          {/* Room & Codes Card */}
          <div className="glass-panel" style={{ padding: '22px' }}>
            <h3 style={{ fontSize: '1.05rem', fontWeight: '700', margin: '0 0 16px 0', color: '#34d399', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Building size={18} /> 1. Configuration de la Salle & Identifiants
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1.5fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
                  Nom de la Salle / Amphi :
                </label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Ex: Salle 101, Amphi B, Salle TP 03"
                  value={roomName}
                  onChange={e => setRoomName(e.target.value)}
                  style={{ fontSize: '0.9rem', padding: '10px 14px' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
                  Code Unique de l'Épreuve :
                </label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Ex: ALGO31082026"
                  value={examCode}
                  onChange={e => setExamCode(e.target.value.toUpperCase())}
                  style={{ fontSize: '0.9rem', padding: '10px 14px', color: '#c4b5fd', fontWeight: '700' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
                  Préfixe :
                </label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Ex: AL"
                  value={prefix}
                  onChange={e => setPrefix(e.target.value.toUpperCase())}
                  style={{ fontSize: '0.9rem', padding: '10px 14px' }}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1.2fr 1fr', gap: '14px', marginTop: '14px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
                  📅 Date de l'Épreuve :
                </label>
                <input
                  type="date"
                  className="form-input"
                  value={examDate}
                  onChange={e => setExamDate(e.target.value)}
                  style={{ fontSize: '0.9rem', padding: '10px 14px' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
                  ⏰ Heure de Début :
                </label>
                <input
                  type="time"
                  className="form-input"
                  value={examStartTime}
                  onChange={e => setExamStartTime(e.target.value)}
                  style={{ fontSize: '0.9rem', padding: '10px 14px' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '700', color: '#e2e8f0' }}>
                  ⏱️ Durée (Minutes) :
                </label>
                <input
                  type="number"
                  min="5"
                  max="360"
                  className="form-input"
                  value={durationMinutes}
                  onChange={e => setDurationMinutes(Math.max(5, parseInt(e.target.value) || 0))}
                  style={{ fontSize: '0.9rem', padding: '10px 14px', color: '#34d399', fontWeight: '700' }}
                />
              </div>
            </div>

            <div style={{ marginTop: '14px', background: 'rgba(0,0,0,0.25)', padding: '12px 16px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.06)' }}>
              <div style={{ fontSize: '0.84rem', color: '#cbd5e1', marginBottom: '8px' }}>
                🏷️ <strong>Format des codes anonymes générés pour cette salle :</strong> <code style={{ color: '#34d399', fontWeight: '700', background: 'rgba(52,211,153,0.12)', padding: '2px 8px', borderRadius: '4px' }}>{cleanRoomCode}-{prefix}-001</code>, <code style={{ color: '#34d399' }}>{cleanRoomCode}-{prefix}-002</code>, ...
              </div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={randomizeOrder}
                  onChange={e => setRandomizeOrder(e.target.checked)}
                  style={{ width: '16px', height: '16px', cursor: 'pointer' }}
                />
                <span style={{ fontSize: '0.82rem', color: '#94a3b8' }}>
                  🔀 Mélanger aléatoirement l'ordre des étudiants pour la génération des codes anonymes
                </span>
              </label>
            </div>
          </div>

          {/* Student Assignment Mode Card */}
          <div className="glass-panel" style={{ padding: '22px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.05rem', fontWeight: '700', margin: 0, color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Users size={18} /> 2. Étudiants Présents dans cette Salle
              </h3>

              {/* Toggle Mode Buttons */}
              <div style={{ display: 'flex', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', padding: '3px', border: '1px solid rgba(255,255,255,0.1)' }}>
                <button
                  type="button"
                  onClick={() => setAssignmentMode('ROSTER')}
                  style={{
                    padding: '5px 14px', borderRadius: '6px', border: 'none', fontSize: '0.8rem', fontWeight: '700',
                    background: assignmentMode === 'ROSTER' ? '#3b82f6' : 'transparent',
                    color: assignmentMode === 'ROSTER' ? '#fff' : '#94a3b8',
                    cursor: 'pointer', transition: 'all 0.15s ease'
                  }}
                >
                  Sélection Liste ({students.length})
                </button>
                <button
                  type="button"
                  onClick={() => setAssignmentMode('CSV')}
                  style={{
                    padding: '5px 14px', borderRadius: '6px', border: 'none', fontSize: '0.8rem', fontWeight: '700',
                    background: assignmentMode === 'CSV' ? '#3b82f6' : 'transparent',
                    color: assignmentMode === 'CSV' ? '#fff' : '#94a3b8',
                    cursor: 'pointer', transition: 'all 0.15s ease'
                  }}
                >
                  Téléverser CSV
                </button>
              </div>
            </div>

            {assignmentMode === 'ROSTER' ? (
              <div>
                {/* Search & Filter Bar */}
                <div style={{ display: 'flex', gap: '10px', marginBottom: '14px' }}>
                  <div style={{ position: 'relative', flex: 1 }}>
                    <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Filtrer par nom ou matricule..."
                      style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
                      value={studentSearch}
                      onChange={e => setStudentSearch(e.target.value)}
                    />
                  </div>

                  <select
                    className="form-input"
                    style={{ width: '180px', fontSize: '0.85rem' }}
                    value={selectedGroupFilter}
                    onChange={e => setSelectedGroupFilter(e.target.value)}
                  >
                    <option value="ALL">Tous les Groupes</option>
                    {availableGroups.map(g => (
                      <option key={g} value={g}>Groupe {g}</option>
                    ))}
                  </select>

                  <button
                    type="button"
                    className="btn btn-secondary"
                    style={{ padding: '6px 14px', fontSize: '0.82rem', whiteSpace: 'nowrap' }}
                    onClick={handleSelectAllFiltered}
                  >
                    {filteredStudents.length > 0 && filteredStudents.every(s => selectedStudentIds.includes(s.id))
                      ? 'Désélectionner Tout'
                      : `Tout Sélectionner (${filteredStudents.length})`}
                  </button>
                </div>

                {/* Selected Count Indicator */}
                <div style={{ marginBottom: '10px', fontSize: '0.82rem', color: '#93c5fd', fontWeight: '700' }}>
                  ✓ {selectedStudentIds.length} étudiant(s) sélectionné(s) pour cette salle
                </div>

                {/* Students Grid */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '8px', maxHeight: '280px', overflowY: 'auto' }}>
                  {filteredStudents.map(s => {
                    const isSelected = selectedStudentIds.includes(s.id);
                    return (
                      <div
                        key={s.id}
                        onClick={() => handleToggleStudent(s.id)}
                        style={{
                          padding: '8px 12px', borderRadius: '6px', cursor: 'pointer',
                          border: isSelected ? '1px solid #3b82f6' : '1px solid rgba(255,255,255,0.08)',
                          background: isSelected ? 'rgba(59, 130, 246, 0.16)' : 'rgba(0,0,0,0.2)',
                          display: 'flex', alignItems: 'center', gap: '8px', transition: 'all 0.12s ease'
                        }}
                      >
                        <input type="checkbox" checked={isSelected} onChange={() => {}} style={{ cursor: 'pointer' }} />
                        <div style={{ overflow: 'hidden' }}>
                          <strong style={{ fontSize: '0.82rem', display: 'block', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                            {s.lastName?.toUpperCase()} {s.firstName}
                          </strong>
                          <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                            {s.studentId} • Gr {s.group || '1'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* CSV Upload Mode */
              <div>
                <FileDropZone
                  accept=".csv,.txt"
                  selectedFile={csvFile}
                  onFileSelect={handleCSVFileSelect}
                  onClear={() => handleCSVFileSelect(null)}
                  label="Glissez & déposez le fichier CSV de la salle ici"
                  hint="ou cliquez pour parcourir vos dossiers (Formats: Matricule, Nom, Prénom, Groupe)"
                />

                {csvPreviewRows.length > 0 && (
                  <div style={{ marginTop: '16px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                      <span style={{ fontSize: '0.85rem', fontWeight: '700', color: selectedCsvIndices.size > 0 ? '#34d399' : '#f87171' }}>
                        ✓ {selectedCsvIndices.size} / {csvPreviewRows.length} étudiant(s) sélectionné(s) :
                      </span>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button
                          type="button"
                          className="btn btn-secondary"
                          onClick={handleToggleSelectAllCsv}
                          style={{ padding: '4px 10px', fontSize: '0.78rem' }}
                        >
                          {selectedCsvIndices.size === csvPreviewRows.length ? 'Tout désélectionner' : 'Tout sélectionner'}
                        </button>
                      </div>
                    </div>
                    <div style={{ maxHeight: '200px', overflowY: 'auto', background: 'rgba(0,0,0,0.3)', borderRadius: '6px', border: '1px solid rgba(255,255,255,0.1)' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem' }}>
                        <thead>
                          <tr style={{ background: 'rgba(255,255,255,0.05)', color: '#94a3b8', textAlign: 'left' }}>
                            <th style={{ padding: '6px 10px', width: '36px', textAlign: 'center' }}>
                              <input
                                type="checkbox"
                                checked={selectedCsvIndices.size === csvPreviewRows.length && csvPreviewRows.length > 0}
                                onChange={handleToggleSelectAllCsv}
                                style={{ cursor: 'pointer' }}
                              />
                            </th>
                            <th style={{ padding: '6px 10px' }}>Matricule</th>
                            <th style={{ padding: '6px 10px' }}>Nom & Prénom</th>
                            <th style={{ padding: '6px 10px' }}>Groupe</th>
                            <th style={{ padding: '6px 10px' }}>Code Anonyme</th>
                          </tr>
                        </thead>
                        <tbody>
                          {csvPreviewRows.map((r, idx) => {
                            const isSelected = selectedCsvIndices.has(idx);
                            return (
                              <tr
                                key={idx}
                                style={{
                                  borderBottom: '1px solid rgba(255,255,255,0.04)',
                                  background: isSelected ? 'rgba(59, 130, 246, 0.08)' : 'transparent',
                                  cursor: 'pointer'
                                }}
                                onClick={() => handleToggleCsvRow(idx)}
                              >
                                <td style={{ padding: '5px 10px', textAlign: 'center' }} onClick={e => e.stopPropagation()}>
                                  <input
                                    type="checkbox"
                                    checked={isSelected}
                                    onChange={() => handleToggleCsvRow(idx)}
                                    style={{ cursor: 'pointer' }}
                                  />
                                </td>
                                <td style={{ padding: '5px 10px', color: '#60a5fa' }}>{r.studentId}</td>
                                <td style={{ padding: '5px 10px', color: '#fff' }}>{r.lastName} {r.firstName}</td>
                                <td style={{ padding: '5px 10px', color: 'var(--text-muted)' }}>{r.group}</td>
                                <td style={{ padding: '5px 10px', color: r.customCode ? '#a78bfa' : '#34d399', fontWeight: '700' }}>
                                  {r.customCode ? `🔑 ${r.customCode}` : `⚙️ ${cleanRoomCode}-${prefix}-${String(idx + 1).padStart(3, '0')}`}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ── ACTION BUTTONS: PREPARE VS START LIVE ── */}
          <div style={{ display: 'flex', gap: '14px', marginTop: '16px', flexWrap: 'wrap' }}>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onBack}
              style={{ padding: '14px 20px', fontSize: '0.92rem' }}
            >
              Annuler
            </button>

            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => handleLaunch('WAITING')}
              disabled={isLaunching}
              style={{
                flex: 1,
                minWidth: '240px',
                padding: '14px 20px',
                fontSize: '0.95rem',
                fontWeight: '700',
                background: 'rgba(245, 158, 11, 0.12)',
                border: '1px solid rgba(245, 158, 11, 0.4)',
                color: '#fbbf24',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                cursor: isLaunching ? 'not-allowed' : 'pointer'
              }}
              title="Configure la salle avec les codes d'accès et met l'épreuve en statut En Attente"
            >
              <Clock size={18} />
              📅 Préparer la Salle (En Attente / Prêt)
            </button>

            <button
              type="button"
              className="btn btn-success"
              onClick={() => handleLaunch('RUNNING')}
              disabled={isLaunching}
              style={{
                flex: 1.3,
                minWidth: '260px',
                padding: '14px 24px',
                fontSize: '1rem',
                fontWeight: '800',
                background: 'linear-gradient(135deg, #10b981 0%, #047857 100%)',
                boxShadow: '0 6px 20px rgba(16, 185, 129, 0.4)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px',
                cursor: isLaunching ? 'not-allowed' : 'pointer'
              }}
              title="Lance le chronomètre et démarre immédiatement l'épreuve en direct"
            >
              <Play size={18} fill="#fff" />
              {isLaunching ? 'Démarrage...' : `🚀 DÉMARRER LE LIVE (${assignmentMode === 'ROSTER' ? selectedStudentIds.length : selectedCsvIndices.size} Étudiants)`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
