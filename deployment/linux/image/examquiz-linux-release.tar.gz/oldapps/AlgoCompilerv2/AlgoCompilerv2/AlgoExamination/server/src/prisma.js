const { Pool } = require('pg');
const { PrismaPg } = require('@prisma/adapter-pg');
const { PrismaClient } = require('@prisma/client');

const connectionString = process.env.DATABASE_URL;

const pool = new Pool({
  connectionString,
  options: '-c search_path=exam,public',
  max: 25,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle pg pool client:', err.message || err);
});

const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

// Retry wrapper for database queries to withstand transient network spikes / ETIMEDOUT / EAI_AGAIN
async function withRetry(fn, retries = 3, delayMs = 600) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      const errMsg = (err.message || '').toLowerCase();
      const errCode = err.code || '';
      const isTransientNetworkErr =
        errCode === 'ETIMEDOUT' ||
        errCode === 'EAI_AGAIN' ||
        errCode === 'ENOTFOUND' ||
        errCode === 'ECONNRESET' ||
        errMsg.includes('etimedout') ||
        errMsg.includes('eai_again') ||
        errMsg.includes('enotfound') ||
        errMsg.includes('connection terminated') ||
        errMsg.includes('getaddrinfo') ||
        errMsg.includes('timeout');

      if (isTransientNetworkErr && attempt < retries) {
        console.warn(`[Prisma Query Retry] Attempt ${attempt}/${retries} failed with ${errCode || 'network error'}. Retrying in ${delayMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      } else {
        throw err;
      }
    }
  }
}

module.exports = prisma;
module.exports.withRetry = withRetry;
