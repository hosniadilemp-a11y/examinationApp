const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'algoexamination_secret_jwt_key_2026_super_secure';

function authenticateTeacher(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded.teacherId) {
      return res.status(403).json({ error: 'Invalid teacher token' });
    }
    req.teacher = {
      ...decoded,
      id: decoded.teacherId || decoded.id,
      teacherId: decoded.teacherId || decoded.id
    };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function authenticateStudent(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Student authentication required' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded.studentId || !decoded.examId) {
      return res.status(403).json({ error: 'Invalid student exam token' });
    }
    req.studentExamSession = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }
}

module.exports = {
  authenticateTeacher,
  authenticateStudent,
  JWT_SECRET
};
