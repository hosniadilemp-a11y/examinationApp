const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const OFFICIAL_PROBLEMS = [
  {
    title: "Somme de Deux Entiers",
    topic: "Chapitre 1: Introduction à l'Algorithmique, Chapitre 5: Actions Paramétrées (Fonctions & Procédures)",
    tags: ["Chapitre 1: Introduction à l'Algorithmique", "Chapitre 5: Actions Paramétrées (Fonctions & Procédures)"],
    difficulty: "FACILE",
    starterTemplate: "ALGORITHME Somme_Deux_Entiers\nVAR\n   a, b, s : ENTIER;\nDEBUT\n   LIRE(a);\n   LIRE(b);\n   s := a + b;\n   ECRIRE(s);\nFIN.",
    referenceSolution: "ALGORITHME Solution_Somme_Deux_Entiers\nVAR\n   a, b, s : ENTIER;\nDEBUT\n   LIRE(a);\n   LIRE(b);\n   s := a + b;\n   ECRIRE(s);\nFIN.",
    description: `## 🎯 Objectif ##
Écrire un algorithme en langage \`ALGO\` qui lit deux entiers \`a\` et \`b\` sur l'entrée standard puis affiche leur somme.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`a\` (ENTIER)
- **Ligne 2** : \`b\` (ENTIER)

### 📤 Sorties Attendues (STDOUT) ###
- La somme \`a + b\` affichée sur la sortie standard.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
10
20
\`\`\`

**Sortie Attendue :**
\`\`\`
30
\`\`\``,
    testCases: [
      { inputData: '5\n10', expectedOutput: '15', isPublic: true },
      { inputData: '0\n7', expectedOutput: '7', isPublic: true },
      { inputData: '-3\n8', expectedOutput: '5', isPublic: false },
      { inputData: '100\n200', expectedOutput: '300', isPublic: false },
      { inputData: '-50\n-20', expectedOutput: '-70', isPublic: false },
      { inputData: '999\n1', expectedOutput: '1000', isPublic: false },
      { inputData: '0\n0', expectedOutput: '0', isPublic: false },
      { inputData: '1234\n5678', expectedOutput: '6912', isPublic: false },
      { inputData: '-1000\n1000', expectedOutput: '0', isPublic: false },
      { inputData: '42\n58', expectedOutput: '100', isPublic: false },
      { inputData: '15\n-30', expectedOutput: '-15', isPublic: false },
      { inputData: '8888\n1112', expectedOutput: '10000', isPublic: false }
    ]
  },
  {
    title: "Maximum d'un Tableau",
    topic: "Chapitre 2: Tableaux et Matrices",
    tags: ["Chapitre 2: Tableaux et Matrices"],
    difficulty: "MOYEN",
    starterTemplate: "ALGORITHME Max_Tableau\nVAR\n   T : TABLEAU[1..100] DE ENTIER;\n   n, i, maxVal : ENTIER;\nDEBUT\n   LIRE(n);\n   POUR i := 1 A n FAIRE\n      LIRE(T[i]);\n   FINPOUR;\n   // Rechercher le maximum...\nFIN.",
    referenceSolution: "ALGORITHME Solution_Max_Tableau\nVAR\n   T : TABLEAU[1..100] DE ENTIER;\n   n, i, maxVal : ENTIER;\nDEBUT\n   LIRE(n);\n   POUR i := 1 A n FAIRE\n      LIRE(T[i]);\n   FINPOUR;\n   maxVal := T[1];\n   POUR i := 2 A n FAIRE\n      SI T[i] > maxVal ALORS\n         maxVal := T[i];\n      FINSI;\n   FINPOUR;\n   ECRIRE(maxVal);\nFIN.",
    description: `## 🎯 Objectif ##
Écrire un algorithme en \`ALGO\` qui lit la taille \`n\` d'un tableau d'entiers \`T\`, puis les \`n\` éléments du tableau, et affiche la valeur maximale contenue dans le tableau.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`n\` (ENTIER, $1 \\le n \\le 100$)
- **Lignes 2..n+1** : Les \`n\` éléments du tableau \`T\`

### 📤 Sorties Attendues (STDOUT) ###
- L'élément maximal du tableau.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
5
10 20 5 40 30
\`\`\`

**Sortie Attendue :**
\`\`\`
40
\`\`\``,
    testCases: [
      { inputData: '5\n10 20 5 40 30', expectedOutput: '40', isPublic: true },
      { inputData: '3\n-5 -2 -10', expectedOutput: '-2', isPublic: true },
      { inputData: '1\n100', expectedOutput: '100', isPublic: false },
      { inputData: '4\n0 0 0 0', expectedOutput: '0', isPublic: false },
      { inputData: '6\n1 2 3 4 5 6', expectedOutput: '6', isPublic: false },
      { inputData: '6\n6 5 4 3 2 1', expectedOutput: '6', isPublic: false },
      { inputData: '5\n-100 50 -20 0 10', expectedOutput: '50', isPublic: false },
      { inputData: '4\n8 8 8 8', expectedOutput: '8', isPublic: false },
      { inputData: '7\n12 45 89 23 67 34 89', expectedOutput: '89', isPublic: false },
      { inputData: '5\n99 100 1 2 3', expectedOutput: '100', isPublic: false },
      { inputData: '3\n-1000 0 -500', expectedOutput: '0', isPublic: false },
      { inputData: '8\n5 12 7 99 2 4 80 1', expectedOutput: '99', isPublic: false }
    ]
  },
  {
    title: "Tri à Bulles",
    topic: "Chapitre 2: Tableaux et Matrices",
    tags: ["Chapitre 2: Tableaux et Matrices"],
    difficulty: "MOYEN",
    starterTemplate: "ALGORITHME Tri_Bulles\nVAR\n   T : TABLEAU[1..100] DE ENTIER;\n   n, i, j, tmp : ENTIER;\nDEBUT\n   LIRE(n);\n   POUR i := 1 A n FAIRE\n      LIRE(T[i]);\n   FINPOUR;\n   // Appliquer le tri à bulles...\nFIN.",
    referenceSolution: "ALGORITHME Solution_Tri_Bulles\nVAR\n   T : TABLEAU[1..100] DE ENTIER;\n   n, i, j, tmp : ENTIER;\nDEBUT\n   LIRE(n);\n   POUR i := 1 A n FAIRE\n      LIRE(T[i]);\n   FINPOUR;\n   POUR i := 1 A n - 1 FAIRE\n      POUR j := 1 A n - i FAIRE\n         SI T[j] > T[j+1] ALORS\n            tmp := T[j];\n            T[j] := T[j+1];\n            T[j+1] := tmp;\n         FINSI;\n      FINPOUR;\n   FINPOUR;\n   POUR i := 1 A n FAIRE\n      ECRIRE(T[i]);\n   FINPOUR;\nFIN.",
    description: `## 🎯 Objectif ##
Implémenter l'algorithme du **Tri à Bulles** en \`ALGO\` pour trier un tableau de \`n\` entiers par ordre croissant.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`n\` (ENTIER)
- **Lignes suivantes** : \`n\` entiers du tableau.

### 📤 Sorties Attendues (STDOUT) ###
- Les éléments du tableau triés par ordre croissant séparés par des espaces.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
5
5 3 1 4 2
\`\`\`

**Sortie Attendue :**
\`\`\`
1 2 3 4 5
\`\`\``,
    testCases: [
      { inputData: '5\n5 3 1 4 2', expectedOutput: '1 2 3 4 5', isPublic: true },
      { inputData: '3\n9 1 5', expectedOutput: '1 5 9', isPublic: true },
      { inputData: '1\n42', expectedOutput: '42', isPublic: false },
      { inputData: '4\n4 3 2 1', expectedOutput: '1 2 3 4', isPublic: false },
      { inputData: '4\n1 2 3 4', expectedOutput: '1 2 3 4', isPublic: false },
      { inputData: '6\n10 -5 20 0 15 -10', expectedOutput: '-10 -5 0 10 15 20', isPublic: false },
      { inputData: '5\n7 7 7 7 7', expectedOutput: '7 7 7 7 7', isPublic: false },
      { inputData: '6\n100 90 80 70 60 50', expectedOutput: '60 70 80 90 100', isPublic: false },
      { inputData: '2\n2 1', expectedOutput: '1 2', isPublic: false },
      { inputData: '7\n12 5 8 1 9 3 7', expectedOutput: '1 3 5 7 8 9 12', isPublic: false },
      { inputData: '4\n-1 -2 -3 -4', expectedOutput: '-4 -3 -2 -1', isPublic: false },
      { inputData: '5\n0 5 0 2 0', expectedOutput: '0 0 0 2 5', isPublic: false }
    ]
  },
  {
    title: "Comptage des Voyelles",
    topic: "Chapitre 3: Chaînes de Caractères",
    tags: ["Chapitre 3: Chaînes de Caractères"],
    difficulty: "FACILE",
    starterTemplate: "ALGORITHME Compter_Voyelles\nVAR\n   ch : CHAINE;\n   i, count, len : ENTIER;\n   c : CARACTERE;\nDEBUT\n   LIRE(ch);\n   // Compter les voyelles...\nFIN.",
    referenceSolution: "ALGORITHME Solution_Compter_Voyelles\nVAR\n   ch : CHAINE;\n   i, count, len : ENTIER;\n   c : CARACTERE;\nDEBUT\n   LIRE(ch);\n   len := LONGUEUR(ch);\n   count := 0;\n   POUR i := 1 A len FAIRE\n      c := ch[i];\n      SI (c = 'a') OU (c = 'e') OU (c = 'i') OU (c = 'o') OU (c = 'u') OU (c = 'A') OU (c = 'E') OU (c = 'I') OU (c = 'O') OU (c = 'U') ALORS\n         count := count + 1;\n      FINSI;\n   FINPOUR;\n   ECRIRE(count);\nFIN.",
    description: `## 🎯 Objectif ##
Écrire un algorithme en \`ALGO\` qui compte le nombre de voyelles (a, e, i, o, u en majuscule ou minuscule) dans une chaîne de caractères donnée.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`ch\` (CHAINE)

### 📤 Sorties Attendues (STDOUT) ###
- Le nombre total de voyelles contenues dans la chaîne.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
AlgoCompiler
\`\`\`

**Sortie Attendue :**
\`\`\`
4
\`\`\``,
    testCases: [
      { inputData: 'AlgoCompiler', expectedOutput: '4', isPublic: true },
      { inputData: 'bcdfg', expectedOutput: '0', isPublic: true },
      { inputData: 'aeiou', expectedOutput: '5', isPublic: false },
      { inputData: 'AEIOU', expectedOutput: '5', isPublic: false },
      { inputData: 'Hello World', expectedOutput: '3', isPublic: false },
      { inputData: 'Informatique', expectedOutput: '6', isPublic: false },
      { inputData: 'Python', expectedOutput: '1', isPublic: false },
      { inputData: 'a', expectedOutput: '1', isPublic: false },
      { inputData: 'b', expectedOutput: '0', isPublic: false },
      { inputData: 'ABCDEF', expectedOutput: '2', isPublic: false },
      { inputData: 'ESI Alger', expectedOutput: '4', isPublic: false },
      { inputData: 'Examen Final 2026', expectedOutput: '5', isPublic: false }
    ]
  },
  {
    title: "Calcul de la Factorielle",
    topic: "Chapitre 1: Introduction à l'Algorithmique, Chapitre 5: Actions Paramétrées (Fonctions & Procédures)",
    tags: ["Chapitre 1: Introduction à l'Algorithmique", "Chapitre 5: Actions Paramétrées (Fonctions & Procédures)"],
    difficulty: "FACILE",
    starterTemplate: "ALGORITHME Factorielle\nVAR\n   n, i, fact : ENTIER;\nDEBUT\n   LIRE(n);\n   // Calculer n!...\nFIN.",
    referenceSolution: "ALGORITHME Solution_Factorielle\nVAR\n   n, i, fact : ENTIER;\nDEBUT\n   LIRE(n);\n   fact := 1;\n   POUR i := 1 A n FAIRE\n      fact := fact * i;\n   FINPOUR;\n   ECRIRE(fact);\nFIN.",
    description: `## 🎯 Objectif ##
Écrire un algorithme qui calcule et affiche la factorielle $n! = 1 \\times 2 \\times \\dots \\times n$ d'un nombre entier positif $n$. Pour $n = 0$, $0! = 1$.

### 📥 Entrées (STDIN) ###
- **Ligne 1** : \`n\` (ENTIER, $0 \\le n \\le 12$)

### 📤 Sorties Attendues (STDOUT) ###
- La valeur de $n!$.

### 💡 Exemple d'Exécution ###
**Entrée :**
\`\`\`
5
\`\`\`

**Sortie Attendue :**
\`\`\`
120
\`\`\``,
    testCases: [
      { inputData: '5', expectedOutput: '120', isPublic: true },
      { inputData: '0', expectedOutput: '1', isPublic: true },
      { inputData: '1', expectedOutput: '1', isPublic: false },
      { inputData: '2', expectedOutput: '2', isPublic: false },
      { inputData: '3', expectedOutput: '6', isPublic: false },
      { inputData: '4', expectedOutput: '24', isPublic: false },
      { inputData: '6', expectedOutput: '720', isPublic: false },
      { inputData: '7', expectedOutput: '5040', isPublic: false },
      { inputData: '8', expectedOutput: '40320', isPublic: false },
      { inputData: '9', expectedOutput: '362880', isPublic: false },
      { inputData: '10', expectedOutput: '3628800', isPublic: false },
      { inputData: '12', expectedOutput: '479001600', isPublic: false }
    ]
  }
];

async function seedCleanOfficialProblems() {
  console.log('🧹 Cleaning DB problems and resetting JSON files...');

  try {
    // 1. Delete all existing problems and test cases in DB
    await prisma.testCase.deleteMany({});
    await prisma.examProblem.deleteMany({});
    await prisma.problem.deleteMany({});
    console.log('✅ DB problems and test cases wiped clean.');

    // 2. Clear JSON directories
    const jsonDirs = [
      path.join(__dirname, '../../data/problems'),
      path.join(__dirname, '../../../client/public/problems')
    ];

    jsonDirs.forEach(dir => {
      if (fs.existsSync(dir)) {
        fs.readdirSync(dir).forEach(file => {
          if (file.endsWith('.json')) {
            fs.unlinkSync(path.join(dir, file));
          }
        });
      } else {
        fs.mkdirSync(dir, { recursive: true });
      }
    });

    // 3. Create fresh official problems
    let count = 0;
    for (const probData of OFFICIAL_PROBLEMS) {
      const created = await prisma.problem.create({
        data: {
          title: probData.title,
          description: probData.description,
          topic: probData.topic,
          difficulty: probData.difficulty,
          referenceSolution: probData.referenceSolution,
          templateCode: { ALGO: probData.starterTemplate, PYTHON: '' }
        }
      });

      for (const tc of probData.testCases) {
        await prisma.testCase.create({
          data: {
            problemId: created.id,
            inputData: tc.inputData,
            expectedOutput: tc.expectedOutput,
            isPublic: tc.isPublic
          }
        });
      }

      const slug = probData.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');

      const fileName = `Probleme_${slug}_${created.id.slice(0, 8)}.json`;

      const jsonPayload = {
        id: created.id,
        title: created.title,
        description: created.description,
        difficulty: created.difficulty,
        topic: created.topic,
        tags: probData.tags,
        starterTemplate: probData.starterTemplate,
        referenceSolution: created.referenceSolution,
        testCases: probData.testCases.map(tc => ({
          input: tc.inputData,
          expectedOutput: tc.expectedOutput,
          weight: 1,
          isHidden: !tc.isPublic
        })),
        createdAt: created.createdAt
      };

      const jsonString = JSON.stringify(jsonPayload, null, 2);
      jsonDirs.forEach(dir => {
        fs.writeFileSync(path.join(dir, fileName), jsonString, 'utf8');
      });

      count++;
      console.log(`  [${count}/${OFFICIAL_PROBLEMS.length}] Clean Problem Seeded & Saved: ${fileName}`);
    }

    console.log(`\n🎉 Success! All ${count} official curriculum problems seeded into DB and exported to JSON files!`);
  } catch (err) {
    console.error('❌ Seeding failed:', err);
  } finally {
    await prisma.$disconnect();
  }
}

seedCleanOfficialProblems();
