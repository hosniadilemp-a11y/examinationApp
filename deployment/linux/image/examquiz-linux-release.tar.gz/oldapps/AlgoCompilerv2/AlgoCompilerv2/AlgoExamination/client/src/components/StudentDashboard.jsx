import React from 'react';
import { User, Clock, FileText, Play, CheckCircle2, AlertTriangle, LogOut } from 'lucide-react';

export default function StudentDashboard({ studentData, onEnterExam, onLogout }) {
  const { student, exam, sessionStatus } = studentData;

  const renderStatusBadge = () => {
    switch (exam.status) {
      case 'RUNNING':
        return <span className="badge badge-green"><Play size={12} /> En Cours</span>;
      case 'WAITING':
        return <span className="badge badge-yellow"><Clock size={12} /> Salle d’Attente</span>;
      case 'FINISHED':
      case 'CLOSED':
        return <span className="badge badge-blue"><CheckCircle2 size={12} /> Terminé</span>;
      default:
        return <span className="badge badge-yellow"><Clock size={12} /> Programmé</span>;
    }
  };

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '40px 20px' }}>
      {/* Student Identity Header */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ width: '52px', height: '52px', borderRadius: '50%', background: 'rgba(59, 130, 246, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(59, 130, 246, 0.4)' }}>
            <User size={28} color="#60a5fa" />
          </div>
          <div>
            <h2 style={{ fontSize: '1.4rem' }}>{student.firstName} {student.lastName}</h2>
            <div style={{ display: 'flex', gap: '15px', color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
              <span>Groupe: <strong>{student.group}</strong></span>
              <span>Spécialité: <strong>{student.speciality}</strong></span>
              <span>N° Accès: <code style={{ color: '#34d399', fontFamily: 'var(--font-mono)' }}>{student.accessNumber}</code></span>
            </div>
          </div>
        </div>

        <button className="btn btn-secondary" onClick={onLogout} title="Déconnexion">
          <LogOut size={16} /> Déconnexion
        </button>
      </div>

      <h3 style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <FileText color="#60a5fa" /> Mes Examens Assignés
      </h3>

      <div className="glass-panel" style={{ padding: '30px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
              <h2 style={{ fontSize: '1.5rem' }}>{exam.title}</h2>
              {renderStatusBadge()}
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
              {exam.description || 'Examen d’algorithmique contrôlé.'}
            </p>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', background: 'rgba(0, 0, 0, 0.2)', padding: '20px', borderRadius: '8px', marginBottom: '25px', border: '1px solid var(--panel-border)' }}>
          <div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>Durée Totale</div>
            <div style={{ fontSize: '1.2rem', fontWeight: '700', color: '#60a5fa' }}>{exam.durationMinutes} Minutes</div>
          </div>
          <div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>Sécurité Anti-Triche</div>
            <div style={{ fontSize: '0.95rem', fontWeight: '600', color: '#34d399' }}>Plein Écran Strict</div>
          </div>
          <div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>Langages Autorisés</div>
            <div style={{ fontSize: '0.85rem', fontWeight: '500', color: 'var(--text-main)', marginTop: '4px' }}>
              {exam.allowedLanguages.join(', ')}
            </div>
          </div>
        </div>

        {sessionStatus === 'TERMINATED' ? (
          <div style={{ padding: '16px', background: 'var(--danger-bg)', border: '1px solid var(--accent-red)', borderRadius: '8px', color: '#f87171', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <AlertTriangle size={24} />
            <div>Votre session d’examen a été interrompue par l’administrateur.</div>
          </div>
        ) : sessionStatus === 'FINISHED' ? (
          <div style={{ padding: '16px', background: 'rgba(59, 130, 246, 0.15)', border: '1px solid rgba(59, 130, 246, 0.3)', borderRadius: '8px', color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <CheckCircle2 size={24} />
            <div>Vous avez déjà soumis et terminé cet examen.</div>
          </div>
        ) : (
          <button
            className="btn btn-primary"
            style={{ width: '100%', padding: '14px', fontSize: '1.1rem' }}
            onClick={onEnterExam}
          >
            <Play size={20} /> {exam.status === 'RUNNING' ? 'Entrer en Salle d’Examen' : 'Rejoindre la Salle d’Attente'}
          </button>
        )}
      </div>
    </div>
  );
}
