import os
import json
import urllib.request

OLLAMA_DIR = os.path.expanduser('~/.ollama/models')
BLOBS_DIR = os.path.join(OLLAMA_DIR, 'blobs')
MANIFESTS_DIR = os.path.join(OLLAMA_DIR, 'manifests/registry.ollama.ai/library/qwen2.5-coder')

os.makedirs(BLOBS_DIR, exist_ok=True)
os.makedirs(MANIFESTS_DIR, exist_ok=True)

MODEL_TAG = '1.5b'
MANIFEST_URL = f"https://registry.ollama.ai/v2/library/qwen2.5-coder/manifests/{MODEL_TAG}"

print(f"Fetching manifest from {MANIFEST_URL}...")
req = urllib.request.Request(MANIFEST_URL, headers={'Accept': 'application/vnd.docker.distribution.manifest.v2+json'})
with urllib.request.urlopen(req) as resp:
    manifest_bytes = resp.read()
    manifest = json.loads(manifest_bytes.decode('utf-8'))

manifest_path = os.path.join(MANIFESTS_DIR, MODEL_TAG)
with open(manifest_path, 'wb') as f:
    f.write(manifest_bytes)
print(f"Saved manifest to {manifest_path}")

# Download each layer blob
layers = manifest.get('layers', []) + [manifest.get('config')]
for layer in layers:
    digest = layer['digest']
    clean_hash = digest.replace(':', '-')
    blob_file = os.path.join(BLOBS_DIR, clean_hash)
    
    if os.path.exists(blob_file) and os.path.getsize(blob_file) == layer['size']:
        print(f"Blob {clean_hash} already downloaded ({layer['size']} bytes). Skipping.")
        continue
        
    blob_url = f"https://registry.ollama.ai/v2/library/qwen2.5-coder/blobs/{digest}"
    print(f"Downloading blob {digest} ({layer['size']} bytes)...")
    
    try:
        req = urllib.request.Request(blob_url, headers={'User-Agent': 'ollama/0.32.9'})
        with urllib.request.urlopen(req) as resp, open(blob_file, 'wb') as out_f:
            copied = 0
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                out_f.write(chunk)
                copied += len(chunk)
                print(f"Downloaded {copied}/{layer['size']} bytes...", end='\r')
            print(f"\nSuccessfully downloaded {clean_hash}!")
    except Exception as e:
        print(f"Error downloading {digest}: {e}")

print("✅ Model download & manifest setup completed successfully!")
