import React, { useState, useEffect } from 'react';
import { listProblems, deleteProblem } from '../services/api';
import { BookOpen, Plus, Trash2, ArrowLeft, Edit3, Clock, Layers, Tag } from 'lucide-react';
import Swal from 'sweetalert2';
import ProblemStudio from './ProblemStudio';

function formatChapterShort(str) {
  if (!str) return 'Chapitre 1';
  const match = str.match(/^(?:Chapitre|CH)\s*(\d+)/i) || str.match(/Chapitre\s+(\d+)/i) || str.match(/CH(\d+)/i);
  if (match) {
    return `Chapitre ${match[1]}`;
  }
  return str;
}

export default function ProblemBank({ onBack, onSelectProblemForEdit }) {
  const [problems, setProblems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingProblem, setEditingProblem] = useState(null);
  const [isStudioOpen, setIsStudioOpen] = useState(false);

  const fetchProblems = async () => {
    try {
      setLoading(true);
      const data = await listProblems();
      setProblems(data);
    } catch (err) {
      console.error(err);
      Swal.fire('Erreur', 'Impossible de charger la banque de problèmes', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProblems();
  }, []);

  const handleOpenStudio = (problem = null) => {
    setEditingProblem(problem);
    setIsStudioOpen(true);
  };

  const handleCloseStudio = () => {
    setIsStudioOpen(false);
    setEditingProblem(null);
    fetchProblems();
  };

  const handleDelete = async (id) => {
    const res = await Swal.fire({
      title: 'Supprimer ce problème ?',
      text: 'Cette action est irréversible et supprimera également les cas de test associés.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#3b82f6',
      confirmButtonText: 'Oui, supprimer',
      cancelButtonText: 'Annuler',
      background: '#1e293b',
      color: '#f8fafc'
    });

    if (res.isConfirmed) {
      try {
        await deleteProblem(id);
        Swal.fire({
          icon: 'success',
          title: 'Supprimé !',
          text: 'Le problème a été retiré de la banque.',
          timer: 1500,
          showConfirmButton: false,
          background: '#1e293b',
          color: '#f8fafc'
        });
        fetchProblems();
      } catch (err) {
        console.error(err);
        Swal.fire('Erreur', 'Échec de la suppression', 'error');
      }
    }
  };

  if (isStudioOpen) {
    return (
      <ProblemStudio
        initialProblem={editingProblem}
        onBack={handleCloseStudio}
        onClose={handleCloseStudio}
        onSaveSuccess={() => {
          handleCloseStudio();
        }}
      />
    );
  }

  return (
    <div style={{ padding: '30px', maxWidth: '1200px', margin: '0 auto' }}>
      <button className="btn btn-secondary" onClick={onBack} style={{ marginBottom: '20px' }}>
        <ArrowLeft size={16} /> Retour au Dashboard
      </button>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' }}>
        <div>
          <h2>Banque de Problèmes Algorithmiques</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
            Studio d’édition de problèmes, sujets Markdown, briques de code et cas de tests.
          </p>
        </div>

        <button className="btn btn-primary" onClick={() => handleOpenStudio(null)}>
          <Plus size={16} /> Nouveau Problème
        </button>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>
          Chargement de la banque de problèmes...
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '20px' }}>
          {problems.map(p => {
            const diffCls = p.difficulty?.toUpperCase() === 'FACILE' ? 'badge-green' : (p.difficulty?.toUpperCase() === 'DIFFICILE' ? 'badge-red' : 'badge-yellow');
            const testCount = p.testCases?.length || 0;
            const qCount = p.questions?.length || 1;

            return (
              <div key={p.id} className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', borderRadius: '12px', border: '1px solid var(--panel-border)', background: 'rgba(17, 24, 39, 0.7)' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', gap: '8px', flexWrap: 'wrap' }}>
                    <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'nowrap' }}>
                      <span className="badge badge-purple" style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                        {formatChapterShort(p.topic || (p.tags && p.tags[0]) || 'Chapitre 1')}
                      </span>
                      <span className="badge badge-blue" style={{ fontSize: '0.75rem', whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center' }}>
                        {qCount === 1 ? '1 Question' : `${qCount} Questions`}
                      </span>
                    </div>
                    <span className={`badge ${diffCls}`} style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{p.difficulty || 'MOYEN'}</span>
                  </div>

                  <h3 style={{ fontSize: '1.15rem', fontWeight: '800', margin: '0 0 10px 0', color: '#f8fafc' }}>
                    {p.title}
                  </h3>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '14px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.78rem', color: '#94a3b8' }}>
                      <Clock size={13} color="#60a5fa" />
                      <span>Limite d'exécution : <strong style={{ color: '#cbd5e1' }}>{p.timeLimitMs || 2000} ms</strong></span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.78rem', color: '#94a3b8' }}>
                      <Layers size={13} color="#34d399" />
                      <span>Mode : <strong style={{ color: '#cbd5e1' }}>{testCount > 0 ? `${testCount} Cas de Test(s)` : 'Évaluation 100% Structure (Sans test)'}</strong></span>
                    </div>

                    {Array.isArray(p.tags) && p.tags.length > 0 && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap', marginTop: '4px' }}>
                        <Tag size={12} color="#a78bfa" />
                        {p.tags.map((t, idx) => (
                          <span key={idx} style={{ fontSize: '0.72rem', background: 'rgba(167, 139, 250, 0.15)', color: '#c4b5fd', padding: '1px 6px', borderRadius: '4px', border: '1px solid rgba(167, 139, 250, 0.3)', whiteSpace: 'nowrap' }}>
                            {formatChapterShort(t)}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div style={{ marginTop: '14px', paddingTop: '14px', borderTop: '1px solid var(--panel-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <button className="btn btn-secondary" style={{ padding: '6px 14px', fontSize: '0.82rem', fontWeight: '700', color: '#60a5fa', borderColor: 'rgba(96,165,250,0.3)', display: 'flex', alignItems: 'center', gap: '6px' }} onClick={() => handleOpenStudio(p)}>
                    <Edit3 size={14} /> Éditer dans le Studio
                  </button>
                  <button className="btn btn-secondary" style={{ padding: '6px 10px', color: '#f87171', borderColor: 'rgba(239,68,68,0.3)' }} onClick={() => handleDelete(p.id)} title="Supprimer ce problème">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
