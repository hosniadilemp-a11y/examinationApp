# 04. LLM Agent Coding & Prompting Guidelines

## 🤖 Directives for Future AI Agents & LLM Executions

When working on or modifying the **AlgoExamination** codebase, adhere to the following architectural constraints and conventions:

---

### 1. Date & Time Validation Rule
- **Never pass unparsed time strings** (e.g. `"14:00"`) directly into `new Date("14:00")` inside Prisma queries. In JavaScript, `new Date("14:00")` produces `Invalid Date`, which crashes Prisma with a `500 Validation Error`.
- Always use the `parseSafeDate(dateVal, timeVal)` helper in `exam.controller.js` to combine date and time into a valid Date object or `null`.

### 2. Dependency & Module Format Rule (`archiver`)
- The project uses Node.js CommonJS (`require()`).
- Do **NOT** upgrade `archiver` to version 6+ (which is an ES Module and throws `ERR_REQUIRE_ESM`).
- Keep `archiver@5.3.2` installed and required at the top of [grading.controller.js](file:///home/adel/Documents/Coding%20and%20projects/AlgoCompilerv2/AlgoExamination/server/src/controllers/grading.controller.js).

### 3. Lucide React Props Rule
- Do **NOT** pass `flexShrink` directly as a prop on SVG icon components (e.g., `<AlertTriangle flexShrink={0} />`). React will throw a DOM property warning.
- Always pass it inside inline style: `<AlertTriangle style={{ flexShrink: 0 }} />`.

### 4. Socket Room & Status Dual-Reporting Rule
- Whenever student status changes (such as `LOCK_STUDENT`, `UNLOCK_STUDENT`, `TERMINATE_STUDENT`, 3-strike auto-kick, or violation auto-suspend), you MUST emit **BOTH**:
  1. Target command to `student_${studentId}` (e.g., `student_locked`, `student_terminated`).
  2. Status broadcast to `exam_${examId}` (`student_status_changed`) so the teacher live dashboard updates immediately without manual page refresh.

### 5. PDF Generation & Styling Rules
- All PDF document generation in [pdf.service.js](file:///home/adel/Documents/Coding%20and%20projects/AlgoCompilerv2/AlgoExamination/server/src/services/pdf.service.js) MUST maintain a strict **Pure White Background & Black Text** academic theme.
- Never use solid dark background fills (`rect().fill('#111827')`) in PDFKit as it results in unreadable black pages on physical printers.
- Always include the dynamic `exam.university`, `exam.module`, and `exam.session` in the header block.

### 6. Barème & Point Allocation Preservation Rule
- When adding a new exercise to an exam in `ExamManager.jsx`, calculate remaining points up to 20 (`Math.max(0, 20 - sumOfExisting)`) and assign it to the new exercise.
- **Never reset or redistribute points on existing exercises** when toggling a new exercise on.

---

## 🎯 Quick Verification Commands for Agents

Before concluding any turn after editing code, run these automated checks:

```bash
# 1. Frontend compilation check
cd client && /home/adel/.cache/ms-playwright-go/1.57.0/node ./node_modules/vite/bin/vite.js build

# 2. Backend syntax & controller require check
cd server && PATH=/home/adel/.local/node-v20/bin:$PATH node -e "require('./src/controllers/exam.controller.js'); require('./src/controllers/grading.controller.js'); console.log('Syntax OK');"

# 3. Prisma schema validation
cd server && PATH=/home/adel/.local/node-v20/bin:$PATH npx prisma validate
```
