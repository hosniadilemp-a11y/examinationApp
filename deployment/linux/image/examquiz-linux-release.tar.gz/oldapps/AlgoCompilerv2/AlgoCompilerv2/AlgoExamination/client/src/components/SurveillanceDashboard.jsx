import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ShieldAlert, Eye, Play, Pause, Square, Clock, Users, Building,
  Download, RefreshCw, AlertTriangle, CheckCircle, Wifi, WifiOff,
  Search, ArrowLeft, Maximize, AlertOctagon, Plus, Settings, LogOut,
  Upload, FileCode, Trash2, Package, Radio, MessageSquare, Volume2,
  FileCheck, Shield, ChevronRight, Sparkles, Edit3
} from 'lucide-react';
import Swal from 'sweetalert2';
import {
  listExams, getExamDetails, updateExamStatus, deleteExam,
  exportExamBundle, importExamTemplate, listStudents
} from '../services/api';
import SystemSettingsModal, { getSystemVaultKey } from './SystemSettingsModal';
import ExamLauncher from './ExamLauncher';
import ExamMonitor from './ExamMonitor';
import FileDropZone from './FileDropZone';

/* ── STATUS BADGE CONFIG ── */
const EXAM_STATUS = {
  DRAFT:     { label: 'Modèle (Brouillon)', cls: 'badge-secondary', color: '#6b7280' },
  SCHEDULED: { label: 'Planifié',          cls: 'badge-yellow',    color: '#f59e0b' },
  WAITING:   { label: 'En Attente',         cls: 'badge-yellow',    color: '#f59e0b' },
  RUNNING:   { label: 'En Cours (LIVE)',    cls: 'badge-green',     color: '#10b981' },
  PAUSED:    { label: 'Suspendu',           cls: 'badge-red',       color: '#ef4444' },
  FINISHED:  { label: 'Terminé',            cls: 'badge-purple',    color: '#c084fc' },
  CLOSED:    { label: 'Clôturé',            cls: 'badge-secondary', color: '#6b7280' },
};

export default function SurveillanceDashboard({ onLogout }) {
  const [view, setView] = useState('EXAM_LIST'); // EXAM_LIST | EXAM_LAUNCH | EXAM_MONITOR | EXAM_STATUSES
  const [selectedExam, setSelectedExam] = useState(null);
  const [exams, setExams] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [templateFile, setTemplateFile] = useState(null);
  const [importingTemplate, setImportingTemplate] = useState(false);
  const pollRef = useRef(null);

  const load = useCallback(async () => {
    try {
      const [examsData, studentsData] = await Promise.all([
        listExams(),
        listStudents().catch(() => [])
      ]);
      setExams(examsData);
      setStudents(studentsData);
    } catch (e) {
      console.error('Surveillance load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    pollRef.current = setInterval(load, 8000);
    return () => clearInterval(pollRef.current);
  }, [load]);

  const handleStatusChange = async (exam, newStatus) => {
    if (newStatus === 'FINISHED') {
      const confirm = await Swal.fire({
        title: '🏁 Terminer l\'Épreuve ?',
        html: `<p style="color: #fca5a5;">Cette action va <strong>expulser tous les étudiants encore connectés</strong> et clôturer l'examen "${exam.title}".</p>`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Oui, terminer l\'épreuve',
        cancelButtonText: 'Annuler',
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        background: '#111827',
        color: '#fff'
      });
      if (!confirm.isConfirmed) return;
    }

    try {
      await updateExamStatus(exam.id, newStatus);
      await load();

      if (newStatus === 'FINISHED') {
        const askExport = await Swal.fire({
          icon: 'success',
          title: '🏁 Épreuve Terminée !',
          text: 'Tous les étudiants ont été déconnectés. Souhaitez-vous télécharger le paquet chiffré .algobundle maintenant pour l\'enseignant ?',
          showCancelButton: true,
          confirmButtonText: '📦 Télécharger le Paquet (.algobundle)',
          cancelButtonText: 'Plus tard',
          confirmButtonColor: '#10b981',
          cancelButtonColor: '#64748b',
          background: '#111827',
          color: '#fff'
        });
        if (askExport.isConfirmed) {
          await handleExportBundle(exam.id, exam.title);
        }
      } else {
        Swal.fire({
          icon: 'success',
          title: `Statut → ${EXAM_STATUS[newStatus]?.label || newStatus}`,
          timer: 1200,
          showConfirmButton: false,
          background: '#111827',
          color: '#fff'
        });
      }
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Erreur',
        text: err.data?.error || err.message,
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const handleExportBundle = async (examId, title) => {
    try {
      const examObj = exams.find(e => e.id === examId);
      const moduleName = (examObj?.module || 'ASD').replace(/[^\w]/g, '_');
      const safeTitle = (title || examObj?.title || 'Examen').replace(/[^\w]/g, '_');
      const roomStr = (examObj?.room || 'Salle').replace(/[^\w]/g, '_');
      const examCode = (examObj?.examCode || '').replace(/[^\w]/g, '_');

      const vaultKey = getSystemVaultKey();
      const encryptedData = await exportExamBundle(examId, vaultKey);
      const jsonStr = JSON.stringify(encryptedData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Copies_${moduleName}_${safeTitle}_${roomStr}${examCode ? '_' + examCode : ''}.algobundle`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: '📦 Paquet de Salle Exporté !',
        text: 'Le fichier chiffré .algobundle est prêt pour la transmission à l\'enseignant.',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export bundle error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Impossible d’exporter le paquet.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const handleDeleteExam = async (exam) => {
    const confirm = await Swal.fire({
      title: '🗑️ Supprimer cette Épreuve ?',
      text: `Êtes-vous sûr de vouloir supprimer l'examen "${exam.title}" ? Cette action est irréversible.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Oui, supprimer',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff'
    });

    if (confirm.isConfirmed) {
      try {
        await deleteExam(exam.id);
        Swal.fire({
          icon: 'success',
          title: 'Examen Supprimé',
          timer: 1500,
          showConfirmButton: false,
          background: '#111827',
          color: '#fff'
        });
        load();
      } catch (err) {
        Swal.fire({
          icon: 'error',
          title: 'Erreur',
          text: err.data?.error || err.message || 'Impossible de supprimer cet examen.',
          background: '#111827',
          color: '#fff'
        });
      }
    }
  };

  const handleProcessImportTemplate = async () => {
    if (!templateFile) return;
    setImportingTemplate(true);
    try {
      const formData = new FormData();
      formData.append('template', templateFile);

      const res = await importExamTemplate(formData);
      setIsImportModalOpen(false);
      setTemplateFile(null);
      await load();

      Swal.fire({
        icon: 'success',
        title: 'Modèle Importé avec Succès !',
        text: `L'épreuve "${res.exam?.title}" est prête. Vous pouvez maintenant configurer et lancer la salle.`,
        background: '#111827',
        color: '#fff'
      });

      setSelectedExam(res.exam);
      setView('EXAM_LAUNCH');
    } catch (err) {
      console.error('Import template error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Importation',
        text: err.data?.error || err.message || 'Fichier .algoexam invalide.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setImportingTemplate(false);
    }
  };

  const stats = {
    total:    exams.length,
    running:  exams.filter(e => e.status === 'RUNNING').length,
    waiting:  exams.filter(e => e.status === 'WAITING').length,
    finished: exams.filter(e => e.status === 'FINISHED' || e.status === 'CLOSED').length,
  };

  const filteredExams = exams.filter(exam => {
    const matchSearch = !search.trim() ||
      exam.title.toLowerCase().includes(search.toLowerCase()) ||
      (exam.module && exam.module.toLowerCase().includes(search.toLowerCase())) ||
      (exam.room && exam.room.toLowerCase().includes(search.toLowerCase())) ||
      (exam.examCode && exam.examCode.toLowerCase().includes(search.toLowerCase()));

    if (filterStatus === 'RUNNING') return matchSearch && ['RUNNING', 'WAITING', 'PAUSED'].includes(exam.status);
    if (filterStatus === 'WAITING') return matchSearch && ['DRAFT', 'SCHEDULED', 'WAITING'].includes(exam.status);
    if (filterStatus === 'FINISHED') return matchSearch && ['FINISHED', 'CLOSED'].includes(exam.status);
    return matchSearch;
  });

  // Render Exam Launcher
  if (view === 'EXAM_LAUNCH' && selectedExam) {
    return (
      <ExamLauncher
        exam={selectedExam}
        students={students}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); load(); }}
        onExamLaunched={(updatedExam) => {
          setSelectedExam(updatedExam || selectedExam);
          setView('EXAM_MONITOR');
          load();
        }}
      />
    );
  }

  // Render Full Live Proctoring Monitor (EXACT SAME as Teacher View)
  if (view === 'EXAM_MONITOR' && selectedExam) {
    return (
      <ExamMonitor
        exam={selectedExam}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); load(); }}
      />
    );
  }

  // Render Attendance & Statuses View
  if (view === 'EXAM_STATUSES' && selectedExam) {
    return (
      <SurveillanceAttendanceView
        exam={selectedExam}
        onBack={() => { setView('EXAM_LIST'); setSelectedExam(null); load(); }}
      />
    );
  }

  const launchedExams = exams.filter(e => ['RUNNING', 'WAITING', 'PAUSED', 'FINISHED', 'CLOSED'].includes(e.status) || (e._count?.assignments > 0));
  const subjectTemplates = exams.filter(e => ['DRAFT', 'SCHEDULED'].includes(e.status) && (!e._count?.assignments || e._count?.assignments === 0));

  return (
    <div style={{ padding: '28px', maxWidth: '1380px', margin: '0 auto' }}>
      
      {/* ═══════════════════════════════════════════════════════════
          VARIANTE 3 : LINE 1 (TOP IDENTITY & GLOBAL SYSTEM TOOLS)
      ═══════════════════════════════════════════════════════════ */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '22px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ fontSize: '1.6rem' }}>👁️</span>
            <h1 style={{ fontSize: '1.65rem', fontWeight: '800', margin: 0, color: '#f8fafc', letterSpacing: '-0.5px' }}>
              Espace Surveillance & Gestion des Salles
            </h1>
            <span className="badge badge-yellow" style={{ fontSize: '0.72rem', padding: '3px 8px' }}>SURVEILLANCE LIVE</span>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.86rem', margin: '4px 0 0 0' }}>
            Lancement de salle, présence des candidats, surveillance anti-triche et export des paquets d'épreuves.
          </p>
        </div>

        {/* Global system actions */}
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' }}>
          <button className="btn btn-secondary" onClick={load} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <RefreshCw size={14} /> Actualiser
          </button>
          <button className="btn btn-secondary" onClick={() => setIsSettingsOpen(true)} style={{ padding: '7px 12px', fontSize: '0.84rem' }}>
            <Settings size={14} /> Paramètres
          </button>
          {onLogout && (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onLogout}
              style={{ color: '#f87171', borderColor: 'rgba(239, 68, 68, 0.3)', display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 12px', fontSize: '0.84rem' }}
            >
              <LogOut size={14} /> Déconnexion
            </button>
          )}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════
          VARIANTE 3 : LINE 2 (LINEAR / GITHUB TABBED COMMAND BAR)
      ═══════════════════════════════════════════════════════════ */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
        marginBottom: '24px',
        paddingBottom: '0px',
        flexWrap: 'wrap',
        gap: '14px'
      }}>
        {/* Left: Underlined Clean Tabs */}
        <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
          <button
            onClick={() => setFilterStatus('ALL')}
            style={{
              background: 'transparent',
              border: 'none',
              borderBottom: filterStatus === 'ALL' ? '2px solid #10b981' : '2px solid transparent',
              color: filterStatus === 'ALL' ? '#34d399' : 'var(--text-muted)',
              padding: '12px 18px',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '0.92rem',
              transition: 'all 0.15s ease'
            }}
          >
            <Radio size={16} /> 🟢 Toutes les Salles
            <span style={{
              fontSize: '0.75rem',
              padding: '2px 7px',
              borderRadius: '12px',
              background: filterStatus === 'ALL' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.06)',
              color: filterStatus === 'ALL' ? '#34d399' : 'var(--text-muted)'
            }}>
              {exams.length}
            </span>
          </button>

          <button
            onClick={() => setFilterStatus('ACTIVE')}
            style={{
              background: 'transparent',
              border: 'none',
              borderBottom: filterStatus === 'ACTIVE' ? '2px solid #3b82f6' : '2px solid transparent',
              color: filterStatus === 'ACTIVE' ? '#93c5fd' : 'var(--text-muted)',
              padding: '12px 18px',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '0.92rem',
              transition: 'all 0.15s ease'
            }}
          >
            <Eye size={16} /> 👁️ En Cours & En Attente
            <span style={{
              fontSize: '0.75rem',
              padding: '2px 7px',
              borderRadius: '12px',
              background: filterStatus === 'ACTIVE' ? 'rgba(59, 130, 246, 0.2)' : 'rgba(255,255,255,0.06)',
              color: filterStatus === 'ACTIVE' ? '#93c5fd' : 'var(--text-muted)'
            }}>
              {stats.running + stats.waiting}
            </span>
          </button>

          <button
            onClick={() => setFilterStatus('FINISHED')}
            style={{
              background: 'transparent',
              border: 'none',
              borderBottom: filterStatus === 'FINISHED' ? '2px solid #a78bfa' : '2px solid transparent',
              color: filterStatus === 'FINISHED' ? '#c084fc' : 'var(--text-muted)',
              padding: '12px 18px',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '0.92rem',
              transition: 'all 0.15s ease'
            }}
          >
            <Package size={16} /> 📦 Terminées & Paquets Prêts
            <span style={{
              fontSize: '0.75rem',
              padding: '2px 7px',
              borderRadius: '12px',
              background: filterStatus === 'FINISHED' ? 'rgba(168, 85, 247, 0.2)' : 'rgba(255,255,255,0.06)',
              color: filterStatus === 'FINISHED' ? '#c084fc' : 'var(--text-muted)'
            }}>
              {stats.finished}
            </span>
          </button>
        </div>

        {/* Right: Actions */}
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', paddingBottom: '8px' }}>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setIsImportModalOpen(true)}
            style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 16px', fontSize: '0.85rem', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', fontWeight: '700' }}
            title="Importer un modèle .algoexam préparé par l'enseignant pour lancer une salle"
          >
            <Upload size={14} /> 📥 Importer un Modèle (.algoexam)
          </button>
        </div>
      </div>

      {/* ── Stats Summary Row ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
        {[
          { label: 'Total Salles & Épreuves', value: stats.total, color: '#60a5fa', icon: '📋' },
          { label: 'En Cours (LIVE)', value: stats.running, color: '#10b981', icon: '🟢' },
          { label: 'En Attente / Prêt', value: stats.waiting, color: '#f59e0b', icon: '⏳' },
          { label: 'Terminées (Paquets Prêts)', value: stats.finished, color: '#a78bfa', icon: '📦' },
        ].map(({ label, value, color, icon }) => (
          <div key={label} className="glass-panel" style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ fontSize: '1.8rem' }}>{icon}</div>
            <div>
              <div style={{ fontSize: '1.6rem', fontWeight: '800', color, lineHeight: 1.1 }}>{value}</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* ── Search & Filter Controls ── */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px', alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: '240px' }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
          <input
            type="text"
            className="form-input"
            placeholder="Rechercher par titre, module, salle ou code..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ paddingLeft: '38px', fontSize: '0.88rem' }}
          />
        </div>

        <div style={{ display: 'flex', gap: '6px' }}>
          {[
            { id: 'ALL', label: 'Toutes les épreuves' },
            { id: 'RUNNING', label: 'En Cours (LIVE)' },
            { id: 'WAITING', label: 'En Attente' },
            { id: 'FINISHED', label: 'Terminées' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className="btn"
              style={{
                fontSize: '0.82rem',
                padding: '8px 14px',
                background: filterStatus === tab.id ? 'rgba(59, 130, 246, 0.25)' : 'rgba(30, 41, 59, 0.6)',
                border: filterStatus === tab.id ? '1px solid #3b82f6' : '1px solid #334155',
                color: filterStatus === tab.id ? '#60a5fa' : '#94a3b8',
                fontWeight: filterStatus === tab.id ? '700' : '500'
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Exam Cards List ── */}
      {loading ? (
        <div className="glass-panel" style={{ padding: '60px', textAlign: 'center', color: 'var(--text-muted)' }}>
          Chargement des épreuves pour la surveillance...
        </div>
      ) : filteredExams.length === 0 ? (
        <div className="glass-panel" style={{ padding: '60px', textAlign: 'center' }}>
          <div style={{ fontSize: '3rem', marginBottom: '16px' }}>📋</div>
          <h3 style={{ margin: '0 0 8px 0' }}>Aucune épreuve trouvée</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '16px' }}>
            Importez un modèle <code>.algoexam</code> fourni par l'enseignant pour configurer et lancer votre salle.
          </p>
          <button className="btn btn-primary" onClick={() => setIsImportModalOpen(true)}>
            <Upload size={16} /> Importer un Modèle (.algoexam)
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {filteredExams.map(exam => {
            const si = EXAM_STATUS[exam.status] || EXAM_STATUS.DRAFT;
            const isNotLaunched = ['DRAFT', 'SCHEDULED'].includes(exam.status);
            const isRunningOrLive = ['RUNNING', 'WAITING', 'PAUSED'].includes(exam.status);
            const isFinished = ['FINISHED', 'CLOSED'].includes(exam.status);

            return (
              <div
                key={exam.id}
                className="glass-panel"
                style={{
                  padding: '22px 26px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '14px',
                  borderLeft: `4px solid ${si.color}`
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '20px', justifyContent: 'space-between', flexWrap: 'wrap' }}>
                  
                  {/* Left info */}
                  <div style={{ flex: 1, minWidth: '260px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px', flexWrap: 'wrap' }}>
                      <span className={`badge ${si.cls}`}>{si.label}</span>
                      {exam.examCode && (
                        <code style={{ fontSize: '0.8rem', color: '#a78bfa', background: 'rgba(167,139,250,0.1)', padding: '2px 8px', borderRadius: '4px', border: '1px solid rgba(167,139,250,0.3)' }}>
                          {exam.examCode}
                        </code>
                      )}
                      <span style={{ fontSize: '1.25rem', fontWeight: '800', color: '#f8fafc' }}>
                        {exam.title}
                      </span>
                    </div>

                    <div style={{ display: 'flex', gap: '18px', color: 'var(--text-muted)', fontSize: '0.83rem', flexWrap: 'wrap' }}>
                      <span>📚 {exam.module || 'ASD'}</span>
                      <span>⏱ {exam.durationMinutes} min</span>
                      <span>👥 {exam._count?.assignments || 0} candidat(s)</span>
                      <span>🧩 {exam._count?.problems || 0} exercice(s)</span>
                      {exam.room && (
                        <span>🏢 Salle : <strong style={{ color: '#34d399' }}>{exam.room}</strong></span>
                      )}
                    </div>
                  </div>

                  {/* Right Actions */}
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
                    
                    {/* State 1: Ready to launch */}
                    {isNotLaunched && (
                      <>
                        <button
                          className="btn btn-success"
                          style={{ padding: '8px 18px', fontSize: '0.85rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '6px', background: 'linear-gradient(135deg, #10b981, #059669)', boxShadow: '0 4px 12px rgba(16,185,129,0.3)' }}
                          onClick={() => { setSelectedExam(exam); setView('EXAM_LAUNCH'); }}
                          title="Configurer la salle et importer les étudiants"
                        >
                          <Play size={15} fill="#fff" /> Lancer la Salle
                        </button>

                        <button
                          className="btn btn-danger"
                          style={{ padding: '8px 10px', fontSize: '0.8rem' }}
                          onClick={() => handleDeleteExam(exam)}
                          title="Supprimer cette épreuve"
                        >
                          <Trash2 size={14} />
                        </button>
                      </>
                    )}

                    {/* State 2: Live / Running */}
                    {isRunningOrLive && (
                      <>
                        <button
                          className="btn btn-primary"
                          style={{ padding: '8px 18px', fontSize: '0.85rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '6px', background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)', boxShadow: '0 4px 14px rgba(59,130,246,0.4)' }}
                          onClick={() => { setSelectedExam(exam); setView('EXAM_MONITOR'); }}
                          title="Surveiller les candidats en temps réel avec toutes les options de proctoring"
                        >
                          <Eye size={15} /> Surveiller l'Épreuve (Live)
                        </button>

                        {/* Paquet button disabled while exam is in progress */}
                        <button
                          className="btn btn-secondary"
                          disabled={true}
                          style={{ padding: '8px 12px', fontSize: '0.82rem', opacity: 0.5, cursor: 'not-allowed' }}
                          title="Le paquet de copies .algobundle sera disponible une fois l'examen terminé"
                        >
                          <Package size={14} /> Paquet (En cours)
                        </button>

                        {exam.status === 'RUNNING' ? (
                          <button
                            className="btn btn-secondary"
                            style={{ padding: '8px 12px', fontSize: '0.82rem', color: '#f59e0b' }}
                            onClick={() => handleStatusChange(exam, 'PAUSED')}
                            title="Suspendre l'épreuve"
                          >
                            <Pause size={14} /> Suspendre
                          </button>
                        ) : (
                          <button
                            className="btn btn-secondary"
                            style={{ padding: '8px 12px', fontSize: '0.82rem', color: '#10b981' }}
                            onClick={() => handleStatusChange(exam, 'RUNNING')}
                            title="Reprendre l'épreuve"
                          >
                            <Play size={14} /> Reprendre
                          </button>
                        )}

                        <button
                          className="btn btn-danger"
                          style={{ padding: '8px 12px', fontSize: '0.82rem' }}
                          onClick={() => handleStatusChange(exam, 'FINISHED')}
                          title="Terminer l'épreuve pour toute la salle"
                        >
                          <Square size={14} /> Terminer
                        </button>
                      </>
                    )}

                    {/* State 3: Finished */}
                    {isFinished && (
                      <>
                        <button
                          className="btn btn-primary"
                          style={{ padding: '8px 16px', fontSize: '0.85rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '6px', background: 'linear-gradient(135deg, #10b981, #059669)', boxShadow: '0 4px 12px rgba(16,185,129,0.3)' }}
                          onClick={() => handleExportBundle(exam.id, exam.title)}
                          title="Exporter le paquet de soumissions chiffré (.algobundle) pour l'enseignant"
                        >
                          <Package size={15} /> Exporter le Paquet Salle (.algobundle)
                        </button>

                        <button
                          className="btn btn-secondary"
                          style={{ padding: '8px 14px', fontSize: '0.85rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '6px' }}
                          onClick={() => { setSelectedExam(exam); setView('EXAM_STATUSES'); }}
                          title="Voir les présences et le statut final des candidats"
                        >
                          <Users size={15} /> Présences & Statuts
                        </button>

                        <button
                          className="btn btn-danger"
                          style={{ padding: '8px 10px', fontSize: '0.8rem' }}
                          onClick={() => handleDeleteExam(exam)}
                          title="Supprimer cette épreuve"
                        >
                          <Trash2 size={14} />
                        </button>
                      </>
                    )}

                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── DRAG & DROP MODAL: IMPORT EXAM TEMPLATE (.algoexam) ── */}
      {isImportModalOpen && (
        <div className="fullscreen-overlay" style={{ background: 'rgba(0,0,0,0.8)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '100%', maxWidth: '520px', padding: '30px' }}>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '1.25rem', fontWeight: '800', color: '#34d399', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Upload size={20} /> Importer un Modèle d'Épreuve (.algoexam)
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '18px' }}>
              Sélectionnez ou glissez-déposez le fichier <code>.algoexam</code> transmis par l'équipe pédagogique.
            </p>

            <FileDropZone
              accept=".algoexam,.json"
              selectedFile={templateFile}
              onFileSelect={(file) => setTemplateFile(file)}
              onClear={() => setTemplateFile(null)}
              label="Glissez & déposez le fichier .algoexam ici"
              hint="ou cliquez pour parcourir vos dossiers"
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => { setIsImportModalOpen(false); setTemplateFile(null); }}
                disabled={importingTemplate}
              >
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleProcessImportTemplate}
                disabled={!templateFile || importingTemplate}
                style={{ background: 'linear-gradient(135deg, #10b981, #059669)' }}
              >
                {importingTemplate ? 'Importation en cours...' : 'Importer & Configurer Salle'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* System Settings Modal */}
      <SystemSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   SURVEILLANCE ATTENDANCE & STATUSES VIEW
 ═══════════════════════════════════════════════════════════ */
function SurveillanceAttendanceView({ exam, onBack }) {
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getExamDetails(exam.id)
      .then(setDetail)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [exam.id]);

  const assignments = detail?.assignments || [];

  return (
    <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
      <button className="btn btn-secondary" onClick={onBack} style={{ marginBottom: '20px' }}>
        <ArrowLeft size={16} /> Retour au Dashboard
      </button>

      <div className="glass-panel" style={{ padding: '24px', marginBottom: '24px' }}>
        <h2 style={{ margin: '0 0 6px 0', fontSize: '1.4rem' }}>
          👁️ Registre des Présences & Statuts — {exam.title}
        </h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', margin: 0 }}>
          Salle : <strong style={{ color: '#34d399' }}>{exam.room || 'Non assignée'}</strong> • Total candidats : {assignments.length}
        </p>
      </div>

      {loading ? (
        <div className="glass-panel" style={{ padding: '40px', textAlign: 'center' }}>Chargement...</div>
      ) : (
        <div className="glass-panel" style={{ padding: '20px' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Code Anonyme</th>
                <th>Nom & Prénom</th>
                <th>Matricule</th>
                <th>Groupe</th>
                <th>Statut Final</th>
                <th>Incidents Anti-triche</th>
              </tr>
            </thead>
            <tbody>
              {assignments.map(a => (
                <tr key={a.id}>
                  <td><code style={{ color: '#34d399', fontWeight: '700' }}>{a.accessNumber}</code></td>
                  <td><strong>{a.student?.lastName} {a.student?.firstName}</strong></td>
                  <td>{a.student?.studentId}</td>
                  <td>{a.student?.group}</td>
                  <td>
                    <span className={`badge ${a.status === 'FINISHED' ? 'badge-primary' : a.status === 'KICKED_OUT' ? 'badge-danger' : 'badge-muted'}`}>
                      {a.status}
                    </span>
                  </td>
                  <td>
                    <span style={{ color: (a.violations || 0) > 0 ? '#f87171' : '#34d399', fontWeight: '700' }}>
                      {a.violations || 0} violation(s)
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
