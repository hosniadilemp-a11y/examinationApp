import { EditorState, RangeSetBuilder, Annotation } from '@codemirror/state';
import { Decoration, ViewPlugin } from '@codemirror/view';

export const MARKER_REGEX = /^\s*\/\/\s*(?:question\s+(\d+)\s+(?:starts|ends|commence|se\s+termine|termine|d[ée]bute?|fin)\s*(?:here|ici)?|(?:d[ée]but|fin)\s+question\s+(\d+))\s*$/i;

export const formatTransactionAnnotation = Annotation.define();

export function isMarkerLine(lineText) {
  return MARKER_REGEX.test(lineText);
}

// 1. Transaction changeFilter: Blocks any edit or deletion of the marker line text,
// but permits inserting new lines/code directly after or before the marker line,
// and permits formatting transactions that preserve all marker lines intact.
export const lockedMarkersChangeFilter = EditorState.changeFilter.of((tr) => {
  if (!tr.docChanged) return true;

  // If this is a format transaction, allow it if all marker comments remain intact
  if (tr.annotation(formatTransactionAnnotation)) {
    const doc = tr.startState.doc;
    const originalMarkers = [];
    for (let l = 1; l <= doc.lines; l++) {
      const lineText = doc.line(l).text.trim();
      if (MARKER_REGEX.test(lineText)) {
        originalMarkers.push(lineText);
      }
    }
    const newText = tr.newDoc.toString();
    const newLines = newText.split(/\r?\n/).map(l => l.trim());
    const allPreserved = originalMarkers.every(m => newLines.includes(m));
    return allPreserved;
  }

  const doc = tr.startState.doc;
  let blocksEdit = false;

  tr.changes.iterChanges((fromA, toA) => {
    if (blocksEdit) return;

    const lineStart = doc.lineAt(fromA);
    const lineEnd = doc.lineAt(toA);

    for (let l = lineStart.number; l <= lineEnd.number; l++) {
      const line = doc.line(l);
      if (MARKER_REGEX.test(line.text)) {
        if (fromA === toA) {
          // Pure insertion: only block if inserting strictly INSIDE the marker comment text
          if (fromA > line.from && fromA < line.to) {
            blocksEdit = true;
            break;
          }
        } else {
          // Deletion or replacement: block if it touches/alters the marker line characters
          if (fromA < line.to && toA > line.from) {
            blocksEdit = true;
            break;
          }
        }
      }
    }
  });

  return !blocksEdit;
});

// 2. Visual Decorations: Highlights locked marker lines with a distinct style
const markerLineDeco = Decoration.line({
  attributes: {
    class: 'cm-locked-marker-line',
    style: 'background: rgba(167, 139, 250, 0.14); border-left: 3px solid #a78bfa; font-weight: 700; color: #c4b5fd; user-select: none;'
  }
});

export const lockedMarkersViewPlugin = ViewPlugin.fromClass(class {
  constructor(view) {
    this.decorations = this.buildDecorations(view);
  }

  update(update) {
    if (update.docChanged || update.viewportChanged) {
      this.decorations = this.buildDecorations(update.view);
    }
  }

  buildDecorations(view) {
    const builder = new RangeSetBuilder();
    for (const { from, to } of view.visibleRanges) {
      for (let pos = from; pos <= to;) {
        const line = view.state.doc.lineAt(pos);
        if (MARKER_REGEX.test(line.text)) {
          builder.add(line.from, line.from, markerLineDeco);
        }
        pos = line.to + 1;
      }
    }
    return builder.finish();
  }
}, {
  decorations: v => v.decorations
});

export function lockedZonesExtension() {
  return [lockedMarkersChangeFilter, lockedMarkersViewPlugin];
}
