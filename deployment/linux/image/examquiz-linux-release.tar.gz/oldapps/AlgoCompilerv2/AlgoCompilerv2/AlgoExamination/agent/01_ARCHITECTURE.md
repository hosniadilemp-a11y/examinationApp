# AlgoExamination — Architecture Map

## Stack

### Frontend
- React + Vite
- Vanilla CSS design system
- Lucide React
- SweetAlert2
- Socket.IO Client
- Custom Monaco-style pseudo-code editor

### Backend
- Node.js 20
- Express
- PostgreSQL
- Prisma ORM, schema `exam`
- Socket.IO
- PDFKit
- qrcode
- archiver 5.3.2 CommonJS
- child-process based pseudo-code runner

## Directory

```text
AlgoExamination/
├── client/
│   └── src/
│       ├── components/
│       ├── services/
│       └── utils/
├── server/
│   ├── prisma/
│   └── src/
│       ├── controllers/
│       ├── middleware/
│       ├── runner/
│       ├── services/
│       ├── sockets/
│       └── index.js
└── doc/
```

## Main Frontend Components

- `ExamManager.jsx`: exam authoring
- `WaitingRoom.jsx`: pre-exam gate
- `ExamWorkspace.jsx`: student exam
- `TeacherDashboard.jsx`: live monitoring
- `CorrectionWorkspace.jsx`: grading/export
- `ExamResults.jsx`: results
- `ProblemBank.jsx`: problems/tests
- `StudentDashboard.jsx`: student portal
- `StudentManager.jsx`: roster
- `StudentLogin.jsx`: student access
- `TeacherLogin.jsx`: teacher authentication

## Main Backend Areas

- `auth.controller.js`: authentication
- `exam.controller.js`: exam lifecycle
- `student.controller.js`: student workspace/autosave/violations
- `student-mgmt.controller.js`: roster
- `grading.controller.js`: grading/export
- `prototype.controller.js`: 3-module AI evaluation (Sandbox test 50%, AST structure 25%, Ollama LLM rubric 25%), student plagiarism similarity analysis
- `problem.controller.js`: problem bank
- `exam.socket.js`: real-time events
- `code-execution.service.js`: pseudo-code runner
- `pdf.service.js`: official PDF generation with line comments and QR authentication

## Critical Data Flow

### Student enters exam

```text
StudentLogin
  → API authentication
  → ExamAssignment
  → WaitingRoom
  → Socket room subscription
  → Teacher launches exam
  → exam_started / exam_status_changed
  → ExamWorkspace
```

### Student saves code

```text
ExamWorkspace
  → POST autosave
  → student.controller.js
  → ExamAssignment.currentCodeMap
```

### Violation

```text
Browser event
  → student violation endpoint/socket
  → persistence
  → status calculation
  → student_${studentId} command
  → exam_${examId} student_status_changed
  → TeacherDashboard
```

### Grading

```text
CorrectionWorkspace
  → grading API
  → grading.controller.js
  → syntax analysis / grade persistence
  → PDF service
  → PDF/ZIP response
```

## Architecture Rule

Before modifying a component, identify:
1. What data it owns.
2. Which API endpoints it calls.
3. Which socket events it consumes/emits.
4. Which database fields it depends on.
5. Which other components depend on its output.
