/**
 * Bulk Import Script: Imports all ~62 examples from AlgoCompiler/examples into Problem Bank
 * Parses single vs multi-function structure, extracts sub-questions, adds question markers,
 * and creates Problem and ProblemQuestion records in PostgreSQL database.
 */

const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const EXAMPLES_DIR = path.resolve(__dirname, '../../../../AlgoCompiler/examples');

const CATEGORY_TOPIC_MAP = {
  'Arrays': 'Chapitre 2: Tableaux et Matrices',
  'Basics': "Chapitre 1: Introduction à l'Algorithmique",
  'Dynamic_Allocation': 'Chapitre 4: Allocation Dynamique',
  'Enregistrements': 'Chapitre 6: Les Enregistrements',
  'Files': 'Chapitre 10: Les Files (Queues)',
  'Functions': 'Chapitre 5: Actions Paramétrées (Fonctions & Procédures)',
  'Listes_Chainees': 'Chapitre 8: Les Listes Chaînées',
  'Piles': 'Chapitre 9: Les Piles (Stacks)',
  'Pointers': 'Chapitre 4: Allocation Dynamique',
  'Strings': 'Chapitre 3: Chaînes de Caractères',
  'Tests': "Chapitre 1: Introduction à l'Algorithmique"
};

function formatTitle(filename) {
  let name = filename.replace(/\.algo$/i, '');
  name = name.replace(/^\d+_/i, '');
  name = name.replace(/_/g, ' ');
  return name.trim();
}

function parseAlgoFile(filePath, category) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const filename = path.basename(filePath);
  const title = formatTitle(filename);
  const topic = CATEGORY_TOPIC_MAP[category] || "Chapitre 1: Introduction à l'Algorithmique";

  // Extract leading comments as description
  const lines = content.split('\n');
  const commentLines = [];
  let codeStartIdx = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.startsWith('//') || line.startsWith('/*') || line.startsWith('*') || line === '') {
      if (line.startsWith('//') && !line.includes('===') && !line.includes('---')) {
        commentLines.push(line.replace(/^\/\/\s*/, ''));
      }
    } else {
      codeStartIdx = i;
      break;
    }
  }

  const rawDescription = commentLines.filter(Boolean).join(' ').trim();
  const description = rawDescription.length > 10
    ? rawDescription
    : `Étude et implémentation algorithmique pour **${title}** (${topic}).`;

  // Detect functions / procedures for multi-question splitting
  const funcRegex = /(Fonction|Procedure)\s+([a-zA-Z0-9_]+)\s*\(([\s\S]*?)\)(?:\s*:\s*([a-zA-Z0-9_\[\]]+))?/gi;
  const matches = [];
  let match;

  while ((match = funcRegex.exec(content)) !== null) {
    matches.push({
      kind: match[1],
      name: match[2],
      params: match[3],
      returnType: match[4] || null,
      index: match.index
    });
  }

  // Difficulty estimation
  let difficulty = 'MOYEN';
  if (category === 'Basics' || category === 'Strings') difficulty = 'FACILE';
  else if (category === 'Listes_Chainees' || category === 'Dynamic_Allocation') difficulty = 'DIFFICILE';

  if (matches.length > 1) {
    // Multi-question structure
    const questions = [];
    const solutionParts = [];
    const templateParts = [];

    // Extract Type / Global declarations before first function
    const headerCode = content.substring(0, matches[0].index).trim();
    if (headerCode) {
      solutionParts.push(headerCode);
      templateParts.push(headerCode);
    }

    matches.forEach((m, idx) => {
      const qIndex = idx + 1;
      const nextIdx = matches[idx + 1] ? matches[idx + 1].index : content.length;
      const funcBlock = content.substring(m.index, nextIdx).trim();

      const qStatement = `### Question ${qIndex} : ${m.kind} \`${m.name}\`\n\n` +
        `Implémentez la ${m.kind.toLowerCase()} \`${m.name}\` qui prend en paramètres \`(${m.params.trim()})\`` +
        (m.returnType ? ` et retourne un résultat de type \`${m.returnType}\`.` : `.`);

      questions.push({
        orderIndex: qIndex,
        statement: qStatement
      });

      // Solution with French markers
      solutionParts.push(`\n// question ${qIndex} commence ici\n${funcBlock}\n// question ${qIndex} se termine ici\n`);

      // Template with empty body and French markers
      const proto = `${m.kind} ${m.name}(${m.params.trim()})` + (m.returnType ? ` : ${m.returnType}` : '');
      templateParts.push(
        `\n// question ${qIndex} commence ici\n${proto}\nVar\n    // Déclarer vos variables locales ici\nDebut\n    // Rédigez le corps de la question ${qIndex} ici\nFin;\n// question ${qIndex} se termine ici\n`
      );
    });

    return {
      title,
      description,
      topic,
      difficulty,
      tags: [topic, 'Exemple Officiel', 'Multi-Questions'],
      referenceSolution: solutionParts.join('\n').trim(),
      templateCode: templateParts.join('\n').trim(),
      questions
    };
  } else {
    // Single monolithic question
    const templateCode = `// --- Squelette pour : ${title} ---\n// question 1 commence ici\n` +
      `Algorithme ${title.replace(/\s+/g, '_')};\nVar\n    // Déclarer vos variables ici\nDebut\n    // Rédigez votre solution ici\nFin.\n// question 1 se termine ici\n`;

    const refSolution = `// question 1 commence ici\n${content.trim()}\n// question 1 se termine ici\n`;

    return {
      title,
      description,
      topic,
      difficulty,
      tags: [topic, 'Exemple Officiel'],
      referenceSolution: refSolution,
      templateCode,
      questions: [
        {
          orderIndex: 1,
          statement: `### Question 1 : Résolution de ${title}\n\n${description}`
        }
      ]
    };
  }
}

async function run() {
  console.log(`🚀 Starting Bulk Import from: ${EXAMPLES_DIR}`);

  if (!fs.existsSync(EXAMPLES_DIR)) {
    console.error(`❌ Directory not found: ${EXAMPLES_DIR}`);
    process.exit(1);
  }

  const categories = fs.readdirSync(EXAMPLES_DIR).filter(f => fs.statSync(path.join(EXAMPLES_DIR, f)).isDirectory());

  let totalImported = 0;
  let totalUpdated = 0;

  for (const cat of categories) {
    const catDir = path.join(EXAMPLES_DIR, cat);
    const files = fs.readdirSync(catDir).filter(f => f.endsWith('.algo'));

    console.log(`📂 Processing category [${cat}] - ${files.length} files...`);

    for (const file of files) {
      const filePath = path.join(catDir, file);
      const probData = parseAlgoFile(filePath, cat);

      try {
        const existing = await prisma.problem.findFirst({
          where: { title: probData.title }
        });

        if (existing) {
          // Update existing problem
          await prisma.problem.update({
            where: { id: existing.id },
            data: {
              description: probData.description,
              topic: probData.topic,
              difficulty: probData.difficulty,
              tags: probData.tags,
              referenceSolution: probData.referenceSolution,
              templateCode: probData.templateCode
            }
          });

          // Update questions
          await prisma.problemQuestion.deleteMany({ where: { problemId: existing.id } });
          for (const q of probData.questions) {
            await prisma.problemQuestion.create({
              data: {
                problemId: existing.id,
                orderIndex: q.orderIndex,
                statement: q.statement
              }
            });
          }

          totalUpdated++;
          console.log(`   🔄 Updated: "${probData.title}" (${probData.questions.length} questions)`);
        } else {
          // Create new problem
          const created = await prisma.problem.create({
            data: {
              title: probData.title,
              description: probData.description,
              topic: probData.topic,
              difficulty: probData.difficulty,
              timeLimitMs: 2000,
              tags: probData.tags,
              referenceSolution: probData.referenceSolution,
              templateCode: probData.templateCode,
              questions: {
                create: probData.questions.map(q => ({
                  orderIndex: q.orderIndex,
                  statement: q.statement
                }))
              }
            }
          });

          totalImported++;
          console.log(`   ✨ Created: "${probData.title}" (${probData.questions.length} questions)`);
        }
      } catch (err) {
        console.error(`   ❌ Failed importing "${probData.title}":`, err.message);
      }
    }
  }

  console.log(`\n🎉 Bulk Import Completed!`);
  console.log(`   Total Created: ${totalImported}`);
  console.log(`   Total Updated: ${totalUpdated}`);
  console.log(`   Total Problems in Database: ${await prisma.problem.count()}`);

  await prisma.$disconnect();
}

run().catch(async (e) => {
  console.error(e);
  await prisma.$disconnect();
  process.exit(1);
});
