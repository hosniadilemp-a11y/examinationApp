# AlgoExamination — Grading and Correction

## Component

`CorrectionWorkspace.jsx`

Backend:
`grading.controller.js`

## Responsibilities

- student navigation
- student code display next to reference solution (side-by-side)
- 3-module AI evaluation & summary breakdown (Execution/Sandbox 50%, AST Structure 25%, Local AI Rubric 25%)
- line-by-line comment annotations (`AnnotatedCodeViewer`)
- student code edition & sandbox re-execution with automatic score updates
- student-to-student plagiarism/similarity analysis (AST, textual, semantic) with threshold filtering
- teacher reference solution comparison modal & AST graph visualization
- grading persistence (exercise scores, line comments, general feedback, corrected version)
- PDF export (single copy & bulk ZIP export)

## 3-Module Evaluation Engine Architecture

1. **Module 1 — Execution & Sandbox Tests (Pondération 50%)**:
   - Executes deterministic public & private/hidden test cases.
   - Evaluates STDIN input, expected output vs actual student output, stderr trace, and runtime in ms.
   - Re-executing modified student code automatically recalculates sandbox test pass ratio and updates exercise score.

2. **Module 2 — AST & Structural Analysis (Pondération 25%)**:
   - Parses AST node trees via Python AST compiler (`RealASTTreeNodeGraph`).
   - Compares student AST tree against teacher reference AST tree ignoring variable names, whitespace, and formatting.
   - Interactive comparison modal (`CompareSolutionsModal`) classifies structure: Equivalent, Similar, Different, Incorrect.

3. **Module 3 — Local AI Logic & Rubric Evaluation (Pondération 25%)**:
   - Runs local Ollama LLM (`qwen1_5b` / `qwen2.5-coder:1.5b`) on CPU with JSON schema enforcement.
   - Evaluates 5 dimensions: Algorithmic correctness, Logical correctness, Semantic equivalence, Partial understanding, Algorithmic quality.
   - Generates strengths, detected errors, and French-only pedagogical feedback (`feedback_fr`).
   - Resilient fault isolation: operates independently with retry button if AI daemon is offline.

## Student Plagiarism / Similarity Engine

- Computes multi-level similarity between all student submissions per problem:
  - **AST Structural Similarity** (Tree Jaccard matching)
  - **Textual Token Similarity** (Normalized token Jaccard)
  - **Semantic Similarity** (Canonical statement matching)
- Configurable threshold (60%, 70%, 80%, 90%, default 70%).
- Non-intrusive Academic Integrity Warning Banner when similarity $\ge 85\%$.
- Interactive `CompareSimilarityModal` for side-by-side diff review between current student and similar student.

## Syntax Analyzer

Current checks include structures such as:

```text
ALGORITHME
VARIABLES
DEBUT
FIN
SI / FINSI
POUR / FINPOUR
TANTQUE / FINTANTQUE
```

## Analyzer Rule

A syntax analyzer should provide useful diagnostics, not reject valid algorithms based on superficial formatting.

Avoid brittle regex assumptions such as:
- requiring one exact whitespace pattern
- treating capitalization as semantic when the language is intended to be case-insensitive
- confusing variable names with keywords
- failing because comments exist

When changing parsing logic, test valid and invalid examples.

## Teacher Reference Solution

Reference code is displayed side-by-side next to the student's solution as a direct grading aid.

Do not automatically replace student code with the teacher solution unless requested via the "Version Corrigée" view.

## Inline Line Comments & Code Execution

Keep separate concepts:
- line-by-line comment annotations (`lineCommentsMapByProblem`)
- teacher corrected code (`correctedCodeInput`)
- official exercise score attributed (`exerciseScores`)

Re-running tests on edited code updates the student's evaluated test pass status and automatically recalculates the exercise score.

## Student Navigation

Expected navigation:
- Up/Down → exercises
- Left/Right → students

Keyboard navigation must not interfere with the code editor unexpectedly.

## Score

Final score is out of 20.

If individual exercise points use another scale internally, conversion must be explicit and deterministic.

## Grading Checklist

- [ ] Student selected correctly
- [ ] Assignment ID correct
- [ ] Exercise ID correct
- [ ] Student code displayed side-by-side with reference solution
- [ ] 3-Module executive summary card displayed with points attributed
- [ ] 3-Module detailed cards displayed (Module 1, Module 2, Module 3)
- [ ] Edited code execution recalculates test results and updates score
- [ ] Line comments persisted per line
- [ ] Student-to-student similarity analysis working with diff modal
- [ ] Final /20 score correct
- [ ] PDF export uses persisted values, line comments, and AI feedback
- [ ] CSV export uses persisted values
