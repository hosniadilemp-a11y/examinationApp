# AlgoExamination — Required Verification

## Mandatory Checks

After code changes, run:

### Frontend

```bash
cd client && /home/adel/.cache/ms-playwright-go/1.57.0/node ./node_modules/vite/bin/vite.js build
```

### Backend

```bash
cd server && PATH=/home/adel/.local/node-v20/bin:$PATH node -e "require('./src/controllers/exam.controller.js'); require('./src/controllers/grading.controller.js'); console.log('Syntax OK');"
```

### Prisma

```bash
cd server && PATH=/home/adel/.local/node-v20/bin:$PATH npx prisma validate
```

## Additional Verification by Task

### Exam changes

Check:
- create
- edit
- date/time
- point allocation
- student assignment
- status transition

### Student exam changes

Check:
- login
- waiting room
- launch
- autosave
- timer
- termination
- reconnect

### Anti-cheat changes

Check:
- fullscreen
- violation counter
- 3 fullscreen strikes
- lock
- unlock
- terminate
- teacher dashboard update

### Grading changes

Check:
- code loading
- syntax analysis
- score
- feedback
- corrected version
- persistence

### PDF changes

Check:
- PDF opens
- white background
- identity header
- score
- QR
- ZIP generation
- progress

## Build Failure Rule

If verification fails:
1. do not claim success
2. identify whether failure is related to the change
3. fix it if safe
4. otherwise report the exact failure

## Final Agent Report

A good final report should contain:

```text
Changed:
- ...

Verified:
- frontend build: PASS/FAIL
- backend require check: PASS/FAIL
- Prisma validation: PASS/FAIL

Potential limitations:
- ...
```

Do not report checks as PASS unless actually executed.
