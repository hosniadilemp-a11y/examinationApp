import React, { useState, useEffect } from 'react';
import { getStudentWorkspace } from '../services/api';
import {
  CheckCircle2,
  LogOut,
  ShieldCheck,
  FileCheck2,
  CheckCircle,
  Eye,
  EyeOff,
  Code2,
  Lock
} from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { algoExtension } from '../utils/algo-language';

export default function ExamCompleted({ onLogout }) {
  const [workspaceData, setWorkspaceData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [expandedProblems, setExpandedProblems] = useState({});

  useEffect(() => {
    fetchSummaryData();
  }, []);

  const fetchSummaryData = async () => {
    try {
      const data = await getStudentWorkspace();
      setWorkspaceData(data);

      // Expand all problems by default so student can immediately see their solutions
      if (data?.problems) {
        const initialMap = {};
        data.problems.forEach((p, idx) => {
          initialMap[p.id] = idx === 0; // Expand first problem by default
        });
        setExpandedProblems(initialMap);
      }
    } catch (err) {
      console.error('Failed to load completed exam data:', err);
    } finally {
      setLoading(false);
    }
  };

  const { student, exam, problems, currentCodeMap, submissions } = workspaceData || {};

  const getSolutionCode = (probId) => {
    if (!probId) return '';
    // Priority 1: latest submission
    const sub = (submissions || []).find(s => s.problemId === probId);
    if (sub && sub.sourceCode) return sub.sourceCode;

    // Priority 2: autosaved current code map
    const saved = currentCodeMap?.[probId];
    if (saved) {
      if (typeof saved === 'string') return saved;
      if (saved.code) return saved.code;
    }

    // Priority 3: template code fallback
    const prob = (problems || []).find(p => p.id === probId);
    if (!prob) return '// Aucune solution rédigée pour cet exercice.';
    let tCode = prob.templateCode;
    if (typeof tCode === 'string') {
      try {
        const parsed = JSON.parse(tCode);
        if (parsed && typeof parsed === 'object') tCode = parsed;
      } catch (e) {}
    }
    return (typeof tCode === 'object' && tCode !== null)
      ? (tCode.ALGO || tCode.code || tCode.PYTHON || prob.starterTemplate || '// Aucune solution rédigée pour cet exercice.')
      : (typeof tCode === 'string' && tCode.trim() ? tCode : (prob.starterTemplate || '// Aucune solution rédigée pour cet exercice.'));
  };

  const toggleProblem = (probId) => {
    setExpandedProblems(prev => ({
      ...prev,
      [probId]: !prev[probId]
    }));
  };

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0b0f19', color: '#fff' }}>
        <div style={{ textAlign: 'center' }}>
          <div className="spinner" style={{ width: '40px', height: '40px', border: '3px solid rgba(59,130,246,0.2)', borderTopColor: '#3b82f6', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 16px' }} />
          <p style={{ color: '#94a3b8' }}>Chargement de vos solutions transmises...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(circle at top, #0f172a 0%, #020617 100%)',
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '32px 16px'
    }}>
      <div className="glass-panel" style={{
        width: '100%',
        maxWidth: '820px',
        padding: '40px 36px',
        borderRadius: '20px',
        border: '1px solid rgba(52, 211, 153, 0.3)',
        boxShadow: '0 25px 70px rgba(0, 0, 0, 0.7), 0 0 50px rgba(16, 185, 129, 0.12)',
        textAlign: 'center'
      }}>

        {/* Success Icon Header */}
        <div style={{
          width: '84px',
          height: '84px',
          borderRadius: '50%',
          background: 'rgba(16, 185, 129, 0.15)',
          border: '2px solid rgba(16, 185, 129, 0.4)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: '20px',
          boxShadow: '0 0 35px rgba(52, 211, 153, 0.25)'
        }}>
          <CheckCircle2 size={50} color="#34d399" />
        </div>

        <h1 style={{ fontSize: '2rem', fontWeight: '800', marginBottom: '8px', color: '#ffffff' }}>
          Examen Soumis avec Succès !
        </h1>

        <p style={{ color: '#94a3b8', fontSize: '1rem', lineHeight: '1.6', marginBottom: '28px', maxWidth: '640px', margin: '0 auto 28px' }}>
          Toutes vos solutions et données de session ont été transmises et sauvegardées en toute sécurité sur le serveur d'examen.
        </p>

        {/* Student Session Details Summary */}
        {student && (
          <div style={{
            background: 'rgba(15, 23, 42, 0.75)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            borderRadius: '14px',
            padding: '20px 24px',
            marginBottom: '32px',
            textAlign: 'left',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: '16px',
            fontSize: '0.88rem'
          }}>
            <div>
              <div style={{ color: '#64748b', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '700', letterSpacing: '0.05em' }}>Étudiant</div>
              <div style={{ fontWeight: '700', color: '#f8fafc', fontSize: '1rem', marginTop: '3px' }}>
                {student.firstName} {student.lastName}
              </div>
            </div>

            <div>
              <div style={{ color: '#64748b', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '700', letterSpacing: '0.05em' }}>Groupe / Spécialité</div>
              <div style={{ fontWeight: '600', color: '#cbd5e1', fontSize: '0.95rem', marginTop: '3px' }}>
                {student.group || 'N/A'} {student.speciality ? `(${student.speciality})` : ''}
              </div>
            </div>

            <div>
              <div style={{ color: '#64748b', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '700', letterSpacing: '0.05em' }}>Numéro d'Accès</div>
              <div style={{ fontWeight: '700', color: '#60a5fa', fontFamily: 'var(--font-mono)', fontSize: '0.95rem', marginTop: '3px' }}>
                {student.accessNumber}
              </div>
            </div>

            <div>
              <div style={{ color: '#64748b', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '700', letterSpacing: '0.05em' }}>Statut Session</div>
              <div style={{ color: '#34d399', fontWeight: '700', fontSize: '0.92rem', marginTop: '3px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <ShieldCheck size={16} /> Terminé & Transmis
              </div>
            </div>
          </div>
        )}

        {/* Exercises & Submitted Solutions List */}
        <div style={{ marginBottom: '32px', textAlign: 'left' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
            <div style={{ fontSize: '0.95rem', fontWeight: '800', color: '#f1f5f9', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <FileCheck2 size={18} color="#60a5fa" /> Confirmation & Consultation des Solutions :
            </div>
            <span style={{ fontSize: '0.78rem', color: '#94a3b8' }}>
              ({problems?.length || 0} Exercice{problems?.length > 1 ? 's' : ''})
            </span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {(problems || []).map((prob, idx) => {
              const isExpanded = !!expandedProblems[prob.id];
              const code = getSolutionCode(prob.id);

              return (
                <div key={prob.id || idx} style={{
                  borderRadius: '12px',
                  background: 'rgba(30, 41, 59, 0.55)',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  overflow: 'hidden',
                  transition: 'all 0.2s ease'
                }}>
                  {/* Problem Card Header Bar */}
                  <div
                    onClick={() => toggleProblem(prob.id)}
                    style={{
                      padding: '14px 18px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      cursor: 'pointer',
                      background: isExpanded ? 'rgba(59, 130, 246, 0.1)' : 'transparent',
                      userSelect: 'none'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <Code2 size={18} color="#c084fc" />
                      <span style={{ fontWeight: '700', fontSize: '0.95rem', color: '#f8fafc' }}>
                        Exercice {idx + 1} : {prob.title}
                      </span>
                      <span className="badge badge-purple" style={{ fontSize: '0.72rem', padding: '2px 8px' }}>
                        {prob.points} Points
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <span style={{
                        fontSize: '0.75rem',
                        fontWeight: '700',
                        color: '#34d399',
                        background: 'rgba(16, 185, 129, 0.15)',
                        padding: '4px 12px',
                        borderRadius: '14px',
                        border: '1px solid rgba(16, 185, 129, 0.3)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '5px'
                      }}>
                        <CheckCircle size={13} /> Solution enregistrée
                      </span>

                      <button
                        style={{
                          background: 'rgba(255,255,255,0.06)',
                          border: '1px solid rgba(255,255,255,0.12)',
                          color: '#cbd5e1',
                          padding: '6px 12px',
                          borderRadius: '6px',
                          fontSize: '0.78rem',
                          fontWeight: '600',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}
                      >
                        {isExpanded ? <EyeOff size={14} /> : <Eye size={14} />}
                        {isExpanded ? 'Masquer' : 'Voir Solution'}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Code View (Read-Only) */}
                  {isExpanded && (
                    <div style={{ borderTop: '1px solid rgba(255, 255, 255, 0.08)', background: '#090d16', padding: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px', padding: '0 6px' }}>
                        <span style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: '600' }}>
                          Code Algorithmique Transmis :
                        </span>
                        <span style={{ fontSize: '0.72rem', color: '#ef4444', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Lock size={12} /> Lecture Seule (Non Modifiable)
                        </span>
                      </div>

                      <div style={{ borderRadius: '8px', overflow: 'hidden', border: '1px solid #1e293b' }}>
                        <CodeMirror
                          value={code}
                          height="auto"
                          maxHeight="280px"
                          theme="dark"
                          readOnly={true}
                          editable={false}
                          extensions={[...algoExtension()]}
                          style={{ fontSize: '13px', fontFamily: 'var(--font-mono)' }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Main Page Exit Button */}
        <button
          className="btn btn-primary"
          onClick={onLogout}
          style={{
            width: '100%',
            padding: '16px',
            fontSize: '1.05rem',
            fontWeight: '800',
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '12px',
            boxShadow: '0 4px 20px rgba(59, 130, 246, 0.35)'
          }}
        >
          <LogOut size={20} /> Retourner à la Page Principale
        </button>

      </div>
    </div>
  );
}
