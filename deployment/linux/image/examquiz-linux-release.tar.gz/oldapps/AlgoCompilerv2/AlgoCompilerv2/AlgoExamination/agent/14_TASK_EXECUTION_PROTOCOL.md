# AlgoExamination — Agent Task Execution Protocol

Use this protocol for every coding task.

## Phase 1 — Understand

Write internally:
- What is requested?
- Which user role is affected?
- Which component owns the behavior?
- Is this frontend, backend, database, socket, or cross-layer?

## Phase 2 — Inspect

Search for:
- relevant component
- API endpoint
- controller
- Prisma model
- socket event
- utility/service
- tests

Do not modify before locating the existing implementation.

## Phase 3 — Map Dependencies

Determine:

```text
UI
↓
API / Socket
↓
Controller
↓
Service / Runner
↓
Prisma
↓
Socket response/event
↓
Other UI
```

## Phase 4 — Identify Invariants

Ask:
- Does this affect student identity?
- score?
- exam status?
- student status?
- anti-cheat?
- autosave?
- PDF authenticity?
- real-time synchronization?
- existing data?

## Phase 5 — Implement

Use the smallest coherent patch.

Prefer existing:
- utilities
- API wrappers
- CSS tokens
- socket singleton
- Prisma patterns
- services

## Phase 6 — Regression Review

Check adjacent behavior.

Example:
Changing student termination requires checking:
- backend status
- student socket
- teacher socket
- dashboard
- student workspace
- database
- exam completion

## Phase 7 — Verify

Run required commands.

## Phase 8 — Report

Report:
- what changed
- files changed
- verification performed
- known limitations

## Stop Conditions

Pause and inspect instead of guessing if:
- schema is unclear
- socket contract is unclear
- authentication flow is unclear
- a dependency version is ambiguous
- existing behavior conflicts with documentation
- a destructive database change appears necessary
