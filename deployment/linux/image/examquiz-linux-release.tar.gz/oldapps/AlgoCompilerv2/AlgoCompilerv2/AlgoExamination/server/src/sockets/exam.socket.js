const prisma = require('../prisma');

// Max fullscreen exits before auto-kick
const MAX_FULLSCREEN_EXITS = 3;

// Max total violations before auto-suspension (student must be unlocked by teacher)
const MAX_VIOLATIONS_BEFORE_SUSPEND = 4;

function setupExamSocket(io) {
  io.on('connection', (socket) => {
    console.log(`Socket connected: ${socket.id}`);

    // =========================================================
    // JOIN EXAM ROOM  (student or teacher)
    // =========================================================
    socket.on('join_exam_room', async ({ examId, studentId, isTeacher }) => {
      if (!examId) return;

      const roomName = `exam_${examId}`;
      socket.join(roomName);

      if (studentId && !isTeacher) {
        const studentRoom = `student_${studentId}`;
        socket.join(studentRoom);
        socket.studentId = studentId;
        socket.examId   = examId;

        try {
          const exam = await prisma.exam.findUnique({ where: { id: examId } });
          const assignment = await prisma.examAssignment.findUnique({
            where: { examId_studentId: { examId, studentId } },
            include: { student: true }
          });

          if (!assignment) return;

          // Guard: finished/kicked students cannot re-enter
          if (['FINISHED', 'KICKED_OUT', 'ABSENT'].includes(assignment.status)) {
            socket.emit('student_terminated', {
              reason: 'Votre session est terminée. Vous ne pouvez pas rejoindre à nouveau.'
            });
            return;
          }

          // Determine exam status, strictly preserving PAUSED / suspension upon reconnection
          const wasDisconnected = !assignment.isOnline;
          const isTemporarilyPaused = assignment.pausedUntil && new Date(assignment.pausedUntil).getTime() > Date.now();
          const isIndefinitelyPaused = assignment.status === 'PAUSED' && !assignment.pausedUntil;

          let targetStatus = assignment.status;
          if (isTemporarilyPaused || isIndefinitelyPaused) {
            targetStatus = 'PAUSED';
            socket.emit('student_locked', {
              reason: isTemporarilyPaused
                ? `Votre session est temporairement suspendue jusqu'à ${new Date(assignment.pausedUntil).toLocaleTimeString()}.`
                : 'Votre session est actuellement suspendue par l’équipe de surveillance.',
              pausedUntil: assignment.pausedUntil
            });
          } else if (assignment.status === 'WAITING' || assignment.status === 'NOT_ENTERED' || !assignment.status) {
            targetStatus = exam?.status === 'RUNNING' ? 'IN_EXAM' : 'WAITING';
          }

          const updated = await prisma.examAssignment.update({
            where: { id: assignment.id },
            data: {
              status: targetStatus,
              isOnline: true,
              lastSeenAt: new Date(),
              loginTime: assignment.loginTime || new Date(),
              startedAt: (targetStatus === 'IN_EXAM' && !assignment.startedAt)
                ? new Date()
                : assignment.startedAt
            }
          });

          // Persist event
          const eventType = wasDisconnected ? 'RE_ENTERED' : 'CONNECTED';
          await _logEvent(examId, studentId, eventType, 'LOW');

          // Broadcast full status update to teacher room
          io.to(roomName).emit('student_status_changed', {
            studentId,
            accessNumber: assignment.accessNumber,
            studentName:  `${assignment.student.firstName} ${assignment.student.lastName}`,
            status:       updated.status,
            pausedUntil:  assignment.pausedUntil,
            isOnline:     true,
            lastSeenAt:   updated.lastSeenAt,
            eventType
          });

        } catch (e) {
          console.error('join_exam_room error:', e);
        }
      }

      console.log(`Socket ${socket.id} joined room ${roomName} (Teacher: ${!!isTeacher})`);
    });

    // =========================================================
    // VIOLATION EVENTS  (fullscreen exit/return, tab switch, etc.)
    // =========================================================
    socket.on('student_violation', async ({ examId, studentId, eventType, severity, problemId, metadata }) => {
      if (!examId || !studentId) return;

      try {
        // Persist monitoring event
        const event = await prisma.monitoringEvent.create({
          data: {
            examId,
            studentId,
            eventType,
            severity: severity || 'MEDIUM',
            problemId: problemId || null,
            metadata: metadata || {}
          }
        });

        let newViolations = 0;
        let newFsExits = 0;
        let assignment = null;

        if (eventType === 'FULLSCREEN_EXIT') {
          // Increment both fullscreenExits AND violations
          assignment = await prisma.examAssignment.update({
            where: { examId_studentId: { examId, studentId } },
            data: {
              fullscreenExits: { increment: 1 },
              violations:      { increment: 1 }
            },
            include: { exam: true, student: true }
          });
          newViolations = assignment.violations;
          newFsExits    = assignment.fullscreenExits;

          // ── 3-strike auto-suspend ──
          if (newFsExits >= MAX_FULLSCREEN_EXITS && assignment.status === 'IN_EXAM') {
            await prisma.examAssignment.update({
              where: { id: assignment.id },
              data: { status: 'PAUSED' }
            });

            await _logEvent(examId, studentId, 'FS_EXITS_EXCEEDED', 'HIGH');

            io.to(`student_${studentId}`).emit('student_locked', {
              reason: `Session suspendue : vous avez quitté le plein écran ${newFsExits} fois (limite : ${MAX_FULLSCREEN_EXITS}). Attendez l'enseignant.`
            });
            io.to(`exam_${examId}`).emit('student_status_changed', {
              studentId,
              accessNumber: assignment.accessNumber,
              studentName:  `${assignment.student.firstName} ${assignment.student.lastName}`,
              status:       'PAUSED',
              isOnline:     assignment.isOnline,
              eventType:    'FS_EXITS_EXCEEDED'
            });
            return;
          }

          // Send warning to student with remaining strikes
          const remaining = MAX_FULLSCREEN_EXITS - newFsExits;
          io.to(`student_${studentId}`).emit('student_fullscreen_warning', {
            count: newFsExits,
            max: MAX_FULLSCREEN_EXITS,
            remaining
          });

        } else if (eventType === 'FULLSCREEN_RETURN') {
          // No penalty — just log
          assignment = await prisma.examAssignment.findUnique({
            where: { examId_studentId: { examId, studentId } },
            include: { student: true }
          });
          newViolations = assignment?.violations || 0;
          newFsExits    = assignment?.fullscreenExits || 0;

        } else {
          // All other violations (TAB_SWITCH, COPY_ATTEMPT, SHORTCUT_BLOCKED, etc.)
          assignment = await prisma.examAssignment.update({
            where: { examId_studentId: { examId, studentId } },
            data: { violations: { increment: 1 } },
            include: { exam: true, student: true }
          });
          newViolations = assignment.violations;
          newFsExits    = assignment.fullscreenExits;

          // Auto-suspend at 4 warnings (and every 4 warnings: 4, 8, 12...)
          if (newViolations >= 4 && newViolations % 4 === 0 && assignment.status === 'IN_EXAM') {
            await prisma.examAssignment.update({
              where: { id: assignment.id },
              data: { status: 'PAUSED' }
            });

            const suspendMsg = `Votre session a été suspendue automatiquement après ${newViolations} avertissements. Contactez l'enseignant pour être débloqué.`;
            io.to(`student_${studentId}`).emit('student_locked', { reason: suspendMsg });

            // Notify teacher
            io.to(`exam_${examId}`).emit('student_status_changed', {
              studentId,
              accessNumber: assignment.accessNumber,
              studentName:  `${assignment.student.firstName} ${assignment.student.lastName}`,
              status:       'PAUSED',
              isOnline:     assignment.isOnline
            });
          }
        }

        // Broadcast live violation to teacher
        const studentInfo = assignment?.student;
        io.to(`exam_${examId}`).emit('live_monitoring_event', {
          studentId,
          studentName:  studentInfo ? `${studentInfo.firstName} ${studentInfo.lastName}` : studentId,
          accessNumber: assignment?.accessNumber,
          eventType,
          severity:     severity || 'MEDIUM',
          problemId,
          violations:   newViolations,
          fullscreenExits: newFsExits,
          timestamp:    event.timestamp
        });

      } catch (err) {
        console.error('student_violation socket error:', err);
      }
    });

    // =========================================================
    // STUDENT SWITCH PROBLEM
    // =========================================================
    socket.on('student_switch_problem', ({ examId, studentId, problemId }) => {
      if (!examId || !studentId) return;
      io.to(`exam_${examId}`).emit('student_problem_changed', {
        studentId,
        problemId,
        timestamp: new Date()
      });
    });

    // =========================================================
    // DISCONNECT
    // =========================================================
    socket.on('disconnect', async () => {
      if (socket.studentId && socket.examId) {
        const { studentId, examId } = socket;
        const roomName = `exam_${examId}`;

        try {
          const assignment = await prisma.examAssignment.findUnique({
            where: { examId_studentId: { examId, studentId } },
            include: { student: true }
          });

          if (assignment && !['FINISHED', 'KICKED_OUT', 'ABSENT'].includes(assignment.status)) {
            // Keep the student's exam progression status (IN_EXAM, WAITING, PAUSED) intact.
            // Only update connection status: isOnline = false
            const updated = await prisma.examAssignment.update({
              where: { id: assignment.id },
              data: {
                isOnline: false,
                lastSeenAt: new Date()
              }
            });

            await _logEvent(examId, studentId, 'DISCONNECTED', 'LOW');

            // Alert teacher: connection dropped without changing exam status
            io.to(roomName).emit('student_online_changed', {
              studentId,
              accessNumber: assignment.accessNumber,
              studentName: `${assignment.student.firstName} ${assignment.student.lastName}`,
              isOnline: false,
              status: assignment.status,
              lastSeenAt: updated.lastSeenAt
            });
          }
        } catch (e) {
          console.error('disconnect handler error:', e);
        }

        io.to(roomName).emit('student_disconnected', {
          studentId,
          timestamp: new Date()
        });
      }

      console.log(`Socket disconnected: ${socket.id}`);
    });
  });
}

// ── Helper: persist a MonitoringEvent ──────────────────────────
async function _logEvent(examId, studentId, eventType, severity = 'LOW', metadata = {}) {
  try {
    await prisma.monitoringEvent.create({
      data: { examId, studentId, eventType, severity, metadata }
    });
  } catch (e) {
    console.error('_logEvent error:', e);
  }
}

module.exports = setupExamSocket;
