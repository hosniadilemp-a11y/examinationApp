# AlgoExamination — PDF and ZIP Export

## Service

`server/src/services/pdf.service.js`

## PDF Requirements

Official student copies must be:
- pure white background
- black text
- black borders
- printer friendly
- readable in grayscale
- academically structured

## Header

Must dynamically include:
- university
- module
- exam title
- session
- student name
- group
- matricule
- date

Never hard-code these values.

## QR Authentication

The QR code contains a cryptographic signature based on the configured identity data.

Current requirement references:
- assignment ID
- student ID
- score /20
- date

The signing secret must remain server-side.

Do not expose HMAC secrets to:
- React
- generated PDF text
- CSV
- QR payload in plaintext if not required

## PDF Safety

Avoid:
- dark backgrounds
- low-contrast text
- excessive decorative UI styling
- screenshots of the web interface as official copies

## ZIP Export

`grading.controller.js` uses:

```text
archiver@5.3.2
```

The ZIP should stream rather than load every PDF into memory unnecessarily.

Progress event:

```text
pdf_zip_progress
```

Payload concept:

```json
{
  "done": 3,
  "total": 25,
  "studentName": "...",
  "status": "..."
}
```

## ZIP Failure Handling

If one student PDF fails:
- report the failure
- do not silently claim complete success
- ensure the HTTP stream remains valid or terminates safely according to the implementation

## Export Verification

Check:
- number of students
- filename uniqueness
- PDF opens
- QR exists
- score correct
- identity correct
- no dark page
- ZIP contains expected files
- progress reaches final state
