import React, { useState, useEffect } from 'react';
import StudentLogin from './components/StudentLogin';
import TeacherLogin from './components/TeacherLogin';
import StudentDashboard from './components/StudentDashboard';
import WaitingRoom from './components/WaitingRoom';
import ExamWorkspace from './components/ExamWorkspace';
import ExamCompleted from './components/ExamCompleted';
import TeacherDashboard from './components/TeacherDashboard';
import SurveillanceDashboard from './components/SurveillanceDashboard';
import AdminDashboard from './components/AdminDashboard';
import StudentManager from './components/StudentManager';
import ProblemBank from './components/ProblemBank';
import ExamManager from './components/ExamManager';

export default function App() {
  const isStudentPortal = (() => {
    if (window.location.port === '5174') return true;
    if (window.location.port === '5175') return false;
    const path = window.location.pathname.toLowerCase();
    if (path.startsWith('/student')) return true;
    if (path.startsWith('/staff') || path.startsWith('/teacher') || path.startsWith('/proctor') || path.startsWith('/admin')) return false;
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('portal') === 'student') return true;
    if (urlParams.get('portal') === 'staff') return false;
    const role = localStorage.getItem('userRole');
    if (role === 'STUDENT') return true;
    if (role === 'TEACHER' || role === 'ADMIN' || role === 'PROCTOR') return false;
    return true;
  })();

  const [studentSessionData, setStudentSessionData] = useState(null);
  const [staffRole, setStaffRole] = useState(() => localStorage.getItem('userRole') || null);

  const getInitialView = () => {
    const token = localStorage.getItem('token');
    const storedRole = localStorage.getItem('userRole');

    // ── CANDIDATE / STUDENT PORTAL ──
    if (isStudentPortal) {
      if (token && storedRole === 'STUDENT') {
        return studentSessionData ? (studentSessionData.exam?.status === 'RUNNING' ? 'EXAM_WORKSPACE' : 'WAITING_ROOM') : 'STUDENT_LOGIN';
      }
      return 'STUDENT_LOGIN';
    }

    // ── STAFF PORTAL (Teacher, Surveillance, Admin) ──
    if (token && (storedRole === 'TEACHER' || storedRole === 'ADMIN' || storedRole === 'PROCTOR')) {
      if (storedRole === 'PROCTOR') return 'SURVEILLANCE_DASHBOARD';
      if (storedRole === 'ADMIN') return 'ADMIN_DASHBOARD';
      const savedTeacherView = localStorage.getItem('app_teacher_active_view');
      return savedTeacherView || 'TEACHER_DASHBOARD';
    }

    return 'TEACHER_LOGIN';
  };

  const [view, setView] = useState(getInitialView);

  useEffect(() => {
    if (view && (view.startsWith('TEACHER') || view === 'EXAM_MANAGER' || view === 'PROBLEM_BANK' || view === 'STUDENT_MGMT')) {
      localStorage.setItem('app_teacher_active_view', view);
    }
  }, [view]);

  useEffect(() => {
    const handlePopState = () => {
      setView(getInitialView());
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    const handleUnauthorized = () => {
      localStorage.removeItem('token');
      localStorage.removeItem('userRole');
      localStorage.removeItem('userName');
      setStudentSessionData(null);
      setStaffRole(null);
      setView(isStudentPortal ? 'STUDENT_LOGIN' : 'TEACHER_LOGIN');
    };
    window.addEventListener('auth_unauthorized', handleUnauthorized);
    return () => window.removeEventListener('auth_unauthorized', handleUnauthorized);
  }, [isStudentPortal]);

  // ── Student Auth Handlers ──
  const handleStudentLoginSuccess = (data) => {
    setStudentSessionData(data);
    if (data.exam?.status === 'RUNNING') {
      setView('EXAM_WORKSPACE');
    } else {
      setView('WAITING_ROOM');
    }
  };

  // ── Staff Auth Handlers ──
  const handleStaffLoginSuccess = (data) => {
    const role = data?.teacher?.role || localStorage.getItem('userRole') || 'TEACHER';
    setStaffRole(role);

    if (role === 'PROCTOR') {
      setView('SURVEILLANCE_DASHBOARD');
    } else if (role === 'ADMIN') {
      setView('ADMIN_DASHBOARD');
    } else {
      setView('TEACHER_DASHBOARD');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userName');
    setStudentSessionData(null);
    setStaffRole(null);
    setView(isStudentPortal ? 'STUDENT_LOGIN' : 'TEACHER_LOGIN');
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-color)', color: 'var(--text-main)', display: 'flex', flexDirection: 'column' }}>
      <main style={{ flex: 1 }}>

        {/* ═══════════════════════════════════════════════════════════
            PORT 5174 : ESPACE ÉTUDIANT TOTALEMENT ISOLÉ
        ═══════════════════════════════════════════════════════════ */}
        {isStudentPortal && (
          <>
            {view === 'STUDENT_LOGIN' && (
              <StudentLogin onLoginSuccess={handleStudentLoginSuccess} />
            )}

            {view === 'STUDENT_DASHBOARD' && studentSessionData && (
              <StudentDashboard
                studentData={studentSessionData}
                onEnterExam={() => {
                  if (studentSessionData.exam.status === 'RUNNING') {
                    setView('EXAM_WORKSPACE');
                  } else {
                    setView('WAITING_ROOM');
                  }
                }}
                onLogout={handleLogout}
              />
            )}

            {view === 'WAITING_ROOM' && studentSessionData && (
              <WaitingRoom
                studentData={studentSessionData}
                onExamStarted={() => {
                  setStudentSessionData(prev => prev ? { ...prev, exam: { ...prev.exam, status: 'RUNNING' } } : prev);
                  setView('EXAM_WORKSPACE');
                }}
                onLogout={handleLogout}
              />
            )}

            {view === 'EXAM_WORKSPACE' && (
              <ExamWorkspace
                key={studentSessionData?.student?.id || localStorage.getItem('token') || 'workspace'}
                onFinishExam={() => setView('EXAM_COMPLETED')}
                onRedirectWaitingRoom={() => setView('WAITING_ROOM')}
              />
            )}

            {view === 'EXAM_COMPLETED' && (
              <ExamCompleted onLogout={handleLogout} />
            )}
          </>
        )}

        {/* ═══════════════════════════════════════════════════════════
            PORT 5175 : ESPACE PERSONNEL (Enseignant / Surveillance / Admin)
        ═══════════════════════════════════════════════════════════ */}
        {!isStudentPortal && (
          <>
            {view === 'TEACHER_LOGIN' && (
              <TeacherLogin onLoginSuccess={handleStaffLoginSuccess} />
            )}

            {view === 'SURVEILLANCE_DASHBOARD' && (
              <SurveillanceDashboard onLogout={handleLogout} />
            )}

            {view === 'ADMIN_DASHBOARD' && (
              <AdminDashboard onLogout={handleLogout} />
            )}

            {view === 'TEACHER_DASHBOARD' && (
              <TeacherDashboard
                onNavigate={(targetView) => setView(targetView)}
                onLogout={handleLogout}
              />
            )}

            {view === 'STUDENT_MGMT' && (
              <StudentManager onBack={() => setView('TEACHER_DASHBOARD')} />
            )}

            {view === 'PROBLEM_BANK' && (
              <ProblemBank onBack={() => setView('TEACHER_DASHBOARD')} />
            )}

            {view === 'CREATE_EXAM' && (
              <ExamManager onBack={() => setView('TEACHER_DASHBOARD')} />
            )}

            {view === 'EXAM_MGMT' && (
              <ExamManager onBack={() => setView('TEACHER_DASHBOARD')} />
            )}
          </>
        )}

      </main>
    </div>
  );
}
