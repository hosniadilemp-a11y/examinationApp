# AlgoExamination — Common AI Agent Mistakes to Avoid

This file exists specifically to prevent predictable coding-agent failures.

## Mistake 1 — Rebuilding Instead of Inspecting

Bad behavior:
- creating a new architecture
- replacing existing components
- assuming routes
- inventing models

Correct behavior:
- inspect existing implementation
- modify the current architecture

## Mistake 2 — Fixing One Side of Real-Time State

Bad:
```text
DB updated
but socket not emitted
```

or:

```text
student socket updated
but teacher dashboard not updated
```

Correct:
persist + target event + teacher broadcast.

## Mistake 3 — Trusting the Browser for Critical State

Bad:
```text
if timer === 0:
    assume exam is finished
```

Correct:
server remains authoritative.

## Mistake 4 — Breaking Existing Defaults

Do not replace existing default values because a new requirement "looks cleaner."

Search first.

## Mistake 5 — Accidentally Redistributing Points

Bad:
```text
new problem added
→ recalculate all points
```

Correct:
```text
existing points preserved
→ remaining points assigned to new problem
```

## Mistake 6 — Introducing ESM into CommonJS

Do not change dependencies without checking module compatibility.

## Mistake 7 — Using `new Date(time)`

Never parse `"HH:MM"` directly as a Date.

## Mistake 8 — Overengineering Anti-Cheat

Do not add claims or mechanisms that the browser cannot reliably enforce.

Prefer the existing measurable events.

## Mistake 9 — Removing Polling Because "Sockets Are Real-Time"

Polling is a reliability fallback.

## Mistake 10 — Changing Socket Event Names

This can silently break the opposite client.

Search all producers and consumers first.

## Mistake 11 — Making PDF Look Like the Dark Web UI

The PDF is an academic print artifact.

It must remain white/black.

## Mistake 12 — Hiding Errors

Do not use empty catch blocks.

## Mistake 13 — Huge Refactors for Small Requests

A request such as:
"change the button"

does not justify:
- replacing routing
- changing state architecture
- changing database models
- rewriting CSS globally

## Mistake 14 — Ignoring Existing Data

Database already contains exams, assignments, grades, and code.

A change must consider existing records.

## Mistake 15 — Testing Only the Happy Path

For examination software, test:
- disconnect
- refresh
- duplicate events
- expired time
- invalid input
- missing records
- teacher termination
- socket loss
- API failure

## Mistake 16 — Declaring Success Without Running Checks

Never say "done" merely because the code looks correct.

## Mistake 17 — Mixing Unrelated Fixes

Keep the patch focused.

If you discover an unrelated issue:
- mention it
- do not silently redesign it

## Mistake 18 — Assuming a File Exists

Always inspect the repository before referencing a path.

## Mistake 19 — Ignoring Naming/Contract Mismatches

If documentation says one thing but code does another:
- inspect actual code
- preserve compatibility
- document the discrepancy
- do not blindly follow documentation over implementation

## Mistake 20 — Changing Security-Sensitive Code Casually

Authentication, JWT, HMAC, code execution, anti-cheat, and authorization require extra review.

Do not expose secrets or weaken authorization to make a test pass.
