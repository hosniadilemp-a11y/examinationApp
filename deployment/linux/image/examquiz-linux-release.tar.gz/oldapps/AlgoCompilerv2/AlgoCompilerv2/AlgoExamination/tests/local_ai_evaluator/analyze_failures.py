import os
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_FILE = os.path.join(BASE_DIR, 'results', 'benchmark_results.json')
SOLUTIONS_FILE = os.path.join(BASE_DIR, 'student_solutions.json')

def analyze_failures():
    if not os.path.exists(RESULTS_FILE):
        print(f"❌ Results file not found: {RESULTS_FILE}")
        return

    with open(RESULTS_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)
    with open(SOLUTIONS_FILE, 'r', encoding='utf-8') as f:
        student_solutions = {s['id']: s for s in json.load(f)}

    results = data.get('results', [])
    print("=" * 80)
    print(f"🔍 FAILURE MODE & ACCURACY AUDIT -- MODEL: {data.get('model')}")
    print("=" * 80)

    bias_checks = {
        "variable_name_bias": False,
        "structure_bias": False,
        "false_negative": False,
        "false_positive": False,
        "partial_credit_failure": False,
        "hallucinated_errors": False
    }

    for r in results:
        t_id = r['test_id']
        meta = student_solutions.get(t_id, {})
        actual_score = r['actual_score']
        actual_class = r['actual_classification']
        expected_class = meta.get('expectedClassification')
        min_score = meta.get('expectedScoreMin', 0)
        max_score = meta.get('expectedScoreMax', 20)

        # Check 1: Variable Name Bias (Student 3)
        if t_id == 'student_3_renamed_variables':
            if actual_score < min_score:
                bias_checks['variable_name_bias'] = True
                print(f"⚠️ DETECTED VARIABLE NAME BIAS: Student 3 received {actual_score}/20 (Expected >={min_score}). Model penalized variable renaming.")

        # Check 2: Structure Bias (Student 2)
        if t_id == 'student_2_equivalent_structure':
            if actual_score < min_score:
                bias_checks['structure_bias'] = True
                print(f"⚠️ DETECTED STRUCTURE BIAS: Student 2 received {actual_score}/20 (Expected >={min_score}). Model penalized equivalent structure.")

        # Check 3: False Negative (Student 1, 2, 3)
        if t_id in ['student_1_identical', 'student_2_equivalent_structure', 'student_3_renamed_variables']:
            if actual_class not in ['correct', 'equivalent']:
                bias_checks['false_negative'] = True
                print(f"⚠️ DETECTED FALSE NEGATIVE: {t_id} classified as '{actual_class}' instead of 'correct'.")

        # Check 4: False Positive (Student 4, 6)
        if t_id in ['student_4_incorrect_binary_update', 'student_6_unrelated_approach']:
            if actual_score > max_score or actual_class == 'correct':
                bias_checks['false_positive'] = True
                print(f"⚠️ DETECTED FALSE POSITIVE: {t_id} received {actual_score}/20 (Expected <={max_score}).")

        # Check 5: Partial Credit Failure (Student 5)
        if t_id == 'student_5_partial_understanding':
            if actual_score < min_score or actual_score > max_score:
                bias_checks['partial_credit_failure'] = True
                print(f"⚠️ DETECTED PARTIAL CREDIT FAILURE: Student 5 received {actual_score}/20 (Expected {min_score}-{max_score}).")

    print("\n--------------------------------------------------------------------------------")
    print("📌 SUMMARY OF FAILURE MODES & RISKS DETECTED:")
    print("--------------------------------------------------------------------------------")
    has_any_bias = False
    for k, v in bias_checks.items():
        status = "❌ PRESENT" if v else "✅ PASSED (No Bias)"
        print(f"- {k.replace('_', ' ').title()}: {status}")
        if v: has_any_bias = True

    if not has_any_bias:
        print("\n🎉 EXCELLENT: The local evaluator demonstrated robust semantic reasoning without variable or structural bias!")
    else:
        print("\n⚠️ RECOMMENDATION: Prompt engineering or hybrid AST pre-filtering is required to eliminate detected biases.")

if __name__ == '__main__':
    analyze_failures()
