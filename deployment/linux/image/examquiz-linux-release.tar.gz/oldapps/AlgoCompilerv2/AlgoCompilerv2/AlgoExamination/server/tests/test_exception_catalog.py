import unittest
import sys
import os

# Add server/src/runner to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src/runner')))
from french_exception_translator import translate_exception

class TestExceptionCatalog(unittest.TestCase):
    def _get_translated_exception(self, code_block):
        try:
            exec(code_block, {})
        except Exception as e:
            return translate_exception(e)
        return ""

    def assert_french_clean(self, msg, line_expected=None):
        self.assertTrue(len(msg) > 0, "Error message should not be empty")
        self.assertIn("Ligne ", msg, "Message must reference source line")
        if line_expected is not None:
            self.assertIn(f"Ligne {line_expected}", msg, f"Message should reference line {line_expected}")
        
        # Non-negotiable check: Zero internal symbols leaked!
        banned_terms = ['Pointer', '_ref_', '_b_', '_algo_', 'Traceback', 'File "', '.py']
        for term in banned_terms:
            self.assertNotIn(term, msg, f"Message leaked banned internal symbol: {term}")

    def test_index_error(self):
        code = """
lst = [1, 2, 3]
x = lst[10]
"""
        msg = self._get_translated_exception(code)
        self.assert_french_clean(msg)
        self.assertIn("Index hors limites", msg)

    def test_type_error(self):
        code = """
x = "texte" + 5
"""
        msg = self._get_translated_exception(code)
        self.assert_french_clean(msg)
        self.assertIn("Incompatibilité de types", msg)

    def test_zero_division_error(self):
        code = """
x = 10 / 0
"""
        msg = self._get_translated_exception(code)
        self.assert_french_clean(msg)
        self.assertIn("Division par zéro", msg)

    def test_recursion_error(self):
        code = """
def rec():
    return rec()
rec()
"""
        msg = self._get_translated_exception(code)
        self.assert_french_clean(msg)
        self.assertIn("récursion", msg)

    def test_value_error(self):
        code = """
x = int("invalid_num")
"""
        msg = self._get_translated_exception(code)
        self.assert_french_clean(msg)
        self.assertIn("Valeur", msg)

    def test_name_error(self):
        code = """
x = variable_inconue_123
"""
        msg = self._get_translated_exception(code)
        self.assert_french_clean(msg)
        self.assertIn("non reconnu", msg)

    def test_attribute_error(self):
        code = """
x = (5).non_existent_field
"""
        msg = self._get_translated_exception(code)
        self.assert_french_clean(msg)
        self.assertIn("Champ ou propriété non valide", msg)

    def test_fallback_unmapped_error(self):
        # Trigger an unmapped or custom exception
        class CustomUnmappedException(Exception):
            pass
        
        try:
            raise CustomUnmappedException("Internal detail secret_path/foo.py")
        except Exception as e:
            msg = translate_exception(e)

        self.assert_french_clean(msg)
        self.assertIn("Une erreur est survenue lors de l'exécution", msg)

if __name__ == '__main__':
    unittest.main()
