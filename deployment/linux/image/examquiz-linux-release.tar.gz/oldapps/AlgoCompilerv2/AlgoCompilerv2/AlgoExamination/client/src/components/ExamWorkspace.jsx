import React, { useState, useEffect, useRef } from 'react';
import {
  getStudentWorkspace,
  autosaveCode,
  runSampleCode,
  submitSolution,
  logMonitoringEvent,
  finalizeExam,
  validateCodeSyntax
} from '../services/api';
import { getSocket, joinExamRoom, sendStudentViolation, sendStudentSwitchProblem } from '../services/socket';
import {
  Maximize,
  ShieldAlert,
  Play,
  Send,
  Clock,
  CheckCircle,
  AlertCircle,
  FileCode,
  Terminal,
  LogOut,
  Megaphone,
  Eye,
  ChevronUp,
  ChevronDown,
  Plus,
  Sparkles
} from 'lucide-react';
import Swal from 'sweetalert2';
import { renderMarkdownHTML, formatOutputText } from '../utils/markdown';

import { ALGO_CHAPTERS, COMPREHENSIVE_CODE_BRICKS } from '../utils/algo-constants';
import { formatAlgoCode } from '../utils/algo-formatter';
import { Search } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { algoExtension } from '../utils/algo-language';
import { search } from '@codemirror/search';
import { linter, lintGutter } from '@codemirror/lint';
import { lockedZonesExtension, formatTransactionAnnotation } from '../utils/locked-zones-extension';

const algoLinterExtension = linter(async (view) => {
  try {
    const docText = view.state.doc.toString();
    if (!docText || !docText.trim()) return [];

    const res = await validateCodeSyntax(docText);
    if (!res || !res.errors || !Array.isArray(res.errors)) return [];

    return res.errors.map(err => {
      const lineNum = Math.max(1, Math.min(err.line || 1, view.state.doc.lines));
      const lineObj = view.state.doc.line(lineNum);
      return {
        from: lineObj.from,
        to: lineObj.to,
        severity: err.severity || 'error',
        message: err.message || 'Erreur de syntaxe'
      };
    });
  } catch (_) {
    return [];
  }
}, { delay: 500 });

const CODE_BRICKS = [
  { id: 'LIRE_TAB', label: '📥 Remplissage Tableau 1D', snippet: '// Remplissage du tableau T de 1 à N\nPour i := 1 a N Faire\n    Ecrire("Entrer l\'élément ", i, " : ");\n    Lire(T[i]);\nFin Pour;' },
  { id: 'AFFICHER_TAB', label: '📤 Affichage Tableau 1D', snippet: '// Affichage du tableau T de 1 à N\nPour i := 1 a N Faire\n    Ecrire("T[", i, "] = ", T[i]);\nFin Pour;' },
  { id: 'LIRE_MATRICE', label: '📥 Remplissage Matrice 2D', snippet: '// Remplissage de la matrice M (N x M)\nPour i := 1 a N Faire\n    Pour j := 1 a M Faire\n        Ecrire("M[", i, ",", j, "] = ");\n        Lire(M[i,j]);\n    Fin Pour;\nFin Pour;' },
  { id: 'AFFICHER_MATRICE', label: '📤 Affichage Matrice 2D', snippet: '// Affichage de la matrice M (N x M)\nPour i := 1 a N Faire\n    Pour j := 1 a M Faire\n        Ecrire(M[i,j], " ");\n    Fin Pour;\n    Ecrire("\n");\nFin Pour;' },
  { id: 'RECHERCHE_MAX', label: '🔍 Recherche Maximum', snippet: '// Recherche du Maximum dans un tableau T de taille N\nmaxVal := T[1];\nposMax := 1;\nPour i := 2 a N Faire\n    Si (T[i] > maxVal) Alors\n        maxVal := T[i];\n        posMax := i;\n    Fin Si;\nFin Pour;' },
  { id: 'TRI_BULLES', label: '🔄 Tri à Bulles', snippet: '// Tri à bulles d\'un tableau T de taille N\nPour i := 1 a N-1 Faire\n    Pour j := 1 a N-i Faire\n        Si (T[j] > T[j+1]) Alors\n            temp := T[j];\n            T[j] := T[j+1];\n            T[j+1] := temp;\n        Fin Si;\n    Fin Pour;\nFin Pour;' }
];

export default function ExamWorkspace({ onFinishExam, onRedirectWaitingRoom }) {
  const [workspaceData, setWorkspaceData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentProblemIdx, setCurrentProblemIdx] = useState(0);
  const [codeMap, setCodeMap] = useState({});
  const [fontSize, setFontSize] = useState(14);
  const [showBricksMenu, setShowBricksMenu] = useState(false); // Briques hidden by default
  const [selectedStudentBrickChapter, setSelectedStudentBrickChapter] = useState('CH1');
  const [studentBrickSearch, setStudentBrickSearch] = useState('');
  const [expandedStudentBrickIds, setExpandedStudentBrickIds] = useState({});

  const handleFormatCode = () => {
    if (isSuspended || !workspaceData) return;
    const currentProb = workspaceData?.problems?.[currentProblemIdx];
    if (!currentProb) return;

    let currentCode = '';
    if (editorViewRef.current && editorViewRef.current.state) {
      currentCode = editorViewRef.current.state.doc.toString();
    } else {
      currentCode = codeMap[currentProb.id] || '';
    }

    if (!currentCode) return;

    const formatted = formatAlgoCode(currentCode);

    setCodeMap(prev => ({ ...prev, [currentProb.id]: formatted }));

    if (editorViewRef.current && editorViewRef.current.state) {
      const docLen = editorViewRef.current.state.doc.length;
      editorViewRef.current.dispatch({
        changes: { from: 0, to: docLen, insert: formatted },
        annotations: [formatTransactionAnnotation.of(true)]
      });
      editorViewRef.current.focus();
    }
  };
  const [showShortcutsModal, setShowShortcutsModal] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(
    !!(document.fullscreenElement || document.webkitFullscreenElement)
  );
  const [violationsCount, setViolationsCount] = useState(0);
  const [fullscreenExits, setFullscreenExits] = useState(0);
  const [fsWarning, setFsWarning] = useState(null);
  const [isSuspended, setIsSuspended] = useState(false);
  const [suspendReason, setSuspendReason] = useState('');
  const [pausedUntil, setPausedUntil] = useState(null);
  const [fsGraceSecs, setFsGraceSecs] = useState(null);
  const [tempSecsLeft, setTempSecsLeft] = useState(null);
  const [announcements, setAnnouncements] = useState([]);
  
  // Timer state
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(null);
  
  // Code execution & submission states
  const [executing, setExecuting] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [consoleOutput, setConsoleOutput] = useState(null);
  const [customInput, setCustomInput] = useState('');
  const [consoleTab, setConsoleTab] = useState('custom');  // 'custom' | 'tests' | 'results'
  const [publicTestResults, setPublicTestResults] = useState(null); // array of {tc, result}

  const containerRef = useRef(null);
  const autosaveTimerRef = useRef(null);
  const fsGraceTimerRef = useRef(null);
  const editorViewRef = useRef(null);

  useEffect(() => {
    loadWorkspace();
    // Don't call requestFullscreen() on mount — browser blocks it without user gesture
    // The fullscreen overlay will prompt the student to click
  }, []);

  const requestFullscreen = () => {
    const element = document.documentElement;
    if (element.requestFullscreen) {
      element.requestFullscreen().catch(() => {});
    }
  };

  const loadWorkspace = async () => {
    try {
      const data = await getStudentWorkspace();
      if (data.assignmentStatus === 'FINISHED') {
        onFinishExam();
        return;
      }

      setWorkspaceData(data);
      setViolationsCount(data.violationsCount || 0);
      if (data.exam?.announcements) {
        setAnnouncements(data.exam.announcements);
      }
      const isPaused = data.assignmentStatus === 'PAUSED' || data.assignment?.status === 'PAUSED';
      const pUntil = data.pausedUntil || data.assignment?.pausedUntil;
      const isTempStillActive = pUntil && new Date(pUntil).getTime() > Date.now();

      if (isPaused || isTempStillActive) {
        setIsSuspended(true);
        setSuspendReason(
          isTempStillActive
            ? "Votre session est temporairement suspendue par l'enseignant."
            : "Votre session a été suspendue. Attendez l'enseignant."
        );
        if (pUntil) {
          setPausedUntil(pUntil);
        }
      } else {
        setIsSuspended(false);
        setSuspendReason('');
        setPausedUntil(null);
      }

      // Join Socket.io room
      joinExamRoom(data.exam.id, data.student.id, false);

      // Initialize codeMap from saved data or problem templates
      const initialCode = {};

      data.problems.forEach(p => {
        const saved = data.currentCodeMap?.[p.id];
        let tCode = p.templateCode;
        if (typeof tCode === 'string') {
          try {
            const parsed = JSON.parse(tCode);
            if (parsed && typeof parsed === 'object') tCode = parsed;
          } catch (e) {}
        }
        const defaultTemplate = (typeof tCode === 'object' && tCode !== null)
          ? (tCode.ALGO || tCode.code || tCode.PYTHON || p.starterTemplate || '// Écrivez votre algorithme en pseudo-code ici\n')
          : (typeof tCode === 'string' && tCode.trim() ? tCode : (p.starterTemplate || '// Écrivez votre algorithme en pseudo-code ici\n'));

        const savedCodeStr = (typeof saved === 'string' ? saved : (saved?.code)) || '';
        const isGenericFallback = !savedCodeStr.trim() || savedCodeStr.trim() === '// Écrivez votre algorithme en pseudo-code ici';
        initialCode[p.id] = isGenericFallback ? defaultTemplate : savedCodeStr;
      });

      setCodeMap(initialCode);

      // Setup initial custom input for selected problem
      if (data.problems[0]?.publicTestCases[0]) {
        setCustomInput(data.problems[0].publicTestCases[0].inputData);
      }
    } catch (err) {
      console.error('loadWorkspace error:', err);
      if (err.data?.error === 'EXAM_ALREADY_FINISHED') {
        onFinishExam();
        return;
      }
      if (err.data?.error === 'EXAM_NOT_STARTED' && onRedirectWaitingRoom) {
        onRedirectWaitingRoom();
        return;
      }
      Swal.fire({
        icon: 'error',
        title: 'Accès Refusé',
        text: err.data?.message || err.data?.error || 'Impossible de charger la session d’examen.',
        background: '#111827',
        color: '#ffffff'
      });
    } finally {
      setLoading(false);
    }
  };

  // ── Socket: terminate / FS warning / suspension / exam ended ──────────────
  useEffect(() => {
    if (!workspaceData) return;
    const socket = getSocket();

    const handleTerminated = ({ reason }) => {
      localStorage.removeItem('token');
      localStorage.removeItem('userRole');
      Swal.fire({
        icon: 'error',
        title: 'Session Interrompue',
        text: reason || "Votre session a été fermée par l'enseignant.",
        background: '#111827', color: '#fff',
        allowOutsideClick: false, confirmButtonText: 'Fermer'
      }).then(() => onFinishExam());
    };

    const handleExamForceEnded = ({ reason }) => {
      localStorage.removeItem('token');
      localStorage.removeItem('userRole');
      Swal.fire({
        icon: 'warning',
        title: "L'examen est terminé",
        text: reason || "L'enseignant a clôturé l'examen.",
        background: '#111827', color: '#fff',
        allowOutsideClick: false, confirmButtonText: 'Fermer'
      }).then(() => onFinishExam());
    };

    const handleExamPausedByTeacher = ({ reason }) => {
      setIsSuspended(true);
      setSuspendReason(reason || "L'examen a été suspendu par l'enseignant. Attendez la reprise.");
      setWorkspaceData(prev => prev ? ({ ...prev, exam: { ...prev.exam, status: 'PAUSED' } }) : prev);
    };

    const handleExamResumed = ({ startTime } = {}) => {
      setIsSuspended(false);
      setSuspendReason('');
      setWorkspaceData(prev => prev ? ({ ...prev, exam: { ...prev.exam, status: 'RUNNING', ...(startTime ? { startTime } : {}) } }) : prev);
    };

    const handleStudentLocked = ({ reason, pausedUntil }) => {
      setIsSuspended(true);
      setSuspendReason(reason || "Votre session a été suspendue. Contactez l'enseignant.");
      if (pausedUntil) setPausedUntil(pausedUntil);
    };

    const handleStudentUnlocked = () => {
      setIsSuspended(false);
      setSuspendReason('');
      setPausedUntil(null);
    };

    const handleFullscreenWarning = ({ count, max, remaining }) => {
      setFullscreenExits(count);
      setFsWarning({ count, max, remaining });
    };

    const handleExamStatusChanged = ({ status, startTime }) => {
      if (['FINISHED', 'CLOSED'].includes(status)) handleExamForceEnded({ reason: "L'enseignant a clôturé l'examen." });
      if (status === 'RUNNING') {
        setIsSuspended(false);
        setSuspendReason('');
        setPausedUntil(null);
        setWorkspaceData(prev => prev ? ({ ...prev, exam: { ...prev.exam, status: 'RUNNING', ...(startTime ? { startTime } : {}) } }) : prev);
      } else if (status === 'PAUSED') {
        setIsSuspended(true);
        setSuspendReason("L'examen a été suspendu par l'enseignant. Attendez la reprise.");
        setWorkspaceData(prev => prev ? ({ ...prev, exam: { ...prev.exam, status: 'PAUSED' } }) : prev);
      }
    };

    const handleNewAnnouncement = (announcement) => {
      setAnnouncements(prev => [announcement, ...prev]);
      Swal.fire({
        icon: 'info',
        title: '📢 Annonce de l\'Enseignant',
        text: announcement.message,
        background: '#111827', color: '#fff',
        confirmButtonColor: '#3b82f6'
      });
    };

    const handleStudentStatusChanged = (data) => {
      if (data && workspaceData && (data.studentId === workspaceData.student.id || data.accessNumber === workspaceData.student.accessNumber)) {
        if (data.status === 'PAUSED') {
          setIsSuspended(true);
          setSuspendReason(data.reason || "Votre session a été suspendue par l'enseignant.");
          if (data.pausedUntil) setPausedUntil(data.pausedUntil);
        } else if (data.status === 'KICKED_OUT') {
          handleTerminated({ reason: "Vous avez été exclu de l'examen par l'enseignant." });
        } else if (data.status === 'IN_EXAM') {
          setIsSuspended(false);
          setSuspendReason('');
          setPausedUntil(null);
        }
      }
    };

    const handleConnect = () => {
      if (workspaceData?.exam?.id && workspaceData?.student?.id) {
        joinExamRoom(workspaceData.exam.id, workspaceData.student.id, false);
      }
    };

    socket.on('student_terminated',       handleTerminated);
    socket.on('exam_force_ended',          handleExamForceEnded);
    socket.on('exam_paused_by_teacher',    handleExamPausedByTeacher);
    socket.on('exam_status_changed',       handleExamStatusChanged);
    socket.on('exam_started',              handleExamResumed);
    socket.on('student_locked',            handleStudentLocked);
    socket.on('student_unlocked',          handleStudentUnlocked);
    socket.on('student_fullscreen_warning', handleFullscreenWarning);
    socket.on('new_announcement',          handleNewAnnouncement);
    socket.on('student_status_changed',    handleStudentStatusChanged);
    socket.on('connect',                   handleConnect);

    return () => {
      socket.off('student_terminated',       handleTerminated);
      socket.off('exam_force_ended',          handleExamForceEnded);
      socket.off('exam_paused_by_teacher',    handleExamPausedByTeacher);
      socket.off('exam_status_changed',       handleExamStatusChanged);
      socket.off('exam_started',              handleExamResumed);
      socket.off('student_locked',            handleStudentLocked);
      socket.off('student_unlocked',          handleStudentUnlocked);
      socket.off('student_fullscreen_warning', handleFullscreenWarning);
      socket.off('new_announcement',          handleNewAnnouncement);
      socket.off('student_status_changed',    handleStudentStatusChanged);
      socket.off('connect',                   handleConnect);
    };
  }, [workspaceData, onFinishExam]);

  // ── Auto-resume countdown for temporary suspensions ──
  useEffect(() => {
    if (!isSuspended || !pausedUntil) {
      setTempSecsLeft(null);
      return;
    }

    const updateCount = () => {
      const remainingMs = new Date(pausedUntil).getTime() - Date.now();
      const secs = Math.max(0, Math.floor(remainingMs / 1000));
      setTempSecsLeft(secs);

      if (secs <= 0) {
        setIsSuspended(false);
        setSuspendReason('');
        setPausedUntil(null);
        loadWorkspace();
      }
    };

    updateCount();
    const interval = setInterval(updateCount, 1000);
    return () => clearInterval(interval);
  }, [isSuspended, pausedUntil]);

  // ── 10-Second Fullscreen Exit Grace Timer ──
  useEffect(() => {
    if (!workspaceData?.exam?.fullscreenRequired) return;

    if (!isFullscreen && !isSuspended) {
      setFsGraceSecs(10);
      fsGraceTimerRef.current = setInterval(() => {
        setFsGraceSecs(prev => {
          if (prev === null) return null;
          if (prev <= 1) {
            clearInterval(fsGraceTimerRef.current);
            // 10 seconds expired without returning to FS -> suspend student
            triggerViolation('FULLSCREEN_EXIT_TIMEOUT', 'HIGH', 'Sortie du plein écran pendant plus de 10 secondes.');
            setIsSuspended(true);
            setSuspendReason("Session suspendue : vous n'avez pas réactivé le plein écran dans les 10 secondes imparties.");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (fsGraceTimerRef.current) clearInterval(fsGraceTimerRef.current);
      setFsGraceSecs(null);
    }

    return () => {
      if (fsGraceTimerRef.current) clearInterval(fsGraceTimerRef.current);
    };
  }, [isFullscreen, isSuspended, workspaceData?.exam?.fullscreenRequired]);

  // Timer Countdown logic
  useEffect(() => {
    if (!workspaceData?.exam) return;

    const interval = setInterval(() => {
      const { startTime, totalTimeMs, durationMinutes, status } = workspaceData.exam;
      if (status === 'PAUSED') {
        return; // Freeze countdown while exam is paused by teacher
      }
      if (!startTime) {
        setTimeLeftSeconds((durationMinutes || 60) * 60);
        return;
      }

      const totalAllowedMs = (durationMinutes * 60 * 1000) + (workspaceData.assignment?.timeExtendedMs || 0);
      const elapsedMs = Date.now() - new Date(startTime).getTime();
      const remainingMs = Math.max(0, totalAllowedMs - elapsedMs);
      const secs = Math.floor(remainingMs / 1000);

      setTimeLeftSeconds(secs);

      if (secs <= 0) {
        clearInterval(interval);
        handleAutoSubmitOnTimeOut();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [workspaceData]);

  // Autosave periodically all problems in codeMap
  useEffect(() => {
    autosaveTimerRef.current = setInterval(() => {
      if (!workspaceData?.problems || !codeMap) return;
      autosaveCode(null, null, 'ALGO', codeMap);
    }, 6000);

    return () => clearInterval(autosaveTimerRef.current);
  }, [codeMap, workspaceData]);

  // ── Anti-cheat: fullscreen + keyboard shortcut blocking ─────────────────
  useEffect(() => {
    if (!workspaceData) return;

    const checkIsFullscreen = () => {
      const fsEl = document.fullscreenElement || document.webkitFullscreenElement
        || document.mozFullScreenElement || document.msFullscreenElement;
      const sizeMatch = Math.abs(window.innerWidth - screen.width) <= 10
        && Math.abs(window.innerHeight - screen.height) <= 10;
      return !!(fsEl || sizeMatch);
    };

    // ── Fullscreen events ──
    const handleFsChange = () => {
      const inFs = checkIsFullscreen();
      setIsFullscreen(inFs);
      if (!inFs) {
        triggerViolation('FULLSCREEN_EXIT', 'HIGH', 'Sortie du mode plein écran.');
      } else {
        setFsWarning(null);
        if (workspaceData) {
          sendStudentViolation(workspaceData.exam.id, workspaceData.student.id, 'FULLSCREEN_RETURN', 'LOW', null, {});
        }
      }
    };

    const handleVisibility = () => {
      if (document.hidden) {
        setIsFullscreen(false);
        triggerViolation('TAB_SWITCH', 'HIGH', 'Changement d\'onglet détecté.');
      }
    };

    const handleBlur = () => {
      // Only log if we are actually in fullscreen context
      if (!checkIsFullscreen()) {
        setIsFullscreen(false);
        triggerViolation('FOCUS_LOSS', 'MEDIUM', 'Perte de focus de la fenêtre.');
      }
    };

    // ── Keyboard shortcuts & security ──
    const BLOCKED_KEYS = new Set([
      'F1','F2','F3','F4','F5','F6','F7','F8','F9','F10','F11','F12'
    ]);
    const BLOCKED_CTRL_SHIFT = new Set(['I','J','C','K','U','M','N','P']);

    const handleKeydown = (e) => {
      const { key, ctrlKey, metaKey, altKey, shiftKey } = e;
      const lowerKey = key.toLowerCase();

      // Editor Quick Shortcuts (Alt+Key)
      if (altKey && !ctrlKey && !metaKey) {
        if (lowerKey === 'h') { e.preventDefault(); insertSnippetAtCursor('Algorithme MonAlgorithme;\nVar\n    x : Entier;\nDebut\n    \nFin.'); return; }
        if (lowerKey === 's') { e.preventDefault(); insertSnippetAtCursor('Si (condition) Alors\n    \nSinon\n    \nFin Si;'); return; }
        if (lowerKey === 'p') { e.preventDefault(); insertSnippetAtCursor('Pour i := 1 a N Faire\n    \nFin Pour;'); return; }
        if (lowerKey === 't') { e.preventDefault(); insertSnippetAtCursor('Tant Que (condition) Faire\n    \nFin Tant Que;'); return; }
        if (lowerKey === 'v') { e.preventDefault(); insertSnippetAtCursor('Var\n    x, y : Entier;'); return; }
        if (lowerKey === 'a') { e.preventDefault(); insertSnippetAtCursor('T : Tableau[1..N] de Entier;'); return; }
        if (lowerKey === 'i') { e.preventDefault(); insertSnippetAtCursor('Lire(variable);\nEcrire(resultat);'); return; }
        if (lowerKey === 'b') { e.preventDefault(); setShowBricksMenu(prev => !prev); return; }
      }

      // Format Code: Ctrl+Shift+F
      if (ctrlKey && shiftKey && lowerKey === 'f') {
        e.preventDefault();
        handleFormatCode();
        return;
      }

      // Comment / Uncomment: Ctrl+/ or Ctrl+Alt+/
      const isSlashKey = key === '/' || lowerKey === '/' || e.code === 'Slash' || key === ':';
      if (ctrlKey && isSlashKey) {
        e.preventDefault();
        if (altKey) {
          handleUncommentCode();
        } else {
          handleToggleComment();
        }
        return;
      }

      // Block developer tools & dangerous keys
      if (BLOCKED_KEYS.has(key)) {
        e.preventDefault();
        e.stopPropagation();
        triggerViolation('SHORTCUT_BLOCKED', 'MEDIUM', `Touche bloquée: ${key}`);
        return;
      }

      // Windows / Mac Meta key combos
      if (metaKey) {
        e.preventDefault();
        e.stopPropagation();
        triggerViolation('META_KEY', 'MEDIUM', `Raccourci système bloqué: Meta+${key}`);
        return;
      }

      // Alt+F4 (close window)
      if (altKey && key === 'F4') {
        e.preventDefault();
        triggerViolation('ALT_F4', 'HIGH', 'Tentative de fermeture de fenêtre.');
        return;
      }

      if (ctrlKey && shiftKey && BLOCKED_CTRL_SHIFT.has(key)) {
        e.preventDefault();
        e.stopPropagation();
        triggerViolation('DEVTOOLS_SHORTCUT', 'HIGH', `Accès outils développeur bloqué: Ctrl+Shift+${key}`);
        return;
      }

      // Block copy/paste shortcuts only if explicitly forbidden in exam settings
      if (ctrlKey) {
        if (lowerKey === 'c' && workspaceData?.exam?.copyDisabled) {
          e.preventDefault();
          triggerViolation('COPY_ATTEMPT', 'MEDIUM', 'Raccourci copier bloqué par l\'enseignant');
          return;
        }
        if (lowerKey === 'v' && workspaceData?.exam?.pasteDisabled) {
          e.preventDefault();
          triggerViolation('PASTE_ATTEMPT', 'MEDIUM', 'Raccourci coller bloqué par l\'enseignant');
          return;
        }
        if (lowerKey === 'x' && workspaceData?.exam?.copyDisabled) {
          e.preventDefault();
          triggerViolation('CUT_ATTEMPT', 'MEDIUM', 'Raccourci couper bloqué par l\'enseignant');
          return;
        }
      }

      // Escape — prevent exiting fullscreen or workspace windows
      if (key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    // ── Prevent right-click context menu ──
    const handleContextMenu = (e) => {
      e.preventDefault();
      triggerViolation('CONTEXT_MENU', 'LOW', 'Menu contextuel bloqué.');
    };

    // ── Clipboard event handlers (respect exam settings) ──
    const handleCopy = (e) => { if (workspaceData?.exam?.copyDisabled) e.preventDefault(); };
    const handlePaste = (e) => { if (workspaceData?.exam?.pasteDisabled) e.preventDefault(); };
    const handleCut  = (e) => { if (workspaceData?.exam?.copyDisabled) e.preventDefault(); };

    // ── 500ms heartbeat for fullscreen ──
    const heartbeat = setInterval(() => {
      if (!checkIsFullscreen()) setIsFullscreen(false);
    }, 500);

    document.addEventListener('fullscreenchange',       handleFsChange);
    document.addEventListener('webkitfullscreenchange', handleFsChange);
    document.addEventListener('mozfullscreenchange',    handleFsChange);
    document.addEventListener('visibilitychange',       handleVisibility);
    window.addEventListener('blur',                     handleBlur);
    document.addEventListener('keydown',                handleKeydown, true);
    document.addEventListener('contextmenu',            handleContextMenu);
    document.addEventListener('copy',                   handleCopy);
    document.addEventListener('paste',                  handlePaste);
    document.addEventListener('cut',                    handleCut);

    return () => {
      clearInterval(heartbeat);
      document.removeEventListener('fullscreenchange',       handleFsChange);
      document.removeEventListener('webkitfullscreenchange', handleFsChange);
      document.removeEventListener('mozfullscreenchange',    handleFsChange);
      document.removeEventListener('visibilitychange',       handleVisibility);
      window.removeEventListener('blur',                     handleBlur);
      document.removeEventListener('keydown',                handleKeydown, true);
      document.removeEventListener('contextmenu',            handleContextMenu);
      document.removeEventListener('copy',                   handleCopy);
      document.removeEventListener('paste',                  handlePaste);
      document.removeEventListener('cut',                    handleCut);
    };
  }, [workspaceData, currentProblemIdx]);

  const triggerViolation = async (eventType, severity, description) => {
    if (!workspaceData) return;
    const probId = workspaceData.problems[currentProblemIdx]?.id;

    setViolationsCount(prev => prev + 1);

    logMonitoringEvent(eventType, severity, probId, { description });
    sendStudentViolation(workspaceData.exam.id, workspaceData.student.id, eventType, severity, probId, { description });
  };

  const handleAutoSubmitOnTimeOut = async () => {
    Swal.fire({
      icon: 'warning',
      title: 'Temps Écoulé !',
      text: 'Le temps imparti pour cet examen est terminé. Vos réponses sont soumises automatiquement.',
      background: '#111827',
      color: '#ffffff',
      confirmButtonColor: '#3b82f6'
    }).then(async () => {
      try {
        const result = await finalizeExam();
        if (result?.invalidateToken) {
          localStorage.removeItem('token');
          localStorage.removeItem('userRole');
        }
      } catch (_) {}
      onFinishExam();
    });
  };

  const getLiveCode = (probId) => {
    if (editorViewRef.current && editorViewRef.current.state) {
      const liveDoc = editorViewRef.current.state.doc.toString();
      if (liveDoc !== undefined) return liveDoc;
    }
    return codeMap[probId] || '';
  };

  const handleCodeChange = (newCode) => {
    if (!workspaceData) return;
    const currentProb = workspaceData?.problems?.[currentProblemIdx];
    if (!currentProb) return;

    setCodeMap(prev => ({ ...prev, [currentProb.id]: newCode }));
    if (consoleOutput && consoleOutput.status === 'ERROR') {
      setConsoleOutput(null);
    }
  };

  const insertSnippetAtCursor = (snippetText) => {
    if (isSuspended || !workspaceData) return;
    const currentProb = workspaceData?.problems?.[currentProblemIdx];
    if (!currentProb) return;

    const view = editorViewRef.current;
    if (view && view.state) {
      const selection = view.state.selection.main;
      view.dispatch({
        changes: { from: selection.from, to: selection.to, insert: snippetText },
        selection: { anchor: selection.from + snippetText.length }
      });
      const newCode = view.state.doc.toString();
      setCodeMap(prev => ({ ...prev, [currentProb.id]: newCode }));
      view.focus();
    } else {
      const currentCode = codeMap[currentProb.id] || '';
      const newCode = currentCode ? `${currentCode}\n${snippetText}` : snippetText;
      setCodeMap(prev => ({ ...prev, [currentProb.id]: newCode }));
    }
  };


  const handleCommentCode = () => {
    handleToggleComment(false);
  };

  const handleUncommentCode = () => {
    handleToggleComment(true);
  };

  const handleToggleComment = (uncommentOnly = false) => {
    if (isSuspended || !workspaceData) return;
    const currentProb = workspaceData?.problems?.[currentProblemIdx];
    if (!currentProb) return;

    const view = editorViewRef.current;
    if (view && view.state) {
      const { state } = view;
      const selection = state.selection.main;
      
      const startLine = state.doc.lineAt(selection.from);
      const endLine = state.doc.lineAt(selection.to);
      
      let lines = [];
      for (let l = startLine.number; l <= endLine.number; l++) {
        lines.push(state.doc.line(l));
      }

      const allCommented = lines.every(line => line.text.trim() === '' || /^\s*\/\//.test(line.text));
      const shouldUncomment = uncommentOnly || allCommented;

      const changes = [];
      lines.forEach(line => {
        const text = line.text;
        if (shouldUncomment) {
          const match = text.match(/^(\s*)\/\/\s?/);
          if (match) {
            const startPos = line.from + match[1].length;
            const len = match[0].length - match[1].length;
            changes.push({ from: startPos, to: startPos + len, insert: '' });
          }
        } else {
          if (text.trim() !== '') {
            const indentMatch = text.match(/^(\s*)/);
            const insertPos = line.from + (indentMatch ? indentMatch[1].length : 0);
            changes.push({ from: insertPos, insert: '// ' });
          }
        }
      });

      if (changes.length > 0) {
        view.dispatch({ changes });
        const updatedCode = view.state.doc.toString();
        setCodeMap(prev => ({ ...prev, [currentProb.id]: updatedCode }));
        view.focus();
      }
    } else {
      const currentCode = codeMap[currentProb.id] || '';
      const lines = currentCode.split('\n');
      const allCommented = lines.every(l => l.trim() === '' || /^\s*\/\//.test(l));
      const shouldUncomment = uncommentOnly || allCommented;
      
      const updated = lines.map(l => {
        if (shouldUncomment) return l.replace(/^\s*\/\/\s?/, '');
        return l.trim() === '' ? l : `// ${l}`;
      }).join('\n');

      setCodeMap(prev => ({ ...prev, [currentProb.id]: updated }));
    }
  };

  const handleResetTemplate = async () => {
    if (isSuspended || !workspaceData) return;
    const currentProb = workspaceData?.problems?.[currentProblemIdx];
    if (!currentProb) return;

    const confirm = await Swal.fire({
      title: 'Réinitialiser le code ?',
      text: 'Voulez-vous remplacer votre code actuel par le modèle initial ?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Oui, Réinitialiser',
      cancelButtonText: 'Annuler',
      background: '#111827', color: '#fff'
    });

    if (confirm.isConfirmed) {
      let tCode = currentProb.templateCode;
      if (typeof tCode === 'string') {
        try {
          const parsed = JSON.parse(tCode);
          if (parsed && typeof parsed === 'object') tCode = parsed;
        } catch (e) {}
      }
      const template = (typeof tCode === 'object' && tCode !== null)
        ? (tCode.ALGO || tCode.code || tCode.PYTHON || currentProb.starterTemplate || '// Écrivez votre algorithme en pseudo-code ici\n')
        : (typeof tCode === 'string' && tCode.trim() ? tCode : (currentProb.starterTemplate || '// Écrivez votre algorithme en pseudo-code ici\n'));

      setCodeMap(prev => ({ ...prev, [currentProb.id]: template }));
    }
  };

  const normalizeOutput = (str) => {
    if (!str) return '';
    return str
      .split('\n')
      .map(line => line.trim().replace(/[ \t]+/g, ' '))
      .filter(line => line.length > 0)
      .join('\n');
  };

  const handleRunSample = async () => {
    if (isSuspended) return;
    const currentProb = workspaceData.problems[currentProblemIdx];
    if (!currentProb) return;

    setExecuting(true);
    setConsoleOutput(null);
    setConsoleTab('results');

    try {
      const code = getLiveCode(currentProb.id);
      const res = await runSampleCode(code, 'ALGO', customInput);
      setConsoleOutput(res);
    } catch (err) {
      const errMsg = err.data?.error || err.data?.message || err.message || 'Erreur d\'exécution';
      setConsoleOutput({ status: 'ERROR', stderr: errMsg });
    } finally {
      setExecuting(false);
    }
  };

  const handleRunPublicTests = async () => {
    if (isSuspended) return;
    const currentProb = workspaceData.problems[currentProblemIdx];
    if (!currentProb) return;

    setExecuting(true);
    setPublicTestResults(null);
    setConsoleTab('tests');

    try {
      const code = getLiveCode(currentProb.id);
      const tests = currentProb.publicTestCases || [];
      const results = [];

      for (const tc of tests) {
        const res = await runSampleCode(code, 'ALGO', tc.inputData);
        const passed = res.status === 'SUCCESS' && normalizeOutput(res.stdout) === normalizeOutput(tc.expectedOutput);
        results.push({ tc, result: res, passed });
      }

      setPublicTestResults(results);
    } catch (err) {
      console.error('Run public tests error:', err);
    } finally {
      setExecuting(false);
    }
  };

  const handleSubmitProblem = async () => {
    if (isSuspended) return;
    const currentProb = workspaceData.problems[currentProblemIdx];
    if (!currentProb) return;

    const confirm = await Swal.fire({
      title: 'Soumettre la solution ?',
      text: `Voulez-vous soumettre votre solution algorithmique pour "${currentProb.title}" ?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Oui, Soumettre',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#ffffff',
      confirmButtonColor: '#10b981',
      cancelButtonColor: '#6b7280'
    });

    if (!confirm.isConfirmed) return;

    setSubmitting(true);
    try {
      const code = getLiveCode(currentProb.id);
      const res = await submitSolution(currentProb.id, 'ALGO', code);

      setWorkspaceData(prev => ({
        ...prev,
        submissions: [res, ...(prev.submissions || [])]
      }));

      Swal.fire({
        icon: res.status === 'ACCEPTED' ? 'success' : 'warning',
        title: res.status === 'ACCEPTED' ? 'Solution Acceptée !' : `Statut: ${res.status}`,
        text: `Score: ${res.score}% (${res.passedTests}/${res.totalTests} tests validés)`,
        background: '#111827',
        color: '#ffffff'
      });
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Échec de la soumission',
        text: err.data?.message || err.data?.error || 'Erreur lors de l’évaluation.',
        background: '#111827',
        color: '#ffffff'
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleFinalSubmitAll = async () => {
    const confirm = await Swal.fire({
      title: 'Terminer l\'Examen ?',
      text: 'Êtes-vous sûr de vouloir soumettre définitivement tout votre examen ? Vous ne pourrez plus modifier vos réponses.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Oui, Terminer',
      cancelButtonText: 'Continuer l\'Examen',
      background: '#111827',
      color: '#ffffff',
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#3b82f6'
    });

    if (confirm.isConfirmed) {
      try {
        // Save ALL problem codes in codeMap before finalization
        if (codeMap && Object.keys(codeMap).length > 0) {
          await autosaveCode(null, null, 'ALGO', codeMap);
        }

        await finalizeExam();

        await Swal.fire({
          icon: 'success',
          title: '✅ Examen Terminé & Soumis avec Succès !',
          text: 'Toutes vos solutions ont été enregistrées. Vous allez être redirigé vers la page de confirmation.',
          confirmButtonText: 'Voir la confirmation',
          background: '#111827',
          color: '#ffffff',
          confirmButtonColor: '#10b981'
        });
      } catch (err) {
        console.error('Finalize error:', err);
      }
      onFinishExam();
    }
  };

  if (loading || !workspaceData) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <h2>Chargement de la salle d’examen...</h2>
      </div>
    );
  }

  const { student, exam, problems, submissions } = workspaceData;
  const currentProb = problems[currentProblemIdx];

  const formatTimer = (totalSecs) => {
    if (totalSecs === null || totalSecs < 0) return '00:00:00';
    const h = Math.floor(totalSecs / 3600);
    const m = Math.floor((totalSecs % 3600) / 60);
    const s = totalSecs % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const getProblemSubmission = (pId) => {
    return (submissions || []).find(sub => sub.problemId === pId);
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#0b0f19', userSelect: 'none' }} ref={containerRef}>

      {/* ── SUSPENDED overlay (violations > max or teacher locked) ── */}
      {isSuspended && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 9999,
          background: 'rgba(5, 8, 15, 0.88)',
          backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          pointerEvents: 'auto'
        }}>
          <div style={{
            background: '#160808', border: '2px solid #ef4444',
            borderRadius: '16px', padding: '40px 36px', maxWidth: '520px', width: '90%',
            textAlign: 'center', boxShadow: '0 0 60px rgba(239,68,68,0.4)'
          }}>
            <div style={{ fontSize: '3.5rem', marginBottom: '12px' }}>🚫</div>
            <h2 style={{ color: '#f87171', fontSize: '1.6rem', marginBottom: '12px', fontWeight: '800' }}>
              Session Suspendue
            </h2>
            <p style={{ color: '#fca5a5', fontSize: '0.95rem', lineHeight: '1.6', marginBottom: '16px' }}>
              {suspendReason || "Votre session a été suspendue. Vos réponses saisies restent enregistrées."}
            </p>

            {tempSecsLeft !== null && (
              <div style={{
                fontSize: '1.15rem', color: '#60a5fa', fontWeight: '700',
                margin: '16px 0', padding: '12px 16px',
                background: 'rgba(59, 130, 246, 0.15)', borderRadius: '10px',
                border: '1px solid rgba(59, 130, 246, 0.3)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px'
              }}>
                <Clock size={18} /> Reprise automatique dans : <strong>{formatTimer(tempSecsLeft)}</strong>
              </div>
            )}

            <div style={{ padding: '10px 14px', background: 'rgba(239,68,68,0.12)', borderRadius: '8px', fontSize: '0.82rem', color: '#fbbf24' }}>
              ⚠️ Votre écran reste visible en arrière-plan mais toute saisie est bloquée jusqu'au déblocage par l'enseignant.
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Violation Lock Overlay — shows 10s countdown */}
      {(!isFullscreen && exam.fullscreenRequired && !isSuspended) && (
        <div className="fullscreen-overlay" style={{ background: 'rgba(5, 8, 15, 0.92)', backdropFilter: 'blur(6px)' }}>
          <div className="fullscreen-box" style={{ maxWidth: '480px', border: '2px solid #f59e0b' }}>
            <div className="warning-icon">⚠️</div>
            <h2 style={{ color: '#fbbf24', margin: '8px 0' }}>Mode Plein Écran Exigé</h2>

            {fsGraceSecs !== null && (
              <div style={{
                fontSize: '1.3rem', color: '#f87171', fontWeight: '800',
                margin: '14px 0', padding: '12px', background: 'rgba(239,68,68,0.15)',
                borderRadius: '10px', border: '1px solid rgba(239,68,68,0.4)',
                fontFamily: 'var(--font-mono)'
              }}>
                ⏱ Réactivez le plein écran dans : <strong>{fsGraceSecs}s</strong>
              </div>
            )}

            <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginBottom: '20px', lineHeight: '1.5' }}>
              Pour maintenir l'intégrité de l'examen, le mode plein écran est obligatoire. Si vous ne réactivez pas le plein écran sous 10 secondes, votre session sera <strong>suspendue</strong>.
            </p>

            <button className="btn btn-primary" onClick={requestFullscreen} style={{ width: '100%', padding: '14px', fontSize: '1rem', fontWeight: '700' }}>
              <Maximize size={18} /> Activer le Mode Plein Écran pour Continuer
            </button>
          </div>
        </div>
      )}

      {/* Header Toolbar — Sticky Fixed on Top */}
      <header className="glass-panel" style={{
        borderRadius: 0, padding: '12px 24px', display: 'flex', alignItems: 'center',
        justify: 'space-between', borderBottom: '1px solid var(--panel-border)',
        position: 'sticky', top: 0, zIndex: 1000, background: 'rgba(5, 7, 13, 0.98)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <FileCode color="#3b82f6" size={24} />
            <span style={{ fontWeight: '700', fontSize: '1.1rem' }}>{exam.title}</span>
          </div>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>|</span>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Étudiant: <strong style={{ color: '#ffffff' }}>{student.firstName} {student.lastName}</strong> ({student.group})
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: violationsCount > 0 ? '#f87171' : 'var(--text-muted)' }}>
            <ShieldAlert size={16} /> Avertissements: <strong>{violationsCount}</strong>
          </div>

          <div
            className={`timer-pill ${workspaceData?.exam?.status === 'PAUSED' ? 'paused' : (timeLeftSeconds < 300 ? 'urgent' : '')}`}
            style={workspaceData?.exam?.status === 'PAUSED' ? { background: 'rgba(245, 158, 11, 0.2)', border: '1px solid #f59e0b', color: '#fbbf24' } : {}}
          >
            <Clock size={18} /> {workspaceData?.exam?.status === 'PAUSED' ? `⏸ EN PAUSE (${formatTimer(timeLeftSeconds)})` : formatTimer(timeLeftSeconds)}
          </div>

          <button className="btn btn-danger" onClick={handleFinalSubmitAll} disabled={isSuspended}>
            <Send size={16} /> Terminer & Soumettre
          </button>
        </div>
      </header>

      {/* ── Announcement Strip ── */}
      {announcements.length > 0 && (
        <div style={{
          background: 'rgba(59, 130, 246, 0.2)', borderBottom: '1px solid #3b82f6',
          padding: '8px 24px', display: 'flex', alignItems: 'center', gap: '12px',
          color: '#93c5fd', fontSize: '0.88rem', fontWeight: '600'
        }}>
          <Megaphone size={18} color="#60a5fa" style={{ flexShrink: 0 }} />
          <span style={{ flex: 1 }}>
            📢 <strong>Annonce Enseignant :</strong> {announcements[0].message}
          </span>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            {new Date(announcements[0].createdAt || Date.now()).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      )}

      {/* Main Examination Grid */}
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '400px 1fr', overflow: 'hidden' }}>
        {/* Left Pane: Problems & Statement */}
        <div style={{ borderRight: '1px solid var(--panel-border)', display: 'flex', flexDirection: 'column', background: 'rgba(17, 24, 39, 0.5)', height: '100%', overflow: 'hidden', minHeight: 0 }}>
          {/* Problem Selector Tabs */}
          <div style={{ display: 'flex', borderBottom: '1px solid var(--panel-border)', background: 'rgba(0,0,0,0.2)', flexShrink: 0 }}>
            {problems.map((p, idx) => {
              const sub = getProblemSubmission(p.id);
              const isActive = idx === currentProblemIdx;
              return (
                <button
                  key={p.id}
                  onClick={() => {
                    if (idx === currentProblemIdx) return;
                    // Persist live editor text of currently open problem before switching
                    if (editorViewRef.current && editorViewRef.current.state && currentProb) {
                      const liveCode = editorViewRef.current.state.doc.toString();
                      setCodeMap(prev => ({ ...prev, [currentProb.id]: liveCode }));
                    }
                    setCurrentProblemIdx(idx);
                    sendStudentSwitchProblem(exam.id, student.id, p.id);
                    if (p.publicTestCases && p.publicTestCases[0]) {
                      setCustomInput(p.publicTestCases[0].inputData);
                    }
                    setConsoleOutput(null);
                    setPublicTestResults(null);
                  }}
                  style={{
                    flex: 1,
                    padding: '12px 8px',
                    background: isActive ? 'rgba(59, 130, 246, 0.15)' : 'transparent',
                    border: 'none',
                    borderBottom: isActive ? '2px solid #3b82f6' : '2px solid transparent',
                    color: isActive ? '#ffffff' : 'var(--text-muted)',
                    cursor: 'pointer',
                    fontSize: '0.85rem',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px'
                  }}
                >
                  Problème {idx + 1}
                  {sub?.status === 'ACCEPTED' && <CheckCircle size={14} color="#34d399" />}
                  {sub?.status && sub.status !== 'ACCEPTED' && <AlertCircle size={14} color="#fbbf24" />}
                </button>
              );
            })}
          </div>

          {/* Statement Content */}
          <div style={{ flex: 1, padding: '24px', overflowY: 'auto', minHeight: 0 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
              <h2 style={{ fontSize: '1.3rem' }}>{currentProb.title}</h2>
              <span className="badge badge-purple">{currentProb.points} Points</span>
            </div>

            <div className="markdown-body" style={{ color: 'var(--text-main)', fontSize: '0.95rem', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: renderMarkdownHTML(currentProb.description) }} />

            {/* Sub-questions breakdown if multi-questions */}
            {Array.isArray(currentProb.questions) && currentProb.questions.length > 1 && (
              <div style={{ marginTop: '22px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div style={{ fontSize: '0.88rem', fontWeight: '800', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span>📋 Questions de l'Exercice ({currentProb.questions.length}) :</span>
                </div>
                {currentProb.questions.map((q, qIdx) => {
                  const qPts = currentProb.questionPoints?.[q.id] || currentProb.questionPoints?.[q.orderIndex];
                  return (
                    <div key={q.id || qIdx} className="glass-panel" style={{ padding: '14px 18px', borderLeft: '3px solid #8b5cf6', background: 'rgba(15, 23, 42, 0.65)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <span style={{ fontWeight: '800', color: '#c4b5fd', fontSize: '0.9rem' }}>
                          Question {q.orderIndex}
                        </span>
                        {qPts != null && (
                          <span className="badge badge-blue" style={{ fontSize: '0.75rem' }}>
                            {parseFloat(Number(qPts).toFixed(2))} pts
                          </span>
                        )}
                      </div>
                      <div className="markdown-body" style={{ fontSize: '0.9rem', lineHeight: '1.5' }} dangerouslySetInnerHTML={{ __html: renderMarkdownHTML(q.statement) }} />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Pane: CodeMirror Editor & Execution Console */}
        <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
          {/* Editor Header Bar */}
          <div style={{ padding: '10px 20px', background: 'rgba(0,0,0,0.3)', borderBottom: '1px solid var(--panel-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span className="badge badge-blue">Langage Algorithmique</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>(Autocomplétion & Coloration activées)</span>
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              {currentProb?.publicTestCases && currentProb.publicTestCases.length > 0 && (
                <button className="btn btn-secondary" onClick={handleRunPublicTests} disabled={executing || isSuspended} style={{ fontSize: '0.82rem', padding: '6px 12px' }}>
                  <Play size={14} color="#60a5fa" /> {executing && consoleTab === 'tests' ? 'Test...' : 'Tests Publics'}
                </button>
              )}
              <button className="btn btn-secondary" onClick={handleRunSample} disabled={executing || isSuspended} style={{ fontSize: '0.82rem', padding: '6px 12px' }}>
                <Play size={14} color="#34d399" /> {executing && consoleTab === 'results' ? 'Exécution...' : 'Exécuter'}
              </button>
            </div>
          </div>

          {/* CodeMirror Workspace */}
          <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            {/* Top Editor Action Toolbar */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '6px 16px',
              background: '#090d16',
              borderBottom: '1px solid var(--panel-border)',
              fontSize: '0.8rem'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  style={{ padding: '3px 10px', fontSize: '0.75rem', color: '#60a5fa', borderColor: 'rgba(96,165,250,0.3)' }}
                  onClick={handleFormatCode}
                  title="Formater et indenter le code ALGO (Alt+F)"
                >
                  <Sparkles size={12} color="#60a5fa" /> Formater <kbd className="shortcut-kbd">Alt+F</kbd>
                </button>
                <button
                  type="button"
                  className="btn btn-secondary"
                  style={{ padding: '3px 10px', fontSize: '0.75rem' }}
                  onClick={handleCommentCode}
                  title="Commenter/Décommenter la ligne (Ctrl+/)"
                >
                  💬 Commenter <kbd className="shortcut-kbd">Ctrl+/</kbd>
                </button>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', background: '#1e293b', borderRadius: '4px', padding: '1px 6px' }}>
                  <button type="button" onClick={() => setFontSize(f => Math.max(12, f - 1))} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '0.8rem' }}>-</button>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-main)', minWidth: '24px', textAlign: 'center' }}>{fontSize}px</span>
                  <button type="button" onClick={() => setFontSize(f => Math.min(22, f + 1))} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '0.8rem' }}>+</button>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  style={{
                    padding: '4px 12px',
                    fontSize: '0.78rem',
                    background: showBricksMenu ? 'rgba(244,63,94,0.18)' : 'rgba(255,255,255,0.05)',
                    borderColor: showBricksMenu ? '#f43f5e' : 'rgba(255,255,255,0.15)',
                    color: showBricksMenu ? '#ffffff' : 'var(--text-muted)',
                    fontWeight: '800'
                  }}
                  onClick={() => setShowBricksMenu(prev => !prev)}
                  title="Afficher/Masquer le panneau des Briques de Code (Alt+B)"
                >
                  🧩 Briques de Code <kbd className="shortcut-kbd">Alt+B</kbd> {showBricksMenu ? '▶' : '◀'}
                </button>
              </div>
            </div>

            {/* Split Editor Container: Main CodeMirror (Left) + Right Bricks Panel */}
            <div style={{ flex: 1, display: 'flex', height: '100%', overflow: 'hidden' }}>
              {/* Main CodeMirror Editor (Left) */}
              <div style={{ flex: 1, height: '100%', overflow: 'hidden' }}>
                <CodeMirror
                  key={currentProb?.id || 'editor'}
                  value={codeMap[currentProb?.id] ?? ''}
                  height="100%"
                  theme="dark"
                  readOnly={isSuspended}
                  onCreateEditor={(view) => {
                    editorViewRef.current = view;
                  }}
                  onUpdate={(update) => {
                    if (update.docChanged) {
                      const newCode = update.state.doc.toString();
                      handleCodeChange(newCode);
                    }
                  }}
                  extensions={[...algoExtension(), search({ top: true }), algoLinterExtension, lintGutter(), lockedZonesExtension()]}
                  style={{ height: '100%', fontSize: `${fontSize}px` }}
                />
              </div>

              {/* RIGHT SIDEBAR: Code Bricks Panel */}
              {showBricksMenu && (
                <div style={{
                  width: '400px', minWidth: '340px', maxWidth: '48%',
                  background: '#0b1120', borderLeft: '1px solid var(--panel-border)',
                  display: 'flex', flexDirection: 'column', padding: '18px', overflow: 'hidden'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', paddingBottom: '8px', borderBottom: '1px solid rgba(255,255,255,0.12)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '1.2rem' }}>🧩</span>
                      <h4 style={{ fontSize: '0.98rem', margin: 0, color: '#f8fafc', fontWeight: '800' }}>
                        Briques de Code
                      </h4>
                    </div>
                    <button
                      className="btn btn-secondary"
                      style={{ padding: '3px 10px', fontSize: '0.78rem', fontWeight: '700' }}
                      onClick={() => setShowBricksMenu(false)}
                      title="Masquer le panneau"
                    >
                      ✕ Masquer
                    </button>
                  </div>

                  <div style={{ fontSize: '0.74rem', color: '#93c5fd', background: 'rgba(59,130,246,0.1)', padding: '5px 10px', borderRadius: '6px', marginBottom: '10px', border: '1px solid rgba(59,130,246,0.25)' }}>
                    💡 <strong>Astuce :</strong> Double-cliquez sur une brique pour l'insérer instantanément au curseur.
                  </div>

                  <div style={{ position: 'relative', marginBottom: '10px' }}>
                    <Search size={15} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Filtrer les briques..."
                      style={{ paddingLeft: '32px', fontSize: '0.82rem', padding: '6px 10px 6px 32px' }}
                      value={studentBrickSearch}
                      onChange={e => setStudentBrickSearch(e.target.value)}
                    />
                  </div>

                  {/* Flat List of Allowed Bricks */}
                  <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px', paddingRight: '4px' }}>
                    {(() => {
                      let allowedList = workspaceData?.exam?.allowedBricks;
                      if (typeof allowedList === 'string') {
                        try {
                          allowedList = JSON.parse(allowedList);
                        } catch (err) {
                          allowedList = null;
                        }
                      }

                      const legacyMap = {
                        "LIRE_TAB": "CH2_LIRE_1D",
                        "AFFICHER_TAB": "CH2_ECRIRE_1D",
                        "LIRE_MATRICE": "CH2_LIRE_2D",
                        "AFFICHER_MATRICE": "CH2_ECRIRE_2D",
                        "RECHERCHE_MAX": "CH2_MAX_MIN",
                        "TRI_BULLES": "CH2_TRI_BULLES"
                      };

                      const filteredBricks = COMPREHENSIVE_CODE_BRICKS.filter(b => {
                        let isAllowed = true;
                        if (Array.isArray(allowedList)) {
                          isAllowed = allowedList.includes(b.id) ||
                            Object.entries(legacyMap).some(([oldId, newId]) => newId === b.id && allowedList.includes(oldId));
                        }

                        const matchSearch = !studentBrickSearch.trim() ||
                          b.label.toLowerCase().includes(studentBrickSearch.toLowerCase()) ||
                          b.snippet.toLowerCase().includes(studentBrickSearch.toLowerCase());

                        return isAllowed && matchSearch;
                      });

                      if (filteredBricks.length === 0) {
                        return (
                          <div style={{ padding: '20px 12px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.82rem', fontWeight: '600' }}>
                            🚫 Aucune brique autorisée pour cet examen.
                          </div>
                        );
                      }

                      return filteredBricks.map(b => {
                        const isExpanded = !!expandedStudentBrickIds[b.id];

                        return (
                          <div
                            key={b.id}
                            style={{
                              borderRadius: '8px',
                              border: isExpanded ? '1px solid #a855f7' : '1px solid rgba(255, 255, 255, 0.1)',
                              background: isExpanded ? 'rgba(168, 85, 247, 0.12)' : 'rgba(15, 23, 42, 0.7)',
                              display: 'flex', flexDirection: 'column', overflow: 'hidden',
                              transition: 'all 0.12s ease',
                              flexShrink: 0
                            }}
                            onDoubleClick={() => insertSnippetAtCursor(b.snippet)}
                            title="Double-cliquez pour insérer directement"
                          >
                            <div
                              style={{
                                padding: '8px 10px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                cursor: 'default', userSelect: 'none', gap: '8px'
                              }}
                            >
                              <div
                                style={{ display: 'flex', alignItems: 'center', gap: '6px', flex: 1, minWidth: 0 }}
                              >
                                <span style={{
                                  fontSize: '0.82rem',
                                  fontWeight: '700',
                                  color: '#f1f5f9',
                                  lineHeight: '1.25',
                                  whiteSpace: 'normal',
                                  wordBreak: 'break-word'
                                }}>
                                  {b.label}
                                </span>
                              </div>

                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0 }}>
                                <button
                                  type="button"
                                  style={{
                                    background: isExpanded ? 'rgba(168,85,247,0.3)' : 'rgba(255,255,255,0.06)',
                                    border: '1px solid rgba(255,255,255,0.15)',
                                    color: isExpanded ? '#c084fc' : '#94a3b8',
                                    borderRadius: '4px',
                                    cursor: 'pointer', padding: '3px 6px', display: 'flex', alignItems: 'center', gap: '3px',
                                    fontSize: '0.72rem', fontWeight: '600'
                                  }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setExpandedStudentBrickIds(prev => ({ ...prev, [b.id]: !prev[b.id] }));
                                  }}
                                  title="Voir / Masquer le code"
                                >
                                  <Eye size={12} /> {isExpanded ? 'Fermer' : 'Voir'}
                                </button>

                                <button
                                  type="button"
                                  style={{
                                    background: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
                                    border: 'none', color: '#ffffff',
                                    borderRadius: '4px',
                                    cursor: 'pointer', padding: '3px 8px', display: 'flex', alignItems: 'center', gap: '3px',
                                    fontSize: '0.74rem', fontWeight: '700',
                                    boxShadow: '0 2px 4px rgba(124, 58, 237, 0.3)'
                                  }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    insertSnippetAtCursor(b.snippet);
                                  }}
                                  title="Insérer le code au curseur"
                                >
                                  <Plus size={13} /> Insérer
                                </button>
                              </div>
                            </div>

                            {/* Code Snippet (Visible when expanded) */}
                            {isExpanded && (
                              <div style={{ padding: '0 10px 10px 10px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <pre style={{
                                  margin: 0, padding: '8px 10px', background: '#05070d', borderRadius: '6px',
                                  fontSize: '0.82rem', color: '#34d399', fontFamily: 'var(--font-mono)',
                                  lineHeight: '1.45', whiteSpace: 'pre-wrap', maxHeight: '180px', overflowY: 'auto',
                                  border: '1px solid rgba(255,255,255,0.08)'
                                }}>
                                  {b.snippet}
                                </pre>

                                <button
                                  type="button"
                                  className="btn btn-primary"
                                  style={{ padding: '6px 12px', fontSize: '0.8rem', fontWeight: '700', width: '100%', background: 'linear-gradient(135deg, #8b5cf6, #7c3aed)' }}
                                  onClick={() => {
                                    insertSnippetAtCursor(b.snippet);
                                  }}
                                >
                                  ➕ Insérer au Curseur (ou Double-Clic)
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Bottom Panel: Custom Input + Tests + Results */}
          <div style={{ height: '260px', borderTop: '1px solid var(--panel-border)', background: 'rgba(5, 7, 13, 0.98)', display: 'flex', flexDirection: 'column' }}>

            {/* Tab bar */}
            <div style={{ display: 'flex', borderBottom: '1px solid var(--panel-border)', background: 'rgba(0,0,0,0.3)', flexShrink: 0 }}>
              {[
                { key: 'custom',  label: '✏️ Entrée Personnalisée' },
                ...(currentProb?.publicTestCases?.length > 0 ? [{ key: 'tests', label: `🧪 Tests Publics${publicTestResults ? ` (${publicTestResults.filter(r=>r.passed).length}/${publicTestResults.length})` : ''}` }] : []),
                { key: 'results', label: `🖥️ Résultats${consoleOutput ? ` — ${consoleOutput.status}` : ''}` },
              ].map(tab => (
                <button key={tab.key} onClick={() => setConsoleTab(tab.key)}
                  style={{
                    padding: '8px 16px', background: 'none', border: 'none',
                    borderBottom: consoleTab === tab.key ? '2px solid #3b82f6' : '2px solid transparent',
                    color: consoleTab === tab.key ? '#fff' : 'var(--text-muted)',
                    fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', whiteSpace: 'nowrap'
                  }}
                >{tab.label}</button>
              ))}

              {(!currentProb?.publicTestCases || currentProb?.publicTestCases?.length === 0) && (
                <span style={{ padding: '0 14px', fontSize: '0.75rem', color: '#fbbf24', alignSelf: 'center', fontWeight: '600' }}>
                  ℹ️ Aucun test public (Évaluation manuelle)
                </span>
              )}

              <div style={{ flex: 1 }} />
              <span style={{ padding: '0 14px', fontSize: '0.75rem', color: 'var(--text-muted)', alignSelf: 'center', display: 'flex', alignItems: 'center', gap: '5px' }}>
                <Terminal size={12} /> Console
              </span>
            </div>

            {/* Tab content */}
            <div style={{ flex: 1, overflow: 'hidden', display: 'flex' }}>

              {/* ── Custom Input Tab ── */}
              {consoleTab === 'custom' && (
                <div style={{ flex: 1, display: 'flex', gap: 0 }}>
                  {/* Input area */}
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: '1px solid var(--panel-border)' }}>
                    <div style={{ padding: '6px 12px', fontSize: '0.75rem', color: '#60a5fa', fontWeight: '600', borderBottom: '1px solid var(--panel-border)', background: 'rgba(59,130,246,0.06)' }}>
                      STDIN (Entrée Personnalisée)
                    </div>
                    <textarea
                      value={customInput}
                      onChange={e => setCustomInput(e.target.value)}
                      onKeyDown={e => e.stopPropagation()}
                      spellCheck={false}
                      placeholder="Tapez votre entrée ici..."
                      style={{
                        flex: 1, background: 'transparent', border: 'none', outline: 'none',
                        color: '#f3f4f6', fontFamily: 'var(--font-mono)', fontSize: '0.85rem',
                        padding: '10px 14px', resize: 'none', lineHeight: '1.5'
                      }}
                    />
                  </div>
                  {/* Quick test case buttons */}
                  <div style={{ width: '160px', display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
                    <div style={{ padding: '6px 10px', fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: '600', borderBottom: '1px solid var(--panel-border)', background: 'rgba(0,0,0,0.3)' }}>
                      Exemples
                    </div>
                    {(currentProb.publicTestCases || []).map((tc, i) => (
                      <button key={tc.id || i}
                        onClick={() => setCustomInput(tc.inputData)}
                        style={{
                          padding: '8px 10px', background: 'none', border: 'none',
                          borderBottom: '1px solid var(--panel-border)',
                          color: 'var(--text-muted)', fontSize: '0.75rem',
                          cursor: 'pointer', textAlign: 'left'
                        }}
                        onMouseEnter={e => e.target.style.background = 'rgba(59,130,246,0.1)'}
                        onMouseLeave={e => e.target.style.background = 'none'}
                      >
                        📥 Exemple {i + 1}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* ── Public Tests Tab ── */}
              {consoleTab === 'tests' && (
                <div style={{ flex: 1, overflowY: 'auto', padding: '10px 14px' }}>
                  {!publicTestResults ? (
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem', padding: '10px 0' }}>
                      Cliquez sur <strong style={{color:'#60a5fa'}}>"Tests Publics"</strong> pour exécuter votre code sur tous les exemples.
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {publicTestResults.map(({ tc, result, passed }, i) => (
                        <div key={tc.id || i} style={{
                          padding: '10px 12px', borderRadius: '6px',
                          background: passed ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
                          border: `1px solid ${passed ? 'rgba(16,185,129,0.4)' : 'rgba(239,68,68,0.4)'}`
                        }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', fontWeight: '700', marginBottom: '6px' }}>
                            <span style={{ color: passed ? '#34d399' : '#f87171' }}>
                              {passed ? '✓ Exemple' : '✕ Exemple'} #{i + 1}
                            </span>
                            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>{result.executionMs || 0}ms</span>
                          </div>
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '0.78rem', fontFamily: 'var(--font-mono)' }}>
                            <div>
                              <div style={{ color: 'var(--text-muted)', marginBottom: '2px' }}>Entrée:</div>
                              <pre style={{ color: '#e5e7eb', margin: 0, background: 'rgba(0,0,0,0.3)', padding: '4px 6px', borderRadius: '4px', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{tc.inputData || '(vide)'}</pre>
                            </div>
                            <div>
                              <div style={{ color: 'var(--text-muted)', marginBottom: '2px' }}>Attendu:</div>
                              <pre style={{ color: '#e5e7eb', margin: 0, background: 'rgba(0,0,0,0.3)', padding: '4px 6px', borderRadius: '4px', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{tc.expectedOutput || '(vide)'}</pre>
                            </div>
                            <div style={{ gridColumn: '1/-1' }}>
                              <div style={{ color: passed ? '#34d399' : '#f87171', marginBottom: '2px' }}>Votre sortie:</div>
                              <pre style={{ color: '#e5e7eb', margin: 0, background: 'rgba(0,0,0,0.3)', padding: '4px 6px', borderRadius: '4px', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{formatOutputText(result.stdout || result.stderr) || '(vide)'}</pre>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* ── Results Tab (custom run output) ── */}
              {consoleTab === 'results' && (
                <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px', fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>
                  {consoleOutput ? (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Statut :</span>
                          <span className={`badge ${consoleOutput.status === 'SUCCESS' ? 'badge-green' : 'badge-red'}`}>
                            {consoleOutput.status === 'SUCCESS' ? '✓ Succès' : '✕ Erreur'}
                          </span>
                        </div>
                        {consoleOutput.executionMs !== undefined && (
                          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>⏱ {consoleOutput.executionMs}ms</span>
                        )}
                      </div>

                      {/* Display STDIN Input Used */}
                      <div>
                        <div style={{ color: '#60a5fa', marginBottom: '4px', fontSize: '0.75rem', fontWeight: '700' }}>
                          📥 Entrée Fournie (STDIN) :
                        </div>
                        <pre style={{
                          background: 'rgba(0,0,0,0.4)', padding: '8px 12px', borderRadius: '6px',
                          color: '#cbd5e1', margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                          border: '1px solid rgba(96,165,250,0.2)'
                        }}>{customInput ? customInput : '(Aucune entrée fournie)'}</pre>
                      </div>

                      {/* Display STDOUT Output */}
                      <div>
                        <div style={{ color: '#34d399', marginBottom: '4px', fontSize: '0.75rem', fontWeight: '700' }}>
                          📤 Sortie Standard (STDOUT) :
                        </div>
                        <pre style={{
                          background: 'rgba(0,0,0,0.5)', padding: '10px 12px', borderRadius: '6px',
                          color: '#f3f4f6', margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                          border: '1px solid rgba(52,211,153,0.3)', minHeight: '38px'
                        }}>{consoleOutput.stdout ? formatOutputText(consoleOutput.stdout) : (consoleOutput.status === 'SUCCESS' ? '(Exécution terminée sans affichage Ecrire)' : '(Sortie vide)')}</pre>
                      </div>

                      {/* Display STDERR */}
                      {consoleOutput.stderr && (
                        <div>
                          <div style={{ color: '#f87171', marginBottom: '4px', fontSize: '0.75rem', fontWeight: '700' }}>
                            ⚠️ Erreurs / Trace d'exécution (STDERR) :
                          </div>
                          <pre style={{
                            background: 'rgba(239,68,68,0.1)', padding: '10px 12px', borderRadius: '6px',
                            color: '#fca5a5', margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                            border: '1px solid rgba(239,68,68,0.4)'
                          }}>{formatOutputText(consoleOutput.stderr)}</pre>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div style={{ color: 'var(--text-muted)' }}>
                      Cliquez sur <strong style={{color:'#34d399'}}>"Exécuter"</strong> pour tester avec votre entrée personnalisée.
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── KEYBOARD SHORTCUTS GUIDE MODAL ── */}
      {showShortcutsModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000, padding: '20px' }}>
          <div className="glass-panel" style={{ width: '90%', maxWidth: '640px', background: '#0f172a', border: '1px solid #334155', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 20px 50px rgba(0,0,0,0.8)' }}>
            <div style={{ padding: '16px 20px', background: 'rgba(30,41,59,0.8)', borderBottom: '1px solid #334155', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span style={{ fontSize: '1.2rem' }}>⌨️</span>
                <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: '800', color: '#fff' }}>Guide des Raccourcis Clavier</h3>
              </div>
              <button onClick={() => setShowShortcutsModal(false)} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: '1.2rem', fontWeight: '700' }}>✕</button>
            </div>

            <div style={{ padding: '20px', maxHeight: '70vh', overflowY: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid #334155', textAlign: 'left', color: '#60a5fa' }}>
                    <th style={{ padding: '8px' }}>Raccourci</th>
                    <th style={{ padding: '8px' }}>Action & Inserteur</th>
                  </tr>
                </thead>
                <tbody style={{ color: '#e2e8f0' }}>
                  {[
                    { key: 'Ctrl + F', desc: 'Ouvrir le panneau de recherche dans le code' },
                    { key: 'Ctrl + H', desc: 'Ouvrir le panneau de recherche et remplacement' },
                    { key: 'Ctrl + Z', desc: 'Défaire la dernière modification' },
                    { key: 'Ctrl + Y', desc: 'Rétablir la modification annulée' },
                    { key: 'Ctrl + Shift + F', desc: 'Reformater et indenter automatiquement tout le code' },
                    { key: 'Ctrl + /', desc: 'Commenter les lignes sélectionnées (//)' },
                    { key: 'Ctrl + Alt + /', desc: 'Décommenter les lignes sélectionnées' },
                    { key: 'Alt + H', desc: 'Insérer la structure d\'en-tête (Algorithme...Fin)' },
                    { key: 'Alt + S', desc: 'Insérer un bloc conditionnel (Si...Alors...Sinon)' },
                    { key: 'Alt + P', desc: 'Insérer une boucle itérative (Pour...Faire)' },
                    { key: 'Alt + T', desc: 'Insérer une boucle conditionnelle (TantQue...Faire)' },
                    { key: 'Alt + V', desc: 'Insérer une déclaration de variables (Var)' },
                    { key: 'Alt + A', desc: 'Insérer une structure de Tableau' },
                    { key: 'Alt + I', desc: 'Insérer instructions Lire / Ecrire' },
                    { key: 'Alt + B', desc: 'Ouvrir le menu déroulant des Briques de Code' },
                    { key: 'Ctrl + Espace', desc: 'Déclencher manuellement l\'autocomplétion IntelliSense' }
                  ].map((s, idx) => (
                    <tr key={idx} style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                      <td style={{ padding: '10px 8px' }}><kbd className="shortcut-kbd" style={{ fontSize: '0.78rem', padding: '3px 8px' }}>{s.key}</kbd></td>
                      <td style={{ padding: '10px 8px', color: '#cbd5e1' }}>{s.desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div style={{ padding: '14px 20px', background: 'rgba(15,23,42,0.8)', borderTop: '1px solid #334155', textAlign: 'right' }}>
              <button className="btn btn-primary" onClick={() => setShowShortcutsModal(false)} style={{ padding: '6px 16px', fontSize: '0.85rem' }}>Fermer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
