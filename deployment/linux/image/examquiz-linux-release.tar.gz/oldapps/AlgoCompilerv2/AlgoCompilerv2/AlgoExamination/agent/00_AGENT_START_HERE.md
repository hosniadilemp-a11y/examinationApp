# AlgoExamination — Agent Start Here

## Purpose

This documentation is the operational memory for AI coding agents working on AlgoExamination.

The agent MUST read this file first, then the relevant specialized documents before changing code.

## Core Principle

> Understand the existing architecture first. Make the smallest safe change that satisfies the task. Preserve existing behavior unless the task explicitly changes it.

AlgoExamination is a real-time academic examination platform. Small changes can affect:
- exam state transitions
- student access and identity
- anti-cheat enforcement
- Socket.IO synchronization
- autosave
- grading
- PDF authenticity
- Prisma data integrity
- teacher live monitoring

Never treat a UI request as UI-only until its backend, database, socket, and security implications have been checked.

## Required Reading by Task

| Task | Read |
|---|---|
| Any task | `01_ARCHITECTURE.md`, `02_ENGINEERING_RULES.md` |
| Exam creation/editing | `03_EXAM_MANAGER.md`, `04_DATABASE.md` |
| Student exam | `05_STUDENT_EXPERIENCE.md`, `06_ANTICHEAT.md` |
| Teacher monitoring | `06_ANTICHEAT.md`, `07_SOCKETIO.md` |
| Grading | `08_GRADING.md` |
| PDF/ZIP export | `09_PDF_EXPORT.md` |
| Pseudo-code execution | `10_CODE_EXECUTION.md` |
| Bug fixing | `11_DEBUGGING.md`, `12_VERIFICATION.md` |

## Non-Negotiable Rules

1. Do not invent architecture that contradicts the existing codebase.
2. Do not change dependency module formats casually.
3. Do not change Prisma models without checking all affected controllers/components.
4. Never pass raw time strings into JavaScript `Date` or Prisma.
5. Student status changes require both target and teacher-room socket reporting.
6. Existing exercise points must never be redistributed when adding an exercise.
7. Official PDFs remain pure black/white.
8. Do not remove anti-cheat behavior while fixing unrelated UI bugs.
9. Do not trust only Socket.IO for critical state; preserve the existing HTTP fallback mechanisms.
10. Run verification commands before declaring a task complete.

## Safe Modification Workflow

1. Inspect repository structure.
2. Locate the exact implementation.
3. Read the relevant documentation.
4. Trace data flow: UI → API/socket → controller/service → Prisma → response/event.
5. Identify invariants.
6. Make the smallest coherent change.
7. Check related code for regressions.
8. Run the required verification commands.
9. Report exactly what changed and what was verified.

## Never Claim

Do not say:
- "fixed" without verification
- "works" without testing
- "secure" without checking the relevant security path
- "real-time" merely because a socket event exists
- "PDF verified" unless QR/signature behavior was actually checked
