import React, { useState } from 'react';
import { teacherLogin, studentLogin } from '../services/api';
import { ShieldCheck, LogIn, GraduationCap, Eye, Building, KeyRound } from 'lucide-react';
import Swal from 'sweetalert2';

const LOGIN_ROLES = [
  {
    id: 'STUDENT',
    label: 'Étudiant',
    icon: KeyRound,
    color: '#60a5fa',
    type: 'STUDENT',
    desc: 'Accès candidat : entrez votre numéro d’accès individuel (code anonyme).'
  },
  {
    id: 'TEACHER',
    label: 'Enseignant',
    icon: GraduationCap,
    email: 'teacher@esi.dz',
    color: '#3b82f6',
    type: 'STAFF',
    desc: 'Création d’épreuves, gestion des modèles, correction anonyme & attribution des notes.'
  },
  {
    id: 'PROCTOR',
    label: 'Surveillant',
    icon: Eye,
    email: 'surveillance@esi.dz',
    color: '#10b981',
    type: 'STAFF',
    desc: 'Lancement de salle, suivi des présences en temps réel, anti-triche & export .algobundle.'
  },
  {
    id: 'ADMIN',
    label: 'Administration',
    icon: Building,
    email: 'admin@esi.dz',
    color: '#f59e0b',
    type: 'STAFF',
    desc: 'Service Scolarité : résultats dé-anonymisés, PVs officiels, statistiques & recours PDF.'
  }
];

export default function UnifiedLogin({ onStudentLoginSuccess, onTeacherLoginSuccess }) {
  const getInitialRole = () => {
    const path = window.location.pathname.toLowerCase();
    if (path.startsWith('/surveillance')) return 'PROCTOR';
    if (path.startsWith('/admin')) return 'ADMIN';
    if (path.startsWith('/teacher')) return 'TEACHER';
    if (path.startsWith('/student')) return 'STUDENT';
    return 'STUDENT';
  };

  const [activeRole, setActiveRole] = useState(getInitialRole);
  const [accessNumber, setAccessNumber] = useState('');
  const [email, setEmail] = useState(() => {
    const r = LOGIN_ROLES.find(x => x.id === getInitialRole());
    return r?.email || 'teacher@esi.dz';
  });
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);

  const handleRoleSelect = (role) => {
    setActiveRole(role.id);
    if (role.email) setEmail(role.email);
    setPassword('admin123');
  };

  const handleStudentSubmit = async (e) => {
    e.preventDefault();
    if (!accessNumber.trim()) return;

    setLoading(true);
    try {
      const data = await studentLogin(accessNumber.trim());
      localStorage.setItem('token', data.token);
      localStorage.setItem('userRole', 'STUDENT');
      window.history.replaceState({}, '', '/student');
      onStudentLoginSuccess(data);
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Accès refusé',
        text: err.data?.error || 'Numéro d’accès invalide ou examen non démarré.',
        background: '#111827',
        color: '#ffffff',
        confirmButtonColor: '#ef4444'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStaffSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await teacherLogin(email, password);
      const userRole = data.teacher?.role || activeRole;
      localStorage.setItem('token', data.token);
      localStorage.setItem('userRole', userRole);
      localStorage.setItem('userName', data.teacher?.name || 'Personnel');

      if (userRole === 'PROCTOR') {
        window.history.replaceState({}, '', '/surveillance');
      } else if (userRole === 'ADMIN') {
        window.history.replaceState({}, '', '/admin');
      } else {
        window.history.replaceState({}, '', '/teacher');
      }

      onTeacherLoginSuccess(data);
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Authentification échouée',
        text: err.data?.error || 'Email ou mot de passe incorrect.',
        background: '#111827',
        color: '#ffffff',
        confirmButtonColor: '#ef4444'
      });
    } finally {
      setLoading(false);
    }
  };

  const activeRoleObj = LOGIN_ROLES.find(r => r.id === activeRole) || LOGIN_ROLES[0];
  const isStudent = activeRole === 'STUDENT';

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', background: 'var(--bg-color)' }}>
      <div className="glass-panel" style={{ width: '100%', maxWidth: '540px', padding: '36px', border: `1px solid ${activeRoleObj.color}40`, boxShadow: `0 8px 32px ${activeRoleObj.color}15` }}>
        
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{
            width: '62px', height: '62px', borderRadius: '16px',
            background: `${activeRoleObj.color}20`,
            border: `1px solid ${activeRoleObj.color}60`,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: '12px'
          }}>
            <activeRoleObj.icon size={32} color={activeRoleObj.color} />
          </div>
          <h2 style={{ margin: '0 0 6px 0', fontSize: '1.55rem', fontWeight: '800', color: '#f8fafc' }}>
            AlgoExamination
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', margin: 0 }}>
            {activeRoleObj.desc}
          </p>
        </div>

        {/* Unified 4-Role Switcher Tabs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px', marginBottom: '24px' }}>
          {LOGIN_ROLES.map((role) => {
            const isSelected = activeRole === role.id;
            const Icon = role.icon;
            return (
              <button
                key={role.id}
                type="button"
                onClick={() => handleRoleSelect(role)}
                style={{
                  padding: '9px 4px',
                  borderRadius: '8px',
                  border: isSelected ? `2px solid ${role.color}` : '1px solid #334155',
                  background: isSelected ? `${role.color}20` : 'rgba(15, 23, 42, 0.6)',
                  color: isSelected ? '#fff' : '#94a3b8',
                  fontWeight: isSelected ? '800' : '600',
                  fontSize: '0.78rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '5px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
              >
                <Icon size={16} color={isSelected ? role.color : '#94a3b8'} />
                <span>{role.label}</span>
              </button>
            );
          })}
        </div>

        {/* Form rendering depending on selected role */}
        {isStudent ? (
          <form onSubmit={handleStudentSubmit}>
            <div className="form-group" style={{ marginBottom: '22px' }}>
              <label htmlFor="studentAccessCode" style={{ fontSize: '0.85rem', color: '#cbd5e1', marginBottom: '6px', display: 'block' }}>
                Numéro d’Accès Candidat (Code Anonyme)
              </label>
              <input
                id="studentAccessCode"
                type="text"
                className="form-input"
                placeholder="ex: AL2026-001"
                value={accessNumber}
                onChange={(e) => setAccessNumber(e.target.value.toUpperCase())}
                style={{ fontSize: '1.2rem', textAlign: 'center', letterSpacing: '2px', fontFamily: 'var(--font-mono)', padding: '10px' }}
                autoFocus
                required
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{
                width: '100%',
                padding: '12px',
                fontSize: '0.92rem',
                fontWeight: '800',
                background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px'
              }}
              disabled={loading}
            >
              {loading ? 'Connexion...' : <><LogIn size={18} /> Entrer en Salle d’Examen</>}
            </button>
          </form>
        ) : (
          <form onSubmit={handleStaffSubmit}>
            <div className="form-group" style={{ marginBottom: '16px' }}>
              <label htmlFor="staffEmail" style={{ fontSize: '0.84rem', color: '#cbd5e1', marginBottom: '6px', display: 'block' }}>
                Adresse E-mail ({activeRoleObj.label})
              </label>
              <input
                id="staffEmail"
                type="email"
                className="form-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                style={{ fontSize: '0.9rem', padding: '10px 14px' }}
              />
            </div>

            <div className="form-group" style={{ marginBottom: '22px' }}>
              <label htmlFor="staffPassword" style={{ fontSize: '0.84rem', color: '#cbd5e1', marginBottom: '6px', display: 'block' }}>
                Mot de passe
              </label>
              <input
                id="staffPassword"
                type="password"
                className="form-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                style={{ fontSize: '0.9rem', padding: '10px 14px' }}
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{
                width: '100%',
                padding: '12px',
                fontSize: '0.92rem',
                fontWeight: '800',
                background: `linear-gradient(135deg, ${activeRoleObj.color} 0%, ${activeRoleObj.color}cc 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px'
              }}
              disabled={loading}
            >
              {loading ? (
                'Connexion en cours...'
              ) : (
                <>
                  <LogIn size={18} /> Se Connecter ({activeRoleObj.label})
                </>
              )}
            </button>

            {/* Quick credentials box */}
            <div style={{
              marginTop: '18px',
              padding: '10px 14px',
              borderRadius: '8px',
              background: 'rgba(30, 41, 59, 0.5)',
              border: '1px solid rgba(255, 255, 255, 0.05)',
              fontSize: '0.78rem',
              color: '#94a3b8',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <div>Compte : <strong style={{ color: '#fff' }}>{email}</strong></div>
              <div>Mot de passe : <strong style={{ color: '#34d399' }}>admin123</strong></div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
