#!/bin/bash

# ==============================================================================
# AlgoExamination — Launch & Health Check Management Script
# ==============================================================================

# Ensure Node v20 is in PATH
export PATH=/home/adel/.local/node-v20/bin:$PATH

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVER_DIR="$ROOT_DIR/server"
CLIENT_DIR="$ROOT_DIR/client"

PID_DIR="$ROOT_DIR/.pids"
LOG_DIR="$ROOT_DIR/.logs"

mkdir -p "$PID_DIR" "$LOG_DIR"

SERVER_PID_FILE="$PID_DIR/server.pid"
STUDENT_PID_FILE="$PID_DIR/student.pid"
STAFF_PID_FILE="$PID_DIR/staff.pid"
ALGOCOMPILER_PID_FILE="$PID_DIR/algocompiler.pid"

SERVER_LOG="$LOG_DIR/server.log"
STUDENT_LOG="$LOG_DIR/student.log"
STAFF_LOG="$LOG_DIR/staff.log"
ALGOCOMPILER_LOG="$LOG_DIR/algocompiler.log"

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

check_health() {
    local url=$1
    local name=$2

    if curl -sf "$url" > /dev/null 2>&1; then
        echo -e "${GREEN}✔ ONLINE${NC} — $name ($url)"
        return 0
    else
        echo -e "${RED}✖ OFFLINE${NC} — $name ($url)"
        return 1
    fi
}

start_services() {
    echo -e "${CYAN}=====================================================${NC}"
    echo -e "${CYAN}  Launching AlgoExamination Platform Services...      ${NC}"
    echo -e "${CYAN}=====================================================${NC}"

    export PATH=/home/adel/.local/node-v20/bin:$PATH

    # 1. Start Backend Server (Port 4000)
    echo -n "Starting Backend Express Server (Port 4000)... "
    pkill -9 -f "node src/index.js" > /dev/null 2>&1 || true
    pkill -9 -f nodemon > /dev/null 2>&1 || true
    fuser -k 4000/tcp > /dev/null 2>&1 || true
    cd "$SERVER_DIR" && setsid node src/index.js > "$SERVER_LOG" 2>&1 &
    SERVER_PID=$!
    echo $SERVER_PID > "$SERVER_PID_FILE"
    echo -e "${GREEN}Started (PID: $SERVER_PID)${NC}"

    # 2. Start Student Portal (Port 5174) — 100% Isolated for Candidates
    echo -n "Starting Student Portal (Port 5174)... "
    pkill -f "vite.*5174" > /dev/null 2>&1 || true
    cd "$CLIENT_DIR" && setsid npm run dev:student > "$STUDENT_LOG" 2>&1 &
    echo $! > "$STUDENT_PID_FILE"
    echo -e "${GREEN}Started (PID: $(cat "$STUDENT_PID_FILE"))${NC}"

    # 3. Start Staff Portal (Port 5175) — 100% Isolated for Staff (Teacher / Proctor / Admin)
    echo -n "Starting Staff Portal (Port 5175)... "
    pkill -f "vite.*5175" > /dev/null 2>&1 || true
    cd "$CLIENT_DIR" && setsid npm run dev:staff > "$STAFF_LOG" 2>&1 &
    echo $! > "$STAFF_PID_FILE"
    echo -e "${GREEN}Started (PID: $(cat "$STAFF_PID_FILE"))${NC}"

    # 4. Start AlgoCompiler Standalone Web Application (Port 5000)
    ALGO_COMPILER_DIR="$(cd "$ROOT_DIR/../AlgoCompiler" && pwd)"
    echo -n "Starting AlgoCompiler Web Application (Port 5000)... "
    if pgrep -f "python3.*src/web/app.py" > /dev/null; then
        echo -e "${YELLOW}Already running.${NC}"
    else
        cd "$ALGO_COMPILER_DIR"
        if [ -f "AlgoCompiler.env" ]; then
            export $(grep -v '^#' AlgoCompiler.env | xargs)
        fi
        ./venv/bin/python src/web/app.py > "$ALGOCOMPILER_LOG" 2>&1 &
        echo $! > "$ALGOCOMPILER_PID_FILE"
        echo -e "${GREEN}Started (PID: $(cat "$ALGOCOMPILER_PID_FILE"))${NC}"
    fi

    echo -e "\nWaiting 4 seconds for services to initialize..."
    sleep 4

    verify_status
}

verify_status() {
    echo -e "\n${CYAN}=====================================================${NC}"
    echo -e "${CYAN}  Performing Health & Connectivity Checks...         ${NC}"
    echo -e "${CYAN}=====================================================${NC}"

    check_health "http://localhost:4000/health" "Backend Express API"
    check_health "http://localhost:5174" "Portail Candidats / Étudiant (Port 5174)"
    check_health "http://localhost:5175" "Portail Personnel / Staff (Port 5175)"
    check_health "http://localhost:5000" "AlgoCompiler Standalone Web App (Port 5000)"

    echo -e "\n${BLUE}🎓 AlgoExamination Dedicated Portals:${NC}"
    echo -e "   👨‍🎓 PORTAIL ÉTUDIANT (Port 5174) :   ${GREEN}http://localhost:5174${NC} (100% Candidat - Code Anonyme)"
    echo -e "   👥 PORTAIL PERSONNEL (Port 5175) :  ${GREEN}http://localhost:5175${NC} (Enseignant / Surveillance / Admin)"
    echo -e "      • Enseignant    : teacher@esi.dz / admin123"
    echo -e "      • Surveillance  : surveillance@esi.dz / admin123"
    echo -e "      • Administration: admin@esi.dz / admin123"
    echo -e "   💻 AlgoCompiler Web App :           ${GREEN}http://localhost:5000${NC}"
    echo -e "   ⚙️  Backend Health API :             ${GREEN}http://localhost:4000/health${NC}"
    echo -e "${CYAN}=====================================================${NC}\n"
}

stop_services() {
    echo -e "${YELLOW}Stopping all platform services...${NC}"

    pkill -f "node.*server/src/index.js" && echo "Backend server stopped."
    pkill -f "vite" && echo "Vite client stopped."
    pkill -f "python3.*src/web/app.py" && echo "AlgoCompiler web app (5000) stopped."

    rm -rf "$PID_DIR"/*.pid
    echo -e "${GREEN}All services stopped cleanly.${NC}"
}

case "$1" in
    start)
        start_services
        ;;
    status|check)
        verify_status
        ;;
    stop)
        stop_services
        ;;
    restart)
        stop_services
        sleep 2
        start_services
        ;;
    *)
        start_services
        ;;
esac
