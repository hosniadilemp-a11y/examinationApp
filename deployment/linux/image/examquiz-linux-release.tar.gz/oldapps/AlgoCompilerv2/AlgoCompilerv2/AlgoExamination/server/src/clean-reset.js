const prisma = require('./prisma');
const bcrypt = require('bcryptjs');

async function cleanReset() {
  console.log('Purging all exam data and submissions from the database...');

  // 1. Delete all exam-related transactional data
  try {
    await prisma.submission.deleteMany({});
    console.log('✔ Submissions deleted.');
  } catch (e) { console.log('Submissions:', e.message); }

  try {
    await prisma.monitoringEvent.deleteMany({});
    console.log('✔ Monitoring events deleted.');
  } catch (e) { console.log('MonitoringEvents:', e.message); }

  try {
    await prisma.announcement.deleteMany({});
    console.log('✔ Announcements deleted.');
  } catch (e) { console.log('Announcements:', e.message); }

  try {
    await prisma.incident.deleteMany({});
    console.log('✔ Incidents deleted.');
  } catch (e) { console.log('Incidents:', e.message); }

  try {
    await prisma.examAssignment.deleteMany({});
    console.log('✔ Exam assignments deleted.');
  } catch (e) { console.log('ExamAssignments:', e.message); }

  try {
    await prisma.examProblem.deleteMany({});
    console.log('✔ Exam problem mappings deleted.');
  } catch (e) { console.log('ExamProblems:', e.message); }

  try {
    await prisma.exam.deleteMany({});
    console.log('✔ All exams deleted.');
  } catch (e) { console.log('Exams:', e.message); }

  // 2. Ensure default staff accounts for all 3 portals exist
  const defaultPassword = await bcrypt.hash('admin123', 10);
  const staff = [
    { email: 'teacher@esi.dz', name: 'Prof. Enseignant ASD', role: 'TEACHER' },
    { email: 'teacher@algoexam.edu', name: 'Prof. Enseignant ASD', role: 'TEACHER' },
    { email: 'surveillance@esi.dz', name: 'Surveillant de Salle', role: 'PROCTOR' },
    { email: 'proctor@algoexam.edu', name: 'Surveillant de Salle', role: 'PROCTOR' },
    { email: 'admin@esi.dz', name: 'Administration & Scolarité', role: 'ADMIN' },
    { email: 'admin@algoexam.edu', name: 'Administration & Scolarité', role: 'ADMIN' },
  ];

  for (const s of staff) {
    await prisma.teacher.upsert({
      where: { email: s.email },
      update: { role: s.role, name: s.name, password: defaultPassword },
      create: {
        email: s.email,
        name: s.name,
        role: s.role,
        password: defaultPassword
      }
    });
  }

  console.log('✔ Default staff accounts initialized:');
  console.log('   - Enseignant   : teacher@esi.dz / admin123');
  console.log('   - Surveillance : surveillance@esi.dz / admin123');
  console.log('   - Administration: admin@esi.dz / admin123');
  console.log('\nDatabase is clean and ready for fresh exams!');
}

cleanReset()
  .catch(e => {
    console.error('Clean reset error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
