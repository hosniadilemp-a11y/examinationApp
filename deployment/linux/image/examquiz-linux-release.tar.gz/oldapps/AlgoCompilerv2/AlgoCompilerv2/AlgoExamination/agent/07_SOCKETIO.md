# AlgoExamination — Socket.IO Contract

## Rooms

### Teacher Room

```text
exam_${examId}
```

Receives:
- exam status
- student status
- monitoring events
- export progress

### Student Room

```text
student_${studentId}
```

Receives targeted commands.

## Event Contract

| Event | Room | Purpose |
|---|---|---|
| `exam_status_changed` | exam room | exam lifecycle |
| `exam_started` | exam room | launch |
| `exam_force_ended` | exam room | force completion |
| `student_status_changed` | exam room | teacher dashboard |
| `live_monitoring_event` | exam room | violation/activity |
| `pdf_zip_progress` | exam room | export progress |
| `student_locked` | student room | lock workspace |
| `student_unlocked` | student room | resume workspace |
| `student_terminated` | student room | terminate workspace |
| `student_fullscreen_warning` | student room | warning |

## Event Design Rules

### 1. Do not rename events casually

Event names are contracts between:
- server
- teacher client
- student client

Search all emit/listener occurrences before changing one.

### 2. Payload compatibility

When adding payload fields:
- preserve existing fields
- avoid changing field types
- update all consumers

### 3. Room correctness

Before emitting:
- verify `examId`
- verify `studentId`
- verify the event belongs to the correct room

A student-specific event must never accidentally be broadcast to every student.

### 4. Reconnection

Socket clients should recover subscriptions after reconnect.

Do not assume a reconnect automatically restores application-level room membership.

### 5. Idempotency

Important commands may arrive more than once.

Student UI should safely handle repeated:
- lock
- unlock
- terminate

without corrupting state.

## Debugging

When real-time behavior fails, inspect in this order:

1. server emitted event?
2. correct room?
3. client connected?
4. client joined room?
5. listener registered?
6. payload shape correct?
7. React state update executed?
8. HTTP fallback recovers state?

Do not immediately rewrite the socket layer.
