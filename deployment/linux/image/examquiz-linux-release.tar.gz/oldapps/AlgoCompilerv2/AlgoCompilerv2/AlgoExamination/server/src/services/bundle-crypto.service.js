const crypto = require('crypto');
const prisma = require('../prisma');
const { withRetry } = require('../prisma');

const TEMPLATE_MAGIC = 'ALGO_EXAM_TEMPLATE_V1';
const BUNDLE_MAGIC = 'ALGO_EXAM_BUNDLE_V1';
const RESULTS_MAGIC = 'ALGO_EXAM_RESULTS_V1';
const PBKDF2_ITERATIONS = 100000;
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 12;  // 96 bits for GCM
const SALT_LENGTH = 16;
const DIGEST = 'sha256';

const DEFAULT_MASTER_KEY = process.env.ALGO_BUNDLE_MASTER_KEY || 'ALGO_EXAM_SYSTEM_VAULT_KEY_2026_@ESI';

/**
 * Derives a 256-bit encryption key from a passphrase and salt using PBKDF2.
 */
function deriveKey(passphrase, salt) {
  return crypto.pbkdf2Sync(passphrase, salt, PBKDF2_ITERATIONS, KEY_LENGTH, DIGEST);
}

/**
 * Encrypts a plain JavaScript object using AES-256-GCM.
 * Returns an encrypted envelope object.
 * If passphrase is not provided, defaults to the internal system vault key.
 */
function encryptData(dataObj, passphrase, magic = BUNDLE_MAGIC) {
  const effectivePassphrase = (passphrase && typeof passphrase === 'string' && passphrase.trim().length > 0)
    ? passphrase.trim()
    : DEFAULT_MASTER_KEY;

  const jsonString = JSON.stringify(dataObj);
  const dataChecksum = crypto.createHash('sha256').update(jsonString, 'utf8').digest('hex');

  const salt = crypto.randomBytes(SALT_LENGTH);
  const iv = crypto.randomBytes(IV_LENGTH);
  const key = deriveKey(effectivePassphrase, salt);

  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  let ciphertext = cipher.update(jsonString, 'utf8', 'base64');
  ciphertext += cipher.final('base64');
  const authTag = cipher.getAuthTag();

  return {
    magic,
    version: '1.0.0',
    kdf: 'pbkdf2',
    iterations: PBKDF2_ITERATIONS,
    salt: salt.toString('hex'),
    iv: iv.toString('hex'),
    authTag: authTag.toString('hex'),
    checksum: dataChecksum,
    ciphertext,
    exportedAt: new Date().toISOString()
  };
}

/**
 * Robustly parses a Buffer into a JavaScript object, stripping BOMs,
 * handling UTF-8 / UTF-16LE / UTF-16BE / Base64, and removing null bytes/whitespace.
 */
function safeParseBufferToJSON(buffer) {
  if (!buffer || buffer.length === 0) {
    throw new Error('Le fichier est vide.');
  }

  // 1. Detect and handle UTF-16 LE (0xFF 0xFE)
  if (buffer.length >= 2 && buffer[0] === 0xFF && buffer[1] === 0xFE) {
    let str = buffer.toString('utf16le');
    if (str.charCodeAt(0) === 0xFEFF) str = str.slice(1);
    return JSON.parse(str.trim());
  }

  // 2. Detect and handle UTF-16 BE (0xFE 0xFF)
  if (buffer.length >= 2 && buffer[0] === 0xFE && buffer[1] === 0xFF) {
    let str = buffer.swap16().toString('utf16le');
    if (str.charCodeAt(0) === 0xFEFF) str = str.slice(1);
    return JSON.parse(str.trim());
  }

  // 3. UTF-8 (default)
  let str = buffer.toString('utf8');

  // Strip UTF-8 BOM if present (0xEF 0xBB 0xBF -> \uFEFF)
  if (str.charCodeAt(0) === 0xFEFF) {
    str = str.slice(1);
  }

  // Clean trailing/leading null bytes, unprintable control chars, whitespaces
  str = str.replace(/^[\x00-\x1F\x7F-\x9F]+/, '').replace(/[\x00-\x1F\x7F-\x9F]+$/, '').trim();
  str = str.replace(/^\uFEFF+/, '').trim();

  try {
    return JSON.parse(str);
  } catch (err) {
    // If standard JSON.parse fails, try decoding as base64 in case the file was base64 encoded
    try {
      const decodedBase64 = Buffer.from(str, 'base64').toString('utf8');
      const cleanB64 = decodedBase64.replace(/^\uFEFF+/, '').trim();
      if (cleanB64.startsWith('{') || cleanB64.startsWith('[')) {
        return JSON.parse(cleanB64);
      }
    } catch (_) {}

    // If double encoded / quoted JSON string
    if (str.startsWith('"') && str.endsWith('"')) {
      try {
        const unescaped = JSON.parse(str);
        if (typeof unescaped === 'string') {
          return JSON.parse(unescaped);
        }
      } catch (_) {}
    }

    throw err;
  }
}

/**
 * Robustly parses a string into a JavaScript object, stripping BOMs and control characters.
 */
function safeParseStringToJSON(str) {
  if (!str) return str;
  if (typeof str !== 'string') return str;
  let clean = str.replace(/^\uFEFF+/, '').replace(/^[\x00-\x1F\x7F-\x9F]+/, '').replace(/[\x00-\x1F\x7F-\x9F]+$/, '').trim();
  try {
    return JSON.parse(clean);
  } catch (err) {
    try {
      const decodedBase64 = Buffer.from(clean, 'base64').toString('utf8');
      const cleanB64 = decodedBase64.replace(/^\uFEFF+/, '').trim();
      if (cleanB64.startsWith('{') || cleanB64.startsWith('[')) {
        return JSON.parse(cleanB64);
      }
    } catch (_) {}
    throw err;
  }
}

/**
 * Decrypts an envelope object using AES-256-GCM and returns the original JavaScript object.
 * First tries the provided passphrase; automatically falls back to DEFAULT_MASTER_KEY.
 */
function decryptData(envelope, passphrase) {
  if (typeof envelope === 'string') {
    try {
      envelope = safeParseStringToJSON(envelope);
    } catch (e) {
      throw new Error('Fichier de paquet invalide ou corrompu.');
    }
  }

  if (!envelope || !envelope.ciphertext || !envelope.salt || !envelope.iv || !envelope.authTag) {
    throw new Error('Fichier de paquet invalide ou corrompu.');
  }

  const keysToTry = [];
  if (passphrase && typeof passphrase === 'string' && passphrase.trim().length > 0) {
    keysToTry.push(passphrase.trim());
  }
  if (!keysToTry.includes(DEFAULT_MASTER_KEY)) {
    keysToTry.push(DEFAULT_MASTER_KEY);
  }

  for (const keyCandidate of keysToTry) {
    try {
      const salt = Buffer.from(envelope.salt.trim(), 'hex');
      const iv = Buffer.from(envelope.iv.trim(), 'hex');
      const authTag = Buffer.from(envelope.authTag.trim(), 'hex');
      const key = deriveKey(keyCandidate, salt);

      const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
      decipher.setAuthTag(authTag);

      let decrypted = decipher.update(envelope.ciphertext.trim(), 'base64', 'utf8');
      decrypted += decipher.final('utf8');

      if (decrypted.charCodeAt(0) === 0xFEFF) {
        decrypted = decrypted.slice(1);
      }
      decrypted = decrypted.trim();

      // Verify Checksum
      const calculatedChecksum = crypto.createHash('sha256').update(decrypted, 'utf8').digest('hex');
      if (envelope.checksum && envelope.checksum !== calculatedChecksum) {
        throw new Error("Erreur d'intégrité : l'empreinte du paquet déchiffré ne correspond pas.");
      }

      return JSON.parse(decrypted);
    } catch (err) {
      // Continue to next key candidate if any
    }
  }

  throw new Error('Mot de passe incorrect ou fichier altéré.');
}

/**
 * Builds and encrypts an Exam Template (.algoexam)
 */
async function buildEncryptedExamTemplate(examId, passphrase) {
  const exam = await withRetry(() => prisma.exam.findUnique({
    where: { id: examId },
    include: {
      problems: {
        orderBy: { orderIndex: 'asc' },
        include: {
          problem: {
            include: {
              questions: { orderBy: { orderIndex: 'asc' } },
              testCases: true
            }
          }
        }
      }
    }
  }));

  if (!exam) {
    throw new Error('Modèle d\'examen non trouvé.');
  }

  const templatePayload = {
    bundleType: 'EXAM_TEMPLATE',
    format: 'ALGO_EXAM_TEMPLATE_V1',
    exportedAt: new Date().toISOString(),
    exam: {
      examCode: exam.examCode,
      title: exam.title,
      description: exam.description,
      university: exam.university,
      module: exam.module,
      session: exam.session,
      durationMinutes: exam.durationMinutes,
      prefix: exam.prefix,
      maxViolationsAllowed: exam.maxViolationsAllowed,
      copyDisabled: exam.copyDisabled,
      pasteDisabled: exam.pasteDisabled,
      fullscreenRequired: exam.fullscreenRequired,
      internetWarning: exam.internetWarning,
      allowCodeBricks: exam.allowCodeBricks,
      allowedBricks: exam.allowedBricks,
      allowedLanguages: exam.allowedLanguages,
      problems: exam.problems.map((ep, idx) => ({
        orderIndex: ep.orderIndex || idx + 1,
        points: ep.points,
        weightTest: ep.weightTest,
        weightAst: ep.weightAst,
        weightAi: ep.weightAi,
        questionPoints: ep.questionPoints,
        problem: {
          id: ep.problem.id,
          title: ep.problem.title,
          description: ep.problem.description,
          topic: ep.problem.topic,
          difficulty: ep.problem.difficulty,
          tags: ep.problem.tags,
          points: ep.problem.points,
          starterTemplate: ep.problem.starterTemplate,
          referenceSolution: ep.problem.referenceSolution,
          questions: (ep.problem.questions || []).map(q => ({
            orderIndex: q.orderIndex,
            statement: q.statement,
            description: q.description,
            points: q.points,
            initialCode: q.initialCode
          })),
          testCases: (ep.problem.testCases || []).map(tc => ({
            inputData: tc.inputData,
            expectedOutput: tc.expectedOutput,
            isPublic: tc.isPublic !== undefined ? tc.isPublic : (!tc.isHidden),
            points: tc.points
          }))
        }
      }))
    }
  };

  return encryptData(templatePayload, passphrase, TEMPLATE_MAGIC);
}

/**
 * Builds and encrypts a complete Exam Submission Bundle (.algobundle)
 */
async function buildEncryptedSubmissionBundle(examId, passphrase) {
  const exam = await withRetry(() => prisma.exam.findUnique({
    where: { id: examId },
    include: {
      problems: {
        orderBy: { orderIndex: 'asc' },
        include: {
          problem: {
            include: {
              testCases: true,
              questions: { orderBy: { orderIndex: 'asc' } }
            }
          }
        }
      },
      assignments: {
        include: {
          student: true
        }
      }
    }
  }));

  if (!exam) {
    throw new Error('Examen non trouvé.');
  }

  const submissions = await withRetry(() => prisma.submission.findMany({
    where: { examId },
    orderBy: { createdAt: 'asc' }
  }));

  const bundlePayload = {
    bundleType: 'SUBMISSION_BUNDLE',
    exam: {
      id: exam.id,
      examCode: exam.examCode,
      room: exam.room,
      title: exam.title,
      description: exam.description,
      university: exam.university,
      module: exam.module,
      session: exam.session,
      prefix: exam.prefix,
      durationMinutes: exam.durationMinutes,
      maxViolationsAllowed: exam.maxViolationsAllowed,
      allowedLanguages: exam.allowedLanguages,
      allowedBricks: exam.allowedBricks,
      problems: exam.problems.map(ep => ({
        examProblemId: ep.id,
        problemId: ep.problemId,
        orderIndex: ep.orderIndex,
        points: ep.points,
        weightTest: ep.weightTest,
        weightAst: ep.weightAst,
        weightAi: ep.weightAi,
        questionPoints: ep.questionPoints,
        problem: ep.problem
      }))
    },
    assignments: exam.assignments.map(asgn => ({
      id: asgn.id,
      studentId: asgn.studentId,
      room: asgn.room || exam.room,
      accessNumber: asgn.accessNumber,
      status: asgn.status,
      loginTime: asgn.loginTime,
      startedAt: asgn.startedAt,
      finishedAt: asgn.finishedAt,
      violations: asgn.violations,
      fullscreenExits: asgn.fullscreenExits,
      currentCodeMap: asgn.currentCodeMap,
      finalScore: asgn.finalScore,
      gradingStatus: asgn.gradingStatus,
      generalFeedback: asgn.generalFeedback,
      student: asgn.student ? {
        id: asgn.student.id,
        studentId: asgn.student.studentId,
        firstName: asgn.student.firstName,
        lastName: asgn.student.lastName,
        group: asgn.student.group,
        speciality: asgn.student.speciality,
        academicYear: asgn.student.academicYear
      } : null
    })),
    submissions: submissions.map(sub => ({
      id: sub.id,
      studentId: sub.studentId,
      problemId: sub.problemId,
      language: sub.language,
      sourceCode: sub.sourceCode,
      status: sub.status,
      score: sub.score,
      passedTests: sub.passedTests,
      totalTests: sub.totalTests,
      manualScore: sub.manualScore,
      teacherFeedback: sub.teacherFeedback,
      rubricScores: sub.rubricScores,
      createdAt: sub.createdAt,
      gradedAt: sub.gradedAt
    }))
  };

  return encryptData(bundlePayload, passphrase, BUNDLE_MAGIC);
}

/**
 * Merges one or more decrypted bundles into the target Exam database.
 * Deduplicates and resolves submission conflicts using the latest timestamp.
 */
async function mergeSubmissionsIntoExam(examId, decryptedBundles) {
  const targetExam = await withRetry(() => prisma.exam.findUnique({
    where: { id: examId },
    include: {
      assignments: { include: { student: true } },
      problems: { include: { problem: true } }
    }
  }));

  if (!targetExam) {
    throw new Error('Examen cible non trouvé.');
  }

  let totalStudentsImported = 0;
  let totalSubmissionsImported = 0;
  let totalSubmissionsUpdated = 0;

  for (const bundle of decryptedBundles) {
    if (!bundle || (!bundle.assignments && !bundle.submissions)) continue;

    // Exam Compatibility Validation
    if (bundle.exam) {
      const bCode = (bundle.exam.examCode || '').trim();
      const tCode = (targetExam.examCode || '').trim();
      const bTitle = (bundle.exam.title || '').trim().toLowerCase();
      const tTitle = (targetExam.title || '').trim().toLowerCase();

      // If both have exam codes and they differ -> STRICT REJECTION
      if (bCode && tCode && bCode !== tCode) {
        throw new Error(`Fusion Impossible (Codes d'Épreuve Différents) : Le paquet importé appartient au code [${bCode}], alors que l'épreuve cible a pour code [${tCode}]. La fusion est strictement réservée aux différentes salles d'un même examen.`);
      }

      // If no codes present and titles differ -> REJECTION
      if (!bCode && !tCode && bTitle && tTitle && bTitle !== tTitle) {
        throw new Error(`Incompatibilité d'épreuve : Ce paquet appartient à l'épreuve "${bundle.exam.title}", qui est différente de "${targetExam.title}".`);
      }
    }

    // Build Problem ID Map (Foreign Problem ID -> Target Problem ID)
    const probIdMap = {};
    if (bundle.exam && Array.isArray(bundle.exam.problems)) {
      for (const inEp of bundle.exam.problems) {
        const inProb = inEp.problem || inEp;
        const inTitle = (inProb.title || '').trim().toLowerCase();
        const matchingTargetEp = targetExam.problems.find(tep => {
          const tTitle = ((tep.problem && tep.problem.title) || '').trim().toLowerCase();
          return (inTitle && tTitle && inTitle === tTitle)
            || (inEp.orderIndex && tep.orderIndex === inEp.orderIndex)
            || (tep.problemId === (inEp.problemId || inProb.id));
        });
        if (matchingTargetEp) {
          if (inEp.problemId) probIdMap[inEp.problemId] = matchingTargetEp.problemId;
          if (inProb.id) probIdMap[inProb.id] = matchingTargetEp.problemId;
          if (inEp.examProblemId) probIdMap[inEp.examProblemId] = matchingTargetEp.problemId;
        }
      }
    }

    const incomingAssignments = bundle.assignments || [];
    const incomingSubmissions = bundle.submissions || [];

    // 1. Process Students & Assignments
    for (const inAsgn of incomingAssignments) {
      if (!inAsgn.student && !inAsgn.accessNumber) continue;

      let targetStudentId = inAsgn.studentId;

      // Find or create student in local database by studentId matricule
      if (inAsgn.student && inAsgn.student.studentId) {
        const studentMatricule = String(inAsgn.student.studentId).trim();
        let existingStudent = await prisma.student.findUnique({
          where: { studentId: studentMatricule }
        });

        if (!existingStudent) {
          existingStudent = await prisma.student.create({
            data: {
              studentId: studentMatricule,
              firstName: inAsgn.student.firstName || 'Étudiant',
              lastName: inAsgn.student.lastName || inAsgn.accessNumber,
              group: inAsgn.student.group || 'G01',
              speciality: inAsgn.student.speciality || '1CP',
              academicYear: inAsgn.student.academicYear || 2026
            }
          });
        }
        targetStudentId = existingStudent.id;
      }

      // Remap currentCodeMap keys with local problem IDs
      const rawIncomingCodeMap = inAsgn.currentCodeMap || {};
      const remappedCodeMap = {};
      if (typeof rawIncomingCodeMap === 'object' && rawIncomingCodeMap !== null) {
        for (const [k, v] of Object.entries(rawIncomingCodeMap)) {
          const mappedKey = probIdMap[k] || k;
          remappedCodeMap[mappedKey] = v;
        }
      }

      // Upsert ExamAssignment
      if (targetStudentId) {
        const existingAsgn = await prisma.examAssignment.findUnique({
          where: { examId_studentId: { examId, studentId: targetStudentId } }
        });

        const accessNum = inAsgn.accessNumber || '';
        const matchS = accessNum.match(/^S(\d+)-/i);
        const matchSA = accessNum.match(/^SA(\d+)-/i);
        const inferredRoom = inAsgn.room || (matchS ? `Salle ${matchS[1]}` : null) || (matchSA ? `Salle A${matchSA[1]}` : null) || targetExam.room;

        if (!existingAsgn) {
          await prisma.examAssignment.create({
            data: {
              examId,
              studentId: targetStudentId,
              room: inferredRoom,
              accessNumber: inAsgn.accessNumber || `${targetExam.prefix}-${String(Math.floor(100 + Math.random() * 900))}`,
              status: inAsgn.status || 'FINISHED',
              startedAt: inAsgn.startedAt ? new Date(inAsgn.startedAt) : new Date(),
              finishedAt: inAsgn.finishedAt ? new Date(inAsgn.finishedAt) : new Date(),
              currentCodeMap: remappedCodeMap,
              violations: inAsgn.violations || 0,
              fullscreenExits: inAsgn.fullscreenExits || 0,
              finalScore: inAsgn.finalScore !== undefined ? inAsgn.finalScore : null,
              gradingStatus: inAsgn.gradingStatus || 'UNGRADED',
              generalFeedback: inAsgn.generalFeedback || null
            }
          });
          totalStudentsImported++;
        } else {
          // Update codeMap if incoming has newer content
          const currentCodeMap = existingAsgn.currentCodeMap || {};
          const mergedCodeMap = {
            ...(typeof currentCodeMap === 'object' ? currentCodeMap : {}),
            ...remappedCodeMap
          };

          await prisma.examAssignment.update({
            where: { id: existingAsgn.id },
            data: {
              room: existingAsgn.room || inferredRoom,
              currentCodeMap: mergedCodeMap,
              status: inAsgn.status === 'FINISHED' ? 'FINISHED' : existingAsgn.status,
              finishedAt: inAsgn.finishedAt ? new Date(inAsgn.finishedAt) : existingAsgn.finishedAt
            }
          });
        }
      }
    }

    // 2. Process Submissions (Latest Timestamp Wins)
    for (const inSub of incomingSubmissions) {
      if (!inSub.problemId || (!inSub.studentId && !inSub.accessNumber)) continue;

      const targetProblemId = probIdMap[inSub.problemId] || inSub.problemId;

      let targetStudentId = inSub.studentId;
      if (!targetStudentId && inSub.accessNumber) {
        const matchingAsgn = await prisma.examAssignment.findFirst({
          where: { examId, accessNumber: inSub.accessNumber }
        });
        if (matchingAsgn) targetStudentId = matchingAsgn.studentId;
      }

      if (!targetStudentId) continue;

      const existingSub = await prisma.submission.findFirst({
        where: {
          examId,
          studentId: targetStudentId,
          problemId: targetProblemId
        }
      });

      const incomingCreatedAt = inSub.createdAt ? new Date(inSub.createdAt) : new Date();

      if (!existingSub) {
        await prisma.submission.create({
          data: {
            examId,
            studentId: targetStudentId,
            problemId: targetProblemId,
            language: inSub.language || 'ALGO',
            sourceCode: inSub.sourceCode || '',
            status: inSub.status || 'PENDING_MANUAL',
            score: inSub.score || 0,
            passedTests: inSub.passedTests || 0,
            totalTests: inSub.totalTests || 0,
            manualScore: inSub.manualScore !== undefined ? inSub.manualScore : null,
            teacherFeedback: inSub.teacherFeedback || null,
            rubricScores: inSub.rubricScores || null,
            createdAt: incomingCreatedAt,
            gradedAt: inSub.gradedAt ? new Date(inSub.gradedAt) : null
          }
        });
        totalSubmissionsImported++;
      } else {
        // Compare Timestamps: If incoming is newer, update code
        const existingCreatedAt = new Date(existingSub.createdAt);
        if (incomingCreatedAt >= existingCreatedAt) {
          await prisma.submission.update({
            where: { id: existingSub.id },
            data: {
              sourceCode: inSub.sourceCode || existingSub.sourceCode,
              passedTests: inSub.passedTests !== undefined ? inSub.passedTests : existingSub.passedTests,
              totalTests: inSub.totalTests !== undefined ? inSub.totalTests : existingSub.totalTests,
              score: inSub.score !== undefined ? inSub.score : existingSub.score,
              manualScore: inSub.manualScore !== undefined ? inSub.manualScore : existingSub.manualScore,
              teacherFeedback: inSub.teacherFeedback || existingSub.teacherFeedback,
              rubricScores: inSub.rubricScores || existingSub.rubricScores,
              createdAt: incomingCreatedAt
            }
          });
          totalSubmissionsUpdated++;
        }
      }
    }
  }

  return {
    success: true,
    totalStudentsImported,
    totalSubmissionsImported,
    totalSubmissionsUpdated
  };
}

/**
 * Builds and encrypts a Corrected Results Bundle (.algoresults)
 */
async function buildEncryptedResultsBundle(examId, passphrase) {
  const exam = await withRetry(() => prisma.exam.findUnique({
    where: { id: examId },
    include: {
      problems: {
        orderBy: { orderIndex: 'asc' },
        include: { problem: true }
      },
      assignments: {
        include: { student: true },
        orderBy: { accessNumber: 'asc' }
      }
    }
  }));

  if (!exam) {
    throw new Error('Examen non trouvé.');
  }

  const submissions = await withRetry(() => prisma.submission.findMany({
    where: { examId },
    orderBy: { createdAt: 'asc' }
  }));

  const resultsPayload = {
    bundleType: 'CORRECTED_RESULTS_BUNDLE',
    exam: {
      id: exam.id,
      examCode: exam.examCode,
      title: exam.title,
      description: exam.description,
      university: exam.university,
      module: exam.module,
      session: exam.session,
      prefix: exam.prefix,
      room: exam.room,
      durationMinutes: exam.durationMinutes,
      date: exam.date,
      problems: exam.problems.map(ep => ({
        id: ep.id,
        problemId: ep.problemId,
        title: ep.problem ? ep.problem.title : '',
        orderIndex: ep.orderIndex,
        points: ep.points,
        weightTest: ep.weightTest,
        weightAst: ep.weightAst,
        weightAi: ep.weightAi,
        questionPoints: ep.questionPoints,
        problem: ep.problem
      }))
    },
    students: exam.assignments.map(asgn => ({
      studentId: asgn.student ? asgn.student.studentId : asgn.studentId,
      firstName: asgn.student ? asgn.student.firstName : '',
      lastName: asgn.student ? asgn.student.lastName : '',
      group: asgn.student ? asgn.student.group : '',
      speciality: asgn.student ? asgn.student.speciality : '',
      academicYear: asgn.student ? asgn.student.academicYear : 2026,
      accessNumber: asgn.accessNumber,
      finalScore: asgn.finalScore,
      gradingStatus: asgn.gradingStatus,
      generalFeedback: asgn.generalFeedback,
      problemGrades: submissions
        .filter(s => s.studentId === asgn.studentId)
        .map(s => ({
          problemId: s.problemId,
          score: s.score,
          manualScore: s.manualScore,
          passedTests: s.passedTests,
          totalTests: s.totalTests,
          teacherFeedback: s.teacherFeedback,
          gradedAt: s.gradedAt
        }))
    }))
  };

  return encryptData(resultsPayload, passphrase, RESULTS_MAGIC);
}

/**
 * Merges one or more decrypted results bundles (.algoresults) into an exam in the database.
 */
async function mergeResultsIntoExam(targetExamId, decryptedResultsList) {
  const targetExam = await withRetry(() => prisma.exam.findUnique({
    where: { id: targetExamId },
    include: {
      problems: { include: { problem: true } },
      assignments: true
    }
  }));

  if (!targetExam) {
    throw new Error('Examen cible non trouvé.');
  }

  let totalStudentsSynchronized = 0;
  let totalGradesUpdated = 0;

  for (const bundle of decryptedResultsList) {
    if (!bundle || !bundle.students || !Array.isArray(bundle.students)) continue;

    // Exam Compatibility Validation
    if (bundle.exam) {
      const bCode = (bundle.exam.examCode || '').trim();
      const tCode = (targetExam.examCode || '').trim();
      const bTitle = (bundle.exam.title || '').trim().toLowerCase();
      const tTitle = (targetExam.title || '').trim().toLowerCase();

      // If both have exam codes and they differ -> STRICT REJECTION
      if (bCode && tCode && bCode !== tCode) {
        throw new Error(`Fusion Impossible (Codes d'Épreuve Différents) : Le paquet de résultats appartient au code [${bCode}], alors que l'épreuve sélectionnée a pour code [${tCode}].`);
      }

      // If no codes present and titles differ -> REJECTION
      if (!bCode && !tCode && bTitle && tTitle && bTitle !== tTitle) {
        throw new Error(`Incompatibilité d'épreuve : Ce paquet de résultats provient de l'épreuve "${bundle.exam.title}", différente de "${targetExam.title}".`);
      }
    }

    // Build Problem ID Map
    const probIdMap = {};
    if (bundle.exam && Array.isArray(bundle.exam.problems)) {
      for (const inEp of bundle.exam.problems) {
        const inProb = inEp.problem || inEp;
        const inTitle = (inProb.title || '').trim().toLowerCase();
        const matchingTargetEp = targetExam.problems.find(tep => {
          const tTitle = ((tep.problem && tep.problem.title) || '').trim().toLowerCase();
          return (inTitle && tTitle && inTitle === tTitle)
            || (inEp.orderIndex && tep.orderIndex === inEp.orderIndex)
            || (tep.problemId === (inEp.problemId || inProb.id));
        });
        if (matchingTargetEp) {
          if (inEp.problemId) probIdMap[inEp.problemId] = matchingTargetEp.problemId;
          if (inProb.id) probIdMap[inProb.id] = matchingTargetEp.problemId;
        }
      }
    }

    for (const sData of bundle.students) {
      if (!sData.studentId && !sData.accessNumber) continue;

      // Find or create student
      let student = null;
      if (sData.studentId) {
        student = await withRetry(() => prisma.student.findUnique({
          where: { studentId: sData.studentId }
        }));
      }

      if (!student && sData.studentId) {
        student = await withRetry(() => prisma.student.create({
          data: {
            studentId: sData.studentId,
            firstName: sData.firstName || 'Étudiant',
            lastName: sData.lastName || 'Importé',
            group: sData.group || 'G1',
            speciality: sData.speciality || 'INFO',
            academicYear: sData.academicYear || '2026/2027'
          }
        }));
      }

      if (!student) continue;

      // Find or create ExamAssignment
      let assignment = await withRetry(() => prisma.examAssignment.findFirst({
        where: {
          examId: targetExamId,
          studentId: student.id
        }
      }));

      if (!assignment) {
        assignment = await withRetry(() => prisma.examAssignment.create({
          data: {
            examId: targetExamId,
            studentId: student.id,
            accessNumber: sData.accessNumber || `AL-${String(totalStudentsSynchronized + 1).padStart(3, '0')}`,
            status: 'FINISHED',
            gradingStatus: sData.gradingStatus || 'GRADED',
            finalScore: sData.finalScore != null ? parseFloat(sData.finalScore) : null,
            generalFeedback: sData.generalFeedback || ''
          }
        }));
      } else {
        assignment = await withRetry(() => prisma.examAssignment.update({
          where: { id: assignment.id },
          data: {
            gradingStatus: sData.gradingStatus || 'GRADED',
            finalScore: sData.finalScore != null ? parseFloat(sData.finalScore) : assignment.finalScore,
            generalFeedback: sData.generalFeedback || assignment.generalFeedback
          }
        }));
      }

      totalStudentsSynchronized++;

      // Update problem grades / submissions
      if (sData.problemGrades && Array.isArray(sData.problemGrades)) {
        for (const pg of sData.problemGrades) {
          if (!pg.problemId) continue;

          const targetProblemId = probIdMap[pg.problemId] || pg.problemId;

          const existingSub = await withRetry(() => prisma.submission.findFirst({
            where: {
              examId: targetExamId,
              studentId: student.id,
              problemId: targetProblemId
            }
          }));

          if (existingSub) {
            await withRetry(() => prisma.submission.update({
              where: { id: existingSub.id },
              data: {
                status: 'GRADED',
                score: pg.score != null ? parseFloat(pg.score) : existingSub.score,
                manualScore: pg.manualScore != null ? parseFloat(pg.manualScore) : existingSub.manualScore,
                teacherFeedback: pg.teacherFeedback || existingSub.teacherFeedback,
                passedTests: pg.passedTests != null ? pg.passedTests : existingSub.passedTests,
                totalTests: pg.totalTests != null ? pg.totalTests : existingSub.totalTests,
                gradedAt: pg.gradedAt ? new Date(pg.gradedAt) : new Date()
              }
            }));
            totalGradesUpdated++;
          } else {
            await withRetry(() => prisma.submission.create({
              data: {
                examId: targetExamId,
                studentId: student.id,
                problemId: targetProblemId,
                language: 'ALGO',
                sourceCode: pg.sourceCode || '',
                status: 'GRADED',
                score: pg.score != null ? parseFloat(pg.score) : 0,
                manualScore: pg.manualScore != null ? parseFloat(pg.manualScore) : null,
                teacherFeedback: pg.teacherFeedback || null,
                passedTests: pg.passedTests != null ? pg.passedTests : 0,
                totalTests: pg.totalTests != null ? pg.totalTests : 0,
                gradedAt: pg.gradedAt ? new Date(pg.gradedAt) : new Date()
              }
            }));
            totalGradesUpdated++;
          }
        }
      }
    }
  }

  // Set the exam status to CLOSED so it is recognized as completely Corrigé
  await withRetry(() => prisma.exam.update({
    where: { id: targetExamId },
    data: { status: 'CLOSED' }
  }));

  return {
    totalStudentsSynchronized,
    totalGradesUpdated
  };
}

module.exports = {
  TEMPLATE_MAGIC,
  BUNDLE_MAGIC,
  RESULTS_MAGIC,
  encryptData,
  decryptData,
  safeParseBufferToJSON,
  safeParseStringToJSON,
  buildEncryptedExamTemplate,
  buildEncryptedSubmissionBundle,
  mergeSubmissionsIntoExam,
  buildEncryptedResultsBundle,
  mergeResultsIntoExam
};
