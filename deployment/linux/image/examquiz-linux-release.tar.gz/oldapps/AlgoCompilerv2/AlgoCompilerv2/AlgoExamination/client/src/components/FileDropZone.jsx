import React, { useState, useRef } from 'react';
import { UploadCloud, FileCheck, X, FileSpreadsheet, FileCode, Archive } from 'lucide-react';

export default function FileDropZone({
  onFileSelect,
  accept = '.csv,.algoexam,.algobundle,.algoresults,.json,.txt',
  multiple = false,
  label = 'Glissez & déposez votre fichier ici',
  hint = 'ou cliquez pour parcourir vos dossiers',
  icon: CustomIcon,
  selectedFile,
  selectedFiles = [],
  onClear,
  style = {}
}) {
  const [isDragOver, setIsDragOver] = useState(false);
  const inputRef = useRef(null);

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragOver) setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      if (multiple) {
        onFileSelect(Array.from(files));
      } else {
        onFileSelect(files[0]);
      }
    }
  };

  const handleInputChange = (e) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      if (multiple) {
        onFileSelect(Array.from(files));
      } else {
        onFileSelect(files[0]);
      }
    }
  };

  const hasFiles = multiple ? selectedFiles.length > 0 : !!selectedFile;

  const getFileIcon = (filename = '') => {
    const ext = filename.split('.').pop().toLowerCase();
    if (ext === 'csv' || ext === 'xlsx') return <FileSpreadsheet size={28} color="#34d399" />;
    if (ext === 'algoexam' || ext === 'json') return <FileCode size={28} color="#60a5fa" />;
    if (ext === 'algobundle' || ext === 'algoresults' || ext === 'zip') return <Archive size={28} color="#a78bfa" />;
    return <FileCheck size={28} color="#38bdf8" />;
  };

  return (
    <div
      onDragEnter={handleDragEnter}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      style={{
        border: isDragOver
          ? '2px dashed #3b82f6'
          : hasFiles
          ? '2px solid rgba(52, 211, 153, 0.5)'
          : '2px dashed #475569',
        borderRadius: '12px',
        padding: '24px 18px',
        textAlign: 'center',
        background: isDragOver
          ? 'rgba(59, 130, 246, 0.15)'
          : hasFiles
          ? 'rgba(16, 185, 129, 0.08)'
          : 'rgba(15, 23, 42, 0.5)',
        cursor: 'pointer',
        transition: 'all 0.2s ease-in-out',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '8px',
        userSelect: 'none',
        ...style
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={handleInputChange}
        style={{ display: 'none' }}
      />

      {hasFiles ? (
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
          {multiple ? (
            <div style={{ width: '100%' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', color: '#34d399', fontWeight: '700', fontSize: '0.92rem' }}>
                <FileCheck size={20} />
                <span>{selectedFiles.length} fichier(s) sélectionné(s) :</span>
              </div>
              <div style={{ marginTop: '8px', display: 'flex', flexWrap: 'wrap', gap: '6px', justifyContent: 'center' }}>
                {selectedFiles.map((f, i) => (
                  <span
                    key={i}
                    style={{
                      background: 'rgba(30, 41, 59, 0.8)',
                      border: '1px solid rgba(52, 211, 153, 0.3)',
                      borderRadius: '6px',
                      padding: '4px 8px',
                      fontSize: '0.78rem',
                      color: '#cbd5e1'
                    }}
                  >
                    📄 {f.name} ({(f.size / 1024).toFixed(1)} Ko)
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              {getFileIcon(selectedFile?.name)}
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontWeight: '700', color: '#f8fafc', fontSize: '0.9rem' }}>
                  {selectedFile?.name}
                </div>
                <div style={{ fontSize: '0.78rem', color: '#94a3b8' }}>
                  {((selectedFile?.size || 0) / 1024).toFixed(1)} Ko • Prêt pour le traitement
                </div>
              </div>
            </div>
          )}

          {onClear && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                if (inputRef.current) inputRef.current.value = '';
                onClear();
              }}
              style={{
                marginTop: '4px',
                background: 'rgba(239, 68, 68, 0.15)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                color: '#f87171',
                borderRadius: '6px',
                padding: '4px 10px',
                fontSize: '0.76rem',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
            >
              <X size={13} /> Changer de fichier
            </button>
          )}
        </div>
      ) : (
        <>
          <div
            style={{
              width: '48px',
              height: '48px',
              borderRadius: '12px',
              background: isDragOver ? 'rgba(59, 130, 246, 0.25)' : 'rgba(59, 130, 246, 0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              border: '1px solid rgba(59, 130, 246, 0.25)',
              transform: isDragOver ? 'scale(1.08)' : 'scale(1)',
              transition: 'transform 0.2s'
            }}
          >
            {CustomIcon ? (
              <CustomIcon size={24} color="#60a5fa" />
            ) : (
              <UploadCloud size={24} color="#60a5fa" />
            )}
          </div>
          <div>
            <div style={{ fontWeight: '700', color: isDragOver ? '#60a5fa' : '#e2e8f0', fontSize: '0.88rem' }}>
              {isDragOver ? 'Déposez le fichier ici !' : label}
            </div>
            <div style={{ fontSize: '0.78rem', color: '#94a3b8', marginTop: '2px' }}>
              {hint}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
