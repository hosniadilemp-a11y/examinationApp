const prisma = require('../server/src/prisma');

async function resetAllScores() {
  console.log('Resetting all generated scores across submissions and assignments...');

  const updatedSubmissions = await prisma.submission.updateMany({
    data: {
      score: 0,
      manualScore: null,
      passedTests: 0,
      status: 'PENDING_MANUAL',
      gradedAt: null,
      gradedBy: null,
      teacherFeedback: null,
      rubricScores: null
    }
  });

  const updatedAssignments = await prisma.examAssignment.updateMany({
    data: {
      finalScore: null,
      gradingStatus: 'UNGRADED',
      generalFeedback: null
    }
  });

  console.log(`Reset complete: ${updatedSubmissions.count} submissions updated, ${updatedAssignments.count} assignments updated.`);
}

resetAllScores()
  .catch(err => {
    console.error('Error resetting scores:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
