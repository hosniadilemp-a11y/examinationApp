import { StreamLanguage } from '@codemirror/language';
import { autocompletion, snippetCompletion } from '@codemirror/autocomplete';
import { keymap, ViewPlugin, Decoration } from '@codemirror/view';
import { Prec, RangeSetBuilder } from '@codemirror/state';

// Keywords list for stream syntax highlighter (case-insensitive)
const keywordsList = [
  'algorithme', 'var', 'const', 'debut', 'fin',
  'si', 'alors', 'sinon', 'fsi', 'finsi',
  'pour', 'finpour', 'faire', 'de',
  'tant', 'tantque', 'fintantque', 'que',
  'repeter', 'jusqua',
  'ecrire', 'lire', 'retourner',
  'fonction', 'procedure', 'tableau',
  'nil', 'type', 'enregistrement'
];

const typesList = ['entier', 'reel', 'chaine', 'booleen', 'caractere'];
const functionsList = ['longueur', 'concat', 'souschaine', 'abs', 'sqrt', 'puissance', 'min', 'max', 'allouer', 'liberer', 'taille'];
const atomsList = ['vrai', 'faux'];
const operatorsList = ['mod', 'div', 'et', 'ou', 'non'];

// Stream Language Definition for Algorithmic Pseudocode
export const algoLanguage = StreamLanguage.define({
  name: 'algo',
  startState: () => ({ inComment: false }),
  token: (stream, state) => {
    // Comments
    if (stream.match(/\/\/.*/)) return 'comment';
    if (stream.match(/\/\*/)) {
      state.inComment = true;
      return 'comment';
    }
    if (state.inComment) {
      if (stream.match(/.*?\*\//)) {
        state.inComment = false;
      } else {
        stream.skipToEnd();
      }
      return 'comment';
    }

    // Strings
    if (stream.match(/"(?:[^\\]|\\.)*?(?:"|$)/) || stream.match(/'(?:[^\\]|\\.)*?(?:'|$)/)) {
      return 'string';
    }

    // Numbers
    if (stream.match(/\d+\.?\d*/)) {
      return 'number';
    }

    // Operators & Assignment
    if (stream.match(/<-|:=|<=|>=|<>|<|>|\+|-|\*|\/|=/)) {
      return 'keyword';
    }

    // Punctuation
    if (stream.match(/[;:,\[\]\(\)\{\}\^\&\.]/)) {
      return 'punctuation';
    }

    // Identifiers & Keywords
    if (stream.match(/[a-zA-ZÀ-ÿ_][a-zA-ZÀ-ÿ0-9_]*/)) {
      const word = stream.current().toLowerCase();
      if (keywordsList.includes(word)) return 'keyword';
      if (typesList.includes(word)) return 'typeName';
      if (functionsList.includes(word)) return 'standard(name)';
      if (atomsList.includes(word)) return 'atom';
      if (operatorsList.includes(word)) return 'operator';
      return 'variableName';
    }

    stream.next();
    return null;
  }
});

// Clean CodeMirror Snippet Block Completions (Tabstops - no literal text placeholders)
const algoSnippets = [
  snippetCompletion('Algorithme ${MonAlgorithme};\nVar\n\t${x} : Entier;\nDebut\n\t${}\nFin.', {
    label: 'Algorithme ... Fin',
    type: 'snippet',
    boost: 100,
    detail: 'Structure complète algorithme'
  }),
  snippetCompletion('Si (${condition}) Alors\n\t${}\nFinSi;', {
    label: 'Si ... FinSi',
    type: 'snippet',
    boost: 95,
    detail: 'Bloc conditionnel Si'
  }),
  snippetCompletion('Si (${condition}) Alors\n\t${1}\nSinon\n\t${}\nFinSi;', {
    label: 'Si ... Sinon ... FinSi',
    type: 'snippet',
    boost: 94,
    detail: 'Bloc conditionnel Si / Sinon'
  }),
  snippetCompletion('Pour ${i} := 1 a ${N} Faire\n\t${}\nFinPour;', {
    label: 'Pour ... FinPour',
    type: 'snippet',
    boost: 90,
    detail: 'Boucle itérative Pour'
  }),
  snippetCompletion('TantQue (${condition}) Faire\n\t${}\nFinTantQue;', {
    label: 'TantQue ... FinTantQue',
    type: 'snippet',
    boost: 88,
    detail: 'Boucle conditionnelle TantQue'
  }),
  snippetCompletion('Repeter\n\t${}\nJusqu\'a (${condition});', {
    label: 'Repeter ... Jusqu\'a',
    type: 'snippet',
    boost: 86,
    detail: 'Boucle Repeter / Jusqu\'a'
  }),
  snippetCompletion('Procedure ${NomProc}(VAR ${param} : Entier);\nVar\n\t${}\nDebut\n\nFin;', {
    label: 'Procedure ... Fin',
    type: 'snippet',
    boost: 84,
    detail: 'Déclaration de procédure'
  }),
  snippetCompletion('Fonction ${NomFct}(${param} : Entier) : Entier;\nVar\n\t${}\nDebut\n\tRetourner ${valeur};\nFin;', {
    label: 'Fonction ... Fin',
    type: 'snippet',
    boost: 83,
    detail: 'Déclaration de fonction avec retour'
  }),
  snippetCompletion('Ecrire(${msg});', {
    label: 'Ecrire(...)',
    type: 'function',
    boost: 82,
    detail: 'Affichage console'
  }),
  snippetCompletion('Lire(${var});', {
    label: 'Lire(...)',
    type: 'function',
    boost: 81,
    detail: 'Saisie clavier'
  }),
  snippetCompletion('Longueur(${chaine})', {
    label: 'Longueur(...)',
    type: 'function',
    boost: 80,
    detail: 'Longueur d\'une chaîne'
  }),
  snippetCompletion('Concat(${s1}, ${s2})', {
    label: 'Concat(...)',
    type: 'function',
    boost: 79,
    detail: 'Concaténation de chaînes'
  }),
  snippetCompletion('Allouer(${ptr});', {
    label: 'Allouer(...)',
    type: 'function',
    boost: 78,
    detail: 'Allocation dynamique de mémoire'
  }),
  snippetCompletion('Liberer(${ptr});', {
    label: 'Liberer(...)',
    type: 'function',
    boost: 77,
    detail: 'Libération d\'un pointeur'
  }),
  snippetCompletion('Taille(${type})', {
    label: 'Taille(...)',
    type: 'function',
    boost: 76,
    detail: 'Taille en mémoire d\'un type'
  }),
  snippetCompletion('SousChaine(${chaine}, ${debut}, ${longueur})', {
    label: 'SousChaine(...)',
    type: 'function',
    boost: 75,
    detail: 'Extraction d\'une sous-chaîne'
  }),
  snippetCompletion('Type ${NomType} = Enregistrement\n\t${champ} : Entier;\nFin;', {
    label: 'Type ... Enregistrement',
    type: 'snippet',
    boost: 85,
    detail: 'Déclaration d\'enregistrement'
  })
];

// Single Canonical Word Completions (TitleCase + common aliases)
const keywordCompletions = [
  // Built-in functions
  { label: 'Longueur', type: 'function', detail: 'Longueur de chaîne' },
  { label: 'longueur', type: 'function', detail: 'Longueur de chaîne' },
  { label: 'Concat', type: 'function', detail: 'Concaténation de chaînes' },
  { label: 'concat', type: 'function', detail: 'Concaténation de chaînes' },
  { label: 'Allouer', type: 'function', detail: 'Allocation dynamique de mémoire' },
  { label: 'allouer', type: 'function', detail: 'Allocation dynamique de mémoire' },
  { label: 'Liberer', type: 'function', detail: 'Libération d\'un pointeur' },
  { label: 'liberer', type: 'function', detail: 'Libération d\'un pointeur' },
  { label: 'Taille', type: 'function', detail: 'Taille d\'un type' },
  { label: 'taille', type: 'function', detail: 'Taille d\'un type' },
  { label: 'SousChaine', type: 'function', detail: 'Sous-chaîne(chaine, debut, len)' },
  { label: 'souschaine', type: 'function', detail: 'Sous-chaîne(chaine, debut, len)' },
  { label: 'Abs', type: 'function', detail: 'Valeur absolue' },
  { label: 'abs', type: 'function', detail: 'Valeur absolue' },
  { label: 'Sqrt', type: 'function', detail: 'Racine carrée' },
  { label: 'sqrt', type: 'function', detail: 'Racine carrée' },
  { label: 'Puissance', type: 'function', detail: 'Puissance(base, exp)' },
  { label: 'puissance', type: 'function', detail: 'Puissance(base, exp)' },
  { label: 'Min', type: 'function', detail: 'Minimum' },
  { label: 'min', type: 'function', detail: 'Minimum' },
  { label: 'Max', type: 'function', detail: 'Maximum' },
  { label: 'max', type: 'function', detail: 'Maximum' },
  { label: 'Ecrire', type: 'function', detail: 'Affichage console' },
  { label: 'ecrire', type: 'function', detail: 'Affichage console' },
  { label: 'Lire', type: 'function', detail: 'Saisie clavier' },
  { label: 'lire', type: 'function', detail: 'Saisie clavier' },

  // Types & Data structures
  { label: 'Entier', type: 'type', detail: 'Type entier' },
  { label: 'entier', type: 'type', detail: 'Type entier' },
  { label: 'Reel', type: 'type', detail: 'Type réel' },
  { label: 'reel', type: 'type', detail: 'Type réel' },
  { label: 'Chaine', type: 'type', detail: 'Type chaîne de caractères' },
  { label: 'chaine', type: 'type', detail: 'Type chaîne de caractères' },
  { label: 'Booleen', type: 'type', detail: 'Type booléen' },
  { label: 'booleen', type: 'type', detail: 'Type booléen' },
  { label: 'Caractere', type: 'type', detail: 'Type caractère' },
  { label: 'caractere', type: 'type', detail: 'Type caractère' },
  { label: 'Tableau', type: 'type', detail: 'Structure tableau' },
  { label: 'tableau', type: 'type', detail: 'Structure tableau' },
  { label: 'Matrice', type: 'type', detail: 'Structure matrice 2D' },
  { label: 'matrice', type: 'type', detail: 'Structure matrice 2D' },
  { label: 'Pointeur', type: 'type', detail: 'Type pointeur' },
  { label: 'pointeur', type: 'type', detail: 'Type pointeur' },

  // Keywords
  { label: 'Type', type: 'keyword', detail: 'Déclaration de type personnalisé' },
  { label: 'type', type: 'keyword', detail: 'Déclaration de type personnalisé' },
  { label: 'Enregistrement', type: 'keyword', detail: 'Structure enregistrement' },
  { label: 'enregistrement', type: 'keyword', detail: 'Structure enregistrement' },
  { label: 'Nil', type: 'atom', detail: 'Pointeur nul (NIL)' },
  { label: 'nil', type: 'atom', detail: 'Pointeur nul (NIL)' },

  { label: 'Algorithme', type: 'keyword', detail: 'Mot-clé en-tête' },
  { label: 'Var', type: 'keyword', detail: 'Section déclaration variables' },
  { label: 'var', type: 'keyword', detail: 'Section déclaration variables' },
  { label: 'Const', type: 'keyword', detail: 'Section constante' },
  { label: 'const', type: 'keyword', detail: 'Section constante' },
  { label: 'Debut', type: 'keyword', detail: 'Début du bloc d\'instructions' },
  { label: 'debut', type: 'keyword', detail: 'Début du bloc d\'instructions' },
  { label: 'Fin', type: 'keyword', detail: 'Fin de l\'algorithme ou bloc' },
  { label: 'fin', type: 'keyword', detail: 'Fin de l\'algorithme ou bloc' },

  { label: 'Si', type: 'keyword', detail: 'Condition Si' },
  { label: 'si', type: 'keyword', detail: 'Condition Si' },
  { label: 'Alors', type: 'keyword', detail: 'Mot-clé Alors' },
  { label: 'alors', type: 'keyword', detail: 'Mot-clé Alors' },
  { label: 'Sinon', type: 'keyword', detail: 'Alternative Sinon' },
  { label: 'sinon', type: 'keyword', detail: 'Alternative Sinon' },
  { label: 'FinSi', type: 'keyword', detail: 'Fin de condition Si' },
  { label: 'finsi', type: 'keyword', detail: 'Fin de condition Si' },

  { label: 'Pour', type: 'keyword', detail: 'Boucle itérative Pour' },
  { label: 'pour', type: 'keyword', detail: 'Boucle itérative Pour' },
  { label: 'Faire', type: 'keyword', detail: 'Mot-clé Faire' },
  { label: 'faire', type: 'keyword', detail: 'Mot-clé Faire' },
  { label: 'FinPour', type: 'keyword', detail: 'Fin de boucle Pour' },
  { label: 'finpour', type: 'keyword', detail: 'Fin de boucle Pour' },

  { label: 'TantQue', type: 'keyword', detail: 'Boucle conditionnelle TantQue' },
  { label: 'tantque', type: 'keyword', detail: 'Boucle conditionnelle TantQue' },
  { label: 'FinTantQue', type: 'keyword', detail: 'Fin de boucle TantQue' },
  { label: 'fintantque', type: 'keyword', detail: 'Fin de boucle TantQue' },

  { label: 'Repeter', type: 'keyword', detail: 'Boucle Repeter' },
  { label: 'repeter', type: 'keyword', detail: 'Boucle Repeter' },
  { label: 'Jusqu\'a', type: 'keyword', detail: 'Condition de fin Repeter' },
  { label: 'jusqua', type: 'keyword', detail: 'Condition de fin Repeter' },

  { label: 'Fonction', type: 'keyword', detail: 'Déclaration de fonction' },
  { label: 'fonction', type: 'keyword', detail: 'Déclaration de fonction' },
  { label: 'Procedure', type: 'keyword', detail: 'Déclaration de procédure' },
  { label: 'procedure', type: 'keyword', detail: 'Déclaration de procédure' },
  { label: 'Retourner', type: 'keyword', detail: 'Retour de fonction' },
  { label: 'retourner', type: 'keyword', detail: 'Retour de fonction' },

  { label: 'Mod', type: 'operator', detail: 'Reste de division entière' },
  { label: 'mod', type: 'operator', detail: 'Reste de division entière' },
  { label: 'Div', type: 'operator', detail: 'Quotient de division entière' },
  { label: 'div', type: 'operator', detail: 'Quotient de division entière' },
  { label: 'Et', type: 'operator', detail: 'Opérateur logique ET' },
  { label: 'et', type: 'operator', detail: 'Opérateur logique ET' },
  { label: 'Ou', type: 'operator', detail: 'Opérateur logique OU' },
  { label: 'ou', type: 'operator', detail: 'Opérateur logique OU' },
  { label: 'Non', type: 'operator', detail: 'Opérateur logique NON' },
  { label: 'non', type: 'operator', detail: 'Opérateur logique NON' },
  { label: 'Vrai', type: 'atom', detail: 'Constante Vrai' },
  { label: 'vrai', type: 'atom', detail: 'Constante Vrai' },
  { label: 'Faux', type: 'atom', detail: 'Constante Faux' },
  { label: 'faux', type: 'atom', detail: 'Constante Faux' }
];

const allStaticCompletions = [...algoSnippets, ...keywordCompletions];

// B2: Context-Aware Variable Autocomplete (extract identifiers from Var...Debut)
function extractVariablesFromDoc(docText) {
  const vars = [];
  try {
    const varMatch = docText.match(/Var([\s\S]*?)(Debut|Fin|$)/i);
    if (!varMatch) return [];

    const varBlock = varMatch[1];
    const lines = varBlock.split('\n');

    for (const line of lines) {
      const cleanLine = line.replace(/\/\/.*$/, '').trim();
      if (!cleanLine || !cleanLine.includes(':')) continue;

      const [namePart, typePart] = cleanLine.split(':');
      if (!namePart || !typePart) continue;

      const typeName = typePart.replace(';', '').trim();
      const names = namePart.split(',').map(n => n.trim());

      for (let rawName of names) {
        const cleanName = rawName.replace(/\[.*\]/, '').trim();
        if (/^[a-zA-ZÀ-ÿ_][a-zA-ZÀ-ÿ0-9_]*$/.test(cleanName)) {
          if (!keywordsList.includes(cleanName.toLowerCase())) {
            vars.push({
              label: cleanName,
              type: 'variable',
              detail: `🧮 Variable (${typeName || 'Entier'})`,
              boost: 98
            });
          }
        }
      }
    }
  } catch (_) {}
  return vars;
}

// Autocomplete completion source
export function algoCompletionSource(context) {
  const word = context.matchBefore(/[\w\d_À-ÿ]*/);
  if (!word || (word.from === word.to && !context.explicit)) return null;

  const docText = context.state.doc.toString();
  const dynamicVars = extractVariablesFromDoc(docText);
  const completions = [...dynamicVars, ...allStaticCompletions];

  return {
    from: word.from,
    options: completions,
    validFor: /^[\w\d_À-ÿ]*$/
  };
}

// B3: Auto-Closing Block Pairs Extension (Smart: prevents duplicate closer insertion if closer exists below)
export const autoCloseBlocksExtension = Prec.high(keymap.of([
  {
    key: 'Enter',
    run: (view) => {
      const state = view.state;
      const pos = state.selection.main.head;
      const line = state.doc.lineAt(pos);
      const textBefore = line.text.slice(0, pos - line.from).trim();

      // Ensure no-op inside string or comment
      const lineTextUntilCursor = line.text.slice(0, pos - line.from);
      if (lineTextUntilCursor.includes('//') || (lineTextUntilCursor.match(/"/g) || []).length % 2 === 1) {
        return false;
      }

      let closer = '';
      let openerRegex = null;
      let closerRegex = null;

      if (/(^|\s)alors$/i.test(textBefore)) {
        closer = 'FinSi;';
        openerRegex = /\bSi\b/gi;
        closerRegex = /\bFinSi\b/gi;
      } else if (/(^|\s)faire$/i.test(textBefore)) {
        if (/pour/i.test(textBefore)) {
          closer = 'FinPour;';
          openerRegex = /\bPour\b/gi;
          closerRegex = /\bFinPour\b/gi;
        } else {
          closer = 'FinTantQue;';
          openerRegex = /\bTantQue\b/gi;
          closerRegex = /\bFinTantQue\b/gi;
        }
      } else if (/^repeter$/i.test(textBefore)) {
        closer = "Jusqu'a (condition);";
        openerRegex = /\bRepeter\b/gi;
        closerRegex = /\bJusqu'a\b/gi;
      }

      if (!closer) return false;

      // Smart check: Inspect document text AFTER cursor position
      const textAfterCursor = state.doc.sliceString(pos);
      const openersAfter = (textAfterCursor.match(openerRegex) || []).length;
      const closersAfter = (textAfterCursor.match(closerRegex) || []).length;

      // If matching closer already exists below, do NOT insert a duplicate closer
      if (closersAfter > openersAfter) {
        return false;
      }

      const indentMatch = line.text.match(/^\s*/);
      const baseIndent = indentMatch ? indentMatch[0] : '';
      const innerIndent = baseIndent + '    ';

      const insertText = `\n${innerIndent}\n${baseIndent}${closer}`;
      const cursorNewPos = pos + 1 + innerIndent.length;

      view.dispatch({
        changes: { from: pos, to: pos, insert: insertText },
        selection: { anchor: cursorNewPos, head: cursorNewPos },
        userEvent: 'input.completeBlock'
      });

      return true;
    }
  }
]));

// B4: Block-Pair Highlighting Extension
const matchedOpenerDeco = Decoration.mark({ class: 'cm-block-match' });
const unmatchedOpenerDeco = Decoration.mark({ class: 'cm-block-unmatched' });

export const blockPairHighlightExtension = ViewPlugin.fromClass(class {
  constructor(view) {
    this.decorations = this.getMatchDecorations(view);
  }

  update(update) {
    if (update.docChanged || update.selectionSet) {
      this.decorations = this.getMatchDecorations(update.view);
    }
  }

  getMatchDecorations(view) {
    const builder = new RangeSetBuilder();
    const state = view.state;
    const pos = state.selection.main.head;
    const text = state.doc.toString();

    const tokenRegex = /\b(Si|FinSi|Pour|FinPour|TantQue|FinTantQue|Repeter|Jusqu'a)\b/gi;
    const tokens = [];
    let match;

    while ((match = tokenRegex.exec(text)) !== null) {
      tokens.push({
        word: match[0],
        lower: match[0].toLowerCase(),
        from: match.index,
        to: match.index + match[0].length
      });
    }

    const activeIdx = tokens.findIndex(t => pos >= t.from && pos <= t.to);
    if (activeIdx === -1) return Decoration.none;

    const activeToken = tokens[activeIdx];

    const stack = [];
    const pairs = [];
    const unmatched = new Set();

    for (let i = 0; i < tokens.length; i++) {
      const t = tokens[i];
      const norm = t.lower;

      if (['si', 'pour', 'tantque', 'repeter'].includes(norm)) {
        stack.push(t);
      } else if (['finsi', 'finpour', 'fintantque', "jusqu'a"].includes(norm)) {
        if (stack.length > 0) {
          const top = stack.pop();
          pairs.push({ opener: top, closer: t });
        } else {
          unmatched.add(t);
        }
      }
    }
    stack.forEach(t => unmatched.add(t));

    const activePair = pairs.find(p => p.opener === activeToken || p.closer === activeToken);

    if (activePair) {
      const sorted = [activePair.opener, activePair.closer].sort((a, b) => a.from - b.from);
      builder.add(sorted[0].from, sorted[0].to, matchedOpenerDeco);
      builder.add(sorted[1].from, sorted[1].to, matchedOpenerDeco);
    } else if (unmatched.has(activeToken)) {
      builder.add(activeToken.from, activeToken.to, unmatchedOpenerDeco);
    }

    return builder.finish();
  }
}, {
  decorations: v => v.decorations
});

export function algoExtension() {
  return [
    algoLanguage,
    autoCloseBlocksExtension,
    blockPairHighlightExtension,
    autocompletion({ override: [algoCompletionSource] })
  ];
}
