# 🎓 AlgoExamination — AlgoCompiler & Code Editor Technical Architecture Specification

> **Official Comprehensive Technical Documentation & Specification Reference**  
> *Version 2.5 — Core Compiler Pipeline, Frontend Editor & Evaluation Specification*

> [!IMPORTANT]
> **Module Scope Clarification**:  
> The **AlgoCompiler** engine and **`ExamWorkspace.jsx`** component specified in this document form a specialized **Code Editing & Execution Sub-Module** within the larger **AlgoExamination** platform. This module handles exclusively interactive pseudo-code editing, Intellisense autocompletion, structural formatting, transpilation, and sandbox execution. It is **not** the entire platform on its own; it operates as an integrated component alongside **AlgoExamination**'s broader exam session management, anti-cheat surveillance, live teacher monitoring, grading dashboards, academic PDF export, and cryptographic QR verification systems.

---

## 1. System Overview & End-to-End Architecture

**AlgoExamination** incorporates a proprietary algorithmic pseudo-code execution and editing engine designed specifically for computer science higher education (e.g., École Nationale Supérieure d'Informatique). Within the broader platform, this sub-module consists of two primary operational layers:

1. **Frontend Interactive Code Editor (`ExamWorkspace.jsx`)**: A CodeMirror 6 environment tailored with custom French algorithmic syntax highlighting, VS Code Intellisense-style autocompletion, contextual auto-indentation, keyboard shortcut guards, font scaling, and teacher-configurable code snippet briques.
2. **Backend Execution & Evaluation Pipeline (`AlgoCompiler`)**: A multi-stage compiler that tokenizes, parses, validates static semantics, transpiles French algorithmic pseudo-code into sandboxed Python 3 ASTs, executes them inside isolated processes with strict time/memory bounds, and computes automated unit test results alongside AI-driven rubric evaluations.

```
+---------------------------------------------------------------------------------------------------+
|                                  CLIENT LAYER (BROWSER ENVIRONMENT)                               |
|                                                                                                   |
|   ExamWorkspace.jsx (React)                                                                       |
|   +-------------------------------------------------------------------------------------------+   |
|   |  CodeMirror 6 Editor Component                                                            |   |
|   |  - Custom StreamLanguage Tokenizer (algoLanguage in algo-language.js)                      |   |
|   |  - Autocompletion Source (algoCompletionSource - Case-insensitive match)                   |   |
|   |  - Contextual Auto-Indenter (handleFormatCode)                                            |   |
|   |  - Dynamic Font Scale Binding (12px - 22px)                                               |   |
|   |  - Keyboard Shortcut Interceptor (Ctrl+Z, Ctrl+Y, Ctrl+Shift+F, Ctrl+/, Alt+B)             |   |
|   +-------------------------------------------------------------------------------------------+   |
|   |  Editor Action Toolbar: 🧩 Code Bricks | ⌨️ Shortcuts Guide | 🧹 Indenter | 💬/🔓 Comment   |   |
|   +-------------------------------------------------------------------------------------------+   |
+---------------------------------------------------------------------------------------------------+
                                                  |
                                                  | HTTP REST / WebSocket Payload
                                                  v
+---------------------------------------------------------------------------------------------------+
|                                  SERVER LAYER (NODE.JS SERVER)                                    |
|                                                                                                   |
|   1. Lexical Analysis (Lexer)                                                                     |
|      Transforms raw pseudo-code into a stream of typed Tokens (Keywords, Identifiers, Literals).  |
|                                                 |                                                 |
|   2. Syntactic & Semantic Parsing (Parser)                                                        |
|      Constructs an Abstract Syntax Tree (AST) & verifies type declarations and array dimensions. |
|                                                 |                                                 |
|   3. Code Generation (Transpiler)                                                                 |
|      Generates Python 3 ASTs with built-in alias bindings (_b_str, _b_int) & Pointer wrappers.    |
|                                                 |                                                 |
|   4. Security Sandbox Runner (code-execution.service.js)                                          |
|      Spawns restricted sub-processes with CPU time limits (2000ms) & memory thresholds.           |
|                                                 |                                                 |
|   5. Evaluator & Rubric Engine (ai-rubric.service.js & multi_evaluator_driver.py)                 |
|      Evaluates public/hidden test cases and computes structural AI rubric scores.                |
+---------------------------------------------------------------------------------------------------+
```

---

## 2. CodeMirror 6 Editor Implementation (`ExamWorkspace.jsx`)

The frontend code editor is implemented using CodeMirror 6 (`@uiw/react-codemirror`), integrated with custom state hooks and lifecycle listeners.

### 2.1 Technical Capabilities & Features
- **Dynamic Font Size Scaling**: Editor font size is bound to local React state (`fontSize`, range `12px` to `22px`). Hardcoded CSS overrides were eliminated from `index.css` to allow smooth inline font scaling.
- **Copy & Paste Control Policy**: Listens to exam session configuration (`copyDisabled`, `pasteDisabled`). When active, clipboard events (`onCopy`, `onPaste`, `onCut`) are intercepted and blocked.
- **Shortcut Interception & Suppression**: Prevents default browser behaviors (such as saving web pages on <kbd>Ctrl+S</kbd>, printing on <kbd>Ctrl+P</kbd>, view-source on <kbd>Ctrl+U</kbd>, or inspector on <kbd>F12</kbd>) while allowing full code editing shortcuts.
- **Local State Caching & Persistence**: Student code per problem is maintained in a key-value dictionary state (`codeMap[problemId]`). Code state is persisted locally and periodically autosaved to PostgreSQL (`currentCodeMap`).

---

## 3. VS Code Intellisense Autocomplete Engine Specification (`algo-language.js`)

The autocompletion extension (`algoCompletionSource`) provides a context-aware popup menu styled identically to **VS Code Intellisense**.

```
+-------------------------------------------------------------------------+
|  p|                                                                     |
+-------------------------------------------------------------------------+
|  🧩 Pour ... FinPour           Block       Boucle itérative Pour        |
|  🔤 Pour                       Keyword     Boucle itérative Pour        |
|  ⚡ Puissance                   Function    Calcul de puissance (x^y)    |
|  🏷️ Pointeur                   Type        Type pointeur mémoire        |
+-------------------------------------------------------------------------+
```

### 3.1 Categorized Token Palette & Visual Styling
Autocomplete items are categorized into distinct types with tailored CSS badges:

1. 🔤 **Keywords (`type: 'keyword'`)**:
   - Styled with Cyan/Blue badge (`🔤 Keyword`).
   - Represents language keywords: `Algorithme`, `Var`, `Const`, `Debut`, `Fin`, `Si`, `Alors`, `Sinon`, `FinSi`, `Pour`, `FinPour`, `TantQue`, `FinTantQue`, `Faire`, `Repeter`, `Jusqu'a`, `Fonction`, `Procedure`, `Retourner`.

2. 🧩 **Code Snippet Blocks (`type: 'snippet'`)**:
   - Styled with Indigo/Purple badge (`🧩 Block`).
   - Built using `@codemirror/autocomplete`'s `snippetCompletion()` engine. Uses tabstops (`${0}`, `${1}`) allowing clean <kbd>Tab</kbd> navigation between parameter fields without printing raw template placeholders into student code.

3. 🏷️ **Data Types (`type: 'type'`)**:
   - Styled with Emerald Green badge (`🏷️ Type`).
   - Covers primitive and composite types: `Entier`, `Reel`, `Chaine`, `Booleen`, `Caractere`, `Tableau`.

4. ⚡ **Standard Functions (`type: 'function'`)**:
   - Styled with Amber Yellow badge (`⚡ Fonction`).
   - Built-in subprograms: `Ecrire`, `Lire`, `Longueur`, `Concat`, `SousChaine`, `Abs`, `Sqrt`, `Puissance`, `Min`, `Max`.

### 3.2 Single Canonical Keyword Variant Standard
To prevent duplicate suggestions in the autocomplete dropdown:
- **Zero Duplicate Case/Space Variants**: Variants such as `POUR`, `FINPOUR`, `Fin Pour`, `TANTQUE`, `FINTANTQUE`, `Fin Tant Que` were purged.
- **Single Canonical Representation**: Every keyword exposes exactly **1 TitleCase/PascalCase entry** (e.g., `Pour`, `FinPour`, `TantQue`, `FinTantQue`, `Si`, `FinSi`).

---

## 4. Editor Action Toolbar & Code Assistance Tools

Located directly above the code editor pane, the action toolbar gives students fast structural insertion and code formatting utilities.

```
+---------------------------------------------------------------------------------------------------------------+
|  🧩 Briques de Code ▾  |  ⌨️ Raccourcis Clavier  ||  🧹 Reformater  |  💬 Commenter  |  🔓 Décommenter  |  - 14px +  |  🔄 Reset  |
+---------------------------------------------------------------------------------------------------------------+
```

### 4.1 Functional Tool Specifications
- 🧩 **Briques de Code Dropdown**: Displays teacher-authorized algorithmic loops and matrix templates.
- ⌨️ **Raccourcis Clavier Button**: Triggers the interactive modal listing all supported application shortcuts.
- 🧹 **Contextual Auto-Indenter (`handleFormatCode`)**: Formats student code automatically by evaluating block depth.
  - Decrements indent on block closers (`fin`, `sinon`, `finsi`, `finpour`, `fintantque`, `jusqua`).
  - Applies 4 spaces per nesting depth (`'    '.repeat(indent)`).
  - Increments indent on block openers (`debut`, `alors`, `faire`, `sinon`, `repeter`).
- 💬 **Comment Lignes (`handleCommentCode`)**: Prepends `// ` to active or selected lines.
- 🔓 **Décomment Lignes (`handleUncommentCode`)**: Strips leading `// ` from active or selected lines.
- 🔍 **Font Size Controls (`setFontSize`)**: Increments or decrements font size within bounds (`12px` to `22px`).
- 🔄 **Template Reset (`handleResetTemplate`)**: Restores problem template code after confirmation prompt.

---

## 5. Teacher-Configurable Code Bricks System (`ExamManager.jsx`)

Teachers can customize code assistance by enabling or disabling pre-written code briques during exam creation.

### 5.1 Prisma Schema Fields
```prisma
model Exam {
  id                   String   @id @default(uuid())
  allowCodeBricks      Boolean  @default(true)
  allowedBricks        String[] @default(["LIRE_TAB", "AFFICHER_TAB", "LIRE_MATRICE", "AFFICHER_MATRICE", "RECHERCHE_MAX", "TRI_BULLES"])
}
```

### 5.2 Pre-written Briques Catalog
1. **Remplissage Tableau 1D (`LIRE_TAB`)**:
   ```algo
   Pour i := 1 a N Faire
       Ecrire("T[", i, "] = ");
       Lire(T[i]);
   FinPour;
   ```
2. **Affichage Tableau 1D (`AFFICHER_TAB`)**:
   ```algo
   Pour i := 1 a N Faire
       Ecrire(T[i], " ");
   FinPour;
   ```
3. **Remplissage Matrice 2D (`LIRE_MATRICE`)**:
   ```algo
   Pour i := 1 a N Faire
       Pour j := 1 a M Faire
           Ecrire("M[", i, ",", j, "] = ");
           Lire(M[i,j]);
       FinPour;
   FinPour;
   ```
4. **Affichage Matrice 2D (`AFFICHER_MATRICE`)**:
   ```algo
   Pour i := 1 a N Faire
       Pour j := 1 a M Faire
           Ecrire(M[i,j], " ");
       FinPour;
       Ecrire("\n");
   FinPour;
   ```
5. **Recherche Maximum (`RECHERCHE_MAX`)**:
   ```algo
   maxVal := T[1];
   posMax := 1;
   Pour i := 2 a N Faire
       Si (T[i] > maxVal) Alors
           maxVal := T[i];
           posMax := i;
       FinSi;
   FinPour;
   ```
6. **Tri à Bulles (`TRI_BULLES`)**:
   ```algo
   Pour i := 1 a N-1 Faire
       Pour j := 1 a N-i Faire
           Si (T[j] > T[j+1]) Alors
               temp := T[j];
               T[j] := T[j+1];
               T[j+1] := temp;
           FinSi;
       FinPour;
   FinPour;
   ```

---

## 6. Keyboard Shortcuts Engine & Modal Reference

The **Keyboard Shortcuts Guide Modal** (<kbd>⌨️ Raccourcis Clavier</kbd>) lists all available editor keys:

| Shortcut Key | Action / Inserter Purpose |
| :--- | :--- |
| <kbd>Ctrl + Z</kbd> | Défaire la dernière modification (Undo) |
| <kbd>Ctrl + Y</kbd> | Rétablir la modification annulée (Redo) |
| <kbd>Ctrl + Shift + F</kbd> | Reformater et indenter automatiquement tout le code |
| <kbd>Ctrl + /</kbd> | Commenter les lignes sélectionnées (`//`) |
| <kbd>Ctrl + Alt + /</kbd> | Décommenter les lignes sélectionnées |
| <kbd>Alt + H</kbd> | Insérer la structure d'en-tête (`Algorithme...Fin`) |
| <kbd>Alt + S</kbd> | Insérer un bloc conditionnel (`Si...Alors...Sinon`) |
| <kbd>Alt + P</kbd> | Insérer une boucle itérative (`Pour...Faire`) |
| <kbd>Alt + T</kbd> | Insérer une boucle conditionnelle (`TantQue...Faire`) |
| <kbd>Alt + V</kbd> | Insérer une déclaration de variables (`Var`) |
| <kbd>Alt + A</kbd> | Insérer une structure de Tableau (`Tableau[1..N]`) |
| <kbd>Alt + I</kbd> | Insérer instructions `Lire` / `Ecrire` |
| <kbd>Alt + B</kbd> | Ouvrir le menu déroulant des Briques de Code |
| <kbd>Ctrl + Espace</kbd> | Déclencher manuellement l'autocomplétion IntelliSense |

---

## 7. AlgoCompiler Pseudo-Code Language Grammar Specification

### 7.1 Program Structure Grammar
```algo
Algorithme NomDeLAlgorithme;
Const
    MAX = 100;
Var
    x, y : Entier;
    T[MAX] : Entier;
Debut
    Lire(x);
    y := x * 2;
    Ecrire("Résultat = ", y);
Fin.
```

### 7.2 Type System & Variable Mapping
- **`Entier`**: 64-bit signed integer (`0`).
- **`Reel`**: Double precision floating point (`0.0`).
- **`Booleen`**: Boolean flag (`Vrai` / `Faux`).
- **`Caractere`**: Single character (`'a'`).
- **`Chaine`**: Fixed or dynamic string (`"texte"`).
- **`Tableau`**: 1D and 2D arrays (`T[1..100] de Entier`, `M[1..50, 1..50] de Reel`).
- **`Pointeur`**: Memory address reference (`^Entier`, `NIL`).

---

## 8. Compiler Transpilation Architecture & Security Sandbox

```
Source Code --> Tokenizer --> Parser (AST) --> Python Transpiler --> Restricted Subprocess Sandbox
```

### 8.1 Built-in Function Protection Aliasing
To prevent code inside the sandbox from overriding built-in Python primitives:
```python
_b_int = int
_b_float = float
_b_str = str
_b_len = len
_b_range = range
_b_print = print
_b_bool = bool
_b_list = list
```

### 8.2 Execution Runner Subprocess Dispatch (`code-execution.service.js`)
When a student executes code or submits solutions, `runCodeSingle()` handles execution:
1. Writes pseudo-code payload to temporary file (`tmp/{fileId}.algo`).
2. Wraps execution in `runnerScript` redirecting standard input tokens (`_algo_input`).
3. Spawns python runner process with `timeLimitMs` timeout (2000ms max CPU time).
4. Captures `stdout` and `stderr` streams, computing exact execution duration (`executionMs`).

---

## 9. Pointer System & Pass-by-Reference (`VAR` Parameters)

Subprogram parameters declared with `VAR` are passed by reference using synthetic `Pointer` wrappers.

### 9.1 Pointer Class Definition
```python
class Pointer:
    def __init__(self, name, scope_dict, base_var=None):
        self.name = name
        self.scope_dict = scope_dict
        self.base_var = base_var

    def get(self):
        return self.base_var[0] if self.base_var is not None else self.scope_dict[self.name]

    def set(self, val):
        if self.base_var is not None:
            self.base_var[0] = val
        else:
            self.scope_dict[self.name] = val
```

### 9.2 Call-Site Walrus Tuple Translation
```algo
// Algorithmic Pseudo-Code:
Procedure Permuter(VAR a : Entier; VAR b : Entier);
Var temp : Entier;
Debut
    temp := a;
    a := b;
    b := temp;
Fin;

// Invocation:
Permuter(x, y);
```

```python
# Generated Transpiled Python Code:
(_ref_x := [x], _ref_y := [y], Permuter(Pointer('x', None, _ref_x), Pointer('y', None, _ref_y)), x := _ref_x[0], y := _ref_y[0])
```

---

## 10. Multi-Evaluator & AI Rubric Scoring Pipeline (`ai-rubric.service.js`)

Student solutions are evaluated using a 3-Module Grading Pipeline:

1. **Module 1: Public Unit Tests (Auto-Tested)**
   - Evaluates visible test cases provided in problem description.
2. **Module 2: Hidden Unit Tests (Auto-Tested)**
   - Evaluates edge-case hidden unit tests (boundary values, empty inputs, large arrays).
3. **Module 3: AI Rubric & AST Structural Grading (`ai-rubric.service.js`)**
   - Integrates local LLM (`qwen2.5-coder:1.5b` via Ollama API at `127.0.0.1:11434`) for qualitative evaluation.
   - If local LLM is offline, automatically executes the **AST Fallback Rubric Engine**, analyzing variable declarations, instruction presence inside `DEBUT...FIN`, structural loops, and output statements.

---

## 11. Portal Isolation & Security Session State Management

### 11.1 Portal Isolation Policy
- **Student Portal**: Hosted at `http://localhost:5174/student`. If a user attempts to manually enter `/teacher` on Port 5174, `App.jsx` intercepts the URL and forces navigation back to `/student`.
- **Teacher Portal**: Hosted at `http://localhost:5175/teacher`. Dedicated exclusively to exam administration, surveillance, and grading.

### 11.2 Disconnection & Unlock Reconnection Protocol
- When a teacher unlocks a student (`UNLOCK_STUDENT`) or extends exam time (`EXTEND_TIME_STUDENT`), `exam.controller.js` updates `ExamAssignment`:
  - `status` is reset to `'IN_EXAM'`
  - `finishedAt` is cleared to `null`
- This ensures that disconnected or unlocked students logging back in with their access number are welcomed straight back into their exam session instead of seeing error blocks.

---

## 12. Verification Matrix & Audit Status

| Component / Subsystem | Verification Metric | Audit Output | Status |
| :--- | :--- | :---: | :---: |
| **AlgoCompiler Core Engine** | 62 Standard Algorithmic Suite Tests | **62 / 62 PASSED** | **`VERIFIED`** |
| **Execution Concurrency Queue** | 40 Concurrent Load Request Test | **40 / 40 PASSED (508ms)** | **`VERIFIED`** |
| **French Exception Translator** | Unit Test Suite (6 Exception Types + Fallback) | **8 / 8 PASSED** | **`VERIFIED`** |
| **CodeMirror 6 Autocomplete** | Context-Aware Variable Extraction + Single Canonical | **0 Duplicates / 100% Pass** | **`VERIFIED`** |
| **Vite Client Production Build** | `npm run build` Bundle Transformation | **Built in 2.42s** | **`VERIFIED`** |
| **Multi-Service Health Check** | Express Backend (4000) + Student (5174) + Teacher (5175) | **3/3 ONLINE** | **`VERIFIED`** |

---

## 13. System Reliability & Code Editor UX Enhancements (v2.6)

### 13.1 Execution Concurrency Queue (`concurrency-queue.js`)
- **Bounded Concurrency Primitive**: In-process queue wrapper in `code-execution.service.js` capping sub-process execution spawns.
- **Configurability**: Limit controlled via `EXECUTION_CONCURRENCY_LIMIT` (default: `cpu_cores - 1`) and depth ceiling via `EXECUTION_QUEUE_MAX_DEPTH` (default: `100`).
- **Saturation Protection**: Requests beyond queue depth ceiling immediately receive HTTP 429 (`"Le serveur est actuellement saturé, réessayez dans quelques secondes"`).
- **Client State Feedback**: Queued requests notify student UI with `"En attente d'une ressource d'exécution…"`.

### 13.2 French Source-Line-Accurate Error Translator (`french_exception_translator.py`)
- **Domain Terminology Mapping**: Translates raw Python runtime exceptions (`IndexError`, `TypeError`, `ZeroDivisionError`, `RecursionError`, `ValueError`, `NameError`, `AttributeError`) into French messages referencing algorithmic concepts (`Tableau`, `Variable`, `Pointeur`).
- **Internal Masking Guarantee**: Zero Python tracebacks, stack frames, file paths (`/tmp/...`), or internal compiler symbols (`Pointer`, `_ref_x`, `_b_list`, `_algo_`) are ever exposed to students.
- **Safe Fallback**: Unmapped exceptions resolve to `Ligne {n} : Une erreur est survenue lors de l'exécution.`.

### 13.3 Code Mirror 6 Editor UX Enhancements (`ExamWorkspace.jsx` & `algo-language.js`)
1. **Search & Replace (B1)**: `@codemirror/search` integration supporting <kbd>Ctrl+F</kbd> (Search) and <kbd>Ctrl+H</kbd> (Replace), respecting exam session paste controls.
2. **Context-Aware Variable Autocomplete (B2)**: Scoped regex scan over `Var ... Debut` extracting declared variables (`x, y : Entier;`, `T[100] : Entier;`) into completion suggestions with badge `🧮 Variable (${type})`.
3. **Auto-Closing Block Pairs (B3)**: High-priority <kbd>Enter</kbd> keymap inserting matching closers (`Si` → `FinSi;`, `Pour` → `FinPour;`, `TantQue` → `FinTantQue;`, `Repeter` → `Jusqu'a (...)`) with 4-space indented inner line and single <kbd>Ctrl+Z</kbd> undo.
4. **Block-Pair Highlighting (B4)**: Stack-based token matcher highlighting active block opener/closer pairs in blue (`.cm-block-match`) and unmatched blocks in subtle amber (`.cm-block-unmatched`).
5. **Live Inline Diagnostics (B5)**: Fast non-blocking backend endpoint (`POST /api/validate`) running Lexer + Parser stages (20ms response time), debounced by 500ms and feeding inline diagnostics into `@codemirror/lint` `linter()`.
