import os
import json
import re
import sys

# Add path to AlgoCompiler parser
ALGO_COMPILER_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../AlgoCompiler/src'))
if ALGO_COMPILER_PATH not in sys.path:
    sys.path.insert(0, ALGO_COMPILER_PATH)

try:
    from compiler.parser import compile_algo
    COMPILER_AVAILABLE = True
except ImportError:
    COMPILER_AVAILABLE = False

def evaluate_deterministic(problem_data, rubric_data, student_code):
    errors = []
    warnings = []
    recognized_strengths = []
    
    code = student_code or ''
    has_algo_header = bool(re.search(r'ALGORITHME\s+\w+', code, re.I))
    has_var_section = bool(re.search(r'\b(VAR|VARIABLES)\b', code, re.I))
    has_debut = bool(re.search(r'\bDEBUT\b', code, re.I))
    has_fin = bool(re.search(r'\bFIN\b', code, re.I))
    
    # 1. Syntax & Variable Declarations (4 pts)
    syntax_score = 0
    if has_algo_header: syntax_score += 1
    else: warnings.append("En-tête 'ALGORITHME' manquant.")
    
    if has_var_section: syntax_score += 1
    else: warnings.append("Section 'VAR' non explicite.")
    
    if has_debut and has_fin: syntax_score += 2
    else: errors.append("Bloc DEBUT...FIN incomplet.")

    if syntax_score == 4:
        recognized_strengths.append("En-tête et structure de variables conformes aux règles algorithmiques.")

    # 2. Control Flow & Structure (6 pts)
    structure_score = 0
    si_count = len(re.findall(r'\bSI\b', code, re.I))
    finsi_count = len(re.findall(r'\bFIN\s*SI\b|\bFINSI\b', code, re.I))
    tantque_count = len(re.findall(r'\bTANT\s*QUE\b|\bTANTQUE\b', code, re.I))
    fintantque_count = len(re.findall(r'\bFIN\s*TANT\s*QUE\b|\bFINTANTQUE\b', code, re.I))

    if si_count == finsi_count:
        structure_score += 3
        if si_count > 0: recognized_strengths.append("Blocs conditionnels SI/FINSI correctement équilibrés.")
    else:
        errors.append(f"Déséquilibre dans les blocs conditionnels: {si_count} SI vs {finsi_count} FINSI.")

    if tantque_count == fintantque_count:
        structure_score += 3
        if tantque_count > 0: recognized_strengths.append("Boucle TANT QUE correctement fermée.")
    else:
        errors.append(f"Déséquilibre de boucle: {tantque_count} TANT QUE vs {fintantque_count} FIN TANT QUE.")

    # 3. Core Algorithmic Correctness & Bounds Updates (7 pts)
    algo_score = 0
    has_mid_calc = bool(re.search(r'\(.*?\+.*?\)\s*(/|div)\s*2', code, re.I))
    has_deb_update = bool(re.search(r'deb(ut)?\s*(:=|<-|=)\s*.*?(\+|\-)\s*1', code, re.I) or re.search(r'gauche\s*(:=|<-|=)\s*.*?(\+|\-)\s*1', code, re.I))
    has_f_update = bool(re.search(r'f(in)?\s*(:=|<-|=)\s*.*?(\+|\-)\s*1', code, re.I) or re.search(r'droite\s*(:=|<-|=)\s*.*?(\+|\-)\s*1', code, re.I))

    if has_mid_calc:
        algo_score += 3
        recognized_strengths.append("Calcul exact du point milieu par division de l'intervalle.")
    else:
        errors.append("Calcul du point milieu manquant ou incorrect.")

    if has_deb_update and has_f_update:
        # Check if bounds update is logically correct vs inverted (Student 5 bug)
        is_inverted = bool(re.search(r'T\[.*?\]\s*<\s*X.*?f\s*:=', code, re.I | re.DOTALL))
        if is_inverted:
            algo_score += 2 # Partial credit for trying bounds update
            errors.append("Mise à jour des bornes inversée: 'f := milieu - 1' au lieu de 'deb := milieu + 1'.")
        else:
            algo_score += 4
            recognized_strengths.append("Mise à jour stricte des bornes d'intervalle.")
    elif 'deb := milieu' in code or 'deb <- milieu' in code or 'f := milieu' in code:
        algo_score += 1
        errors.append("Mise à jour des bornes sans le '+ 1' ou '- 1', risquant une boucle infinie.")

    # 4. Execution & Edge Cases (3 pts)
    execution_score = 0
    has_return_pos = bool(re.search(r'(pos|indice|indiceTrouve)\s*(:=|<-|=)', code, re.I))
    has_print = bool(re.search(r'Ecrire\(', code, re.I))

    if has_return_pos: execution_score += 2
    if has_print: execution_score += 1

    total_score = round(syntax_score + structure_score + algo_score + execution_score, 1)

    # Classification logic
    if total_score >= 18:
        classification = "correct"
        equivalence = "equivalent"
        correctness = "correct"
    elif total_score >= 10:
        classification = "partially_correct"
        equivalence = "partially_equivalent"
        correctness = "partially_correct"
    elif total_score >= 4:
        classification = "incorrect"
        equivalence = "not_equivalent"
        correctness = "incorrect"
    else:
        classification = "unrelated"
        equivalence = "not_equivalent"
        correctness = "incorrect"

    feedback_fr = f"Note attribuée : {total_score}/20.\n"
    if recognized_strengths:
        feedback_fr += "Points forts : " + ", ".join(recognized_strengths) + ".\n"
    if errors:
        feedback_fr += "Erreurs identifiées : " + ", ".join(errors) + ".\n"

    feedback_en = f"Assigned score: {total_score}/20.\n"
    if recognized_strengths:
        feedback_en += "Strengths: " + ", ".join(recognized_strengths) + ".\n"
    if errors:
        feedback_en += "Identified errors: " + ", ".join(errors) + ".\n"

    return {
        "score": total_score,
        "classification": classification,
        "algorithmic_equivalence": equivalence,
        "correctness": correctness,
        "confidence": 95,
        "identified_errors": errors,
        "recognized_strengths": recognized_strengths,
        "feedback_fr": feedback_fr.strip(),
        "feedback_en": feedback_en.strip(),
        "reasoning_summary": f"Évaluation déterministe AST & Syntaxe. Score={total_score}/20."
    }
