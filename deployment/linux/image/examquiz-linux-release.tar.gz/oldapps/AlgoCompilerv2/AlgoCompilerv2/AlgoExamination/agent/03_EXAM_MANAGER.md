# AlgoExamination — Exam Manager Rules

## Component

`client/src/components/ExamManager.jsx`

## Responsibilities

ExamManager creates and edits an exam session including:
- institutional metadata
- schedule
- duration
- access prefix
- exercises
- points
- anti-cheat settings
- assigned students

## Defaults

Module:

```text
Algorithmique et Structure d'Adonnées
```

Use the exact existing project default if the codebase already defines one; do not silently rename existing persisted values.

Title:

```text
Partiel 01
```

Session:
- August–December → S1
- January–July → S2

Date:
- today's date

Start time:
- current time + approximately 2 minutes

## Point Allocation

The total target is 20.

When adding a new problem:

```js
const remaining = Math.max(
  0,
  20 - existingProblems.reduce((sum, p) => sum + (p.points || 0), 0)
);
```

Then assign `remaining` to the new problem.

### Forbidden behavior

Never:
- recalculate every existing problem
- divide 20 equally automatically
- overwrite teacher-entered points
- reset points after reordering
- reset points after toggling selection

## Warning

If:

```text
total !== 20
```

show the existing warning state.

Do not silently force the total to 20.

## Student Assignment

Support:
- group/speciality filter
- name search
- matricule search
- CSV import
- mass selection

Preserve existing selected students when filters change.

Filtering should not accidentally delete assignments.

## Scheduling

Never construct DateTime values from a time-only string.

Use the backend's safe date/time handling.

## Anti-Cheat Controls

Existing controls include:
- copy disabled
- paste disabled
- fullscreen required
- internet warning
- maximum violations

Do not make a control visually disabled while still sending the opposite value to the backend.

## Exam Creation Checklist

Before completing changes:
- [ ] Title persists
- [ ] Module persists
- [ ] University persists
- [ ] Session persists
- [ ] Date persists
- [ ] Start time persists
- [ ] Duration persists
- [ ] Prefix persists
- [ ] Problems persist in order
- [ ] Custom points persist
- [ ] Total warning works
- [ ] Anti-cheat values persist
- [ ] Student assignments persist
- [ ] No existing selection is accidentally lost
