require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const path = require('path');
const apiRoutes = require('./routes/api.routes');
const setupExamSocket = require('./sockets/exam.socket');

const app = express();
const server = http.createServer(app);

const PORT = process.env.PORT || 4000;
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';

// Socket.io initialization
const io = new Server(server, {
  cors: {
    origin: CORS_ORIGIN,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']
  }
});
app.set('io', io);

// Middleware
app.use(cors({ origin: CORS_ORIGIN }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Attach Socket.io to request object for controllers
app.use((req, res, next) => {
  req.io = io;
  next();
});

// API Routes
app.use('/api', apiRoutes);

// Root health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'AlgoExamination Platform', timestamp: new Date() });
});

// Setup Socket.io event handlers
setupExamSocket(io);

// Unhandled Error Handlers to prevent silent process crashes
process.on('uncaughtException', (err) => {
  console.error('SERVER UNCAUGHT EXCEPTION:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('SERVER UNHANDLED REJECTION:', reason);
});

// Ensure default staff accounts for all 3 roles (Teacher, Proctor, Admin)
const bcrypt = require('bcryptjs');
const prisma = require('./prisma');
async function ensureDefaultStaffAccounts() {
  try {
    const defaultPassword = await bcrypt.hash('admin123', 10);
    const staff = [
      { email: 'teacher@esi.dz', name: 'Prof. Enseignant ASD', role: 'TEACHER' },
      { email: 'teacher@algoexam.edu', name: 'Prof. Enseignant ASD', role: 'TEACHER' },
      { email: 'surveillance@esi.dz', name: 'Surveillant de Salle', role: 'PROCTOR' },
      { email: 'proctor@algoexam.edu', name: 'Surveillant de Salle', role: 'PROCTOR' },
      { email: 'admin@esi.dz', name: 'Administration & Scolarité', role: 'ADMIN' },
      { email: 'admin@algoexam.edu', name: 'Administration & Scolarité', role: 'ADMIN' },
    ];

    for (const s of staff) {
      await prisma.teacher.upsert({
        where: { email: s.email },
        update: { role: s.role, name: s.name },
        create: {
          email: s.email,
          name: s.name,
          role: s.role,
          password: defaultPassword
        }
      });
    }
  } catch (err) {
    console.error('Error seeding default staff accounts:', err);
  }
}

// Start HTTP & Socket server
server.listen(PORT, async () => {
  await ensureDefaultStaffAccounts();
  console.log(`=================================================`);
  console.log(` AlgoExamination Server running on port ${PORT}`);
  console.log(` Health Check: http://localhost:${PORT}/health`);
  console.log(`=================================================`);
});
