import React, { useState, useEffect, useMemo } from 'react';
import {
  listExams,
  createExam,
  updateExam,
  deleteExam,
  listProblems,
  listStudents,
  exportExamBundle,
  importExamBundles,
  exportExamTemplate,
  importExamTemplate,
  launchExamWithRoom
} from '../services/api';
import {
  FilePlus, ArrowLeft, Check, Pencil, Trash2,
  Users, RefreshCw, Plus, BookOpen, FlaskConical, Play,
  ChevronDown, ChevronUp, ChevronRight, Clock, Upload, Download, Search, Filter,
  AlertTriangle, Calendar, ShieldAlert, Building, GraduationCap, FileText, Layers, Sparkles, Code2, Eye, Save, Package, FileCode
} from 'lucide-react';
import Swal from 'sweetalert2';
import ProblemStudio from './ProblemStudio';
import FileDropZone from './FileDropZone';
import { ALGO_CHAPTERS, COMPREHENSIVE_CODE_BRICKS } from '../utils/algo-constants';

const STATUS_LABELS = {
  DRAFT: { label: 'Brouillon', cls: 'badge-secondary' },
  SCHEDULED: { label: 'Planifié', cls: 'badge-yellow' },
  WAITING: { label: 'En Attente', cls: 'badge-yellow' },
  RUNNING: { label: 'En Cours', cls: 'badge-green' },
  PAUSED: { label: 'Suspendu', cls: 'badge-yellow' },
  FINISHED: { label: 'Terminé', cls: 'badge-blue' },
  CLOSED: { label: 'Clôturé', cls: 'badge-secondary' }
};

const DIFFICULTY_CONFIG = {
  FACILE: { label: 'FACILE', color: '#10b981', bg: 'rgba(16, 185, 129, 0.15)', border: 'rgba(16, 185, 129, 0.3)' },
  MOYEN: { label: 'MOYEN', color: '#f59e0b', bg: 'rgba(245, 158, 11, 0.15)', border: 'rgba(245, 158, 11, 0.3)' },
  DIFFICILE: { label: 'DIFFICILE', color: '#ef4444', bg: 'rgba(239, 68, 68, 0.15)', border: 'rgba(239, 68, 68, 0.3)' }
};

function getDefaultSession() {
  const now = new Date();
  const month = now.getMonth();
  const year = now.getFullYear();

  if (month >= 7 && month <= 11) {
    return `${year}/${year + 1} — Semestre 1`;
  } else {
    return `${year - 1}/${year} — Semestre 2`;
  }
}

function getTodayDateAndStartTime() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const dateStr = `${year}-${month}-${day}`;

  const inTwoMins = new Date(now.getTime() + 2 * 60 * 1000);
  const hours = String(inTwoMins.getHours()).padStart(2, '0');
  const mins = String(inTwoMins.getMinutes()).padStart(2, '0');
  const timeStr = `${hours}:${mins}`;

  return { dateStr, timeStr };
}

function generateDefaultExamCode(date = new Date()) {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `ALGO${day}${month}${year}`;
}

const getInitialFormState = () => {
  const { dateStr, timeStr } = getTodayDateAndStartTime();
  return {
    title: 'Partiel 01',
    examCode: generateDefaultExamCode(),
    description: '',
    university: 'École Nationale Supérieure d\'Informatique',
    module: 'Algorithmique et Structure de Données',
    session: getDefaultSession(),
    date: dateStr,
    startTime: timeStr,
    durationMinutes: 90,
    prefix: 'AL',
    maxViolationsAllowed: 4,
    copyDisabled: false,
    pasteDisabled: false,
    fullscreenRequired: true,
    internetWarning: true,
    allowCodeBricks: true,
    allowedBricks: COMPREHENSIVE_CODE_BRICKS.map(b => b.id)
  };
};

export default function ExamManager({ onBack, initialEditingExam, initialCreateMode }) {
  const [view, setView] = useState(() => {
    if (initialEditingExam) return 'EDIT';
    if (initialCreateMode) return 'CREATE';
    return localStorage.getItem('exam_manager_view') || 'LIST';
  });
  const [exams, setExams] = useState([]);
  const [problems, setProblems] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [templateFile, setTemplateFile] = useState(null);
  const [importingTemplate, setImportingTemplate] = useState(false);

  // Form state
  const [editingExam, setEditingExam] = useState(initialEditingExam || null);
  const [formData, setFormData] = useState(getInitialFormState());
  const [selectedProblemsMap, setSelectedProblemsMap] = useState({});
  const [selectedStudentIds, setSelectedStudentIds] = useState([]);
  const [expandedExamId, setExpandedExamId] = useState(null);

  // Custom Brick Snippets state: { [brickId]: customCodeSnippet }
  const [customBrickSnippets, setCustomBrickSnippets] = useState({});
  const [editingProblem, setEditingProblem] = useState(null);
  const [expandedBrickCodeIds, setExpandedBrickCodeIds] = useState({});
  const [inlineBrickDrafts, setInlineBrickDrafts] = useState({});

  // Collapsible Form Sections state (Section 1..6)
  const [collapsedSections, setCollapsedSections] = useState({
    sec1: false,
    sec2: false,
    sec3: false,
    sec4: false,
    sec5: false,
    sec6: false
  });

  const toggleSection = (secKey) => {
    setCollapsedSections(prev => ({ ...prev, [secKey]: !prev[secKey] }));
  };

  const toggleAllSections = (collapse) => {
    setCollapsedSections({
      sec1: collapse,
      sec2: collapse,
      sec3: collapse,
      sec4: collapse,
      sec5: collapse,
      sec6: collapse
    });
  };

  // Collapsible Chapters in Section 3 (Exercices) - Default Collapsed
  const [collapsedExamChapters, setCollapsedExamChapters] = useState({});

  const isExamChapterCollapsed = (topicName) => {
    return collapsedExamChapters[topicName] !== undefined ? collapsedExamChapters[topicName] : true;
  };

  const toggleExamChapter = (topicName) => {
    setCollapsedExamChapters(prev => ({
      ...prev,
      [topicName]: prev[topicName] !== undefined ? !prev[topicName] : false
    }));
  };

  // Collapsible Chapters in Section 4 (Briques) - Default Collapsed
  const [collapsedBrickChapters, setCollapsedBrickChapters] = useState({});

  const isBrickChapterCollapsed = (chapterId) => {
    return collapsedBrickChapters[chapterId] !== undefined ? collapsedBrickChapters[chapterId] : true;
  };

  const toggleBrickChapter = (chapterId) => {
    setCollapsedBrickChapters(prev => ({
      ...prev,
      [chapterId]: prev[chapterId] !== undefined ? !prev[chapterId] : false
    }));
  };

  // Problem Bank Search & Filters in Step 3
  const [probSearch, setProbSearch] = useState('');
  const [selectedTopicFilter, setSelectedTopicFilter] = useState('ALL');

  // Sub-question Points Mapping: { [probId]: { [qId]: points } }
  const [questionPointsMap, setQuestionPointsMap] = useState({});

  // Tripartite Weights Mapping: { [probId]: { weightTest: 40, weightAst: 60, weightAi: 0 } }
  const [problemWeightsMap, setProblemWeightsMap] = useState({});

  // Student Filter state
  const [studentSearch, setStudentSearch] = useState('');
  const [selectedGroupFilter, setSelectedGroupFilter] = useState('ALL');
  const [selectedYearFilter, setSelectedYearFilter] = useState('ALL');

  // Embedded ProblemStudio State
  const [isStudioOpen, setIsStudioOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('exam_manager_view', view);
  }, [view]);

  useEffect(() => {
    const init = async () => {
      await loadAll();
      if (initialEditingExam) {
        openEdit(initialEditingExam);
      } else if (initialCreateMode) {
        openCreate();
      }
    };
    init();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [e, p, s] = await Promise.all([listExams(), listProblems(), listStudents()]);
      setExams(e);
      setProblems(p);
      setStudents(s);
    } catch (err) {
      console.error('Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  /* ---------- Form helpers ---------- */
  const openCreate = () => {
    setEditingExam(null);
    setFormData(getInitialFormState());
    setSelectedProblemsMap({});
    setQuestionPointsMap({});
    setProblemWeightsMap({});
    setCustomBrickSnippets({});
    setSelectedStudentIds(students.map(s => s.id));
    setView('CREATE');
  };

  const openEdit = (exam) => {
    setEditingExam(exam);

    let dStr = '';
    let tStr = '';
    if (exam.startTime) {
      const dt = new Date(exam.startTime);
      const year = dt.getFullYear();
      const month = String(dt.getMonth() + 1).padStart(2, '0');
      const day = String(dt.getDate()).padStart(2, '0');
      dStr = `${year}-${month}-${day}`;

      const hours = String(dt.getHours()).padStart(2, '0');
      const mins = String(dt.getMinutes()).padStart(2, '0');
      tStr = `${hours}:${mins}`;
    }

    setFormData({
      title: exam.title || '',
      description: exam.description || '',
      university: exam.university || 'École Nationale Supérieure d\'Informatique',
      module: exam.module || 'Algorithmique et Structure de Données',
      session: exam.session || getDefaultSession(),
      date: dStr || getTodayDateAndStartTime().dateStr,
      startTime: tStr || getTodayDateAndStartTime().timeStr,
      durationMinutes: exam.durationMinutes || 90,
      prefix: exam.prefix || 'AL2026',
      maxViolationsAllowed: exam.maxViolationsAllowed || 4,
      copyDisabled: !!exam.copyDisabled,
      pasteDisabled: !!exam.pasteDisabled,
      fullscreenRequired: exam.fullscreenRequired !== false,
      internetWarning: exam.internetWarning !== false,
      allowedBricks: (() => {
        let b = exam.allowedBricks;
        if (typeof b === 'string') {
          try { b = JSON.parse(b); } catch (e) { b = null; }
        }
        return Array.isArray(b) ? b : COMPREHENSIVE_CODE_BRICKS.map(brick => brick.id);
      })()
    });

    const pMap = {};
    const qpMap = {};
    const pwMap = {};
    if (Array.isArray(exam.problems)) {
      exam.problems.forEach(ep => {
        pMap[ep.problemId] = ep.points || ep.problem?.points || 5;
        pwMap[ep.problemId] = {
          weightTest: ep.weightTest !== undefined ? ep.weightTest : 40,
          weightAst: ep.weightAst !== undefined ? ep.weightAst : 60,
          weightAi: ep.weightAi !== undefined ? ep.weightAi : 0
        };
        if (ep.questionPoints && typeof ep.questionPoints === 'object') {
          qpMap[ep.problemId] = ep.questionPoints;
        }
      });
    }
    setSelectedProblemsMap(pMap);
    setQuestionPointsMap(qpMap);
    setProblemWeightsMap(pwMap);

    const stIds = Array.isArray(exam.assignments)
      ? exam.assignments.map(a => a.studentId)
      : [];
    setSelectedStudentIds(stIds);

    setView('EDIT');
  };

  const handleToggleProblem = (prob) => {
    setSelectedProblemsMap(prev => {
      const next = { ...prev };
      if (next[prob.id] !== undefined) {
        delete next[prob.id];
      } else {
        const currentSum = Object.values(next).reduce((sum, pts) => sum + (parseInt(pts, 10) || 0), 0);
        const remaining = 20 - currentSum;
        const newPts = remaining > 0 ? remaining : (prob.points || 5);
        next[prob.id] = newPts;

        // Auto-distribute points across sub-questions if multi-question
        if (Array.isArray(prob.questions) && prob.questions.length > 0) {
          const count = prob.questions.length;
          const perQ = Math.max(1, Math.floor(newPts / count));
          const qDist = {};
          let allocated = 0;
          prob.questions.forEach((q, idx) => {
            const val = (idx === count - 1) ? (newPts - allocated) : perQ;
            qDist[q.id || q.orderIndex] = val > 0 ? val : 1;
            allocated += val;
          });
          setQuestionPointsMap(qp => ({ ...qp, [prob.id]: qDist }));
        }

        // Initialize default weights (Tests 40% / AST 60% / AI 0%)
        const hasTests = Array.isArray(prob.testCases) && prob.testCases.length > 0;
        const isMultiQ = Array.isArray(prob.questions) && prob.questions.length > 1;
        setProblemWeightsMap(wm => ({
          ...wm,
          [prob.id]: wm[prob.id] || {
            weightTest: (!hasTests || isMultiQ) ? 0 : 40,
            weightAst: (!hasTests || isMultiQ) ? 100 : 60,
            weightAi: 0
          }
        }));
      }
      return next;
    });
  };

  const handleUpdateProblemPoints = (probId, pts) => {
    const parsed = Math.max(1, Math.min(20, parseInt(pts, 10) || 1));
    setSelectedProblemsMap(prev => ({
      ...prev,
      [probId]: parsed
    }));
  };

  const handleUpdateQuestionPoints = (probId, qId, pts) => {
    const parsed = Math.max(1, Math.min(20, parseInt(pts, 10) || 1));
    setQuestionPointsMap(prev => {
      const current = { ...(prev[probId] || {}) };
      current[qId] = parsed;
      const newTotal = Object.values(current).reduce((a, b) => a + (parseInt(b, 10) || 0), 0);
      setSelectedProblemsMap(pm => ({ ...pm, [probId]: newTotal }));
      return { ...prev, [probId]: current };
    });
  };

  const handleUpdateProblemWeight = (probId, field, val) => {
    const parsed = Math.max(0, Math.min(100, parseInt(val, 10) || 0));
    setProblemWeightsMap(prev => ({
      ...prev,
      [probId]: {
        ...(prev[probId] || { weightTest: 40, weightAst: 60, weightAi: 0 }),
        [field]: parsed
      }
    }));
  };

  const availableGroups = useMemo(() => {
    const setG = new Set();
    students.forEach(s => {
      if (s.group) setG.add(s.group);
    });
    return Array.from(setG).sort();
  }, [students]);

  const availableYears = useMemo(() => {
    const setY = new Set();
    students.forEach(s => {
      if (s.academicYear) {
        setY.add(String(s.academicYear));
      } else if (s.studentId && s.studentId.length >= 4) {
        const potentialYear = s.studentId.substring(0, 4);
        if (/^\d{4}$/.test(potentialYear)) setY.add(potentialYear);
      }
    });
    return Array.from(setY).sort().reverse();
  }, [students]);

  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      const matchSearch = !studentSearch.trim() ||
        (s.studentId && s.studentId.toLowerCase().includes(studentSearch.toLowerCase())) ||
        (s.firstName && s.firstName.toLowerCase().includes(studentSearch.toLowerCase())) ||
        (s.lastName && s.lastName.toLowerCase().includes(studentSearch.toLowerCase()));

      const matchGroup = selectedGroupFilter === 'ALL' || s.group === selectedGroupFilter;

      const matchYear = selectedYearFilter === 'ALL' ||
        String(s.academicYear) === String(selectedYearFilter) ||
        (s.studentId && s.studentId.startsWith(String(selectedYearFilter)));

      return matchSearch && matchGroup && matchYear;
    });
  }, [students, studentSearch, selectedGroupFilter, selectedYearFilter]);

  const handleToggleStudent = (studentId) => {
    setSelectedStudentIds(prev =>
      prev.includes(studentId)
        ? prev.filter(id => id !== studentId)
        : [...prev, studentId]
    );
  };

  const handleSelectAllStudents = (targetList) => {
    const targetIds = targetList.map(s => s.id);
    const allSelected = targetIds.every(id => selectedStudentIds.includes(id));

    if (allSelected) {
      setSelectedStudentIds(prev => prev.filter(id => !targetIds.includes(id)));
    } else {
      setSelectedStudentIds(prev => Array.from(new Set([...prev, ...targetIds])));
    }
  };

  // Code Bricks Toggle Helpers
  const handleToggleAllBricks = (enable) => {
    setFormData(prev => ({
      ...prev,
      allowedBricks: enable ? COMPREHENSIVE_CODE_BRICKS.map(b => b.id) : []
    }));
  };

  const handleToggleChapterBricks = (chapterId, enable) => {
    const chapterBrickIds = COMPREHENSIVE_CODE_BRICKS.filter(b => b.chapterId === chapterId).map(b => b.id);
    setFormData(prev => {
      let current = [...(prev.allowedBricks || [])];
      if (enable) {
        current = Array.from(new Set([...current, ...chapterBrickIds]));
      } else {
        current = current.filter(id => !chapterBrickIds.includes(id));
      }
      return { ...prev, allowedBricks: current };
    });
  };

  const handleToggleSingleBrick = (brickId) => {
    setFormData(prev => {
      const current = [...(prev.allowedBricks || [])];
      const next = current.includes(brickId)
        ? current.filter(id => id !== brickId)
        : [...current, brickId];
      return { ...prev, allowedBricks: next };
    });
  };

  // Open Edit Brick Code Snippet Modal
  const handleOpenEditBrickModal = (brick, e) => {
    if (e) e.stopPropagation();
    setActiveBrickToEdit(brick);
    const existingCustom = customBrickSnippets[brick.id];
    setTempBrickCode(existingCustom !== undefined ? existingCustom : brick.snippet);
  };

  // Save Custom Brick Code Snippet
  const handleSaveBrickCode = () => {
    if (!activeBrickToEdit) return;
    setCustomBrickSnippets(prev => ({
      ...prev,
      [activeBrickToEdit.id]: tempBrickCode
    }));
    setActiveBrickToEdit(null);
    Swal.fire({
      icon: 'success',
      title: 'Code de la Brique Enregistré !',
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1400,
      background: '#0f172a',
      color: '#fff'
    });
  };

  // Group Problems by Topics (Ordered by Chapter Number)
  const problemsByTopic = useMemo(() => {
    const groups = {};
    problems.forEach(p => {
      const matchSearch = !probSearch.trim() ||
        (p.title && p.title.toLowerCase().includes(probSearch.toLowerCase())) ||
        (p.description && p.description.toLowerCase().includes(probSearch.toLowerCase()));

      const matchTopic = selectedTopicFilter === 'ALL' || (p.topic || '').includes(selectedTopicFilter);

      if (matchSearch && matchTopic) {
        const topicName = p.topic || 'Algorithmique Général';
        if (!groups[topicName]) groups[topicName] = [];
        groups[topicName].push(p);
      }
    });

    // Strictly sort chapters according to ALGO_CHAPTERS order or chapter number
    const sortedGroups = {};
    const getChapterOrder = (name) => {
      const chIdx = ALGO_CHAPTERS.findIndex(ch => ch.title === name || ch.id === name || name.includes(ch.id) || name.includes(ch.title));
      if (chIdx !== -1) return chIdx;
      const numMatch = name.match(/(?:chapitre|ch)\s*(\d+)/i);
      if (numMatch) return parseInt(numMatch[1], 10);
      return 999;
    };

    Object.keys(groups)
      .sort((a, b) => getChapterOrder(a) - getChapterOrder(b))
      .forEach(key => {
        sortedGroups[key] = groups[key];
      });

    return sortedGroups;
  }, [problems, probSearch, selectedTopicFilter]);

  // Handle Form Submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      Swal.fire({ icon: 'warning', title: 'Titre Requis', text: 'Veuillez saisir le titre de l\'examen.', background: '#111827', color: '#fff' });
      return;
    }

    const selectedProbIds = Object.keys(selectedProblemsMap);
    if (selectedProbIds.length === 0) {
      Swal.fire({ icon: 'warning', title: 'Aucun Exercice', text: 'Veuillez sélectionner au moins un exercice dans le barème.', background: '#111827', color: '#fff' });
      return;
    }

    // Validate tripartite weights sum to 100%
    for (const pId of selectedProbIds) {
      const weights = problemWeightsMap[pId] || { weightTest: 40, weightAst: 60, weightAi: 0 };
      const sumW = (parseInt(weights.weightTest, 10) || 0) + (parseInt(weights.weightAst, 10) || 0) + (parseInt(weights.weightAi, 10) || 0);
      if (sumW !== 100) {
        Swal.fire({
          icon: 'error',
          title: 'Pondération Invalide !',
          text: `La somme des pondérations (Tests + AST + IA) pour chaque exercice doit être exactement égale à 100% (actuel: ${sumW}%).`,
          background: '#111827',
          color: '#fff'
        });
        return;
      }
    }

    const totalPts = Object.values(selectedProblemsMap).reduce((sum, pts) => sum + (parseInt(pts, 10) || 0), 0);
    if (totalPts !== 20) {
      const confirmRes = await Swal.fire({
        icon: 'question',
        title: `Barème Total = ${totalPts} / 20 pts`,
        text: 'Le total du barème n\'est pas égal à 20 pts. Voulez-vous continuer quand même ?',
        showCancelButton: true,
        confirmButtonText: 'Oui, Enregistrer',
        cancelButtonText: 'Ajuster le Barème',
        background: '#111827',
        color: '#fff'
      });
      if (!confirmRes.isConfirmed) return;
    }

    const selectedProblemsList = selectedProbIds.map(pId => {
      const weights = problemWeightsMap[pId] || { weightTest: 40, weightAst: 60, weightAi: 0 };
      return {
        id: pId,
        problemId: pId,
        points: selectedProblemsMap[pId] || 5,
        weightTest: weights.weightTest ?? 40,
        weightAst: weights.weightAst ?? 60,
        weightAi: weights.weightAi ?? 0,
        questionPoints: questionPointsMap[pId] || {}
      };
    });

    const startDateTimeISO = new Date(`${formData.date}T${formData.startTime}:00`).toISOString();

    const payload = {
      title: formData.title.trim(),
      examCode: formData.examCode?.trim().toUpperCase(),
      description: formData.description.trim(),
      university: formData.university.trim(),
      module: formData.module.trim(),
      session: formData.session.trim(),
      startTime: startDateTimeISO,
      durationMinutes: parseInt(formData.durationMinutes, 10) || 90,
      prefix: formData.prefix.trim() || 'AL2026',
      maxViolationsAllowed: parseInt(formData.maxViolationsAllowed, 10) || 4,
      copyDisabled: !!formData.copyDisabled,
      pasteDisabled: !!formData.pasteDisabled,
      fullscreenRequired: !!formData.fullscreenRequired,
      internetWarning: !!formData.internetWarning,
      allowCodeBricks: !!formData.allowCodeBricks,
      allowedBricks: formData.allowedBricks,
      problems: selectedProblemsList,
      studentIds: selectedStudentIds
    };

    try {
      if (editingExam) {
        await updateExam(editingExam.id, payload);
        Swal.fire({ icon: 'success', title: 'Examen Modifié !', timer: 1500, showConfirmButton: false, background: '#111827', color: '#fff' });
      } else {
        await createExam(payload);
        Swal.fire({ icon: 'success', title: 'Examen Créé !', timer: 1500, showConfirmButton: false, background: '#111827', color: '#fff' });
      }
      setView('LIST');
      loadAll();
    } catch (err) {
      const errorMsg = err.data?.error || err.message || '';
      await Swal.fire({ icon: 'error', title: 'Erreur', text: errorMsg, background: '#111827', color: '#fff' });
      if (errorMsg.includes('préfixe') || errorMsg.includes('Préfixe') || errorMsg.includes('prefix')) {
        setCollapsedSections(prev => ({ ...prev, sec1: false }));
        setTimeout(() => {
          const el = document.getElementById('prefix-input');
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            el.focus();
            el.style.border = '2px solid #ef4444';
          }
        }, 200);
      }
    }
  };

  const handleDeleteExam = async (examId, title) => {
    const res = await Swal.fire({
      icon: 'warning',
      title: 'Supprimer cet Examen ?',
      text: `Voulez-vous supprimer définitivement "${title}" ? Cette action est irréversible.`,
      showCancelButton: true,
      confirmButtonText: 'Oui, Supprimer',
      cancelButtonText: 'Annuler',
      confirmButtonColor: '#ef4444',
      background: '#111827',
      color: '#fff'
    });

    if (res.isConfirmed) {
      try {
        await deleteExam(examId);
        Swal.fire({ icon: 'success', title: 'Examen Supprimé', timer: 1500, showConfirmButton: false, background: '#111827', color: '#fff' });
        loadAll();
      } catch (err) {
        Swal.fire({ icon: 'error', title: 'Erreur', text: err.data?.error || err.message, background: '#111827', color: '#fff' });
      }
    }
  };

  const handleExportBundle = async (examId, title) => {
    try {
      const encryptedData = await exportExamBundle(examId);
      const jsonStr = JSON.stringify(encryptedData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Paquet_Soumissions_${(title || 'Examen').replace(/[^\w]/g, '_')}.algobundle`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: '📦 Paquet Exporté !',
        text: 'Le fichier chiffré .algobundle a été téléchargé avec succès (AES-256-GCM automatique).',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export bundle error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Impossible d’exporter le paquet.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const handleImportBundles = async (examId, title) => {
    const { value: formValues } = await Swal.fire({
      title: '📥 Importer des Paquets Multi-Room (.algobundle)',
      html: `
        <div style="text-align: left; font-size: 0.88rem; color: #cbd5e1; display: flex; flex-direction: column; gap: 12px;">
          <p style="margin: 0; color: #93c5fd;">Sélectionnez un ou plusieurs fichiers .algobundle provenant de salles déconnectées pour fusionner les soumissions.</p>
          <div>
            <label style="display: block; margin-bottom: 4px; font-weight: bold;">Sélectionner les fichiers .algobundle :</label>
            <input type="file" id="swal-bundles-files" multiple accept=".algobundle,.json" style="width: 100%; font-size: 0.82rem; background: #0f172a; padding: 8px; border: 1px solid #334155; border-radius: 4px; color: #fff;" />
          </div>
          <div>
            <label style="display: block; margin-bottom: 4px; font-size: 0.78rem; color: #94a3b8;">Mot de passe personnalisé (optionnel, laissez vide si standard) :</label>
            <input type="password" id="swal-bundles-passphrase" placeholder="Optionnel (Déchiffrement auto par défaut)" style="width: 100%; font-size: 0.82rem; background: #0f172a; padding: 6px; border: 1px solid #334155; border-radius: 4px; color: #fff;" />
          </div>
        </div>
      `,
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: 'Déchiffrer & Fusionner',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff',
      preConfirm: () => {
        const filesInput = document.getElementById('swal-bundles-files');
        const passInput = document.getElementById('swal-bundles-passphrase');
        if (!filesInput.files || filesInput.files.length === 0) {
          Swal.showValidationMessage('Veuillez sélectionner au moins un fichier .algobundle');
          return false;
        }
        return { files: filesInput.files, passphrase: passInput.value.trim() };
      }
    });

    if (!formValues) return;

    try {
      const formData = new FormData();
      for (let i = 0; i < formValues.files.length; i++) {
        formData.append('bundles', formValues.files[i]);
      }
      if (formValues.passphrase) {
        formData.append('passphrase', formValues.passphrase);
      }

      const res = await importExamBundles(examId, formData);
      Swal.fire({
        icon: 'success',
        title: 'Fusion Terminée !',
        html: `
          <div style="text-align: left; font-size: 0.9rem; color: #cbd5e1;">
            <p>${res.message}</p>
            <ul style="margin-top: 8px; padding-left: 20px; color: #93c5fd;">
              <li>Nouveaux étudiants : <strong>${res.totalStudentsImported}</strong></li>
              <li>Nouvelles soumissions : <strong>${res.totalSubmissionsImported}</strong></li>
              <li>Soumissions mises à jour : <strong>${res.totalSubmissionsUpdated}</strong></li>
            </ul>
          </div>
        `,
        background: '#111827',
        color: '#fff'
      });
      loadAll();
    } catch (err) {
      console.error('Import bundles error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Importation',
        text: err.message || 'Échec de l’importation des paquets.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Export Exam Template (.algoexam)
  const handleExportTemplate = async (examId, title) => {
    try {
      const templateData = await exportExamTemplate(examId);
      const jsonStr = JSON.stringify(templateData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Modele_Examen_${(title || 'Examen').replace(/[^\w]/g, '_')}.algoexam`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      Swal.fire({
        icon: 'success',
        title: 'Modèle Exporté !',
        text: 'Le fichier .algoexam a été téléchargé avec succès (sans données étudiants).',
        timer: 2000,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
    } catch (err) {
      console.error('Export template error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Exportation',
        text: err.data?.error || err.message || 'Impossible d’exporter le modèle d’examen.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  // Import Exam Template (.algoexam)
  const handleImportTemplate = () => {
    setTemplateFile(null);
    setIsImportModalOpen(true);
  };

  const handleProcessImportTemplateModal = async () => {
    if (!templateFile) return;
    setImportingTemplate(true);
    try {
      const formData = new FormData();
      formData.append('template', templateFile);

      const res = await importExamTemplate(formData);
      setIsImportModalOpen(false);
      setTemplateFile(null);

      const summaryRows = (res.problemSummary || []).map((p, idx) => `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.06);">
          <td style="padding: 6px 8px; font-weight: bold; color: #fff;">${idx + 1}. ${p.title}</td>
          <td style="padding: 6px 8px; text-align: center;">
            <span style="padding: 2px 6px; border-radius: 4px; font-size: 0.72rem; font-weight: bold; background: ${p.status === 'CREATED' ? 'rgba(52,211,153,0.2)' : 'rgba(96,165,250,0.2)'}; color: ${p.status === 'CREATED' ? '#34d399' : '#60a5fa'}; border: 1px solid ${p.status === 'CREATED' ? 'rgba(52,211,153,0.4)' : 'rgba(96,165,250,0.4)'};">
              ${p.status === 'CREATED' ? '✨ Créé en Base' : '✓ Déjà Existant'}
            </span>
          </td>
          <td style="padding: 6px 8px; text-align: right; color: #f59e0b; font-weight: bold;">${p.points} pts</td>
        </tr>
      `).join('');

      Swal.fire({
        icon: 'success',
        title: 'Examen Importé avec Succès !',
        html: `
          <div style="text-align: left; font-size: 0.88rem; color: #cbd5e1;">
            <p style="margin-bottom: 10px; color: #34d399; font-weight: bold;">${res.message}</p>
            <div style="max-height: 220px; overflow-y: auto; background: rgba(0,0,0,0.3); border-radius: 6px; border: 1px solid rgba(255,255,255,0.1);">
              <table style="width: 100%; border-collapse: collapse; font-size: 0.82rem;">
                <thead>
                  <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; font-size: 0.75rem; text-transform: uppercase;">
                    <th style="padding: 6px 8px; text-align: left;">Exercice</th>
                    <th style="padding: 6px 8px; text-align: center;">Statut</th>
                    <th style="padding: 6px 8px; text-align: right;">Points</th>
                  </tr>
                </thead>
                <tbody>
                  ${summaryRows}
                </tbody>
              </table>
            </div>
          </div>
        `,
        background: '#111827',
        color: '#fff'
      });
      loadAll();
    } catch (err) {
      console.error('Import template error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur Importation',
        text: err.message || 'Impossible d’importer le modèle d’examen.',
        background: '#111827',
        color: '#fff'
      });
    } finally {
      setImportingTemplate(false);
    }
  };

  // Launch Exam for a Specific Room
  const handleLaunchRoomExam = async (exam) => {
    const groups = Array.from(new Set(students.map(s => s.group || 'G01'))).sort();
    const groupOptionsHtml = groups.map(g => `<option value="${g}">Groupe ${g}</option>`).join('');

    const { value: formValues } = await Swal.fire({
      title: `🚀 Démarrer l'Épreuve : ${exam.title}`,
      html: `
        <div style="text-align: left; font-size: 0.88rem; color: #cbd5e1; display: flex; flex-direction: column; gap: 14px;">
          <div>
            <label style="display: block; margin-bottom: 4px; font-weight: bold; color: #60a5fa;">1. Salle / Amphi d'examen :</label>
            <input type="text" id="swal-room-name" placeholder="Ex: Salle 101, Amphi B, Salle TP 03" value="${exam.room || ''}" style="width: 100%; font-size: 0.85rem; background: #0f172a; padding: 8px 12px; border: 1px solid #334155; border-radius: 6px; color: #fff;" />
          </div>

          <div>
            <label style="display: block; margin-bottom: 4px; font-weight: bold; color: #34d399;">2. Affectation des Étudiants :</label>
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <div>
                <span style="font-size: 0.78rem; color: #94a3b8; display: block; margin-bottom: 3px;">Option A : Filtrer par Groupe dans le Roster :</span>
                <select id="swal-group-select" style="width: 100%; font-size: 0.82rem; background: #0f172a; padding: 6px; border: 1px solid #334155; border-radius: 4px; color: #fff;">
                  <option value="ALL">Tous les groupes (${students.length} étudiants inscrits)</option>
                  ${groupOptionsHtml}
                </select>
              </div>
              <div>
                <span style="font-size: 0.78rem; color: #94a3b8; display: block; margin-bottom: 3px;">Option B : Ou Téléverser un fichier CSV pour cette salle :</span>
                <input type="file" id="swal-room-csv" accept=".csv,.txt" style="width: 100%; font-size: 0.8rem; background: #0f172a; padding: 6px; border: 1px solid #334155; border-radius: 4px; color: #fff;" />
              </div>
            </div>
          </div>

          <div style="display: flex; align-items: center; gap: 8px; background: rgba(0,0,0,0.3); padding: 8px 12px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.06);">
            <input type="checkbox" id="swal-randomize" checked style="cursor: pointer; width: 16px; height: 16px;" />
            <label for="swal-randomize" style="font-size: 0.8rem; color: #cbd5e1; cursor: pointer;">
              Générer des codes anonymisés aléatoires (Ex: <strong>AL-001, AL-002</strong>)
            </label>
          </div>
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: '🚀 Lancer pour cette Salle',
      cancelButtonText: 'Annuler',
      background: '#111827',
      color: '#fff',
      preConfirm: () => {
        const roomInput = document.getElementById('swal-room-name');
        const groupSelect = document.getElementById('swal-group-select');
        const csvInput = document.getElementById('swal-room-csv');
        const randomizeCheck = document.getElementById('swal-randomize');

        const room = roomInput.value.trim() || 'Salle Principale';
        const csvFile = csvInput.files && csvInput.files[0] ? csvInput.files[0] : null;
        const selectedGroup = groupSelect.value;
        const randomizeOrder = randomizeCheck.checked;

        let selectedIds = [];
        if (!csvFile) {
          if (selectedGroup === 'ALL') {
            selectedIds = students.map(s => s.id);
          } else {
            selectedIds = students.filter(s => s.group === selectedGroup).map(s => s.id);
          }
          if (selectedIds.length === 0) {
            Swal.showValidationMessage('Aucun étudiant trouvé pour ce groupe.');
            return false;
          }
        }

        return { room, csvFile, selectedIds, randomizeOrder };
      }
    });

    if (!formValues) return;

    try {
      const formData = new FormData();
      formData.append('room', formValues.room);
      formData.append('randomizeOrder', String(formValues.randomizeOrder));
      if (formValues.csvFile) {
        formData.append('studentsCSV', formValues.csvFile);
      } else {
        formData.append('studentIds', JSON.stringify(formValues.selectedIds));
      }

      const res = await launchExamWithRoom(exam.id, formData);
      Swal.fire({
        icon: 'success',
        title: 'Épreuve Lancée !',
        text: res.message,
        timer: 2500,
        showConfirmButton: false,
        background: '#111827',
        color: '#fff'
      });
      loadAll();
    } catch (err) {
      console.error('Launch room error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Erreur de Lancement',
        text: err.message || 'Impossible de lancer l’épreuve.',
        background: '#111827',
        color: '#fff'
      });
    }
  };

  const handleCSVUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = (event.target.result || '').replace(/^\uFEFF+/, '');
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      const foundMatricules = new Set();

      lines.forEach(line => {
        const parts = line.split(/[,;\t]/).map(p => p.trim());
        parts.forEach(p => {
          if (p.length >= 3) foundMatricules.add(p.toLowerCase());
        });
      });

      const matchedIds = students
        .filter(s => s.studentId && foundMatricules.has(s.studentId.toLowerCase()))
        .map(s => s.id);

      if (matchedIds.length > 0) {
        setSelectedStudentIds(prev => Array.from(new Set([...prev, ...matchedIds])));
        Swal.fire({
          icon: 'success',
          title: 'Import CSV Réussi !',
          text: `${matchedIds.length} étudiants correspondants ont été sélectionnés.`,
          background: '#111827',
          color: '#fff'
        });
      } else {
        Swal.fire({ icon: 'info', title: 'Aucune correspondance', text: 'Aucun matricule trouvé dans la liste.', background: '#111827', color: '#fff' });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  if (isStudioOpen) {
    return (
      <ProblemStudio
        initialProblem={editingProblem}
        onBack={() => {
          setIsStudioOpen(false);
          setEditingProblem(null);
        }}
        onSaveSuccess={(newProb) => {
          setIsStudioOpen(false);
          setEditingProblem(null);
          if (newProb && newProb.id) {
            setProblems(prev => [newProb, ...prev.filter(p => p.id !== newProb.id)]);
            setSelectedProblemsMap(prev => ({
              ...prev,
              [newProb.id]: prev[newProb.id] || newProb.points || 5
            }));
          }
          loadAll();
        }}
      />
    );
  }

  const totalExamPoints = Object.values(selectedProblemsMap).reduce((sum, pts) => sum + (parseInt(pts, 10) || 0), 0);
  const areAllSectionsCollapsed = Object.values(collapsedSections).every(Boolean);

  return (
    <div style={{ padding: '30px', maxWidth: '1240px', margin: '0 auto', color: 'var(--text-main)' }}>
      
      {/* Navigation Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <button type="button" className="btn btn-secondary" onClick={onBack}>
          <ArrowLeft size={16} /> Tableau de Bord des Examens
        </button>

        {view === 'LIST' ? (
          <div style={{ display: 'flex', gap: '10px' }}>
            <button type="button" className="btn btn-secondary" onClick={handleImportTemplate} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgba(30,41,59,0.8)', border: '1px solid #3b82f6', color: '#93c5fd' }}>
              <Download size={15} /> Importer Modèle (.algoexam)
            </button>
            <button type="button" className="btn btn-primary" onClick={openCreate} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <FilePlus size={16} /> Créer un Nouveau Sujet
            </button>
          </div>
        ) : (
          <div style={{ display: 'flex', gap: '12px' }}>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => toggleAllSections(!areAllSectionsCollapsed)}
              style={{ padding: '8px 14px', fontSize: '0.82rem', borderColor: '#a78bfa', color: '#c4b5fd' }}
            >
              {areAllSectionsCollapsed ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
              {areAllSectionsCollapsed ? 'Tout Déplier les Sections' : 'Tout Réduire'}
            </button>
            <button type="button" className="btn btn-secondary" onClick={() => setView('LIST')}>
              Annuler & Retourner aux Sujets
            </button>
          </div>
        )}
      </div>

      {view === 'LIST' ? (
        /* ── VIEW 1: EXAM LIST ── */
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <div>
              <h2 style={{ fontSize: '1.5rem', fontWeight: '800', margin: 0 }}>📑 Gestion des Sujets d'Examen & Modèles (.algoexam)</h2>
              <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                {exams.length} modèle(s) de sujet configuré(s) • Créez et exportez vos épreuves sans données étudiants.
              </span>
            </div>
            <button type="button" className="btn btn-secondary" onClick={loadAll} disabled={loading}>
              <RefreshCw size={14} className={loading ? 'spin' : ''} /> Actualiser
            </button>
          </div>

          {loading ? (
            <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>Chargement des examens...</div>
          ) : exams.length === 0 ? (
            <div className="glass-panel" style={{ padding: '40px', textAlign: 'center' }}>
              <FlaskConical size={48} color="var(--text-muted)" style={{ marginBottom: '12px' }} />
              <h3>Aucun Examen Trouvé</h3>
              <p style={{ color: 'var(--text-muted)', marginBottom: '20px' }}>Créez votre première épreuve d'algorithmique.</p>
              <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                <button type="button" className="btn btn-secondary" onClick={handleImportTemplate}>
                  <Download size={16} /> Importer un Modèle (.algoexam)
                </button>
                <button type="button" className="btn btn-primary" onClick={openCreate}>
                  <Plus size={16} /> Créer un Examen
                </button>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {exams.map(exam => {
                const statusMeta = STATUS_LABELS[exam.status] || { label: exam.status, cls: 'badge-secondary' };
                const isExpanded = expandedExamId === exam.id;
                const probCount = exam._count?.problems || exam.problems?.length || 0;
                const stCount = exam._count?.assignments || exam.assignments?.length || 0;

                return (
                  <div key={exam.id} className="glass-panel" style={{ padding: '20px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <strong style={{ fontSize: '1.1rem', color: '#f8fafc' }}>{exam.title}</strong>
                            <span className={`badge ${statusMeta.cls}`}>{statusMeta.label}</span>
                          </div>
                          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px', display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
                            <span><strong>Module :</strong> {exam.module || 'ASD'}</span>
                            <span><strong>Session :</strong> {exam.session || 'S1'}</span>
                            <span><strong>Date :</strong> {exam.startTime ? new Date(exam.startTime).toLocaleDateString('fr-FR') : '—'}</span>
                            <span><strong>Durée :</strong> {exam.durationMinutes} min</span>
                            {exam.room && <span><strong>Salle :</strong> <span style={{ color: '#34d399' }}>{exam.room}</span></span>}
                          </div>
                        </div>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        {exam.status !== 'FINISHED' && exam.status !== 'CLOSED' && (
                          <button
                            type="button"
                            className="btn btn-success"
                            style={{ padding: '6px 12px', fontSize: '0.8rem', fontWeight: '700', background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', display: 'flex', alignItems: 'center', gap: '5px' }}
                            onClick={() => handleLaunchRoomExam(exam)}
                            title="Lancer cette épreuve pour une salle spécifique avec les étudiants"
                          >
                            <Play size={13} fill="#fff" /> Lancer Salle
                          </button>
                        )}
                        <button type="button" className="btn btn-secondary" style={{ padding: '6px 10px', fontSize: '0.8rem', color: '#38bdf8', background: 'rgba(30,41,59,0.8)', border: '1px solid #0284c7' }} onClick={() => handleExportTemplate(exam.id, exam.title)} title="Exporter la structure du modèle d'épreuve (.algoexam)">
                          <FileCode size={13} /> Modèle
                        </button>
                        <button type="button" className="btn btn-secondary" style={{ padding: '6px 10px', fontSize: '0.8rem', color: '#93c5fd', background: 'rgba(30,41,59,0.8)', border: '1px solid #334155' }} onClick={() => handleExportBundle(exam.id, exam.title)} title="Exporter le paquet de soumissions chiffré (.algobundle)">
                          <Package size={13} /> Paquet
                        </button>
                        <button type="button" className="btn btn-secondary" style={{ padding: '6px 10px', fontSize: '0.8rem', color: '#a78bfa', background: 'rgba(30,41,59,0.8)', border: '1px solid #334155' }} onClick={() => handleImportBundles(exam.id, exam.title)} title="Importer et fusionner des paquets de salles déconnectées">
                          <Upload size={13} /> Fusionner
                        </button>
                        <button type="button" className="btn btn-secondary" style={{ padding: '6px 12px', fontSize: '0.82rem' }} onClick={() => setExpandedExamId(isExpanded ? null : exam.id)}>
                          {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />} {probCount} Ex. / {stCount} Étud.
                        </button>
                        {['FINISHED', 'COMPLETED', 'ARCHIVED'].includes(exam.status) ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <span style={{ fontSize: '0.8rem', color: '#f87171', background: 'rgba(239,68,68,0.12)', padding: '4px 10px', borderRadius: '12px', border: '1px solid rgba(239,68,68,0.3)', fontWeight: '700' }}>
                              🔒 Terminé
                            </span>
                            <button type="button" className="btn btn-danger" style={{ padding: '6px 10px' }} onClick={() => handleDeleteExam(exam.id, exam.title)} title="Supprimer cet examen">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        ) : (
                          <>
                            <button type="button" className="btn btn-secondary" style={{ padding: '6px 12px', fontSize: '0.82rem' }} onClick={() => openEdit(exam)}>
                              <Pencil size={14} /> Modifier
                            </button>
                            <button type="button" className="btn btn-danger" style={{ padding: '6px 10px' }} onClick={() => handleDeleteExam(exam.id, exam.title)} title="Supprimer cet examen">
                              <Trash2 size={14} />
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    {isExpanded && (
                      <div style={{ marginTop: '16px', paddingTop: '14px', borderTop: '1px solid var(--panel-border)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                        <div>
                          <strong style={{ fontSize: '0.85rem', color: '#60a5fa', display: 'block', marginBottom: '8px' }}>
                            📚 Exercices Sélectionnés ({probCount}) :
                          </strong>
                          <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                            {exam.problems?.map((p, idx) => (
                              <li key={idx}>
                                {p.problem?.title || `Problème #${idx + 1}`} ({p.points} Pts)
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <strong style={{ fontSize: '0.85rem', color: '#34d399', display: 'block', marginBottom: '8px' }}>
                            👨‍🎓 Étudiants Assignés ({stCount}) :
                          </strong>
                          <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                            {stCount} étudiants inscrits à cette épreuve.
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* ── VIEW 2: CREATE / EDIT EXAM FORM (ALL SECTIONS COLLAPSIBLE) ── */
        <form onSubmit={handleSubmit}>
          <div style={{
            position: 'sticky', top: 0, zIndex: 100,
            background: 'rgba(5, 7, 13, 0.96)', backdropFilter: 'blur(10px)',
            padding: '14px 24px', marginBottom: '20px', borderRadius: '12px',
            border: '1px solid var(--panel-border)', display: 'flex',
            justifyContent: 'space-between', alignItems: 'center'
          }}>
            <div>
              <h2 style={{ fontSize: '1.4rem', fontWeight: '800', margin: 0 }}>
                {editingExam ? `✏️ Modification de : ${editingExam.title}` : '📝 Création d\'une Nouvelle Épreuve'}
              </h2>
              <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                Configurez l'identité, les barèmes, la sécurité anti-triche et les droits des étudiants
              </span>
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button type="button" className="btn btn-secondary" onClick={() => setView('LIST')} style={{ padding: '8px 18px', fontSize: '0.85rem' }}>
                Annuler
              </button>
              <button type="submit" className="btn btn-primary" style={{ padding: '8px 24px', fontWeight: '700', fontSize: '0.85rem' }}>
                {editingExam ? '💾 Enregistrer' : '🚀 Créer l\'Épreuve'}
              </button>
            </div>
          </div>

          {/* SECTION 1: Identité & Métadonnées */}
          <div className="glass-panel" style={{ padding: '20px 26px', marginBottom: '18px' }}>
            <div 
              onClick={() => toggleSection('sec1')}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Building size={20} color="#60a5fa" />
                <h3 style={{ fontSize: '1.15rem', margin: 0 }}>1. Identité de l'Épreuve & Établissement</h3>
                {collapsedSections.sec1 && (
                  <span style={{ fontSize: '0.8rem', color: '#60a5fa', background: 'rgba(96,165,250,0.12)', padding: '3px 10px', borderRadius: '12px', border: '1px solid rgba(96,165,250,0.3)', fontWeight: '600' }}>
                    📌 {formData.title || 'Titre non défini'} • {formData.module || 'ASD'} • {formData.session}
                  </span>
                )}
              </div>
              {collapsedSections.sec1 ? <ChevronRight size={18} color="#60a5fa" /> : <ChevronDown size={18} color="#60a5fa" />}
            </div>

            {!collapsedSections.sec1 && (
              <div style={{ marginTop: '18px', paddingTop: '16px', borderTop: '1px solid var(--panel-border)' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Titre de l'Examen *</label>
                    <input type="text" className="form-input" required placeholder="ex: Examen Final - Algorithmique" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Session Académique</label>
                    <input type="text" className="form-input" value={formData.session} onChange={e => setFormData({ ...formData, session: e.target.value })} />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1.2fr 1fr 1fr', gap: '16px' }}>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Université / École</label>
                    <input type="text" className="form-input" value={formData.university} onChange={e => setFormData({ ...formData, university: e.target.value })} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Module / Matière</label>
                    <input type="text" className="form-input" value={formData.module} onChange={e => setFormData({ ...formData, module: e.target.value })} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Code Épreuve (Unique)</label>
                    <input type="text" className="form-input" placeholder="Ex: ALGO31082026" value={formData.examCode || ''} onChange={e => setFormData({ ...formData, examCode: e.target.value.toUpperCase() })} style={{ fontWeight: '700', color: '#c4b5fd' }} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Préfixe Clé (Média)</label>
                    <input id="prefix-input" type="text" className="form-input" value={formData.prefix} onChange={e => setFormData({ ...formData, prefix: e.target.value })} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* SECTION 2: Horaires & Durée */}
          <div className="glass-panel" style={{ padding: '20px 26px', marginBottom: '18px' }}>
            <div 
              onClick={() => toggleSection('sec2')}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Clock size={20} color="#34d399" />
                <h3 style={{ fontSize: '1.15rem', margin: 0 }}>2. Horaires & Durée de l'Épreuve</h3>
                {collapsedSections.sec2 && (
                  <span style={{ fontSize: '0.8rem', color: '#34d399', background: 'rgba(52,211,153,0.12)', padding: '3px 10px', borderRadius: '12px', border: '1px solid rgba(52,211,153,0.3)', fontWeight: '600' }}>
                    ⏱️ {formData.date} @ {formData.startTime} ({formData.durationMinutes} min)
                  </span>
                )}
              </div>
              {collapsedSections.sec2 ? <ChevronRight size={18} color="#34d399" /> : <ChevronDown size={18} color="#34d399" />}
            </div>

            {!collapsedSections.sec2 && (
              <div style={{ marginTop: '18px', paddingTop: '16px', borderTop: '1px solid var(--panel-border)' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Date de l'Épreuve</label>
                    <input type="date" className="form-input" required value={formData.date} onChange={e => setFormData({ ...formData, date: e.target.value })} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Heure de Début</label>
                    <input type="time" className="form-input" required value={formData.startTime} onChange={e => setFormData({ ...formData, startTime: e.target.value })} />
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label style={{ fontSize: '0.85rem', fontWeight: '600' }}>Durée (Minutes)</label>
                    <input type="number" className="form-input" required min={5} max={360} value={formData.durationMinutes} onChange={e => setFormData({ ...formData, durationMinutes: e.target.value })} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* SECTION 3: Sélection des Exercices (Minimisable par Chapitre) */}
          <div className="glass-panel" style={{ padding: '20px 26px', marginBottom: '18px' }}>
            <div 
              onClick={() => toggleSection('sec3')}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <BookOpen size={20} color="#a78bfa" />
                <h3 style={{ fontSize: '1.15rem', margin: 0 }}>3. Exercices & Attribution du Barème</h3>
                {collapsedSections.sec3 && (
                  <span style={{ fontSize: '0.8rem', color: '#a78bfa', background: 'rgba(167,139,250,0.12)', padding: '3px 10px', borderRadius: '12px', border: '1px solid rgba(167,139,250,0.3)', fontWeight: '600' }}>
                    📚 {Object.keys(selectedProblemsMap).length} Exercice(s) ({totalExamPoints}/20 pts)
                  </span>
                )}
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }} onClick={e => e.stopPropagation()}>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    style={{ padding: '6px 14px', fontSize: '0.82rem', borderColor: '#a78bfa', color: '#c4b5fd' }}
                    onClick={() => setIsStudioOpen(true)}
                  >
                    <Plus size={15} /> Nouveau Problème (Studio)
                  </button>

                  <div style={{
                    display: 'flex', alignItems: 'center', gap: '8px',
                    padding: '6px 14px', borderRadius: '20px', fontSize: '0.88rem', fontWeight: '700',
                    background: totalExamPoints === 20 ? 'rgba(16, 185, 129, 0.2)' : 'rgba(245, 158, 11, 0.2)',
                    border: totalExamPoints === 20 ? '1px solid #10b981' : '1px solid #f59e0b',
                    color: totalExamPoints === 20 ? '#34d399' : '#fbbf24'
                  }}>
                    {totalExamPoints === 20 ? <Check size={16} /> : <AlertTriangle size={16} style={{ flexShrink: 0 }} />}
                    Total Barème : {totalExamPoints} / 20 pts
                  </div>
                </div>

                {collapsedSections.sec3 ? <ChevronRight size={18} color="#a78bfa" /> : <ChevronDown size={18} color="#a78bfa" />}
              </div>
            </div>

            {!collapsedSections.sec3 && (
              <div style={{ marginTop: '18px', paddingTop: '16px', borderTop: '1px solid var(--panel-border)' }}>
                {/* Filter Bar for Exercises */}
                <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
                  <div style={{ position: 'relative', flex: 1 }}>
                    <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Rechercher un exercice par nom..."
                      style={{ paddingLeft: '34px', fontSize: '0.85rem' }}
                      value={probSearch}
                      onChange={e => setProbSearch(e.target.value)}
                    />
                  </div>

                  <select
                    className="form-input"
                    style={{ width: '220px', fontSize: '0.85rem' }}
                    value={selectedTopicFilter}
                    onChange={e => setSelectedTopicFilter(e.target.value)}
                  >
                    <option value="ALL">Tous les Chapitres</option>
                    {ALGO_CHAPTERS.map(ch => (
                      <option key={ch.id} value={ch.title}>{ch.title}</option>
                    ))}
                  </select>
                </div>

                {Object.keys(problemsByTopic).length === 0 ? (
                  <p style={{ color: 'var(--text-muted)' }}>Aucun exercice ne correspond aux filtres.</p>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    {Object.entries(problemsByTopic).map(([topicName, topicProbs]) => {
                      const isTopicCollapsed = isExamChapterCollapsed(topicName);
                      const selectedInTopic = topicProbs.filter(p => selectedProblemsMap[p.id] !== undefined).length;

                      return (
                        <div
                          key={topicName}
                          style={{
                            background: selectedInTopic > 0 ? 'rgba(16, 185, 129, 0.12)' : 'rgba(15, 23, 42, 0.6)',
                            padding: '14px 18px',
                            borderRadius: '10px',
                            border: selectedInTopic > 0 ? '1px solid rgba(16, 185, 129, 0.45)' : '1px solid rgba(255,255,255,0.08)',
                            transition: 'all 0.2s ease'
                          }}
                        >
                          <div 
                            onClick={() => toggleExamChapter(topicName)}
                            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
                          >
                            <div style={{
                              fontSize: '0.95rem',
                              fontWeight: '800',
                              color: selectedInTopic > 0 ? '#34d399' : '#c084fc',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px'
                            }}>
                              <Layers size={16} color={selectedInTopic > 0 ? '#34d399' : '#c084fc'} />
                              {topicName} ({topicProbs.length} exercice(s) {selectedInTopic > 0 ? `• ${selectedInTopic} sélectionné(s)` : ''})
                            </div>
                            <button
                              type="button"
                              className="btn btn-secondary"
                              style={{
                                padding: '2px 8px',
                                border: 'none',
                                background: selectedInTopic > 0 ? 'rgba(16, 185, 129, 0.2)' : 'transparent',
                                color: selectedInTopic > 0 ? '#34d399' : '#c084fc'
                              }}
                            >
                              {isTopicCollapsed ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
                            </button>
                          </div>

                          {!isTopicCollapsed && (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '12px', paddingTop: '10px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                              {topicProbs.map(p => {
                                const isSelected = selectedProblemsMap[p.id] !== undefined;
                                const currentPts = isSelected ? selectedProblemsMap[p.id] : (p.points || 5);
                                const diffMeta = DIFFICULTY_CONFIG[p.difficulty?.toUpperCase()] || DIFFICULTY_CONFIG.MOYEN;
                                const qList = p.questions || [{ id: 'q1', orderIndex: 1, statement: p.description }];
                                const weights = problemWeightsMap[p.id] || { weightTest: 40, weightAst: 60, weightAi: 0 };
                                const sumWeight = (parseInt(weights.weightTest, 10) || 0) + (parseInt(weights.weightAst, 10) || 0) + (parseInt(weights.weightAi, 10) || 0);

                                return (
                                  <div
                                    key={p.id}
                                    style={{
                                      padding: '16px 20px', borderRadius: '10px',
                                      border: isSelected ? '1px solid #8b5cf6' : '1px solid var(--panel-border)',
                                      background: isSelected ? 'rgba(139, 92, 246, 0.12)' : 'rgba(0,0,0,0.2)',
                                      display: 'flex', flexDirection: 'column', gap: '12px'
                                    }}
                                  >
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
                                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1, cursor: 'pointer' }} onClick={() => handleToggleProblem(p)}>
                                        <input type="checkbox" checked={isSelected} onChange={() => {}} style={{ cursor: 'pointer', width: '18px', height: '18px' }} />
                                        <div>
                                          <strong style={{ fontSize: '0.98rem', display: 'block', color: '#f8fafc' }}>{p.title}</strong>
                                          <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginTop: '4px' }}>
                                            <span style={{ fontSize: '0.72rem', fontWeight: '700', padding: '2px 8px', borderRadius: '4px', background: diffMeta.bg, color: diffMeta.color, border: `1px solid ${diffMeta.border}` }}>
                                              {diffMeta.label}
                                            </span>
                                            <span className="badge badge-blue" style={{ fontSize: '0.72rem' }}>
                                              {qList.length === 1 ? '1 Question Unique' : `${qList.length} Sous-Questions`}
                                            </span>
                                            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                              {p.testCases ? `${p.testCases.length} Tests` : 'Sans Tests'}
                                            </span>
                                          </div>
                                        </div>
                                      </div>

                                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }} onClick={e => e.stopPropagation()}>
                                        <button
                                          type="button"
                                          className="btn btn-secondary"
                                          style={{ padding: '4px 8px', fontSize: '0.75rem', borderColor: 'rgba(192,132,252,0.4)', color: '#c084fc', display: 'flex', alignItems: 'center', gap: '4px' }}
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setEditingProblem(p);
                                            setIsStudioOpen(true);
                                          }}
                                          title="Modifier cet exercice dans le Studio"
                                        >
                                          <Pencil size={12} /> Modifier
                                        </button>

                                        {isSelected && qList.length === 1 && (
                                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                            <label style={{ fontSize: '0.8rem', color: '#c4b5fd', fontWeight: '600' }}>Points :</label>
                                            <input
                                              type="number" min={1} max={20}
                                              value={currentPts}
                                              onChange={e => handleUpdateProblemPoints(p.id, e.target.value)}
                                              style={{
                                                width: '54px', padding: '4px 8px', borderRadius: '6px',
                                                background: '#111827', border: '1px solid #8b5cf6',
                                                color: '#fff', fontSize: '0.88rem', fontWeight: '700', textAlign: 'center'
                                              }}
                                            />
                                          </div>
                                        )}
                                      </div>
                                    </div>

                                    {/* Multi-Questions Point Breakdown */}
                                    {isSelected && qList.length > 1 && (
                                      <div style={{ background: '#0b1120', padding: '12px 16px', borderRadius: '8px', border: '1px solid rgba(167, 139, 250, 0.25)' }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                                          <span style={{ fontSize: '0.82rem', fontWeight: '700', color: '#a78bfa' }}>
                                            📝 Répartition des Points par Sous-Question (Total: {currentPts} pts) :
                                          </span>
                                        </div>
                                        <div style={{ display: 'grid', gridTemplateColumns: `repeat(auto-fill, minmax(180px, 1fr))`, gap: '10px' }}>
                                          {qList.map((q, idx) => {
                                            const qKey = q.id || q.orderIndex;
                                            const qPts = questionPointsMap[p.id]?.[qKey] ?? Math.max(1, Math.floor(currentPts / qList.length));
                                            return (
                                              <div key={qKey || idx} style={{ background: 'rgba(15, 23, 42, 0.8)', padding: '6px 12px', borderRadius: '6px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', border: '1px solid rgba(255,255,255,0.08)' }}>
                                                <span style={{ fontSize: '0.78rem', color: '#cbd5e1' }}>Q{q.orderIndex || (idx + 1)} :</span>
                                                <input
                                                  type="number" min={1} max={20}
                                                  value={qPts}
                                                  onChange={e => handleUpdateQuestionPoints(p.id, qKey, e.target.value)}
                                                  style={{ width: '48px', padding: '2px 6px', background: '#1e293b', border: '1px solid #60a5fa', borderRadius: '4px', color: '#fff', fontSize: '0.82rem', fontWeight: '700', textAlign: 'center' }}
                                                />
                                              </div>
                                            );
                                          })}
                                        </div>
                                      </div>
                                    )}

                                    {/* Tripartite Weights Row */}
                                    {isSelected && (
                                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(15, 23, 42, 0.6)', padding: '8px 14px', borderRadius: '6px', border: '1px solid rgba(255,255,255,0.06)', flexWrap: 'wrap', gap: '8px' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
                                          <span style={{ fontSize: '0.78rem', fontWeight: '700', color: '#94a3b8' }}>⚖️ Pondération :</span>
                                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                            <span style={{ fontSize: '0.75rem', color: '#60a5fa' }}>🧪 Tests :</span>
                                            <input
                                              type="number" min={0} max={100}
                                              value={weights.weightTest}
                                              onChange={e => handleUpdateProblemWeight(p.id, 'weightTest', e.target.value)}
                                              style={{ width: '44px', padding: '2px 4px', background: '#111827', border: '1px solid rgba(96,165,250,0.4)', borderRadius: '4px', color: '#fff', fontSize: '0.78rem', textAlign: 'center' }}
                                            />
                                            <span style={{ fontSize: '0.72rem', color: '#94a3b8' }}>%</span>
                                          </div>
                                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                            <span style={{ fontSize: '0.75rem', color: '#a78bfa' }}>🌳 AST :</span>
                                            <input
                                              type="number" min={0} max={100}
                                              value={weights.weightAst}
                                              onChange={e => handleUpdateProblemWeight(p.id, 'weightAst', e.target.value)}
                                              style={{ width: '44px', padding: '2px 4px', background: '#111827', border: '1px solid rgba(167,139,250,0.4)', borderRadius: '4px', color: '#fff', fontSize: '0.78rem', textAlign: 'center' }}
                                            />
                                            <span style={{ fontSize: '0.72rem', color: '#94a3b8' }}>%</span>
                                          </div>
                                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                            <span style={{ fontSize: '0.75rem', color: '#cbd5e1' }}>🤖 IA :</span>
                                            <input
                                              type="number" min={0} max={100}
                                              value={weights.weightAi}
                                              onChange={e => handleUpdateProblemWeight(p.id, 'weightAi', e.target.value)}
                                              style={{ width: '44px', padding: '2px 4px', background: '#111827', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '4px', color: '#fff', fontSize: '0.78rem', textAlign: 'center' }}
                                            />
                                            <span style={{ fontSize: '0.72rem', color: '#94a3b8' }}>%</span>
                                          </div>
                                        </div>

                                        <span className={`badge ${sumWeight === 100 ? 'badge-green' : 'badge-red'}`} style={{ fontSize: '0.72rem' }}>
                                          {sumWeight === 100 ? '✅ 100% OK' : `⚠️ Total : ${sumWeight}%`}
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* SECTION 4: Briques Autorisées */}
          <div className="glass-panel" style={{ padding: '20px 26px', marginBottom: '18px' }}>
            <div 
              onClick={() => toggleSection('sec4')}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Code2 size={20} color="#f43f5e" />
                <h3 style={{ fontSize: '1.15rem', margin: 0, color: '#f43f5e' }}>
                  4. Briques Algorithmiques Autorisées
                </h3>
                {collapsedSections.sec4 && (
                  <span style={{ fontSize: '0.8rem', color: '#f43f5e', background: 'rgba(244,63,94,0.12)', padding: '3px 10px', borderRadius: '12px', border: '1px solid rgba(244,63,94,0.3)', fontWeight: '600' }}>
                    🧱 {formData.allowedBricks?.length || 0} / {COMPREHENSIVE_CODE_BRICKS.length} Briques Autorisées
                  </span>
                )}
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }} onClick={e => e.stopPropagation()}>
                  <button type="button" className="btn btn-secondary" style={{ padding: '5px 12px', fontSize: '0.78rem', color: '#34d399' }} onClick={() => handleToggleAllBricks(true)}>
                    ✅ Tout Autoriser
                  </button>
                  <button type="button" className="btn btn-secondary" style={{ padding: '5px 12px', fontSize: '0.78rem', color: '#ef4444' }} onClick={() => handleToggleAllBricks(false)}>
                    🚫 Tout Bloquer
                  </button>
                </div>
                {collapsedSections.sec4 ? <ChevronRight size={18} color="#f43f5e" /> : <ChevronDown size={18} color="#f43f5e" />}
              </div>
            </div>

            {!collapsedSections.sec4 && (
              <div style={{ marginTop: '18px', paddingTop: '16px', borderTop: '1px solid var(--panel-border)' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  {ALGO_CHAPTERS.map(ch => {
                    const chBricks = COMPREHENSIVE_CODE_BRICKS.filter(b => b.chapterId === ch.id);
                    const allSelected = chBricks.every(b => formData.allowedBricks?.includes(b.id));
                    const isChCollapsed = isBrickChapterCollapsed(ch.id);
                    const countAllowedInCh = chBricks.filter(b => formData.allowedBricks?.includes(b.id)).length;

                    return (
                      <div key={ch.id} style={{ background: 'rgba(15, 23, 42, 0.6)', padding: '14px 18px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.08)' }}>
                        <div 
                          onClick={() => toggleBrickChapter(ch.id)}
                          style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
                        >
                          <span style={{ fontSize: '0.88rem', fontWeight: '700', color: '#60a5fa' }}>
                            📚 {ch.title} ({countAllowedInCh} / {chBricks.length} Autorisées)
                          </span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }} onClick={e => e.stopPropagation()}>
                            <button
                              type="button"
                              className="btn btn-secondary"
                              style={{ padding: '3px 10px', fontSize: '0.75rem' }}
                              onClick={() => handleToggleChapterBricks(ch.id, !allSelected)}
                            >
                              {allSelected ? 'Tout Désactiver Ce Chapitre' : 'Tout Autoriser Ce Chapitre'}
                            </button>
                            <button type="button" className="btn btn-secondary" style={{ padding: '2px 6px', border: 'none' }}>
                              {isChCollapsed ? <ChevronDown size={16} color="#60a5fa" /> : <ChevronUp size={16} color="#60a5fa" />}
                            </button>
                          </div>
                        </div>

                        {!isChCollapsed && (
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '12px', paddingTop: '10px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                            {chBricks.map(b => {
                              const isAllowed = formData.allowedBricks?.includes(b.id);
                              const isCustomized = customBrickSnippets[b.id] !== undefined;
                              const isCodeExpanded = !!expandedBrickCodeIds[b.id];

                              return (
                                <div key={b.id} style={{ display: 'flex', flexDirection: 'column', gap: '8px', width: '100%' }}>
                                  <div
                                    style={{
                                      padding: '8px 14px', borderRadius: '8px',
                                      border: isAllowed ? '1px solid #f43f5e' : '1px solid rgba(255,255,255,0.1)',
                                      background: isAllowed ? 'rgba(244, 63, 94, 0.16)' : 'rgba(0,0,0,0.3)',
                                      color: isAllowed ? '#ffffff' : 'var(--text-muted)',
                                      fontSize: '0.82rem', fontWeight: isAllowed ? '700' : '500',
                                      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px', transition: 'all 0.15s ease'
                                    }}
                                  >
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }} onClick={() => handleToggleSingleBrick(b.id)}>
                                      <input type="checkbox" checked={isAllowed} onChange={() => {}} style={{ cursor: 'pointer', width: '15px', height: '15px' }} />
                                      <span>{b.label}</span>
                                      {isCustomized && <span style={{ fontSize: '0.72rem', color: '#34d399', fontWeight: '800', padding: '1px 6px', background: 'rgba(52,211,153,0.15)', borderRadius: '4px', border: '1px solid rgba(52,211,153,0.3)' }}>✏️ Code Modifié</span>}
                                    </div>

                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setExpandedBrickCodeIds(prev => {
                                          const isExp = !prev[b.id];
                                          if (isExp && inlineBrickDrafts[b.id] === undefined) {
                                            const existingCustom = customBrickSnippets[b.id];
                                            setInlineBrickDrafts(d => ({ ...d, [b.id]: existingCustom !== undefined ? existingCustom : b.snippet }));
                                          }
                                          return { ...prev, [b.id]: isExp };
                                        });
                                      }}
                                      style={{
                                        background: isCodeExpanded ? 'rgba(192,132,252,0.3)' : 'rgba(255,255,255,0.1)',
                                        border: '1px solid rgba(192,132,252,0.4)', borderRadius: '6px',
                                        padding: '4px 10px', color: '#c084fc', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.75rem', fontWeight: '700'
                                      }}
                                      title={isCodeExpanded ? "Réduire l'affichage du code" : "Afficher et modifier le code de cette brique"}
                                    >
                                      {isCodeExpanded ? <ChevronUp size={14} /> : <Eye size={14} />}
                                      {isCodeExpanded ? 'Masquer Code' : 'Voir / Modifier Code'}
                                    </button>
                                  </div>

                                  {/* Inline Collapsible Code Area (Hidden until user clicks) */}
                                  {isCodeExpanded && (
                                    <div style={{
                                      padding: '14px', background: '#090d16', border: '1px solid rgba(192,132,252,0.4)',
                                      borderRadius: '8px', display: 'flex', flexDirection: 'column', gap: '10px', width: '100%'
                                    }} onClick={e => e.stopPropagation()}>
                                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <span style={{ fontSize: '0.78rem', color: '#c084fc', fontWeight: '700' }}>
                                          📝 Modèle de Code pour "{b.label}" :
                                        </span>
                                        {isCustomized && (
                                          <span style={{ fontSize: '0.72rem', color: '#34d399', fontWeight: '700' }}>
                                            ✓ Code Personnalisé Enregistré
                                          </span>
                                        )}
                                      </div>

                                      <textarea
                                        className="form-input"
                                        rows={6}
                                        style={{
                                          fontFamily: 'var(--font-mono)', fontSize: '0.8rem', background: '#030712',
                                          color: '#34d399', border: '1px solid rgba(255,255,255,0.15)', padding: '10px', borderRadius: '6px'
                                        }}
                                        value={inlineBrickDrafts[b.id] !== undefined ? inlineBrickDrafts[b.id] : (customBrickSnippets[b.id] || b.snippet)}
                                        onChange={e => setInlineBrickDrafts(prev => ({ ...prev, [b.id]: e.target.value }))}
                                      />

                                      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                                        {isCustomized && (
                                          <button
                                            type="button"
                                            className="btn btn-secondary"
                                            style={{ padding: '5px 12px', fontSize: '0.75rem', color: '#ef4444' }}
                                            onClick={() => {
                                              setCustomBrickSnippets(prev => {
                                                const next = { ...prev };
                                                delete next[b.id];
                                                return next;
                                              });
                                              setInlineBrickDrafts(prev => ({ ...prev, [b.id]: b.snippet }));
                                            }}
                                          >
                                            Réinitialiser Code d'Origine
                                          </button>
                                        )}
                                        <button
                                          type="button"
                                          className="btn btn-primary"
                                          style={{ padding: '5px 14px', fontSize: '0.78rem', fontWeight: '700', background: 'linear-gradient(135deg, #8b5cf6, #c084fc)' }}
                                          onClick={() => {
                                            const codeToSave = inlineBrickDrafts[b.id] !== undefined ? inlineBrickDrafts[b.id] : b.snippet;
                                            setCustomBrickSnippets(prev => ({ ...prev, [b.id]: codeToSave }));
                                            Swal.fire({
                                              icon: 'success',
                                              title: 'Code Enregistré !',
                                              toast: true,
                                              position: 'top-end',
                                              showConfirmButton: false,
                                              timer: 1400,
                                              background: '#0f172a',
                                              color: '#fff'
                                            });
                                          }}
                                        >
                                          💾 Enregistrer les Modifications du Code
                                        </button>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* SECTION 5: Anti-Triche */}
          <div className="glass-panel" style={{ padding: '20px 26px', marginBottom: '18px' }}>
            <div 
              onClick={() => toggleSection('sec5')}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <ShieldAlert size={20} color="#ef4444" />
                <h3 style={{ fontSize: '1.15rem', margin: 0 }}>5. Surveillance Anti-Triche</h3>
                {collapsedSections.sec5 && (
                  <span style={{ fontSize: '0.8rem', color: '#ef4444', background: 'rgba(239,68,68,0.12)', padding: '3px 10px', borderRadius: '12px', border: '1px solid rgba(239,68,68,0.3)', fontWeight: '600' }}>
                    🛡️ Copier: {formData.copyDisabled ? 'OFF' : 'ON'} | Coller: {formData.pasteDisabled ? 'OFF' : 'ON'} | Plein Écran: {formData.fullscreenRequired ? 'ON' : 'OFF'}
                  </span>
                )}
              </div>
              {collapsedSections.sec5 ? <ChevronRight size={18} color="#ef4444" /> : <ChevronDown size={18} color="#ef4444" />}
            </div>

            {!collapsedSections.sec5 && (
              <div style={{ marginTop: '18px', paddingTop: '16px', borderTop: '1px solid var(--panel-border)' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  {[
                    { key: 'copyDisabled', title: 'Désactiver le Copier (Ctrl+C)', desc: 'Empêche la copie de texte depuis l\'éditeur.' },
                    { key: 'pasteDisabled', title: 'Désactiver le Coller (Ctrl+V)', desc: 'Interdit le collage de code externe.' },
                    { key: 'fullscreenRequired', title: 'Plein Écran Obligatoire', desc: 'Bascule automatique en plein écran.' },
                    { key: 'internetWarning', title: 'Avertissement Réseau', desc: 'Signale l\'interdiction de la navigation web.' }
                  ].map(({ key, title, desc }) => (
                    <label key={key} style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', padding: '14px', borderRadius: '8px', border: '1px solid var(--panel-border)', background: 'rgba(0,0,0,0.18)', cursor: 'pointer' }}>
                      <input type="checkbox" checked={formData[key]} onChange={e => setFormData({ ...formData, [key]: e.target.checked })} style={{ marginTop: '3px', width: '16px', height: '16px' }} />
                      <div>
                        <span style={{ fontSize: '0.88rem', fontWeight: '700', display: 'block' }}>{title}</span>
                        <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{desc}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '14px', marginBottom: '40px' }}>
            <button type="button" className="btn btn-secondary" onClick={() => setView('LIST')} style={{ padding: '10px 24px' }}>
              Annuler
            </button>
            <button type="submit" className="btn btn-primary" style={{ padding: '10px 30px', fontWeight: '700' }}>
              {editingExam ? '💾 Enregistrer les Modifications' : '💾 Enregistrer le Modèle d\'Épreuve'}
            </button>
          </div>
        </form>
      )}
      {/* ── DRAG & DROP MODAL: IMPORT EXAM TEMPLATE (.algoexam) ── */}
      {isImportModalOpen && (
        <div className="fullscreen-overlay" style={{ background: 'rgba(0,0,0,0.8)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '100%', maxWidth: '520px', padding: '30px' }}>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '1.25rem', fontWeight: '800', color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Download size={20} /> Importer un Modèle d'Épreuve (.algoexam)
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '18px' }}>
              Sélectionnez ou glissez-déposez le fichier <code>.algoexam</code> pour charger la structure complète de l'examen.
            </p>

            <FileDropZone
              accept=".algoexam,.json"
              selectedFile={templateFile}
              onFileSelect={(file) => setTemplateFile(file)}
              onClear={() => setTemplateFile(null)}
              label="Glissez & déposez le fichier .algoexam ici"
              hint="ou cliquez pour parcourir vos dossiers"
            />

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => { setIsImportModalOpen(false); setTemplateFile(null); }}
                disabled={importingTemplate}
              >
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleProcessImportTemplateModal}
                disabled={!templateFile || importingTemplate}
              >
                {importingTemplate ? 'Importation en cours...' : 'Analyser & Importer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
