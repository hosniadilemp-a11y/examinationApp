# AlgoExamination — Debugging Playbook

## First Rule

Do not patch the symptom before identifying the state/data flow causing it.

## Frontend Bug

Trace:

```text
component
→ state
→ API/socket call
→ response/event
→ state update
→ rendering
```

Check browser console and network requests.

## Backend Bug

Trace:

```text
route
→ middleware
→ controller
→ service
→ Prisma
→ response/socket
```

Check server logs and actual database values.

## Socket Bug

Use the sequence:

```text
emit?
→ correct room?
→ socket connected?
→ joined room?
→ listener registered?
→ payload valid?
→ state updated?
```

## Prisma Bug

Check:
- schema field type
- nullability
- enum
- DateTime
- relation
- generated client
- actual database data

For DateTime errors, inspect whether a time-only string entered a DateTime field.

## Common Existing Failure Modes

### Invalid Date

Symptom:
```text
Prisma Validation Error
Invalid Date
```

Likely cause:
```js
new Date("14:00")
```

Fix:
use safe date + time parsing.

### ERR_REQUIRE_ESM

Symptom:
```text
require() of ES Module
```

Likely cause:
archiver version changed.

Fix:
keep CommonJS-compatible `archiver@5.3.2`.

### Teacher dashboard not updating

Likely cause:
status mutation emitted only to student room.

Fix:
emit both target command and `student_status_changed`.

### Student receives command but teacher does not update

Likely cause:
missing teacher-room broadcast.

### PDF prints black

Likely cause:
dark fill introduced in PDFKit.

Fix:
restore white/black academic rendering.

### Exercise points change unexpectedly

Likely cause:
point recalculation resets existing values.

Fix:
only allocate remaining points to the newly added exercise.

## Debugging Discipline

Before changing code:
- reproduce
- locate exact failure
- inspect logs/state
- identify invariant
- patch
- run regression checks
