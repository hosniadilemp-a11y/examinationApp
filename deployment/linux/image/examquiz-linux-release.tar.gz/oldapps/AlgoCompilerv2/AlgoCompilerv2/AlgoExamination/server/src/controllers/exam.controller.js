const prisma = require('../prisma');
const { withRetry } = require('../prisma');
const bcrypt = require('bcryptjs');
const {
  buildEncryptedExamTemplate,
  buildEncryptedSubmissionBundle,
  mergeSubmissionsIntoExam,
  buildEncryptedResultsBundle,
  mergeResultsIntoExam,
  decryptData,
  safeParseBufferToJSON,
  safeParseStringToJSON
} = require('../services/bundle-crypto.service');

// Helper to resolve an existing valid Teacher ID in the database (preventing Foreign Key violations)
async function getValidTeacherId(requestedId) {
  try {
    if (requestedId && typeof requestedId === 'string' && requestedId.trim()) {
      const found = await prisma.teacher.findUnique({ where: { id: requestedId.trim() } });
      if (found) return found.id;
    }
    const firstTeacher = await prisma.teacher.findFirst();
    if (firstTeacher) return firstTeacher.id;

    const defaultPassword = await bcrypt.hash('admin123', 10);
    const newT = await prisma.teacher.create({
      data: {
        email: 'teacher@esi.dz',
        name: 'Prof. Enseignant ASD',
        role: 'TEACHER',
        password: defaultPassword
      }
    });
    return newT.id;
  } catch (err) {
    console.error('getValidTeacherId error:', err);
    const fallback = await prisma.teacher.findFirst();
    return fallback ? fallback.id : '';
  }
}

// List exams for teacher
async function listExams(req, res) {
  try {
    const exams = await withRetry(() => prisma.exam.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        assignments: {
          select: {
            id: true,
            gradingStatus: true,
            finalScore: true,
            room: true
          }
        },
        _count: {
          select: {
            assignments: true,
            problems: true
          }
        }
      }
    }));

    const enriched = exams.map(e => {
      const distinctRooms = [...new Set((e.assignments || []).map(a => a.room).filter(Boolean))];
      if (e.room && !distinctRooms.includes(e.room)) {
        distinctRooms.unshift(e.room);
      }
      return {
        ...e,
        distinctRooms
      };
    });

    return res.json(enriched);
  } catch (err) {
    console.error('listExams error:', err);
    return res.status(500).json({ error: 'Failed to fetch exams' });
  }
}

// Get detailed single exam with problems and student status
async function getExamDetails(req, res) {
  try {
    const { id } = req.params;
    const exam = await withRetry(() => prisma.exam.findUnique({
      where: { id },
      include: {
        problems: {
          include: {
            problem: {
              include: {
                testCases: true,
                questions: { orderBy: { orderIndex: 'asc' } }
              }
            }
          },
          orderBy: { orderIndex: 'asc' }
        },
        assignments: {
          include: {
            student: true
          },
          orderBy: { accessNumber: 'asc' }
        },
        announcements: { orderBy: { createdAt: 'desc' } },
        incidents: { orderBy: { createdAt: 'desc' } }
      }
    }));

    if (!exam) {
      return res.status(404).json({ error: 'Exam not found' });
    }

    return res.json(exam);
  } catch (err) {
    console.error('getExamDetails error:', err);
    return res.status(500).json({ error: 'Failed to fetch exam details' });
  }
}

// Helper: Generate Default Exam Code (e.g. ALGO31082026)
function generateDefaultExamCode(date = new Date()) {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `ALGO${day}${month}${year}`;
}

// Helper: Sanitize Room Name to a clean short prefix (e.g. "A 12" -> "A12", "Amphi 1" -> "Am1", "Salle 101" -> "S101")
function sanitizeRoomCode(room) {
  if (!room || typeof room !== 'string') return 'A1';
  const str = room.trim();
  // Match "Amphi 1" / "Amphi A" / "Amphithéâtre 1" -> "Am1", "AmA"
  const amphiMatch = str.match(/^amphi(?:th[ée][âa]tre)?\s*([a-z0-9]+)/i);
  if (amphiMatch) {
    return `Am${amphiMatch[1]}`;
  }
  // Match "Salle 101" -> "S101"
  const salleMatch = str.match(/^salle\s*([a-z0-9]+)/i);
  if (salleMatch) {
    return `S${salleMatch[1]}`;
  }
  // Match "Labo 3" -> "L3"
  const laboMatch = str.match(/^labo(?:ratoire)?\s*([a-z0-9]+)/i);
  if (laboMatch) {
    return `L${laboMatch[1]}`;
  }
  // Otherwise strip spaces and hyphens: "A 12" -> "A12", "B 04" -> "B04"
  let clean = str.replace(/[\s\-_]/g, '');
  clean = clean.replace(/[^a-zA-Z0-9]/g, '');
  return clean || 'A1';
}

function generateRandomizedNumbers(count) {
  const maxRange = Math.max(100, count * 3);
  const pool = [];
  for (let i = 1; i <= maxRange; i++) {
    pool.push(i);
  }
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, count).map(n => String(n).padStart(3, '0'));
}

function parseSafeDate(dateVal, timeVal) {
  let parsedDate = null;
  let parsedStartTime = null;

  if (dateVal) {
    const d = new Date(dateVal);
    if (!isNaN(d.getTime())) parsedDate = d;
  }

  if (timeVal) {
    if (typeof timeVal === 'string' && /^\d{1,2}:\d{2}$/.test(timeVal.trim())) {
      const dateStr = dateVal || new Date().toISOString().split('T')[0];
      const st = new Date(`${dateStr}T${timeVal.trim()}:00`);
      if (!isNaN(st.getTime())) parsedStartTime = st;
    } else {
      const st = new Date(timeVal);
      if (!isNaN(st.getTime())) parsedStartTime = st;
    }
  }

  return { parsedDate, parsedStartTime };
}

async function createExam(req, res) {
  try {
    const {
      title,
      description,
      university,
      module,
      session,
      date,
      startTime,
      durationMinutes,
      examCode,
      prefix,
      maxViolationsAllowed,
      copyDisabled,
      pasteDisabled,
      fullscreenRequired,
      internetWarning,
      allowedLanguages,
      problems: problemsPayload, // [{id, points}] or [id]
      problemIds,               // legacy plain-id array
      studentIds
    } = req.body;

    if (!title || !durationMinutes) {
      return res.status(400).json({ error: 'Title and durationMinutes are required' });
    }

    const teacherId = await getValidTeacherId(req.teacher?.teacherId || req.teacher?.id);

    const { parsedDate, parsedStartTime } = parseSafeDate(date, startTime);

    const cleanPrefix = (prefix || 'AL').trim().toUpperCase();
    const cleanExamCode = examCode && typeof examCode === 'string' && examCode.trim()
      ? examCode.trim().toUpperCase()
      : generateDefaultExamCode(parsedDate || new Date());

    const exam = await prisma.exam.create({
      data: {
        title,
        description: description || '',
        university: university || null,
        module: module || null,
        session: session || null,
        date: parsedDate,
        startTime: parsedStartTime,
        durationMinutes: parseInt(durationMinutes, 10),
        status: 'DRAFT',
        examCode: cleanExamCode,
        prefix: cleanPrefix,
        maxViolationsAllowed: maxViolationsAllowed ? parseInt(maxViolationsAllowed, 10) : 4,
        copyDisabled: copyDisabled === true,
        pasteDisabled: pasteDisabled === true,
        fullscreenRequired: fullscreenRequired !== false,
        internetWarning: internetWarning !== false,
        allowCodeBricks: req.body.allowCodeBricks !== false,
        allowedBricks: Array.isArray(req.body.allowedBricks) ? req.body.allowedBricks : ["LIRE_TAB", "AFFICHER_TAB", "LIRE_MATRICE", "AFFICHER_MATRICE", "RECHERCHE_MAX", "TRI_BULLES"],
        allowedLanguages: allowedLanguages || ['ALGO'],
        teacherId
      }
    });

    // Support both [{problemId, points}], [{id, points}], and plain [id] problem lists
    const normalizedProblems = Array.isArray(problemsPayload) && problemsPayload.length > 0
      ? problemsPayload
      : Array.isArray(problemIds) ? problemIds.map(id => ({ id })) : [];

    for (let i = 0; i < normalizedProblems.length; i++) {
      const p = normalizedProblems[i];
      const pid = typeof p === 'string' ? p : (p.problemId || p.id);
      const pts = typeof p === 'object' && p.points != null ? parseInt(p.points, 10) : 10;
      const wTest = p.weightTest !== undefined ? parseInt(p.weightTest, 10) : 40;
      const wAst = p.weightAst !== undefined ? parseInt(p.weightAst, 10) : 60;
      const wAi = p.weightAi !== undefined ? parseInt(p.weightAi, 10) : 0;

      if (wTest + wAst + wAi !== 100) {
        return res.status(400).json({
          error: `La somme des pondérations de l'exercice doit être égale à 100% (actuel: ${wTest}% + ${wAst}% + ${wAi}% = ${wTest + wAst + wAi}%).`
        });
      }

      if (pid) {
        await prisma.examProblem.create({
          data: {
            examId: exam.id,
            problemId: pid,
            orderIndex: i + 1,
            points: pts,
            weightTest: wTest,
            weightAst: wAst,
            weightAi: wAi,
            questionPoints: p.questionPoints || {}
          }
        });
      }
    }

    // Assign students if provided
    if (Array.isArray(studentIds) && studentIds.length > 0) {
      await assignStudentsToExam(exam.id, studentIds, exam.prefix);
    }

    return res.status(201).json(exam);
  } catch (err) {
    console.error('createExam error:', err);
    return res.status(500).json({ error: 'Failed to create exam' });
  }
}

// Update Exam Status (SCHEDULED, WAITING, RUNNING, PAUSED, FINISHED, CLOSED)
async function updateExamStatus(req, res) {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const allowed = ['DRAFT', 'SCHEDULED', 'WAITING', 'RUNNING', 'PAUSED', 'FINISHED', 'CLOSED'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ error: 'Invalid exam status' });
    }

    const updateData = { status };

    if (status === 'RUNNING') {
      const existing = await prisma.exam.findUnique({ where: { id } });
      if (!existing.startTime) {
        updateData.startTime = new Date();
      } else if (existing.status === 'PAUSED' && existing.updatedAt) {
        // Compensate the paused period so students do not lose exam time while paused
        const pauseElapsedMs = Math.max(0, Date.now() - new Date(existing.updatedAt).getTime());
        updateData.startTime = new Date(new Date(existing.startTime).getTime() + pauseElapsedMs);
      }

      // Move all WAITING students to IN_EXAM
      await prisma.examAssignment.updateMany({
        where: { examId: id, status: 'WAITING' },
        data: { status: 'IN_EXAM', startedAt: new Date() }
      });
    }

    if (status === 'FINISHED' || status === 'CLOSED') {
      // Transition all active students to FINISHED and mark them offline
      await prisma.examAssignment.updateMany({
        where: { examId: id, status: { in: ['IN_EXAM', 'WAITING', 'DISCONNECTED', 'PAUSED'] } },
        data: { status: 'FINISHED', finishedAt: new Date(), isOnline: false }
      });
    }

    const updated = await prisma.exam.update({ where: { id }, data: updateData });

    // Socket broadcasts
    if (req.io) {
      req.io.to(`exam_${id}`).emit('exam_status_changed', { status, startTime: updated.startTime });

      if (status === 'RUNNING') {
        req.io.to(`exam_${id}`).emit('exam_started', { startTime: updated.startTime });
      }

      if (status === 'FINISHED' || status === 'CLOSED') {
        // Broadcast to ALL clients in room — students will redirect themselves
        req.io.to(`exam_${id}`).emit('exam_force_ended', {
          reason: "L'enseignant a mis fin à l'examen. Votre session est terminée."
        });
      }

      if (status === 'PAUSED') {
        req.io.to(`exam_${id}`).emit('exam_paused_by_teacher', {
          reason: "L'examen a été suspendu par l'enseignant. Attendez la reprise."
        });
      }
    }

    return res.json(updated);
  } catch (err) {
    console.error('updateExamStatus error:', err);
    return res.status(500).json({ error: 'Failed to update exam status' });
  }
}

// Teacher Emergency Controls (Extend time, pause, unlock student, terminate student)
async function teacherEmergencyControl(req, res) {
  try {
    const { id: examId } = req.params;
    const { action, studentId, extensionMinutes, message } = req.body;

    const exam = await prisma.exam.findUnique({ where: { id: examId } });
    if (!exam) return res.status(404).json({ error: 'Exam not found' });

    if (action === 'EXTEND_TIME_ALL') {
      const addedMs = (parseInt(extensionMinutes, 10) || 5) * 60 * 1000;
      await prisma.examAssignment.updateMany({
        where: { examId },
        data: { timeExtendedMs: { increment: addedMs } }
      });

      if (req.io) {
        req.io.to(`exam_${examId}`).emit('time_extended', { addedMs, extensionMinutes });
      }

      return res.json({ success: true, message: `Extended exam time by ${extensionMinutes} mins for all students` });
    }

    if (action === 'EXTEND_TIME_STUDENT' && studentId) {
      const addedMs = (parseInt(extensionMinutes, 10) || 5) * 60 * 1000;
      const updatedAssignment = await prisma.examAssignment.update({
        where: { examId_studentId: { examId, studentId } },
        data: {
          timeExtendedMs: { increment: addedMs },
          status: 'IN_EXAM',
          finishedAt: null
        },
        include: { student: true }
      });

      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_time_extended', { addedMs, extensionMinutes });
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: updatedAssignment.accessNumber,
          studentName: `${updatedAssignment.student?.firstName || ''} ${updatedAssignment.student?.lastName || ''}`,
          status: 'IN_EXAM',
          isOnline: updatedAssignment.isOnline
        });
      }

      return res.json({ success: true, message: `Extended time by ${extensionMinutes} mins for student` });
    }

    if (action === 'LOCK_STUDENT' && studentId) {
      const assignment = await prisma.examAssignment.update({
        where: { examId_studentId: { examId, studentId } },
        data: { status: 'PAUSED', pausedUntil: null },
        include: { student: true }
      });

      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_locked', { reason: message || 'Locked by teacher' });
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: assignment.accessNumber,
          studentName: `${assignment.student?.firstName || ''} ${assignment.student?.lastName || ''}`,
          status: 'PAUSED',
          isOnline: assignment.isOnline
        });
      }
      return res.json({ success: true });
    }

    if (action === 'SUSPEND_STUDENT_TEMP' && studentId) {
      const mins = parseInt(req.body.durationMinutes, 10) || 5;
      const pausedUntil = new Date(Date.now() + mins * 60 * 1000);

      const assignment = await prisma.examAssignment.update({
        where: { examId_studentId: { examId, studentId } },
        data: { status: 'PAUSED', pausedUntil },
        include: { student: true }
      });

      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_locked', {
          reason: message || `Session suspendue pour ${mins} minutes.`,
          pausedUntil,
          durationMinutes: mins
        });
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: assignment.accessNumber,
          studentName: `${assignment.student?.firstName || ''} ${assignment.student?.lastName || ''}`,
          status: 'PAUSED',
          pausedUntil,
          isOnline: assignment.isOnline
        });
      }
      return res.json({ success: true, pausedUntil });
    }

    if (action === 'UNLOCK_STUDENT' && studentId) {
      const assignment = await prisma.examAssignment.update({
        where: { examId_studentId: { examId, studentId } },
        data: { status: 'IN_EXAM', pausedUntil: null, finishedAt: null },
        include: { student: true }
      });

      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_unlocked');
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: assignment.accessNumber,
          studentName: `${assignment.student?.firstName || ''} ${assignment.student?.lastName || ''}`,
          status: 'IN_EXAM',
          pausedUntil: null,
          isOnline: assignment.isOnline
        });
      }
      return res.json({ success: true });
    }

    if (action === 'TERMINATE_STUDENT' && studentId) {
      const assignment = await prisma.examAssignment.update({
        where: { examId_studentId: { examId, studentId } },
        data: { status: 'KICKED_OUT', finishedAt: new Date(), isOnline: false },
        include: { student: true }
      });

      if (req.io) {
        req.io.to(`student_${studentId}`).emit('student_terminated', { reason: message || 'Exclu par l’enseignant' });
        req.io.to(`exam_${examId}`).emit('student_status_changed', {
          studentId,
          accessNumber: assignment.accessNumber,
          studentName: `${assignment.student?.firstName || ''} ${assignment.student?.lastName || ''}`,
          status: 'KICKED_OUT',
          isOnline: false
        });
      }
      return res.json({ success: true });
    }

    if (action === 'ANNOUNCEMENT' && message) {
      const announcement = await prisma.announcement.create({
        data: { examId, message }
      });

      if (req.io) {
        req.io.to(`exam_${examId}`).emit('new_announcement', announcement);
      }
      return res.json(announcement);
    }

    return res.status(400).json({ error: 'Invalid emergency action' });
  } catch (err) {
    console.error('teacherEmergencyControl error:', err);
    return res.status(500).json({ error: 'Failed to process emergency action' });
  }
}

// Fisher-Yates shuffle helper for unbiased random assignment order
function shuffleArray(arr) {
  const array = [...arr];
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Helper: Assign students to an exam and generate unique randomized anonymized access numbers (e.g. AL-001)
async function assignStudentsToExam(examId, studentIds, prefix = 'AL') {
  const existingCount = await prisma.examAssignment.count({ where: { examId } });
  let seq = existingCount + 1;

  // Shuffle assigned students so order is randomized
  const randomizedStudentIds = shuffleArray(studentIds);

  for (const studentId of randomizedStudentIds) {
    const accessNumber = `${prefix}-${String(seq).padStart(3, '0')}`;
    seq++;

    await prisma.examAssignment.upsert({
      where: { examId_studentId: { examId, studentId } },
      update: {},
      create: {
        examId,
        studentId,
        accessNumber,
        status: 'NOT_ENTERED'
      }
    });
  }
}

// Update Exam details (Title, Duration, Max Violations, Problems, Assigned Students)
async function updateExam(req, res) {
  try {
    const { id } = req.params;
    const {
      title, description, university, module, session, date, startTime,
      durationMinutes, prefix, maxViolationsAllowed, allowedLanguages,
      copyDisabled, pasteDisabled, fullscreenRequired, internetWarning,
      problems: problemsPayload, problemIds, studentIds
    } = req.body;

    const existing = await prisma.exam.findUnique({ where: { id } });
    if (!existing) return res.status(404).json({ error: 'Exam not found' });

    if (['FINISHED', 'COMPLETED', 'ARCHIVED'].includes(existing.status)) {
      return res.status(400).json({ error: "Cet examen est déjà terminé et ne peut plus être modifié." });
    }

    const updatedData = {};
    if (req.body.examCode !== undefined && req.body.examCode.trim()) {
      updatedData.examCode = req.body.examCode.trim().toUpperCase();
    }
    if (title !== undefined)               updatedData.title = title;
    if (description !== undefined)         updatedData.description = description;
    if (university !== undefined)          updatedData.university = university || null;
    if (module !== undefined)              updatedData.module = module || null;
    if (session !== undefined)             updatedData.session = session || null;
    if (date !== undefined || startTime !== undefined) {
      const { parsedDate, parsedStartTime } = parseSafeDate(
        date !== undefined ? date : existing.date,
        startTime !== undefined ? startTime : existing.startTime
      );
      if (date !== undefined) updatedData.date = parsedDate;
      if (startTime !== undefined) updatedData.startTime = parsedStartTime;
    }
    if (durationMinutes !== undefined)     updatedData.durationMinutes = parseInt(durationMinutes, 10);
    if (prefix !== undefined) {
      const cleanPrefix = (prefix || 'AL').trim().toUpperCase();
      const duplicatePrefix = await prisma.exam.findFirst({ where: { prefix: cleanPrefix, NOT: { id } } });
      if (duplicatePrefix) {
        return res.status(400).json({ error: `Le préfixe clé (Média) "${cleanPrefix}" est déjà utilisé par l'examen "${duplicatePrefix.title}".` });
      }
      updatedData.prefix = cleanPrefix;
    }
    if (maxViolationsAllowed !== undefined) updatedData.maxViolationsAllowed = parseInt(maxViolationsAllowed, 10);
    if (copyDisabled !== undefined)        updatedData.copyDisabled = copyDisabled === true;
    if (pasteDisabled !== undefined)       updatedData.pasteDisabled = pasteDisabled === true;
    if (fullscreenRequired !== undefined)  updatedData.fullscreenRequired = fullscreenRequired !== false;
    if (internetWarning !== undefined)     updatedData.internetWarning = internetWarning !== false;
    if (req.body.allowCodeBricks !== undefined) updatedData.allowCodeBricks = req.body.allowCodeBricks !== false;
    if (Array.isArray(req.body.allowedBricks))  updatedData.allowedBricks = req.body.allowedBricks;
    if (Array.isArray(allowedLanguages))   updatedData.allowedLanguages = ['ALGO'];

    const updatedExam = await prisma.exam.update({ where: { id }, data: updatedData });

    // Support both [{id, points}] and plain [id] problem lists
    const normalizedProblems = Array.isArray(problemsPayload) && problemsPayload.length > 0
      ? problemsPayload
      : Array.isArray(problemIds) ? problemIds.map(pid => ({ id: pid })) : null;

    if (normalizedProblems) {
      // Validate weights for all problems first
      for (const p of normalizedProblems) {
        const wTest = p.weightTest !== undefined ? parseInt(p.weightTest, 10) : 40;
        const wAst = p.weightAst !== undefined ? parseInt(p.weightAst, 10) : 60;
        const wAi = p.weightAi !== undefined ? parseInt(p.weightAi, 10) : 0;
        if (wTest + wAst + wAi !== 100) {
          return res.status(400).json({
            error: `La somme des pondérations de l'exercice doit être égale à 100% (actuel: ${wTest}% + ${wAst}% + ${wAi}% = ${wTest + wAst + wAi}%).`
          });
        }
      }

      // Differential update for exam problems to preserve existing Grade records
      const existingExamProblems = await prisma.examProblem.findMany({ where: { examId: id } });
      const incomingProblemIds = new Set();

      for (let i = 0; i < normalizedProblems.length; i++) {
        const p = normalizedProblems[i];
        const pid = typeof p === 'string' ? p : (p.problemId || p.id);
        const pts = typeof p === 'object' && p.points != null ? parseInt(p.points, 10) : 10;
        const wTest = p.weightTest !== undefined ? parseInt(p.weightTest, 10) : 40;
        const wAst = p.weightAst !== undefined ? parseInt(p.weightAst, 10) : 60;
        const wAi = p.weightAi !== undefined ? parseInt(p.weightAi, 10) : 0;
        const qPoints = p.questionPoints || {};

        if (pid) {
          incomingProblemIds.add(pid);
          const existingEp = existingExamProblems.find(ep => ep.problemId === pid);
          if (existingEp) {
            await prisma.examProblem.update({
              where: { id: existingEp.id },
              data: {
                orderIndex: i + 1,
                points: pts,
                weightTest: wTest,
                weightAst: wAst,
                weightAi: wAi,
                questionPoints: qPoints
              }
            });
          } else {
            await prisma.examProblem.create({
              data: {
                examId: id,
                problemId: pid,
                orderIndex: i + 1,
                points: pts,
                weightTest: wTest,
                weightAst: wAst,
                weightAi: wAi,
                questionPoints: qPoints
              }
            });
          }
        }
      }

      // Remove only problems that are no longer part of the exam
      const toRemove = existingExamProblems.filter(ep => !incomingProblemIds.has(ep.problemId));
      if (toRemove.length > 0) {
        await prisma.examProblem.deleteMany({
          where: { id: { in: toRemove.map(ep => ep.id) } }
        });
      }
    }

    // Assign additional students if provided
    if (Array.isArray(studentIds) && studentIds.length > 0) {
      await assignStudentsToExam(id, studentIds, prefix || existing.prefix || 'AL');
    }

    return res.json(updatedExam);
  } catch (err) {
    console.error('updateExam error:', err);
    return res.status(500).json({ error: 'Failed to update exam' });
  }
}

// Delete Exam and associated records
async function deleteExam(req, res) {
  try {
    const { id } = req.params;

    const existing = await prisma.exam.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'Exam not found' });
    }

    await prisma.submission.deleteMany({ where: { examId: id } });
    await prisma.monitoringEvent.deleteMany({ where: { examId: id } });
    await prisma.announcement.deleteMany({ where: { examId: id } });
    await prisma.incident.deleteMany({ where: { examId: id } });
    await prisma.examProblem.deleteMany({ where: { examId: id } });
    await prisma.examAssignment.deleteMany({ where: { examId: id } });
    await prisma.exam.delete({ where: { id } });

    return res.json({ success: true, message: 'Exam deleted successfully' });
  } catch (err) {
    console.error('deleteExam error:', err);
    return res.status(500).json({ error: 'Failed to delete exam' });
  }
}

// ── Exam Results & Analytics ─────────────────────────────────────────────
async function getExamResults(req, res) {
  try {
    const { id } = req.params;

    const exam = await prisma.exam.findUnique({
      where: { id },
      include: {
        problems: {
          orderBy: { orderIndex: 'asc' },
          include: { problem: { select: { id: true, title: true } } }
        },
        assignments: {
          include: {
            student: { select: { id: true, firstName: true, lastName: true, group: true, studentId: true } }
          },
          orderBy: { student: { lastName: 'asc' } }
        }
      }
    });

    if (!exam) return res.status(404).json({ error: 'Exam not found' });

    // Fetch all submissions for this exam
    const submissions = await prisma.submission.findMany({
      where: { examId: id },
      orderBy: { createdAt: 'asc' }
    });

    // Group submissions by studentId + problemId (keep best score per problem)
    const bestSubmissions = {};
    for (const sub of submissions) {
      const key = `${sub.studentId}__${sub.problemId}`;
      if (!bestSubmissions[key] || sub.score > bestSubmissions[key].score) {
        bestSubmissions[key] = sub;
      }
    }

    // Build per-student result rows
    const problemList = exam.problems.map(ep => ({ ...ep.problem, points: ep.points || 10 }));
    const totalMaxScore = problemList.reduce((sum, p) => sum + p.points, 0);

    const studentRows = exam.assignments.map(asgn => {
      const s = asgn.student || {};
      const sId = s.id || asgn.studentId;

      // Per-problem scores (use manualScore if set by teacher, else fallback to auto score)
      const problemScores = problemList.map(p => {
        const sub = bestSubmissions[`${sId}__${p.id}`];
        let earnedPoints = 0;
        let scorePct = 0;

        if (sub) {
          if (sub.manualScore !== null && sub.manualScore !== undefined) {
            earnedPoints = parseFloat(Number(sub.manualScore).toFixed(2));
            scorePct = p.points > 0 ? Math.round((earnedPoints / p.points) * 100) : 0;
          } else {
            scorePct = Math.round(sub.score || 0);
            earnedPoints = parseFloat((((sub.score || 0) / 100) * p.points).toFixed(2));
          }
        }

        return {
          problemId:   p.id,
          title:       p.title,
          maxPoints:   p.points,
          score:       scorePct,
          earnedPoints,
          passedTests: sub ? sub.passedTests : 0,
          totalTests:  sub ? sub.totalTests : 0,
          status:      sub ? sub.status : 'NOT_SUBMITTED'
        };
      });

      const totalEarned   = parseFloat(problemScores.reduce((sum, p) => sum + (p.earnedPoints || 0), 0).toFixed(2));
      const totalPercent  = totalMaxScore > 0 ? Math.round((totalEarned / totalMaxScore) * 100) : 0;
      const rawScore20    = totalMaxScore > 0 ? parseFloat(((totalEarned / totalMaxScore) * 20).toFixed(2)) : 0;
      const finalScore20  = asgn.finalScore !== null && asgn.finalScore !== undefined
        ? parseFloat(Number(asgn.finalScore).toFixed(2))
        : rawScore20;

      const totalPassed   = problemScores.reduce((sum, p) => sum + p.passedTests, 0);
      const totalTestsAll = problemScores.reduce((sum, p) => sum + p.totalTests, 0);

      // Time taken (ms)
      const timeTakenMs = (asgn.startedAt && asgn.finishedAt)
        ? new Date(asgn.finishedAt) - new Date(asgn.startedAt)
        : null;

      return {
        studentId:     sId,
        studentCode:   s.studentId || asgn.accessNumber || sId,
        firstName:     s.firstName || '',
        lastName:      s.lastName || 'Candidat',
        group:         s.group || asgn.room || 'Salle A',
        accessNumber:  asgn.accessNumber,
        status:        asgn.status,
        gradingStatus: asgn.gradingStatus || 'NOT_ENTERED',
        startedAt:     asgn.startedAt,
        finishedAt:    asgn.finishedAt,
        timeTakenMs,
        violations:    asgn.violations || 0,
        fullscreenExits: asgn.fullscreenExits || 0,
        totalEarned,
        totalMaxScore,
        totalPercent,
        finalScore20,
        totalPassed,
        totalTestsAll,
        problemScores
      };
    });

    // Class-wide statistics based on /20 scale
    const finishedRows  = studentRows.filter(r => r.status === 'FINISHED' || r.gradingStatus === 'GRADED');
    const kickedRows    = studentRows.filter(r => r.status === 'KICKED_OUT');
    const absentRows    = studentRows.filter(r => ['ABSENT', 'NOT_ENTERED'].includes(r.status));
    
    const scores20      = studentRows.map(r => r.finalScore20);
    const avgScore20    = scores20.length ? parseFloat((scores20.reduce((a,b)=>a+b,0) / scores20.length).toFixed(2)) : 0;
    const maxScore20    = scores20.length ? Math.max(...scores20) : 0;
    const minScore20    = scores20.length ? Math.min(...scores20) : 0;
    
    const avgScorePct   = totalMaxScore > 0 ? Math.round((avgScore20 / 20) * 100) : 0;

    const avgTimeMs     = finishedRows.length
      ? Math.round(finishedRows.filter(r=>r.timeTakenMs).reduce((s,r)=>s+r.timeTakenMs,0) / finishedRows.filter(r=>r.timeTakenMs).length)
      : null;
    const totalViolations = studentRows.reduce((s,r) => s + r.violations, 0);

    // Score distribution on /20 scale ([0-8], [8-10], [10-12], [12-14], [14-16], [16-18], [18-20])
    const buckets = [
      { label: '< 8 /20', min: 0, max: 8 },
      { label: '8 - 10 /20', min: 8, max: 10 },
      { label: '10 - 12 /20', min: 10, max: 12 },
      { label: '12 - 14 /20', min: 12, max: 14 },
      { label: '14 - 16 /20', min: 14, max: 16 },
      { label: '16 - 18 /20', min: 16, max: 18 },
      { label: '18 - 20 /20', min: 18, max: 20.1 }
    ];

    const distribution = buckets.map(b => ({
      label: b.label,
      count: scores20.filter(s => s >= b.min && s < b.max).length
    }));

    // Per-problem statistics with average score per exercise
    const problemStats = problemList.map(p => {
      const rows = studentRows.map(r => r.problemScores.find(ps => ps.problemId === p.id));
      const submitted = rows.filter(ps => ps?.status !== 'NOT_SUBMITTED').length;
      const passed    = rows.filter(ps => ps?.passedTests > 0 && ps?.passedTests === ps?.totalTests).length;
      
      const sumEarned = rows.reduce((s, ps) => s + (ps?.earnedPoints || 0), 0);
      const avgEarnedPoints = rows.length ? parseFloat((sumEarned / rows.length).toFixed(2)) : 0;
      const avgScore20 = p.points > 0 ? parseFloat(((avgEarnedPoints / p.points) * 20).toFixed(2)) : 0;

      return {
        problemId: p.id,
        title: p.title,
        maxPoints: p.points,
        submitted,
        passed,
        avgEarnedPoints,
        avgScore20,
        total: studentRows.length
      };
    });

    return res.json({
      exam: {
        id: exam.id, title: exam.title, startTime: exam.startTime,
        durationMinutes: exam.durationMinutes, status: exam.status
      },
      problems: problemList,
      studentRows,
      stats: {
        total: studentRows.length,
        finished: finishedRows.length,
        kickedOut: kickedRows.length,
        absent: absentRows.length,
        avgScore20,
        maxScore20,
        minScore20,
        avgScorePct,
        avgTimeMs,
        totalViolations,
        distribution,
        problemStats
      }
    });
  } catch (err) {
    console.error('getExamResults error:', err);
    return res.status(500).json({ error: 'Failed to fetch exam results' });
  }
}

// ── Encrypted Submission Bundle Controllers ──────────────────────────────

// Export Encrypted Submission Bundle (.algobundle)
async function exportSubmissionBundle(req, res) {
  try {
    const { id: examId } = req.params;
    const passphrase = req.body.passphrase ? req.body.passphrase.trim() : null;

    const encryptedBundle = await buildEncryptedSubmissionBundle(examId, passphrase);
    return res.json(encryptedBundle);
  } catch (err) {
    console.error('exportSubmissionBundle error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors de l'exportation du paquet." });
  }
}

// Import & Merge One or More Submission Bundles (.algobundle)
async function importSubmissionBundles(req, res) {
  try {
    const examId = req.params.id;
    const passphrase = req.body.passphrase ? req.body.passphrase.trim() : null;

    let bundlePayloads = [];

    // Check if uploaded via multer (req.files or req.file)
    const uploadedFiles = req.files && Array.isArray(req.files) && req.files.length > 0
      ? req.files
      : (req.file ? [req.file] : []);

    if (uploadedFiles.length > 0) {
      for (const f of uploadedFiles) {
        try {
          const parsed = safeParseBufferToJSON(f.buffer);
          bundlePayloads.push(parsed);
        } catch (e) {
          return res.status(400).json({ error: `Le fichier "${f.originalname || 'téléversé'}" n'est pas un JSON valide.` });
        }
      }
    } else if (req.body.bundles && Array.isArray(req.body.bundles)) {
      bundlePayloads = req.body.bundles.map(b => typeof b === 'string' ? safeParseStringToJSON(b) : b);
    } else if (req.body.bundle) {
      bundlePayloads = typeof req.body.bundle === 'string' ? [safeParseStringToJSON(req.body.bundle)] : [req.body.bundle];
    }

    if (bundlePayloads.length === 0) {
      return res.status(400).json({ error: 'Aucun fichier de paquet fourni.' });
    }

    // Decrypt all bundles (using custom passphrase or fallback to system vault key)
    const decryptedList = [];
    for (let i = 0; i < bundlePayloads.length; i++) {
      const b = bundlePayloads[i];
      try {
        const decrypted = decryptData(b, passphrase);
        decryptedList.push(decrypted);
      } catch (err) {
        return res.status(400).json({ error: `Échec du déchiffrement du paquet ${i + 1} : ${err.message}` });
      }
    }

    if (decryptedList.length === 0) {
      return res.status(400).json({ error: 'Aucun paquet déchiffrable trouvé.' });
    }

    let targetExam = null;
    if (examId && examId !== 'direct') {
      targetExam = await prisma.exam.findUnique({ where: { id: examId } });
    }

    const firstBundleExam = decryptedList[0].exam || {};
    const candidateCode = firstBundleExam.examCode || generateDefaultExamCode(firstBundleExam.date || firstBundleExam.createdAt);

    if (!targetExam) {
      if (candidateCode) {
        targetExam = await prisma.exam.findFirst({
          where: { examCode: candidateCode }
        });
      }
      if (!targetExam && !candidateCode && firstBundleExam.title) {
        targetExam = await prisma.exam.findFirst({
          where: { title: firstBundleExam.title }
        });
      }
    }

    // If still no matching exam exists, auto-create it from bundle metadata!
    if (!targetExam) {
      const teacherId = await getValidTeacherId(req.teacher?.teacherId || req.teacher?.id);

      const incomingProblems = firstBundleExam.problems || [];
      const examProblemData = [];
      for (let i = 0; i < incomingProblems.length; i++) {
        const ep = incomingProblems[i];
        const pData = ep.problem || ep;
        let existingProb = await prisma.problem.findFirst({ where: { title: pData.title } });
        if (!existingProb) {
          const starterTemplate = pData.starterTemplate || '';
          const finalTemplateCode = typeof starterTemplate === 'string'
            ? { ALGO: starterTemplate, PYTHON: '' }
            : (pData.templateCode || { ALGO: '', PYTHON: '' });

          existingProb = await prisma.problem.create({
            data: {
              title: pData.title,
              description: pData.description || 'Description',
              topic: pData.topic || 'ASD',
              difficulty: pData.difficulty || 'Medium',
              referenceSolution: pData.referenceSolution || '',
              templateCode: finalTemplateCode,
              questions: {
                create: (pData.questions || []).map((q, qIdx) => ({
                  orderIndex: q.orderIndex || qIdx + 1,
                  statement: q.statement || `Question ${qIdx + 1}`
                }))
              },
              testCases: {
                create: (pData.testCases || []).map(tc => ({
                  input: tc.input || '',
                  expectedOutput: tc.expectedOutput || '',
                  label: tc.label || '',
                  points: tc.points !== undefined ? tc.points : 1,
                  isHidden: tc.isHidden || false
                }))
              }
            }
          });
        }
        let qPoints = ep.questionPoints;
        if (!qPoints || Object.keys(qPoints).length === 0) {
          qPoints = {};
          if (Array.isArray(pData.questions)) {
            pData.questions.forEach((q, qIdx) => {
              const qIndex = q.orderIndex || qIdx + 1;
              if (q.points !== undefined && q.points !== null) {
                qPoints[qIndex] = Number(q.points);
                qPoints[String(qIndex)] = Number(q.points);
              }
            });
          }
        } else {
          const normalized = {};
          const incomingQuestions = pData.questions || [];
          incomingQuestions.forEach((iq, iqIdx) => {
            const qIdx = iq.orderIndex || iqIdx + 1;
            const pts = qPoints[iq.id] ?? qPoints[String(qIdx)] ?? qPoints[qIdx] ?? iq.points;
            if (pts !== undefined && pts !== null) {
              normalized[qIdx] = Number(pts);
              normalized[String(qIdx)] = Number(pts);
            }
          });
          qPoints = { ...qPoints, ...normalized };
        }

        examProblemData.push({
          problemId: existingProb.id,
          orderIndex: ep.orderIndex || i + 1,
          points: ep.points || 5,
          weightTest: ep.weightTest !== undefined ? ep.weightTest : 40,
          weightAst: ep.weightAst !== undefined ? ep.weightAst : 60,
          weightAi: ep.weightAi !== undefined ? ep.weightAi : 0,
          questionPoints: qPoints || {}
        });
      }

      targetExam = await prisma.exam.create({
        data: {
          title: firstBundleExam.title || 'Examen Importé',
          description: firstBundleExam.description || '',
          university: firstBundleExam.university || 'ESI - École Nationale Supérieure d\'Informatique',
          module: firstBundleExam.module || 'ASD',
          session: firstBundleExam.session || 'Partiel',
          examCode: candidateCode,
          prefix: firstBundleExam.prefix || 'AL',
          durationMinutes: firstBundleExam.durationMinutes || 90,
          status: 'FINISHED',
          teacherId: teacherId || '',
          problems: {
            create: examProblemData
          }
        }
      });
    }

    const finalExamId = targetExam.id;

    // Merge into target exam
    const mergeResult = await mergeSubmissionsIntoExam(finalExamId, decryptedList);

    return res.json({
      success: true,
      exam: targetExam,
      message: `${decryptedList.length} paquet(s) importé(s) et fusionné(s) avec succès.`,
      ...mergeResult
    });
  } catch (err) {
    console.error('importSubmissionBundles error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors de l'importation des paquets." });
  }
}

// Export Encrypted Corrected Results (.algoresults)
async function exportCorrectedResults(req, res) {
  try {
    const { id: examId } = req.params;
    const passphrase = req.body.passphrase ? req.body.passphrase.trim() : null;

    const encryptedResults = await buildEncryptedResultsBundle(examId, passphrase);
    return res.json(encryptedResults);
  } catch (err) {
    console.error('exportCorrectedResults error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors de l'exportation des résultats." });
  }
}

// Import Corrected Results (.algoresults)
async function importCorrectedResults(req, res) {
  try {
    const examId = req.params.id;
    const passphrase = req.body.passphrase ? req.body.passphrase.trim() : null;

    let payloads = [];
    const uploadedFiles = req.files && Array.isArray(req.files) && req.files.length > 0
      ? req.files
      : (req.file ? [req.file] : []);

    if (uploadedFiles.length > 0) {
      for (const f of uploadedFiles) {
        try {
          payloads.push(safeParseBufferToJSON(f.buffer));
        } catch (e) {
          return res.status(400).json({ error: `Le fichier "${f.originalname || 'téléversé'}" n'est pas un JSON valide.` });
        }
      }
    } else if (req.body.results) {
      payloads = Array.isArray(req.body.results)
        ? req.body.results.map(r => typeof r === 'string' ? safeParseStringToJSON(r) : r)
        : [typeof req.body.results === 'string' ? safeParseStringToJSON(req.body.results) : req.body.results];
    }

    if (payloads.length === 0) {
      return res.status(400).json({ error: 'Fichier(s) de résultats requis.' });
    }

    const decryptedList = [];
    for (let i = 0; i < payloads.length; i++) {
      const p = payloads[i];
      try {
        const dec = decryptData(p, passphrase);
        if (dec.bundleType !== 'CORRECTED_RESULTS_BUNDLE' && !dec.students) {
          return res.status(400).json({ error: `Le fichier #${i + 1} n'est pas un paquet de résultats corrigés (.algoresults) valide.` });
        }
        decryptedList.push(dec);
      } catch (err) {
        return res.status(400).json({ error: `Échec du déchiffrement du fichier #${i + 1} : ${err.message}` });
      }
    }

    if (decryptedList.length === 0) {
      return res.status(400).json({ error: 'Aucun résultat déchiffrable.' });
    }

    let targetExam = null;
    if (examId && examId !== 'direct') {
      targetExam = await prisma.exam.findUnique({ where: { id: examId } });
    }

    const firstResExam = decryptedList[0].exam || {};
    const candidateCode = firstResExam.examCode || generateDefaultExamCode(firstResExam.date || firstResExam.createdAt);

    if (!targetExam) {
      if (candidateCode) {
        targetExam = await prisma.exam.findFirst({
          where: { examCode: candidateCode }
        });
      }
      if (!targetExam && !candidateCode && firstResExam.title) {
        targetExam = await prisma.exam.findFirst({
          where: { title: firstResExam.title }
        });
      }
    }

    // If still no matching exam exists, auto-create it from results metadata with status CLOSED!
    if (!targetExam) {
      const teacherId = await getValidTeacherId(req.teacher?.teacherId || req.teacher?.id);

      const incomingProblems = firstResExam.problems || [];
      const examProblemData = [];
      for (let i = 0; i < incomingProblems.length; i++) {
        const ep = incomingProblems[i];
        const pData = ep.problem || ep;
        let existingProb = await prisma.problem.findFirst({ where: { title: pData.title } });
        if (!existingProb) {
          const starterTemplate = pData.starterTemplate || '';
          const finalTemplateCode = typeof starterTemplate === 'string'
            ? { ALGO: starterTemplate, PYTHON: '' }
            : (pData.templateCode || { ALGO: '', PYTHON: '' });

          existingProb = await prisma.problem.create({
            data: {
              title: pData.title,
              description: pData.description || 'Description',
              topic: pData.topic || 'ASD',
              difficulty: pData.difficulty || 'Medium',
              referenceSolution: pData.referenceSolution || '',
              templateCode: finalTemplateCode,
              questions: {
                create: (pData.questions || []).map((q, qIdx) => ({
                  orderIndex: q.orderIndex || qIdx + 1,
                  statement: q.statement || `Question ${qIdx + 1}`
                }))
              },
              testCases: {
                create: (pData.testCases || []).map(tc => ({
                  input: tc.input || '',
                  expectedOutput: tc.expectedOutput || '',
                  label: tc.label || '',
                  points: tc.points !== undefined ? tc.points : 1,
                  isHidden: tc.isHidden || false
                }))
              }
            }
          });
        }
        let qPoints = ep.questionPoints;
        if (!qPoints || Object.keys(qPoints).length === 0) {
          qPoints = {};
          if (Array.isArray(pData.questions)) {
            pData.questions.forEach((q, qIdx) => {
              const qIndex = q.orderIndex || qIdx + 1;
              if (q.points !== undefined && q.points !== null) {
                qPoints[qIndex] = Number(q.points);
                qPoints[String(qIndex)] = Number(q.points);
              }
            });
          }
        } else {
          const normalized = {};
          const incomingQuestions = pData.questions || [];
          incomingQuestions.forEach((iq, iqIdx) => {
            const qIdx = iq.orderIndex || iqIdx + 1;
            const pts = qPoints[iq.id] ?? qPoints[String(qIdx)] ?? qPoints[qIdx] ?? iq.points;
            if (pts !== undefined && pts !== null) {
              normalized[qIdx] = Number(pts);
              normalized[String(qIdx)] = Number(pts);
            }
          });
          qPoints = { ...qPoints, ...normalized };
        }

        examProblemData.push({
          problemId: existingProb.id,
          orderIndex: ep.orderIndex || i + 1,
          points: ep.points || 5,
          weightTest: ep.weightTest !== undefined ? ep.weightTest : 40,
          weightAst: ep.weightAst !== undefined ? ep.weightAst : 60,
          weightAi: ep.weightAi !== undefined ? ep.weightAi : 0,
          questionPoints: qPoints || {}
        });
      }

      targetExam = await prisma.exam.create({
        data: {
          title: firstResExam.title || 'Examen Corrigé (Importé)',
          description: firstResExam.description || '',
          university: firstResExam.university || 'ESI - École Nationale Supérieure d\'Informatique',
          module: firstResExam.module || 'ASD',
          session: firstResExam.session || 'Partiel',
          examCode: candidateCode,
          prefix: firstResExam.prefix || 'AL',
          durationMinutes: firstResExam.durationMinutes || 90,
          status: 'CLOSED',
          teacherId: teacherId || '',
          problems: {
            create: examProblemData
          }
        }
      });
    }

    const finalExamId = targetExam.id;
    const mergeStats = await mergeResultsIntoExam(finalExamId, decryptedList);

    return res.json({
      success: true,
      exam: targetExam,
      message: `${decryptedList.length} fichier(s) de résultats synchronisé(s) avec succès (${mergeStats.totalStudentsSynchronized} étudiants mis à jour).`,
      ...mergeStats
    });
  } catch (err) {
    console.error('importCorrectedResults error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors de l'importation des résultats." });
  }
}

// Export Exam Template Definition (.algoexam) — pure exam & problems without student data
async function exportExamTemplate(req, res) {
  try {
    const { id: examId } = req.params;
    const passphrase = req.body?.passphrase ? req.body.passphrase.trim() : null;

    const encryptedTemplate = await buildEncryptedExamTemplate(examId, passphrase);
    return res.json(encryptedTemplate);
  } catch (err) {
    console.error('exportExamTemplate error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors de l'exportation du modèle d'examen." });
  }
}

// Import Exam Template Definition (.algoexam) — checks/creates problems and instantiates exam
async function importExamTemplate(req, res) {
  try {
    let raw = null;
    const passphrase = req.body?.passphrase ? req.body.passphrase.trim() : null;

    const uploadedFile = req.file || (req.files && Array.isArray(req.files) && req.files.length > 0 ? req.files[0] : null);

    if (uploadedFile) {
      try {
        raw = safeParseBufferToJSON(uploadedFile.buffer);
      } catch (e) {
        return res.status(400).json({ error: `Le fichier téléversé n'est pas un JSON valide : ${e.message}` });
      }
    } else if (req.body.template) {
      raw = typeof req.body.template === 'string' ? safeParseStringToJSON(req.body.template) : req.body.template;
    } else if (req.body.exam) {
      raw = typeof req.body.exam === 'string' ? safeParseStringToJSON(req.body.exam) : req.body.exam;
    } else if (req.body && typeof req.body === 'object' && (req.body.title || req.body.ciphertext || req.body.exam)) {
      raw = req.body;
    }

    if (!raw) {
      return res.status(400).json({ error: "Aucun fichier ou contenu de modèle d'examen fourni." });
    }

    let payload = null;
    if (raw && raw.ciphertext) {
      try {
        payload = decryptData(raw, passphrase);
      } catch (errDec) {
        return res.status(400).json({ error: `Échec du déchiffrement du modèle (.algoexam) : ${errDec.message}` });
      }
    } else {
      payload = raw;
    }

    if (!payload || (!payload.exam && !payload.title)) {
      return res.status(400).json({ error: "Fichier de modèle d'examen (.algoexam) invalide." });
    }

    const templateExam = payload.exam || payload;
    const teacherId = await getValidTeacherId(req.teacher?.teacherId || req.teacher?.id);
    const problemSummary = [];
    const examProblemData = [];

    const incomingProblems = templateExam.problems || [];
    for (let i = 0; i < incomingProblems.length; i++) {
      const ep = incomingProblems[i];
      const pData = ep.problem || ep;

      // Check if problem already exists in DB by title
      let existingProb = await prisma.problem.findFirst({
        where: { title: pData.title }
      });

      if (!existingProb) {
        const starterTemplate = pData.starterTemplate || '';
        const finalTemplateCode = typeof starterTemplate === 'string'
          ? { ALGO: starterTemplate, PYTHON: '' }
          : (pData.templateCode || { ALGO: '', PYTHON: '' });

        // Create new problem with questions and test cases conforming to schema
        existingProb = await prisma.problem.create({
          data: {
            title: pData.title,
            description: pData.description || 'Description de l\'exercice',
            topic: pData.topic || 'Algorithmique Général',
            difficulty: pData.difficulty || 'Medium',
            tags: Array.isArray(pData.tags) ? pData.tags : [],
            referenceSolution: pData.referenceSolution || '',
            templateCode: finalTemplateCode,
            questions: {
              create: (pData.questions || []).map((q, qIdx) => ({
                orderIndex: q.orderIndex || qIdx + 1,
                statement: q.statement || `Question ${qIdx + 1}`
              }))
            },
            testCases: {
              create: (pData.testCases || []).map(tc => ({
                inputData: tc.inputData || '',
                expectedOutput: tc.expectedOutput || '',
                isPublic: tc.isPublic != null ? !!tc.isPublic : (tc.isHidden != null ? !tc.isHidden : false)
              }))
            }
          }
        });
        problemSummary.push({
          title: pData.title,
          status: 'CREATED',
          problemId: existingProb.id,
          points: ep.points || pData.points || 5
        });
      } else {
        problemSummary.push({
          title: pData.title,
          status: 'EXISTING',
          problemId: existingProb.id,
          points: ep.points || existingProb.points || 5
        });
      }

      let qPoints = ep.questionPoints;
      if (!qPoints || Object.keys(qPoints).length === 0) {
        qPoints = {};
        if (Array.isArray(pData.questions)) {
          pData.questions.forEach((q, qIdx) => {
            const qIndex = q.orderIndex || qIdx + 1;
            if (q.points !== undefined && q.points !== null) {
              qPoints[qIndex] = Number(q.points);
              qPoints[String(qIndex)] = Number(q.points);
            }
          });
        }
      } else {
        const normalized = {};
        const incomingQuestions = pData.questions || [];
        incomingQuestions.forEach((iq, iqIdx) => {
          const qIdx = iq.orderIndex || iqIdx + 1;
          const pts = qPoints[iq.id] ?? qPoints[String(qIdx)] ?? qPoints[qIdx] ?? iq.points;
          if (pts !== undefined && pts !== null) {
            normalized[qIdx] = Number(pts);
            normalized[String(qIdx)] = Number(pts);
          }
        });
        qPoints = { ...qPoints, ...normalized };
      }

      examProblemData.push({
        problemId: existingProb.id,
        orderIndex: ep.orderIndex || i + 1,
        points: ep.points || existingProb.points || 5,
        weightTest: ep.weightTest ?? 40,
        weightAst: ep.weightAst ?? 60,
        weightAi: ep.weightAi ?? 0,
        questionPoints: qPoints || {}
      });
    }

    const examCode = templateExam.examCode || generateDefaultExamCode();

    // Create the Exam record (without student affiliations)
    const newExam = await prisma.exam.create({
      data: {
        examCode,
        title: templateExam.title ? `${templateExam.title} (Importé)` : 'Nouvel Examen Importé',
        description: templateExam.description || '',
        university: templateExam.university || 'École Nationale Supérieure d\'Informatique (ESI)',
        module: templateExam.module || 'Algorithmique et Structure de Données',
        session: templateExam.session || '2025/2026',
        durationMinutes: templateExam.durationMinutes || 120,
        status: 'DRAFT',
        teacherId,
        prefix: templateExam.prefix || 'AL',
        maxViolationsAllowed: templateExam.maxViolationsAllowed ?? 4,
        copyDisabled: templateExam.copyDisabled ?? false,
        pasteDisabled: templateExam.pasteDisabled ?? false,
        fullscreenRequired: templateExam.fullscreenRequired ?? true,
        internetWarning: templateExam.internetWarning ?? true,
        allowCodeBricks: templateExam.allowCodeBricks ?? true,
        allowedBricks: templateExam.allowedBricks || ["LIRE_TAB", "AFFICHER_TAB", "LIRE_MATRICE", "AFFICHER_MATRICE", "RECHERCHE_MAX", "TRI_BULLES"],
        allowedLanguages: templateExam.allowedLanguages || ["ALGO"],
        problems: {
          create: examProblemData
        }
      },
      include: {
        problems: {
          include: { problem: true }
        }
      }
    });

    return res.json({
      success: true,
      message: `Examen "${newExam.title}" importé avec succès (${problemSummary.length} exercices reliés).`,
      exam: newExam,
      problemSummary
    });
  } catch (err) {
    console.error('importExamTemplate error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors de l'importation du modèle d'examen." });
  }
}

// Launch Exam with Room assignment and optional CSV/selected students
async function launchExamWithRoom(req, res) {
  try {
    const { id: examId } = req.params;
    let { room, studentIds, studentsCSV, prefix, randomizeOrder, examCode, targetStatus, date, startTime, durationMinutes } = req.body;

    const exam = await prisma.exam.findUnique({ where: { id: examId } });
    if (!exam) {
      return res.status(404).json({ error: 'Examen non trouvé.' });
    }

    const targetStudentIds = [];
    const customCodeMap = {}; // student.id -> custom code
    let headerMap = null;

    if (Array.isArray(studentIds)) {
      targetStudentIds.push(...studentIds);
    } else if (typeof studentIds === 'string' && studentIds.trim()) {
      try {
        const parsed = JSON.parse(studentIds);
        if (Array.isArray(parsed)) targetStudentIds.push(...parsed);
      } catch (e) {
        targetStudentIds.push(...studentIds.split(',').map(s => s.trim()).filter(Boolean));
      }
    }

    // Process uploaded CSV if present
    let csvContent = studentsCSV;
    const uploadedCSVFile = req.file || (req.files && Array.isArray(req.files) && req.files.length > 0 ? req.files[0] : null);
    if (uploadedCSVFile) {
      csvContent = uploadedCSVFile.buffer.toString('utf8').replace(/^\uFEFF+/, '');
    } else if (typeof csvContent === 'string') {
      csvContent = csvContent.replace(/^\uFEFF+/, '');
    }

    if (csvContent && typeof csvContent === 'string' && csvContent.trim()) {
      const lines = csvContent.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
        const line = lines[lineIdx];
        const parts = line.split(/[;,]/).map(p => p.trim());
        if (parts.length >= 1) {
          if (lineIdx === 0 && /^student|^matricule|^id|^code|^nom/i.test(parts[0])) {
            headerMap = {};
            parts.forEach((col, cIdx) => {
              const lower = col.toLowerCase();
              if (/code_anonyme|codeanonyme|anonym|code/i.test(lower)) headerMap.code = cIdx;
              else if (/matricule|student_id|studentid|id/i.test(lower)) headerMap.id = cIdx;
              else if (/prenom|firstname/i.test(lower)) headerMap.firstName = cIdx;
              else if (/nom|lastname/i.test(lower)) headerMap.lastName = cIdx;
              else if (/group|groupe/i.test(lower)) headerMap.group = cIdx;
              else if (/specialit/i.test(lower)) headerMap.speciality = cIdx;
            });
            continue;
          }

          let studentId = '';
          let firstName = 'Étudiant';
          let lastName = '';
          let group = 'G01';
          let speciality = 'Informatique';
          let academicYear = 2026;
          let customCode = '';

          if (headerMap && headerMap.id !== undefined) {
            studentId = parts[headerMap.id] || '';
            if (headerMap.code !== undefined) customCode = parts[headerMap.code] || '';
            if (headerMap.firstName !== undefined) firstName = parts[headerMap.firstName] || firstName;
            if (headerMap.lastName !== undefined) lastName = parts[headerMap.lastName] || lastName;
            if (headerMap.group !== undefined) group = parts[headerMap.group] || group;
            if (headerMap.speciality !== undefined) speciality = parts[headerMap.speciality] || speciality;
          } else {
            studentId = parts[0];
            firstName = parts[1] || 'Étudiant';
            lastName = parts[2] || parts[0];
            group = parts[3] || 'G01';
            speciality = parts[4] || 'Informatique';
            if (parts[5]) customCode = parts[5];
          }

          if (studentId) {
            let student = await prisma.student.findUnique({ where: { studentId } });
            if (!student) {
              student = await prisma.student.create({
                data: { studentId, firstName, lastName, group, speciality, academicYear }
              });
            }
            if (!targetStudentIds.includes(student.id)) {
              targetStudentIds.push(student.id);
            }
            if (customCode) {
              customCodeMap[student.id] = customCode;
            }
          }
        }
      }
    }

    if (targetStudentIds.length === 0) {
      return res.status(400).json({ error: 'Veuillez sélectionner des étudiants ou téléverser un fichier CSV pour cette salle.' });
    }

    // Randomize / Shuffle students order for anonymization if requested
    if (randomizeOrder !== false && randomizeOrder !== 'false') {
      for (let i = targetStudentIds.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [targetStudentIds[i], targetStudentIds[j]] = [targetStudentIds[j], targetStudentIds[i]];
      }
    }

    const examPrefix = prefix || exam.prefix || 'AL';
    const roomName = room?.trim() || 'Salle 101';
    const roomCode = sanitizeRoomCode(roomName);

    // Create or update assignments with room and sequential anonymous access codes
    const assignmentsCreated = [];
    const finalExamCode = (examCode && examCode.trim()) || exam.examCode || generateDefaultExamCode(exam.date || new Date());
    const finalStatus = targetStatus === 'WAITING' ? 'WAITING' : 'RUNNING';

    let parsedStartTime = finalStatus === 'RUNNING' ? new Date() : (exam.startTime || null);
    if (finalStatus === 'WAITING' && date && startTime) {
      try {
        const [hours, mins] = String(startTime).split(':').map(Number);
        const d = new Date(date);
        d.setHours(hours || 0, mins || 0, 0, 0);
        parsedStartTime = d;
      } catch (e) {}
    }

    // ── IF EXAM IS A TEMPLATE (DRAFT / SCHEDULED): KEEP TEMPLATE AND CLONE NEW LIVE SESSION ──
    if (exam.status === 'DRAFT' || exam.status === 'SCHEDULED') {
      // Check if there is already an active session running for this subject template
      const activeSession = await prisma.exam.findFirst({
        where: {
          title: exam.title,
          status: { in: ['RUNNING', 'WAITING', 'PAUSED'] }
        }
      });

      if (activeSession) {
        return res.status(400).json({
          error: `Une séance pour le sujet "${exam.title}" est déjà active en cours d'exécution (Salle: ${activeSession.room || 'Salle Principale'}, Statut: ${activeSession.status}). Vous ne pouvez pas lancer deux séances simultanément pour le même sujet.`
        });
      }

      // Fetch template problems to replicate
      const templateWithProbs = await prisma.exam.findUnique({
        where: { id: examId },
        include: { problems: true }
      });

      const teacherId = await getValidTeacherId(req.teacher?.teacherId || req.teacher?.id || exam.teacherId);

      // Create new live session exam
      const newSessionExam = await prisma.exam.create({
        data: {
          title: exam.title,
          description: exam.description,
          university: exam.university,
          module: exam.module,
          session: exam.session,
          examCode: finalExamCode,
          prefix: examPrefix,
          room: roomName,
          durationMinutes: (durationMinutes && !isNaN(Number(durationMinutes))) ? Number(durationMinutes) : (exam.durationMinutes || 90),
          status: finalStatus,
          startTime: parsedStartTime,
          date: date ? new Date(date) : (exam.date || new Date()),
          teacherId,
          maxViolationsAllowed: exam.maxViolationsAllowed,
          copyDisabled: exam.copyDisabled,
          pasteDisabled: exam.pasteDisabled,
          fullscreenRequired: exam.fullscreenRequired,
          internetWarning: exam.internetWarning,
          allowCodeBricks: exam.allowCodeBricks,
          allowedBricks: exam.allowedBricks,
          allowedLanguages: exam.allowedLanguages,
          problems: {
            create: (templateWithProbs?.problems || []).map(ep => ({
              problemId: ep.problemId,
              orderIndex: ep.orderIndex,
              points: ep.points,
              weightTest: ep.weightTest,
              weightAst: ep.weightAst,
              weightAi: ep.weightAi,
              questionPoints: ep.questionPoints
            }))
          }
        }
      });

      const isRandom = (randomizeOrder !== false && randomizeOrder !== 'false');
      const studentNumbers = isRandom
        ? generateRandomizedNumbers(targetStudentIds.length)
        : Array.from({ length: targetStudentIds.length }, (_, i) => String(i + 1).padStart(3, '0'));

      // Create assignments on the new session exam
      for (let idx = 0; idx < targetStudentIds.length; idx++) {
        const sId = targetStudentIds[idx];
        const customCode = customCodeMap[sId];
        const defaultCode = `${roomCode}${studentNumbers[idx]}`;
        const accessNumber = customCode || defaultCode;

        const asgn = await prisma.examAssignment.create({
          data: {
            examId: newSessionExam.id,
            studentId: sId,
            room: roomName,
            accessNumber,
            status: 'WAITING'
          }
        });
        assignmentsCreated.push(asgn);
      }

      const finalExam = await prisma.exam.findUnique({
        where: { id: newSessionExam.id },
        include: {
          assignments: { include: { student: true } },
          problems: { include: { problem: true } }
        }
      });

      const statusMsg = finalStatus === 'RUNNING' ? 'lancée et en cours' : 'préparée en attente de lancement';

      return res.json({
        success: true,
        message: `Séance pour la salle "${roomName}" ${statusMsg} avec ${assignmentsCreated.length} étudiant(s) inscrits. Le modèle de sujet original reste disponible.`,
        exam: finalExam,
        totalAssigned: assignmentsCreated.length
      });
    }

    // ── OTHERWISE (Existing Session Update) ──
    const isRandom = (randomizeOrder !== false && randomizeOrder !== 'false');
    const studentNumbers = isRandom
      ? generateRandomizedNumbers(targetStudentIds.length)
      : Array.from({ length: targetStudentIds.length }, (_, i) => String(i + 1).padStart(3, '0'));

    for (let idx = 0; idx < targetStudentIds.length; idx++) {
      const sId = targetStudentIds[idx];
      const customCode = customCodeMap[sId];
      const defaultCode = `${roomCode}${studentNumbers[idx]}`;
      const accessNumber = customCode || defaultCode;

      const asgn = await prisma.examAssignment.upsert({
        where: { examId_studentId: { examId, studentId: sId } },
        create: {
          examId,
          studentId: sId,
          room: roomName,
          accessNumber,
          status: 'WAITING'
        },
        update: {
          room: roomName,
          accessNumber
        }
      });
      assignmentsCreated.push(asgn);
    }

    const updateData = {
      room: roomName,
      examCode: finalExamCode,
      status: finalStatus,
      startTime: parsedStartTime
    };

    if (durationMinutes && !isNaN(Number(durationMinutes))) {
      updateData.durationMinutes = Number(durationMinutes);
    }
    if (date) {
      try {
        updateData.date = new Date(date);
      } catch (e) {}
    }

    // Update Exam status to RUNNING or WAITING, set room, examCode & startTime
    const updatedExam = await prisma.exam.update({
      where: { id: examId },
      data: updateData,
      include: {
        assignments: { include: { student: true } },
        problems: { include: { problem: true } }
      }
    });

    const statusMsg = finalStatus === 'RUNNING' ? 'lancé et en cours' : 'préparé en attente de lancement';

    return res.json({
      success: true,
      message: `Examen pour la salle "${roomName}" ${statusMsg} avec ${assignmentsCreated.length} étudiant(s) inscrits.`,
      exam: updatedExam,
      totalAssigned: assignmentsCreated.length
    });
  } catch (err) {
    console.error('launchExamWithRoom error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors du lancement de l'examen." });
  }
}

// Clone any existing exam session into a clean DRAFT Subject Template (.algoexam)
async function cloneExamAsTemplate(req, res) {
  try {
    const { id: examId } = req.params;
    const sourceExam = await prisma.exam.findUnique({
      where: { id: examId },
      include: { problems: true }
    });

    if (!sourceExam) {
      return res.status(404).json({ error: "Examen non trouvé." });
    }

    const teacherId = await getValidTeacherId(req.teacher?.teacherId || req.teacher?.id || sourceExam.teacherId);

    const newTemplate = await prisma.exam.create({
      data: {
        title: `${sourceExam.title} (Modèle)`,
        description: sourceExam.description || '',
        university: sourceExam.university,
        module: sourceExam.module,
        session: sourceExam.session,
        examCode: sourceExam.examCode || generateDefaultExamCode(),
        prefix: sourceExam.prefix || 'AL',
        durationMinutes: sourceExam.durationMinutes || 90,
        status: 'DRAFT',
        teacherId,
        maxViolationsAllowed: sourceExam.maxViolationsAllowed ?? 4,
        copyDisabled: sourceExam.copyDisabled ?? false,
        pasteDisabled: sourceExam.pasteDisabled ?? false,
        fullscreenRequired: sourceExam.fullscreenRequired ?? true,
        internetWarning: sourceExam.internetWarning ?? true,
        allowCodeBricks: sourceExam.allowCodeBricks ?? true,
        allowedBricks: sourceExam.allowedBricks || ["LIRE_TAB", "AFFICHER_TAB", "LIRE_MATRICE", "AFFICHER_MATRICE", "RECHERCHE_MAX", "TRI_BULLES"],
        allowedLanguages: sourceExam.allowedLanguages || ["ALGO"],
        problems: {
          create: (sourceExam.problems || []).map(ep => ({
            problemId: ep.problemId,
            orderIndex: ep.orderIndex,
            points: ep.points,
            weightTest: ep.weightTest,
            weightAst: ep.weightAst,
            weightAi: ep.weightAi,
            questionPoints: ep.questionPoints
          }))
        }
      },
      include: {
        problems: { include: { problem: true } }
      }
    });

    return res.json({
      success: true,
      message: `Modèle de sujet "${newTemplate.title}" créé avec succès.`,
      exam: newTemplate
    });
  } catch (err) {
    console.error('cloneExamAsTemplate error:', err);
    return res.status(500).json({ error: err.message || "Erreur lors de la duplication du modèle." });
  }
}

module.exports = {
  listExams,
  getExamDetails,
  createExam,
  updateExam,
  deleteExam,
  updateExamStatus,
  teacherEmergencyControl,
  getExamResults,
  exportSubmissionBundle,
  importSubmissionBundles,
  exportCorrectedResults,
  importCorrectedResults,
  exportExamTemplate,
  importExamTemplate,
  launchExamWithRoom,
  cloneExamAsTemplate
};
