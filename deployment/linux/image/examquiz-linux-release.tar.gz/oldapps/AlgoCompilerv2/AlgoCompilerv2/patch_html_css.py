import os
import re

with open('Exos/generate_app.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update KaTeX script tag with onload
old_katex = r'''    <!-- KaTeX CDN for crisp LaTeX mathematical rendering -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>'''

new_katex = r'''    <!-- KaTeX CDN for crisp LaTeX mathematical rendering -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js" onload="triggerKaTeXRender()"></script>'''

assert old_katex in content, "Could not find old_katex block"
content = content.replace(old_katex, new_katex, 1)

# 2. Update CSS for Tabs with distinct neon accents and non-wrapping triplets row
old_tabs_css = r'''        .tab-btn.active {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.15) 100%);
            border-color: var(--accent-primary);
            box-shadow: 0 0 20px rgba(99, 102, 241, 0.25), inset 0 0 12px rgba(99, 102, 241, 0.1);
        }

        .tab-btn.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: var(--accent-primary);
            border-radius: 4px;
            box-shadow: 0 0 10px var(--accent-primary);
        }'''

new_tabs_css = r'''        .tab-btn.active {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.15) 100%);
            border-color: var(--accent-primary);
            box-shadow: 0 0 20px rgba(99, 102, 241, 0.25), inset 0 0 12px rgba(99, 102, 241, 0.1);
        }

        .tab-btn:nth-child(1).active {
            border-color: #6366f1;
            box-shadow: 0 0 22px rgba(99, 102, 241, 0.35);
        }
        .tab-btn:nth-child(1).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #6366f1; border-radius: 4px; box-shadow: 0 0 10px #6366f1;
        }

        .tab-btn:nth-child(2).active {
            border-color: #10b981;
            box-shadow: 0 0 22px rgba(16, 185, 129, 0.35);
        }
        .tab-btn:nth-child(2).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #10b981; border-radius: 4px; box-shadow: 0 0 10px #10b981;
        }

        .tab-btn:nth-child(3).active {
            border-color: #f59e0b;
            box-shadow: 0 0 22px rgba(245, 158, 11, 0.35);
        }
        .tab-btn:nth-child(3).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #f59e0b; border-radius: 4px; box-shadow: 0 0 10px #f59e0b;
        }

        .tab-btn:nth-child(4).active {
            border-color: #38bdf8;
            box-shadow: 0 0 22px rgba(56, 189, 248, 0.35);
        }
        .tab-btn:nth-child(4).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #38bdf8; border-radius: 4px; box-shadow: 0 0 10px #38bdf8;
        }'''

assert old_tabs_css in content, "Could not find old_tabs_css"
content = content.replace(old_tabs_css, new_tabs_css, 1)

# 3. Update .triplets-array-row in CSS to nowrap so arcs do not cross wrapped lines
old_triplets_row_css = r'''        .triplets-array-row {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            position: relative;
            z-index: 5;
        }'''

new_triplets_row_css = r'''        .triplets-array-row {
            display: flex;
            gap: 12px;
            justify-content: flex-start;
            align-items: center;
            flex-wrap: nowrap;
            overflow-x: auto;
            padding: 10px 4px;
            position: relative;
            z-index: 5;
            scrollbar-width: thin;
        }'''

assert old_triplets_row_css in content, "Could not find old_triplets_row_css"
content = content.replace(old_triplets_row_css, new_triplets_row_css, 1)

# 4. Update Ex 1 controls to add Custom R input and direct rotation
old_ex1_controls = r'''                    <div style="display: flex; align-items: center; gap: 8px;">
                        <label style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Vitesse :</label>
                        <select id="mat-speed-select" class="select-modern" onchange="updateMatrixSpeed()">
                            <option value="800">Lente (0.8s)</option>
                            <option value="450" selected>Normale (0.45s)</option>
                            <option value="200">Rapide (0.2s)</option>
                        </select>
                    </div>
                </div>'''

new_ex1_controls = r'''                    <div style="display: flex; align-items: center; gap: 8px;">
                        <label style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Vitesse :</label>
                        <select id="mat-speed-select" class="select-modern" onchange="updateMatrixSpeed()">
                            <option value="800">Lente (0.8s)</option>
                            <option value="450" selected>Normale (0.45s)</option>
                            <option value="200">Rapide (0.2s)</option>
                        </select>
                    </div>

                    <div style="display: flex; align-items: center; gap: 8px;">
                        <label style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Rotations R :</label>
                        <input type="number" id="mat-custom-r-input" value="4" min="1" max="100" class="input-modern" style="width:65px;">
                        <button class="btn-ghost" onclick="applyDirectRotationsR()">
                            <span>⚡</span> Appliquer R
                        </button>
                    </div>
                </div>'''

assert old_ex1_controls in content, "Could not find old_ex1_controls"
content = content.replace(old_ex1_controls, new_ex1_controls, 1)

# 5. Update Ex 1 ring legend bar to be dynamic container id="mat-perimeters-bar"
old_ex1_legend = r'''                    <div class="ring-legend-bar">
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <span style="display:inline-block; width:14px; height:14px; background:rgba(6,182,212,0.3); border:1.5px solid #06b6d4; border-radius:3px;"></span>
                            <b>Anneau 0 (Périmètre externe) :</b> <span id="p-ring-0">$P_0 = 12$</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <span style="display:inline-block; width:14px; height:14px; background:rgba(245,158,11,0.3); border:1.5px solid #f59e0b; border-radius:3px;"></span>
                            <b>Anneau 1 (Périmètre interne) :</b> <span id="p-ring-1">$P_1 = 4$</span>
                        </div>
                        <div style="color: var(--text-heading); font-family: var(--font-mono);">
                            Rotations effectuées : <b id="mat-counter-display" style="color: var(--accent-cyan);">0</b>
                        </div>
                    </div>'''

new_ex1_legend = r'''                    <div class="ring-legend-bar" id="mat-perimeters-bar" style="display:flex; flex-wrap:wrap; gap:16px; align-items:center;">
                        <!-- Rendu dynamique par updateRingPerimetersUI() -->
                    </div>'''

assert old_ex1_legend in content, "Could not find old_ex1_legend"
content = content.replace(old_ex1_legend, new_ex1_legend, 1)

# 6. Update Ex 2 controls: add custom DNA input field
old_ex2_controls = r'''                    <button class="btn-ghost" onclick="resetDnaState()">
                        <span>↺</span> Réinitialiser
                    </button>
                </div>'''

new_ex2_controls = r'''                    <button class="btn-ghost" onclick="resetDnaState()">
                        <span>↺</span> Réinitialiser
                    </button>

                    <div style="display:flex; align-items:center; gap:8px; margin-left:auto;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Saisie ADN :</label>
                        <input type="text" id="dna-custom-input" placeholder="Ex: ACGTGCAATGCA..." class="input-modern" style="width:200px; text-transform:uppercase;" oninput="onCustomDnaInput()">
                        <span id="dna-custom-msg" style="font-size:0.75rem;"></span>
                    </div>
                </div>'''

assert old_ex2_controls in content, "Could not find old_ex2_controls"
content = content.replace(old_ex2_controls, new_ex2_controls, 1)

# 7. Update Ex 3 filtered canvas to have scan-box overlay too, and scan button id
old_ex3_btn = r'''                <div class="controls-panel">
                    <button class="btn-modern" onclick="animateMedianScan()">
                        <span>▶</span> Lancer le Balayage Animé
                    </button>'''

new_ex3_btn = r'''                <div class="controls-panel">
                    <button class="btn-modern" id="median-scan-btn" onclick="animateMedianScan()">
                        <span id="median-scan-btn-icon">▶</span> <span id="median-scan-btn-label">Lancer le Balayage Animé</span>
                    </button>'''

assert old_ex3_btn in content, "Could not find old_ex3_btn"
content = content.replace(old_ex3_btn, new_ex3_btn, 1)

old_ex3_filtered_canvas = r'''                    <div class="canvas-card" style="border-color: rgba(16, 185, 129, 0.4);">
                        <div class="canvas-title" style="color:#34d399;">
                            <span>●</span> 3. Image Restaurée (Filtre Médian)
                        </div>
                        <div class="canvas-frame" style="border-color: #10b981;">
                            <canvas id="cv-filtered" class="pixel-canvas" width="64" height="64" style="width:220px; height:220px;"></canvas>
                        </div>
                        <div style="font-size:0.75rem; color:#34d399; margin-top:8px;" id="denoise-stats-text">
                            Bruits 0 et 255 éliminés avec succès !
                        </div>
                    </div>'''

new_ex3_filtered_canvas = r'''                    <div class="canvas-card" style="border-color: rgba(16, 185, 129, 0.4);">
                        <div class="canvas-title" style="color:#34d399;">
                            <span>●</span> 3. Image Restaurée (Filtre Médian)
                        </div>
                        <div class="canvas-frame" style="border-color: #10b981;">
                            <canvas id="cv-filtered" class="pixel-canvas" width="64" height="64" style="width:220px; height:220px;"></canvas>
                            <div id="scan-box-filtered" class="scan-overlay-box" style="border-color:#10b981;"></div>
                        </div>
                        <div style="font-size:0.75rem; color:#34d399; margin-top:8px;" id="denoise-stats-text">
                            Bruits 0 et 255 éliminés avec succès !
                        </div>
                    </div>'''

assert old_ex3_filtered_canvas in content, "Could not find old_ex3_filtered_canvas"
content = content.replace(old_ex3_filtered_canvas, new_ex3_filtered_canvas, 1)

# 8. Update Ex 4 controls: add presets and custom array input
old_ex4_controls = r'''                <div class="controls-panel">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Raison $d$ :</label>
                        <input type="number" id="triplet-d-input" value="3" min="1" max="10" class="input-modern" style="width:70px;" onchange="updateTripletsDifference()">
                    </div>

                    <button class="btn-modern" onclick="stepTripletAlgorithm()">
                        <span>▶</span> Pas Suivant (Tester $A[i]$)
                    </button>'''

new_ex4_controls = r'''                <div class="controls-panel">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Raison $d$ :</label>
                        <input type="number" id="triplet-d-input" value="3" min="1" max="10" class="input-modern" style="width:60px;" onchange="updateTripletsDifference()">
                    </div>

                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Presets :</label>
                        <select id="triplet-preset-select" class="select-modern" onchange="loadTripletPreset()">
                            <option value="standard">[1, 2, 4, 5, 7, 8, 10, 12, 13, 16] (d=3)</option>
                            <option value="arithmetic">[1, 3, 5, 7, 9, 11, 13, 15] (d=2)</option>
                            <option value="multiple">[2, 5, 8, 11, 14, 17, 20] (d=3)</option>
                            <option value="sparse">[1, 6, 7, 11, 13, 16, 21] (d=5)</option>
                        </select>
                    </div>

                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Tableau :</label>
                        <input type="text" id="triplet-custom-input" placeholder="Ex: 1, 4, 7, 10, 13..." class="input-modern" style="width:170px;" onchange="onCustomTripletInput()">
                    </div>

                    <button class="btn-modern" onclick="stepTripletAlgorithm()">
                        <span>▶</span> Pas Suivant
                    </button>'''

assert old_ex4_controls in content, "Could not find old_ex4_controls"
content = content.replace(old_ex4_controls, new_ex4_controls, 1)

# Write intermediate check
with open('Exos/generate_app.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Part 1: HTML & CSS updates applied successfully!")
