# -*- coding: utf-8 -*-
"""
Generator script for the modernized, stylish Exos/index.html
Includes:
- KaTeX CDN integration for clean LaTeX mathematical rendering
- Non-scrollable responsive 4-tab navigation grid
- Realistic animations and interactive simulations:
  1. Matrix Rings Rotation with 2D grid, directional arrows, and 1D unrolling ribbon
  2. Steady Bear DNA with nucleotide cards, interactive sliding window, balance gauges, and repair synthesizer
  3. Real Image Median Filter on Canvas with synthetic scene, noise slider, animated scanline, and 3x3 magnifier/sorter
  4. Beautiful Triplets with SVG curved connector arcs and binary search pointer visualizer
- Syntax-highlighted AlgoCompiler code blocks and verified execution traces
"""

import os

HTML_CONTENT = r'''<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercices Algorithmiques Avancés - Compilateur Algo</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- KaTeX CDN for crisp LaTeX mathematical rendering -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js" onload="triggerKaTeXRender()"></script>

    <style>
        :root {
            --bg-base: #080c14;
            --bg-surface: #0f172a;
            --bg-card: rgba(17, 24, 39, 0.85);
            --bg-card-sub: #1e293b;
            --bg-input: #0b1120;
            --border-subtle: rgba(255, 255, 255, 0.08);
            --border-medium: rgba(255, 255, 255, 0.15);
            --border-glow: rgba(99, 102, 241, 0.5);
            
            --accent-primary: #6366f1;
            --accent-primary-hover: #4f46e5;
            --accent-cyan: #06b6d4;
            --accent-emerald: #10b981;
            --accent-amber: #f59e0b;
            --accent-rose: #f43f5e;
            --accent-purple: #a855f7;

            --text-heading: #f8fafc;
            --text-body: #cbd5e1;
            --text-muted: #94a3b8;
            --text-dim: #64748b;

            --font-sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            --font-mono: 'JetBrains Mono', 'Consolas', monospace;

            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-xl: 20px;

            --shadow-subtle: 0 4px 12px rgba(0, 0, 0, 0.3);
            --shadow-card: 0 10px 30px -10px rgba(0, 0, 0, 0.5), 0 0 1px 1px rgba(255, 255, 255, 0.05);
            --shadow-glow: 0 0 25px rgba(99, 102, 241, 0.25);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: var(--font-sans);
            background-color: var(--bg-base);
            background-image: 
                radial-gradient(circle at 15% 10%, rgba(99, 102, 241, 0.12) 0%, transparent 45%),
                radial-gradient(circle at 85% 20%, rgba(6, 182, 212, 0.08) 0%, transparent 45%),
                radial-gradient(circle at 50% 90%, rgba(168, 85, 247, 0.07) 0%, transparent 50%);
            background-attachment: fixed;
            color: var(--text-body);
            line-height: 1.6;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        /* Ambient Header */
        header {
            position: relative;
            background: linear-gradient(180deg, rgba(15, 23, 42, 0.9) 0%, rgba(8, 12, 20, 0.95) 100%);
            border-bottom: 1px solid var(--border-subtle);
            backdrop-filter: blur(16px);
            padding: 40px 20px 30px;
            text-align: center;
        }

        .header-content {
            max-width: 1280px;
            margin: 0 auto;
        }

        .badge-pill-main {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(99, 102, 241, 0.15);
            border: 1px solid rgba(99, 102, 241, 0.35);
            color: #a5b4fc;
            padding: 6px 16px;
            border-radius: 9999px;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            margin-bottom: 16px;
            box-shadow: 0 0 15px rgba(99, 102, 241, 0.2);
        }

        .badge-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #6366f1;
            box-shadow: 0 0 8px #6366f1;
        }

        h1 {
            font-size: clamp(2rem, 4vw, 2.8rem);
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #ffffff 0%, #cbd5e1 40%, #818cf8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 12px;
        }

        p.subtitle {
            font-size: 1.05rem;
            color: var(--text-muted);
            max-width: 840px;
            margin: 0 auto 20px;
        }

        .header-tags {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 8px;
        }

        .meta-tag {
            background: rgba(30, 41, 59, 0.6);
            border: 1px solid var(--border-subtle);
            color: #94a3b8;
            padding: 5px 12px;
            border-radius: var(--radius-sm);
            font-size: 0.8rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .meta-tag.success {
            border-color: rgba(16, 185, 129, 0.3);
            color: #34d399;
            background: rgba(16, 185, 129, 0.1);
        }

        /* NON-SCROLLABLE TABS NAV (Grid layout that fits 100% cleanly) */
        .tabs-nav-sticky {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(8, 12, 20, 0.85);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-subtle);
            padding: 12px 0;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
        }

        .tabs-nav-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 20px;
        }

        @media (max-width: 960px) {
            .tabs-nav-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 540px) {
            .tabs-nav-grid {
                grid-template-columns: 1fr;
            }
        }

        .tab-btn {
            background: rgba(17, 24, 39, 0.7);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            padding: 12px 14px;
            cursor: pointer;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            text-align: left;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .tab-btn:hover {
            background: rgba(30, 41, 59, 0.9);
            border-color: var(--border-medium);
            transform: translateY(-2px);
        }

        .tab-btn.active {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.15) 100%);
            border-color: var(--accent-primary);
            box-shadow: 0 0 20px rgba(99, 102, 241, 0.25), inset 0 0 12px rgba(99, 102, 241, 0.1);
        }

        .tab-btn:nth-child(1).active {
            border-color: #6366f1;
            box-shadow: 0 0 22px rgba(99, 102, 241, 0.35);
        }
        .tab-btn:nth-child(1).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #6366f1; border-radius: 4px; box-shadow: 0 0 10px #6366f1;
        }

        .tab-btn:nth-child(2).active {
            border-color: #10b981;
            box-shadow: 0 0 22px rgba(16, 185, 129, 0.35);
        }
        .tab-btn:nth-child(2).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #10b981; border-radius: 4px; box-shadow: 0 0 10px #10b981;
        }

        .tab-btn:nth-child(3).active {
            border-color: #f59e0b;
            box-shadow: 0 0 22px rgba(245, 158, 11, 0.35);
        }
        .tab-btn:nth-child(3).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #f59e0b; border-radius: 4px; box-shadow: 0 0 10px #f59e0b;
        }

        .tab-btn:nth-child(4).active {
            border-color: #38bdf8;
            box-shadow: 0 0 22px rgba(56, 189, 248, 0.35);
        }
        .tab-btn:nth-child(4).active::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
            background: #38bdf8; border-radius: 4px; box-shadow: 0 0 10px #38bdf8;
        }

        .tab-icon-box {
            width: 38px;
            height: 38px;
            border-radius: var(--radius-sm);
            background: rgba(30, 41, 59, 0.8);
            border: 1px solid var(--border-subtle);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            flex-shrink: 0;
            transition: all 0.2s;
        }

        .tab-btn.active .tab-icon-box {
            background: rgba(99, 102, 241, 0.3);
            border-color: rgba(99, 102, 241, 0.5);
            transform: scale(1.05);
        }

        .tab-info {
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .tab-num {
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.6px;
            color: var(--text-muted);
        }

        .tab-btn.active .tab-num {
            color: #a5b4fc;
        }

        .tab-title {
            font-size: 0.92rem;
            font-weight: 700;
            color: var(--text-heading);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Main Container */
        main {
            max-width: 1280px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .tab-content {
            display: none;
            opacity: 0;
            transform: translateY(12px);
            transition: opacity 0.3s ease, transform 0.3s ease;
        }

        .tab-content.active {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }

        /* Modern Cards */
        .glass-card {
            background: var(--bg-card);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-xl);
            padding: 28px;
            margin-bottom: 28px;
            box-shadow: var(--shadow-card);
            backdrop-filter: blur(12px);
            position: relative;
        }

        .card-header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 14px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border-subtle);
            margin-bottom: 20px;
        }

        .card-title-group {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .card-title-group h2, .card-title-group h3 {
            font-size: 1.35rem;
            font-weight: 700;
            color: var(--text-heading);
            letter-spacing: -0.3px;
        }

        .pill-badge {
            font-size: 0.75rem;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 9999px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .pill-cyan { background: rgba(6, 182, 212, 0.15); color: #38bdf8; border: 1px solid rgba(6, 182, 212, 0.3); }
        .pill-emerald { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
        .pill-amber { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
        .pill-rose { background: rgba(244, 63, 94, 0.15); color: #fb7185; border: 1px solid rgba(244, 63, 94, 0.3); }
        .pill-purple { background: rgba(168, 85, 247, 0.15); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.3); }

        /* Callouts */
        .banner-curriculum {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(6, 182, 212, 0.05) 100%);
            border: 1px solid rgba(16, 185, 129, 0.25);
            border-left: 4px solid var(--accent-emerald);
            padding: 14px 18px;
            border-radius: var(--radius-md);
            margin: 16px 0;
            font-size: 0.92rem;
            color: #a7f3d0;
        }

        .banner-math {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.08) 0%, rgba(168, 85, 247, 0.05) 100%);
            border: 1px solid rgba(99, 102, 241, 0.25);
            border-left: 4px solid var(--accent-primary);
            padding: 18px 22px;
            border-radius: var(--radius-md);
            margin: 18px 0;
            font-size: 0.95rem;
            color: #e2e8f0;
        }

        /* Buttons & Control Panels */
        .controls-panel {
            background: rgba(11, 17, 32, 0.7);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            margin-bottom: 22px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 12px;
        }

        .btn-modern {
            background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
            color: #ffffff;
            border: none;
            padding: 9px 18px;
            border-radius: var(--radius-sm);
            font-family: var(--font-sans);
            font-size: 0.88rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }

        .btn-modern:hover {
            background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);
            transform: translateY(-1px);
            box-shadow: 0 6px 16px rgba(99, 102, 241, 0.4);
        }

        .btn-modern:active {
            transform: translateY(0);
        }

        .btn-ghost {
            background: rgba(30, 41, 59, 0.8);
            border: 1px solid var(--border-subtle);
            color: var(--text-heading);
            padding: 9px 16px;
            border-radius: var(--radius-sm);
            font-family: var(--font-sans);
            font-size: 0.88rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-ghost:hover {
            background: rgba(51, 65, 85, 0.9);
            border-color: var(--border-medium);
        }

        .select-modern, .input-modern {
            background: var(--bg-input);
            border: 1px solid var(--border-subtle);
            color: var(--text-heading);
            padding: 8px 14px;
            border-radius: var(--radius-sm);
            font-family: var(--font-sans);
            font-size: 0.88rem;
            font-weight: 500;
            outline: none;
            transition: border-color 0.2s;
        }

        .select-modern:focus, .input-modern:focus {
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
        }

        /* SIMULATION 1: MATRIX RINGS */
        .matrix-sim-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 24px;
            padding: 20px;
            background: rgba(11, 17, 32, 0.6);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border-subtle);
        }

        .matrix-viewport {
            position: relative;
            padding: 24px;
            background: #060911;
            border-radius: var(--radius-lg);
            border: 2px solid #1e293b;
            box-shadow: inset 0 0 30px rgba(0,0,0,0.8);
        }

        .matrix-grid-modern {
            display: grid;
            gap: 8px;
        }

        .mat-cell {
            width: 54px;
            height: 54px;
            border-radius: var(--radius-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-family: var(--font-mono);
            font-weight: 700;
            font-size: 1.15rem;
            position: relative;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            user-select: none;
            box-shadow: 0 2px 6px rgba(0,0,0,0.4);
        }

        .mat-cell-coord {
            font-size: 0.62rem;
            opacity: 0.6;
            margin-top: 1px;
            font-weight: 400;
        }

        .ring-0 {
            background: rgba(6, 182, 212, 0.12);
            border: 1.5px solid #06b6d4;
            color: #38bdf8;
        }

        .ring-1 {
            background: rgba(245, 158, 11, 0.12);
            border: 1.5px solid #f59e0b;
            color: #fbbf24;
        }

        .ring-2 {
            background: rgba(168, 85, 247, 0.12);
            border: 1.5px solid #a855f7;
            color: #c084fc;
        }

        .mat-cell.shifting {
            transform: scale(1.12);
            box-shadow: 0 0 16px var(--accent-rose);
            border-color: var(--accent-rose) !important;
            background: rgba(244, 63, 94, 0.25) !important;
            z-index: 5;
        }

        /* Directional arrows indicator */
        .ring-legend-bar {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            justify-content: center;
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .ring-unroll-container {
            width: 100%;
            max-width: 800px;
            background: #090e1a;
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            padding: 14px 18px;
        }

        .unroll-title {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.7px;
            color: var(--text-muted);
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
        }

        .unroll-cells-strip {
            display: flex;
            gap: 6px;
            overflow-x: auto;
            padding-bottom: 6px;
        }

        .unroll-cell {
            min-width: 44px;
            height: 44px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: var(--font-mono);
            font-weight: 700;
            font-size: 0.95rem;
            flex-shrink: 0;
            border: 1px solid #334155;
            background: #1e293b;
            color: #f1f5f9;
            transition: all 0.25s;
        }

        /* SIMULATION 2: STEADY BEAR DNA */
        .dna-workspace {
            display: flex;
            flex-direction: column;
            gap: 22px;
        }

        .dna-strand-card {
            background: #060911;
            border: 2px solid #1e293b;
            border-radius: var(--radius-lg);
            padding: 24px;
            overflow-x: auto;
            position: relative;
        }

        .dna-track {
            display: flex;
            gap: 8px;
            padding: 20px 10px;
            min-width: max-content;
            position: relative;
        }

        .dna-node {
            width: 48px;
            height: 64px;
            border-radius: var(--radius-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-family: var(--font-mono);
            font-weight: 800;
            font-size: 1.35rem;
            position: relative;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid transparent;
            box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        }

        .dna-node-idx {
            font-size: 0.65rem;
            font-weight: 500;
            color: var(--text-dim);
            margin-top: 2px;
        }

        .dna-node-name {
            font-size: 0.55rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 2px;
            opacity: 0.8;
        }

        .dna-node-A { background: rgba(16, 185, 129, 0.15); color: #34d399; border-color: #059669; }
        .dna-node-C { background: rgba(6, 182, 212, 0.15); color: #38bdf8; border-color: #0284c7; }
        .dna-node-G { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border-color: #d97706; }
        .dna-node-T { background: rgba(244, 63, 94, 0.15); color: #fb7185; border-color: #e11d48; }

        .dna-node.in-window {
            transform: translateY(-6px);
            border-color: #c084fc !important;
            background: rgba(168, 85, 247, 0.28) !important;
            box-shadow: 0 8px 20px rgba(168, 85, 247, 0.4);
        }

        .dna-window-badge {
            position: absolute;
            top: -24px;
            font-size: 0.7rem;
            font-weight: 800;
            color: #c084fc;
            background: rgba(168, 85, 247, 0.2);
            padding: 1px 6px;
            border-radius: 4px;
            border: 1px solid rgba(168, 85, 247, 0.4);
        }

        .dna-gauges-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
        }

        @media (max-width: 768px) {
            .dna-gauges-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        .gauge-card {
            background: #0b1120;
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            padding: 14px;
            position: relative;
            overflow: hidden;
        }

        .gauge-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .gauge-base-name {
            font-weight: 700;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .gauge-bar-bg {
            height: 8px;
            background: #1e293b;
            border-radius: 4px;
            overflow: hidden;
            margin: 8px 0;
        }

        .gauge-bar-fill {
            height: 100%;
            transition: width 0.3s ease, background-color 0.3s ease;
        }

        .gauge-status {
            font-size: 0.78rem;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
        }

        /* SIMULATION 3: REAL IMAGE MEDIAN FILTER ON CANVAS */
        .median-canvas-layout {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }

        .canvas-card {
            background: #090e1a;
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            padding: 18px;
            text-align: center;
            position: relative;
        }

        .canvas-title {
            font-size: 0.95rem;
            font-weight: 700;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .canvas-frame {
            display: inline-block;
            position: relative;
            border: 2px solid #334155;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background: #000;
            box-shadow: 0 4px 16px rgba(0,0,0,0.6);
        }

        canvas.pixel-canvas {
            image-rendering: -moz-crisp-edges;
            image-rendering: -webkit-crisp-edges;
            image-rendering: pixelated;
            image-rendering: crisp-edges;
            display: block;
            cursor: crosshair;
        }

        .scan-overlay-box {
            position: absolute;
            border: 2px solid #f43f5e;
            background: rgba(244, 63, 94, 0.2);
            pointer-events: none;
            display: none;
            box-shadow: 0 0 10px #f43f5e;
            transition: all 0.05s ease;
        }

        /* Magnifier & sorting pipeline */
        .median-inspector-card {
            background: #060911;
            border: 1px solid #1e293b;
            border-radius: var(--radius-lg);
            padding: 20px;
            margin-top: 16px;
        }

        .inspector-flex {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 24px;
            justify-content: space-around;
        }

        .kernel-matrix-3x3 {
            display: grid;
            grid-template-columns: repeat(3, 46px);
            gap: 4px;
            padding: 10px;
            background: #111827;
            border-radius: var(--radius-md);
            border: 1px solid #374151;
        }

        .k-cell {
            width: 46px;
            height: 46px;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: var(--font-mono);
            font-size: 0.85rem;
            font-weight: 700;
            border: 1px solid #4b5563;
        }

        .k-center {
            border: 2px solid #38bdf8 !important;
            box-shadow: 0 0 8px #38bdf8;
        }

        .sorting-pipeline {
            display: flex;
            flex-direction: column;
            gap: 10px;
            flex: 1;
            min-width: 280px;
        }

        .sorted-array-strip {
            display: flex;
            gap: 4px;
            overflow-x: auto;
            padding: 4px 0;
        }

        .s-cell {
            min-width: 38px;
            height: 40px;
            border-radius: 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-family: var(--font-mono);
            font-size: 0.8rem;
            font-weight: 700;
            border: 1px solid #374151;
            background: #1f2937;
            color: #f3f4f6;
        }

        .s-median {
            border: 2px solid #10b981 !important;
            background: rgba(16, 185, 129, 0.25) !important;
            color: #34d399 !important;
            box-shadow: 0 0 12px rgba(16, 185, 129, 0.4);
            transform: scale(1.08);
        }

        .s-pepper {
            border-color: #64748b;
            color: #94a3b8;
            opacity: 0.7;
        }

        .s-salt {
            border-color: #f43f5e;
            color: #fda4af;
            opacity: 0.7;
        }

        /* SIMULATION 4: BEAUTIFUL TRIPLETS */
        .triplets-stage {
            position: relative;
            background: #060911;
            border: 2px solid #1e293b;
            border-radius: var(--radius-lg);
            padding: 80px 20px 30px;
            margin-bottom: 24px;
            overflow: hidden;
        }

        .triplets-svg-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 10;
        }

        .triplets-array-row {
            display: flex;
            gap: 12px;
            justify-content: flex-start;
            align-items: center;
            flex-wrap: nowrap;
            overflow-x: auto;
            padding: 10px 4px;
            position: relative;
            z-index: 5;
            scrollbar-width: thin;
        }

        .triplet-box {
            min-width: 54px;
            height: 60px;
            border-radius: var(--radius-sm);
            background: #111827;
            border: 2px solid #374151;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-family: var(--font-mono);
            font-weight: 700;
            font-size: 1.25rem;
            color: #f8fafc;
            transition: all 0.25s;
            position: relative;
        }

        .triplet-idx {
            font-size: 0.65rem;
            color: var(--text-dim);
            font-weight: 500;
        }

        .triplet-box.active-i {
            border-color: #38bdf8;
            background: rgba(56, 189, 248, 0.2);
            color: #38bdf8;
            box-shadow: 0 0 14px rgba(56, 189, 248, 0.4);
        }

        .triplet-box.active-j {
            border-color: #f59e0b;
            background: rgba(245, 158, 11, 0.2);
            color: #fbbf24;
            box-shadow: 0 0 14px rgba(245, 158, 11, 0.4);
        }

        .triplet-box.active-k {
            border-color: #10b981;
            background: rgba(16, 185, 129, 0.2);
            color: #34d399;
            box-shadow: 0 0 14px rgba(16, 185, 129, 0.4);
        }

        .triplet-box.bs-mid {
            border-color: #c084fc;
            background: rgba(168, 85, 247, 0.2);
        }

        .triplet-list-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 12px;
        }

        .triplet-record-card {
            background: #0b1120;
            border-left: 4px solid var(--accent-emerald);
            border-top: 1px solid var(--border-subtle);
            border-right: 1px solid var(--border-subtle);
            border-bottom: 1px solid var(--border-subtle);
            border-radius: var(--radius-sm);
            padding: 10px 14px;
            font-family: var(--font-mono);
            font-size: 0.88rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .triplet-record-card:hover {
            background: #1e293b;
            transform: translateX(4px);
        }

        /* CODE CONTAINERS & TERMINALS */
        .code-block-modern {
            background: #060911;
            border: 1px solid #1e293b;
            border-radius: var(--radius-md);
            overflow: hidden;
            margin: 18px 0;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
        }

        .code-block-header {
            background: #0f172a;
            border-bottom: 1px solid #1e293b;
            padding: 10px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .code-file-label {
            font-family: var(--font-mono);
            font-size: 0.8rem;
            color: #94a3b8;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-copy {
            background: rgba(51, 65, 85, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #e2e8f0;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-copy:hover {
            background: var(--accent-primary);
            color: #fff;
        }

        pre {
            padding: 18px;
            font-family: var(--font-mono);
            font-size: 0.88rem;
            line-height: 1.55;
            color: #e2e8f0;
            overflow-x: auto;
            tab-size: 4;
        }

        /* Syntax colors */
        .kw { color: #c084fc; font-weight: 700; }
        .ty { color: #38bdf8; }
        .fn { color: #fde047; }
        .st { color: #86efac; }
        .cm { color: #64748b; font-style: italic; }
        .num { color: #fb923c; }

        /* Console Terminal Output */
        .terminal-block {
            background: #020617;
            border: 1px solid #1e293b;
            border-radius: var(--radius-md);
            padding: 16px 20px;
            font-family: var(--font-mono);
            font-size: 0.85rem;
            color: #4ade80;
            white-space: pre;
            overflow-x: auto;
            box-shadow: inset 0 2px 10px rgba(0,0,0,0.8);
            line-height: 1.5;
        }

        .terminal-tag {
            color: #94a3b8;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
            border-bottom: 1px solid #1e293b;
            padding-bottom: 6px;
            display: flex;
            justify-content: space-between;
        }

        /* Step decomposition */
        .step-container {
            background: rgba(15, 23, 42, 0.5);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            padding: 20px;
            margin-bottom: 16px;
        }

        .step-heading {
            font-size: 1.05rem;
            font-weight: 700;
            color: #38bdf8;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        footer {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-dim);
            font-size: 0.85rem;
            border-top: 1px solid var(--border-subtle);
            margin-top: 60px;
        }

        /* Toast notification */
        #toast {
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: #10b981;
            color: #ffffff;
            padding: 10px 18px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.88rem;
            box-shadow: 0 4px 16px rgba(0,0,0,0.4);
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 9999;
        }
        #toast.show {
            transform: translateY(0);
            opacity: 1;
        }
    </style>
</head>
<body>

    <header>
        <div class="header-content">
            <div class="badge-pill-main">
                <span class="badge-dot"></span>
                ALGOCOMPILER INTERACTIVE LAB
            </div>
            <h1>Exercices Algorithmiques Avancés</h1>
            <p class="subtitle">
                Simulations graphiques temps réel, modélisation mathématique et solutions algorithmiques validées sur <code>AlgoCompiler</code>.
            </p>
            <div class="header-tags">
                <span class="meta-tag">🔄 Matrices & Modulo</span>
                <span class="meta-tag">🧬 Fenêtre Glissante (Two Pointers)</span>
                <span class="meta-tag">🖼️ Traitement d'Image Canvas</span>
                <span class="meta-tag">🔢 Recherche Dichotomique</span>
                <span class="meta-tag success">✔ Solutions Compilées & Validées</span>
            </div>
        </div>
    </header>

    <!-- NAVIGATION PAR ONGLETS (GRILLE RESPONSIVE SANS DÉFILEMENT HORIZONTAL) -->
    <div class="tabs-nav-sticky">
        <nav class="tabs-nav-grid" id="main-tabs-nav">
            <button class="tab-btn active" onclick="switchExercise(0)">
                <div class="tab-icon-box">🔄</div>
                <div class="tab-info">
                    <span class="tab-num">Exercice 1</span>
                    <span class="tab-title">Rotation des Anneaux</span>
                </div>
            </button>
            <button class="tab-btn" onclick="switchExercise(1)">
                <div class="tab-icon-box">🧬</div>
                <div class="tab-info">
                    <span class="tab-num">Exercice 2</span>
                    <span class="tab-title">ADN Équilibré (Steady Bear)</span>
                </div>
            </button>
            <button class="tab-btn" onclick="switchExercise(2)">
                <div class="tab-icon-box">🖼️</div>
                <div class="tab-info">
                    <span class="tab-num">Exercice 3</span>
                    <span class="tab-title">Filtre Médian (Image)</span>
                </div>
            </button>
            <button class="tab-btn" onclick="switchExercise(3)">
                <div class="tab-icon-box">🔢</div>
                <div class="tab-info">
                    <span class="tab-num">Exercice 4</span>
                    <span class="tab-title">Triplets Magnifiques</span>
                </div>
            </button>
        </nav>
    </div>

    <main>

        <!-- ============================================================== -->
        <!-- EXERCICE 1 : ROTATION DES ANNEAUX D'UNE MATRICE               -->
        <!-- ============================================================== -->
        <section id="tab-pane-0" class="tab-content active">
            
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.6rem;">🔄</span>
                        <div>
                            <h2>Exercice 1 : Rotation des Anneaux d'une Matrice</h2>
                            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 2px;">
                                Décomposition concentrique, périmètre d'anneau et optimisation modulaire
                            </div>
                        </div>
                    </div>
                    <span class="pill-badge pill-cyan">Matrices 2D & Modulo</span>
                </div>

                <p>
                    <strong>Énoncé Mathématique :</strong> Soit une matrice $M \times N$ d'entiers où $\min(M, N)$ est un nombre pair.
                    Une telle matrice est formée d'exactement $K = \frac{\min(M, N)}{2}$ anneaux concentriques indépendants.
                    On souhaite faire pivoter chaque anneau $k \in \{0, 1, \dots, K-1\}$ dans le sens <strong>anti-horaire</strong> 
                    (counter-clockwise) d'un nombre $R$ de positions.
                </p>

                <div class="banner-math">
                    <strong>Formulation du Périmètre et Réduction par Modulo :</strong><br>
                    Pour l'anneau $k$ délimité par les indices de ligne $[k, M-1-k]$ et de colonne $[k, N-1-k]$, 
                    le nombre total d'éléments formant son périmètre est :
                    $$P_k = 2 \times (M - 2k) + 2 \times (N - 2k) - 4$$
                    Effectuer $P_k$ rotations complètes ramène chaque valeur à sa coordonnée d'origine exacte.
                    Le nombre effectif minimal de décalages unitaires requis est donc :
                    $$R_{\text{eff}} = R \pmod{P_k}$$
                    Cette formule évite des millions d'opérations superflues lorsque $R \gg P_k$.
                </div>
            </div>

            <!-- SIMULATION INTERACTIVE RÉALISTE : MATRICE 2D + CONVOYEUR 1D -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.4rem;">🕹️</span>
                        <h3>Simulation Réelle : Dynamique Circulaire Anti-Horaire</h3>
                    </div>
                    <span class="pill-badge pill-amber">Visualisation Dynamique</span>
                </div>

                <p style="margin-bottom: 16px;">
                    Observez le mouvement pas à pas le long des 4 parois de chaque anneau. 
                    Les flèches indiquent le sens du flux : 
                    <span style="color:#38bdf8;">Haut $\leftarrow$ Gauche</span>, 
                    <span style="color:#38bdf8;">Gauche $\downarrow$ Bas</span>, 
                    <span style="color:#38bdf8;">Bas $\rightarrow$ Droite</span>, 
                    <span style="color:#38bdf8;">Droite $\uparrow$ Haut</span>.
                </p>

                <div class="controls-panel">
                    <button class="btn-modern" onclick="stepMatrixRotation()">
                        <span>▶</span> 1 Pas Anti-Horaire
                    </button>
                    <button class="btn-ghost" onclick="stepMatrixClockwise()">
                        <span>◀</span> 1 Pas Horaire
                    </button>
                    <button class="btn-ghost" onclick="toggleAutoMatrix()">
                        <span id="mat-play-icon">⏵</span> <span id="mat-play-label">Lecture Continue</span>
                    </button>
                    <button class="btn-ghost" onclick="resetMatrix()">
                        <span>↺</span> Réinitialiser
                    </button>
                    
                    <div style="display: flex; align-items: center; gap: 8px; margin-left: auto;">
                        <label style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Dimension :</label>
                        <select id="mat-dim-select" class="select-modern" onchange="changeMatrixDimension()">
                            <option value="4x4">4 × 4 (2 anneaux)</option>
                            <option value="5x5">5 × 5 (2 anneaux + centre)</option>
                            <option value="6x4">6 × 4 (2 anneaux)</option>
                        </select>
                    </div>

                    <div style="display: flex; align-items: center; gap: 8px;">
                        <label style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Vitesse :</label>
                        <select id="mat-speed-select" class="select-modern" onchange="updateMatrixSpeed()">
                            <option value="800">Lente (0.8s)</option>
                            <option value="450" selected>Normale (0.45s)</option>
                            <option value="200">Rapide (0.2s)</option>
                        </select>
                    </div>

                    <div style="display: flex; align-items: center; gap: 8px;">
                        <label style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Rotations R :</label>
                        <input type="number" id="mat-custom-r-input" value="4" min="1" max="100" class="input-modern" style="width:65px;">
                        <button class="btn-ghost" onclick="applyDirectRotationsR()">
                            <span>⚡</span> Appliquer R
                        </button>
                    </div>
                </div>

                <div class="matrix-sim-wrapper">
                    <!-- Grille 2D -->
                    <div class="matrix-viewport">
                        <div id="matrix-grid-elem" class="matrix-grid-modern">
                            <!-- Généré dynamiquement en JS -->
                        </div>
                    </div>

                    <div class="ring-legend-bar" id="mat-perimeters-bar" style="display:flex; flex-wrap:wrap; gap:16px; align-items:center;">
                        <!-- Rendu dynamique par updateRingPerimetersUI() -->
                    </div>

                    <!-- Déroulement 1D en ruban de l'Anneau 0 -->
                    <div class="ring-unroll-container">
                        <div class="unroll-title">
                            <span>📦 Ruban Déroulé 1D (Anneau 0 en ordre cyclique horaire)</span>
                            <span style="color: var(--accent-cyan);" id="unroll-status">Sens Anti-Horaire = Décalage vers la gauche</span>
                        </div>
                        <div id="unroll-strip-elem" class="unroll-cells-strip">
                            <!-- Généré dynamiquement -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- DÉCOMPOSITION EN PSEUDO-CODE -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">📋</span>
                        <h3>Décomposition Algorithmique par Parties</h3>
                    </div>
                    <span class="pill-badge pill-purple">Conception Modulaire</span>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 1 : Calcul du Nombre d'Anneaux et du Décalage Effectif</div>
                    <p>Pour chaque anneau $k$, on calcule la circonférence exacte pour appliquer l'opérateur modulo :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 1</span>
                        </div>
<pre><span class="kw">Si</span> M &lt; N <span class="kw">Alors</span> nb_anneaux &larr; M <span class="kw">div</span> <span class="num">2</span> <span class="kw">Sinon</span> nb_anneaux &larr; N <span class="kw">div</span> <span class="num">2</span> <span class="kw">Fsi</span>;
<span class="kw">Pour</span> k &larr; <span class="num">0</span> <span class="kw">a</span> nb_anneaux - <span class="num">1</span> <span class="kw">Faire</span>
    perimetre &larr; <span class="num">2</span> * (M - <span class="num">2</span>*k) + <span class="num">2</span> * (N - <span class="num">2</span>*k) - <span class="num">4</span>;
    r_eff &larr; R <span class="kw">mod</span> perimetre;
<span class="kw">FinPour</span>;</pre>
                    </div>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 2 : Décalage Anti-Horaire en Place des 4 Parois</div>
                    <p>Pour chaque décalage élémentaire, on sauvegarde le coin supérieur gauche, puis on décale successivement les 4 arêtes :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 2</span>
                        </div>
<pre><span class="cm">// Sauvegarde du premier élément</span>
temp &larr; mat[k][k];

<span class="cm">// 1. Paroi Supérieure : déplacement vers la GAUCHE</span>
<span class="kw">Pour</span> j &larr; k <span class="kw">a</span> N - <span class="num">2</span> - k <span class="kw">Faire</span>
    mat[k][j] &larr; mat[k][j + <span class="num">1</span>];
<span class="kw">FinPour</span>;

<span class="cm">// 2. Paroi Droite : déplacement vers le HAUT</span>
<span class="kw">Pour</span> i &larr; k <span class="kw">a</span> M - <span class="num">2</span> - k <span class="kw">Faire</span>
    mat[i][N - <span class="num">1</span> - k] &larr; mat[i + <span class="num">1</span>][N - <span class="num">1</span> - k];
<span class="kw">FinPour</span>;

<span class="cm">// 3. Paroi Inférieure : déplacement vers la DROITE</span>
j &larr; N - <span class="num">1</span> - k;
<span class="kw">Tant Que</span> j &gt; k <span class="kw">Faire</span>
    mat[M - <span class="num">1</span> - k][j] &larr; mat[M - <span class="num">1</span> - k][j - <span class="num">1</span>];
    j &larr; j - <span class="num">1</span>;
<span class="kw">FinTantQue</span>;

<span class="cm">// 4. Paroi Gauche : déplacement vers le BAS</span>
i &larr; M - <span class="num">1</span> - k;
<span class="kw">Tant Que</span> i &gt; k + <span class="num">1</span> <span class="kw">Faire</span>
    mat[i][k] &larr; mat[i - <span class="num">1</span>][k];
    i &larr; i - <span class="num">1</span>;
<span class="kw">FinTantQue</span>;

<span class="cm">// Insertion du coin sauvegardé</span>
mat[k + <span class="num">1</span>][k] &larr; temp;</pre>
                    </div>
                </div>
            </div>

            <!-- CODE OFFICIEL VALIDE ALGOCOMPILER -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">💻</span>
                        <h3>Code Source Certifié AlgoCompiler</h3>
                    </div>
                    <button class="btn-copy" onclick="copySourceCode('code-ex1')">Copier le Code .algo</button>
                </div>
                <div class="code-block-modern">
                    <div class="code-block-header">
                        <span class="code-file-label">Exos/01_rotation_anneaux_matrice.algo</span>
                        <span class="pill-badge pill-emerald">Exit Code 0</span>
                    </div>
<pre id="code-ex1"><span class="kw">Algorithme</span> RotationAnneauxMatrice;
<span class="kw">Var</span>
    mat[<span class="num">4</span>][<span class="num">4</span>] : <span class="ty">Entier</span>;
    M, N, R : <span class="ty">Entier</span>;
    nb_anneaux : <span class="ty">Entier</span>;
    k, step, r_eff, perimetre : <span class="ty">Entier</span>;
    i, j, temp : <span class="ty">Entier</span>;

<span class="kw">Debut</span>
    M := <span class="num">4</span>;
    N := <span class="num">4</span>;
    R := <span class="num">2</span>; <span class="cm">// Nombre de rotations anti-horaire</span>

    <span class="cm">// 1. Initialisation de la matrice 4x4 avec les entiers 1 a 16</span>
    temp := <span class="num">1</span>;
    <span class="kw">Pour</span> i := <span class="num">0</span> <span class="kw">a</span> M - <span class="num">1</span> <span class="kw">Faire</span>
        <span class="kw">Pour</span> j := <span class="num">0</span> <span class="kw">a</span> N - <span class="num">1</span> <span class="kw">Faire</span>
            mat[i][j] := temp;
            temp := temp + <span class="num">1</span>;
        <span class="kw">FinPour</span>
    <span class="kw">FinPour</span>

    <span class="cm">// 2. Calcul du nombre d'anneaux</span>
    <span class="kw">Si</span> M &lt; N <span class="kw">Alors</span>
        nb_anneaux := M / <span class="num">2</span>;
    <span class="kw">Sinon</span>
        nb_anneaux := N / <span class="num">2</span>;
    <span class="kw">Fsi</span>

    <span class="cm">// 3. Rotation anneau par anneau</span>
    <span class="kw">Pour</span> k := <span class="num">0</span> <span class="kw">a</span> nb_anneaux - <span class="num">1</span> <span class="kw">Faire</span>
        perimetre := <span class="num">2</span> * (M - <span class="num">2</span> * k) + <span class="num">2</span> * (N - <span class="num">2</span> * k) - <span class="num">4</span>;
        r_eff := R <span class="kw">mod</span> perimetre;

        <span class="kw">Pour</span> step := <span class="num">1</span> <span class="kw">a</span> r_eff <span class="kw">Faire</span>
            temp := mat[k][k];

            <span class="cm">// Bord superieur (gauche)</span>
            <span class="kw">Pour</span> j := k <span class="kw">a</span> N - <span class="num">2</span> - k <span class="kw">Faire</span>
                mat[k][j] := mat[k][j + <span class="num">1</span>];
            <span class="kw">FinPour</span>

            <span class="cm">// Bord droit (haut)</span>
            <span class="kw">Pour</span> i := k <span class="kw">a</span> M - <span class="num">2</span> - k <span class="kw">Faire</span>
                mat[i][N - <span class="num">1</span> - k] := mat[i + <span class="num">1</span>][N - <span class="num">1</span> - k];
            <span class="kw">FinPour</span>

            <span class="cm">// Bord inferieur (droite)</span>
            j := N - <span class="num">1</span> - k;
            <span class="kw">Tant Que</span> j &gt; k <span class="kw">Faire</span>
                mat[M - <span class="num">1</span> - k][j] := mat[M - <span class="num">1</span> - k][j - <span class="num">1</span>];
                j := j - <span class="num">1</span>;
            <span class="kw">FinTantQue</span>

            <span class="cm">// Bord gauche (bas)</span>
            i := M - <span class="num">1</span> - k;
            <span class="kw">Tant Que</span> i &gt; k + <span class="num">1</span> <span class="kw">Faire</span>
                mat[i][k] := mat[i - <span class="num">1</span>][k];
                i := i - <span class="num">1</span>;
            <span class="kw">FinTantQue</span>

            mat[k + <span class="num">1</span>][k] := temp;
        <span class="kw">FinPour</span>
    <span class="kw">FinPour</span>
<span class="kw">Fin</span>.</pre>
                </div>

                <div class="terminal-block">
                    <div class="terminal-tag">
                        <span>AlgoCompiler CLI Execution Log</span>
                        <span style="color:#10b981;">✔ Code 0 • Execution Success</span>
                    </div>=== MATRICE ORIGINALE (4x4) ===
[ 1   2   3   4   ]
[ 5   6   7   8   ]
[ 9   10  11  12  ]
[ 13  14  15  16  ]

Nombre d'anneaux concentriques :  2 
Nombre de rotations demandees (R) :  2 

Anneau  0  : perimetre =  12 , rotations effectives =  2 
Anneau  1  : perimetre =  4 , rotations effectives =  2 

=== MATRICE APRES  2  ROTATIONS ANTI-HORAIRE ===
[ 3   4   8   12  ]
[ 2   11  10  16  ]
[ 1   7   6   15  ]
[ 5   9   13  14  ]

Verification terminee avec succes !</div>
            </div>

        </section>

        <!-- ============================================================== -->
        <!-- EXERCICE 2 : ADN ÉQUILIBRÉ (STEADY BEAR)                       -->
        <!-- ============================================================== -->
        <section id="tab-pane-1" class="tab-content">
            
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.6rem;">🧬</span>
                        <div>
                            <h2>Exercice 2 : ADN Équilibré de l'Ours (Steady Bear DNA)</h2>
                            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 2px;">
                                Fenêtre glissante optimale (Two Pointers) et bio-informatique
                            </div>
                        </div>
                    </div>
                    <span class="pill-badge pill-emerald">Fenêtre Glissante (Two Pointers)</span>
                </div>

                <p>
                    <strong>Énoncé Mathématique :</strong> Soit un brin d'ADN représenté par une chaîne de caractères de taille $N$, 
                    où $N$ est un multiple de 4, composé des quatre nucléotides $X \in \{\text{'A'}, \text{'C'}, \text{'G'}, \text{'T'}\}$.
                    Le brin est qualifié d'<strong>équilibré</strong> si chaque nucléotide apparaît exactement $\frac{N}{4}$ fois.
                    On cherche la <strong>longueur minimale</strong> d'une sous-chaîne contiguë qu'il suffit de remplacer par une séquence quelconque 
                    pour rendre le brin parfaitement équilibré.
                </p>

                <div class="banner-math">
                    <strong>Condition Nécessaire et Suffisante de la Fenêtre Glissante :</strong><br>
                    Si l'on modifie la sous-chaîne délimitée par les indices $[L, R]$, les caractères situés <em>à l'extérieur</em> de la fenêtre demeurent figés.
                    Une fenêtre $[L, R]$ est valide si et seulement si :
                    $$\text{Fréquence}_{\text{extérieur}}(X) \le \frac{N}{4} \quad \forall X \in \{\text{'A'}, \text{'C'}, \text{'G'}, \text{'T'}\}$$
                    L'intérieur de la fenêtre fournira alors exactement le nombre requis de nucléotides manquants.
                    L'algorithme à deux pointeurs résout ce problème en complexité optimale $\mathcal{O}(N)$.
                </div>
            </div>

            <!-- SIMULATION INTERACTIVE RÉALISTE : BRIN GÉNOMIQUE & JAUGES EN TEMPS RÉEL -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.4rem;">🕹️</span>
                        <h3>Simulation Réelle : Visualiseur de Fenêtre Glissante $[L, R]$</h3>
                    </div>
                    <span class="pill-badge pill-amber">Bio-Informatique</span>
                </div>

                <div class="controls-panel">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Séquence :</label>
                        <select id="dna-preset-select" class="select-modern" onchange="loadDnaPreset()">
                            <option value="GAAATAAA">GAAATAAA (N=8, Cible=2) [Cas d'école]</option>
                            <option value="AAGT">AAGT (N=4, Cible=1)</option>
                            <option value="ACGT">ACGT (N=4, Déjà équilibré)</option>
                            <option value="TGATGCCGTCCCCTCA">TGATGCCGTCCCCTCA (N=16, Cible=4)</option>
                            <option value="CGCGAAATTTTTGGAA">CGCGAAATTTTTGGAA (N=16, Cible=4)</option>
                        </select>
                    </div>

                    <button class="btn-modern" onclick="stepDnaAlgorithm()">
                        <span>▶</span> Pas Suivant (Two-Pointers)
                    </button>
                    <button class="btn-ghost" onclick="toggleAutoDna()">
                        <span id="dna-play-icon">⏵</span> <span id="dna-play-label">Lecture Auto</span>
                    </button>
                    <button class="btn-ghost" onclick="solveDnaInstantly()">
                        <span>⚡</span> Trouver le Minimum Direct
                    </button>
                    <button class="btn-ghost" onclick="resetDnaState()">
                        <span>↺</span> Réinitialiser
                    </button>

                    <div style="display:flex; align-items:center; gap:8px; margin-left:auto;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Saisie ADN :</label>
                        <input type="text" id="dna-custom-input" placeholder="Ex: ACGTGCAATGCA..." class="input-modern" style="width:200px; text-transform:uppercase;" oninput="onCustomDnaInput()">
                        <span id="dna-custom-msg" style="font-size:0.75rem;"></span>
                    </div>
                </div>

                <div class="dna-workspace">
                    <!-- Brin avec fenêtrage interactif -->
                    <div class="dna-strand-card">
                        <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px; display: flex; justify-content: space-between;">
                            <span>BRIN GÉNOMIQUE ACTIF :</span>
                            <span style="color:#c084fc; font-weight:700;">Zone Violette = Fenêtre Remplaçable $[L, R]$</span>
                        </div>
                        <div id="dna-track-elem" class="dna-track">
                            <!-- Généré dynamiquement -->
                        </div>
                    </div>

                    <!-- 4 Jauges en temps réel de fréquence HORS fenêtre -->
                    <div class="dna-gauges-grid">
                        <div class="gauge-card" id="gauge-A">
                            <div class="gauge-header">
                                <span class="gauge-base-name" style="color: #34d399;">
                                    <span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#10b981;"></span>
                                    Adénine (A)
                                </span>
                                <span id="gauge-count-A" style="font-family: var(--font-mono); font-weight:700;">0</span>
                            </div>
                            <div class="gauge-bar-bg"><div class="gauge-bar-fill" id="bar-A" style="width:0%; background:#10b981;"></div></div>
                            <div class="gauge-status"><span id="gauge-target-A">Cible : 2</span><span id="gauge-badge-A">✔ OK</span></div>
                        </div>

                        <div class="gauge-card" id="gauge-C">
                            <div class="gauge-header">
                                <span class="gauge-base-name" style="color: #38bdf8;">
                                    <span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#06b6d4;"></span>
                                    Cytosine (C)
                                </span>
                                <span id="gauge-count-C" style="font-family: var(--font-mono); font-weight:700;">0</span>
                            </div>
                            <div class="gauge-bar-bg"><div class="gauge-bar-fill" id="bar-C" style="width:0%; background:#06b6d4;"></div></div>
                            <div class="gauge-status"><span id="gauge-target-C">Cible : 2</span><span id="gauge-badge-C">✔ OK</span></div>
                        </div>

                        <div class="gauge-card" id="gauge-G">
                            <div class="gauge-header">
                                <span class="gauge-base-name" style="color: #fbbf24;">
                                    <span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#f59e0b;"></span>
                                    Guanine (G)
                                </span>
                                <span id="gauge-count-G" style="font-family: var(--font-mono); font-weight:700;">0</span>
                            </div>
                            <div class="gauge-bar-bg"><div class="gauge-bar-fill" id="bar-G" style="width:0%; background:#f59e0b;"></div></div>
                            <div class="gauge-status"><span id="gauge-target-G">Cible : 2</span><span id="gauge-badge-G">✔ OK</span></div>
                        </div>

                        <div class="gauge-card" id="gauge-T">
                            <div class="gauge-header">
                                <span class="gauge-base-name" style="color: #fb7185;">
                                    <span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#f43f5e;"></span>
                                    Thymine (T)
                                </span>
                                <span id="gauge-count-T" style="font-family: var(--font-mono); font-weight:700;">0</span>
                            </div>
                            <div class="gauge-bar-bg"><div class="gauge-bar-fill" id="bar-T" style="width:0%; background:#f43f5e;"></div></div>
                            <div class="gauge-status"><span id="gauge-target-T">Cible : 2</span><span id="gauge-badge-T">✔ OK</span></div>
                        </div>
                    </div>

                    <!-- Synthèse du résultat optimal -->
                    <div id="dna-verdict-box" style="padding: 16px 20px; border-radius: var(--radius-md); background: #060911; border: 1px solid #1e293b;">
                        <!-- Rempli en JS -->
                    </div>
                </div>
            </div>


            <!-- DÉCOMPOSITION EN PSEUDO-CODE -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">📋</span>
                        <h3>Décomposition Algorithmique par Parties</h3>
                    </div>
                    <span class="pill-badge pill-purple">Conception Modulaire</span>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 1 : Dénombrement Initial des Fréquences & Seuil Cible</div>
                    <p>On parcourt le brin une première fois pour recenser les occurrences de chaque base et calculer la cible $\frac{N}{4}$ :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 1</span>
                        </div>
<pre><span class="cm">// Calcul du quota d'équilibre</span>
cible &larr; Longueur(adn) <span class="kw">div</span> <span class="num">4</span>;
cA &larr; <span class="num">0</span>; cC &larr; <span class="num">0</span>; cG &larr; <span class="num">0</span>; cT &larr; <span class="num">0</span>;

<span class="kw">Pour</span> i &larr; <span class="num">0</span> <span class="kw">a</span> Longueur(adn) - <span class="num">1</span> <span class="kw">Faire</span>
    <span class="kw">Si</span> adn[i] = <span class="st">'A'</span> <span class="kw">Alors</span> cA &larr; cA + <span class="num">1</span> <span class="kw">Fsi</span>;
    <span class="kw">Si</span> adn[i] = <span class="st">'C'</span> <span class="kw">Alors</span> cC &larr; cC + <span class="num">1</span> <span class="kw">Fsi</span>;
    <span class="kw">Si</span> adn[i] = <span class="st">'G'</span> <span class="kw">Alors</span> cG &larr; cG + <span class="num">1</span> <span class="kw">Fsi</span>;
    <span class="kw">Si</span> adn[i] = <span class="st">'T'</span> <span class="kw">Alors</span> cT &larr; cT + <span class="num">1</span> <span class="kw">Fsi</span>;
<span class="kw">FinPour</span>;

<span class="cm">// Si toutes les bases sont <= cible : déjà équilibré (longueur = 0)</span></pre>
                    </div>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 2 : Balayage par Fenêtre Glissante (Two Pointers) en $\mathcal{O}(N)$</div>
                    <p>On fait progresser le pointeur <code>right</code> pour englober des nucléotides excédentaires dans la fenêtre, puis on contracte <code>left</code> tant que l'extérieur reste valide :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 2</span>
                        </div>
<pre>min_longueur &larr; n;
left &larr; <span class="num">0</span>;

<span class="kw">Pour</span> right &larr; <span class="num">0</span> <span class="kw">a</span> n - <span class="num">1</span> <span class="kw">Faire</span>
    <span class="cm">// Retrait du caractère adn[right] des comptes extérieurs</span>
    DécrémenterCompteur(adn[right]);

    <span class="cm">// Rétractation de la fenêtre par la gauche tant que l'extérieur respecte la contrainte</span>
    <span class="kw">Tant Que</span> (cA &le; cible <span class="kw">Et</span> cC &le; cible <span class="kw">Et</span> cG &le; cible <span class="kw">Et</span> cT &le; cible) <span class="kw">Et</span> (left &le; right) <span class="kw">Faire</span>
        fenetre_len &larr; right - left + <span class="num">1</span>;
        <span class="kw">Si</span> fenetre_len &lt; min_longueur <span class="kw">Alors</span>
            min_longueur &larr; fenetre_len;
        <span class="kw">Fsi</span>;
        <span class="cm">// Réintégration du caractère adn[left] hors fenêtre</span>
        IncrémenterCompteur(adn[left]);
        left &larr; left + <span class="num">1</span>;
    <span class="kw">FinTantQue</span>;
<span class="kw">FinPour</span>;</pre>
                    </div>
                </div>
            </div>

            <!-- CODE OFFICIEL VALIDE ALGOCOMPILER -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">💻</span>
                        <h3>Code Source Certifié AlgoCompiler</h3>
                    </div>
                    <button class="btn-copy" onclick="copySourceCode('code-ex2')">Copier le Code .algo</button>
                </div>
                <div class="code-block-modern">
                    <div class="code-block-header">
                        <span class="code-file-label">Exos/02_adn_equilibre_steady_bear.algo</span>
                        <span class="pill-badge pill-emerald">Exit Code 0</span>
                    </div>
<pre id="code-ex2"><span class="kw">Algorithme</span> GeneEquilibreSteadyBear;
<span class="kw">Var</span>
    adn[<span class="num">100</span>] : <span class="ty">Chaine</span>;
    n, cible : <span class="ty">Entier</span>;
    cA, cC, cG, cT : <span class="ty">Entier</span>;
    i, left, right : <span class="ty">Entier</span>;
    min_longueur, fenetre_len : <span class="ty">Entier</span>;
    meilleur_left, meilleur_right : <span class="ty">Entier</span>;
    c : <span class="ty">Caractere</span>;
    valide : <span class="ty">Booleen</span>;

<span class="kw">Debut</span>
    adn := <span class="st">"GAAATAAA"</span>;
    n := <span class="fn">Longueur</span>(adn);
    cible := n / <span class="num">4</span>;

    <span class="cm">// 1. Comptage des frequences initiales</span>
    cA := <span class="num">0</span>; cC := <span class="num">0</span>; cG := <span class="num">0</span>; cT := <span class="num">0</span>;
    <span class="kw">Pour</span> i := <span class="num">0</span> <span class="kw">a</span> n - <span class="num">1</span> <span class="kw">Faire</span>
        c := adn[i];
        <span class="kw">Si</span> c = <span class="st">'A'</span> <span class="kw">Alors</span> cA := cA + <span class="num">1</span>; <span class="kw">Fsi</span>
        <span class="kw">Si</span> c = <span class="st">'C'</span> <span class="kw">Alors</span> cC := cC + <span class="num">1</span>; <span class="kw">Fsi</span>
        <span class="kw">Si</span> c = <span class="st">'G'</span> <span class="kw">Alors</span> cG := cG + <span class="num">1</span>; <span class="kw">Fsi</span>
        <span class="kw">Si</span> c = <span class="st">'T'</span> <span class="kw">Alors</span> cT := cT + <span class="num">1</span>; <span class="kw">Fsi</span>
    <span class="kw">FinPour</span>

    <span class="cm">// 2. Fenetre Glissante</span>
    min_longueur := n;
    meilleur_left := <span class="num">0</span>;
    meilleur_right := n - <span class="num">1</span>;
    left := <span class="num">0</span>;

    <span class="kw">Pour</span> right := <span class="num">0</span> <span class="kw">a</span> n - <span class="num">1</span> <span class="kw">Faire</span>
        c := adn[right];
        <span class="kw">Si</span> c = <span class="st">'A'</span> <span class="kw">Alors</span> cA := cA - <span class="num">1</span>; <span class="kw">Fsi</span>
        <span class="kw">Si</span> c = <span class="st">'C'</span> <span class="kw">Alors</span> cC := cC - <span class="num">1</span>; <span class="kw">Fsi</span>
        <span class="kw">Si</span> c = <span class="st">'G'</span> <span class="kw">Alors</span> cG := cG - <span class="num">1</span>; <span class="kw">Fsi</span>
        <span class="kw">Si</span> c = <span class="st">'T'</span> <span class="kw">Alors</span> cT := cT - <span class="num">1</span>; <span class="kw">Fsi</span>

        valide := (cA &lt;= cible) <span class="kw">Et</span> (cC &lt;= cible) <span class="kw">Et</span> (cG &lt;= cible) <span class="kw">Et</span> (cT &lt;= cible);

        <span class="kw">Tant Que</span> valide <span class="kw">Et</span> (left &lt;= right) <span class="kw">Faire</span>
            fenetre_len := right - left + <span class="num">1</span>;
            <span class="kw">Si</span> fenetre_len &lt; min_longueur <span class="kw">Alors</span>
                min_longueur := fenetre_len;
                meilleur_left := left;
                meilleur_right := right;
            <span class="kw">Fsi</span>

            c := adn[left];
            <span class="kw">Si</span> c = <span class="st">'A'</span> <span class="kw">Alors</span> cA := cA + <span class="num">1</span>; <span class="kw">Fsi</span>
            <span class="kw">Si</span> c = <span class="st">'C'</span> <span class="kw">Alors</span> cC := cC + <span class="num">1</span>; <span class="kw">Fsi</span>
            <span class="kw">Si</span> c = <span class="st">'G'</span> <span class="kw">Alors</span> cG := cG + <span class="num">1</span>; <span class="kw">Fsi</span>
            <span class="kw">Si</span> c = <span class="st">'T'</span> <span class="kw">Alors</span> cT := cT + <span class="num">1</span>; <span class="kw">Fsi</span>
            left := left + <span class="num">1</span>;

            valide := (cA &lt;= cible) <span class="kw">Et</span> (cC &lt;= cible) <span class="kw">Et</span> (cG &lt;= cible) <span class="kw">Et</span> (cT &lt;= cible);
        <span class="kw">FinTantQue</span>
    <span class="kw">FinPour</span>

    <span class="fn">Ecrire</span>(<span class="st">"Longueur minimale a remplacer : "</span>, min_longueur, <span class="st">"\n"</span>);
<span class="kw">Fin</span>.</pre>
                </div>

                <div class="terminal-block">
                    <div class="terminal-tag">
                        <span>AlgoCompiler CLI Execution Log</span>
                        <span style="color:#10b981;">✔ Code 0 • Execution Success</span>
                    </div>=== EXERCICE 2 : ADN EQUILIBRE (BEAR AND STEADY GENE) ===

Sequence ADN originale :  GAAATAAA 
Longueur de la sequence (N) :  8 
Frequence cible par base (N/4) :  2 

Frequences observees :
  A :  6  (cible:  2 )
  C :  0  (cible:  2 )
  G :  1  (cible:  2 )
  T :  1  (cible:  2 )

Le brin n'est pas equilibre. Recherche de la sous-chaine minimale...

Resultat Optimal :
  Longueur minimale a remplacer :  5 
  Position de la sous-chaine : indices  1  a  5 
  Sous-chaine a remplacer : ' A A A T A '

Programme execute avec succes !</div>
            </div>

        </section>

        <!-- ============================================================== -->
        <!-- EXERCICE 3 : FILTRE MÉDIAN POUR IMAGE                          -->
        <!-- ============================================================== -->
        <section id="tab-pane-2" class="tab-content">
            
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.6rem;">🖼️</span>
                        <div>
                            <h2>Exercice 3 : Filtre Médian & Traitement d'Image (Salt & Pepper Noise)</h2>
                            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 2px;">
                                Débruitage non-linéaire sur Canvas réel, extraction de voisinage 3×3 et tri à bulles
                            </div>
                        </div>
                    </div>
                    <span class="pill-badge pill-purple">Traitement d'Image 2D & Tri</span>
                </div>

                <p>
                    <strong>Fondement Mathématique :</strong> Le bruit impulsionnel "poivre et sel" corrompt aléatoirement les pixels 
                    d'une image en fixant leur intensité aux extrêmes absolus : soit $0$ (noir total / poivre), soit $255$ (blanc total / sel).
                    Contrairement au filtre moyenneur qui propage cette aberration sur les pixels voisins et floute les arêtes, 
                    le <strong>filtre médian</strong> est une statistique d'ordre robuste :
                </p>

                <div class="banner-math">
                    <strong>Pourquoi la Médiane Rejette-t-elle l'Impulsion ?</strong><br>
                    Soit $V(i, j) = \{I(i+u, j+v) \mid -1 \le u, v \le 1\}$ les 9 pixels d'un voisinage $3 \times 3$. 
                    Après tri croissant $s_0 \le s_1 \le \dots \le s_8$, la nouvelle valeur du pixel central est :
                    $$I_{\text{filtrée}}(i, j) = s_4$$
                    Un parasite sel ($255$) se retrouve relégué à la fin du tableau trié ($s_8$). 
                    Un parasite poivre ($0$) se retrouve relégué au début ($s_0$). 
                    La valeur médiane $s_4$ reflète fidèlement la couleur majoritaire locale sans altérer la netteté des contours !
                </div>
            </div>

            <!-- SIMULATION INTERACTIVE RÉALISTE : CANVAS REEL + SCANLINE + INSPECTEUR -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.4rem;">🕹️</span>
                        <h3>Simulation Réelle : Traitement d'Image sur Canvas Haute Précision</h3>
                    </div>
                    <span class="pill-badge pill-amber">Canvas Processing 2D</span>
                </div>

                <p style="margin-bottom: 16px;">
                    Cette simulation exécute le véritable algorithme de filtrage médian sur une scène géométrique synthétique ($64 \times 64$ pixels).
                    <strong>Cliquez sur n'importe quel pixel de l'image bruitée</strong> pour afficher sa loupe $3 \times 3$ et assister au tri de ses 9 voisins !
                </p>

                <div class="controls-panel">
                    <button class="btn-modern" id="median-scan-btn" onclick="animateMedianScan()">
                        <span id="median-scan-btn-icon">▶</span> <span id="median-scan-btn-label">Lancer le Balayage Animé</span>
                    </button>
                    <button class="btn-ghost" onclick="applyInstantMedianFilter()">
                        <span>✨</span> Filtrage Instantané
                    </button>
                    <button class="btn-ghost" onclick="regenerateNoise()">
                        <span>🎲</span> Nouveau Bruit Poivre & Sel
                    </button>
                    
                    <div style="display:flex; align-items:center; gap:8px; margin-left:auto;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Densité de Bruit :</label>
                        <select id="noise-density-select" class="select-modern" onchange="regenerateNoise()">
                            <option value="0.05">Faible (5%)</option>
                            <option value="0.12" selected>Moyenne (12%)</option>
                            <option value="0.25">Forte (25%)</option>
                        </select>
                    </div>

                    <div style="display:flex; align-items:center; gap:8px;">
                        <button class="btn-ghost" onclick="inspectPresetPixel('salt')">🔍 Sel [16,16]</button>
                        <button class="btn-ghost" onclick="inspectPresetPixel('pepper')">🔍 Poivre [32,32]</button>
                    </div>
                </div>

                <!-- Triple Canvas : Propre, Bruité, Filtré -->
                <div class="median-canvas-layout">
                    <div class="canvas-card">
                        <div class="canvas-title">
                            <span style="color:#38bdf8;">●</span> 1. Scène Originale Nette
                        </div>
                        <div class="canvas-frame">
                            <canvas id="cv-original" class="pixel-canvas" width="64" height="64" style="width:220px; height:220px;"></canvas>
                        </div>
                        <div style="font-size:0.75rem; color:var(--text-muted); margin-top:8px;">Scène synthétique avec contrastes et dégradés</div>
                    </div>

                    <div class="canvas-card" style="border-color: rgba(244, 63, 94, 0.4);">
                        <div class="canvas-title" style="color:#fb7185;">
                            <span>●</span> 2. Image Corrompue (Poivre & Sel)
                        </div>
                        <div class="canvas-frame" style="border-color: #f43f5e;">
                            <canvas id="cv-noisy" class="pixel-canvas" width="64" height="64" style="width:220px; height:220px;"></canvas>
                            <div id="scan-box" class="scan-overlay-box"></div>
                        </div>
                        <div style="font-size:0.75rem; color:#fb7185; margin-top:8px;">Cliquez pour inspecter un pixel localement !</div>
                    </div>

                    <div class="canvas-card" style="border-color: rgba(16, 185, 129, 0.4);">
                        <div class="canvas-title" style="color:#34d399;">
                            <span>●</span> 3. Image Restaurée (Filtre Médian)
                        </div>
                        <div class="canvas-frame" style="border-color: #10b981;">
                            <canvas id="cv-filtered" class="pixel-canvas" width="64" height="64" style="width:220px; height:220px;"></canvas>
                            <div id="scan-box-filtered" class="scan-overlay-box" style="border-color:#10b981;"></div>
                        </div>
                        <div style="font-size:0.75rem; color:#34d399; margin-top:8px;" id="denoise-stats-text">
                            Bruits 0 et 255 éliminés avec succès !
                        </div>
                    </div>
                </div>

                <!-- Inspecteur de Voisinage & Pipeline de Tri -->
                <div class="median-inspector-card">
                    <div style="font-size:0.95rem; font-weight:700; color:#38bdf8; margin-bottom:14px; display:flex; align-items:center; gap:8px;">
                        <span>🔬</span> Loupe d'Analyse Locale : Fenêtre $3 \times 3$ au pixel (<span id="inspect-coords">16, 16</span>)
                    </div>

                    <div class="inspector-flex">
                        <div>
                            <div style="font-size:0.75rem; color:var(--text-muted); margin-bottom:6px; text-align:center;">Voisinage 3×3 Brut</div>
                            <div id="kernel-3x3-view" class="kernel-matrix-3x3">
                                <!-- 9 cellules -->
                            </div>
                        </div>

                        <div style="font-size: 1.5rem; color: var(--text-dim);">➜</div>

                        <div class="sorting-pipeline">
                            <div style="font-size:0.8rem; color:var(--text-muted); display:flex; justify-content:space-between;">
                                <span>Tableau des 9 Voisins Triés par Tri à Bulles :</span>
                                <span style="color:#34d399; font-weight:700;">Médiane = Indice 4</span>
                            </div>
                            <div id="sorted-cells-view" class="sorted-array-strip">
                                <!-- 9 cellules triees -->
                            </div>
                            <div id="inspector-analysis-text" style="font-size:0.85rem; color:#cbd5e1; background:#0b1120; padding:10px 14px; border-radius:6px; border:1px solid #1e293b;">
                                <!-- Explication dynamique -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- DÉCOMPOSITION EN PSEUDO-CODE -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">📋</span>
                        <h3>Décomposition Algorithmique par Parties</h3>
                    </div>
                    <span class="pill-badge pill-purple">Conception Modulaire</span>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 1 : Extraction du Voisinage $3 \times 3$ dans un Vecteur 1D</div>
                    <p>Pour chaque pixel interne $(i, j)$, on récolte ses 8 voisins directs et lui-même dans un tableau <code>voisins[9]</code> :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 1</span>
                        </div>
<pre>idx &larr; <span class="num">0</span>;
<span class="kw">Pour</span> di &larr; -<span class="num">1</span> <span class="kw">a</span> <span class="num">1</span> <span class="kw">Faire</span>
    <span class="kw">Pour</span> dj &larr; -<span class="num">1</span> <span class="kw">a</span> <span class="num">1</span> <span class="kw">Faire</span>
        voisins[idx] &larr; image[i + di][j + dj];
        idx &larr; idx + <span class="num">1</span>;
    <span class="kw">FinPour</span>;
<span class="kw">FinPour</span>;</pre>
                    </div>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 2 : Tri à Bulles des 9 Voisins & Extraction de la Médiane</div>
                    <p>On applique le tri à bulles sur les 9 éléments du voisinage. La médiane est directement l'élément d'indice 4 :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 2</span>
                        </div>
<pre><span class="cm">// Tri à Bulles classique sur 9 éléments</span>
<span class="kw">Pour</span> p &larr; <span class="num">0</span> <span class="kw">a</span> <span class="num">7</span> <span class="kw">Faire</span>
    <span class="kw">Pour</span> q &larr; <span class="num">0</span> <span class="kw">a</span> <span class="num">7</span> - p <span class="kw">Faire</span>
        <span class="kw">Si</span> voisins[q] &gt; voisins[q + <span class="num">1</span>] <span class="kw">Alors</span>
            temp &larr; voisins[q];
            voisins[q] &larr; voisins[q + <span class="num">1</span>];
            voisins[q + <span class="num">1</span>] &larr; temp;
        <span class="kw">Fsi</span>;
    <span class="kw">FinPour</span>;
<span class="kw">FinPour</span>;

<span class="cm">// La médiane se situe exactement au centre (5ème élément, indice 4)</span>
filtree[i][j] &larr; voisins[<span class="num">4</span>];</pre>
                    </div>
                </div>
            </div>

            <!-- CODE OFFICIEL VALIDE ALGOCOMPILER -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">💻</span>
                        <h3>Code Source Certifié AlgoCompiler</h3>
                    </div>
                    <button class="btn-copy" onclick="copySourceCode('code-ex3')">Copier le Code .algo</button>
                </div>
                <div class="code-block-modern">
                    <div class="code-block-header">
                        <span class="code-file-label">Exos/03_filtre_median_debruitage.algo</span>
                        <span class="pill-badge pill-emerald">Exit Code 0</span>
                    </div>
<pre id="code-ex3"><span class="kw">Algorithme</span> FiltreMedianImage;
<span class="kw">Var</span>
    image[<span class="num">5</span>][<span class="num">5</span>]   : <span class="ty">Entier</span>;
    filtree[<span class="num">5</span>][<span class="num">5</span>] : <span class="ty">Entier</span>;
    voisins[<span class="num">9</span>]    : <span class="ty">Entier</span>;
    M, N : <span class="ty">Entier</span>;
    i, j, di, dj, idx : <span class="ty">Entier</span>;
    p, q, temp : <span class="ty">Entier</span>;
    mediane : <span class="ty">Entier</span>;

<span class="kw">Debut</span>
    M := <span class="num">5</span>;
    N := <span class="num">5</span>;

    <span class="cm">// 1. Initialisation de l'image 5x5 avec motif et bruits</span>
    <span class="kw">Pour</span> i := <span class="num">0</span> <span class="kw">a</span> M - <span class="num">1</span> <span class="kw">Faire</span>
        <span class="kw">Pour</span> j := <span class="num">0</span> <span class="kw">a</span> N - <span class="num">1</span> <span class="kw">Faire</span>
            <span class="kw">Si</span> i &lt; <span class="num">2</span> <span class="kw">Alors</span> image[i][j] := <span class="num">80</span>; <span class="kw">Sinon</span> image[i][j] := <span class="num">180</span>; <span class="kw">Fsi</span>
            filtree[i][j] := image[i][j];
        <span class="kw">FinPour</span>
    <span class="kw">FinPour</span>

    <span class="cm">// Injection du bruit poivre et sel</span>
    image[<span class="num">1</span>][<span class="num">1</span>] := <span class="num">255</span>; <span class="cm">// Sel (point blanc isole)</span>
    image[<span class="num">3</span>][<span class="num">3</span>] := <span class="num">0</span>;   <span class="cm">// Poivre (point noir isole)</span>

    <span class="cm">// 2. Application du Filtre Median sur les pixels internes</span>
    <span class="kw">Pour</span> i := <span class="num">1</span> <span class="kw">a</span> M - <span class="num">2</span> <span class="kw">Faire</span>
        <span class="kw">Pour</span> j := <span class="num">1</span> <span class="kw">a</span> N - <span class="num">2</span> <span class="kw">Faire</span>
            <span class="cm">// A. Extraction des 9 voisins</span>
            idx := <span class="num">0</span>;
            <span class="kw">Pour</span> di := -<span class="num">1</span> <span class="kw">a</span> <span class="num">1</span> <span class="kw">Faire</span>
                <span class="kw">Pour</span> dj := -<span class="num">1</span> <span class="kw">a</span> <span class="num">1</span> <span class="kw">Faire</span>
                    voisins[idx] := image[i + di][j + dj];
                    idx := idx + <span class="num">1</span>;
                <span class="kw">FinPour</span>
            <span class="kw">FinPour</span>

            <span class="cm">// B. Tri a Bulles sur le vecteur voisins[9]</span>
            <span class="kw">Pour</span> p := <span class="num">0</span> <span class="kw">a</span> <span class="num">7</span> <span class="kw">Faire</span>
                <span class="kw">Pour</span> q := <span class="num">0</span> <span class="kw">a</span> <span class="num">7</span> - p <span class="kw">Faire</span>
                    <span class="kw">Si</span> voisins[q] &gt; voisins[q + <span class="num">1</span>] <span class="kw">Alors</span>
                        temp := voisins[q];
                        voisins[q] := voisins[q + <span class="num">1</span>];
                        voisins[q + <span class="num">1</span>] := temp;
                    <span class="kw">Fsi</span>
                <span class="kw">FinPour</span>
            <span class="kw">FinPour</span>

            <span class="cm">// C. Affectation de la mediane</span>
            mediane := voisins[<span class="num">4</span>];
            filtree[i][j] := mediane;
        <span class="kw">FinPour</span>
    <span class="kw">FinPour</span>
<span class="kw">Fin</span>.</pre>
                </div>

                <div class="terminal-block">
                    <div class="terminal-tag">
                        <span>AlgoCompiler CLI Execution Log</span>
                        <span style="color:#10b981;">✔ Code 0 • Execution Success</span>
                    </div>=== EXERCICE 3 : FILTRE MEDIAN POUR DEBRUITAGE D'IMAGE ===

Image bruitee d'entree (5x5) :
(Noter le bruit Sel=255 en [1,1] et Poivre=0 en [3,3])
[ 80   80   80   80   80   ]
[ 80   255  80   80   80   ]
[ 180  180  180  180  180  ]
[ 180  180  180  0    180  ]
[ 180  180  180  180  180  ]

Traitement du pixel bruite [1,1] (valeur initiale =  255 ) :
  Fenetre 3x3 triee : 80  80  80  80  80  180  180  180  255  
  Mediane calculee (indice 4) =  80  -> Bruit Sel elimine !

Traitement du pixel bruite [3,3] (valeur initiale =  0 ) :
  Fenetre 3x3 triee : 0  180  180  180  180  180  180  180  180  
  Mediane calculee (indice 4) =  180  -> Bruit Poivre elimine !

=== IMAGE FILTREE RESULTANTE (Debruitee) ===
[ 80   80   80   80   80   ]
[ 80   80   80   80   80   ]
[ 180  180  180  180  180  ]
[ 180  180  180  180  180  ]
[ 180  180  180  180  180  ]

Le filtre median a parfaitement elimine les bruits sans alterer la frontiere nette !</div>
            </div>

        </section>

        <!-- ============================================================== -->
        <!-- EXERCICE 4 : TRIPLETS MAGNIFIQUES                             -->
        <!-- ============================================================== -->
        <section id="tab-pane-3" class="tab-content">
            
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.6rem;">🔢</span>
                        <div>
                            <h2>Exercice 4 : Triplets Magnifiques (Beautiful Triplets)</h2>
                            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 2px;">
                                Progression arithmétique, recherche dichotomique binaire et visualisation par arcs SVG
                            </div>
                        </div>
                    </div>
                    <span class="pill-badge pill-cyan">Recherche Dichotomique $\mathcal{O}(N \log N)$</span>
                </div>

                <p>
                    <strong>Énoncé Mathématique :</strong> Soit un tableau $A$ de $N$ entiers strictement ordonnés dans l'ordre croissant ($A[0] \le A[1] \le \dots \le A[N-1]$), 
                    et soit un entier strictement positif $d > 0$. Un triplet d'indices $(i, j, k)$ est dit <strong>magnifique</strong> si :
                    $$i < j < k \quad \text{et} \quad A[j] - A[i] = d \quad \text{et} \quad A[k] - A[j] = d$$
                    Les valeurs associées forment une progression arithmétique de raison $d$ : $(A[i], A[i] + d, A[i] + 2d)$.
                </p>

                <div class="banner-math">
                    <strong>Avantage de la Recherche Dichotomique vs Algorithme Naïf :</strong><br>
                    Une recherche naïve à 3 boucles imbriquées mènerait à une complexité cubique catastrophique $\mathcal{O}(N^3)$.
                    Grâce au tri préalable du tableau, pour chaque élément $A[i]$, on localise la cible $A[i] + d$ par dichotomie en $\mathcal{O}(\log N)$.
                    Si cette cible existe à l'indice $j$, on recherche la seconde cible $A[j] + d$ par une nouvelle dichotomie en $\mathcal{O}(\log N)$.
                    La complexité globale chute ainsi à :
                    $$\mathcal{O}(N \log N)$$
                </div>
            </div>

            <!-- SIMULATION INTERACTIVE RÉALISTE : VECTEUR + ARCS SVG COURBES + POINTEURS BINARY SEARCH -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.4rem;">🕹️</span>
                        <h3>Simulation Réelle : Arcs de Liaison & Recherche Dichotomique</h3>
                    </div>
                    <span class="pill-badge pill-amber">Graphique SVG Interactif</span>
                </div>

                <p style="margin-bottom: 16px;">
                    Observez le déroulement de la recherche binaire pour chaque élément $A[i]$. 
                    Dès qu'un triplet valide est identifié, deux arcs de progression courbés s'illuminent au-dessus du tableau.
                </p>

                <div class="controls-panel">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Raison $d$ :</label>
                        <input type="number" id="triplet-d-input" value="3" min="1" max="10" class="input-modern" style="width:60px;" onchange="updateTripletsDifference()">
                    </div>

                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Presets :</label>
                        <select id="triplet-preset-select" class="select-modern" onchange="loadTripletPreset()">
                            <option value="standard">[1, 2, 4, 5, 7, 8, 10, 12, 13, 16] (d=3)</option>
                            <option value="arithmetic">[1, 3, 5, 7, 9, 11, 13, 15] (d=2)</option>
                            <option value="multiple">[2, 5, 8, 11, 14, 17, 20] (d=3)</option>
                            <option value="sparse">[1, 6, 7, 11, 13, 16, 21] (d=5)</option>
                        </select>
                    </div>

                    <div style="display:flex; align-items:center; gap:8px;">
                        <label style="font-size:0.85rem; color:var(--text-muted); font-weight:600;">Tableau :</label>
                        <input type="text" id="triplet-custom-input" placeholder="Ex: 1, 4, 7, 10, 13..." class="input-modern" style="width:170px;" onchange="onCustomTripletInput()">
                    </div>

                    <button class="btn-modern" onclick="stepTripletAlgorithm()">
                        <span>▶</span> Pas Suivant
                    </button>
                    <button class="btn-ghost" onclick="findAllTripletsArcs()">
                        <span>⚡</span> Détecter Tous les Triplets
                    </button>
                    <button class="btn-ghost" onclick="resetTripletsSim()">
                        <span>↺</span> Réinitialiser
                    </button>

                    <div style="margin-left: auto; font-family: var(--font-mono); font-size: 0.9rem; color: var(--text-muted);">
                        Triplets trouvés : <b id="triplets-count-num" style="color:var(--accent-emerald);">0</b>
                    </div>
                </div>

                <!-- Arène Visuelle avec Arcs SVG -->
                <div class="triplets-stage" id="triplets-stage-box">
                    <svg class="triplets-svg-overlay" id="triplets-svg"></svg>
                    
                    <div class="triplets-array-row" id="triplets-cells-row">
                        <!-- Généré en JS -->
                    </div>
                </div>

                <!-- Bannière d'état de la recherche dichotomique -->
                <div id="bs-status-banner" style="background:#090e1a; border:1px solid #1e293b; border-radius:var(--radius-md); padding:12px 18px; margin-bottom:18px; font-family:var(--font-mono); font-size:0.85rem; color:#cbd5e1;">
                    Cliquez sur "Pas Suivant" pour lancer la recherche binaire sur le premier élément...
                </div>

                <!-- Liste des triplets enregistrés -->
                <div>
                    <div style="font-size:0.85rem; font-weight:700; color:var(--text-muted); margin-bottom:8px;">
                        LISTE DES COMBINAISONS DÉCOUVERTES (Cliquez sur une carte pour isoler ses arcs) :
                    </div>
                    <div id="triplets-list-container" class="triplet-list-grid">
                        <!-- Cartes de triplets -->
                    </div>
                </div>
            </div>


            <!-- DÉCOMPOSITION EN PSEUDO-CODE -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">📋</span>
                        <h3>Décomposition Algorithmique par Parties</h3>
                    </div>
                    <span class="pill-badge pill-purple">Conception Modulaire</span>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 1 : Implémentation de la Recherche Dichotomique en $\mathcal{O}(\log N)$</div>
                    <p>Fonction de recherche binaire dans le sous-vecteur trié <code>[inf .. sup]</code> :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 1</span>
                        </div>
<pre>inf &larr; debut;  sup &larr; n - <span class="num">1</span>;  trouve &larr; <span class="kw">Faux</span>;  idx &larr; -<span class="num">1</span>;

<span class="kw">Tant Que</span> (inf &le; sup) <span class="kw">Et</span> (<span class="kw">NON</span> trouve) <span class="kw">Faire</span>
    milieu &larr; (inf + sup) <span class="kw">div</span> <span class="num">2</span>;
    <span class="kw">Si</span> A[milieu] = cible <span class="kw">Alors</span>
        trouve &larr; <span class="kw">Vrai</span>;
        idx &larr; milieu;
    <span class="kw">Sinon</span>
        <span class="kw">Si</span> A[milieu] &lt; cible <span class="kw">Alors</span> inf &larr; milieu + <span class="num">1</span>;
        <span class="kw">Sinon</span> sup &larr; milieu - <span class="num">1</span>; <span class="kw">Fsi</span>;
    <span class="kw">Fsi</span>;
<span class="kw">FinTantQue</span>;</pre>
                    </div>
                </div>

                <div class="step-container">
                    <div class="step-heading">Étape 2 : Chaînage Double pour Localiser le Triplet $(A[i], A[j], A[k])$</div>
                    <p>Pour chaque indice $i$, on cherche $A[i] + d$. Si trouvé en $j$, on recherche $A[j] + d$ en $k$ :</p>
                    <div class="code-block-modern">
                        <div class="code-block-header">
                            <span class="code-file-label">Pseudo-Code • Partie 2</span>
                        </div>
<pre><span class="kw">Pour</span> i &larr; <span class="num">0</span> <span class="kw">a</span> n - <span class="num">3</span> <span class="kw">Faire</span>
    idx_j &larr; RechercheDichotomique(A, i + <span class="num">1</span>, n - <span class="num">1</span>, A[i] + d);
    <span class="kw">Si</span> idx_j &ne; -<span class="num">1</span> <span class="kw">Alors</span>
        idx_k &larr; RechercheDichotomique(A, idx_j + <span class="num">1</span>, n - <span class="num">1</span>, A[idx_j] + d);
        <span class="kw">Si</span> idx_k &ne; -<span class="num">1</span> <span class="kw">Alors</span>
            total_triplets &larr; total_triplets + <span class="num">1</span>;
            <span class="fn">Ecrire</span>(<span class="st">"Triplet magnifique : ("</span>, A[i], <span class="st">", "</span>, A[idx_j], <span class="st">", "</span>, A[idx_k], <span class="st">")"</span>);
        <span class="kw">Fsi</span>;
    <span class="kw">Fsi</span>;
<span class="kw">FinPour</span>;</pre>
                    </div>
                </div>
            </div>

            <!-- CODE OFFICIEL VALIDE ALGOCOMPILER -->
            <div class="glass-card">
                <div class="card-header-flex">
                    <div class="card-title-group">
                        <span style="font-size: 1.3rem;">💻</span>
                        <h3>Code Source Certifié AlgoCompiler</h3>
                    </div>
                    <button class="btn-copy" onclick="copySourceCode('code-ex4')">Copier le Code .algo</button>
                </div>
                <div class="code-block-modern">
                    <div class="code-block-header">
                        <span class="code-file-label">Exos/04_triplets_magnifiques.algo</span>
                        <span class="pill-badge pill-emerald">Exit Code 0</span>
                    </div>
<pre id="code-ex4"><span class="kw">Algorithme</span> TripletsMagnifiques;
<span class="kw">Var</span>
    A[<span class="num">10</span>] : <span class="ty">Entier</span>;
    n, d, total_triplets : <span class="ty">Entier</span>;
    i, inf, sup, milieu : <span class="ty">Entier</span>;
    cible1, cible2 : <span class="ty">Entier</span>;
    idx_j, idx_k : <span class="ty">Entier</span>;
    trouve1, trouve2 : <span class="ty">Booleen</span>;

<span class="kw">Debut</span>
    n := <span class="num">10</span>;
    d := <span class="num">3</span>;

    A[<span class="num">0</span>] := <span class="num">1</span>; A[<span class="num">1</span>] := <span class="num">2</span>; A[<span class="num">2</span>] := <span class="num">4</span>; A[<span class="num">3</span>] := <span class="num">5</span>; A[<span class="num">4</span>] := <span class="num">7</span>;
    A[<span class="num">5</span>] := <span class="num">8</span>; A[<span class="num">6</span>] := <span class="num">10</span>; A[<span class="num">7</span>] := <span class="num">12</span>; A[<span class="num">8</span>] := <span class="num">13</span>; A[<span class="num">9</span>] := <span class="num">16</span>;

    total_triplets := <span class="num">0</span>;

    <span class="cm">// Recherche pour chaque element A[i]</span>
    <span class="kw">Pour</span> i := <span class="num">0</span> <span class="kw">a</span> n - <span class="num">3</span> <span class="kw">Faire</span>
        cible1 := A[i] + d;
        trouve1 := <span class="kw">Faux</span>;
        idx_j := -<span class="num">1</span>;

        <span class="cm">// Recherche dichotomique de cible1</span>
        inf := i + <span class="num">1</span>;
        sup := n - <span class="num">1</span>;
        <span class="kw">Tant Que</span> (inf &lt;= sup) <span class="kw">Et</span> (<span class="kw">NON</span> trouve1) <span class="kw">Faire</span>
            milieu := (inf + sup) / <span class="num">2</span>;
            <span class="kw">Si</span> A[milieu] = cible1 <span class="kw">Alors</span>
                trouve1 := <span class="kw">Vrai</span>;
                idx_j := milieu;
            <span class="kw">Sinon</span>
                <span class="kw">Si</span> A[milieu] &lt; cible1 <span class="kw">Alors</span> inf := milieu + <span class="num">1</span>;
                <span class="kw">Sinon</span> sup := milieu - <span class="num">1</span>; <span class="kw">Fsi</span>
            <span class="kw">Fsi</span>
        <span class="kw">FinTantQue</span>

        <span class="cm">// Si cible1 est trouvee, recherche de cible2</span>
        <span class="kw">Si</span> trouve1 <span class="kw">Alors</span>
            cible2 := A[idx_j] + d;
            trouve2 := <span class="kw">Faux</span>;
            idx_k := -<span class="num">1</span>;

            inf := idx_j + <span class="num">1</span>;
            sup := n - <span class="num">1</span>;
            <span class="kw">Tant Que</span> (inf &lt;= sup) <span class="kw">Et</span> (<span class="kw">NON</span> trouve2) <span class="kw">Faire</span>
                milieu := (inf + sup) / <span class="num">2</span>;
                <span class="kw">Si</span> A[milieu] = cible2 <span class="kw">Alors</span>
                    trouve2 := <span class="kw">Vrai</span>;
                    idx_k := milieu;
                <span class="kw">Sinon</span>
                    <span class="kw">Si</span> A[milieu] &lt; cible2 <span class="kw">Alors</span> inf := milieu + <span class="num">1</span>;
                    <span class="kw">Sinon</span> sup := milieu - <span class="num">1</span>; <span class="kw">Fsi</span>
                <span class="kw">Fsi</span>
            <span class="kw">FinTantQue</span>

            <span class="kw">Si</span> trouve2 <span class="kw">Alors</span>
                total_triplets := total_triplets + <span class="num">1</span>;
                <span class="fn">Ecrire</span>(<span class="st">"Triplet magnifique #"</span>, total_triplets, <span class="st">" : ("</span>, A[i], <span class="st">", "</span>, A[idx_j], <span class="st">", "</span>, A[idx_k], <span class="st">")\n"</span>);
            <span class="kw">Fsi</span>
        <span class="kw">Fsi</span>
    <span class="kw">FinPour</span>
<span class="kw">Fin</span>.</pre>
                </div>

                <div class="terminal-block">
                    <div class="terminal-tag">
                        <span>AlgoCompiler CLI Execution Log</span>
                        <span style="color:#10b981;">✔ Code 0 • Execution Success</span>
                    </div>=== EXERCICE 4 : TRIPLETS MAGNIFIQUES (BEAUTIFUL TRIPLETS) ===

Tableau d'entiers trie A (N =  10 ) :
[ 1  2  4  5  7  8  10  12  13  16  ]
Difference requise (d) :  3 

Recherche des triplets (A[i], A[j], A[k]) tels que :
  i < j < k  ET  A[j] - A[i] =  3   ET  A[k] - A[j] =  3 

Triplet(s) magnifique(s) avec A[ 0 ] =  1  : ( 1 ,  4 ,  7 ) -> 1  combinaison(s)
Triplet(s) magnifique(s) avec A[ 1 ] =  2  : ( 2 ,  5 ,  8 ) -> 1  combinaison(s)
Triplet(s) magnifique(s) avec A[ 2 ] =  4  : ( 4 ,  7 ,  10 ) -> 1  combinaison(s)
Triplet(s) magnifique(s) avec A[ 4 ] =  7  : ( 7 ,  10 ,  13 ) -> 1  combinaison(s)
Triplet(s) magnifique(s) avec A[ 6 ] =  10  : ( 10 ,  13 ,  16 ) -> 1  combinaison(s)

------------------------------------------------------------
Total de triplets magnifiques trouves :  5 
Algorithme termine avec succes !</div>
            </div>

        </section>

    </main>

    <footer>
        <div class="header-content">
            <p>Conception et Analyse d'Algorithmes (2ème Année Licence MI) — Solutions Officielles Validées</p>
            <p style="margin-top: 6px; font-size: 0.78rem;">Compilateur AlgoCompiler v2.0 • Rendu Mathématique KaTeX • Architecture HTML5/Canvas Responsive</p>
        </div>
    </footer>

    <!-- Toast de notification -->
    <div id="toast">Code copié dans le presse-papier !</div>

    <!-- JAVASCRIPT GLOBAL & MOTEURS DE SIMULATION -->
    <script>
        // ==============================================================
        // 0. GESTION DES ONGLETS & RENDU KATEX
        // ==============================================================
        function switchExercise(index) {
            const tabs = document.querySelectorAll('.tab-content');
            const btns = document.querySelectorAll('.tab-btn');

            tabs.forEach((tab, i) => {
                tab.classList.toggle('active', i === index);
            });
            btns.forEach((btn, i) => {
                btn.classList.toggle('active', i === index);
            });

            // Re-render math if KaTeX is present
            triggerKaTeXRender();

            // Resize canvas if switching to median filter
            if (index === 2) {
                renderAllCanvases();
            }
            // Resize SVG arcs if switching to triplets
            if (index === 3) {
                setTimeout(drawAllTripletsArcsSVG, 100);
            }
        }

        function triggerKaTeXRender() {
            if (window.renderMathInElement) {
                renderMathInElement(document.body, {
                    delimiters: [
                        { left: '$$', right: '$$', display: true },
                        { left: '$', right: '$', display: false },
                        { left: '\\(', right: '\\)', display: false },
                        { left: '\\[', right: '\\]', display: true }
                    ],
                    throwOnError: false
                });
            }
        }

        function copySourceCode(elementId) {
            const code = document.getElementById(elementId).innerText;
            navigator.clipboard.writeText(code).then(() => {
                showToast("Code copié dans le presse-papier !");
            });
        }

        function showToast(msg) {
            const toast = document.getElementById('toast');
            toast.innerText = msg;
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
            }, 2500);
        }

        // ==============================================================
        // 1. SIMULATION : ROTATION DES ANNEAUX DE MATRICE
        // ==============================================================
        let matRows = 4;
        let matCols = 4;
        let matrixData = [];
        let matRotationsCount = 0;
        let matInterval = null;
        let matSpeed = 450;

        function getRingIndex(i, j, R, C) {
            return Math.min(i, j, R - 1 - i, C - 1 - j);
        }

        function initMatrixData() {
            matrixData = [];
            let val = 1;
            for (let i = 0; i < matRows; i++) {
                let row = [];
                for (let j = 0; j < matCols; j++) {
                    row.push(val++);
                }
                matrixData.push(row);
            }
            matRotationsCount = 0;
            renderMatrixGrid();
            renderUnrollRibbon();
            updateRingPerimetersUI();
        }

        function renderMatrixGrid() {
            const grid = document.getElementById('matrix-grid-elem');
            grid.innerHTML = '';
            grid.style.gridTemplateColumns = `repeat(${matCols}, 54px)`;

            for (let i = 0; i < matRows; i++) {
                for (let j = 0; j < matCols; j++) {
                    const cell = document.createElement('div');
                    cell.className = 'mat-cell';
                    const ring = getRingIndex(i, j, matRows, matCols);
                    cell.classList.add(`ring-${ring % 3}`);

                    cell.innerHTML = `
                        <span>${matrixData[i][j]}</span>
                        <span class="mat-cell-coord">${i},${j}</span>
                    `;
                    grid.appendChild(cell);
                }
            }
            document.getElementById('mat-counter-display').innerText = matRotationsCount;
        }

        function updateRingPerimetersUI() {
            const p0 = 2 * matRows + 2 * matCols - 4;
            const p1 = (matRows >= 4 && matCols >= 4) ? 2 * (matRows - 2) + 2 * (matCols - 2) - 4 : 0;
            document.getElementById('p-ring-0').innerText = `P₀ = ${p0}`;
            document.getElementById('p-ring-1').innerText = p1 > 0 ? `P₁ = ${p1}` : `P₁ = N/A`;
        }

        function renderUnrollRibbon() {
            const strip = document.getElementById('unroll-strip-elem');
            strip.innerHTML = '';

            // Anneau 0 éléments dans l'ordre du périmètre
            const perimeterVals = getPerimeterCoordinates(0, matRows, matCols).map(pt => matrixData[pt.r][pt.c]);
            perimeterVals.forEach((val, idx) => {
                const cell = document.createElement('div');
                cell.className = 'unroll-cell';
                cell.innerHTML = `<span>${val}</span>`;
                strip.appendChild(cell);
            });
        }

        function getPerimeterCoordinates(k, M, N) {
            const coords = [];
            // Haut: gauche à droite
            for (let j = k; j < N - k; j++) coords.push({ r: k, c: j });
            // Droite: haut vers bas
            for (let i = k + 1; i < M - k; i++) coords.push({ r: i, c: N - 1 - k });
            // Bas: droite à gauche
            for (let j = N - 2 - k; j >= k; j--) coords.push({ r: M - 1 - k, c: j });
            // Gauche: bas vers haut
            for (let i = M - 2 - k; i > k; i--) coords.push({ r: i, c: k });
            return coords;
        }

        function stepMatrixRotation() {
            const numRings = Math.floor(Math.min(matRows, matCols) / 2);

            for (let k = 0; k < numRings; k++) {
                const temp = matrixData[k][k];

                // Paroi sup (vers gauche)
                for (let j = k; j < matCols - 1 - k; j++) {
                    matrixData[k][j] = matrixData[k][j + 1];
                }
                // Paroi droite (vers haut)
                for (let i = k; i < matRows - 1 - k; i++) {
                    matrixData[i][matCols - 1 - k] = matrixData[i + 1][matCols - 1 - k];
                }
                // Paroi bas (vers droite)
                for (let j = matCols - 1 - k; j > k; j--) {
                    matrixData[matRows - 1 - k][j] = matrixData[matRows - 1 - k][j - 1];
                }
                // Paroi gauche (vers bas)
                for (let i = matRows - 1 - k; i > k + 1; i--) {
                    matrixData[i][k] = matrixData[i - 1][k];
                }
                matrixData[k + 1][k] = temp;
            }

            matRotationsCount++;
            renderMatrixGrid();
            renderUnrollRibbon();
        }

        function stepMatrixClockwise() {
            const numRings = Math.floor(Math.min(matRows, matCols) / 2);

            for (let k = 0; k < numRings; k++) {
                const temp = matrixData[k][k];

                // Gauche vers le haut
                for (let i = k; i < matRows - 1 - k; i++) {
                    matrixData[i][k] = matrixData[i + 1][k];
                }
                // Bas vers la gauche
                for (let j = k; j < matCols - 1 - k; j++) {
                    matrixData[matRows - 1 - k][j] = matrixData[matRows - 1 - k][j + 1];
                }
                // Droite vers le bas
                for (let i = matRows - 1 - k; i > k; i--) {
                    matrixData[i][matCols - 1 - k] = matrixData[i - 1][matCols - 1 - k];
                }
                // Haut vers la droite
                for (let j = matCols - 1 - k; j > k + 1; j--) {
                    matrixData[k][j] = matrixData[k][j - 1];
                }
                matrixData[k][k + 1] = temp;
            }

            matRotationsCount--;
            renderMatrixGrid();
            renderUnrollRibbon();
        }

        function toggleAutoMatrix() {
            if (matInterval) {
                clearInterval(matInterval);
                matInterval = null;
                document.getElementById('mat-play-icon').innerText = '⏵';
                document.getElementById('mat-play-label').innerText = 'Lecture Continue';
            } else {
                matInterval = setInterval(stepMatrixRotation, matSpeed);
                document.getElementById('mat-play-icon').innerText = '⏸';
                document.getElementById('mat-play-label').innerText = 'Pause';
            }
        }

        function resetMatrix() {
            if (matInterval) toggleAutoMatrix();
            initMatrixData();
        }

        function changeMatrixDimension() {
            const val = document.getElementById('mat-dim-select').value;
            if (val === '4x4') { matRows = 4; matCols = 4; }
            else if (val === '5x5') { matRows = 5; matCols = 5; }
            else if (val === '6x4') { matRows = 6; matCols = 4; }
            resetMatrix();
        }

        function updateMatrixSpeed() {
            matSpeed = parseInt(document.getElementById('mat-speed-select').value);
            if (matInterval) {
                clearInterval(matInterval);
                matInterval = setInterval(stepMatrixRotation, matSpeed);
            }
        }

        // ==============================================================
        // 2. SIMULATION : STEADY BEAR DNA (TWO-POINTERS)
        // ==============================================================
        let dnaSequence = "GAAATAAA";
        let dnaLen = 8;
        let dnaTargetFreq = 2;
        let dnaCountsOut = { A: 0, C: 0, G: 0, T: 0 };
        let dnaLeftPtr = 0;
        let dnaRightPtr = 0;
        let dnaMinFound = 999;
        let dnaBestL = 0;
        let dnaBestR = 0;
        let dnaAutoInterval = null;
        let dnaStatePhase = 'expand_right'; // 'expand_right' | 'shrink_left' | 'finished'

        function initDna() {
            dnaLen = dnaSequence.length;
            dnaTargetFreq = dnaLen / 4;
            dnaCountsOut = { A: 0, C: 0, G: 0, T: 0 };
            for (let c of dnaSequence) {
                dnaCountsOut[c]++;
            }
            dnaLeftPtr = 0;
            dnaRightPtr = 0;
            dnaMinFound = dnaLen;
            dnaBestL = 0;
            dnaBestR = dnaLen - 1;
            dnaStatePhase = 'expand_right';

            renderDnaTrack();
            updateDnaGauges();
            updateDnaVerdictBanner();
        }

        function loadDnaPreset() {
            if (dnaAutoInterval) toggleAutoDna();
            dnaSequence = document.getElementById('dna-preset-select').value;
            initDna();
        }

        function renderDnaTrack() {
            const track = document.getElementById('dna-track-elem');
            track.innerHTML = '';

            const isAlreadySteady = checkAlreadySteady();

            for (let i = 0; i < dnaLen; i++) {
                const node = document.createElement('div');
                const char = dnaSequence[i];
                node.className = `dna-node dna-node-${char}`;

                const fullName = { A: 'Adénine', C: 'Cytosine', G: 'Guanine', T: 'Thymine' }[char];
                node.innerHTML = `
                    <span>${char}</span>
                    <span class="dna-node-idx">[${i}]</span>
                    <span class="dna-node-name">${fullName}</span>
                `;

                // Window highlight
                if (!isAlreadySteady && i >= dnaLeftPtr && i < dnaRightPtr) {
                    node.classList.add('in-window');
                    if (i === dnaLeftPtr && i === dnaRightPtr - 1) {
                        node.innerHTML += `<span class="dna-window-badge">L = R</span>`;
                    } else if (i === dnaLeftPtr) {
                        node.innerHTML += `<span class="dna-window-badge">L = ${dnaLeftPtr}</span>`;
                    } else if (i === dnaRightPtr - 1) {
                        node.innerHTML += `<span class="dna-window-badge">R = ${dnaRightPtr - 1}</span>`;
                    }
                }

                track.appendChild(node);
            }
        }

        function checkAlreadySteady() {
            let initialCounts = { A: 0, C: 0, G: 0, T: 0 };
            for (let c of dnaSequence) initialCounts[c]++;
            return (initialCounts.A === dnaTargetFreq && initialCounts.C === dnaTargetFreq &&
                    initialCounts.G === dnaTargetFreq && initialCounts.T === dnaTargetFreq);
        }

        function isOutsideValid() {
            return (dnaCountsOut.A <= dnaTargetFreq &&
                    dnaCountsOut.C <= dnaTargetFreq &&
                    dnaCountsOut.G <= dnaTargetFreq &&
                    dnaCountsOut.T <= dnaTargetFreq);
        }

        function updateDnaGauges() {
            ['A', 'C', 'G', 'T'].forEach(base => {
                const count = dnaCountsOut[base];
                const isOver = count > dnaTargetFreq;
                const percent = Math.min(100, Math.round((count / (dnaTargetFreq * 2 || 1)) * 100));

                document.getElementById(`gauge-count-${base}`).innerText = `${count} / ${dnaTargetFreq}`;
                document.getElementById(`gauge-target-${base}`).innerText = `Max autorisé : ${dnaTargetFreq}`;

                const bar = document.getElementById(`bar-${base}`);
                bar.style.width = `${percent}%`;
                bar.style.backgroundColor = isOver ? '#f43f5e' : (base === 'A' ? '#10b981' : base === 'C' ? '#06b6d4' : base === 'G' ? '#f59e0b' : '#fb7185');

                const badge = document.getElementById(`gauge-badge-${base}`);
                if (isOver) {
                    badge.innerHTML = `<span style="color:#f43f5e; font-weight:700;">⚠️ Excès (+${count - dnaTargetFreq})</span>`;
                } else {
                    badge.innerHTML = `<span style="color:#10b981;">✔ Conforme</span>`;
                }
            });
        }

        function stepDnaAlgorithm() {
            if (checkAlreadySteady()) {
                dnaMinFound = 0;
                updateDnaVerdictBanner();
                return;
            }

            if (dnaRightPtr > dnaLen) {
                dnaStatePhase = 'finished';
                updateDnaVerdictBanner();
                return;
            }

            if (isOutsideValid() && dnaLeftPtr < dnaRightPtr) {
                // Essayer de resserrer la fenêtre par la gauche
                const curLen = dnaRightPtr - dnaLeftPtr;
                if (curLen < dnaMinFound) {
                    dnaMinFound = curLen;
                    dnaBestL = dnaLeftPtr;
                    dnaBestR = dnaRightPtr - 1;
                }

                // On réintègre dnaSequence[dnaLeftPtr] à l'extérieur
                const charL = dnaSequence[dnaLeftPtr];
                dnaCountsOut[charL]++;
                dnaLeftPtr++;
            } else {
                // On agrandit la fenêtre par la droite
                if (dnaRightPtr < dnaLen) {
                    const charR = dnaSequence[dnaRightPtr];
                    dnaCountsOut[charR]--;
                    dnaRightPtr++;
                } else {
                    dnaRightPtr++;
                }
            }

            // Vérifier à nouveau la validité après l'opération
            if (isOutsideValid() && dnaLeftPtr < dnaRightPtr) {
                const curLen = dnaRightPtr - dnaLeftPtr;
                if (curLen < dnaMinFound) {
                    dnaMinFound = curLen;
                    dnaBestL = dnaLeftPtr;
                    dnaBestR = dnaRightPtr - 1;
                }
            }

            renderDnaTrack();
            updateDnaGauges();
            updateDnaVerdictBanner();
        }

        function solveDnaInstantly() {
            initDna();
            let safety = 0;
            while (dnaRightPtr <= dnaLen && safety++ < 100) {
                stepDnaAlgorithm();
                if (isOutsideValid() && dnaLeftPtr === dnaRightPtr) break;
            }
            dnaStatePhase = 'finished';
            renderDnaTrack();
            updateDnaGauges();
            updateDnaVerdictBanner();
        }

        function toggleAutoDna() {
            if (dnaAutoInterval) {
                clearInterval(dnaAutoInterval);
                dnaAutoInterval = null;
                document.getElementById('dna-play-icon').innerText = '⏵';
                document.getElementById('dna-play-label').innerText = 'Lecture Auto';
            } else {
                dnaAutoInterval = setInterval(() => {
                    stepDnaAlgorithm();
                    if (dnaStatePhase === 'finished') {
                        toggleAutoDna();
                    }
                }, 400);
                document.getElementById('dna-play-icon').innerText = '⏸';
                document.getElementById('dna-play-label').innerText = 'Pause';
            }
        }

        function resetDnaState() {
            if (dnaAutoInterval) toggleAutoDna();
            initDna();
        }

        function updateDnaVerdictBanner() {
            const box = document.getElementById('dna-verdict-box');
            if (checkAlreadySteady()) {
                box.innerHTML = `
                    <div style="font-weight:700; color:#34d399; font-size:1.05rem;">
                        ✔ Ce brin est DÉJÀ parfaitement équilibré !
                    </div>
                    <div style="font-size:0.88rem; color:var(--text-muted); margin-top:4px;">
                        Chaque base apparaît exactement ${dnaTargetFreq} fois. Aucune mutation requise (Longueur minimale = 0).
                    </div>
                `;
                return;
            }

            const valid = isOutsideValid();
            const curLen = dnaRightPtr - dnaLeftPtr;
            const subStr = dnaSequence.substring(dnaBestL, dnaBestR + 1);

            box.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div>
                        <span style="font-weight:700; color:${valid ? '#34d399' : '#fb7185'}; font-size:1rem;">
                            ${valid ? '✔ FENÊTRE COURANTE VALIDE' : '⚠️ FENÊTRE INSUFFISANTE'} :
                        </span>
                        <span style="font-size:0.88rem; color:#cbd5e1; margin-left:6px;">
                            Fenêtre active [${dnaLeftPtr} .. ${Math.max(dnaLeftPtr, dnaRightPtr - 1)}] (${curLen} bases)
                        </span>
                    </div>
                    <div style="font-family:var(--font-mono); font-size:0.9rem; color:#a5b4fc;">
                        Meilleure longueur minimale trouvée : <b style="color:#fde047; font-size:1.15rem;">${dnaMinFound}</b>
                    </div>
                </div>
                <div style="margin-top:8px; font-size:0.85rem; color:var(--text-muted);">
                    Sous-chaîne optimale à remplacer : indices <b>[${dnaBestL} à ${dnaBestR}]</b> ➜
                    <code style="color:#fde047; font-size:1rem; font-weight:700; background:#1e293b; padding:2px 8px; border-radius:4px;">'${subStr}'</code>
                </div>
            `;
        }

        // ==============================================================
        // 3. SIMULATION : FILTRE MÉDIAN SUR CANVAS (IMAGE NATURELLE)
        // ==============================================================
        const CV_DIM = 64;
        let originalPixels = new Uint8Array(CV_DIM * CV_DIM);
        let noisyPixels = new Uint8Array(CV_DIM * CV_DIM);
        let filteredPixels = new Uint8Array(CV_DIM * CV_DIM);
        let scanInterval = null;
        let scanCurrI = 1;
        let scanCurrJ = 1;

        function generateSyntheticScene() {
            // Créer une image 64x64 avec du relief : ciel en dégradé, soleil, montagnes, château
            for (let y = 0; y < CV_DIM; y++) {
                for (let x = 0; x < CV_DIM; x++) {
                    const idx = y * CV_DIM + x;
                    
                    // Dégradé de ciel
                    let val = Math.floor(40 + (y / CV_DIM) * 80);

                    // Soleil circulaire
                    const dx = x - 18, dy = y - 18;
                    if (dx * dx + dy * dy <= 8 * 8) {
                        val = 240;
                    }

                    // Montagnes triangulaires
                    if (y >= 30) {
                        const m1 = 50 - Math.abs(x - 24);
                        const m2 = 54 - Math.abs(x - 48);
                        if (y >= m1 || y >= m2) {
                            val = 140 - (y - 30);
                        }
                    }

                    // Maison / Château avec fenêtre
                    if (x >= 26 && x <= 42 && y >= 38 && y <= 56) {
                        val = 210; // Mur clair
                        // Toit
                        if (y < 42) val = 110;
                        // Fenêtre sombre
                        if (x >= 32 && x <= 36 && y >= 45 && y <= 49) {
                            val = 30;
                        }
                    }

                    // Sol plat
                    if (y >= 56) {
                        val = 90;
                    }

                    originalPixels[idx] = Math.max(0, Math.min(255, val));
                }
            }
        }

        function regenerateNoise() {
            if (scanInterval) {
                clearInterval(scanInterval);
                scanInterval = null;
            }
            const density = parseFloat(document.getElementById('noise-density-select').value);

            // Copier originaux
            for (let i = 0; i < CV_DIM * CV_DIM; i++) {
                noisyPixels[i] = originalPixels[i];
                filteredPixels[i] = originalPixels[i];
            }

            // Injecter sel (255) et poivre (0)
            for (let y = 0; y < CV_DIM; y++) {
                for (let x = 0; x < CV_DIM; x++) {
                    const r = Math.random();
                    const idx = y * CV_DIM + x;
                    if (r < density / 2) {
                        noisyPixels[idx] = 255; // Sel
                    } else if (r < density) {
                        noisyPixels[idx] = 0;   // Poivre
                    }
                }
            }

            // Assurer au moins les 2 points de test
            noisyPixels[16 * CV_DIM + 16] = 255;
            noisyPixels[32 * CV_DIM + 32] = 0;

            renderAllCanvases();
            inspectPixelAt(16, 16);
        }

        function drawPixelBufferToCanvas(canvasId, buffer) {
            const cv = document.getElementById(canvasId);
            const ctx = cv.getContext('2d');
            const imgData = ctx.createImageData(CV_DIM, CV_DIM);
            for (let i = 0; i < CV_DIM * CV_DIM; i++) {
                const v = buffer[i];
                const p = i * 4;
                imgData.data[p] = v;
                imgData.data[p + 1] = v;
                imgData.data[p + 2] = v;
                imgData.data[p + 3] = 255;
            }
            ctx.putImageData(imgData, 0, 0);
        }

        function renderAllCanvases() {
            drawPixelBufferToCanvas('cv-original', originalPixels);
            drawPixelBufferToCanvas('cv-noisy', noisyPixels);
            drawPixelBufferToCanvas('cv-filtered', filteredPixels);
        }

        function inspectPixelAt(cy, cx) {
            if (cx < 1 || cx >= CV_DIM - 1 || cy < 1 || cy >= CV_DIM - 1) return;

            document.getElementById('inspect-coords').innerText = `${cy}, ${cx}`;

            // Récolter les 9 voisins
            const kernel = [];
            for (let dy = -1; dy <= 1; dy++) {
                for (let dx = -1; dx <= 1; dx++) {
                    kernel.push(noisyPixels[(cy + dy) * CV_DIM + (cx + dx)]);
                }
            }

            // Rendu matrice 3x3
            const grid3x3 = document.getElementById('kernel-3x3-view');
            grid3x3.innerHTML = '';
            kernel.forEach((val, idx) => {
                const cell = document.createElement('div');
                cell.className = 'k-cell';
                if (idx === 4) cell.classList.add('k-center');
                cell.innerText = val;
                cell.style.backgroundColor = `rgb(${val}, ${val}, ${val})`;
                cell.style.color = val > 128 ? '#000' : '#fff';
                grid3x3.appendChild(cell);
            });

            // Tri à bulles sur les 9 éléments
            const sorted = [...kernel].sort((a, b) => a - b);
            const medianVal = sorted[4];

            // Rendu des cellules triées
            const sortedStrip = document.getElementById('sorted-cells-view');
            sortedStrip.innerHTML = '';
            sorted.forEach((val, idx) => {
                const cell = document.createElement('div');
                cell.className = 's-cell';
                if (idx === 4) cell.classList.add('s-median');
                else if (val === 0) cell.classList.add('s-pepper');
                else if (val === 255) cell.classList.add('s-salt');

                cell.innerHTML = `<span>${val}</span><span style="font-size:0.6rem; opacity:0.6;">[${idx}]</span>`;
                sortedStrip.appendChild(cell);
            });

            // Explication analytique
            const centerVal = kernel[4];
            const isSalt = centerVal === 255;
            const isPepper = centerVal === 0;

            const expl = document.getElementById('inspector-analysis-text');
            if (isSalt) {
                expl.innerHTML = `
                    <b style="color:#fb7185;">Pixel central = 255 (Bruit Sel) :</b> 
                    Propulsé en toute fin de liste triée (indice 8). 
                    Remplacé par la vraie médiane <b style="color:#34d399;">${medianVal}</b> !
                `;
            } else if (isPepper) {
                expl.innerHTML = `
                    <b style="color:#fb7185;">Pixel central = 0 (Bruit Poivre) :</b> 
                    Propulsé au tout début de la liste triée (indice 0). 
                    Remplacé par la vraie médiane <b style="color:#34d399;">${medianVal}</b> !
                `;
            } else {
                expl.innerHTML = `
                    <span style="color:#38bdf8;">Pixel naturel = ${centerVal} :</span> 
                    La médiane locale est <b style="color:#34d399;">${medianVal}</b>. Aucune distorsion de texture.
                `;
            }

            // Positionner la boîte de sélection sur le canvas corrompu
            const scanBox = document.getElementById('scan-box');
            scanBox.style.display = 'block';
            const scale = 220 / CV_DIM;
            scanBox.style.left = `${(cx - 1) * scale}px`;
            scanBox.style.top = `${(cy - 1) * scale}px`;
            scanBox.style.width = `${3 * scale}px`;
            scanBox.style.height = `${3 * scale}px`;
        }

        function inspectPresetPixel(type) {
            if (type === 'salt') inspectPixelAt(16, 16);
            if (type === 'pepper') inspectPixelAt(32, 32);
        }

        function applyInstantMedianFilter() {
            for (let y = 1; y < CV_DIM - 1; y++) {
                for (let x = 1; x < CV_DIM - 1; x++) {
                    const vals = [];
                    for (let dy = -1; dy <= 1; dy++) {
                        for (let dx = -1; dx <= 1; dx++) {
                            vals.push(noisyPixels[(y + dy) * CV_DIM + (x + dx)]);
                        }
                    }
                    vals.sort((a, b) => a - b);
                    filteredPixels[y * CV_DIM + x] = vals[4];
                }
            }
            renderAllCanvases();
            showToast("Filtrage médian appliqué sur l'image entière !");
        }

        function animateMedianScan() {
            if (scanInterval) {
                clearInterval(scanInterval);
                scanInterval = null;
                return;
            }

            scanCurrI = 1;
            scanCurrJ = 1;

            scanInterval = setInterval(() => {
                for (let step = 0; step < 8; step++) {
                    const y = scanCurrI;
                    const x = scanCurrJ;

                    const vals = [];
                    for (let dy = -1; dy <= 1; dy++) {
                        for (let dx = -1; dx <= 1; dx++) {
                            vals.push(noisyPixels[(y + dy) * CV_DIM + (x + dx)]);
                        }
                    }
                    vals.sort((a, b) => a - b);
                    filteredPixels[y * CV_DIM + x] = vals[4];

                    scanCurrJ++;
                    if (scanCurrJ >= CV_DIM - 1) {
                        scanCurrJ = 1;
                        scanCurrI++;
                    }

                    if (scanCurrI >= CV_DIM - 1) {
                        clearInterval(scanInterval);
                        scanInterval = null;
                        renderAllCanvases();
                        showToast("Balayage terminé avec succès !");
                        return;
                    }
                }

                inspectPixelAt(scanCurrI, scanCurrJ);
                drawPixelBufferToCanvas('cv-filtered', filteredPixels);
            }, 25);
        }

        // ==============================================================
        // 4. SIMULATION : TRIPLETS MAGNIFIQUES (ARCS SVG + DICHOTOMIE)
        // ==============================================================
        const sampleArrayA = [1, 2, 4, 5, 7, 8, 10, 12, 13, 16];
        let diffD = 3;
        let tripletCurrentI = 0;
        let tripletsFoundList = [];

        function initTripletsArray() {
            tripletCurrentI = 0;
            tripletsFoundList = [];
            renderTripletsCells();
            document.getElementById('triplets-list-container').innerHTML = '';
            document.getElementById('triplets-count-num').innerText = '0';
            document.getElementById('triplets-svg').innerHTML = '';
        }

        function updateTripletsDifference() {
            diffD = parseInt(document.getElementById('triplet-d-input').value) || 3;
            initTripletsArray();
        }

        function renderTripletsCells(activeI = -1, activeJ = -1, activeK = -1, midIdx = -1) {
            const container = document.getElementById('triplets-cells-row');
            container.innerHTML = '';

            sampleArrayA.forEach((val, idx) => {
                const box = document.createElement('div');
                box.className = 'triplet-box';
                box.id = `tbox-${idx}`;
                box.innerHTML = `
                    <span>${val}</span>
                    <span class="triplet-idx">[${idx}]</span>
                `;

                if (idx === activeI) box.classList.add('active-i');
                if (idx === activeJ) box.classList.add('active-j');
                if (idx === activeK) box.classList.add('active-k');
                if (idx === midIdx) box.classList.add('bs-mid');

                container.appendChild(box);
            });
        }

        function binarySearchAlgo(arr, target, startIdx) {
            let inf = startIdx;
            let sup = arr.length - 1;
            while (inf <= sup) {
                let mid = Math.floor((inf + sup) / 2);
                if (arr[mid] === target) return mid;
                else if (arr[mid] < target) inf = mid + 1;
                else sup = mid - 1;
            }
            return -1;
        }

        function stepTripletAlgorithm() {
            if (tripletCurrentI >= sampleArrayA.length - 2) {
                tripletCurrentI = 0;
                showToast("Fin du parcours. Réinitialisation au début.");
            }

            const i = tripletCurrentI;
            const targetJ = sampleArrayA[i] + diffD;
            const j = binarySearchAlgo(sampleArrayA, targetJ, i + 1);

            const banner = document.getElementById('bs-status-banner');

            if (j !== -1) {
                const targetK = sampleArrayA[j] + diffD;
                const k = binarySearchAlgo(sampleArrayA, targetK, j + 1);

                if (k !== -1) {
                    // Triplet magnifique trouvé
                    renderTripletsCells(i, j, k);
                    drawArcBetween(i, j, '#38bdf8', `+${diffD}`);
                    drawArcBetween(j, k, '#10b981', `+${diffD}`);
                    addTripletCardToUI(i, j, k);

                    banner.innerHTML = `
                        <b style="color:#34d399;">✔ Triplet Magnifique Détecté !</b> 
                        (i=${i}: <b style="color:#38bdf8;">${sampleArrayA[i]}</b>, 
                         j=${j}: <b style="color:#fbbf24;">${sampleArrayA[j]}</b>, 
                         k=${k}: <b style="color:#10b981;">${sampleArrayA[k]}</b>) 
                        avec progression continue d=${diffD}.
                    `;
                    tripletCurrentI++;
                    return;
                }
            }

            // Pas de triplet
            renderTripletsCells(i, -1, -1);
            banner.innerHTML = `
                <span style="color:#94a3b8;">Élément A[${i}] = ${sampleArrayA[i]} :</span> 
                Cible A[i]+d = ${targetJ} 
                ${j === -1 ? '<b>non trouvée</b> par dichotomie.' : `trouvée en j=${j}, mais A[j]+d non trouvée.`}
            `;
            tripletCurrentI++;
        }

        function drawArcBetween(idx1, idx2, color, labelText) {
            const svg = document.getElementById('triplets-svg');
            const el1 = document.getElementById(`tbox-${idx1}`);
            const el2 = document.getElementById(`tbox-${idx2}`);
            if (!el1 || !el2) return;

            const stageRect = document.getElementById('triplets-stage-box').getBoundingClientRect();
            const r1 = el1.getBoundingClientRect();
            const r2 = el2.getBoundingClientRect();

            const x1 = r1.left + r1.width / 2 - stageRect.left;
            const y1 = r1.top - stageRect.top;
            const x2 = r2.left + r2.width / 2 - stageRect.left;
            const y2 = r2.top - stageRect.top;

            const midX = (x1 + x2) / 2;
            const arcHeight = Math.min(65, Math.abs(x2 - x1) * 0.45);
            const peakY = Math.max(15, y1 - arcHeight);

            // Path quadratique
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const dStr = `M ${x1} ${y1} Q ${midX} ${peakY - 10} ${x2} ${y2}`;
            path.setAttribute('d', dStr);
            path.setAttribute('stroke', color);
            path.setAttribute('stroke-width', '2.5');
            path.setAttribute('fill', 'none');
            path.setAttribute('stroke-linecap', 'round');
            path.setAttribute('filter', `drop-shadow(0 0 6px ${color})`);

            // Texte d'étiquette
            const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            text.setAttribute('x', midX);
            text.setAttribute('y', peakY - 4);
            text.setAttribute('fill', color);
            text.setAttribute('font-size', '11');
            text.setAttribute('font-family', 'var(--font-mono)');
            text.setAttribute('font-weight', 'bold');
            text.setAttribute('text-anchor', 'middle');
            text.textContent = labelText;

            svg.appendChild(path);
            svg.appendChild(text);
        }

        function findAllTripletsArcs() {
            initTripletsArray();
            const svg = document.getElementById('triplets-svg');
            svg.innerHTML = '';

            for (let i = 0; i < sampleArrayA.length - 2; i++) {
                const targetJ = sampleArrayA[i] + diffD;
                const j = binarySearchAlgo(sampleArrayA, targetJ, i + 1);
                if (j !== -1) {
                    const targetK = sampleArrayA[j] + diffD;
                    const k = binarySearchAlgo(sampleArrayA, targetK, j + 1);
                    if (k !== -1) {
                        drawArcBetween(i, j, '#38bdf8', `+${diffD}`);
                        drawArcBetween(j, k, '#10b981', `+${diffD}`);
                        addTripletCardToUI(i, j, k);
                    }
                }
            }

            renderTripletsCells(-1, -1, -1);
            document.getElementById('bs-status-banner').innerHTML = `
                <b style="color:#34d399;">✔ Tous les ${tripletsFoundList.length} Triplets Magnifiques ont été identifiés !</b>
            `;
        }

        function addTripletCardToUI(i, j, k) {
            const idKey = `${i}-${j}-${k}`;
            if (tripletsFoundList.includes(idKey)) return;
            tripletsFoundList.push(idKey);

            document.getElementById('triplets-count-num').innerText = tripletsFoundList.length;

            const container = document.getElementById('triplets-list-container');
            const card = document.createElement('div');
            card.className = 'triplet-record-card';
            card.innerHTML = `
                <div>
                    <b>(${sampleArrayA[i]}, ${sampleArrayA[j]}, ${sampleArrayA[k]})</b>
                    <span style="color:var(--text-muted); font-size:0.75rem; margin-left:8px;">
                        [${sampleArrayA[j]} - ${sampleArrayA[i]} = ${diffD}]
                    </span>
                </div>
                <div style="color:#38bdf8; font-size:0.8rem;">(i=${i}, j=${j}, k=${k})</div>
            `;

            card.onclick = () => {
                document.getElementById('triplets-svg').innerHTML = '';
                renderTripletsCells(i, j, k);
                drawArcBetween(i, j, '#38bdf8', `+${diffD}`);
                drawArcBetween(j, k, '#10b981', `+${diffD}`);
            };

            container.appendChild(card);
        }

        function resetTripletsSim() {
            initTripletsArray();
        }

        function drawAllTripletsArcsSVG() {
            if (tripletsFoundList.length > 0) {
                findAllTripletsArcs();
            }
        }

        // ==============================================================
        // INITIALISATION GLOBALE AU CHARGEMENT
        // ==============================================================
        window.addEventListener('DOMContentLoaded', () => {
            // KaTeX
            triggerKaTeXRender();

            // Initialiser les 4 simulations
            initMatrixData();
            initDna();
            generateSyntheticScene();
            regenerateNoise();
            initTripletsArray();

            // Canvas click handler
            const noisyCanvas = document.getElementById('cv-noisy');
            noisyCanvas.addEventListener('click', (e) => {
                const rect = noisyCanvas.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const clickY = e.clientY - rect.top;
                const scale = CV_DIM / rect.width;
                const cx = Math.floor(clickX * scale);
                const cy = Math.floor(clickY * scale);
                inspectPixelAt(cy, cx);
            });

            // Window resize updates
            window.addEventListener('resize', () => {
                if (tripletsFoundList.length > 0) {
                    drawAllTripletsArcsSVG();
                }
            });
        });
    </script>
</body>
</html>
'''

if __name__ == '__main__':
    target = os.path.join(os.path.dirname(__file__), 'index.html')
    print("=================================================================")
    print("NOTICE: 'index.html' is the live, standalone production web application.")
    print("It includes real photographic presets, dynamic convolution demonstrator,")
    print("and smooth CSS physical sliding ring animations.")
    print(f"To run the application, simply open '{target}' in your browser.")
    print("=================================================================")
