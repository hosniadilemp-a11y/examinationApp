# Exercices Algorithmiques Avancés

Ce dossier `Exos/` contient l'ensemble des exercices algorithmiques avec simulations interactives (Matrices 2D & Anneaux, Bio-informatique & Fenêtre Glissante, Traitement d'Image Matriciel & Tri Médian, Recherche Dichotomique).

Tous les fichiers `.algo` ont été compilés, exécutés et certifiés sans aucune erreur sur le compilateur **AlgoCompiler**.

---

## 📂 Contenu du Dossier

| Fichier | Description | Concepts Mobilisés | Validation Compilateur |
| :--- | :--- | :--- | :--- |
| **[`index.html`](index.html)** | **Application Web Interactive Ultra-Moderne** avec navigation élégante sans défilement horizontal (grille responsive 4 onglets), rendu mathématique LaTeX haute précision via **KaTeX**, simulations graphiques réalistes (matrices animées 2D/1D, bio-visualiseur ADN, traitement d'image réel sur Canvas $64 \times 64$, arcs SVG pour triplets), décompositions en pseudo-code par partie et traces de console officielles. | Tous | ✔ Navigateur Moderne (KaTeX CDN + HTML5 Canvas & SVG) |
| **[`01_rotation_anneaux_matrice.algo`](01_rotation_anneaux_matrice.algo)** | Rotation des anneaux concentriques d'une matrice $M \times N$ dans le sens anti-horaire avec optimisation par modulo. | Matrices 2D, Boucles Pour / Tant Que, Modulo | ✔ Exit Code 0 |
| **[`02_adn_equilibre_steady_bear.algo`](02_adn_equilibre_steady_bear.algo)** | Problème bio-informatique "Bear and Steady Gene" résolu par la technique de la fenêtre glissante (*Two Pointers*). | Chaînes, Tableaux 1D, Boucles, Deux Pointeurs | ✔ Exit Code 0 |
| **[`03_filtre_median_debruitage.algo`](03_filtre_median_debruitage.algo)** | Filtre spatial non linéaire pour éliminer le bruit poivre et sel (0 et 255) sur une image matricielle avec voisinage $3 \times 3$ et tri à bulles. | Matrices 2D, Tableaux 1D, Tri à Bulles | ✔ Exit Code 0 |
| **[`04_triplets_magnifiques.algo`](04_triplets_magnifiques.algo)** | Dénombrement et affichage des triplets magnifiques $(i, j, k)$ tels que $A[j]-A[i]=d$ et $A[k]-A[j]=d$ par recherche dichotomique en $O(N \log N)$. | Tableaux 1D, Recherche Dichotomique | ✔ Exit Code 0 |

---

## 🚀 Comment Lancer et Vérifier

### 1. Ouvrir l'Application Web Interactive
Ouvrez simplement le fichier `Exos/index.html` dans votre navigateur Web moderne (Chrome, Edge, Firefox, Safari).
- **Design UI/UX Moderne** : Palette sombre de prestige, typographies soignées (*Plus Jakarta Sans* & *JetBrains Mono*), cartes en verre dépoli (*glassmorphism*), badges lumineux et interactions fluides.
- **Rendu Mathématique KaTeX** : Typographie LaTeX mathématique impeccable ($...$ et $$...$$).
- **Navigation Propre & Non-Scroller** : Grille responsive 4 colonnes sans aucune barre de défilement horizontal parasite.
- **Simulations Visuelles Réalistes** :
  - **Rotation de matrice** : Visualisation 2D dynamique avec anneaux concentriques colorés, ruban 1D déroulé, indicateurs de flux anti-horaire, sélecteur de dimension ($4 \times 4$, $5 \times 5$, $6 \times 4$) et contrôle de vitesse.
  - **Steady Bear DNA** : Chaîne nucléotidique avec cartes chimiques (A, C, G, T), jauges de fréquence dynamique en temps réel avec seuil $N/4$, surlignage de la fenêtre active $[L, R]$, détection de validité et calcul de la sous-chaîne optimale.
  - **Filtre Médian** : Traitement d'image réel sur 3 éléments Canvas HTML5 ($64 \times 64$ pixels) avec scène géométrique contrastée, injection de bruit poivre & sel réglable (5% à 25%), balayage animé pixel par pixel, loupe d'inspection $3 \times 3$ et pipeline de tri à bulles mettant en évidence l'élimination des extrêmes 0 et 255.
  - **Triplets Magnifiques** : Arène visuelle avec arcs SVG courbés reliant les triplets $(A[i] \to A[j] \to A[k])$ avec étiquettes $+d$, animation de la recherche dichotomique et sélection interactive des triplets trouvés.

### 2. Compiler et Exécuter les Fichiers `.algo` via AlgoCompiler
Depuis le répertoire `AlgoCompiler`, exécutez la commande :

```bash
python tests/test_and_run_algo.py ../Exos/01_rotation_anneaux_matrice.algo
python tests/test_and_run_algo.py ../Exos/02_adn_equilibre_steady_bear.algo
python tests/test_and_run_algo.py ../Exos/03_filtre_median_debruitage.algo
python tests/test_and_run_algo.py ../Exos/04_triplets_magnifiques.algo
```

Ou pour valider la compilation CLI standard :
```bash
python tests/compile_cli.py ../Exos/01_rotation_anneaux_matrice.algo
python tests/compile_cli.py ../Exos/02_adn_equilibre_steady_bear.algo
python tests/compile_cli.py ../Exos/03_filtre_median_debruitage.algo
python tests/compile_cli.py ../Exos/04_triplets_magnifiques.algo
```
