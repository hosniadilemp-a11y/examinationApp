#!/bin/bash
set -e

echo "====================================================="
echo "   AlgoExamination — Exportation Package Docker USB  "
echo "====================================================="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="$SCRIPT_DIR/usb_package"

mkdir -p "$OUTPUT_DIR/windows" "$OUTPUT_DIR/linux"
mkdir -p "$SCRIPT_DIR/deployment/windows" "$SCRIPT_DIR/deployment/linux"

echo "1. Construction de l'image Docker multi-stage..."
docker build -t algoexamination:latest -f "$SCRIPT_DIR/deployment/docker-build/Dockerfile" "$SCRIPT_DIR"

echo "2. Téléchargement de l'image PostgreSQL 16..."
docker pull postgres:16-alpine

echo "3. Exportation et compression de l'archive des images Docker..."
TEMP_TAR="$SCRIPT_DIR/algoexam_images.tar.gz"
docker save algoexamination:latest postgres:16-alpine | gzip > "$TEMP_TAR"

echo "4. Préparation du dossier Windows (usb_package/windows)..."
cp -r "$SCRIPT_DIR/deployment/windows/"* "$OUTPUT_DIR/windows/"
cp "$TEMP_TAR" "$OUTPUT_DIR/windows/"
cp "$TEMP_TAR" "$SCRIPT_DIR/deployment/windows/"

echo "5. Préparation du dossier Linux (usb_package/linux)..."
cp -r "$SCRIPT_DIR/deployment/linux/"* "$OUTPUT_DIR/linux/"
cp "$TEMP_TAR" "$OUTPUT_DIR/linux/"
cp "$TEMP_TAR" "$SCRIPT_DIR/deployment/linux/"
chmod +x "$OUTPUT_DIR/linux/"*.sh "$SCRIPT_DIR/deployment/linux/"*.sh 2>/dev/null || true

# Nettoyage archive temporaire
rm -f "$TEMP_TAR"

# Restaurer les permissions pour l'utilisateur normal (éviter que root bloque le copier-coller)
if [ -n "$SUDO_USER" ]; then
    chown -R "$SUDO_USER:$SUDO_USER" "$OUTPUT_DIR" "$SCRIPT_DIR/deployment"
else
    chown -R $(id -u):$(id -g) "$OUTPUT_DIR" "$SCRIPT_DIR/deployment" 2>/dev/null || true
fi

echo ""
echo "====================================================="
echo "✔ TOUT EST PRÊT DANS LE DOSSIER : usb_package/"
echo ""
echo "📁 Structure générée :"
echo "   ├── usb_package/windows/  <-- À copier sur clé USB pour enseignant sous Windows"
echo "   └── usb_package/linux/    <-- À copier sur clé USB pour enseignant sous Linux"
echo "====================================================="
