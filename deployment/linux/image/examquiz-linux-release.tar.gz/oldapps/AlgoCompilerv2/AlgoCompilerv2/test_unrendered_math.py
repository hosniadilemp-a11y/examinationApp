import re

with open('Exos/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

body = html.split('<script>')[0]

# remove code blocks and pre blocks
body_clean = re.sub(r'<pre>.*?</pre>', '', body, flags=re.DOTALL)
body_clean = re.sub(r'<code>.*?</code>', '', body_clean, flags=re.DOTALL)
body_clean = re.sub(r'<svg.*?</svg>', '', body_clean, flags=re.DOTALL)

# Find any occurrences of O( or \mathcal outside of $...$
# remove all $...$ and $$...$$
no_math = re.sub(r'\$\$.*?\$\$', 'MATH_BLOCK', body_clean, flags=re.DOTALL)
no_math = re.sub(r'\$.*?\$', 'MATH_INLINE', no_math)

# Look for mathematical patterns that might be unrendered
patterns = [
    r'\bO\(.+?\)',
    r'\b\d+\s*[\u00d7x]\s*\d+\b',
    r'\bN\s*/\s*4\b',
    r'\\frac',
    r'\\mathcal',
    r'\\times',
    r'\\pmod',
    r'\\in',
    r'\\le',
    r'\\ge'
]

print("--- UNRENDERED MATH CANDIDATES ---")
for p in patterns:
    matches = list(re.finditer(p, no_math))
    if matches:
        print(f"Pattern '{p}': {len(matches)} matches")
        for m in matches[:5]:
            # find surrounding text
            start = max(0, m.start() - 30)
            end = min(len(no_math), m.end() + 30)
            snippet = no_math[start:end].replace('\n', ' ')
            print(f"   Snippet: ...{snippet}...")
