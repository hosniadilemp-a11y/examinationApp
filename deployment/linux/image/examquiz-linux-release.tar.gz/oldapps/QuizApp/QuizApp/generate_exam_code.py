#!/usr/bin/env python3
"""
Admin tool: generate an exam code for distribution.

Usage:
  python generate_exam_code.py --topics 1111100100 --duration 60
  python generate_exam_code.py --topics 1111100100 --duration 60 --date 04-05-2026
  python generate_exam_code.py --list-topics
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from core.exam_code import TOPIC_ORDER, generate_exam_code, decode_exam_code


def main():
    parser = argparse.ArgumentParser(description="Generate a SecureQuizMaster exam code.")
    parser.add_argument("--topics", type=str, help="10-bit string (1=include, 0=exclude) in TOPIC_ORDER")
    parser.add_argument("--duration", type=int, default=60, help="Exam duration in minutes (default: 60)")
    parser.add_argument("--date", type=str, default=None, help="Date DD-MM-YYYY (default: today)")
    parser.add_argument("--list-topics", action="store_true", help="Print canonical topic list and exit")
    args = parser.parse_args()

    if args.list_topics:
        print("Canonical topic order:")
        for i, t in enumerate(TOPIC_ORDER):
            print(f"  [{i}] {t}")
        return

    if not args.topics:
        parser.error("--topics is required (e.g. --topics 1111100100)")

    if len(args.topics) != len(TOPIC_ORDER):
        parser.error(f"--topics must be exactly {len(TOPIC_ORDER)} chars, got {len(args.topics)}")

    if not all(c in "01" for c in args.topics):
        parser.error("--topics must only contain 0 and 1")

    topics_mask = [c == "1" for c in args.topics]
    code = generate_exam_code(topics_mask, args.duration, args.date)

    print("\n=== EXAM CODE GENERATED ===")
    print(f"Code        : {code}")
    print(f"Duration    : {args.duration} min")
    print(f"Date seed   : {args.date or 'today'}")
    print(f"\nIncluded topics:")
    for topic, included in zip(TOPIC_ORDER, topics_mask):
        mark = "✅" if included else "  "
        print(f"  {mark} {topic}")

    print("\n=== VERIFICATION (decode) ===")
    decoded = decode_exam_code(code, args.date)
    if decoded["valid"]:
        print(f"Exam ID     : {decoded['exam_id']}")
        print(f"Duration    : {decoded['duration']} min")
        print(f"Topics      : {', '.join(decoded['topics'])}")
    else:
        print(f"ERROR: {decoded['error']}")


if __name__ == "__main__":
    main()
