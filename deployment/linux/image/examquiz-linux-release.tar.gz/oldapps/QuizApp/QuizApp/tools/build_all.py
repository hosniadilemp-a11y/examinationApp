import PyInstaller.__main__
import os
import sys
import platform

def build():
    # Detect platform
    current_os = platform.system().lower()
    print(f"Building for {current_os}...")

    # Define base name
    app_name = "SecureQuizMaster"
    
    # Base arguments
    args = [
        'src/main.py',
        '--onefile',
        '--windowed',
        f'--name={app_name}',
        '--add-data=src/data:data' if current_os != 'windows' else '--add-data=src/data;data',
        '--add-data=src/core:core' if current_os != 'windows' else '--add-data=src/core;core',
        '--add-data=src/gui:gui' if current_os != 'windows' else '--add-data=src/gui;gui',
        '--add-data=src/utils:utils' if current_os != 'windows' else '--add-data=src/utils;utils',
        '--add-data=assets:assets' if current_os != 'windows' else '--add-data=assets;assets',
        '--hidden-import=PyQt6.sip',
        '--hidden-import=cryptography',
        '--hidden-import=reportlab',
        '--clean',
    ]

    # Platform-specific adjustments
    if current_os == 'windows':
        if os.path.exists('assets/icon.ico'):
            args.append('--icon=assets/icon.ico')
    elif current_os == 'darwin':  # macOS
        if os.path.exists('assets/icon.png'):
            args.append('--icon=assets/icon.png')
            
    print(f"Running PyInstaller with: {' '.join(args)}")
    PyInstaller.__main__.run(args)

if __name__ == "__main__":
    # Ensure dependencies are installed
    try:
        import PyQt6
        import cryptography
        import reportlab
        import PyInstaller
    except ImportError as e:
        print(f"Error: Missing dependency: {e}")
        print("Please run: pip install -r requirements.txt pyinstaller")
        sys.exit(1)
        
    build()
