import json
import os

qs = []
current_id = 4000

def add_q(topic, diff, is_exam, title, desc, start, pin, pout, hin, hout):
    global current_id
    qs.append({
        "id": current_id,
        "is_exam": is_exam,
        "type": "coding",
        "topic": topic,
        "difficulty": diff,
        "title": title,
        "description": desc,
        "starter_code": start,
        "function_signature": None,
        "public_tests": [{"input": pin, "output": pout}],
        "hidden_tests": [{"input": hin, "output": hout}],
        "points": 1 if diff == "easy" else (2 if diff == "medium" else (3 if diff == "hard" else 4)),
        "execution_settings": {"language": "python", "timeout_ms": 2000, "memory_limit_mb": 128}
    })
    current_id += 1


# ==========================================
# 1. Python Basics
# ==========================================
# Easy (4)
add_q("Python Basics", "easy", True, "Print Name", "Read a name and print 'Hello <name>'.", "n=input()\n", "Ali", "Hello Ali", "Sara", "Hello Sara")
add_q("Python Basics", "easy", False, "Double Input", "Read an integer and print it doubled.", "x=int(input())\n", "5", "10", "12", "24")
add_q("Python Basics", "easy", False, "String Length", "Read a string and print its length.", "s=input()\n", "abc", "3", "python", "6")
add_q("Python Basics", "easy", False, "Modulus", "Read two integers a and b. Print a % b.", "a, b = map(int, input().split())\n", "10 3", "1", "15 4", "3")
# Medium (3)
add_q("Python Basics", "medium", True, "Swap Variables", "Read x and y, swap their values and print them space separated.", "x, y = input().split()\n", "1 2", "2 1", "A B", "B A")
add_q("Python Basics", "medium", False, "Substring Count", "Read string s and target t. Count occurrences of t in s.", "s, t = input().split()\n", "banana a", "3", "apple p", "2")
add_q("Python Basics", "medium", False, "Floor Division", "Read a and b. Print a // b.", "a, b = map(int, input().split())\n", "10 3", "3", "20 6", "3")
# Hard (2)
add_q("Python Basics", "hard", True, "Reverse String", "Read a string and print it reversed.", "s = input()\n", "hello", "olleh", "racecar", "racecar")
add_q("Python Basics", "hard", False, "Palindrome Check", "Print True if the input string is a palindrome.", "s = input()\n", "madam", "True", "hello", "False")
# Very Hard (2)
add_q("Python Basics", "very hard", True, "Anagram Check", "Read two strings, print True if they are anagrams.", "a, b = input().split()\n", "listen silent", "True", "hello world", "False")
add_q("Python Basics", "very hard", False, "Recursive Factorial", "Write a recursive factorial and print fact(n).", "n = int(input())\n", "5", "120", "4", "24")

# ==========================================
# 2. Python Data Types
# ==========================================
# Easy (4)
add_q("Python Data Types", "easy", True, "List First Element", "Read space separated integers and print the first one.", "lst = input().split()\n", "1 2 3", "1", "9 8 7", "9")
add_q("Python Data Types", "easy", False, "List Last Element", "Read space separated integers and print the last one.", "lst = input().split()\n", "1 2 3", "3", "4 5", "5")
add_q("Python Data Types", "easy", False, "List Append", "Read n, append it to [1,2,3] and print the list.", "n = int(input())\n", "4", "[1, 2, 3, 4]", "0", "[1, 2, 3, 0]")
add_q("Python Data Types", "easy", False, "Dict Value", "A dict is {'a':1, 'b':2}. Read a key and print its value. Keys are guaranteed.", "k = input().strip()\nd={'a':1,'b':2}\n", "a", "1", "b", "2")
# Medium (3)
add_q("Python Data Types", "medium", True, "Unique Elements", "Read integers, print a sorted list of unique elements.", "lst = list(map(int, input().split()))\n", "1 2 2 3", "[1, 2, 3]", "4 4 1", "[1, 4]")
add_q("Python Data Types", "medium", False, "Tuple Conversion", "Read integers, convert to a tuple and print it.", "lst = list(map(int, input().split()))\n", "1 2", "(1, 2)", "5 5", "(5, 5)")
add_q("Python Data Types", "medium", False, "Dict Keys", "Read space separated strings, create a dict with them as keys (val=1). Print list of keys sorted.", "keys = input().split()\n", "b a c", "['a', 'b', 'c']", "z x", "['x', 'z']")
# Hard (2)
add_q("Python Data Types", "hard", True, "Dictionary Merge", "Read two comma separated lists. Make dict mapping list1 to list2. Print the dict.", "l1 = input().split(',')\nl2 = input().split(',')\n", "A,B\n1,2", "{'A': '1', 'B': '2'}", "X\n9", "{'X': '9'}")
add_q("Python Data Types", "hard", False, "List Flatten", "Assume input is '1,2 3,4'. Split by space then comma. Flatten and print as list.", "s = input().split()\n", "1,2 3,4", "['1', '2', '3', '4']", "a b,c", "['a', 'b', 'c']")
# Very Hard (2)
add_q("Python Data Types", "very hard", True, "Nested Dictionary", "Read k1, k2, val. Create dict d[k1][k2] = val. Print d.", "k1, k2, v = input().split()\n", "A B 1", "{'A': {'B': '1'}}", "x y z", "{'x': {'y': 'z'}}")
add_q("Python Data Types", "very hard", False, "Sort by frequency", "Read integers, print them sorted by frequency descending.", "lst = list(map(int, input().split()))\n", "1 1 2", "[1, 1, 2]", "3 3 3 1", "[3, 3, 3, 1]")

# ==========================================
# 3. Control Flow
# ==========================================
# Easy (4)
add_q("Control Flow", "easy", True, "Max of Two", "Read two ints, print the larger.", "a, b = map(int, input().split())\n", "5 10", "10", "8 2", "8")
add_q("Control Flow", "easy", False, "Sign Check", "Print 'Positive', 'Negative' or 'Zero'.", "n = int(input())\n", "5", "Positive", "-1", "Negative")
add_q("Control Flow", "easy", False, "Is Even", "Print 'Even' if number is even, else 'Odd'.", "n = int(input())\n", "4", "Even", "7", "Odd")
add_q("Control Flow", "easy", False, "Pass Fail", "Print 'Pass' if grade >= 50 else 'Fail'.", "g = int(input())\n", "60", "Pass", "40", "Fail")
# Medium (3)
add_q("Control Flow", "medium", True, "FizzBuzz", "Read n, print Fizz if div by 3, Buzz if div by 5, FizzBuzz if both, else n.", "n = int(input())\n", "15", "FizzBuzz", "3", "Fizz")
add_q("Control Flow", "medium", False, "Vowel Consonant", "Read a char. Print 'Vowel' or 'Consonant'.", "c = input().strip()\n", "a", "Vowel", "b", "Consonant")
add_q("Control Flow", "medium", False, "Leap Year", "Print True if leap year else False.", "y = int(input())\n", "2000", "True", "1900", "False")
# Hard (2)
add_q("Control Flow", "hard", True, "Prime Check", "Print True if n is prime, else False.", "n = int(input())\n", "7", "True", "4", "False")
add_q("Control Flow", "hard", False, "Fibonacci Nth", "Print the Nth Fibonacci number (1-indexed).", "n = int(input())\n", "5", "5", "1", "1")
# Very Hard (2)
add_q("Control Flow", "very hard", True, "Number to Words", "Read int (0-9). Print it in English (e.g., 'Zero').", "n = int(input())\n", "5", "Five", "0", "Zero")
add_q("Control Flow", "very hard", False, "Collatz Steps", "Print number of steps to reach 1 for Collatz sequence of n.", "n = int(input())\n", "6", "8", "1", "0")

# ==========================================
# 4. List Comprehension
# ==========================================
# Easy (4)
add_q("List Comprehension", "easy", True, "Evens Only", "Read integers. Use list comprehension to get only evens. Print the list.", "lst = list(map(int, input().split()))\n", "1 2 3 4", "[2, 4]", "5 7", "[]")
add_q("List Comprehension", "easy", False, "Squares", "Read n. Print list of squares from 0 to n-1.", "n = int(input())\n", "3", "[0, 1, 4]", "1", "[0]")
add_q("List Comprehension", "easy", False, "Lengths", "Read words. Print list of their lengths.", "words = input().split()\n", "a bb ccc", "[1, 2, 3]", "hello", "[5]")
add_q("List Comprehension", "easy", False, "Upper Case", "Read words. Print list of them in uppercase.", "words = input().split()\n", "a b c", "['A', 'B', 'C']", "hi", "['HI']")
# Medium (3)
add_q("List Comprehension", "medium", True, "Filter by length", "Read words. Keep only words with length >= 3.", "w = input().split()\n", "a bb ccc dddd", "['ccc', 'dddd']", "a b c", "[]")
add_q("List Comprehension", "medium", False, "Divisible by 3", "Read integers. Keep those divisible by 3.", "lst = list(map(int, input().split()))\n", "1 3 6 8", "[3, 6]", "9 10", "[9]")
add_q("List Comprehension", "medium", False, "Positive Only", "Read integers. Print positive ones.", "lst = list(map(int, input().split()))\n", "-1 2 -3 4", "[2, 4]", "0 1", "[1]")
# Hard (2)
add_q("List Comprehension", "hard", True, "Nested Comprehension", "Generate a 2x2 matrix of zeros using list comprehension. Print it.", "n = 2\n", "2", "[[0, 0], [0, 0]]", "2", "[[0, 0], [0, 0]]")
add_q("List Comprehension", "hard", False, "If Else in Comp", "Read ints. If even replace with 1, if odd with 0.", "lst = list(map(int, input().split()))\n", "2 3 4", "[1, 0, 1]", "1 1", "[0, 0]")
# Very Hard (2)
add_q("List Comprehension", "very hard", True, "Flatten Matrix", "Flatten [[1,2], [3,4]] to 1D using list comprehension. (Assume fixed matrix in input).", "matrix = [[1, 2], [3, 4]]\n", "go", "[1, 2, 3, 4]", "go", "[1, 2, 3, 4]")
add_q("List Comprehension", "very hard", False, "Dict Comprehension", "Read words. Create dict mapping word to its length. Print dict.", "words = input().split()\n", "a bb", "{'a': 1, 'bb': 2}", "x", "{'x': 1}")

# ==========================================
# 5. Modules de Base
# ==========================================
# Easy (4)
add_q("Modules de Base", "easy", True, "Math Pi", "Import math, print round(math.pi, 2).", "import math\n", "x", "3.14", "x", "3.14")
add_q("Modules de Base", "easy", False, "Math Sqrt", "Read n, print math.sqrt(n) rounded to 1 decimal.", "import math\nn=int(input())\n", "16", "4.0", "2", "1.4")
add_q("Modules de Base", "easy", False, "Math Ceil", "Read float, print math.ceil.", "import math\nn=float(input())\n", "3.2", "4", "5.9", "6")
add_q("Modules de Base", "easy", False, "Math Floor", "Read float, print math.floor.", "import math\nn=float(input())\n", "3.8", "3", "2.1", "2")
# Medium (3)
add_q("Modules de Base", "medium", True, "Random Choice Mock", "Since random is blocked or unpredictable, write a function that returns the first element as a 'mock' random choice.", "def mock_choice(lst): return lst[0]\nlst = input().split()\n", "A B C", "A", "Z X", "Z")
add_q("Modules de Base", "medium", False, "Math Pow", "Read x, y. Print math.pow(x,y).", "import math\nx,y=map(int, input().split())\n", "2 3", "8.0", "5 2", "25.0")
add_q("Modules de Base", "medium", False, "Math Factorial", "Read n. Print math.factorial(n).", "import math\nn=int(input())\n", "5", "120", "3", "6")
# Hard (2)
add_q("Modules de Base", "hard", True, "Math Log", "Read n. Print math.log10(n) rounded to 1 decimal.", "import math\nn=int(input())\n", "100", "2.0", "10", "1.0")
add_q("Modules de Base", "hard", False, "Datetime Mock", "Print the string '2025-01-01' as a mock for today's date.", "print('2025-01-01')\n", "x", "2025-01-01", "y", "2025-01-01")
# Very Hard (2)
add_q("Modules de Base", "very hard", True, "Math GCD", "Read a, b. Print math.gcd(a,b).", "import math\na,b=map(int, input().split())\n", "10 15", "5", "14 21", "7")
add_q("Modules de Base", "very hard", False, "Math Radians", "Read degrees. Print math.radians(d) rounded to 2 decimals.", "import math\nd=int(input())\n", "180", "3.14", "90", "1.57")

# ==========================================
# 6. I/O
# ==========================================
# Easy (4)
add_q("I/O", "easy", True, "Format String", "Read name, print f'Name: {name}'.", "name=input()\n", "Ali", "Name: Ali", "Bob", "Name: Bob")
add_q("I/O", "easy", False, "CSV Read Line", "Read 'a,b,c', print split by comma.", "s=input()\n", "a,b,c", "['a', 'b', 'c']", "1,2", "['1', '2']")
add_q("I/O", "easy", False, "Space Pad", "Read string, print it right justified to 10 chars.", "s=input()\n", "test", "      test", "a", "         a")
add_q("I/O", "easy", False, "Zero Pad", "Read integer, print it zero padded to 5 chars.", "n=input()\n", "42", "00042", "7", "00007")
# Medium (3)
add_q("I/O", "medium", True, "Multiline Input", "Read 2 lines, print them concatenated with space.", "l1=input()\nl2=input()\n", "hello\nworld", "hello world", "a\nb", "a b")
add_q("I/O", "medium", False, "Float format", "Read float, print with 3 decimal places.", "f=float(input())\n", "3.1", "3.100", "5.1234", "5.123")
add_q("I/O", "medium", False, "List to CSV", "Read ints, join them with comma.", "lst=input().split()\n", "1 2 3", "1,2,3", "a b", "a,b")
# Hard (2)
add_q("I/O", "hard", True, "Mock File Read", "Since file I/O is blocked, you get multiline input until 'EOF'. Print number of lines.", "lines = []\nwhile True:\n    try:\n        lines.append(input())\n    except:\n        break\nprint(len(lines))\n", "a\nb\nc", "3", "1\n2", "2")
add_q("I/O", "hard", False, "Percentage Format", "Read a float fraction, print as percentage with 1 decimal (e.g. 0.5 -> 50.0%).", "f=float(input())\n", "0.55", "55.0%", "1.0", "100.0%")
# Very Hard (2)
add_q("I/O", "very hard", True, "Parse Key-Value", "Read 'k1=v1;k2=v2'. Parse into dict and print.", "s=input()\n", "a=1;b=2", "{'a': '1', 'b': '2'}", "x=9", "{'x': '9'}")
add_q("I/O", "very hard", False, "Tabular Output", "Read 2 strings, print them separated by a tab.", "a,b=input().split()\n", "x y", "x\ty", "1 2", "1\t2")

# ==========================================
# 7. OOP
# ==========================================
# Easy (4)
add_q("OOP", "easy", True, "Empty Class", "Define class Person, create instance p, print type(p).__name__.", "class Person: pass\np = Person()\nprint(type(p).__name__)\n", "x", "Person", "y", "Person")
add_q("OOP", "easy", False, "Class Attribute", "Define class Car with attribute wheels=4. Print Car.wheels.", "class Car:\n    wheels=4\nprint(Car.wheels)\n", "x", "4", "y", "4")
add_q("OOP", "easy", False, "Instance Attribute", "Define class Dog with init setting name. Read name, create dog, print dog.name.", "class Dog:\n    def __init__(self, name): self.name = name\nname=input()\n", "Rex", "Rex", "Max", "Max")
add_q("OOP", "easy", False, "Simple Method", "Define Calculator with method add(a,b). Print calc.add(2,3).", "class Calculator:\n    def add(self, a, b): return a+b\nprint(Calculator().add(2,3))\n", "x", "5", "y", "5")
# Medium (3)
add_q("OOP", "medium", True, "String Representation", "Define Book with __str__ returning 'Book Title'. Print an instance.", "class Book:\n    def __str__(self): return 'Book Title'\nprint(Book())\n", "x", "Book Title", "y", "Book Title")
add_q("OOP", "medium", False, "Inheritance", "Define Animal, then Dog inheriting Animal. Print issubclass(Dog, Animal).", "class Animal: pass\nclass Dog(Animal): pass\nprint(issubclass(Dog, Animal))\n", "x", "True", "y", "True")
add_q("OOP", "medium", False, "Encapsulation Mock", "Define class Bank with _balance. Create obj, set to 100, print _balance.", "class Bank:\n    def __init__(self): self._balance = 100\nprint(Bank()._balance)\n", "x", "100", "y", "100")
# Hard (2)
add_q("OOP", "hard", True, "Polymorphism", "Define Bird.fly() returning 'flap' and Plane.fly() returning 'zoom'. Print both.", "class Bird:\n    def fly(self): return 'flap'\nclass Plane:\n    def fly(self): return 'zoom'\nprint(Bird().fly(), Plane().fly())\n", "x", "flap zoom", "y", "flap zoom")
add_q("OOP", "hard", False, "Class Method", "Define MathUtils with @classmethod get_pi() returning 3.14. Print MathUtils.get_pi().", "class MathUtils:\n    @classmethod\n    def get_pi(cls): return 3.14\nprint(MathUtils.get_pi())\n", "x", "3.14", "y", "3.14")
# Very Hard (2)
add_q("OOP", "very hard", True, "Property Decorator", "Define Circle with property area returning 10. Print Circle().area.", "class Circle:\n    @property\n    def area(self): return 10\nprint(Circle().area)\n", "x", "10", "y", "10")
add_q("OOP", "very hard", False, "Dunder Add", "Define Point with __add__ for coordinates. Point(1,1) + Point(2,2). Print x and y of result.", "class Point:\n    def __init__(self,x,y): self.x=x; self.y=y\n    def __add__(self, o): return Point(self.x+o.x, self.y+o.y)\np = Point(1,1) + Point(2,2)\nprint(p.x, p.y)\n", "x", "3 3", "y", "3 3")

# ==========================================
# 8. Numpy
# ==========================================
# Note: since imports are blocked in the execution sandbox by default, we will mock numpy using lists 
# or use builtins to simulate matrix/array operations as asked in tutorials. 
# Easy (4)
add_q("numpy", "easy", True, "Array Creation Mock", "Create a 1D list representing a numpy array from input and print it.", "arr = list(map(int, input().split()))\nprint(arr)\n", "1 2 3", "[1, 2, 3]", "0 0", "[0, 0]")
add_q("numpy", "easy", False, "Zeros Array Mock", "Print a list of n zeros.", "n = int(input())\nprint([0]*n)\n", "3", "[0, 0, 0]", "2", "[0, 0]")
add_q("numpy", "easy", False, "Ones Array Mock", "Print a list of n ones.", "n = int(input())\nprint([1]*n)\n", "2", "[1, 1]", "4", "[1, 1, 1, 1]")
add_q("numpy", "easy", False, "Array Shape Mock", "Read n elements, then output shape as a tuple (n,).", "lst = input().split()\nprint((len(lst),))\n", "1 2 3", "(3,)", "a b", "(2,)")
# Medium (3)
add_q("numpy", "medium", True, "Elementwise Add", "Read two same-length lists, print element-wise sum.", "a = list(map(int, input().split()))\nb = list(map(int, input().split()))\nres = [x+y for x,y in zip(a,b)]\nprint(res)\n", "1 2\n3 4", "[4, 6]", "0\n0", "[0]")
add_q("numpy", "medium", False, "Scalar Multiply", "Read scalar k and array. Print array multiplied by k.", "k = int(input())\narr = list(map(int, input().split()))\nprint([x*k for x in arr])\n", "2\n1 2 3", "[2, 4, 6]", "10\n1 0", "[10, 0]")
add_q("numpy", "medium", False, "Dot Product Mock", "Read two 1D arrays. Print their dot product.", "a = list(map(int, input().split()))\nb = list(map(int, input().split()))\nprint(sum(x*y for x,y in zip(a,b)))\n", "1 2\n3 4", "11", "2 0\n0 2", "0")
# Hard (2)
add_q("numpy", "hard", True, "Matrix Transpose Mock", "Read 2x2 matrix (4 numbers). Print transposed as nested lists.", "arr = list(map(int, input().split()))\nmat = [[arr[0], arr[1]], [arr[2], arr[3]]]\nprint([[mat[0][0], mat[1][0]], [mat[0][1], mat[1][1]]])\n", "1 2 3 4", "[[1, 3], [2, 4]]", "0 1 2 3", "[[0, 2], [1, 3]]")
add_q("numpy", "hard", False, "Boolean Indexing", "Read array, print elements > 5.", "arr = list(map(int, input().split()))\nprint([x for x in arr if x > 5])\n", "3 6 2 8", "[6, 8]", "1 2 3", "[]")
# Very Hard (2)
add_q("numpy", "very hard", True, "Mean and Std Mock", "Calculate mean of list. (Skip std to avoid math import dependency).", "arr = list(map(int, input().split()))\nprint(sum(arr)/len(arr))\n", "2 4 6", "4.0", "10 20", "15.0")
add_q("numpy", "very hard", False, "Broadcasting Mock", "Add a scalar to a 2x2 matrix mock. Read 4 ints then a scalar.", "a=list(map(int,input().split()))\nk=int(input())\nprint([[a[0]+k, a[1]+k], [a[2]+k, a[3]+k]])\n", "1 2 3 4\n10", "[[11, 12], [13, 14]]", "0 0 0 0\n1", "[[1, 1], [1, 1]]")

# ==========================================
# 9. pandas
# ==========================================
# Note: since pandas is blocked, we mock dataframes with lists of dictionaries or lists of lists.
# Easy (4)
add_q("pandas", "easy", True, "Create Series Mock", "Create a dictionary mimicking a Series from space separated values (indices 0, 1...). Print it.", "v = input().split()\nprint({i: x for i, x in enumerate(v)})\n", "a b", "{0: 'a', 1: 'b'}", "x", "{0: 'x'}")
add_q("pandas", "easy", False, "DataFrame Head", "Print first 2 elements of a list simulating df.head(2).", "lst = input().split()\nprint(lst[:2])\n", "1 2 3 4", "['1', '2']", "A B", "['A', 'B']")
add_q("pandas", "easy", False, "DataFrame Tail", "Print last element simulating df.tail(1).", "lst = input().split()\nprint(lst[-1:])\n", "1 2 3", "['3']", "x", "['x']")
add_q("pandas", "easy", False, "Column Select", "Mock df['col']. Input is values. Print them.", "lst = input().split()\nprint(lst)\n", "a b", "['a', 'b']", "1", "['1']")
# Medium (3)
add_q("pandas", "medium", True, "Filter Rows Mock", "Given ages, print those >= 18.", "ages = list(map(int, input().split()))\nprint([a for a in ages if a >= 18])\n", "12 18 20", "[18, 20]", "10 15", "[]")
add_q("pandas", "medium", False, "Value Counts Mock", "Print dict of counts of items.", "lst = input().split()\ncounts = {}\nfor x in lst: counts[x] = counts.get(x,0)+1\nprint(counts)\n", "a a b", "{'a': 2, 'b': 1}", "x", "{'x': 1}")
add_q("pandas", "medium", False, "Fill NA Mock", "Replace 'NA' strings with '0' in a list.", "lst = input().split()\nprint(['0' if x=='NA' else x for x in lst])\n", "1 NA 3", "['1', '0', '3']", "NA", "['0']")
# Hard (2)
add_q("pandas", "hard", True, "Groupby Sum Mock", "Read 'key val' pairs. Print aggregated sum per key.", "n = int(input())\nd = {}\nfor _ in range(n):\n    k, v = input().split()\n    d[k] = d.get(k,0) + int(v)\nprint(d)\n", "3\na 10\nb 5\na 2", "{'a': 12, 'b': 5}", "1\nx 1", "{'x': 1}")
add_q("pandas", "hard", False, "Apply Function Mock", "Apply x*2 to all integers in list.", "lst = list(map(int, input().split()))\nprint([x*2 for x in lst])\n", "1 2", "[2, 4]", "0", "[0]")
# Very Hard (2)
add_q("pandas", "very hard", True, "Merge DataFrames Mock", "Join two dicts on matching keys.", "d1 = {'id': 1, 'name': 'A'}\nd2 = {'id': 1, 'age': 20}\nres = {**d1, **d2}\nprint(res)\n", "x", "{'id': 1, 'name': 'A', 'age': 20}", "y", "{'id': 1, 'name': 'A', 'age': 20}")
add_q("pandas", "very hard", False, "Pivot Table Mock", "Very simplified pivot. Return unique keys.", "lst = input().split()\nprint(sorted(list(set(lst))))\n", "b a a b c", "['a', 'b', 'c']", "z y", "['y', 'z']")

# ==========================================
# 10. Data Visualization
# ==========================================
# Note: Matplotlib cannot run in sandbox. We mock with ASCII visualizations.
# Easy (4)
add_q("Data Visualization", "easy", True, "ASCII Line", "Draw a line of length N using '-' character.", "n = int(input())\nprint('-' * n)\n", "5", "-----", "2", "--")
add_q("Data Visualization", "easy", False, "ASCII Star", "Draw N stars '*'.", "n = int(input())\nprint('*' * n)\n", "3", "***", "1", "*")
add_q("Data Visualization", "easy", False, "Vertical Bar", "Print '|' N times vertically.", "n = int(input())\nfor _ in range(n): print('|')\n", "2", "|\n|", "1", "|")
add_q("Data Visualization", "easy", False, "Point Plot", "Print a dot '.' at specific spaces.", "n = int(input())\nprint(' ' * n + '.')\n", "2", "  .", "0", ".")
# Medium (3)
add_q("Data Visualization", "medium", True, "ASCII Bar Chart", "Read N integers, print a bar of '#' for each.", "vals = list(map(int, input().split()))\nfor v in vals: print('#' * v)\n", "1 3 2", "#\n###\n##", "2 1", "##\n#")
add_q("Data Visualization", "medium", False, "Labeled Bar", "Read a label and a value, print 'label: ###'.", "lbl, val = input().split()\nprint(f'{lbl}: ' + '#' * int(val))\n", "A 3", "A: ###", "B 1", "B: #")
add_q("Data Visualization", "medium", False, "Scatter Mock", "Print coordinates as tuples simulating scatter plot data.", "x = input().split()\ny = input().split()\nprint(list(zip(x,y)))\n", "1 2\n3 4", "[('1', '3'), ('2', '4')]", "0\n0", "[('0', '0')]")
# Hard (2)
add_q("Data Visualization", "hard", True, "Histogram Bins Mock", "Count numbers in bins (0-9, 10-19). Read numbers, print counts.", "vals = list(map(int, input().split()))\nbins = [0, 0]\nfor v in vals:\n    if v < 10: bins[0]+=1\n    else: bins[1]+=1\nprint(bins)\n", "5 15 2 12 19", "[2, 3]", "1 2", "[2, 0]")
add_q("Data Visualization", "hard", False, "Boxplot Stats", "Print min and max of a list simulating boxplot bounds.", "vals = list(map(int, input().split()))\nprint(min(vals), max(vals))\n", "1 5 10 2", "1 10", "5 5", "5 5")
# Very Hard (2)
add_q("Data Visualization", "very hard", True, "Correlation Mock", "Print 1.0 for self correlation. Just print 1.0.", "print(1.0)\n", "x", "1.0", "y", "1.0")
add_q("Data Visualization", "very hard", False, "Heatmap Mock", "Print a 2x2 grid of '#' depending on values > 5.", "vals = list(map(int, input().split()))\nres = ['#' if v>5 else '.' for v in vals]\nprint(f'{res[0]}{res[1]}\\n{res[2]}{res[3]}')\n", "10 2 6 1", "#.\n#.", "0 0 0 0", "..\n..")


# --- Injection Logic ---
filepath = '/home/adel/Documents/Coding and projects/QuizApp/src/data/coding_questions.py'

with open(filepath, 'r') as f:
    text = f.read()

def build_q(q):
    s = "    {\n"
    for k, v in q.items():
        s += f"        {repr(k)}: {repr(v)},\n"
    s += "    },"
    return s

q_strings = "\n".join(build_q(q) for q in qs)

# Insert before the last closing bracket of CODING_QUESTIONS list
# Find the last `]` in the file.
parts = text.rsplit(']', 1)
if len(parts) == 2:
    new_text = parts[0] + ',\n' + q_strings + '\n]' + parts[1]
    with open(filepath, 'w') as f:
        f.write(new_text)
    print(f"Successfully injected {len(qs)} questions.")
else:
    print("Could not find the end of the list in coding_questions.py")
