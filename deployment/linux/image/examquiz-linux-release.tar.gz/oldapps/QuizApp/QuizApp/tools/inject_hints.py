import os
import sys

# Add src to path to allow importing data modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from data.coding_questions import CODING_QUESTIONS

def generate_hints(q):
    title = q['title'].lower()
    desc = q['description'].lower()
    topic = q['topic'].lower()
    start = q.get('starter_code', '')
    
    # Defaults
    h1 = f"Hint 1: Review the concepts for {topic}. Look closely at the input format."
    h2 = f"Hint 2: Try to use basic python built-ins to solve this."
    
    # Hand-crafted heuristics to ensure correct hints for every specific question
    if "zero vector" in title:
        h1 = "Use the `[0] * n` syntax to create a list of zeros."
        h2 = "Read `n = int(input())`, then `print([0] * n)`."
    elif "column total" in title:
        h1 = "Read the values into a list of integers, then use the `sum()` function."
        h2 = "`values = list(map(int, input().split()))` followed by `print(sum(values))`."
    elif "normalize username" in title:
        h1 = "Chain the string methods `.strip()`, `.lower()`, and `.replace(' ', '_')`."
        h2 = "`print(username.strip().lower().replace(' ', '_'))`"
    elif "best two scores" in title:
        h1 = "Sort the list of scores in descending order and sum the first two elements."
        h2 = "`scores.sort(reverse=True)` then `print(scores[0] + scores[1])`."
    elif "valid access code" in title:
        h1 = "Check `len(code) == 6`, `code.startswith('PY')`, and `code[2:].isdigit()`."
        h2 = "Use an if statement with those 3 conditions. If all True, print 'VALID', else 'INVALID'."
    elif "temperature" in title:
        h1 = "Apply the formula F = C * 9 / 5 + 32. Make sure to cast the result to an integer."
        h2 = "`print(int(celsius * 9 / 5 + 32))`"
    elif "unique values" in title:
        h1 = "A Python `set` automatically removes duplicate values."
        h2 = "`print(len(set(values)))`"
    elif "even or odd" in title:
        h1 = "Use the modulo operator `% 2`. If it equals 0, the number is even."
        h2 = "`if n % 2 == 0: print('EVEN') else: print('ODD')`"
    elif "vowel count" in title:
        h1 = "Iterate through the string and check if each character `in 'aeiouAEIOU'`."
        h2 = "`print(sum(1 for c in text if c in 'aeiouAEIOU'))`"
    elif "filter negatives" in title:
        h1 = "Use a list comprehension to keep only numbers `>= 0`."
        h2 = "`print([x for x in values if x >= 0])`"
    elif "sum of digits" in title:
        h1 = "Convert the number to a string to iterate over its characters, convert back to int to sum."
        h2 = "`print(sum(int(d) for d in str(n)))`"
    elif "fibonacci" in title:
        h1 = "Use a loop to keep generating the next number as the sum of the previous two."
        h2 = "`a, b = 0, 1` then loop `n` times doing `a, b = b, a + b`. Return `a`."
    elif "dictionary squares" in title:
        h1 = "Use dictionary comprehension `{x: x*x for x in range(1, n+1)}`."
        h2 = "`print({x: x*x for x in range(1, n+1)})`"
    elif "list intersection" in title:
        h1 = "Convert both lists to sets and use the `&` operator."
        h2 = "`print(sorted(list(set(l1) & set(l2))))`"
    elif "matrix diagonal sum" in title:
        h1 = "The main diagonal consists of elements where the row index equals the column index (`matrix[i][i]`)."
        h2 = "`print(sum(matrix[i][i] for i in range(n)))`"
    elif "echo input" in title:
        h1 = "Use the print() function on the input variable."
        h2 = "`print(x)`"
    elif "add two" in title:
        h1 = "Use the + operator on a and b."
        h2 = "`print(a + b)`"
    elif "subtract" in title:
        h1 = "Use the - operator on a and b."
        h2 = "`print(a - b)`"
    elif "float addition" in title:
        h1 = "Use the + operator. The inputs are already floats."
        h2 = "`print(a + b)`"
    elif "integer division" in title:
        h1 = "Use the // operator for integer division."
        h2 = "`print(a // b)`"
    elif "true float" in title:
        h1 = "Use the / operator for float division."
        h2 = "`print(a / b)`"
    elif "multiplication" in title:
        h1 = "Use the * operator."
        h2 = "`print(a * b)`"
    elif "power operator" in title:
        h1 = "Use the ** operator for exponentiation."
        h2 = "`print(x ** y)`"
    elif "equality" in title:
        h1 = "Use the == operator."
        h2 = "`print(x == y)`"
    elif "inequality" in title:
        h1 = "Use the != operator."
        h2 = "`print(x != y)`"
    elif "greater than" in title:
        h1 = "Use the > operator."
        h2 = "`print(x > y)`"
    elif "less or equal" in title:
        h1 = "Use the <= operator."
        h2 = "`print(x <= y)`"
    elif "logical and" in title:
        h1 = "Use the `and` keyword."
        h2 = "`print(x and y)`"
    elif "logical or" in title:
        h1 = "Use the `or` keyword."
        h2 = "`print(x or y)`"
    elif "logical xor" in title:
        h1 = "Use the `^` operator for XOR."
        h2 = "`print(x ^ y)`"
    elif "swap" in title:
        h1 = "Print them in reverse order using an f-string or comma."
        h2 = "`print(f'{y} {x}')` or `print(y, x)`"
    elif "string plus number" in title:
        h1 = "Convert the number to a string using str() before concatenating."
        h2 = "`print(s + str(n))`"
    elif "basic function" in title:
        h1 = "Define the function f(x) and call it inside print()."
        h2 = "`print(f(x))`"
    elif "basic lambda" in title:
        h1 = "Call the lambda function `f` with `x`."
        h2 = "`print(f(x))`"
    elif "output formatting" in title:
        h1 = "Use an f-string with the `,` format specifier."
        h2 = "`print(f'{x:,}')`"
    elif "check limits" in title:
        h1 = "Chain the comparison `10 <= x <= 20`."
        h2 = "`print(10 <= x <= 20)`"
    elif "polynomial" in title:
        h1 = "Return `x**2 + 2*x + 1`."
        h2 = "`print(f(x))`"
    elif "energy limit" in title:
        h1 = "Return whether `m * h * g > limit`."
        h2 = "Function returns a boolean, so just `print(e_potentielle(m, h, limit))`."
    elif "function composition" in title:
        h1 = "Call the functions nested: `f(g(f(x)))`."
        h2 = "`print(f(g(f(x))))`"
    elif "nand logic" in title:
        h1 = "NAND is `not (x and y)`."
        h2 = "`print(not (x and y))`"
    elif "complex logic" in title:
        h1 = "Translate the description exactly: `(a and b) or (c and d)`."
        h2 = "`print((a and b) or (c and d))`"
    elif "unpack" in title and "*" in title:
        h1 = "Use the `*` operator to unpack the remaining elements."
        h2 = "`a, *b = numbers` then `print(b)`."
    elif "string slicing" in title:
        h1 = "Use list slicing syntax `[:3]` to get the first 3 characters."
        h2 = "`print(s[:3])`"
    elif "default arguments" in title:
        h1 = "Just call the function with m and h, it will use the default g."
        h2 = "`print(e_potentielle(m, h))`"
    elif "print name" in title:
        h1 = "Use an f-string or string concatenation."
        h2 = "`print(f'Hello {n}')`"
    elif "double input" in title:
        h1 = "Multiply the integer by 2."
        h2 = "`print(x * 2)`"
    elif "string length" in title:
        h1 = "Use the built-in `len()` function."
        h2 = "`print(len(s))`"
    elif "modulus" in title:
        h1 = "Use the `%` operator."
        h2 = "`print(a % b)`"
    elif "substring count" in title:
        h1 = "Use the `.count()` string method."
        h2 = "`print(s.count(t))`"
    elif "reverse string" in title:
        h1 = "Use string slicing with a step of -1 `[::-1]`."
        h2 = "`print(s[::-1])`"
    elif "palindrome" in title:
        h1 = "Check if the string equals its reverse `s[::-1]`."
        h2 = "`print(s == s[::-1])`"
    elif "anagram" in title:
        h1 = "Two words are anagrams if their sorted characters are equal."
        h2 = "`print(sorted(a) == sorted(b))`"
    elif "recursive factorial" in title:
        h1 = "Base case `if n==0: return 1`, else `n * fact(n-1)`."
        h2 = "Define the function then `print(fact(n))`."
    elif "list first" in title:
        h1 = "Access the element at index 0."
        h2 = "`print(lst[0])`"
    elif "list last" in title:
        h1 = "Access the element at index -1."
        h2 = "`print(lst[-1])`"
    elif "list append" in title:
        h1 = "Create the list `[1, 2, 3]`, append `n`, and print it."
        h2 = "`l = [1, 2, 3]; l.append(n); print(l)`"
    elif "dict value" in title:
        h1 = "Access the dictionary using the key."
        h2 = "`print(d[k])`"
    elif "unique elements" in title:
        h1 = "Convert the list to a set, then back to a sorted list."
        h2 = "`print(sorted(list(set(lst))))`"
    elif "tuple conversion" in title:
        h1 = "Use the `tuple()` constructor on the list."
        h2 = "`print(tuple(lst))`"
    elif "dict keys" in title:
        h1 = "Use a dictionary comprehension `{k: 1 for k in keys}`."
        h2 = "`print(sorted(list({k:1 for k in keys}.keys())))`"
    elif "dictionary merge" in title:
        h1 = "Use the `dict()` and `zip()` built-ins."
        h2 = "`print(dict(zip(l1, l2)))`"
    elif "list flatten" in title:
        h1 = "Split the string first by space, then by comma."
        h2 = "`print([item for sub in s for item in sub.split(',')])`"
    elif "sort by frequency" in title:
        h1 = "Use `lst.sort(key=lst.count, reverse=True)`."
        h2 = "`lst.sort(key=lst.count, reverse=True); print(lst)`"
    elif "max of two" in title:
        h1 = "Use the `max()` built-in function."
        h2 = "`print(max(a, b))`"
    elif "sign check" in title:
        h1 = "Use an if-elif-else block for >0, <0, ==0."
        h2 = "`if n>0: print('Positive') elif n<0: print('Negative') else: print('Zero')`"
    elif "pass fail" in title:
        h1 = "Check if `g >= 50`."
        h2 = "`print('Pass' if g >= 50 else 'Fail')`"
    elif "fizzbuzz" in title:
        h1 = "Check modulo 15 first, then 3, then 5."
        h2 = "`print('FizzBuzz' if n%15==0 else 'Fizz' if n%3==0 else 'Buzz' if n%5==0 else n)`"
    elif "vowel consonant" in title:
        h1 = "Check if `c.lower() in 'aeiou'`."
        h2 = "`print('Vowel' if c.lower() in 'aeiou' else 'Consonant')`"
    elif "leap year" in title:
        h1 = "Divisible by 4, but not 100, unless divisible by 400."
        h2 = "`print((y % 4 == 0 and y % 100 != 0) or (y % 400 == 0))`"
    elif "prime check" in title:
        h1 = "Iterate from 2 to n-1 to check for divisibility."
        h2 = "`print(n > 1 and all(n % i != 0 for i in range(2, n)))`"
    elif "number to words" in title:
        h1 = "Use a list of strings where the index matches the number."
        h2 = "`words = ['Zero','One','Two','Three','Four','Five','Six','Seven','Eight','Nine']; print(words[n])`"
    elif "evens only" in title:
        h1 = "Use `[x for x in lst if x % 2 == 0]`."
        h2 = "`print([x for x in lst if x % 2 == 0])`"
    elif "squares" in title:
        h1 = "Use `[x**2 for x in range(n)]`."
        h2 = "`print([x**2 for x in range(n)])`"
    elif "lengths" in title:
        h1 = "Use `[len(w) for w in words]`."
        h2 = "`print([len(w) for w in words])`"
    elif "upper case" in title:
        h1 = "Use `[w.upper() for w in words]`."
        h2 = "`print([w.upper() for w in words])`"
    elif "filter by length" in title:
        h1 = "Use `[w for w in w if len(w) >= 3]`."
        h2 = "`print([w for w in w if len(w) >= 3])`"
    elif "divisible by 3" in title:
        h1 = "Use `[x for x in lst if x % 3 == 0]`."
        h2 = "`print([x for x in lst if x % 3 == 0])`"
    elif "positive only" in title:
        h1 = "Use `[x for x in lst if x > 0]`."
        h2 = "`print([x for x in lst if x > 0])`"
    elif "nested comprehension" in title:
        h1 = "Use `[[0 for _ in range(n)] for _ in range(n)]`."
        h2 = "`print([[0 for _ in range(n)] for _ in range(n)])`"
    elif "if else in comp" in title:
        h1 = "Use `[1 if x % 2 == 0 else 0 for x in lst]`."
        h2 = "`print([1 if x % 2 == 0 else 0 for x in lst])`"
    elif "flatten matrix" in title:
        h1 = "Use `[item for row in matrix for item in row]`."
        h2 = "`print([item for row in matrix for item in row])`"
    elif "dict comprehension" in title:
        h1 = "Use `{w: len(w) for w in words}`."
        h2 = "`print({w: len(w) for w in words})`"
    elif "math pi" in title:
        h1 = "Use `math.pi` and `round()`."
        h2 = "`print(round(math.pi, 2))`"
    elif "math sqrt" in title:
        h1 = "Use `math.sqrt()` and `round()`."
        h2 = "`print(round(math.sqrt(n), 1))`"
    elif "format string" in title:
        h1 = "Use an f-string `f'Name: {name}'`."
        h2 = "`print(f'Name: {name}')`"
    elif "space pad" in title:
        h1 = "Use the `.rjust(10)` method."
        h2 = "`print(s.rjust(10))`"
    elif "multiline input" in title:
        h1 = "Concatenate l1 and l2 with a space."
        h2 = "`print(l1 + ' ' + l2)`"
    elif "class attribute" in title:
        h1 = "Define `wheels = 4` directly under the class definition."
        h2 = "`class Car: wheels = 4`"
    elif "instance attribute" in title:
        h1 = "Define `def __init__(self, name): self.name = name`."
        h2 = "See Hint 1."
    elif "simple method" in title:
        h1 = "Define `def add(self, a, b): return a+b`."
        h2 = "See Hint 1."
    elif "string representation" in title:
        h1 = "Define `def __str__(self): return 'Book Title'`."
        h2 = "See Hint 1."
    elif "array creation" in title:
        h1 = "Just print the list representing the array."
        h2 = "`print(arr)`"
    elif "elementwise add" in title:
        h1 = "Use a list comprehension with `zip(a, b)`."
        h2 = "`print([x+y for x, y in zip(a, b)])`"
    elif "scalar multiply" in title:
        h1 = "Use a list comprehension `[x*k for x in arr]`."
        h2 = "`print([x*k for x in arr])`"
    elif "create series mock" in title:
        h1 = "Use `enumerate()` to generate indices for the values."
        h2 = "`print({i: x for i, x in enumerate(v)})`"
    elif "ascii line" in title:
        h1 = "Multiply the character '-' by the length n."
        h2 = "`print('-' * n)`"
    elif "ascii bar chart" in title:
        h1 = "Loop through the values and print '#' multiplied by the value."
        h2 = "`for v in vals: print('#' * v)`"
        
    return h1, h2


# Now inject the hints and rewrite the file
def rewrite_coding_questions():
    filepath = os.path.abspath(os.path.join(os.path.dirname(__file__), '../src/data/coding_questions.py'))
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('"""Prototype coding questions for the coding test window."""\n\n\n')
        f.write('CODING_QUESTIONS = [\n')
        
        for q in CODING_QUESTIONS:
            # Inject hints for non-exam questions
            if not q.get('is_exam', False):
                h1, h2 = generate_hints(q)
                q['hint1'] = h1
                q['hint2'] = h2
                
            f.write('    {\n')
            for k, v in q.items():
                if k in ['public_tests', 'hidden_tests']:
                    f.write(f'        "{k}": [\n')
                    for test in v:
                        f.write(f'            {repr(test)},\n')
                    f.write('        ],\n')
                elif k == 'execution_settings':
                    f.write(f'        "{k}": {repr(v)},\n')
                else:
                    f.write(f'        "{k}": {repr(v)},\n')
            f.write('    },\n')
        
        f.write(']\n')

if __name__ == "__main__":
    rewrite_coding_questions()
    print("Hints successfully injected into src/data/coding_questions.py")
