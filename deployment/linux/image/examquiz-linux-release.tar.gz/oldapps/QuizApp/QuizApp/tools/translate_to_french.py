import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))
from data.coding_questions import CODING_QUESTIONS

# Mapping: id -> (title, description, hint1, hint2)
# All in French, with proper hints as requested.
TRANSLATIONS = {
    1001: ("Créer un vecteur nul", "Lisez un entier n et affichez une liste Python contenant n zéros. N'importez pas NumPy.", "Utilisez la syntaxe `[0] * n` pour créer une liste de zéros.", "Lisez `n = int(input())`, puis `print([0] * n)`."),
    1002: ("Total de la colonne", "Une colonne de données numériques est fournie (n valeurs). Lisez n, puis les valeurs, et affichez leur total.", "Lisez les valeurs dans une liste d'entiers, puis utilisez la fonction `sum()`.", "`values = list(map(int, input().split()))` suivi de `print(sum(values))`."),
    1003: ("Normaliser le nom d'utilisateur", "Lisez un nom d'utilisateur, supprimez les espaces au début et à la fin, convertissez-le en minuscules et remplacez les espaces à l'intérieur par des tirets bas (_).", "Enchaînez les méthodes de chaîne `.strip()`, `.lower()` et `.replace(' ', '_')`.", "`print(username.strip().lower().replace(' ', '_'))`"),
    1004: ("Les deux meilleurs scores", "Lisez n, puis n scores d'examen. Affichez la somme des deux meilleurs scores.", "Triez la liste des scores par ordre décroissant et additionnez les deux premiers.", "`scores.sort(reverse=True)` puis `print(scores[0] + scores[1])`."),
    1005: ("Code d'accès valide", "Lisez un code d'accès. Un code valide a exactement 6 caractères, commence par 'PY', et les 4 derniers caractères sont des chiffres. Affichez VALID ou INVALID.", "Vérifiez `len(code) == 6`, `code.startswith('PY')` et `code[2:].isdigit()`.", "Utilisez un `if` avec ces 3 conditions. Si toutes sont vraies, affichez 'VALID', sinon 'INVALID'."),
    1006: ("Convertisseur de température", "Lisez une température en Celsius (entier) et affichez sa valeur en Fahrenheit avec la formule F = C * 9 / 5 + 32 (entier).", "Appliquez la formule F = C * 9 / 5 + 32 et convertissez le résultat en `int`.", "`print(int(celsius * 9 / 5 + 32))`"),
    1007: ("Compter les valeurs uniques", "Lisez n, puis n entiers. Affichez combien de valeurs distinctes apparaissent.", "En Python, un `set` (ensemble) supprime automatiquement les doublons.", "`print(len(set(values)))`"),
    1008: ("Pair ou Impair", "Lisez un entier et affichez EVEN s'il est pair, sinon ODD.", "Utilisez l'opérateur modulo `% 2`. S'il vaut 0, le nombre est pair.", "`if n % 2 == 0: print('EVEN') else: print('ODD')`"),
    1009: ("Liste des carrés", "Lisez n et affichez une liste contenant les carrés de 1 à n inclus.", "Utilisez la compréhension de liste `[x**2 for x in range(1, n+1)]`.", "`print([x**2 for x in range(1, n+1)])`"),
    1010: ("Total du reçu", "Lisez trois prix entiers (un par ligne) et affichez leur total.", "Lisez les trois entiers un par un avec `int(input())` et additionnez-les.", "Affichez `print(int(input()) + int(input()) + int(input()))`."),
    1011: ("Distance absolue", "Lisez deux entiers a et b. Affichez la distance absolue entre eux.", "Utilisez la fonction intégrée `abs()` sur la différence entre a et b.", "`print(abs(a - b))`"),
    1012: ("Étiquette d'objet", "Lisez un nom de classe et un identifiant. Affichez-les séparés par un '#', ex: Student#12.", "Utilisez une f-string pour formater les deux variables.", "`print(f'{classe}#{identifiant}')`"),
    1013: ("Addition de vecteurs", "Lisez n, puis deux vecteurs entiers de taille n. Affichez la liste de leur somme élément par élément.", "Utilisez une boucle ou une compréhension de liste avec `zip()` pour additionner les éléments.", "`print([x + y for x, y in zip(vec1, vec2)])`"),
    1014: ("Filtrer les réussites", "Lisez n, puis n scores. Affichez une liste contenant uniquement les scores supérieurs ou égaux à 50.", "Utilisez une compréhension de liste avec une condition `if score >= 50`.", "`print([s for s in scores if s >= 50])`"),
    1015: ("Graphique en barres textuel", "Lisez n, puis n entiers positifs. Pour chaque valeur, affichez une ligne contenant ce nombre de symboles '#'.", "Utilisez une boucle for et l'opérateur de multiplication de chaînes `*`.", "`for v in values: print('#' * v)`"),
    1016: ("Note en lettre", "Lisez un score (0-100). Affichez A pour 90+, B pour 80+, C pour 70+, D pour 60+, sinon F.", "Utilisez une structure `if-elif-else` pour vérifier les seuils dans l'ordre décroissant.", "`if s >= 90: print('A') elif s >= 80: print('B') ... else: print('F')`"),
    1017: ("Analyseur de ligne CSV", "Lisez une ligne de noms séparés par des virgules. Affichez chaque nom nettoyé (sans espaces) sur sa propre ligne.", "Utilisez la méthode `.split(',')` puis `.strip()` sur chaque élément.", "`for name in line.split(','): print(name.strip())`"),
    1018: ("Mise à jour du solde bancaire", "Lisez un solde initial et n opérations ('deposit X' ou 'withdraw X'). Affichez le solde final.", "Dans une boucle, vérifiez si l'opération commence par 'deposit' (ajouter) ou 'withdraw' (soustraire).", "Si l'op a 'deposit', `solde += X`, sinon `solde -= X`."),
    1019: ("Moyenne arrondie", "Lisez n, puis n entiers. Affichez la moyenne arrondie à 2 décimales.", "Calculez la somme, divisez par n, et utilisez `round(val, 2)` ou formatage.", "`print(f'{sum(values) / n:.2f}')`"),
    1020: ("Force du mot de passe", "Lisez un mot de passe. Affichez STRONG s'il fait au moins 8 caractères et contient un chiffre, sinon WEAK.", "Vérifiez `len(pwd) >= 8` et utilisez `any(c.isdigit() for c in pwd)`.", "`if len(pwd) >= 8 and any(c.isdigit() for c in pwd): print('STRONG') else: print('WEAK')`"),
    1021: ("Filtrer les mots longs", "Lisez une phrase et affichez une liste des mots dont la longueur est au moins 5.", "Utilisez `.split()` puis une compréhension de liste avec `len(mot) >= 5`.", "`print([word for word in phrase.split() if len(word) >= 5])`"),
    1022: ("Somme de la diagonale matricielle", "Lisez n, puis une matrice n x n. Affichez la somme de la diagonale principale.", "La diagonale principale est composée des éléments où ligne = colonne (`matrice[i][i]`).", "`print(sum(matrix[i][i] for i in range(n)))`"),
    1023: ("Totaux par groupe", "Lisez n lignes (catégorie et entier). Affichez le total de chaque catégorie par ordre alphabétique (catégorie:total).", "Utilisez un dictionnaire pour cumuler les totaux, puis triez les clés.", "`for k in sorted(d): print(f'{k}:{d[k]}')`"),
    1024: ("Années bissextiles", "Lisez deux années (début, fin). Affichez la liste de toutes les années bissextiles de cette plage inclusive.", "L'année y est bissextile si `(y % 4 == 0 and y % 100 != 0) or (y % 400 == 0)`.", "`print([y for y in range(start, end+1) if (y % 4 == 0 and y % 100 != 0) or (y % 400 == 0)])`"),
    1025: ("Nombre le plus fréquent", "Lisez n, puis n entiers. Affichez le plus fréquent. En cas d'égalité, affichez le plus petit.", "Utilisez la méthode `.count` ou un dictionnaire, et triez par `(fréquence, -valeur)`.", "`print(min(values, key=lambda x: (-values.count(x), x)))`"),
    1026: ("Répéter la chaîne", "Lisez un mot et un entier n séparés par un espace. Affichez le mot répété n fois sans séparateur.", "Séparez l'entrée, convertissez n en entier, et utilisez l'opérateur `*`.", "`mot, n = input().split(); print(mot * int(n))`"),
    1027: ("Compteur de voyelles", "Lisez une chaîne. Affichez le nombre de voyelles (a, e, i, o, u) présentes, sans tenir compte de la casse.", "Parcourez la chaîne et vérifiez si chaque caractère est dans 'aeiouAEIOU'.", "`print(sum(1 for c in text if c in 'aeiouAEIOU'))`"),
    1028: ("Inverser les mots", "Lisez une phrase. Affichez la phrase avec les mots en ordre inverse.", "Utilisez `.split()` pour obtenir la liste des mots, inversez-la avec `[::-1]`, et `.join()`.", "`print(' '.join(phrase.split()[::-1]))`"),
    1029: ("Est-ce un palindrome", "Lisez un mot. Affichez True s'il s'agit d'un palindrome, False sinon.", "Vérifiez si la chaîne est égale à elle-même inversée (`s[::-1]`).", "`print(s == s[::-1])`"),
    1030: ("Casse du titre", "Lisez une phrase. Affichez-la avec la première lettre de chaque mot en majuscule.", "Utilisez la méthode `.title()` ou `.capitalize()` sur chaque mot.", "`print(' '.join(word.capitalize() for word in phrase.split()))`"),

    2001: ("Message de bienvenue", "Lisez un nom et affichez 'Hello, <name>!' (avec le point d'exclamation).", "Utilisez une f-string pour intégrer le nom dans la chaîne.", "`print(f'Hello, {name}!')`"),
    2002: ("Somme des N premiers nombres", "Lisez un entier n et affichez la somme de tous les entiers de 1 à n inclus.", "Vous pouvez utiliser une boucle for ou la formule `n * (n + 1) // 2`.", "`print(n * (n + 1) // 2)`"),
    2003: ("Positif, négatif ou nul", "Lisez un entier et affichez POSITIVE s'il est > 0, NEGATIVE s'il est < 0, sinon ZERO.", "Utilisez une structure conditionnelle `if-elif-else`.", "`if n > 0: print('POSITIVE') elif n < 0: print('NEGATIVE') else: print('ZERO')`"),
    2004: ("Les N premiers nombres pairs", "Lisez un entier n et affichez une liste des n premiers nombres pairs (à partir de 2).", "Utilisez une compréhension de liste en multipliant par 2 la plage de 1 à n.", "`print([i * 2 for i in range(1, n+1)])`"),
    2005: ("Racine carrée", "Lisez un nombre >= 0 et affichez sa racine carrée arrondie à 2 décimales. L'import n'est pas nécessaire.", "En Python, la racine carrée équivaut à la puissance `0.5` (`n ** 0.5`).", "`print(f'{n ** 0.5:.2f}')`"),
    2006: ("Générateur d'acronyme", "Lisez une phrase et affichez son acronyme (première lettre de chaque mot en majuscules).", "Séparez les mots avec `.split()`, prenez le premier caractère `[0]`, et mettez en `.upper()`.", "`print(''.join(word[0].upper() for word in phrase.split()))`"),
    2007: ("Deuxième plus grand distinct", "Lisez n, puis n entiers. Affichez le deuxième plus grand nombre distinct. Si tous sont égaux, affichez None.", "Convertissez la liste en `set` pour enlever les doublons, triez, puis prenez l'avant-dernier.", "`uniques = sorted(set(values)); print(uniques[-2] if len(uniques) > 1 else None)`"),
    2008: ("Liste FizzBuzz", "Lisez un entier n. Affichez une liste de taille n (1 à n) : 'Fizz' (mult 3), 'Buzz' (mult 5), 'FizzBuzz' (les deux), sinon le nombre (en chaîne).", "Vérifiez modulo 15 en premier, puis 3, puis 5.", "`print(['FizzBuzz' if i%15==0 else 'Fizz' if i%3==0 else 'Buzz' if i%5==0 else str(i) for i in range(1, n+1)])`"),
    2009: ("Divisible par 3 et 5", "Lisez n, puis n entiers. Affichez une liste des nombres divisibles par 3 ET par 5.", "La divisibilité par 3 et 5 équivaut à la divisibilité par 15 (`x % 15 == 0`).", "`print([x for x in lst if x % 15 == 0])`"),
    2010: ("Cycle de dés", "Lisez un entier n. Affichez une liste de n lancers de dés en répétant 1, 2, 3, 4, 5, 6 dans l'ordre.", "Utilisez l'opérateur modulo `% 6` et ajoutez 1 pour rester dans la plage 1-6.", "`print([(i % 6) + 1 for i in range(n)])`"),
    2011: ("Nombres premiers dans une plage", "Lisez debut et fin. Affichez une liste de tous les nombres premiers dans la plage inclusive [debut, fin].", "Un nombre est premier s'il est > 1 et n'est divisible que par 1 et lui-même.", "Écrivez une fonction `is_prime(x)` puis utilisez `[x for x in range(start, end+1) if is_prime(x)]`."),
    2012: ("Vérification d'anagramme", "Lisez deux chaînes. Affichez ANAGRAM si ce sont des anagrammes (ignorer la casse et les espaces), sinon NOT ANAGRAM.", "Deux mots sont des anagrammes si leurs caractères triés sont égaux.", "`a = s1.lower().replace(' ', ''); b = s2.lower().replace(' ', ''); print('ANAGRAM' if sorted(a) == sorted(b) else 'NOT ANAGRAM')`"),
    2013: ("Aplatir une liste imbriquée", "Lisez une chaîne représentant une liste de listes (ex: '[[1,2],[3,4]]'). Affichez la liste aplatie en utilisant eval().", "Utilisez `eval()` pour obtenir la liste de listes, puis deux boucles for imbriquées dans une compréhension.", "`print([item for sublist in eval(s) for item in sublist])`"),
    2014: ("Chiffrement de César", "Lisez un décalage k puis un message. Affichez le message chiffré en décalant chaque lettre de k positions dans l'alphabet.", "Utilisez `chr()` et `ord()`, et vérifiez `c.isalpha()`.", "Pour les majuscules : `chr((ord(c) - 65 + k) % 26 + 65)`. Idem pour les minuscules avec 97."),
    2015: ("Différence de dates", "Lisez deux dates (YYYY-MM-DD). Affichez la différence absolue en jours sans importer de modules (astuce : utilisez un format basique).", "Calculez le nombre absolu de jours (simplifié si l'énoncé garantit la même année, ou convertissez tout en jours).", "S'il faut le faire exactement, analysez Y, M, D et calculez l'epoch ou importez `datetime` (si autorisé)."),
    2016: ("Triangle de Pascal", "Lisez n (>= 1). Affichez les n premières lignes du triangle de Pascal sous forme de liste de listes.", "Chaque élément de la ligne i est la somme de deux éléments de la ligne i-1.", "Générez itérativement en utilisant `row = [1] + [row[j-1] + row[j] for j in range(1, len(row))] + [1]`."),
    
    3001: ("Écho de l'entrée", "Lisez une ligne d'entrée et affichez exactement la même valeur.", "Utilisez la fonction print() sur la variable lue.", "`print(input())`"),
    3002: ("Addition de deux entiers", "Lisez deux entiers sur une ligne et affichez leur somme.", "Séparez l'entrée avec `.split()`, convertissez en entiers, et utilisez `+`.", "`a, b = map(int, input().split()); print(a + b)`"),
    3003: ("Aire d'un rectangle", "Lisez la largeur et la hauteur (entiers) sur une ligne. Affichez l'aire du rectangle.", "L'aire d'un rectangle est `largeur * hauteur`.", "`w, h = map(int, input().split()); print(w * h)`"),
    3004: ("Moitié d'un nombre", "Lisez un nombre (flottant) et affichez sa moitié avec exactement 2 décimales.", "Divisez par 2 et utilisez le formatage `.2f`.", "`print(f'{float(input()) / 2:.2f}')`"),
    3005: ("Nom complet", "Lisez un prénom et un nom sur deux lignes. Affichez-les sur une ligne séparés par un espace.", "Utilisez la concaténation de chaînes ou une f-string.", "`print(f'{prenom} {nom}')`"),
    3006: ("Échanger deux valeurs", "Lisez deux valeurs sur une ligne. Échangez-les et affichez la seconde puis la première.", "Lisez les deux valeurs puis affichez-les en ordre inverse.", "`x, y = input().split(); print(f'{y} {x}')`"),
    3007: ("Quotient et Reste", "Lisez deux entiers a et b. Affichez le quotient entier et le reste de la division de a par b.", "Utilisez l'opérateur de division entière `//` et le modulo `%`.", "`print(a // b, a % b)`"),
    3008: ("Calcul de puissance", "Lisez deux entiers x et y. Affichez x à la puissance y.", "Utilisez l'opérateur de puissance `**`.", "`print(x ** y)`"),
    3009: ("Le plus grand nombre", "Lisez deux entiers et affichez le plus grand. S'ils sont égaux, affichez l'un des deux.", "Utilisez la fonction intégrée `max()`.", "`print(max(a, b))`"),
    3010: ("Réussite ou Reprise", "Lisez un score. Affichez PASS si le score est au moins 50, sinon RETRY.", "Utilisez une structure conditionnelle `if-else`.", "`if score >= 50: print('PASS') else: print('RETRY')`"),
    3011: ("Opérateur logique AND", "Lisez deux mots (True ou False). Affichez le résultat de l'opération booléenne AND.", "Convertissez les chaînes en booléens (`s == 'True'`) puis utilisez `and`.", "`a, b = input().split(); print((a == 'True') and (b == 'True'))`"),
    3012: ("Longueur de chaîne", "Lisez une chaîne et affichez son nombre de caractères.", "Utilisez la fonction intégrée `len()`.", "`print(len(s))`"),
    3013: ("Celsius en Kelvin", "Lisez une température en Celsius (flottant) et affichez la température en Kelvin (arrondie à 2 décimales).", "La formule est Kelvin = Celsius + 273.15.", "`print(f'{c + 273.15:.2f}')`"),
    3014: ("Prix avec taxe", "Lisez un prix (flottant). Ajoutez une taxe de 19% et affichez le prix final avec 2 décimales.", "Multipliez le prix par 1.19.", "`print(f'{prix * 1.19:.2f}')`"),
    3015: ("Badge d'identification", "Lisez un nom et un âge. Affichez-les sous le format nom:age.", "Utilisez une f-string pour coller les deux informations.", "`print(f'{nom}:{age}')`"),
    3016: ("Valeur absolue (sans fonction)", "Lisez un entier. Affichez sa valeur absolue en utilisant une condition if.", "Si le nombre est < 0, affichez `-n`.", "`if n < 0: print(-n) else: print(n)`"),
    3017: ("Étiquette de parité", "Lisez un entier et affichez EVEN_NUMBER s'il est pair, sinon ODD_NUMBER.", "Vérifiez si `n % 2 == 0`.", "`print('EVEN_NUMBER' if n % 2 == 0 else 'ODD_NUMBER')`"),
    3018: ("Valeur de la fonction Carré", "Lisez un entier x. Définissez une fonction square(x) qui renvoie x au carré, et affichez le résultat.", "Utilisez `def square(x): return x ** 2`.", "Créez la fonction, puis appelez `print(square(x))`."),
    3019: ("Dernier chiffre", "Lisez un entier positif et affichez son dernier chiffre.", "Le dernier chiffre est obtenu avec le modulo 10 (`n % 10`) ou en convertissant en chaîne.", "`print(n % 10)`"),
    3020: ("Drapeau de connexion simple", "Lisez un identifiant et un code PIN sur deux lignes. Affichez ACCESS si id='admin' et PIN='1234', sinon DENIED.", "Vérifiez les deux conditions avec `and`.", "`if u == 'admin' and p == '1234': print('ACCESS') else: print('DENIED')`"),
    3021: ("Énergie potentielle", "Lisez la masse, la hauteur et g (flottants). Affichez m * h * g avec 2 décimales.", "Multipliez les trois variables et utilisez `.2f`.", "`print(f'{m * h * g:.2f}')`"),
    3022: ("Vérification de la limite d'énergie", "Lisez masse, hauteur, limite. Utilisez g=9.81. Affichez ABOVE si l'énergie > limite, sinon BELOW_OR_EQUAL.", "Calculez l'énergie et utilisez une condition.", "`if m * h * 9.81 > limit: print('ABOVE') else: print('BELOW_OR_EQUAL')`"),
    3023: ("Mini Calculatrice", "Lisez un nombre, un opérateur (+, -, *, /) et un autre nombre. Affichez le résultat (2 décimales pour la division).", "Utilisez des instructions if pour chaque opérateur.", "Si `op == '/'`, affichez `f'{a / b:.2f}'`."),
    3024: ("Note avec bonus", "Lisez un score et un bonus (True/False). Affichez PASS si score >= 50 ou bonus est True, sinon FAIL.", "Utilisez l'opérateur logique `or`.", "`if score >= 50 or bonus == 'True': print('PASS') else: print('FAIL')`"),
    3025: ("Décomposer les secondes", "Lisez un nombre de secondes. Affichez les heures, minutes, et secondes séparées par des espaces.", "Utilisez la division entière `//` et le modulo `%`.", "`h = s // 3600; m = (s % 3600) // 60; sec = s % 60; print(h, m, sec)`"),
    3026: ("Premier, milieu, dernier", "Lisez cinq entiers. En utilisant le unpacking, affichez le premier, le milieu et le dernier.", "Capturez les valeurs avec `a, b, c, d, e = ...` puis affichez a, c, e.", "`a, _, c, _, e = vals; print(a, c, e)`"),
    3027: ("Différence de carrés", "Lisez x et y. Définissez une fonction qui renvoie x² - y², puis affichez le résultat.", "La formule est `(x ** 2) - (y ** 2)`.", "Définissez `def diff(x, y): return x**2 - y**2` puis appelez-la."),
    3028: ("Frais d'expédition", "Lisez un poids (flottant) et un drapeau de membre (True/False). Le coût de base est poids * 5. Les membres ont 10% de réduction. Affichez le coût final avec 2 décimales.", "Si membre, `cout *= 0.9`.", "`cost = w * 5; if member == 'True': cost *= 0.9; print(f'{cost:.2f}')`"),
    3029: ("Compter les nombres positifs", "Lisez n, puis n entiers. Affichez combien sont supérieurs à 0.", "Utilisez une boucle ou une compréhension de liste avec `x > 0`.", "`print(sum(1 for x in values if x > 0))`"),
    3030: ("Division sécurisée", "Lisez a et b. Si b est 0, affichez ERROR. Sinon affichez a / b avec 2 décimales.", "Vérifiez `if b == 0`.", "`if b == 0: print('ERROR') else: print(f'{a / b:.2f}')`"),
    3031: ("Croissance en pourcentage", "Lisez valeur initiale, taux, années. Appliquez le taux chaque année et affichez la valeur avec 2 décimales.", "Utilisez une boucle for pour multiplier la valeur par `(1 + taux/100)`.", "`for _ in range(years): val *= (1 + rate/100)`"),
    3032: ("Tentatives de connexion", "Lisez n tentatives (identifiant et code PIN). Affichez ACCESS si 'admin' '1234' est trouvé, sinon LOCKED.", "Utilisez une variable drapeau (flag) ou un `break` après avoir affiché ACCESS.", "Si trouvé, affichez 'ACCESS' et faites un `break`. Sinon, le `else` de la boucle affiche 'LOCKED'."),
    3033: ("Minimum, Maximum, Moyenne", "Lisez n, puis n entiers. Affichez le minimum, le maximum et la moyenne (2 décimales).", "Utilisez `min()`, `max()`, et `sum() / len()`.", "`print(f'{min(v)} {max(v)} {sum(v)/n:.2f}')`"),
    3034: ("Opérateur logique (Ligne)", "Lisez deux booléens et un opérateur AND, OR, ou XOR. Affichez le résultat.", "Évaluez les booléens et utilisez des `if` pour vérifier l'opérateur.", "Si `op == 'AND'`, affichez `b1 and b2`."),
    3035: ("Fonction par morceaux", "Lisez x. Si x < 0: x². Si x == 0: 0. Si x > 0: 2*x + 1.", "Utilisez un bloc `if-elif-else`.", "`if x < 0: print(x**2) elif x == 0: print(0) else: print(2*x + 1)`"),
    3036: ("Expression de gauche à droite", "Lisez 'a op1 b op2 c'. Évaluez de gauche à droite et affichez le résultat entier.", "Commencez par calculer `res = a op1 b`, puis `res op2 c`.", "Utilisez des conditions if pour appliquer les opérations manuellement."),
    3037: ("Vérificateur de mot de passe", "Lisez un mot de passe. STRONG si len >= 8, au moins un chiffre, une majuscule, et aucun espace. Sinon WEAK.", "Vérifiez `.isdigit()`, `.isupper()`, et `' ' not in pwd`.", "Si toutes les vérifications passent, affichez STRONG."),
    3038: ("Table de fonction", "Lisez début et fin. Pour chaque x, calculez f(x) = x² - 2x + 1. Affichez les résultats sous forme de liste.", "Utilisez une compréhension de liste `[x**2 - 2*x + 1 for x in range(start, end+1)]`.", "`print([x**2 - 2*x + 1 for x in range(start, end+1)])`"),
    3039: ("Rendu de monnaie", "Lisez un montant en centimes. Affichez le nombre minimum de pièces de 25, 10, 5, 1.", "Utilisez la division entière et le modulo à chaque étape.", "`q = m // 25; m %= 25; d = m // 10 ...`"),
    3040: ("Racines quadratiques", "Lisez a, b, c. Si pas de racines, NO REAL ROOTS. Une racine: avec 2 décimales. Deux racines: la plus petite puis la plus grande (2 déc.).", "Calculez le discriminant delta = b² - 4ac.", "`if delta < 0: print('NO REAL ROOTS') ...`")
}

# Provide automatic default translations for generic programmatic questions
def auto_translate(q):
    title = q['title']
    desc = q.get('description', '')
    h1 = q.get('hint1', '')
    h2 = q.get('hint2', '')
    
    # Generic replacements
    title_map = {
        "Echo Input": "Écho de l'entrée",
        "Add Two Integers": "Additionner deux entiers",
        "Subtract Two Integers": "Soustraire deux entiers",
        "Float Addition": "Addition de flottants",
        "Integer Division": "Division entière",
        "True Float Division": "Division flottante vraie",
        "Multiplication": "Multiplication",
        "Power Operator": "Opérateur de puissance",
        "Equality Check": "Vérification d'égalité",
        "Inequality Check": "Vérification d'inégalité",
        "Greater Than": "Plus grand que",
        "Less or Equal": "Plus petit ou égal",
        "Logical AND": "ET logique",
        "Logical OR": "OU logique",
        "Logical XOR": "XOR logique",
        "Variables Swap": "Échange de variables",
        "String Plus Number?": "Chaîne plus nombre ?",
        "Basic Function": "Fonction de base",
        "Basic Lambda": "Lambda de base",
        "Output Formatting": "Formatage de la sortie",
        "Check Limits": "Vérifier les limites",
        "Function x^2 - y^2": "Fonction x² - y²",
        "Variable Unpacking": "Dépaquetage de variable",
        "Default Arguments": "Arguments par défaut",
        "Composed Lambda": "Lambda composée",
        "Complex Logic": "Logique complexe",
        "Polynomial Def": "Définition de polynôme",
        "Print Formatted String": "Affiche une chaîne formatée",
        "String Slicing": "Découpage de chaîne",
        "List Unpacking with *": "Dépaquetage de liste avec *",
        "Energy Limit Exercise": "Exercice de limite d'énergie",
        "Function Composition": "Composition de fonction",
        "Unpack First and Last": "Dépaqueter le premier et le dernier",
        "Nested Lamda": "Lambda imbriquée",
        "NAND Logic": "Logique NAND",
        "Multiple Return Unpacking": "Dépaquetage de retours multiples",
        "Lambda Data Pipeline": "Pipeline de données Lambda",
        "Ternary Operator Equiv": "Équivalent de l'opérateur ternaire",
        "Complex Formatting": "Formatage complexe",
        "Args Wrapper": "Enveloppe d'arguments",
        "Print Name": "Afficher le nom",
        "Double Input": "Doubler l'entrée",
        "String Length": "Longueur de la chaîne",
        "Modulus": "Modulo",
        "Swap Variables": "Échanger des variables",
        "Substring Count": "Compte de sous-chaîne",
        "Floor Division": "Division euclidienne",
        "Reverse String": "Inverser la chaîne",
        "Palindrome Check": "Vérification de palindrome",
        "Anagram Check": "Vérification d'anagramme",
        "Recursive Factorial": "Factorielle récursive",
        "List First Element": "Premier élément de liste",
        "List Last Element": "Dernier élément de liste",
        "List Append": "Ajouter à la liste",
        "Dict Value": "Valeur du dictionnaire",
        "Unique Elements": "Éléments uniques",
        "Tuple Conversion": "Conversion en tuple",
        "Dict Keys": "Clés de dictionnaire",
        "Dictionary Merge": "Fusion de dictionnaires",
        "List Flatten": "Aplatir une liste",
        "Nested Dictionary": "Dictionnaire imbriqué",
        "Sort by frequency": "Trier par fréquence",
        "Max of Two": "Maximum de deux",
        "Sign Check": "Vérification du signe",
        "Is Even": "Est pair",
        "Pass Fail": "Réussite / Échec",
        "FizzBuzz": "FizzBuzz",
        "Vowel Consonant": "Voyelle ou Consonne",
        "Leap Year": "Année bissextile",
        "Prime Check": "Vérification de nombre premier",
        "Fibonacci Nth": "N-ième de Fibonacci",
        "Number to Words": "Nombre en lettres",
        "Collatz Steps": "Étapes de Collatz",
        "Evens Only": "Pairs uniquement",
        "Squares": "Carrés",
        "Lengths": "Longueurs",
        "Upper Case": "Majuscules",
        "Filter by length": "Filtrer par longueur",
        "Divisible by 3": "Divisible par 3",
        "Positive Only": "Positifs uniquement",
        "Nested Comprehension": "Compréhension imbriquée",
        "If Else in Comp": "If Else dans une compréhension",
        "Flatten Matrix": "Aplatir la matrice",
        "Dict Comprehension": "Compréhension de dictionnaire",
        "Math Pi": "Pi (Math)",
        "Math Sqrt": "Racine carrée (Math)",
        "Math Ceil": "Arrondi supérieur (Math)",
        "Math Floor": "Arrondi inférieur (Math)",
        "Random Choice Mock": "Choix aléatoire (Mock)",
        "Math Pow": "Puissance (Math)",
        "Math Factorial": "Factorielle (Math)",
        "Math Log": "Logarithme (Math)",
        "Datetime Mock": "Datetime (Mock)",
        "Math GCD": "PGCD (Math)",
        "Math Radians": "Radians (Math)",
        "Format String": "Formater la chaîne",
        "CSV Read Line": "Lire une ligne CSV",
        "Space Pad": "Remplissage d'espaces",
        "Zero Pad": "Remplissage de zéros",
        "Multiline Input": "Entrée multiligne",
        "Float format": "Format flottant",
        "List to CSV": "Liste vers CSV",
        "Mock File Read": "Lecture de fichier (Mock)",
        "Percentage Format": "Format en pourcentage",
        "Parse Key-Value": "Analyser Clé-Valeur",
        "Tabular Output": "Sortie sous forme de tableau",
        "Empty Class": "Classe vide",
        "Class Attribute": "Attribut de classe",
        "Instance Attribute": "Attribut d'instance",
        "Simple Method": "Méthode simple",
        "String Representation": "Représentation en chaîne",
        "Inheritance": "Héritage",
        "Encapsulation Mock": "Encapsulation (Mock)",
        "Polymorphism": "Polymorphisme",
        "Class Method": "Méthode de classe",
        "Property Decorator": "Décorateur de propriété",
        "Dunder Add": "Dunder Add (Addition spéciale)",
        "Array Creation Mock": "Création de tableau (Mock)",
        "Zeros Array Mock": "Tableau de zéros (Mock)",
        "Ones Array Mock": "Tableau de uns (Mock)",
        "Array Shape Mock": "Forme de tableau (Mock)",
        "Elementwise Add": "Addition élément par élément",
        "Scalar Multiply": "Multiplication scalaire",
        "Dot Product Mock": "Produit scalaire (Mock)",
        "Matrix Transpose Mock": "Transposition de matrice (Mock)",
        "Boolean Indexing": "Indexation booléenne",
        "Mean and Std Mock": "Moyenne et écart-type (Mock)",
        "Broadcasting Mock": "Broadcasting (Mock)",
        "Create Series Mock": "Créer une série (Mock)",
        "DataFrame Head": "En-tête DataFrame",
        "DataFrame Tail": "Fin de DataFrame",
        "Column Select": "Sélection de colonne",
        "Filter Rows Mock": "Filtrer les lignes (Mock)",
        "Value Counts Mock": "Comptage des valeurs (Mock)",
        "Fill NA Mock": "Remplir NA (Mock)",
        "Groupby Sum Mock": "Somme Groupby (Mock)",
        "Apply Function Mock": "Appliquer une fonction (Mock)",
        "Merge DataFrames Mock": "Fusionner des DataFrames (Mock)",
        "Pivot Table Mock": "Table croisée dynamique (Mock)",
        "ASCII Line": "Ligne ASCII",
        "ASCII Star": "Étoile ASCII",
        "Vertical Bar": "Barre verticale",
        "Point Plot": "Nuage de points",
        "ASCII Bar Chart": "Graphique en barres ASCII",
        "Labeled Bar": "Barre étiquetée",
        "Scatter Mock": "Nuage de points (Mock)",
        "Histogram Bins Mock": "Bacs d'histogramme (Mock)",
        "Boxplot Stats": "Statistiques de boîte à moustaches",
        "Correlation Mock": "Corrélation (Mock)",
        "Heatmap Mock": "Carte thermique (Mock)"
    }
    
    if title in title_map:
        title = title_map[title]
        
    # Translate basic verbs in descriptions and hints
    replacements = [
        ("Read", "Lisez"), ("Print", "Affichez"), ("print", "affichez"), ("an integer", "un entier"),
        ("two integers", "deux entiers"), ("and print", "et affichez"), ("their", "leur"),
        ("sum", "somme"), ("Use", "Utilisez"), ("Check", "Vérifiez"), ("Define", "Définissez"),
        ("Return", "Renvoyez"), ("function", "fonction"), ("string", "chaîne"), ("list", "liste"),
        ("space separated", "séparés par un espace"), ("reversed", "inversé"),
        ("True if", "True si"), ("False if", "False si"), ("Assume input is", "Supposons que l'entrée soit"),
        ("Hint 1: Review the concepts for", "Indice 1: Revoyez les concepts pour"),
        ("Look closely at the input format.", "Regardez attentivement le format d'entrée."),
        ("Hint 2: Try to use basic python built-ins to solve this.", "Indice 2: Essayez d'utiliser les fonctions Python de base.")
    ]
    
    for en, fr in replacements:
        desc = desc.replace(en, fr)
        h1 = h1.replace(en, fr)
        h2 = h2.replace(en, fr)
        
    return title, desc, h1, h2

def run_translation():
    filepath = os.path.abspath(os.path.join(os.path.dirname(__file__), '../src/data/coding_questions.py'))
    
    new_questions = []
    
    for q in CODING_QUESTIONS:
        qid = q['id']
        is_exam = q.get('is_exam', False)
        
        # Translate
        if qid in TRANSLATIONS:
            t, d, h1, h2 = TRANSLATIONS[qid]
            q['title'] = t
            q['description'] = d
            if not is_exam:
                q['hint1'] = h1
                q['hint2'] = h2
        else:
            t, d, h1, h2 = auto_translate(q)
            q['title'] = t
            q['description'] = d
            if not is_exam:
                q['hint1'] = h1
                q['hint2'] = h2
                
        new_questions.append(q)
        
    # Write back
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('"""Prototype coding questions for the coding test window."""\n\n\n')
        f.write('CODING_QUESTIONS = [\n')
        
        for q in new_questions:
            f.write('    {\n')
            for k, v in q.items():
                if k in ['public_tests', 'hidden_tests']:
                    f.write(f'        "{k}": [\n')
                    for test in v:
                        f.write(f'            {repr(test)},\n')
                    f.write('        ],\n')
                elif k == 'execution_settings':
                    f.write(f'        "{k}": {repr(v)},\n')
                else:
                    f.write(f'        "{k}": {repr(v)},\n')
            f.write('    },\n')
        f.write(']\n')

if __name__ == "__main__":
    run_translation()
    print("All coding questions have been successfully translated to French.")
