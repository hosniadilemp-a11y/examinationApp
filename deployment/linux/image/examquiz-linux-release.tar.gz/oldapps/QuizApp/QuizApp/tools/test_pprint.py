import pprint

d = {
    "starter_code": "def func():\n    pass\n",
    "solution": "print('hello')\nprint('world')"
}

with open("test_out.py", "w") as f:
    f.write("Q = " + pprint.pformat(d, sort_dicts=False))
