"""Create encrypted final exam .quiz files from JSON sources."""

import argparse
import json
import os
import sys


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_DIR = os.path.join(PROJECT_ROOT, "src")
sys.path.insert(0, SRC_DIR)

from core.exam_loader import ExamLoader


def main() -> None:
    parser = argparse.ArgumentParser(description="Encrypt a final exam JSON file.")
    parser.add_argument("source_json", help="Path to the editable exam JSON file.")
    parser.add_argument("output_quiz", help="Path for the generated .quiz file.")
    parser.add_argument("--password", default="dilo2025", help="Encryption password.")
    args = parser.parse_args()

    with open(args.source_json, "r", encoding="utf-8") as file:
        exam_data = json.load(file)

    os.makedirs(os.path.dirname(args.output_quiz) or ".", exist_ok=True)

    loader = ExamLoader(args.password)
    loader.encrypt_exam(exam_data, args.output_quiz)


if __name__ == "__main__":
    main()
