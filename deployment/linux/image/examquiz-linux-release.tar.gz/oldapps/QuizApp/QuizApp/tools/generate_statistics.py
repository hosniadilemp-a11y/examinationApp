import os
import sys

# Add src to path to allow importing data modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from data.coding_questions import CODING_QUESTIONS
from data.questions import BASE64_QUESTIONS as THEORETICAL_QUESTIONS

def generate_report():
    stats = {}

    # Process theoretical
    for q in THEORETICAL_QUESTIONS:
        topic = q.get('topic', 'Unknown Topic')
        diff = q.get('difficulty', 'easy').lower()
        
        if topic not in stats:
            stats[topic] = {'theoretical': {'easy': 0, 'medium': 0, 'hard': 0, 'very hard': 0},
                            'practical': {'easy': 0, 'medium': 0, 'hard': 0, 'very hard': 0}}
        
        if diff in stats[topic]['theoretical']:
            stats[topic]['theoretical'][diff] += 1
        else:
            stats[topic]['theoretical'][diff] = 1

    # Process practical
    for q in CODING_QUESTIONS:
        topic = q.get('topic', 'Unknown Topic')
        diff = q.get('difficulty', 'easy').lower()
        
        if topic not in stats:
            stats[topic] = {'theoretical': {'easy': 0, 'medium': 0, 'hard': 0, 'very hard': 0},
                            'practical': {'easy': 0, 'medium': 0, 'hard': 0, 'very hard': 0}}
        
        if diff in stats[topic]['practical']:
            stats[topic]['practical'][diff] += 1
        else:
            stats[topic]['practical'][diff] = 1

    # Write report
    report_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../question_statistics_report.txt'))
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("=================================================================\n")
        f.write("               QUESTION STATISTICS REPORT\n")
        f.write("=================================================================\n\n")
        
        total_theo = 0
        total_prac = 0

        for topic, counts in sorted(stats.items()):
            f.write(f"Topic: {topic}\n")
            f.write("-" * 50 + "\n")
            
            # Theoretical
            t_counts = counts['theoretical']
            sum_t = sum(t_counts.values())
            total_theo += sum_t
            f.write(f"  Theoretical ({sum_t} total):\n")
            f.write(f"    - Easy:      {t_counts.get('easy', 0)}\n")
            f.write(f"    - Medium:    {t_counts.get('medium', 0)}\n")
            f.write(f"    - Hard:      {t_counts.get('hard', 0)}\n")
            f.write(f"    - Very Hard: {t_counts.get('very hard', 0)}\n\n")
            
            # Practical
            p_counts = counts['practical']
            sum_p = sum(p_counts.values())
            total_prac += sum_p
            f.write(f"  Practical ({sum_p} total):\n")
            f.write(f"    - Easy:      {p_counts.get('easy', 0)}\n")
            f.write(f"    - Medium:    {p_counts.get('medium', 0)}\n")
            f.write(f"    - Hard:      {p_counts.get('hard', 0)}\n")
            f.write(f"    - Very Hard: {p_counts.get('very hard', 0)}\n\n")
            
        f.write("=================================================================\n")
        f.write(f"TOTAL THEORETICAL QUESTIONS: {total_theo}\n")
        f.write(f"TOTAL PRACTICAL QUESTIONS:   {total_prac}\n")
        f.write(f"GRAND TOTAL:                 {total_theo + total_prac}\n")
        f.write("=================================================================\n")
        
    print(f"Report saved to {report_path}")

if __name__ == "__main__":
    generate_report()
