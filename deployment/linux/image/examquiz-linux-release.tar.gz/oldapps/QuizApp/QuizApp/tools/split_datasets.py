import os
import sys
import shutil
import pprint

sys.path.append(os.path.abspath("src"))

from data.coding_questions import CODING_QUESTIONS
from data.questions import BASE64_QUESTIONS
from core.progression import DIFFICULTY_ORDER

def sanitize_filename(topic):
    return topic.lower().replace(" ", "_").replace("/", "_").replace("-", "_").replace("(", "").replace(")", "").replace("__", "_").strip("_")

def sort_by_difficulty(questions):
    def get_order(q):
        diff = q.get('difficulty', 'easy').lower()
        if diff in DIFFICULTY_ORDER:
            return DIFFICULTY_ORDER.index(diff)
        return 999
    return sorted(questions, key=get_order)

def split_dataset(questions, target_dir, list_var_name):
    # Group by topic
    grouped = {}
    for q in questions:
        topic = q.get('topic', 'unknown')
        if topic not in grouped:
            grouped[topic] = []
        grouped[topic].append(q)
        
    # Sort within topic
    for topic in grouped:
        grouped[topic] = sort_by_difficulty(grouped[topic])
        
    os.makedirs(target_dir, exist_ok=True)
    
    init_lines = [f"# Auto-generated {list_var_name} module\n"]
    all_imports = []
    
    for topic, q_list in grouped.items():
        filename = sanitize_filename(topic)
        file_path = os.path.join(target_dir, f"{filename}.py")
        
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(f'"""Questions for topic: {topic}"""\n\n')
            f.write("QUESTIONS = " + pprint.pformat(q_list, sort_dicts=False, width=120) + "\n")
            
        init_lines.append(f"from .{filename} import QUESTIONS as q_{filename}")
        all_imports.append(f"q_{filename}")
        
    init_lines.append(f"\n{list_var_name} = " + " + ".join(all_imports) + "\n")
    
    with open(os.path.join(target_dir, "__init__.py"), "w", encoding="utf-8") as f:
        f.write("\n".join(init_lines))
    print(f"Successfully split {len(questions)} questions into {target_dir}")

def main():
    print("Splitting coding questions...")
    split_dataset(CODING_QUESTIONS, "src/data/coding_questions_new", "CODING_QUESTIONS")
    
    print("Splitting theoretical questions...")
    split_dataset(BASE64_QUESTIONS, "src/data/questions_new", "BASE64_QUESTIONS")

if __name__ == "__main__":
    main()
