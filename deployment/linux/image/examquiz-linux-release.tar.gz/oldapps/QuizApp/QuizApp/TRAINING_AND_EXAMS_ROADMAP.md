# Training And Final Exams Roadmap

## Requested Updates

1. Training users can choose the topics they want to practice.
2. Training users can choose the difficulty levels they want to practice.
3. Training results do not generate a PDF. PDFs are only for official exams.
4. Previous training attempts are saved.
5. Results show mark evolution overall, by topic, and by difficulty.
6. Results show a training level based on performance and selected difficulty.
7. Results show a topic ranking from training history.
8. Final exam creation has a dedicated folder and procedure using `src/core/exam_loader.py`.

## Step By Step Implementation

### Step 1 - Training Topic Selection

- Read topics from `src/data/questions.py`.
- Show topic checkboxes in Training Mode.
- Store selected topics in `user_info["selected_topics"]`.
- Pass selected topics to `QuizEngine` through `config["topic_filter"]`.

### Step 2 - Training Difficulty Selection

- Read difficulties from `src/data/questions.py`.
- Show difficulty checkboxes in Training Mode.
- Store selected difficulties in `user_info["selected_difficulties"]`.
- Pass selected difficulties to `QuizEngine` through `config["difficulty_filter"]`.

### Step 3 - PDF Only For Exams

- Results window checks `user_info["mode"]`.
- If mode is `training`, no PDF report is created and no report button is shown.
- If mode is `exam`, PDF generation stays unchanged.

### Step 4 - Save Training Attempts

- Save attempts in `results/training_history.json`.
- Each attempt stores date, student name, selected topics, selected difficulties, final mark, percentage, counts, topic analysis, and difficulty analysis.

### Step 5 - Show Evolution Charts

- Training results show an overall mark evolution chart.
- Training results also show per-topic evolution for topics found in previous attempts.
- Training results also show per-difficulty evolution for difficulty levels found in previous attempts.

### Step 6 - Training Level And Topic Ranking

- Calculate a training level from the final mark and selected difficulty.
- Show a topic ranking using average historical marks per topic.

### Step 7 - Question Bank Structure

- Training topics are: numpy, pandas, basic python, Python Data Types, Control condition, module de base python, list comprension, I/O, OOP, and data vise: seaborn matplotlib.
- Each topic has 6 easy, 4 medium, 3 hard, and 2 very hard questions.
- Each MCQ has 6 options and multiple correct answers.
- Difficulty spelling is normalized to `medium` in the data and code.

### Step 8 - Final Exam Creation Procedure

- Use `exams_final/source_json/` for editable final exam JSON files.
- Use `exams_final/encrypted_quiz/` for generated `.quiz` files.
- Use `tools/create_final_exam.py` to encrypt JSON through `ExamLoader`.

## Where Training Questions Are

The built-in training questions are in:

- `src/data/questions.py`
- list name: `BASE64_QUESTIONS`
- exam/training defaults: `EXAM_CONFIG`

Each training question should include:

- `id`
- `type`
- `topic`
- `difficulty`
- `text`
- `points`
- `penalty`
- `options` for MCQ questions
- `correct`
