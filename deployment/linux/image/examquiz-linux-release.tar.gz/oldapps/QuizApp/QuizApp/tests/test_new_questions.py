import pytest
from core.quiz_engine import QuizEngine
from data.questions import BASE64_QUESTIONS

def test_new_question_types_scoring():
    # Setup mock config
    config = {
        'max_questions': 10,
        'passing_score': 50,
        'shuffle_questions': False,
        'shuffle_options': False
    }
    
    # 1. Test Simple Blank question
    blank_q = {
        'id': 10001,
        'type': 'simple_blank',
        'topic': 'Python Basics',
        'difficulty': 'easy',
        'text': 'Complete x.____(4)',
        'code': 'x = [1, 2, 3]\nx.____(4)',
        'answer': 'append',
        'points': 1.0,
        'penalty': 0.25
    }
    
    # 2. Test Matching question
    matching_q = {
        'id': 10003,
        'type': 'matching',
        'topic': 'Python Basics',
        'difficulty': 'easy',
        'text': 'Match operator',
        'pairs': {
            '+': 'Addition',
            '//': 'Division entière'
        },
        'points': 2.0,
        'penalty': 0.0
    }
    
    # 3. Test Intruder question
    intruder_q = {
        'id': 10002,
        'type': 'intruder',
        'topic': 'Python Basics',
        'difficulty': 'easy',
        'text': 'Find the intruder',
        'options': ['def', 'class', 'function', 'return'],
        'correct': 2,
        'points': 1.0,
        'penalty': 0.25
    }
    
    engine = QuizEngine(config, [blank_q, matching_q, intruder_q])
    engine.prepare_exam(3)
    
    # Test blank correct and incorrect answers (case-insensitivity, space stripping)
    res_correct_blank = engine._calculate_simple_blank_score(blank_q, "  APPEND  ")
    assert res_correct_blank['status'] == 'correct'
    assert res_correct_blank['points'] == 1.0
    
    res_wrong_blank = engine._calculate_simple_blank_score(blank_q, "extend")
    assert res_wrong_blank['status'] == 'incorrect'
    assert res_wrong_blank['points'] == 0.0
    assert res_wrong_blank['penalty'] == 0.25
    
    # Test matching: all correct, partial correct, none correct
    res_all_matching = engine._calculate_matching_score(matching_q, {'+': 'Addition', '//': 'Division entière'})
    assert res_all_matching['status'] == 'correct'
    assert res_all_matching['points'] == 2.0
    
    res_partial_matching = engine._calculate_matching_score(matching_q, {'+': 'Addition', '//': 'Wrong'})
    assert res_partial_matching['status'] == 'partial'
    assert res_partial_matching['points'] == 1.0
    
    res_none_matching = engine._calculate_matching_score(matching_q, {'+': 'Wrong', '//': 'Wrong'})
    assert res_none_matching['status'] == 'incorrect'
    assert res_none_matching['points'] == 0.0
    
    # Test intruder: correct and incorrect index selections
    res_correct_intruder = engine._calculate_intruder_score(intruder_q, [2])
    assert res_correct_intruder['status'] == 'correct'
    assert res_correct_intruder['points'] == 1.0
    
    res_wrong_intruder = engine._calculate_intruder_score(intruder_q, [0])
    assert res_wrong_intruder['status'] == 'incorrect'
    assert res_wrong_intruder['points'] == 0.0
    assert res_wrong_intruder['penalty'] == 0.25

def test_new_easy_questions_loading():
    # Assert that the new 50 questions are loaded in the database
    new_ids = set(range(10001, 10051))
    all_loaded_ids = {q['id'] for q in BASE64_QUESTIONS}
    
    loaded_new_ids = new_ids & all_loaded_ids
    assert len(loaded_new_ids) == 50
    
    # Check some fields on loaded new questions
    basics_blank = next(q for q in BASE64_QUESTIONS if q['id'] == 10001)
    assert basics_blank['type'] == 'simple_blank'
    assert basics_blank['topic'] == 'Python Basics'
    assert basics_blank['answer'] == 'append'
    
    basics_matching = next(q for q in BASE64_QUESTIONS if q['id'] == 10003)
    assert basics_matching['type'] == 'matching'
    assert basics_matching['pairs']['+'] == 'Addition'
