import os
import sys
import pytest

# Add src to python path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from core.coding_executor import evaluate_submission
from data.coding_questions.pandas import QUESTIONS as pandas_questions
from data.coding_questions.numpy import QUESTIONS as numpy_questions
from data.coding_questions.data_visualization import QUESTIONS as visualization_questions

def test_pandas_questions():
    # Verify that each pandas question's solution compiles and passes tests
    for question in pandas_questions:
        result = evaluate_submission(question, question['solution'])
        assert result['status'] == 'completed'
        assert result['public_result']['passed'] == result['public_result']['total']
        assert result['hidden_result']['passed'] == result['hidden_result']['total']
        assert result['score'] == question['points']

def test_numpy_questions():
    # Verify that each numpy question's solution compiles and passes tests
    for question in numpy_questions:
        result = evaluate_submission(question, question['solution'])
        assert result['status'] == 'completed'
        assert result['public_result']['passed'] == result['public_result']['total']
        assert result['hidden_result']['passed'] == result['hidden_result']['total']
        assert result['score'] == question['points']

def test_visualization_questions():
    # Verify that each data visualization question's solution compiles and passes tests
    for question in visualization_questions:
        result = evaluate_submission(question, question['solution'])
        assert result['status'] == 'completed'
        assert result['public_result']['passed'] == result['public_result']['total']
        assert result['hidden_result']['passed'] == result['hidden_result']['total']
        assert result['score'] == question['points']
        
        # Verify that output plot files were successfully created
        if question['id'] == 4099:
            assert os.path.exists('plot_sales.png')
            os.remove('plot_sales.png')
        elif question['id'] == 4100:
            assert os.path.exists('plot_expenses.png')
            os.remove('plot_expenses.png')
        elif question['id'] == 4106:
            assert os.path.exists('plot_age_hist.png')
            os.remove('plot_age_hist.png')
        elif question['id'] == 4108:
            assert os.path.exists('plot_salary_age.png')
            os.remove('plot_salary_age.png')
        elif question['id'] == 4112:
            assert os.path.exists('plot_multiline.png')
            os.remove('plot_multiline.png')
        elif question['id'] == 4113:
            assert os.path.exists('plot_salary_box.png')
            os.remove('plot_salary_box.png')
        elif question['id'] == 4118:
            assert os.path.exists('plot_dept_pie.png')
            os.remove('plot_dept_pie.png')
        elif question['id'] == 4119:
            assert os.path.exists('plot_sales_area.png')
            os.remove('plot_sales_area.png')

