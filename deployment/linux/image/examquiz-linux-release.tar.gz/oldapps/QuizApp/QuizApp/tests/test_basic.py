import os
import sys
import json
import pytest

# Add src to python path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from core.quiz_engine import QuizEngine
from core.attempt_tracker import _RC_PATH, get_attempts, record_attempt, can_attempt
from core.progression import is_passing_attempt, get_validation_difficulties

def test_passing_attempt():
    assert is_passing_attempt({"final_mark": 14.0}) is True
    assert is_passing_attempt({"final_mark": 13.9}) is False
    assert is_passing_attempt({"passed": True}) is True
    assert is_passing_attempt({"passed": False}) is False

def test_validation_difficulties():
    assert get_validation_difficulties("easy") == ["easy"]
    assert get_validation_difficulties("medium") == ["easy", "medium"]
    assert get_validation_difficulties("hard") == ["easy", "medium", "hard"]

def test_attempt_tracker(tmp_path):
    # Mock attempt tracker path to avoid modifying real attempts during test
    import core.attempt_tracker as tracker
    original_rc = tracker._RC_PATH
    temp_rc = tmp_path / "temp_quizmasterrc"
    tracker._RC_PATH = str(temp_rc)
    
    try:
        user = "test_candidate"
        assert get_attempts(user) == 0
        assert can_attempt(user) is True
        
        # Record attempts
        assert record_attempt(user) is True
        assert get_attempts(user) == 1
        
        assert record_attempt(user) is True
        assert record_attempt(user) is True
        assert get_attempts(user) == 3
        assert can_attempt(user) is False
        assert record_attempt(user) is False
    finally:
        tracker._RC_PATH = original_rc

def test_quiz_engine_scoring():
    config = {
        "passing_score": 70,
        "max_questions": 2,
    }
    questions = [
        {
            "id": "q1",
            "type": "yesno",
            "text": "Is Python dynamically typed?",
            "points": 2.0,
            "penalty": 1.0,
            "correct": True
        },
        {
            "id": "q2",
            "type": "mcq",
            "text": "Which of these are list methods?",
            "points": 3.0,
            "penalty": 1.0,
            "options": ["append", "add", "extend", "remove"],
            "correct": [0, 2, 3]
        }
    ]
    
    engine = QuizEngine(config, questions)
    engine.prepare_exam(2)
    assert len(engine.selected_questions) == 2
    
    # Identify which question is which
    q1 = [q for q in engine.selected_questions if q["original_id"] == "q1"][0]
    q2 = [q for q in engine.selected_questions if q["original_id"] == "q2"][0]
    
    # Submit correct answer to yes/no (q1)
    engine.submit_answer(q1["id"], True)
    
    # Submit correct answer to mcq (q2)
    user_indices = []
    for display_idx, mapping in q2["display_mapping"].items():
        if mapping["is_correct"]:
            user_indices.append(display_idx)
            
    engine.submit_answer(q2["id"], user_indices)
    
    score = engine.calculate_score()
    assert score["correct_count"] == 2
    assert score["passed"] is True

def test_leveling_system():
    from core.leveling_system import match_canonical_topic, calculate_leveling_data
    
    # Verify topic matching
    assert match_canonical_topic("Introduction to Pandas and Data Science") == "Pandas"
    assert match_canonical_topic("Numpy Matrices") == "NumPy"
    assert match_canonical_topic("Object Oriented Programming Class") == "Object-Oriented Programming (OOP / POO)"
    
    # Mock history
    mock_history = [
        {"assessment_type": "theoretical", "target_topic": "Pandas", "final_mark": 16.5},
        {"assessment_type": "practical", "target_topic": "NumPy", "final_mark": 18.0},
    ]
    
    data = calculate_leveling_data(mock_history)
    assert data["xp"] == 60
    assert data["level"] == 1
    assert data["unlocked_badges"] == 5


