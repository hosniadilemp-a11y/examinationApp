# make.py - Python-based Makefile alternative
import os
import sys
import subprocess
import shutil
from pathlib import Path

class Make:
    def __init__(self):
        self.project_root = Path(__file__).parent
        
    def install(self):
        """Install dependencies"""
        print("📦 Installing dependencies...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
        print("✅ Dependencies installed!")
    
    def build(self):
        """Build Windows executable"""
        print("🔨 Building Windows executable...")
        
        # Clean previous builds
        self.clean()
        
        # Build command
        cmd = [
            'pyinstaller',
            '--name=QuizApp',
            '--windowed',
            '--onefile',
            '--icon=assets/icon.ico',
            '--add-data=src/data;data',
            '--add-data=src/core;core',
            '--add-data=src/gui;gui',
            '--add-data=src/utils;utils',
            '--hidden-import=PyQt6.sip',
            '--clean',
            '--noconsole',
            'src/main.py'
        ]
        
        subprocess.run(cmd)
        
        # Check if build succeeded
        exe_path = self.project_root / 'dist' / 'QuizApp.exe'
        if exe_path.exists():
            print(f"✅ Build successful: {exe_path}")
        else:
            print("❌ Build failed!")
    
    def run(self):
        """Run the application in development mode"""
        print("🚀 Starting application...")
        subprocess.run([sys.executable, "src/main.py"])
    
    def test(self):
        """Run tests"""
        print("🧪 Running tests...")
        subprocess.run([sys.executable, "-m", "pytest", "tests/"])
    
    def clean(self):
        """Clean build artifacts"""
        print("🧹 Cleaning build artifacts...")
        folders = ['build', 'dist', '__pycache__']
        for folder in folders:
            path = self.project_root / folder
            if path.exists():
                shutil.rmtree(path)
                print(f"  Removed {folder}/")
        
        # Remove .spec file
        spec_file = self.project_root / 'QuizApp.spec'
        if spec_file.exists():
            spec_file.unlink()
        
        # Clean pycache in subdirectories
        for pycache in self.project_root.rglob('__pycache__'):
            shutil.rmtree(pycache)
        
        print("✅ Clean complete!")
    
    def help(self):
        """Show help message"""
        print("""
        Quiz App Build System
        
        Commands:
          python make.py install    - Install dependencies
          python make.py build      - Build Windows executable
          python make.py run        - Run in development mode
          python make.py test       - Run tests
          python make.py clean      - Clean build artifacts
          python make.py help       - Show this message
        
        Examples:
          python make.py install    # First time setup
          python make.py build      # Create QuizApp.exe
          python make.py run        # Test the app
        """)

if __name__ == "__main__":
    make = Make()
    
    if len(sys.argv) < 2:
        make.help()
        sys.exit(1)
    
    command = sys.argv[1].lower()
    
    if command == "install":
        make.install()
    elif command == "build":
        make.build()
    elif command == "run":
        make.run()
    elif command == "test":
        make.test()
    elif command == "clean":
        make.clean()
    elif command == "help":
        make.help()
    else:
        print(f"Unknown command: {command}")
        make.help()