# QuizApp - Secure Quiz Master

QuizApp is a comprehensive, secure platform for conducting training sessions and official exams. It features a robust encryption system for quiz data, a level-based training progression, and automated PDF result generation.

## 🚀 Key Features

- **Dual Modes**: 
    - **Training Mode**: Practice specific topics and difficulties. Track your progress and evolution over time.
    - **Exam Mode**: Secure, timed environment for official assessments with encrypted quiz files and PDF certificates.
- **Dynamic Content**: Highly configurable questions with support for multiple topics (NumPy, Pandas, OOP, etc.) and difficulty levels (Easy to Very Hard).
- **Secure Data**: Quiz files are encrypted to prevent unauthorized access.
- **Analytics**: Comprehensive results analysis including evolution charts and topic ranking.
- **Cross-Platform**: Built to run on Windows, macOS, and Linux.

## 🛠️ Setup and Installation

### Prerequisites
- Python 3.8 or higher
- [PyQt6](https://pypi.org/project/PyQt6/) for the graphical interface
- [ReportLab](https://pypi.org/project/reportlab/) for PDF generation

### Quick Start
1. **Clone the repository**:
   ```bash
   git clone https://github.com/hosniadilemp-a11y/QuizAPP.git
   cd QuizAPP
   ```

2. **Initialize Environment**:
   ```bash
   python make.py install
   ```

3. **Run in Development Mode**:
   ```bash
   python make.py run
   ```

## 🏗️ Build and Distribution

Use the built-in build system to generate stand-alone executables:

- **Clean build artifacts**: `python make.py clean`
- **Create Windows Executable**: `python make.py build`
- **Run Tests**: `python make.py test`

## 📂 Project Structure

- `src/`: Core application logic, GUI components, and data management.
- `assets/`: Icons, images, and visual resources.
- `exams/`: Encrypted quiz files for official exams.
- `results/`: Directory for saved training history and generated exam PDFs.
- `tools/`: Administrative tools for exam management and code generation.

## 🛤️ Roadmap

- [x] Level-based training progression
- [x] Topic-specific analytics
- [x] Secure exam coding system
- [ ] Multi-student performance tracking
- [ ] Online synchronization for results

## 📄 License

This project is private and for internal use only.
