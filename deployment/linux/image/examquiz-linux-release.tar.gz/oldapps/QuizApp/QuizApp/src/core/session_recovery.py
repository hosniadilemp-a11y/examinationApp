import os
import json

CACHE_PATH = os.path.join("results", "temp_session.json")

def save_session(session_type, user_info, time_remaining, current_index, flagged_questions, **kwargs):
    os.makedirs("results", exist_ok=True)
    state = {
        "session_type": session_type,
        "user_info": user_info,
        "time_remaining": time_remaining,
        "current_index": current_index,
        "flagged_questions": list(flagged_questions),
    }
    state.update(kwargs)
    try:
        with open(CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error saving temp session: {e}")

def load_session():
    if os.path.exists(CACHE_PATH):
        try:
            with open(CACHE_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading temp session: {e}")
    return None

def clear_session():
    if os.path.exists(CACHE_PATH):
        try:
            os.remove(CACHE_PATH)
        except Exception:
            pass
