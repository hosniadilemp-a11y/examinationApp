#!/usr/bin/env python3
"""
Standalone testing interface for QuizApp.
Allows testing all theoretical and coding questions without security restrictions.
"""

import os
import sys
import random

# Add src directory to Python path
src_dir = os.path.dirname(os.path.abspath(__file__))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QCheckBox,
                             QRadioButton, QButtonGroup, QSpinBox, QFrame,
                             QGridLayout, QScrollArea, QMessageBox, QTabWidget,
                             QTableWidget, QTableWidgetItem, QHeaderView)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QPalette

from core.quiz_engine import QuizEngine
from data import questions as builtin_questions
from data.coding_questions import CODING_QUESTIONS
from gui.quiz_window import QuizWindow
from gui.coding_window import CodingWindow
from gui.results_window import ResultsWindow
from gui.fused_results_window import FusedResultsWindow

# Supported topics
TOPICS = [
    "Basics",
    "Data Types",
    "Control Flow",
    "List Comprehension",
    "Modules",
    "Input/Output",
    "OOP",
    "NumPy",
    "Pandas",
    "Data Visualization",
]

DIFFICULTIES = ["easy", "medium", "hard", "very hard"]
DIFFICULTY_LABELS = {
    "easy": "Facile",
    "medium": "Moyen",
    "hard": "Difficile",
    "very hard": "Très difficile"
}


class TestLauncherWindow(QMainWindow):
    start_requested = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.topic_checkboxes = {}
        self.difficulty_checkboxes = {}
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("🧪 SecureQuizMaster - Interface de Test Standalone")
        self.resize(1000, 950)
        self.setMinimumSize(950, 850)
        
        # Central widget
        central_widget = QWidget()
        central_widget.setObjectName("centralWidget")
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)

        # Header Section
        header_frame = QFrame()
        header_frame.setObjectName("headerFrame")
        header_layout = QVBoxLayout(header_frame)
        header_layout.setContentsMargins(0, 0, 0, 10)
        header_layout.setSpacing(5)
        
        title = QLabel("🧪 Interface de Test de Questions")
        title.setStyleSheet("color: #0f172a; font-size: 24px; font-weight: 800;")
        header_layout.addWidget(title)
        
        subtitle = QLabel("Configurez vos paramètres et testez les questions sans contraintes de sécurité.")
        subtitle.setStyleSheet("color: #475569; font-size: 13px; font-weight: 500;")
        header_layout.addWidget(subtitle)
        main_layout.addWidget(header_frame)

        # Add Stats Panel Widget
        self.stats_panel = self.create_stats_panel()
        main_layout.addWidget(self.stats_panel)

        # Config Panel Scroll Area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        config_widget = QWidget()
        config_widget.setObjectName("configWidget")
        config_layout = QVBoxLayout(config_widget)
        config_layout.setContentsMargins(0, 0, 0, 0)
        config_layout.setSpacing(15)

        # Topic Selector Card
        topics_card = QFrame()
        topics_card.setProperty("class", "card")
        topics_layout = QVBoxLayout(topics_card)
        topics_layout.setContentsMargins(15, 12, 15, 12)
        topics_layout.setSpacing(10)
        
        topics_header = QHBoxLayout()
        topics_title = QLabel("📚 Thèmes de Questions")
        topics_title.setStyleSheet("color: #0f172a; font-size: 14px; font-weight: 700;")
        topics_header.addWidget(topics_title)
        topics_header.addStretch()
        
        select_all_btn = QPushButton("Tout Sélectionner")
        select_all_btn.setObjectName("linkBtn")
        select_all_btn.clicked.connect(self.select_all_topics)
        topics_header.addWidget(select_all_btn)
        
        deselect_all_btn = QPushButton("Tout Désélectionner")
        deselect_all_btn.setObjectName("linkBtn")
        deselect_all_btn.clicked.connect(self.deselect_all_topics)
        topics_header.addWidget(deselect_all_btn)
        
        topics_layout.addLayout(topics_header)
        
        grid_layout = QGridLayout()
        grid_layout.setSpacing(8)
        for idx, topic in enumerate(TOPICS):
            cb = QCheckBox(topic)
            cb.setChecked(True)
            cb.stateChanged.connect(self.update_question_counts)
            row = idx // 2
            col = idx % 2
            grid_layout.addWidget(cb, row, col)
            self.topic_checkboxes[topic] = cb
        topics_layout.addLayout(grid_layout)
        config_layout.addWidget(topics_card)

        # Difficulty Selector Card
        diff_card = QFrame()
        diff_card.setProperty("class", "card")
        diff_layout = QVBoxLayout(diff_card)
        diff_layout.setContentsMargins(15, 12, 15, 12)
        diff_layout.setSpacing(8)
        
        diff_title = QLabel("🎚️ Difficultés")
        diff_title.setStyleSheet("color: #0f172a; font-size: 14px; font-weight: 700;")
        diff_layout.addWidget(diff_title)
        
        diff_options = QHBoxLayout()
        diff_options.setSpacing(20)
        for diff in DIFFICULTIES:
            cb = QCheckBox(DIFFICULTY_LABELS[diff])
            cb.setChecked(True)
            cb.stateChanged.connect(self.update_question_counts)
            diff_options.addWidget(cb)
            self.difficulty_checkboxes[diff] = cb
        diff_options.addStretch()
        diff_layout.addLayout(diff_options)
        config_layout.addWidget(diff_card)

        # Question Type Selector Card
        type_card = QFrame()
        type_card.setProperty("class", "card")
        type_layout = QVBoxLayout(type_card)
        type_layout.setContentsMargins(15, 12, 15, 12)
        type_layout.setSpacing(8)
        
        type_title = QLabel("🧪 Type de Question")
        type_title.setStyleSheet("color: #0f172a; font-size: 14px; font-weight: 700;")
        type_layout.addWidget(type_title)
        
        self.type_group = QButtonGroup(self)
        type_options_layout = QHBoxLayout()
        type_options_layout.setSpacing(20)
        
        self.radio_theoretical = QRadioButton("Théorique (QCM)")
        self.radio_theoretical.setChecked(True)
        self.radio_theoretical.toggled.connect(self.update_question_counts)
        self.type_group.addButton(self.radio_theoretical)
        type_options_layout.addWidget(self.radio_theoretical)
        
        self.radio_practical = QRadioButton("Pratique (Coding)")
        self.radio_practical.toggled.connect(self.update_question_counts)
        self.type_group.addButton(self.radio_practical)
        type_options_layout.addWidget(self.radio_practical)
        
        self.radio_both = QRadioButton("Les deux (Théorique + Pratique)")
        self.radio_both.toggled.connect(self.update_question_counts)
        self.type_group.addButton(self.radio_both)
        type_options_layout.addWidget(self.radio_both)
        
        type_options_layout.addStretch()
        type_layout.addLayout(type_options_layout)
        config_layout.addWidget(type_card)

        # Question Sub-Type Selector Card (for Theoretical Questions)
        self.subtype_card = QFrame()
        self.subtype_card.setProperty("class", "card")
        subtype_layout = QVBoxLayout(self.subtype_card)
        subtype_layout.setContentsMargins(15, 12, 15, 12)
        subtype_layout.setSpacing(8)
        
        subtype_title = QLabel("📝 Sous-types de Questions Théoriques")
        subtype_title.setStyleSheet("color: #0f172a; font-size: 14px; font-weight: 700;")
        subtype_layout.addWidget(subtype_title)
        
        self.subtype_checkboxes = {}
        SUBTYPES = [
            ("mcq", "QCM (mcq)"),
            ("yesno", "Vrai / Faux (yesno)"),
            ("simple_blank", "Compléter le blanc (simple_blank)"),
            ("matching", "Associer les colonnes (matching)"),
            ("intruder", "Trouver l'intrus (intruder)")
        ]
        
        subtype_grid = QGridLayout()
        subtype_grid.setSpacing(8)
        for idx, (subtype_id, subtype_label) in enumerate(SUBTYPES):
            cb = QCheckBox(subtype_label)
            cb.setChecked(True)
            cb.stateChanged.connect(self.update_question_counts)
            self.subtype_checkboxes[subtype_id] = cb
            row = idx // 2
            col = idx % 2
            subtype_grid.addWidget(cb, row, col)
            
        subtype_layout.addLayout(subtype_grid)
        config_layout.addWidget(self.subtype_card)

        # Count & Time Card
        count_card = QFrame()
        count_card.setProperty("class", "card")
        count_layout = QGridLayout(count_card)
        count_layout.setContentsMargins(15, 12, 15, 12)
        count_layout.setHorizontalSpacing(15)
        count_layout.setVerticalSpacing(10)
        
        cnt_lbl = QLabel("Nombre de questions:")
        cnt_lbl.setStyleSheet("color: #334155; font-weight: 600;")
        count_layout.addWidget(cnt_lbl, 0, 0)
        
        self.question_count_spin = QSpinBox()
        self.question_count_spin.setRange(1, 100)
        self.question_count_spin.setValue(10)
        count_layout.addWidget(self.question_count_spin, 0, 1)
        
        time_lbl = QLabel("Temps limite (minutes):")
        time_lbl.setStyleSheet("color: #334155; font-weight: 600;")
        count_layout.addWidget(time_lbl, 1, 0)
        
        self.duration_spin = QSpinBox()
        self.duration_spin.setRange(1, 180)
        self.duration_spin.setValue(15)
        count_layout.addWidget(self.duration_spin, 1, 1)
        
        # Available summary label
        self.pool_info = QLabel("Matching questions count: --")
        self.pool_info.setStyleSheet("color: #0284c7; font-size: 11px; font-weight: 700;")
        count_layout.addWidget(self.pool_info, 2, 0, 1, 2)
        
        config_layout.addWidget(count_card)
        config_widget.setLayout(config_layout)
        scroll_area.setWidget(config_widget)
        main_layout.addWidget(scroll_area)

        # Action Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)
        
        self.close_btn = QPushButton("🚪 Fermer")
        self.close_btn.setObjectName("closeBtn")
        self.close_btn.clicked.connect(self.close)
        btn_layout.addWidget(self.close_btn, 1)
        
        self.start_btn = QPushButton("🚀 Lancer le Test")
        self.start_btn.setObjectName("startBtn")
        self.start_btn.clicked.connect(self.on_start_clicked)
        btn_layout.addWidget(self.start_btn, 2)
        main_layout.addLayout(btn_layout)

        # Dark Style sheet (Harmonious Modern Sleek Style)
        self.setStyleSheet("""
            QWidget#centralWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #f8fafc, stop:1 #e2e8f0);
            }
            QFrame.card {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 10px;
            }
            QCheckBox {
                color: #334155;
                font-size: 13px;
                font-weight: 500;
            }
            QCheckBox:hover {
                color: #0f172a;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border: 1px solid #cbd5e1;
                border-radius: 4px;
                background: #ffffff;
            }
            QCheckBox::indicator:checked {
                border-color: #0284c7;
                background: #0284c7;
            }
            QRadioButton {
                color: #334155;
                font-size: 13px;
                font-weight: 500;
            }
            QRadioButton:hover {
                color: #0f172a;
            }
            QRadioButton::indicator {
                width: 16px;
                height: 16px;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                background: #ffffff;
            }
            QRadioButton::indicator:checked {
                border-color: #0284c7;
                background: #0284c7;
            }
            QSpinBox {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 5px;
                color: #0f172a;
                padding: 4px 8px;
                font-weight: bold;
                font-size: 13px;
            }
            QSpinBox:focus {
                border-color: #0284c7;
            }
            QPushButton#linkBtn {
                color: #0284c7;
                background: transparent;
                border: none;
                font-size: 12px;
                font-weight: bold;
                padding: 2px;
            }
            QPushButton#linkBtn:hover {
                color: #0369a1;
                text-decoration: underline;
            }
            QPushButton#closeBtn {
                background-color: transparent;
                color: #ef4444;
                border: 2px solid #ef4444;
                border-radius: 8px;
                padding: 10px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton#closeBtn:hover {
                background-color: rgba(239, 68, 68, 0.1);
            }
            QPushButton#startBtn {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3b82f6, stop:1 #06b6d4);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px;
                font-weight: 800;
                font-size: 15px;
            }
            QPushButton#startBtn:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563eb, stop:1 #0891b2);
            }
            QPushButton#startBtn:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1d4ed8, stop:1 #0e7490);
            }
            QTableWidget {
                background-color: #ffffff;
                gridline-color: #e2e8f0;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
            }
            QTableWidget::item {
                padding: 4px;
                border: none;
            }
            QTableWidget::item:selected {
                background-color: #38bdf8;
                color: #0f172a;
            }
            QHeaderView::section {
                background-color: #f1f5f9;
                color: #0f172a;
                font-weight: bold;
                border: 1px solid #cbd5e1;
                padding: 4px;
            }
            QLabel {
                border: none;
                background: transparent;
            }
        """)
        
        self.update_question_counts()

    def create_stats_panel(self):
        # Initialize filter state
        self.stats_selected_topic = None
        self.stats_selected_type = None
        self.stats_selected_difficulty = None

        panel = QWidget()
        panel.setObjectName("statsPanel")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(10, 10, 10, 10)
        panel_layout.setSpacing(8)

        # Header with total count label and reset button
        header_layout = QHBoxLayout()
        self.tot_lbl = QLabel()
        self.tot_lbl.setStyleSheet("color: #0f172a; font-size: 14px; font-weight: bold;")
        header_layout.addWidget(self.tot_lbl)
        
        header_layout.addStretch()
        
        self.reset_stats_btn = QPushButton("❌ Réinitialiser les filtres")
        self.reset_stats_btn.setStyleSheet("""
            QPushButton {
                background-color: #f1f5f9;
                color: #475569;
                border: 1px solid #cbd5e1;
                border-radius: 4px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #e2e8f0;
                color: #0f172a;
            }
            QPushButton:pressed {
                background-color: #cbd5e1;
            }
            QPushButton:disabled {
                color: #cbd5e1;
                border-color: #f1f5f9;
                background-color: #f8fafc;
            }
        """)
        self.reset_stats_btn.clicked.connect(self.reset_stats_filters)
        header_layout.addWidget(self.reset_stats_btn)
        
        panel_layout.addLayout(header_layout)

        # Horizontal layout for the three tables
        tables_layout = QHBoxLayout()
        tables_layout.setSpacing(12)

        # Helper function to create blank tables
        def make_table(headers, first_col_width):
            table = QTableWidget()
            table.setColumnCount(len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.verticalHeader().setVisible(False)
            table.setAlternatingRowColors(True)
            table.setFixedHeight(230)
            table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
            table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
            table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
            
            header = table.horizontalHeader()
            header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            header.setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
            table.setColumnWidth(0, first_col_width)
            return table

        # Table 1: By Topics
        topic_headers = ["Thème", "Théo", "Prat", "Total"]
        self.topic_table = make_table(topic_headers, 170)
        self.topic_table.cellClicked.connect(self.on_topic_cell_clicked)
        tables_layout.addWidget(self.topic_table, 2)

        # Table 2: By Question Type
        type_headers = ["Type de Question", "Total"]
        self.type_table = make_table(type_headers, 170)
        self.type_table.cellClicked.connect(self.on_type_cell_clicked)
        tables_layout.addWidget(self.type_table, 1)

        # Table 3: By Difficulty
        diff_headers = ["Difficulté", "Théo", "Prat", "Total"]
        self.diff_table = make_table(diff_headers, 100)
        self.diff_table.cellClicked.connect(self.on_diff_cell_clicked)
        tables_layout.addWidget(self.diff_table, 1)

        panel_layout.addLayout(tables_layout)
        
        # Populate initial stats
        self.update_stats_display()
        
        return panel

    def reset_stats_filters(self):
        self.stats_selected_topic = None
        self.stats_selected_type = None
        self.stats_selected_difficulty = None
        self.update_stats_display()

    def on_topic_cell_clicked(self, row, col):
        from core.exam_code import TOPIC_ORDER
        topic = TOPIC_ORDER[row]
        if self.stats_selected_topic == topic:
            self.stats_selected_topic = None
        else:
            self.stats_selected_topic = topic
        self.topic_table.clearSelection()
        self.update_stats_display()

    def on_type_cell_clicked(self, row, col):
        type_keys = ['mcq', 'yesno', 'simple_blank', 'matching', 'intruder', 'coding']
        q_type = type_keys[row]
        if self.stats_selected_type == q_type:
            self.stats_selected_type = None
        else:
            self.stats_selected_type = q_type
        self.type_table.clearSelection()
        self.update_stats_display()

    def on_diff_cell_clicked(self, row, col):
        diff = DIFFICULTIES[row]
        if self.stats_selected_difficulty == diff:
            self.stats_selected_difficulty = None
        else:
            self.stats_selected_difficulty = diff
        self.diff_table.clearSelection()
        self.update_stats_display()

    def update_stats_display(self):
        from core.leveling_system import match_canonical_topic
        from core.exam_code import TOPIC_ORDER
        
        # Enable/disable reset button
        has_active_filter = (self.stats_selected_topic is not None or 
                             self.stats_selected_type is not None or 
                             self.stats_selected_difficulty is not None)
        self.reset_stats_btn.setEnabled(has_active_filter)
        
        # We need to compile the statistics under the current filter combination
        total_theo = 0
        total_prac = 0
        
        db_by_topic = {t: {'theoretical': 0, 'practical': 0, 'total': 0} for t in TOPIC_ORDER}
        db_by_type = {
            'mcq': 0,
            'yesno': 0,
            'simple_blank': 0,
            'matching': 0,
            'intruder': 0,
            'coding': 0
        }
        db_by_difficulty = {d: {'theoretical': 0, 'practical': 0, 'total': 0} for d in DIFFICULTIES}
        
        # 1. Process Theoretical questions
        for q in builtin_questions.BASE64_QUESTIONS:
            t_canonical = match_canonical_topic(q.get('topic'))
            diff = q.get('difficulty', 'easy').lower()
            q_type = q.get('type', 'mcq')
            
            # Check filter
            if self.stats_selected_topic and t_canonical != self.stats_selected_topic:
                continue
            if self.stats_selected_type and q_type != self.stats_selected_type:
                continue
            if self.stats_selected_difficulty and diff != self.stats_selected_difficulty:
                continue
                
            total_theo += 1
            if t_canonical in db_by_topic:
                db_by_topic[t_canonical]['theoretical'] += 1
                db_by_topic[t_canonical]['total'] += 1
            if diff in db_by_difficulty:
                db_by_difficulty[diff]['theoretical'] += 1
                db_by_difficulty[diff]['total'] += 1
            if q_type in db_by_type:
                db_by_type[q_type] += 1
                
        # 2. Process Practical questions
        for q in CODING_QUESTIONS:
            t_canonical = match_canonical_topic(q.get('topic'))
            diff = q.get('difficulty', 'easy').lower()
            q_type = 'coding'
            
            # Check filter
            if self.stats_selected_topic and t_canonical != self.stats_selected_topic:
                continue
            if self.stats_selected_type and q_type != self.stats_selected_type:
                continue
            if self.stats_selected_difficulty and diff != self.stats_selected_difficulty:
                continue
                
            total_prac += 1
            if t_canonical in db_by_topic:
                db_by_topic[t_canonical]['practical'] += 1
                db_by_topic[t_canonical]['total'] += 1
            if diff in db_by_difficulty:
                db_by_difficulty[diff]['practical'] += 1
                db_by_difficulty[diff]['total'] += 1
            if q_type in db_by_type:
                db_by_type[q_type] += 1

        # Update Header label
        total_q = total_theo + total_prac
        filter_str = ""
        if has_active_filter:
            filters = []
            if self.stats_selected_topic:
                filters.append(f"Thème: {self.stats_selected_topic}")
            if self.stats_selected_type:
                type_name_map = {
                    'mcq': 'QCM', 'yesno': 'Vrai/Faux', 'simple_blank': 'Blanc',
                    'matching': 'Associer', 'intruder': 'Intrus', 'coding': 'Coding'
                }
                filters.append(f"Type: {type_name_map.get(self.stats_selected_type, self.stats_selected_type)}")
            if self.stats_selected_difficulty:
                diff_labels = {'easy': 'Facile', 'medium': 'Moyen', 'hard': 'Difficile', 'very hard': 'Très difficile'}
                filters.append(f"Difficulté: {diff_labels.get(self.stats_selected_difficulty, self.stats_selected_difficulty)}")
            filter_str = f" [Filtré par: {', '.join(filters)}]"
            
        self.tot_lbl.setText(f"📊 <b>Statistiques de la base de données :</b> {total_q} Questions ({total_theo} Théoriques | {total_prac} Pratiques){filter_str}")

        # Update Table 1: Topics
        self.topic_table.setRowCount(len(TOPIC_ORDER))
        for row_idx, topic in enumerate(TOPIC_ORDER):
            is_sel = (self.stats_selected_topic == topic)
            row_data = [
                topic,
                db_by_topic[topic]['theoretical'],
                db_by_topic[topic]['practical'],
                db_by_topic[topic]['total']
            ]
            self._fill_row(self.topic_table, row_idx, row_data, is_sel)

        # Update Table 2: Question Type
        type_name_map = {
            'mcq': "QCM (mcq)",
            'yesno': "Vrai/Faux (yesno)",
            'simple_blank': "Blanc (simple_blank)",
            'matching': "Associer (matching)",
            'intruder': "Intrus (intruder)",
            'coding': "Coding (coding)"
        }
        type_keys = ['mcq', 'yesno', 'simple_blank', 'matching', 'intruder', 'coding']
        self.type_table.setRowCount(len(type_keys))
        for row_idx, q_type in enumerate(type_keys):
            is_sel = (self.stats_selected_type == q_type)
            row_data = [
                type_name_map[q_type],
                db_by_type[q_type]
            ]
            self._fill_row(self.type_table, row_idx, row_data, is_sel)

        # Update Table 3: Difficulty
        diff_keys = DIFFICULTIES
        diff_labels = DIFFICULTY_LABELS
        self.diff_table.setRowCount(len(diff_keys))
        for row_idx, diff in enumerate(diff_keys):
            is_sel = (self.stats_selected_difficulty == diff)
            row_data = [
                diff_labels[diff],
                db_by_difficulty[diff]['theoretical'],
                db_by_difficulty[diff]['practical'],
                db_by_difficulty[diff]['total']
            ]
            self._fill_row(self.diff_table, row_idx, row_data, is_sel)

    def _fill_row(self, table, row_idx, row_data, is_selected):
        for col_idx, value in enumerate(row_data):
            item = QTableWidgetItem(str(value))
            # Set alignment
            if col_idx > 0:
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            else:
                item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            
            # Styling for selected filters
            if is_selected:
                font = QFont()
                font.setBold(True)
                item.setFont(font)
                item.setBackground(QColor("#dbeafe")) # Elegant blue tint
                item.setForeground(QColor("#1e3a8a")) # Dark blue text
            else:
                # Normal styling
                item.setBackground(QColor(Qt.GlobalColor.transparent))
                item.setForeground(QColor("#334155")) # Slate-700
                
            table.setItem(row_idx, col_idx, item)

    def get_selected_topics(self):
        return [t for t, cb in self.topic_checkboxes.items() if cb.isChecked()]

    def get_selected_difficulties(self):
        return [d for d, cb in self.difficulty_checkboxes.items() if cb.isChecked()]

    def get_selected_subtypes(self):
        return [st for st, cb in self.subtype_checkboxes.items() if cb.isChecked()]

    def select_all_topics(self):
        for cb in self.topic_checkboxes.values():
            cb.setChecked(True)

    def deselect_all_topics(self):
        for cb in self.topic_checkboxes.values():
            cb.setChecked(False)

    def count_matching_questions(self, topics, difficulties, assessment_type, subtypes):
        from core.leveling_system import match_canonical_topic
        canonical_topics = {match_canonical_topic(t) for t in topics if match_canonical_topic(t)}
        difficulty_set = set(difficulties)
        subtype_set = set(subtypes)
        
        th_count = 0
        pr_count = 0
        
        if assessment_type != 'practical':
            # Count theoretical matching questions with specific type
            th_count = sum(
                1 for q in builtin_questions.BASE64_QUESTIONS
                if match_canonical_topic(q.get('topic', 'Unknown')) in canonical_topics
                and q.get('difficulty', 'unknown') in difficulty_set
                and q.get('type') in subtype_set
            )
            
        if assessment_type != 'theoretical':
            # Count practical coding matching questions
            pr_count = sum(
                1 for q in CODING_QUESTIONS
                if match_canonical_topic(q.get('topic')) in canonical_topics
                and q.get('difficulty') in difficulty_set
            )
            
        return th_count, pr_count

    def update_question_counts(self):
        topics = self.get_selected_topics()
        difficulties = self.get_selected_difficulties()
        subtypes = self.get_selected_subtypes()
        
        assessment_type = 'theoretical'
        if self.radio_practical.isChecked():
            assessment_type = 'practical'
        elif self.radio_both.isChecked():
            assessment_type = 'both'
            
        is_practical = (assessment_type == 'practical')
        if hasattr(self, 'subtype_card'):
            self.subtype_card.setVisible(not is_practical)
            
        th_count, pr_count = self.count_matching_questions(topics, difficulties, assessment_type, subtypes)
        
        if assessment_type == 'theoretical':
            total_matching = th_count
            self.pool_info.setText(f"Questions théoriques disponibles: {th_count}")
        elif assessment_type == 'practical':
            total_matching = pr_count
            self.pool_info.setText(f"Questions coding disponibles: {pr_count}")
        else:
            total_matching = min(th_count, pr_count)
            self.pool_info.setText(f"Disponibles pour test complet: {th_count} théoriques | {pr_count} coding")
            
        max_val = max(1, total_matching)
        self.question_count_spin.setMaximum(max_val)
        if self.question_count_spin.value() > max_val:
            self.question_count_spin.setValue(max_val)

    def on_start_clicked(self):
        topics = self.get_selected_topics()
        difficulties = self.get_selected_difficulties()
        subtypes = self.get_selected_subtypes()
        
        if not topics:
            QMessageBox.warning(self, "Erreur", "Sélectionnez au moins un thème.")
            return
        if not difficulties:
            QMessageBox.warning(self, "Erreur", "Sélectionnez au moins une difficulté.")
            return
            
        assessment_type = 'theoretical'
        if self.radio_practical.isChecked():
            assessment_type = 'practical'
        elif self.radio_both.isChecked():
            assessment_type = 'both'
            
        if assessment_type != 'practical' and not subtypes:
            QMessageBox.warning(self, "Erreur", "Sélectionnez au moins un sous-type de question théorique.")
            return
            
        q_count = self.question_count_spin.value()
        duration = self.duration_spin.value()
        
        user_info = {
            'first_name': 'Test',
            'last_name': 'User',
            'full_name': 'Test User',
            'specialty': 'Test Mode',
            'question_count': q_count,
            'nbr_question': q_count,
            'duration': duration,
            'mode': 'test',
            'assessment_type': assessment_type,
            'selected_topics': topics,
            'selected_difficulties': difficulties,
            'selected_subtypes': subtypes,
            'test_mode': True
        }
        self.start_requested.emit(user_info)


class TestController:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setStyle("Fusion")
        
        # Set fonts
        font = QFont("system-ui")
        font.setFamilies(["system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"])
        font.setPointSize(10)
        self.app.setFont(font)
        
        self.launcher = TestLauncherWindow()
        self.launcher.start_requested.connect(self.on_start_requested)
        self.launcher.show()
        
        self.quiz_window = None
        self.coding_window = None
        self.results_window = None
        self.fused_results_window = None
        self.user_info = None
        self.exam_data = None
        
    def start(self):
        sys.exit(self.app.exec())
        
    def on_start_requested(self, user_info):
        self.user_info = user_info
        self.launcher.close()
        
        if user_info['assessment_type'] == 'practical':
            self.launch_coding()
        else:
            self.launch_quiz()
            
    def launch_quiz(self):
        from core.leveling_system import match_canonical_topic
        canonical_topics = {match_canonical_topic(t) for t in self.user_info['selected_topics'] if match_canonical_topic(t)}
        difficulty_set = set(self.user_info['selected_difficulties'])
        subtype_set = set(self.user_info.get('selected_subtypes', []))
        
        # Retrieve all theoretical questions
        all_questions = [
            q for q in builtin_questions.BASE64_QUESTIONS
            if match_canonical_topic(q.get('topic', 'Unknown')) in canonical_topics
            and q.get('difficulty', 'unknown') in difficulty_set
            and q.get('type') in subtype_set
        ]
        
        self.exam_data = {
            'config': {
                'title': "Mode Test - Théorique",
                'duration': self.user_info['duration'],
                'points_per_question': 1.0,
                'penalty_per_question': 0.0,
                'max_questions': self.user_info['question_count'],
                'passing_score': 70.0,
                'shuffle_questions': True,
                'shuffle_options': True,
                'options_per_question': 4,
            },
            'questions': all_questions
        }
        
        self.quiz_engine = QuizEngine(self.exam_data['config'], self.exam_data['questions'])
        self.quiz_engine.prepare_exam(self.user_info['question_count'])
        
        self.quiz_window = QuizWindow(self.quiz_engine, self.user_info, self.exam_data['config'])
        self.quiz_window.exam_submitted.connect(self.on_quiz_submitted)
        self.quiz_window.show()
        
    def on_quiz_submitted(self, results):
        score_result = self.quiz_engine.calculate_score()
        if self.user_info['assessment_type'] == 'both':
            self.theoretical_score_result = score_result
            self.theoretical_engine = self.quiz_engine
            if self.quiz_window:
                self.quiz_window.close()
                self.quiz_window = None
            self.launch_coding()
        else:
            self.show_results(score_result)
            
    def launch_coding(self):
        from core.leveling_system import match_canonical_topic
        canonical_topics = {match_canonical_topic(t) for t in self.user_info['selected_topics'] if match_canonical_topic(t)}
        difficulty_set = set(self.user_info['selected_difficulties'])
        
        selected_coding = [
            q for q in CODING_QUESTIONS
            if match_canonical_topic(q.get('topic')) in canonical_topics
            and q.get('difficulty') in difficulty_set
        ]
        
        random.shuffle(selected_coding)
        selected_coding = selected_coding[:self.user_info['question_count']]
        
        # Assign points per difficulty
        for q in selected_coding:
            d = q.get("difficulty", "easy").lower()
            if d == "easy": q["points"] = 2.0
            elif d == "medium": q["points"] = 3.0
            elif d == "hard": q["points"] = 4.0
            elif d == "very hard": q["points"] = 5.0
            else: q["points"] = 2.0
            
        self.coding_window = CodingWindow(selected_coding, self.user_info)
        self.coding_window.coding_finished.connect(self.on_coding_finished)
        self.coding_window.show()
        
    def on_coding_finished(self, questions, submission_results):
        score_result = self.calculate_practical_score(questions, submission_results)
        
        class DummyQuizEngine:
            def __init__(self, q, d):
                self.selected_questions = q
                self.score_details = d
                
        self.coding_engine = DummyQuizEngine(questions, score_result['details'])
        
        if self.user_info['assessment_type'] == 'both':
            self.coding_score_result = score_result
            if self.coding_window:
                self.coding_window.coding_finished_flag = True
                self.coding_window.close()
                self.coding_window = None
            self.show_fused_results()
        else:
            self.quiz_engine = self.coding_engine
            self.exam_data = {'config': {'title': "Mode Test - Pratique", 'duration': self.user_info['duration']}}
            if self.coding_window:
                self.coding_window.coding_finished_flag = True
                self.coding_window.close()
                self.coding_window = None
            self.show_results(score_result)
            
    def calculate_practical_score(self, questions, submission_results):
        def get_points(difficulty):
            d = difficulty.lower()
            if d == "easy": return 2.0
            if d == "medium": return 3.0
            if d == "hard": return 4.0
            if d == "very hard": return 5.0
            return 2.0
            
        sum_max_pts = sum(get_points(q.get("difficulty", "easy")) for q in questions)
        score_details = []
        earned_total = 0.0
        correct_count = 0
        wrong_count = 0
        partial_count = 0
        unanswered_count = 0
        topic_analysis = {}
        
        for q in questions:
            q_id = q["id"]
            max_pts = get_points(q.get("difficulty", "easy"))
            q["points"] = max_pts
            passed = 0
            total = 0
            hints_used = 0
            hidden = {}
            
            if q_id in submission_results:
                hidden = submission_results[q_id].get("hidden_result", {})
                passed = hidden.get("passed", 0)
                total = hidden.get("total", 0)
                hints_used = submission_results[q_id].get("hints_used", 0)
                
                hint_multiplier = 1.0
                if hints_used == 1:
                    hint_multiplier = 0.5
                elif hints_used >= 2:
                    hint_multiplier = 0.0
                
                if total > 0:
                    earned = (passed / total) * max_pts * hint_multiplier
                    if passed == total:
                        status = "correct"
                        correct_count += 1
                    elif passed > 0:
                        status = "partial"
                        partial_count += 1
                    else:
                        status = "incorrect"
                        wrong_count += 1
                else:
                    earned = 0.0
                    status = "incorrect"
                    wrong_count += 1
            else:
                earned = 0.0
                status = "unanswered"
                unanswered_count += 1
                
            earned_total += earned
            topic = q.get("topic", "Practical")
            topic_stats = topic_analysis.setdefault(
                topic,
                {"earned": 0.0, "max": 0.0, "correct": 0, "total": 0},
            )
            topic_stats["earned"] += earned
            topic_stats["max"] += max_pts
            topic_stats["total"] += 1
            if status == "correct":
                topic_stats["correct"] += 1

            score_details.append({
                "id": q_id,
                "status": status,
                "points": earned,
                "penalty": 0.0,
                "passed_tests": passed,
                "total_tests": total,
                "hints_used": hints_used,
                "hidden_result": hidden,
                "code": submission_results[q_id].get("code", "") if q_id in submission_results else "",
            })
            
        final_mark_out_of_20 = (earned_total / sum_max_pts * 20.0) if sum_max_pts > 0 else 0.0
            
        return {
            "percentage": (earned_total / sum_max_pts) * 100.0 if sum_max_pts > 0 else 0.0,
            "final_mark": final_mark_out_of_20,
            "total_points": earned_total,
            "max_points": sum_max_pts,
            "total_questions": len(questions),
            "correct_count": correct_count,
            "wrong_count": wrong_count,
            "unanswered_count": unanswered_count,
            "partial_count": partial_count,
            "submitted_count": correct_count + wrong_count + partial_count,
            "topic_analysis": {
                topic: {
                    "percentage": round((stats["earned"] / stats["max"]) * 100, 2)
                    if stats["max"] else 0,
                    "correct": stats["correct"],
                    "total": stats["total"],
                }
                for topic, stats in topic_analysis.items()
            },
            "details": {d['id']: d for d in score_details}
        }

    def show_results(self, score_result):
        self.results_window = ResultsWindow(
            self.quiz_engine,
            self.user_info,
            self.exam_data['config'],
            score_result
        )
        self.results_window.restart_requested.connect(self.handle_restart)
        self.results_window.exit_requested.connect(self.handle_exit)
        self.results_window.setWindowFlags(Qt.WindowType.Window)
        self.results_window.resize(1600, 1000)
        self.results_window.show()
        
    def show_fused_results(self):
        self.fused_results_window = FusedResultsWindow(
            theoretical_engine=self.theoretical_engine,
            theoretical_score=self.theoretical_score_result,
            coding_engine=self.coding_engine,
            coding_score=self.coding_score_result,
            user_info=self.user_info,
            exam_config=self.exam_data['config']
        )
        self.fused_results_window.restart_requested.connect(self.handle_restart)
        self.fused_results_window.exit_requested.connect(self.handle_exit)
        self.fused_results_window.setWindowFlags(Qt.WindowType.Window)
        self.fused_results_window.resize(1600, 1000)
        self.fused_results_window.show()
        
    def handle_restart(self):
        if self.results_window:
            self.results_window.close()
            self.results_window = None
        if self.fused_results_window:
            self.fused_results_window.close()
            self.fused_results_window = None
        self.launcher = TestLauncherWindow()
        self.launcher.start_requested.connect(self.on_start_requested)
        self.launcher.show()
        
    def handle_exit(self):
        self.app.quit()


def main():
    controller = TestController()
    controller.start()


if __name__ == "__main__":
    main()
