"""
Quiz engine with scoring, randomization, and penalty calculations
"""

import random
import datetime
from typing import List, Dict, Any
import base64
from collections import defaultdict


class QuizEngine:
    def __init__(self, config: Dict[str, Any], questions: List[Dict]):
        self.config = config
        self.original_questions = questions
        self.selected_questions = []
        self.current_question_index = 0
        self.user_answers = {}
        self.start_time = None
        self.score_details = []
        
    def prepare_exam(self, num_questions: int = None) -> None:
        """Prepare random questions from the configured filters."""
        if num_questions is None:
            num_questions = self.config.get('max_questions', 40)

        num_questions = max(1, min(num_questions, self.config.get('max_questions', num_questions)))

        all_questions = self._decode_questions(self.original_questions)

        if 'exams_filter' in self.config:
            expected_exam_flag = bool(self.config.get('exams_filter'))
            all_questions = [
                q for q in all_questions
                if bool(q.get('Exams', False)) == expected_exam_flag
            ]

        if self.config.get('difficulty_filter'):
            all_questions = [
                q for q in all_questions
                if q.get('difficulty') in self.config['difficulty_filter']
            ]

        if self.config.get('topic_filter'):
            all_questions = [
                q for q in all_questions
                if q.get('topic') in self.config['topic_filter']
            ]

        if self.config.get('allowed_topic_difficulty_pairs'):
            allowed_pairs = {
                tuple(pair)
                for pair in self.config.get('allowed_topic_difficulty_pairs', [])
            }
            all_questions = [
                q for q in all_questions
                if (q.get('topic'), q.get('difficulty')) in allowed_pairs
            ]

        if not all_questions:
            self.selected_questions = []
            return

        shuffled_questions = all_questions.copy()
        random.shuffle(shuffled_questions)
        selected = shuffled_questions[:min(num_questions, len(shuffled_questions))]

        self.selected_questions = []
        for position, source_question in enumerate(selected, start=1):
            question = source_question.copy()
            question['original_id'] = source_question.get('id')
            question['id'] = f"{source_question.get('id')}-{position}"

            if question['type'] == 'mcq':
                question['all_options'] = source_question.get('all_options', source_question.get('options', [])).copy()
                self._prepare_mcq_question(question)
            elif question['type'] == 'matching':
                left_items = list(source_question['pairs'].keys())
                right_items = list(source_question['pairs'].values())
                random.shuffle(right_items)
                question['left_items'] = left_items
                question['right_items'] = right_items

            self.selected_questions.append(question)

        if self.config.get('shuffle_questions', True):
            random.shuffle(self.selected_questions)
        
    def _decode_questions(self, questions: List[Dict]) -> List[Dict]:
        """Decode base64 encoded questions"""
        decoded = []
        for q in questions:
            decoded_q = q.copy()
            decoded_q['text'] = q['text']
            
            if q['type'] == 'mcq':
                decoded_q['options'] = [
                   opt
                    for opt in q['options']
                ]
                decoded_q['all_options'] = decoded_q['options'].copy()
            
            decoded.append(decoded_q)
        return decoded
    
    def _prepare_mcq_question(self, question: Dict) -> None:
        """Prepare exactly four randomized MCQ options with at least one correct."""
        correct_indices = question['correct'].copy()
        all_options = question['all_options']
        target_option_count = min(4, len(all_options))

        incorrect_indices = [
            i for i in range(len(all_options)) 
            if i not in correct_indices
        ]

        random.shuffle(correct_indices)
        random.shuffle(incorrect_indices)

        correct_to_show = correct_indices[:min(len(correct_indices), target_option_count)]
        if not correct_to_show and correct_indices:
            correct_to_show = [correct_indices[0]]

        display_indices = correct_to_show.copy()
        needed = target_option_count - len(display_indices)
        display_indices.extend(incorrect_indices[:needed])

        if len(display_indices) < target_option_count:
            available = [
                i for i in range(len(all_options))
                if i not in display_indices
            ]
            random.shuffle(available)
            display_indices.extend(available[:target_option_count - len(display_indices)])

        random.shuffle(display_indices)
        
        # Create display options and mapping
        question['display_options'] = [all_options[i] for i in display_indices]
        
        # Create mapping for scoring
        question['display_mapping'] = {}
        for i, original_idx in enumerate(display_indices):
            question['display_mapping'][i] = {
                'original_index': original_idx,
                'is_correct': original_idx in correct_indices
            }
        
        question['displayed_correct'] = [
            original_idx for original_idx in display_indices
            if original_idx in question['correct']
        ]
        question['original_correct'] = question['displayed_correct'].copy()
    
    def start_exam(self) -> None:
        """Start the exam timer"""
        self.start_time = datetime.datetime.now()
    
    def submit_answer(self, question_id: int, answer: Any) -> None:
        """Store user's answer"""
        self.user_answers[question_id] = {
            'answer': answer,
            'timestamp': datetime.datetime.now()
        }
    
    def calculate_score(self) -> Dict:
        """Calculate final score with penalties and detailed analysis"""
        total_points = 0
        max_points = 0
        correct_count = 0
        wrong_count = 0
        unanswered_count = 0
        partial_count = 0
        self.score_details = []
        
        # Initialize analysis dictionaries
        difficulty_stats = defaultdict(lambda: {'total': 0, 'correct': 0, 'points': 0})
        topic_stats = defaultdict(lambda: {'total': 0, 'correct': 0, 'points': 0})
        
        for question in self.selected_questions:
            max_points += question['points']
            user_answer = self.user_answers.get(question['id'])
            
            # Get question difficulty and topic
            difficulty = question.get('difficulty', 'unknown')
            topic = question.get('topic', 'unknown')
            
            # Update difficulty and topic stats
            difficulty_stats[difficulty]['total'] += 1
            topic_stats[topic]['total'] += 1
        
            if user_answer is None:
                unanswered_count += 1
                self.score_details.append({
                    'id': question['id'],
                    'status': 'unanswered',
                    'points': 0,
                    'penalty': 0,
                    'difficulty': difficulty,
                    'topic': topic,
                    'user_answer': None
                })
                continue
            
            if question['type'] == 'mcq':
                score_info = self._calculate_mcq_score(question, user_answer['answer'])
            elif question['type'] == 'simple_blank':
                score_info = self._calculate_simple_blank_score(question, user_answer['answer'])
            elif question['type'] == 'matching':
                score_info = self._calculate_matching_score(question, user_answer['answer'])
            elif question['type'] == 'intruder':
                score_info = self._calculate_intruder_score(question, user_answer['answer'])
            else:  # yesno
                score_info = self._calculate_yesno_score(question, user_answer['answer'])
            
            total_points += score_info['points']
            total_points -= score_info['penalty']
            
            if score_info['status'] == 'correct':
                correct_count += 1
                # Update stats for correct answers
                difficulty_stats[difficulty]['correct'] += 1
                difficulty_stats[difficulty]['points'] += score_info['points']
                topic_stats[topic]['correct'] += 1
                topic_stats[topic]['points'] += score_info['points']
            elif score_info['status'] == 'partial':
                partial_count += 1
                # Still update stats for partial score
                difficulty_stats[difficulty]['points'] += score_info['points']
                topic_stats[topic]['points'] += score_info['points']
            elif score_info['status'] == 'incorrect':
                wrong_count += 1
                # Still update stats for incorrect answers (just points will be 0)
                difficulty_stats[difficulty]['points'] += 0
                topic_stats[topic]['points'] += 0
            
            self.score_details.append({
                'id': question['id'],
                'status': score_info['status'],
                'points': score_info['points'],
                'penalty': score_info.get('penalty', 0),
                'difficulty': difficulty,
                'topic': topic,
                'user_answer': user_answer['answer']
            })
        
        total_points = max(0, total_points)
        final_percentage = (total_points / max_points * 100) if max_points > 0 else 0
        final_mark = (final_percentage / 100) * 20
        
        # Calculate percentages for difficulty and topic
        difficulty_percentages = {}
        for diff, stats in difficulty_stats.items():
            if stats['total'] > 0:
                percentage = (stats['correct'] / stats['total']) * 100
                difficulty_percentages[diff] = {
                    'percentage': round(percentage, 1),
                    'correct': stats['correct'],
                    'total': stats['total'],
                    'points': stats['points']
                }
        
        topic_percentages = {}
        for topic_name, stats in topic_stats.items():
            if stats['total'] > 0:
                percentage = (stats['correct'] / stats['total']) * 100
                topic_percentages[topic_name] = {
                    'percentage': round(percentage, 1),
                    'correct': stats['correct'],
                    'total': stats['total'],
                    'points': stats['points']
                }
        
        return {
            'total_points': total_points,
            'max_points': max_points,
            'percentage': round(final_percentage, 2),
            'final_mark': round(final_mark, 2),
            'correct_count': correct_count,
            'partial_count': partial_count,
            'wrong_count': wrong_count,
            'unanswered_count': unanswered_count,
            'passed': final_percentage >= self.config.get('passing_score', 50),
            'difficulty_analysis': difficulty_percentages,
            'topic_analysis': topic_percentages,
            'total_questions': len(self.selected_questions),
            'details': {d['id']: d for d in self.score_details}
        }    
    def get_difficulty_color(self, difficulty: str) -> str:
        """Get color for difficulty level"""
        colors = {
            'easy': '#10b981',    # Green
            'medium': '#f59e0b',  # Yellow
            'hard': '#ef4444',    # Red
            'very hard': '#7c3aed',
            'unknown': '#6b7280'  # Gray
        }
        return colors.get(difficulty.lower(), '#6b7280')
    
    def get_difficulty_label(self, difficulty: str) -> str:
        """Get French label for difficulty"""
        labels = {
            'easy': 'Facile',
            'medium': 'Moyen',
            'hard': 'Difficile',
            'very hard': 'Tres difficile',
            'unknown': 'Inconnu'
        }
        return labels.get(difficulty.lower(), 'Inconnu')
    def _calculate_mcq_score(self, question: Dict, user_answer: List[int]) -> Dict:
        """Calculate score for MCQ question with partial credit and penalties"""

        # Map user's display indices to original indices
        user_original = []
        if user_answer:
            for display_idx in user_answer:
                mapping = question['display_mapping'].get(display_idx)
                if mapping:
                    user_original.append(mapping['original_index'])

        correct_set = set(question.get('displayed_correct', question['original_correct']))
        user_set = set(user_original)

        num_correct = len(correct_set)
        if num_correct == 0:
            return {
                'status': 'incorrect',
                'points': 0,
                'penalty': 0
            }

        # Count correct and wrong selections
        correct_selected = len(user_set & correct_set)
        wrong_selected = len(user_set - correct_set)

        # Score only the correct choices visible to the user. For example:
        # 3 points / 4 displayed correct = 0.75 per correct choice.
        # 3 points / 3 displayed correct = 1.00 per correct choice.
        points_per_correct = question['points'] / num_correct
        total_points = correct_selected * points_per_correct
        total_penalty = wrong_selected * question['penalty']

        # Determine status
        if correct_selected == num_correct and wrong_selected == 0:
            status = 'correct'
        elif correct_selected > 0:
            status = 'partial'
        else:
            status = 'incorrect'

        return {
            'status': status,
            'points': round(total_points, 2),
            'penalty': round(total_penalty, 2)
        }

    
    def _calculate_yesno_score(self, question: Dict, user_answer: bool) -> Dict:
        """Calculate score for Yes/No question"""
        if user_answer == question['correct']:
            return {
                'status': 'correct',
                'points': question['points'],
                'penalty': 0
            }
        else:
            return {
                'status': 'incorrect',
                'points': 0,
                'penalty': question['penalty']
            }

    def _calculate_simple_blank_score(self, question: Dict, user_answer: str) -> Dict:
        """Calculate score for simple blank question"""
        ans = str(user_answer).strip().lower()
        expected = str(question['answer']).strip().lower()
        if ans == expected:
            return {
                'status': 'correct',
                'points': question['points'],
                'penalty': 0
            }
        else:
            return {
                'status': 'incorrect',
                'points': 0,
                'penalty': question.get('penalty', 0)
            }

    def _calculate_matching_score(self, question: Dict, user_answer: Dict[str, str]) -> Dict:
        """Calculate score for matching question with partial credit"""
        correct_pairs = question['pairs']
        total_pairs = len(correct_pairs)
        if total_pairs == 0:
            return {'status': 'incorrect', 'points': 0, 'penalty': 0}
        
        correct_count = 0
        if isinstance(user_answer, dict):
            for k, v in user_answer.items():
                if k in correct_pairs and str(v).strip().lower() == str(correct_pairs[k]).strip().lower():
                    correct_count += 1
                    
        points_per_pair = question['points'] / total_pairs
        earned_points = correct_count * points_per_pair
        
        if correct_count == total_pairs:
            status = 'correct'
        elif correct_count > 0:
            status = 'partial'
        else:
            status = 'incorrect'
            
        return {
            'status': status,
            'points': round(earned_points, 2),
            'penalty': 0
        }

    def _calculate_intruder_score(self, question: Dict, user_answer: List[int]) -> Dict:
        """Calculate score for intruder question"""
        if isinstance(user_answer, list) and user_answer and user_answer[0] == question['correct']:
            return {
                'status': 'correct',
                'points': question['points'],
                'penalty': 0
            }
        else:
            return {
                'status': 'incorrect',
                'points': 0,
                'penalty': question.get('penalty', 0)
            }
    
    def get_current_question(self) -> Dict:
        """Get current question"""
        if 0 <= self.current_question_index < len(self.selected_questions):
            return self.selected_questions[self.current_question_index]
        return None
    
    def next_question(self) -> bool:
        """Move to next question"""
        if self.current_question_index < len(self.selected_questions) - 1:
            self.current_question_index += 1
            return True
        return False
    
    def previous_question(self) -> bool:
        """Move to previous question"""
        if self.current_question_index > 0:
            self.current_question_index -= 1
            return True
        return False
    
    def get_progress(self) -> Dict:
        """Get progress information"""
        answered = len(self.user_answers)
        total = len(self.selected_questions)
        percentage = (answered / total) * 100 if total > 0 else 0
        return {
            'current': self.current_question_index + 1,
            'total': total,
            'answered': answered,
            'percentage': percentage
        }
