"""Questions for topic: numpy"""

QUESTIONS = [
    {
        'id': 1001,
        'is_exam': False,
        'type': 'coding',
        'topic': 'numpy',
        'difficulty': 'easy',
        'title': 'Créer un vecteur de zéros',
        'description': "Lisez un entier n, créez un tableau NumPy (1D) de n zéros de type float, et affichez le tableau.",
        'starter_code': "import numpy as np\nn = int(input())\n# Créez et affichez le tableau de n zéros\n",
        'function_signature': None,
        'public_tests': [
            {'input': '3', 'output': '[0. 0. 0.]'},
            {'input': '1', 'output': '[0.]'}
        ],
        'hidden_tests': [
            {'input': '2', 'output': '[0. 0.]'},
            {'input': '5', 'output': '[0. 0. 0. 0. 0.]'}
        ],
        'points': 1,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `np.zeros(n)` pour créer le tableau.",
        'hint2': "N'oubliez pas d'importer `numpy` et d'afficher le résultat.",
        'solution': "import numpy as np\nn = int(input())\nprint(np.zeros(n))"
    },
    {
        'id': 4077,
        'is_exam': False,
        'type': 'coding',
        'topic': 'numpy',
        'difficulty': 'medium',
        'title': 'Redimensionner un tableau',
        'description': "Lisez 6 entiers séparés par des espaces. Convertissez-les en un tableau NumPy 1D, redimensionnez-le (reshape) en une matrice 2D de taille (2, 3), et affichez la matrice.",
        'starter_code': "import numpy as np\n# Lisez 6 entiers, convertissez-les et redimensionnez en (2, 3)\n",
        'function_signature': None,
        'public_tests': [
            {'input': '1 2 3 4 5 6', 'output': '[[1 2 3]\n [4 5 6]]'}
        ],
        'hidden_tests': [
            {'input': '10 20 30 40 50 60', 'output': '[[10 20 30]\n [40 50 60]]'}
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `np.array(...)` puis la méthode `.reshape(2, 3)`.",
        'solution': "import numpy as np\narr = np.array(list(map(int, input().split())))\nprint(arr.reshape(2, 3))"
    },
    {
        'id': 1013,
        'is_exam': False,
        'type': 'coding',
        'topic': 'numpy',
        'difficulty': 'hard',
        'title': 'Matrice transposée',
        'description': "Lisez 4 entiers séparés par des espaces. Créez un tableau NumPy 2D de taille (2, 2) avec ces éléments, calculez sa transposée, et affichez le résultat.",
        'starter_code': "import numpy as np\n# Créez une matrice 2x2 et affichez sa transposée\n",
        'function_signature': None,
        'public_tests': [
            {'input': '1 2 3 4', 'output': '[[1 3]\n [2 4]]'}
        ],
        'hidden_tests': [
            {'input': '5 6 7 8', 'output': '[[5 7]\n [6 8]]'}
        ],
        'points': 3,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "La transposée d'une matrice NumPy `arr` s'obtient simplement avec `arr.T`.",
        'solution': "import numpy as np\nvals = list(map(int, input().split()))\narr = np.array(vals).reshape(2, 2)\nprint(arr.T)"
    },
    {
        'id': 4087,
        'is_exam': False,
        'type': 'coding',
        'topic': 'numpy',
        'difficulty': 'very hard',
        'title': 'Multiplication matricielle',
        'description': "Lisez deux matrices 2x2. La première ligne d'entrée contient 4 entiers pour la première matrice, et la deuxième ligne d'entrée contient 4 entiers pour la deuxième matrice. Effectuez le produit matriciel (dot product ou opérateur @) des deux matrices et affichez le résultat.",
        'starter_code': "import numpy as np\n# Calculez le produit matriciel des deux matrices et affichez-le\n",
        'function_signature': None,
        'public_tests': [
            {'input': '1 2 3 4\n5 6 7 8', 'output': '[[19 22]\n [43 50]]'}
        ],
        'hidden_tests': [
            {'input': '2 0 0 2\n3 4 5 6', 'output': '[[ 6  8]\n [10 12]]'}
        ],
        'points': 4,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez l'opérateur `@` entre les deux matrices reshaped en (2, 2).",
        'solution': "import numpy as np\nm1_vals = list(map(int, input().split()))\nm2_vals = list(map(int, input().split()))\nm1 = np.array(m1_vals).reshape(2, 2)\nm2 = np.array(m2_vals).reshape(2, 2)\nprint(m1 @ m2)"
    },
    {
        'id': 4114,
        'is_exam': False,
        'type': 'coding',
        'topic': 'numpy',
        'difficulty': 'medium',
        'title': 'Normalisation Min-Max',
        'description': "Lisez plusieurs nombres décimaux séparés par des espaces. Convertissez-les en un tableau NumPy 1D. Effectuez une normalisation Min-Max pour ramener toutes les valeurs dans l'intervalle [0, 1] à l'aide de la formule : (x - min) / (max - min). Affichez le tableau résultant arrondi à 2 décimales.",
        'starter_code': "import numpy as np\n# Lisez les valeurs, effectuez la normalisation min-max et affichez le tableau arrondi à 2 décimales\n",
        'function_signature': None,
        'public_tests': [
            {'input': '10.0 20.0 30.0 40.0 50.0', 'output': '[0.   0.25 0.5  0.75 1.  ]'}
        ],
        'hidden_tests': [
            {'input': '1.0 2.0 3.0', 'output': '[0.  0.5 1. ]'},
            {'input': '5.0 15.0 25.0 5.0', 'output': '[0.  0.5 1.  0. ]'}
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez (arr - arr.min()) / (arr.max() - arr.min()) pour la formule.",
        'hint2': "Utilisez np.round(..., 2) pour arrondir le résultat à deux décimales.",
        'solution': "import numpy as np\narr = np.array(list(map(float, input().split())))\nres = (arr - arr.min()) / (arr.max() - arr.min())\nprint(np.round(res, 2))"
    },
    {
        'id': 4115,
        'is_exam': False,
        'type': 'coding',
        'topic': 'numpy',
        'difficulty': 'easy',
        'title': 'Remplacement des impairs',
        'description': "Lisez plusieurs entiers séparés par des espaces. Convertissez-les en un tableau NumPy 1D. Remplacez tous les nombres impairs par la valeur -1 dans ce tableau, puis affichez le tableau résultant.",
        'starter_code': "import numpy as np\n# Lisez les valeurs, remplacez les nombres impairs par -1 et affichez le tableau\n",
        'function_signature': None,
        'public_tests': [
            {'input': '1 2 3 4 5 6 7 8 9', 'output': '[-1  2 -1  4 -1  6 -1  8 -1]'}
        ],
        'hidden_tests': [
            {'input': '10 11 12 13 14', 'output': '[10 -1 12 -1 14]'},
            {'input': '3 5 7', 'output': '[-1 -1 -1]'}
        ],
        'points': 1,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez le masquage booléen arr[arr % 2 != 0] = -1.",
        'solution': "import numpy as np\narr = np.array(list(map(int, input().split())))\narr[arr % 2 != 0] = -1\nprint(arr)"
    }
]

