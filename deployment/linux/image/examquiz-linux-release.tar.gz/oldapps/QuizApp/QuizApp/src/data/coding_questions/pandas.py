"""Questions for topic: pandas"""

QUESTIONS = [
    {
        'id': 1002,
        'is_exam': False,
        'type': 'coding',
        'topic': 'pandas',
        'difficulty': 'easy',
        'title': 'Charger un CSV',
        'description': "Lisez le fichier CSV 'data.csv' à l'aide de pandas et affichez les 2 premières lignes du DataFrame.",
        'starter_code': "import pandas as pd\n# Chargez 'data.csv' et affichez les 2 premières lignes\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '   Id   Name  Age  Salary   Department\n0   1  Alice   25   50000           HR\n1   2    Bob   30   60000  Engineering'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '   Id   Name  Age  Salary   Department\n0   1  Alice   25   50000           HR\n1   2    Bob   30   60000  Engineering'
            }
        ],
        'points': 1,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `pd.read_csv('data.csv')` pour charger les données.",
        'hint2': "Utilisez `print(df.head(2))` pour afficher les deux premières lignes.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.head(2))"
    },
    {
        'id': 4088,
        'is_exam': False,
        'type': 'coding',
        'topic': 'pandas',
        'difficulty': 'medium',
        'title': 'Filtrer les salaires élevés',
        'description': "Lisez le fichier CSV 'data.csv'. Filtrez pour obtenir uniquement les employés ayant un salaire (Salary) strictement supérieur à 50000, et affichez les colonnes 'Name' et 'Salary'.",
        'starter_code': "import pandas as pd\n# Chargez 'data.csv', filtrez pour Salary > 50000 et affichez 'Name' et 'Salary'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '     Name  Salary\n1    Bob   60000\n3  David   75000\n4    Eva   52000'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '     Name  Salary\n1    Bob   60000\n3  David   75000\n4    Eva   52000'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Filtrez avec `df[df['Salary'] > 50000]`.",
        'hint2': "Sélectionnez les colonnes avec `[['Name', 'Salary']]` puis faites un `print`.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df[df['Salary'] > 50000][['Name', 'Salary']])"
    },
    {
        'id': 1023,
        'is_exam': False,
        'type': 'coding',
        'topic': 'pandas',
        'difficulty': 'hard',
        'title': "Moyenne d'âge par département",
        'description': "Lisez le fichier 'data.csv'. Calculez la moyenne d'âge ('Age') par département ('Department'), triée par ordre alphabétique des départements. Affichez la série résultante.",
        'starter_code': "import pandas as pd\n# Calculez la moyenne d'âge par département et affichez le résultat\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Department\nEngineering    32.5\nHR             23.5\nMarketing      28.0\nName: Age, dtype: float64'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Department\nEngineering    32.5\nHR             23.5\nMarketing      28.0\nName: Age, dtype: float64'
            }
        ],
        'points': 3,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `groupby('Department')`.",
        'hint2': "Appliquez la fonction `.mean()` sur la colonne `['Age']`.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.groupby('Department')['Age'].mean())"
    },
    {
        'id': 4097,
        'is_exam': False,
        'type': 'coding',
        'topic': 'pandas',
        'difficulty': 'very hard',
        'title': 'Fusion et calcul de total',
        'description': "Lisez 'data.csv' et 'bonus.csv'. Fusionnez (merge) les deux DataFrames sur la colonne 'Id' (jointure interne). Créez une nouvelle colonne 'Total' qui est la somme de 'Salary' et 'Bonus'. Affichez les colonnes 'Id' et 'Total' du DataFrame fusionné.",
        'starter_code': "import pandas as pd\n# Fusionnez les deux fichiers sur 'Id', calculez le total et affichez 'Id' et 'Total'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '   Id  Total\n0   1  55000\n1   2  68000\n2   3  48000\n3   4  87000\n4   5  56000'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '   Id  Total\n0   1  55000\n1   2  68000\n2   3  48000\n3   4  87000\n4   5  56000'
            }
        ],
        'points': 4,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `pd.merge(df1, df2, on='Id')`.",
        'hint2': "Créez la colonne total avec `m['Total'] = m['Salary'] + m['Bonus']`.",
        'solution': "import pandas as pd\ndf1 = pd.read_csv('data.csv')\ndf2 = pd.read_csv('bonus.csv')\nm = pd.merge(df1, df2, on='Id')\nm['Total'] = m['Salary'] + m['Bonus']\nprint(m[['Id', 'Total']])"
    },
    {
        'id': 4110,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'medium',
        'title': 'Filtrer par âge et département',
        'description': "Lisez 'data.csv'. Filtrez pour obtenir uniquement les employés du département 'HR' ayant un âge strictement inférieur à 24 ans. Affichez les colonnes 'Name', 'Age' et 'Department'.",
        'starter_code': "import pandas as pd\n# Filtrez et affichez les colonnes Name, Age, Department pour HR et Age < 24\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '      Name  Age Department\n2  Charlie   22         HR'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '      Name  Age Department\n2  Charlie   22         HR'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Combinez les conditions avec l'opérateur `&` : `(df['Department'] == 'HR') & (df['Age'] < 24)`.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df[(df['Department'] == 'HR') & (df['Age'] < 24)][['Name', 'Age', 'Department']])"
    },
    {
        'id': 4111,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'hard',
        'title': 'Somme des salaires par département',
        'description': "Lisez 'data.csv'. Calculez la somme cumulée des salaires par département ('Department'). Affichez le résultat.",
        'starter_code': "import pandas as pd\n# Calculez et affichez la somme des salaires par département\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Department\nEngineering    135000\nHR              95000\nMarketing       52000\nName: Salary, dtype: int64'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Department\nEngineering    135000\nHR              95000\nMarketing       52000\nName: Salary, dtype: int64'
            }
        ],
        'points': 3,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `groupby('Department')['Salary'].sum()`.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.groupby('Department')['Salary'].sum())"
    },
    {
        'id': 4116,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'medium',
        'title': 'Tri par valeurs multiples',
        'description': "Lisez le fichier CSV 'data.csv'. Triez le DataFrame par département ('Department') dans l'ordre croissant, puis par salaire ('Salary') dans l'ordre décroissant. Affichez uniquement les colonnes 'Name', 'Department' et 'Salary' du DataFrame trié.",
        'starter_code': "import pandas as pd\n# Triez data.csv par Department (croissant) puis par Salary (décroissant) et affichez Name, Department et Salary\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '      Name   Department  Salary\n3    David  Engineering   75000\n1      Bob  Engineering   60000\n0    Alice           HR   50000\n2  Charlie           HR   45000\n4      Eva    Marketing   52000'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '      Name   Department  Salary\n3    David  Engineering   75000\n1      Bob  Engineering   60000\n0    Alice           HR   50000\n2  Charlie           HR   45000\n4      Eva    Marketing   52000'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `df.sort_values(by=['Department', 'Salary'], ascending=[True, False])`.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.sort_values(by=['Department', 'Salary'], ascending=[True, False])[['Name', 'Department', 'Salary']])"
    },
    {
        'id': 4117,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'medium',
        'title': 'Sélection conditionnelle avec loc',
        'description': "Lisez le fichier CSV 'data.csv'. Sélectionnez les employés dont l'âge ('Age') est supérieur ou égal à 28 ans. Affichez uniquement les colonnes 'Name', 'Age' et 'Salary' de ces employés à l'aide de l'indexeur `.loc`.",
        'starter_code': "import pandas as pd\n# Utilisez .loc pour filtrer Age >= 28 et affichez Name, Age, Salary\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '    Name  Age  Salary\n1    Bob   30   60000\n3  David   35   75000\n4    Eva   28   52000'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '    Name  Age  Salary\n1    Bob   30   60000\n3  David   35   75000\n4    Eva   28   52000'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `df.loc[df['Age'] >= 28, ['Name', 'Age', 'Salary']]`.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.loc[df['Age'] >= 28, ['Name', 'Age', 'Salary']])"
    },
    {
        'id': 4120,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'easy',
        'title': 'Afficher les 5 premières lignes',
        'description': "Lisez le fichier CSV 'data.csv' et affichez ses 5 premières lignes (head) à l'aide de pandas.",
        'starter_code': "import pandas as pd\n# Lisez 'data.csv' et affichez les 5 premières lignes\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '   Id     Name  Age  Salary   Department\n0   1    Alice   25   50000           HR\n1   2      Bob   30   60000  Engineering\n2   3  Charlie   22   45000           HR\n3   4    David   35   75000  Engineering\n4   5      Eva   28   52000    Marketing'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '   Id     Name  Age  Salary   Department\n0   1    Alice   25   50000           HR\n1   2      Bob   30   60000  Engineering\n2   3  Charlie   22   45000           HR\n3   4    David   35   75000  Engineering\n4   5      Eva   28   52000    Marketing'
            }
        ],
        'points': 1,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `df.head(5)` pour afficher les 5 premières lignes.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.head(5))"
    },
    {
        'id': 4121,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'easy',
        'title': 'Afficher les 5 dernières lignes',
        'description': "Lisez le fichier CSV 'data.csv' et affichez ses 5 dernières lignes (tail) à l'aide de pandas.",
        'starter_code': "import pandas as pd\n# Lisez 'data.csv' et affichez les 5 dernières lignes\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '   Id     Name  Age  Salary   Department\n0   1    Alice   25   50000           HR\n1   2      Bob   30   60000  Engineering\n2   3  Charlie   22   45000           HR\n3   4    David   35   75000  Engineering\n4   5      Eva   28   52000    Marketing'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '   Id     Name  Age  Salary   Department\n0   1    Alice   25   50000           HR\n1   2      Bob   30   60000  Engineering\n2   3  Charlie   22   45000           HR\n3   4    David   35   75000  Engineering\n4   5      Eva   28   52000    Marketing'
            }
        ],
        'points': 1,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `df.tail(5)` pour afficher les 5 dernières lignes.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.tail(5))"
    },
    {
        'id': 4122,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'medium',
        'title': 'Statistiques de salaire',
        'description': "Lisez le fichier CSV 'data.csv'. Calculez la somme (sum), la moyenne (mean), le minimum (min), le maximum (max) et l'écart-type (std) de la colonne 'Salary'. Affichez ces valeurs dans cet ordre, chacune sur sa propre ligne (arrondissez la moyenne et l'écart-type à 2 décimales à l'aide de la fonction round()).",
        'starter_code': "import pandas as pd\n# Calculez la somme, moyenne (arrondie), min, max, std (arrondi) et affichez-les dans l'ordre\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '282000\n56400.0\n45000\n75000\n11717.51'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '282000\n56400.0\n45000\n75000\n11717.51'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez s.sum(), s.mean(), s.min(), s.max(), et s.std() sur la série df['Salary'].",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\ns = df['Salary']\nprint(s.sum())\nprint(round(s.mean(), 2))\nprint(s.min())\nprint(s.max())\nprint(round(s.std(), 2))"
    },
    {
        'id': 4123,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'easy',
        'title': "Nombre d'employés par département",
        'description': "Lisez le fichier CSV 'data.csv'. Comptez le nombre d'employés dans chaque département ('Department') à l'aide de la méthode value_counts(), et affichez la série de résultats.",
        'starter_code': "import pandas as pd\n# Calculez et affichez le nombre d'employés par département\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Department\nHR             2\nEngineering    2\nMarketing      1\nName: count, dtype: int64'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Department\nHR             2\nEngineering    2\nMarketing      1\nName: count, dtype: int64'
            }
        ],
        'points': 1,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `df['Department'].value_counts()` pour compter le nombre d'employés.",
        'solution': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df['Department'].value_counts())"
    },
    {
        'id': 4124,
        'is_exam': False,
        'topic': 'pandas',
        'type': 'coding',
        'difficulty': 'hard',
        'title': 'Filtrage conditionnel multiple',
        'description': "Lisez le fichier CSV 'users.csv' qui contient les colonnes x, y, z et w. Calculez et affichez le nombre total d'utilisateurs qui ont la valeur 'a' dans la colonne 'x' ET la valeur 'b' dans la colonne 'z'.",
        'starter_code': "import pandas as pd\n# Filtrez les lignes où x == 'a' et z == 'b', puis affichez leur nombre total\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': '2'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': '2'
            }
        ],
        'points': 3,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Filtrez avec df[(df['x'] == 'a') & (df['z'] == 'b')] et utilisez len() pour obtenir le nombre.",
        'solution': "import pandas as pd\ndf = pd.read_csv('users.csv')\nprint(len(df[(df['x'] == 'a') & (df['z'] == 'b')]))"
    }
]


