"""Training progression, unlock rules, and analytics helpers."""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


PASSING_MARK = 14.0
PASSING_PERCENTAGE = 70
DEFAULT_VALIDATION_QUESTIONS = 20
INITIAL_TOPIC = "Python Basics"
DIFFICULTY_ORDER = ["easy", "medium", "hard", "very hard"]
DIFFICULTY_LABELS = {
    "easy": "Easy",
    "medium": "Medium",
    "hard": "Hard",
    "very hard": "Expert",
}

PREFERRED_TOPIC_ORDER = [
    "Python Basics",
    "Python Data Types",
    "Control Flow",
    "List Comprehension",
    "Modules de Base",
    "I/O",
    "OOP",
    "numpy",
    "pandas",
    "Data Visualization",
]


def is_exam_question(question: Dict[str, Any]) -> bool:
    return bool(question.get("Exams", False))


def get_training_questions(questions: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [question for question in questions if not is_exam_question(question)]


def get_topic_order(questions: Iterable[Dict[str, Any]]) -> List[str]:
    """Return the training topic order, with Python basics first."""
    available = []
    seen = set()
    for question in questions:
        topic = question.get("topic", "Unknown")
        if topic not in seen:
            seen.add(topic)
            available.append(topic)

    ordered = [topic for topic in PREFERRED_TOPIC_ORDER if topic in seen]
    extras = sorted(topic for topic in available if topic not in ordered)
    return ordered + extras


def get_difficulties_for_topic(questions: Iterable[Dict[str, Any]], topic: str) -> List[str]:
    difficulties = {
        question.get("difficulty", "unknown")
        for question in questions
        if question.get("topic") == topic
    }
    return [difficulty for difficulty in DIFFICULTY_ORDER if difficulty in difficulties]


def get_validation_difficulties(target_difficulty: str) -> List[str]:
    """Return previous difficulties plus the target difficulty."""
    if target_difficulty not in DIFFICULTY_ORDER:
        return [target_difficulty]
    return DIFFICULTY_ORDER[: DIFFICULTY_ORDER.index(target_difficulty) + 1]


def get_attempt_target(attempt: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    """Read topic/difficulty from new attempts and simple legacy attempts."""
    topic = attempt.get("target_topic")
    difficulty = attempt.get("target_difficulty")
    if topic and difficulty:
        return topic, difficulty

    topics = attempt.get("selected_topics", [])
    difficulties = attempt.get("selected_difficulties", [])
    if len(topics) == 1 and len(difficulties) == 1:
        return topics[0], difficulties[0]
    return None, None


def is_passing_attempt(attempt: Dict[str, Any]) -> bool:
    if "passed" in attempt:
        return bool(attempt.get("passed"))
    return float(attempt.get("final_mark", 0) or 0) >= PASSING_MARK


def get_completed_difficulties(history: Iterable[Dict[str, Any]]) -> Dict[str, Set[str]]:
    completed: Dict[str, Set[str]] = defaultdict(set)
    for attempt in history:
        topic, difficulty = get_attempt_target(attempt)
        if topic and difficulty and is_passing_attempt(attempt):
            completed[topic].add(difficulty)
    return completed


def is_topic_unlocked(
    topic: str,
    topics: List[str],
    completed: Dict[str, Set[str]],
    available_by_topic: Optional[Dict[str, List[str]]] = None,
) -> bool:
    if not topics:
        return False
    if topic == topics[0] or topic == INITIAL_TOPIC:
        return True
    try:
        index = topics.index(topic)
    except ValueError:
        return False
    previous_topic = topics[index - 1]
    required = ["easy", "medium"]
    if available_by_topic:
        previous_available = available_by_topic.get(previous_topic, [])
        required = [difficulty for difficulty in required if difficulty in previous_available]
        if len(required) < 2:
            required = previous_available[:2]
    return set(required).issubset(completed.get(previous_topic, set()))


def is_difficulty_unlocked(
    topic: str,
    difficulty: str,
    topics: List[str],
    completed: Dict[str, Set[str]],
    available_difficulties: Optional[List[str]] = None,
    available_by_topic: Optional[Dict[str, List[str]]] = None,
) -> bool:
    if not is_topic_unlocked(topic, topics, completed, available_by_topic):
        return False
    difficulties = available_difficulties or DIFFICULTY_ORDER
    if difficulty not in difficulties:
        return False
    if difficulties.index(difficulty) == 0:
        return True
    previous = difficulties[difficulties.index(difficulty) - 1]
    return previous in completed.get(topic, set())


def build_progression_state(questions: List[Dict[str, Any]], history: List[Dict[str, Any]]) -> Dict[str, Any]:
    topics = get_topic_order(questions)
    completed = get_completed_difficulties(history)
    available_by_topic = {
        topic: get_difficulties_for_topic(questions, topic)
        for topic in topics
    }
    active_topic = None
    active_difficulty = None
    topic_states = []

    for topic in topics:
        difficulties = get_difficulties_for_topic(questions, topic)
        topic_unlocked = is_topic_unlocked(topic, topics, completed, available_by_topic)
        difficulty_states = []
        for difficulty in difficulties:
            completed_here = difficulty in completed.get(topic, set())
            unlocked = is_difficulty_unlocked(
                topic,
                difficulty,
                topics,
                completed,
                difficulties,
                available_by_topic,
            )
            is_current = False
            if unlocked and not completed_here and active_topic is None:
                active_topic = topic
                active_difficulty = difficulty
                is_current = True
            difficulty_states.append({
                "name": difficulty,
                "label": DIFFICULTY_LABELS.get(difficulty, difficulty.title()),
                "unlocked": unlocked,
                "completed": completed_here,
                "current": is_current,
            })

        topic_states.append({
            "name": topic,
            "unlocked": topic_unlocked,
            "completed": bool(difficulties) and all(d in completed.get(topic, set()) for d in difficulties),
            "current": topic == active_topic,
            "difficulties": difficulty_states,
            "completed_count": len([d for d in difficulties if d in completed.get(topic, set())]),
            "total_count": len(difficulties),
        })

    return {
        "topics": topic_states,
        "active_topic": active_topic or (topics[0] if topics else None),
        "active_difficulty": active_difficulty or "easy",
        "completed": completed,
    }


def count_validation_questions(
    questions: Iterable[Dict[str, Any]], topic: str, target_difficulty: str
) -> int:
    difficulties = set(get_validation_difficulties(target_difficulty))
    return sum(
        1
        for question in questions
        if question.get("topic") == topic and question.get("difficulty") in difficulties
    )


def build_progress_analytics(questions: List[Dict[str, Any]], history: List[Dict[str, Any]]) -> Dict[str, Any]:
    progression = build_progression_state(questions, history)
    attempts = list(history)
    marks = [float(attempt.get("final_mark", 0) or 0) for attempt in attempts]
    passed = [attempt for attempt in attempts if is_passing_attempt(attempt)]
    total_available = sum(topic["total_count"] for topic in progression["topics"])
    completed_total = sum(topic["completed_count"] for topic in progression["topics"])

    topic_totals: Dict[str, List[float]] = defaultdict(list)
    difficulty_totals: Dict[str, List[float]] = defaultdict(list)
    for attempt in attempts:
        topic, difficulty = get_attempt_target(attempt)
        mark = float(attempt.get("final_mark", 0) or 0)
        if topic:
            topic_totals[topic].append(mark)
        else:
            for topic_name, data in attempt.get("topic_marks", {}).items():
                topic_totals[topic_name].append(float(data.get("mark", 0) or 0))
        if difficulty:
            difficulty_totals[difficulty].append(mark)

    topic_averages = {
        topic: round(sum(values) / len(values), 2)
        for topic, values in topic_totals.items()
        if values
    }
    difficulty_averages = {
        DIFFICULTY_LABELS.get(difficulty, difficulty.title()): round(sum(values) / len(values), 2)
        for difficulty, values in difficulty_totals.items()
        if values
    }

    weak_topics = [(topic, mark) for topic, mark in topic_averages.items() if mark < 10]
    weak_difficulties = [(difficulty, mark) for difficulty, mark in difficulty_averages.items() if mark < 10]
    weak_topics.sort(key=lambda item: item[1])
    weak_difficulties.sort(key=lambda item: item[1])

    return {
        "progression": progression,
        "global_average": round(sum(marks) / len(marks), 2) if marks else 0,
        "topic_averages": topic_averages,
        "difficulty_averages": difficulty_averages,
        "completion_percentage": round((completed_total / total_available) * 100, 1) if total_available else 0,
        "success_rate": round((len(passed) / len(attempts)) * 100, 1) if attempts else 0,
        "failure_rate": round(((len(attempts) - len(passed)) / len(attempts)) * 100, 1) if attempts else 0,
        "tests_completed": len(attempts),
        "total_points": round(sum(float(attempt.get("total_points", 0) or 0) for attempt in attempts), 2),
        "timeline": attempts[-12:],
        "weak_topics": weak_topics,
        "weak_difficulties": weak_difficulties,
    }
