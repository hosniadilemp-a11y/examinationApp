"""
Badge / Level-Up notification popup.
Shows a slide-in toast card when the user unlocks new badges or levels up.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QGraphicsDropShadowEffect, QScrollArea, QApplication
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QRect, pyqtSignal
from PyQt6.QtGui import QColor, QFont


class BadgeNotificationPopup(QWidget):
    """
    A slide-in notification popup displayed after a session ends.
    Shows level-up info and newly unlocked badges.
    """

    closed = pyqtSignal()

    def __init__(self, new_badges: list, old_level: int, new_level: int, new_xp: int, parent=None):
        super().__init__(parent, Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.new_badges = new_badges  # list of milestone dicts that were just unlocked
        self.old_level = old_level
        self.new_level = new_level
        self.new_xp = new_xp
        self.leveled_up = new_level > old_level

        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowModality(Qt.WindowModality.NonModal)
        self._build_ui()
        self._position_and_animate()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        # Main card
        card = QFrame()
        card.setObjectName("notifCard")
        card.setMinimumWidth(380)
        card.setMaximumWidth(420)
        card.setStyleSheet("""
            QFrame#notifCard {
                background-color: #ffffff;
                border: 2px solid #8b5cf6;
                border-radius: 16px;
            }
        """)

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(32)
        shadow.setColor(QColor(139, 92, 246, 80))
        shadow.setOffset(0, 8)
        card.setGraphicsEffect(shadow)

        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(20, 18, 20, 18)
        card_layout.setSpacing(12)

        # ── Header ──────────────────────────────────────────────────────────
        if self.leveled_up:
            header_emoji = "🎉"
            header_text = f"Niveau {self.new_level} atteint !"
            header_sub = f"Vous avez progressé de Niv.{self.old_level} → Niv.{self.new_level} !"
            header_bg = "#fef9c3"
            header_border = "#facc15"
            header_color = "#78350f"
        else:
            header_emoji = "🏆"
            header_text = "Nouveau badge débloqué !"
            header_sub = f"XP total : {self.new_xp} pts"
            header_bg = "#f3e8ff"
            header_border = "#c084fc"
            header_color = "#6b21a8"

        header_frame = QFrame()
        header_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {header_bg};
                border: 1.5px solid {header_border};
                border-radius: 10px;
            }}
        """)
        h_lay = QHBoxLayout(header_frame)
        h_lay.setContentsMargins(12, 10, 12, 10)
        h_lay.setSpacing(10)

        emo = QLabel(header_emoji)
        emo.setStyleSheet("font-size: 28px; background: transparent; border: none;")
        h_lay.addWidget(emo)

        txt_col = QVBoxLayout()
        txt_col.setSpacing(2)
        htitle = QLabel(header_text)
        htitle.setStyleSheet(f"font-size: 15px; font-weight: 900; color: {header_color}; background: transparent; border: none;")
        hsub = QLabel(header_sub)
        hsub.setStyleSheet(f"font-size: 12px; font-weight: 600; color: {header_color}; background: transparent; border: none;")
        txt_col.addWidget(htitle)
        txt_col.addWidget(hsub)
        h_lay.addLayout(txt_col, 1)
        card_layout.addWidget(header_frame)

        # ── Badge list ───────────────────────────────────────────────────────
        if self.new_badges:
            badges_title = QLabel(f"✨ {len(self.new_badges)} badge(s) débloqué(s) :")
            badges_title.setStyleSheet("font-size: 13px; font-weight: 900; color: #1e293b; background: transparent; border: none;")
            card_layout.addWidget(badges_title)

            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setMaximumHeight(200)
            scroll.setStyleSheet("""
                QScrollArea { background: transparent; border: none; }
                QScrollBar:vertical { background: #f1f5f9; width: 8px; border-radius: 4px; }
                QScrollBar::handle:vertical { background: #c084fc; border-radius: 4px; min-height: 20px; }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
            """)

            scroll_w = QWidget()
            scroll_w.setStyleSheet("background: transparent;")
            scroll_lay = QVBoxLayout(scroll_w)
            scroll_lay.setContentsMargins(0, 0, 0, 0)
            scroll_lay.setSpacing(6)

            for badge in self.new_badges:
                brow = QFrame()
                brow.setStyleSheet("""
                    QFrame {
                        background-color: #faf5ff;
                        border: 1px solid #d8b4fe;
                        border-radius: 8px;
                    }
                """)
                brow_lay = QHBoxLayout(brow)
                brow_lay.setContentsMargins(10, 6, 10, 6)
                brow_lay.setSpacing(8)

                b_emo = QLabel(badge.get("emoji", "🏅"))
                b_emo.setStyleSheet("font-size: 20px; background: transparent; border: none;")
                brow_lay.addWidget(b_emo)

                b_col = QVBoxLayout()
                b_col.setSpacing(1)
                b_name = QLabel(badge.get("name", ""))
                b_name.setStyleSheet("font-size: 12px; font-weight: 800; color: #6b21a8; background: transparent; border: none;")
                b_pts = QLabel(f"+{badge.get('points', 0)} XP")
                b_pts.setStyleSheet("font-size: 11px; font-weight: 700; color: #7c3aed; background: transparent; border: none;")
                b_col.addWidget(b_name)
                b_col.addWidget(b_pts)
                brow_lay.addLayout(b_col, 1)
                scroll_lay.addWidget(brow)

            scroll_lay.addStretch()
            scroll.setWidget(scroll_w)
            card_layout.addWidget(scroll)

        # ── Close button ─────────────────────────────────────────────────────
        close_btn = QPushButton("✓ Super, merci !")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #7c3aed, stop:1 #4f46e5);
                color: white;
                border: none;
                border-radius: 8px;
                font-weight: 900;
                font-size: 13px;
                padding: 10px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #6d28d9, stop:1 #4338ca);
            }
        """)
        close_btn.clicked.connect(self._close_animated)
        card_layout.addWidget(close_btn)

        outer.addWidget(card)

    def _position_and_animate(self):
        """Place popup at bottom-right of the screen and slide it in."""
        screen = QApplication.primaryScreen().geometry()
        self.adjustSize()
        w = self.sizeHint().width() + 20
        h = self.sizeHint().height() + 20

        # End position (visible, bottom-right)
        end_x = screen.width() - w - 24
        end_y = screen.height() - h - 60

        # Start off-screen below
        self.setGeometry(end_x, screen.height(), w, h)
        self.show()

        self._anim = QPropertyAnimation(self, b"geometry")
        self._anim.setDuration(400)
        self._anim.setStartValue(QRect(end_x, screen.height(), w, h))
        self._anim.setEndValue(QRect(end_x, end_y, w, h))
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.start()

        # Auto-close after 12 seconds
        QTimer.singleShot(12000, self._close_animated)

    def _close_animated(self):
        screen = QApplication.primaryScreen().geometry()
        geo = self.geometry()
        self._close_anim = QPropertyAnimation(self, b"geometry")
        self._close_anim.setDuration(300)
        self._close_anim.setStartValue(geo)
        self._close_anim.setEndValue(QRect(geo.x(), screen.height(), geo.width(), geo.height()))
        self._close_anim.setEasingCurve(QEasingCurve.Type.InCubic)
        self._close_anim.finished.connect(self.close)
        self._close_anim.finished.connect(self.closed.emit)
        self._close_anim.start()


def check_and_show_notifications(history_before, history_after, parent=None):
    """
    Compare milestones before and after a session.
    If new badges or a level-up occurred, show the popup.
    Returns the popup widget (or None).
    """
    from core.leveling_system import calculate_leveling_data
    data_before = calculate_leveling_data(history_before)
    data_after = calculate_leveling_data(history_after)

    old_level = data_before["level"]
    new_level = data_after["level"]

    # Find newly unlocked badges
    before_ids = {m["id"] for m in data_before["all_milestones"] if m["unlocked"]}
    after_ids = {m["id"] for m in data_after["all_milestones"] if m["unlocked"]}
    new_ids = after_ids - before_ids

    if not new_ids and new_level == old_level:
        return None

    new_badges = [m for m in data_after["all_milestones"] if m["id"] in new_ids]

    popup = BadgeNotificationPopup(
        new_badges=new_badges,
        old_level=old_level,
        new_level=new_level,
        new_xp=data_after["xp"],
        parent=parent,
    )
    return popup
