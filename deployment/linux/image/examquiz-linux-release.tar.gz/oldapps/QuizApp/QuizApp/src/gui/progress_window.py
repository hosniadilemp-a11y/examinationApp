"""Dedicated training progress and analytics window with modern interactive tabs and light mode styling."""

from importlib import reload

from PyQt6.QtCore import Qt, QPointF, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QBrush, QLinearGradient
from PyQt6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QProgressBar,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
    QTabWidget,
    QLineEdit,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QPushButton,
    QMessageBox,
    QToolTip,
)

from core.progression import (
    DIFFICULTY_LABELS,
    PASSING_MARK,
    build_progress_analytics,
    get_training_questions,
    is_passing_attempt,
)
from core.training_history import filter_history_by_type, load_training_history, clear_training_history
from data.coding_questions import CODING_QUESTIONS
from data import questions as builtin_questions


class TopicDetailsDialog(QDialog):
    """Modern light-mode modal dialog showing specific details and attempts for a topic."""

    def __init__(self, topic, history, assessment_type, parent=None):
        super().__init__(parent)
        self.topic = topic
        self.history = history
        self.assessment_type = assessment_type
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle(f"Topic Details: {self.topic['name']}")
        self.setMinimumSize(580, 480)
        self.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
            }
            QLabel {
                color: #1e293b;
            }
            QFrame#card {
                background-color: #f8fafc;
                border: 1px solid #cbd5e1;
                border-radius: 10px;
            }
            QPushButton {
                background-color: #f1f5f9;
                color: #1e293b;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: 800;
            }
            QPushButton:hover {
                background-color: #e2e8f0;
                border-color: #cbd5e1;
            }
            QPushButton#closeBtn {
                background-color: #8b5cf6;
                color: white;
                border: none;
            }
            QPushButton#closeBtn:hover {
                background-color: #7c3aed;
            }
            QScrollArea {
                background-color: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: #f1f5f9;
                width: 10px;
                margin: 2px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical {
                background: #cbd5e1;
                border-radius: 5px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: #8b5cf6;
            }
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Title
        title_label = QLabel(self.topic["name"])
        title_label.setStyleSheet("font-size: 20px; font-weight: 900; color: #0f172a;")
        layout.addWidget(title_label)

        # Status badge & summary
        status_row = QHBoxLayout()
        status_label = QLabel("STATUS:")
        status_label.setStyleSheet("font-weight: 900; color: #64748b; font-size: 11px;")
        status_row.addWidget(status_label)

        status_str = "COMPLETED" if self.topic["completed"] else "CURRENT" if self.topic["current"] else "UNLOCKED" if self.topic["unlocked"] else "LOCKED"
        status_color = "#059669" if self.topic["completed"] else "#2563eb" if self.topic["current"] else "#475569" if self.topic["unlocked"] else "#94a3b8"
        status_val = QLabel(status_str)
        status_val.setStyleSheet(f"font-weight: 900; color: {status_color}; font-size: 12px;")
        status_row.addWidget(status_val)
        status_row.addStretch()
        layout.addLayout(status_row)

        # Difficulty progression
        diff_box = QFrame()
        diff_box.setObjectName("card")
        diff_layout = QVBoxLayout(diff_box)
        diff_layout.setContentsMargins(16, 16, 16, 16)
        diff_layout.setSpacing(10)

        diff_title = QLabel("DIFFICULTY LEVEL TRACKING")
        diff_title.setStyleSheet("font-size: 11px; font-weight: 900; color: #64748b;")
        diff_layout.addWidget(diff_title)

        for diff in self.topic["difficulties"]:
            row = QHBoxLayout()
            icon = "✓" if diff["completed"] else "▶" if diff["current"] else "○" if diff["unlocked"] else "🔒"
            color = "#10b981" if diff["completed"] else "#3b82f6" if diff["current"] else "#475569" if diff["unlocked"] else "#94a3b8"
            
            lbl_icon = QLabel(icon)
            lbl_icon.setStyleSheet(f"font-size: 14px; font-weight: 900; color: {color};")
            row.addWidget(lbl_icon)

            lbl_name = QLabel(diff["label"])
            lbl_name.setStyleSheet(f"font-size: 13px; font-weight: 800; color: {color};")
            row.addWidget(lbl_name)
            
            row.addStretch()
            
            status_text = "Completed" if diff["completed"] else "Active Study" if diff["current"] else "Unlocked" if diff["unlocked"] else "Locked"
            lbl_status = QLabel(status_text)
            lbl_status.setStyleSheet(f"font-size: 12px; font-weight: 600; color: {color};")
            row.addWidget(lbl_status)
            diff_layout.addLayout(row)

        layout.addWidget(diff_box)

        # Topic Attempts History
        history_title = QLabel("RECENT TOPIC ATTEMPTS")
        history_title.setStyleSheet("font-size: 12px; font-weight: 900; color: #64748b;")
        layout.addWidget(history_title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_content.setStyleSheet("background-color: transparent;")
        scroll_layout = QVBoxLayout(scroll_content)
        scroll_layout.setContentsMargins(0, 0, 0, 0)
        scroll_layout.setSpacing(8)

        # Filter attempts for this topic
        topic_attempts = []
        for attempt in self.history:
            atype = attempt.get("assessment_type", "theoretical")
            if self.assessment_type != atype:
                continue
            
            t = attempt.get("target_topic")
            if not t:
                selected_topics = attempt.get("selected_topics", [])
                if self.topic["name"] in selected_topics:
                    topic_attempts.append(attempt)
            elif t == self.topic["name"]:
                topic_attempts.append(attempt)

        if not topic_attempts:
            no_attempts = QLabel("No attempts recorded for this topic yet.")
            no_attempts.setStyleSheet("font-size: 13px; font-weight: 700; color: #94a3b8; padding: 10px;")
            scroll_layout.addWidget(no_attempts)
        else:
            for attempt in reversed(topic_attempts):
                passed = is_passing_attempt(attempt)
                color = "#10b981" if passed else "#ef4444"
                status = "Passed" if passed else "Failed"
                diff_lvl = attempt.get("target_difficulty") or ", ".join(attempt.get("selected_difficulties", [])) or "custom"
                
                row_widget = QFrame()
                row_widget.setStyleSheet("""
                    QFrame {
                        background-color: #ffffff;
                        border: 1px solid #cbd5e1;
                        border-radius: 8px;
                    }
                """)
                row_lay = QHBoxLayout(row_widget)
                row_lay.setContentsMargins(12, 8, 12, 8)
                
                lbl_time = QLabel(attempt.get("timestamp", "")[:16])
                lbl_time.setStyleSheet("font-size: 12px; color: #64748b; font-weight: 600;")
                row_lay.addWidget(lbl_time)
                
                lbl_diff = QLabel(f"Level: {diff_lvl.title()}")
                lbl_diff.setStyleSheet("font-size: 12px; color: #1e293b; font-weight: 600;")
                row_lay.addWidget(lbl_diff)
                
                row_lay.addStretch()
                
                lbl_score = QLabel(f'{attempt.get("final_mark", 0):.1f}/20 ({status})')
                lbl_score.setStyleSheet(f"font-size: 12px; font-weight: 800; color: {color};")
                row_lay.addWidget(lbl_score)
                
                scroll_layout.addWidget(row_widget)

        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)

        # Close button setup
        buttons = QDialogButtonBox()
        close_btn = QPushButton("Close")
        close_btn.setObjectName("closeBtn")
        close_btn.clicked.connect(self.accept)
        buttons.addButton(close_btn, QDialogButtonBox.ButtonRole.AcceptRole)
        layout.addWidget(buttons)


class TopicCard(QFrame):
    """Clickable, styled light-mode card representing a training topic."""

    def __init__(self, topic, assessment_type, click_callback):
        super().__init__()
        self.topic = topic
        self.assessment_type = assessment_type
        self.click_callback = click_callback
        self.setObjectName("topicProgressCard")
        self.init_ui()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.click_callback(self.topic, self.assessment_type)
        super().mousePressEvent(event)

    def init_ui(self):
        unlocked = self.topic["unlocked"]
        completed = self.topic["completed"]
        current = self.topic["current"]
        
        # Light Mode Palette mapping
        border = "#10b981" if completed else "#3b82f6" if current else "#cbd5e1" if unlocked else "#e2e8f0"
        bg = "#ecfdf5" if completed else "#eff6ff" if current else "#ffffff" if unlocked else "#f8fafc"
        title_color = "#047857" if completed else "#1d4ed8" if current else "#1e293b" if unlocked else "#94a3b8"
        
        self.setStyleSheet(f"""
            QFrame#topicProgressCard {{
                background-color: {bg};
                border: 1px solid {border};
                border-radius: 12px;
            }}
            QFrame#topicProgressCard:hover {{
                border-color: #8b5cf6;
                background-color: {bg if not unlocked else '#f5f3ff'};
            }}
        """)
        
        if unlocked:
            self.setCursor(Qt.CursorShape.PointingHandCursor)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        status = "Completed" if completed else "Current" if current else "Unlocked" if unlocked else "Locked"
        heading = QHBoxLayout()
        title = QLabel(self.topic["name"])
        title.setStyleSheet(f"font-size: 15px; font-weight: 900; color: {title_color};")
        title.setWordWrap(True)
        heading.addWidget(title, 1)
        
        badge = QLabel(status.upper())
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setStyleSheet(f"""
            QLabel {{
                color: {border};
                background-color: #ffffff;
                border: 1px solid {border};
                border-radius: 7px;
                padding: 4px 8px;
                font-size: 10px;
                font-weight: 900;
            }}
        """)
        heading.addWidget(badge)
        layout.addLayout(heading)

        bar = QProgressBar()
        bar.setRange(0, max(1, self.topic["total_count"]))
        bar.setValue(self.topic["completed_count"])
        bar.setFormat(f"{self.topic['completed_count']}/{self.topic['total_count']} completed")
        bar.setMinimumHeight(16)
        bar.setStyleSheet(f"""
            QProgressBar {{
                background-color: #e2e8f0;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                color: #1e293b;
                text-align: center;
                font-size: 10px;
                font-weight: 800;
            }}
            QProgressBar::chunk {{
                background-color: {border};
                border-radius: 8px;
            }}
        """)
        layout.addWidget(bar)

        diff_row = QHBoxLayout()
        diff_row.setSpacing(8)
        for difficulty in self.topic["difficulties"]:
            chip = QLabel(self._difficulty_chip_text(difficulty))
            chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
            chip.setStyleSheet(self._difficulty_chip_style(difficulty))
            diff_row.addWidget(chip)
        diff_row.addStretch()
        layout.addLayout(diff_row)

        if unlocked:
            hint = QLabel("💡 Click card for details & attempts")
            hint.setStyleSheet("font-size: 10px; color: #64748b; font-style: italic;")
            layout.addWidget(hint)

    def _difficulty_chip_text(self, difficulty):
        prefix = "✓" if difficulty["completed"] else "▶" if difficulty["current"] else "●" if difficulty["unlocked"] else "🔒"
        return f"{prefix} {difficulty['label']}"

    def _difficulty_chip_style(self, difficulty):
        if difficulty["completed"]:
            bg, color, border = "#d1fae5", "#065f46", "#10b981"
        elif difficulty["current"]:
            bg, color, border = "#dbeafe", "#1e40af", "#3b82f6"
        elif difficulty["unlocked"]:
            bg, color, border = "#f1f5f9", "#475569", "#cbd5e1"
        else:
            bg, color, border = "#f8fafc", "#94a3b8", "#e2e8f0"
        return f"""
            QLabel {{
                background-color: {bg};
                color: {color};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 5px 8px;
                font-size: 11px;
                font-weight: 900;
            }}
        """


import math
from PyQt6.QtWidgets import QWidget

class ProgressChartWidget(QWidget):
    """Custom QPainter-based vector progress line chart to display training performance chronologically."""

    def __init__(self, history, parent=None):
        super().__init__(parent)
        self.history = history
        self.setMouseTracking(True)
        self.hovered_point = None
        self.points = []
        self.setMinimumHeight(260)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        rect = self.rect()
        painter.fillRect(rect, QColor("#ffffff"))
        
        # Gather attempts chronologically
        attempts = []
        for attempt in self.history:
            timestamp = attempt.get("timestamp", "")
            final_mark = attempt.get("final_mark", 0.0)
            percentage = (final_mark / 20.0) * 100.0
            atype = attempt.get("assessment_type", "theoretical")
            type_label = "Coding" if atype == "practical" else "MCQ"
            attempts.append((timestamp, percentage, type_label, final_mark))
            
        attempts = sorted(attempts, key=lambda x: x[0])
        
        padding_left = 60
        padding_right = 30
        padding_top = 30
        padding_bottom = 40
        
        width = rect.width() - padding_left - padding_right
        height = rect.height() - padding_top - padding_bottom
        
        # Draw axes
        painter.setPen(QPen(QColor("#cbd5e1"), 1.5))
        painter.drawLine(padding_left, padding_top, padding_left, rect.height() - padding_bottom)
        painter.drawLine(padding_left, rect.height() - padding_bottom, rect.width() - padding_right, rect.height() - padding_bottom)
        
        # Horizontal grids & Y-axis labels
        grid_lines = 5
        for i in range(grid_lines + 1):
            percent_val = i * (100 // grid_lines)
            y = rect.height() - padding_bottom - (i * (height / grid_lines))
            if i > 0:
                painter.setPen(QPen(QColor("#f1f5f9"), 1, Qt.PenStyle.DashLine))
                painter.drawLine(padding_left, int(y), rect.width() - padding_right, int(y))
            painter.setPen(QPen(QColor("#64748b"), 1))
            painter.setFont(QFont("system-ui", 9, QFont.Weight.Bold))
            painter.drawText(10, int(y) - 10, padding_left - 18, 20, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, f"{percent_val}%")
            
        if not attempts:
            painter.setPen(QPen(QColor("#94a3b8"), 1))
            painter.setFont(QFont("system-ui", 12, QFont.Weight.Bold))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "No attempts recorded yet.")
            return
            
        self.points = []
        num_points = len(attempts)
        x_step = width / (num_points - 1) if num_points > 1 else width
        
        for idx, (timestamp, percentage, type_label, final_mark) in enumerate(attempts):
            if num_points > 1:
                x = padding_left + idx * x_step
            else:
                x = padding_left + width / 2.0
            y = rect.height() - padding_bottom - (percentage / 100.0) * height
            self.points.append((x, y, timestamp, percentage, type_label, final_mark))
            
        # Draw smooth bezier line path
        if num_points > 1:
            path = QPainterPath()
            path.moveTo(self.points[0][0], self.points[0][1])
            
            for idx in range(num_points - 1):
                p0 = self.points[idx]
                p1 = self.points[idx + 1]
                cp_x1 = p0[0] + (p1[0] - p0[0]) / 2.0
                cp_y1 = p0[1]
                cp_x2 = p0[0] + (p1[0] - p0[0]) / 2.0
                cp_y2 = p1[1]
                path.cubicTo(cp_x1, cp_y1, cp_x2, cp_y2, p1[0], p1[1])
                
            # Draw gradient under path
            gradient_path = QPainterPath(path)
            gradient_path.lineTo(self.points[-1][0], rect.height() - padding_bottom)
            gradient_path.lineTo(self.points[0][0], rect.height() - padding_bottom)
            gradient_path.closeSubpath()
            
            gradient = QLinearGradient(0, padding_top, 0, rect.height() - padding_bottom)
            gradient.setColorAt(0.0, QColor(139, 92, 246, 70))
            gradient.setColorAt(1.0, QColor(139, 92, 246, 0))
            painter.fillPath(gradient_path, QBrush(gradient))
            
            painter.setPen(QPen(QColor("#8b5cf6"), 3, Qt.PenStyle.SolidLine))
            painter.drawPath(path)
        else:
            # Draw single point line anchor
            x, y = self.points[0][0], self.points[0][1]
            painter.setPen(QPen(QColor("#cbd5e1"), 2, Qt.PenStyle.DashLine))
            painter.drawLine(padding_left, int(y), rect.width() - padding_right, int(y))
            
        # Draw node circles
        for idx, (x, y, timestamp, percentage, type_label, final_mark) in enumerate(self.points):
            is_hovered = False
            if self.hovered_point is not None:
                hx, hy = self.hovered_point
                dist = math.sqrt((x - hx)**2 + (y - hy)**2)
                if dist < 8:
                    is_hovered = True
                    
            if is_hovered:
                painter.setPen(QPen(QColor("#c084fc"), 2))
                painter.setBrush(QBrush(QColor("#ffffff")))
                painter.drawEllipse(QPointF(x, y), 8, 8)
                
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QBrush(QColor("#8b5cf6")))
                painter.drawEllipse(QPointF(x, y), 5, 5)
                
                # Show tooltip
                tooltip_text = f"Attempt #{idx+1} ({type_label})\nDate: {timestamp[:16]}\nScore: {final_mark:.1f}/20 ({percentage:.1f}%)"
                QToolTip.showText(self.mapToGlobal(QPointF(x, y - 10).toPoint()), tooltip_text, self)
            else:
                painter.setPen(QPen(QColor("#8b5cf6"), 2))
                painter.setBrush(QBrush(QColor("#ffffff")))
                painter.drawEllipse(QPointF(x, y), 5, 5)
                
    def mouseMoveEvent(self, event):
        pos = event.position()
        self.hovered_point = (pos.x(), pos.y())
        self.update()
        
    def leaveEvent(self, event):
        self.hovered_point = None
        self.update()


class ProgressWindow(QMainWindow):
    """Shows unlock progression, long-term stats, and weak areas in a modern interactive tabbed light mode dashboard."""
    revise_topic_requested = pyqtSignal(str)
    history_cleared = pyqtSignal()  # emitted after history is wiped so main_window can refresh

    def __init__(self):
        super().__init__()
        reload(builtin_questions)
        self.history = load_training_history()
        self.theoretical_history = filter_history_by_type(self.history, "theoretical")
        self.practical_history = filter_history_by_type(self.history, "practical")
        self.analytics = build_progress_analytics(
            get_training_questions(builtin_questions.BASE64_QUESTIONS),
            self.theoretical_history,
        )
        self.practical_analytics = build_progress_analytics(
            CODING_QUESTIONS,
            self.practical_history,
        )
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Training Progress Dashboard")
        self.setMinimumSize(1120, 800)

        main_widget = QWidget()
        main_widget.setStyleSheet("background-color: #f8fafc;")
        self.setCentralWidget(main_widget)
        
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(16)

        # Tab widget setup
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #cbd5e1;
                background-color: #f8fafc;
                border-radius: 12px;
                padding: 10px;
            }
            QTabBar::tab {
                background-color: #e2e8f0;
                color: #475569;
                border: 1px solid #cbd5e1;
                border-bottom: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                padding: 12px 24px;
                font-size: 14px;
                font-weight: 800;
                margin-right: 4px;
            }
            QTabBar::tab:selected {
                background-color: #f8fafc;
                color: #8b5cf6;
                border: 1px solid #cbd5e1;
                border-bottom: 2px solid #f8fafc;
            }
            QTabBar::tab:hover {
                background-color: #f1f5f9;
                color: #0f172a;
            }
        """)

        # Add Tab 1: Overview
        self.overview_tab = QScrollArea()
        self.overview_tab.setWidgetResizable(True)
        self.overview_tab.setFrameShape(QFrame.Shape.NoFrame)
        
        overview_content = QWidget()
        overview_content.setStyleSheet("background-color: transparent;")
        overview_layout = QVBoxLayout(overview_content)
        overview_layout.setContentsMargins(10, 10, 10, 10)
        overview_layout.setSpacing(20)
        
        self._add_header(overview_layout)
        
        # Performance Trend Chart
        chart_section = self._section("Performance Trend")
        self.chart_widget = ProgressChartWidget(self.history)
        chart_section.layout().addWidget(self.chart_widget)
        overview_layout.addWidget(chart_section)
        
        insight_row = QHBoxLayout()
        insight_row.setSpacing(20)
        self._add_stats(insight_row)
        self._add_needs_improvement(insight_row)
        overview_layout.addLayout(insight_row)
        
        overview_content.setLayout(overview_layout)
        self.overview_tab.setWidget(overview_content)
        self.tabs.addTab(self.overview_tab, "📊 Overview")

        # Add Tab 2: MCQ Path
        self.mcq_tab = QScrollArea()
        self.mcq_tab.setWidgetResizable(True)
        self.mcq_tab.setFrameShape(QFrame.Shape.NoFrame)
        
        mcq_content = QWidget()
        mcq_content.setStyleSheet("background-color: transparent;")
        mcq_layout = QVBoxLayout(mcq_content)
        mcq_layout.setContentsMargins(10, 10, 10, 10)
        mcq_layout.setSpacing(20)
        
        self._add_unlock_progress(mcq_layout)
        
        mcq_content.setLayout(mcq_layout)
        self.mcq_tab.setWidget(mcq_content)
        self.tabs.addTab(self.mcq_tab, "📚 MCQ Path")

        # Add Tab 3: Coding Path
        self.coding_tab = QScrollArea()
        self.coding_tab.setWidgetResizable(True)
        self.coding_tab.setFrameShape(QFrame.Shape.NoFrame)
        
        coding_content = QWidget()
        coding_content.setStyleSheet("background-color: transparent;")
        coding_layout = QVBoxLayout(coding_content)
        coding_layout.setContentsMargins(10, 10, 10, 10)
        coding_layout.setSpacing(20)
        
        self._add_practical_progress(coding_layout)
        
        coding_content.setLayout(coding_layout)
        self.coding_tab.setWidget(coding_content)
        self.tabs.addTab(self.coding_tab, "🛠️ Coding Path")

        # Add Tab 4: History log
        self.history_tab = QScrollArea()
        self.history_tab.setWidgetResizable(True)
        self.history_tab.setFrameShape(QFrame.Shape.NoFrame)
        
        history_content = QWidget()
        history_content.setStyleSheet("background-color: transparent;")
        self.history_layout = QVBoxLayout(history_content)
        self.history_layout.setContentsMargins(10, 10, 10, 10)
        self.history_layout.setSpacing(16)
        
        self._add_history_controls(self.history_layout)
        self._add_timeline_container(self.history_layout)
        
        history_content.setLayout(self.history_layout)
        self.history_tab.setWidget(history_content)
        self.tabs.addTab(self.history_tab, "⏰ History Log")

        # Add Tab 5: Milestones
        self.milestones_tab = QScrollArea()
        self.milestones_tab.setWidgetResizable(True)
        self.milestones_tab.setFrameShape(QFrame.Shape.NoFrame)
        
        milestones_content = QWidget()
        milestones_content.setStyleSheet("background-color: transparent;")
        milestones_layout = QVBoxLayout(milestones_content)
        milestones_layout.setContentsMargins(10, 10, 10, 10)
        milestones_layout.setSpacing(20)
        
        self._add_milestones_gallery(milestones_layout)
        
        milestones_content.setLayout(milestones_layout)
        self.milestones_tab.setWidget(milestones_content)
        self.tabs.addTab(self.milestones_tab, "🏆 Milestones")

        main_layout.addWidget(self.tabs)

        # Style all vertical scrollbars uniformly
        scroll_style = """
            QScrollArea {
                background-color: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: #f1f5f9;
                width: 12px;
                margin: 2px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #cbd5e1;
                border-radius: 6px;
                min-height: 44px;
            }
            QScrollBar::handle:vertical:hover {
                background: #8b5cf6;
            }
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """
        self.overview_tab.setStyleSheet(scroll_style)
        self.mcq_tab.setStyleSheet(scroll_style)
        self.coding_tab.setStyleSheet(scroll_style)
        self.history_tab.setStyleSheet(scroll_style)
        self.milestones_tab.setStyleSheet(scroll_style)

    def on_topic_card_clicked(self, topic, assessment_type):
        """Called when a TopicCard is clicked."""
        if not topic.get("unlocked", False):
            QMessageBox.information(
                self,
                "Topic Locked",
                f"The topic '{topic['name']}' is currently locked. Complete the previous topics to unlock it!",
            )
            return
        
        dialog = TopicDetailsDialog(topic, self.history, assessment_type, self)
        dialog.exec()

    def _add_header(self, layout):
        header = QFrame()
        header.setObjectName("progressHero")
        header.setStyleSheet("""
            QFrame#progressHero {
                background-color: #ffffff;
                border-radius: 18px;
                border: 1px solid #cbd5e1;
            }
        """)
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(26, 24, 26, 24)
        header_layout.setSpacing(16)

        top_row = QHBoxLayout()
        top_row.setSpacing(18)

        title_box = QVBoxLayout()
        title_box.setSpacing(6)
        title = QLabel("Training Progress")
        title.setStyleSheet("font-size: 34px; font-weight: 900; color: #0f172a; letter-spacing: 0px;")
        title_box.addWidget(title)

        active_topic = self.analytics["progression"].get("active_topic") or "Complete"
        active_difficulty = self.analytics["progression"].get("active_difficulty") or ""
        difficulty_label = DIFFICULTY_LABELS.get(active_difficulty, active_difficulty.title())
        subtitle = QLabel(
            f"Current path: {active_topic} · {difficulty_label} · pass mark {PASSING_MARK:.0f}/20"
        )
        subtitle.setStyleSheet("font-size: 15px; font-weight: 800; color: #475569; letter-spacing: 0px;")
        subtitle.setWordWrap(True)
        title_box.addWidget(subtitle)
        top_row.addLayout(title_box, 1)

        active_badge = QLabel("ACTIVE QUEST")
        active_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        active_badge.setMinimumWidth(132)
        active_badge.setStyleSheet("""
            QLabel {
                color: white;
                background-color: #8b5cf6;
                border: 1px solid #7c3aed;
                border-radius: 12px;
                padding: 10px 14px;
                font-size: 12px;
                font-weight: 900;
                letter-spacing: 1px;
            }
        """)
        top_row.addWidget(active_badge)
        header_layout.addLayout(top_row)

        progress = QProgressBar()
        progress.setRange(0, 100)
        progress.setValue(int(self.analytics["completion_percentage"]))
        progress.setTextVisible(True)
        progress.setFormat(f'{self.analytics["completion_percentage"]:.1f}% unlocked mastery')
        progress.setMinimumHeight(22)
        progress.setStyleSheet("""
            QProgressBar {
                background-color: #e2e8f0;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 11px;
                text-align: center;
                font-weight: 800;
            }
            QProgressBar::chunk {
                background-color: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                          stop: 0 #3b82f6, stop: 1 #8b5cf6);
                border-radius: 11px;
            }
        """)
        header_layout.addWidget(progress)

        metrics = QHBoxLayout()
        metrics.setSpacing(10)
        metrics.addWidget(self._hero_metric(f'{self.analytics["global_average"]:.1f}/20', "Average"))
        metrics.addWidget(self._hero_metric(f'{self.analytics["success_rate"]:.1f}%', "Success"))
        metrics.addWidget(self._hero_metric(str(self.analytics["tests_completed"]), "Tests"))
        metrics.addWidget(self._hero_metric(str(self.practical_analytics["tests_completed"]), "Coding"))
        header_layout.addLayout(metrics)
        layout.addWidget(header)

    def _hero_metric(self, value, label):
        metric = QFrame()
        metric.setObjectName("heroMetric")
        metric.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        metric.setStyleSheet("""
            QFrame#heroMetric {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
            }
            QFrame#heroMetric:hover {
                background-color: #f8fafc;
                border-color: #3b82f6;
            }
        """)
        layout = QVBoxLayout(metric)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(2)
        value_label = QLabel(str(value))
        value_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        value_label.setStyleSheet("font-size: 20px; font-weight: 900; color: #2563eb;")
        label_label = QLabel(label)
        label_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label_label.setStyleSheet("font-size: 11px; font-weight: 900; color: #475569;")
        layout.addWidget(value_label)
        layout.addWidget(label_label)
        return metric

    def _add_unlock_progress(self, layout):
        section = self._section("Theoretical MCQ Path")
        section_layout = section.layout()

        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)

        for index, topic in enumerate(self.analytics["progression"]["topics"]):
            card = TopicCard(topic, "theoretical", self.on_topic_card_clicked)
            grid.addWidget(card, index // 2, index % 2)

        section_layout.addLayout(grid)
        layout.addWidget(section)

    def _add_practical_progress(self, layout):
        section = self._section("Practical Coding Path")
        section_layout = section.layout()

        summary = QHBoxLayout()
        summary.setSpacing(10)
        summary.addWidget(self._hero_metric(f'{self.practical_analytics["global_average"]:.1f}/20', "Coding average"))
        summary.addWidget(self._hero_metric(f'{self.practical_analytics["success_rate"]:.1f}%', "Coding success"))
        summary.addWidget(self._hero_metric(str(self.practical_analytics["tests_completed"]), "Submissions"))
        summary.addWidget(self._hero_metric(f'{self.practical_analytics["completion_percentage"]:.1f}%', "Coding mastery"))
        section_layout.addLayout(summary)

        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)
        for index, topic in enumerate(self.practical_analytics["progression"]["topics"]):
            card = TopicCard(topic, "practical", self.on_topic_card_clicked)
            grid.addWidget(card, index // 2, index % 2)
        section_layout.addLayout(grid)

        average_row = QHBoxLayout()
        average_row.setSpacing(12)
        average_row.addWidget(self._average_list("Practical Topic Averages", self.practical_analytics["topic_averages"]))
        average_row.addWidget(self._average_list("Practical Difficulty Averages", self.practical_analytics["difficulty_averages"]))
        section_layout.addLayout(average_row)

        layout.addWidget(section)

    def _add_stats(self, layout):
        section = self._section("Statistics & Analytics")
        section.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        section_layout = section.layout()

        stats = [
            (f'{self.analytics["global_average"]:.1f}/20', "Global average"),
            (f'{self.analytics["success_rate"]:.1f}%', "Success rate"),
            (f'{self.analytics["failure_rate"]:.1f}%', "Failure rate"),
            (self.analytics["tests_completed"], "Tests completed"),
            (f'{self.analytics["total_points"]:.1f}', "Total points"),
            (f'{self.analytics["completion_percentage"]:.1f}%', "Completion"),
        ]

        grid = QGridLayout()
        grid.setSpacing(10)
        for index, (value, label) in enumerate(stats):
            grid.addWidget(self._stat_card(value, label), index // 2, index % 2)
        section_layout.addLayout(grid)

        average_row = QHBoxLayout()
        average_row.setSpacing(12)
        average_row.addWidget(self._average_list("MCQ Topic Averages", self.analytics["topic_averages"]))
        average_row.addWidget(self._average_list("MCQ Difficulty Averages", self.analytics["difficulty_averages"]))
        section_layout.addLayout(average_row)
        layout.addWidget(section)

    def _stat_card(self, value, label):
        card = QFrame()
        card.setObjectName("statCard")
        card.setStyleSheet("""
            QFrame#statCard {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
            }
            QFrame#statCard:hover {
                border-color: #3b82f6;
                background-color: #f8fafc;
            }
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(4)
        value_label = QLabel(str(value))
        value_label.setStyleSheet("font-size: 26px; font-weight: 900; color: #2563eb;")
        value_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label_label = QLabel(label)
        label_label.setStyleSheet("font-size: 12px; font-weight: 900; color: #475569;")
        label_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(value_label)
        layout.addWidget(label_label)
        return card

    def _average_list(self, title, averages):
        frame = QFrame()
        frame.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        frame.setStyleSheet("""
            QFrame {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 10px;
            }
        """)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(7)
        label = QLabel(title)
        label.setStyleSheet("font-size: 16px; font-weight: 900; color: #0f172a;")
        layout.addWidget(label)

        if not averages:
            empty = QLabel("No completed training attempts yet.")
            empty.setStyleSheet("font-size: 13px; font-weight: 700; color: #94a3b8;")
            layout.addWidget(empty)
            return frame

        for name, mark in sorted(averages.items(), key=lambda item: item[1], reverse=True):
            row = QHBoxLayout()
            name_label = QLabel(name)
            name_label.setStyleSheet("font-size: 13px; font-weight: 800; color: #475569;")
            row.addWidget(name_label)
            row.addStretch()
            mark_label = QLabel(f"{mark:.1f}/20")
            mark_label.setStyleSheet("font-size: 13px; font-weight: 900; color: #0f172a;")
            row.addWidget(mark_label)
            layout.addLayout(row)
        return frame

    def _add_needs_improvement(self, layout):
        section = self._section("Recommendations")
        section.setMinimumWidth(340)
        section.setMaximumWidth(450)
        section_layout = section.layout()

        # Calculate averages for each topic from self.history (across both theoretical and practical attempts)
        from collections import defaultdict
        topic_totals = defaultdict(list)
        for attempt in self.history:
            topic = attempt.get("topic") or attempt.get("target_topic")
            mark = float(attempt.get("final_mark", 0) or 0)
            if topic:
                topic_totals[topic].append(mark)
            else:
                for t_name, data in attempt.get("topic_marks", {}).items():
                    topic_totals[t_name].append(float(data.get("mark", 0) or 0))

        weak_topics = []
        for topic, marks in topic_totals.items():
            avg = sum(marks) / len(marks)
            if avg < 14.0:
                weak_topics.append((topic, avg))
        weak_topics.sort(key=lambda x: x[1])

        if not weak_topics:
            ok = QLabel("Félicitations ! Aucune faiblesse (moyenne < 14/20) détectée.")
            ok.setWordWrap(True)
            ok.setStyleSheet("""
                QLabel {
                    color: #047857;
                    background-color: #d1fae5;
                    border: 1px solid #10b981;
                    border-radius: 10px;
                    padding: 12px;
                    font-size: 13px;
                    font-weight: 800;
                }
            """)
            section_layout.addWidget(ok)
        else:
            for name, avg in weak_topics:
                card = QFrame()
                card.setObjectName("weakTopicCard")
                card.setStyleSheet("""
                    QFrame#weakTopicCard {
                        background-color: #fff1f2;
                        border: 1px solid #fecdd3;
                        border-radius: 10px;
                    }
                """)
                card_layout = QHBoxLayout(card)
                card_layout.setContentsMargins(10, 8, 10, 8)
                
                info_layout = QVBoxLayout()
                info_layout.setSpacing(2)
                
                topic_lbl = QLabel(name)
                topic_lbl.setWordWrap(True)
                topic_lbl.setStyleSheet("font-size: 13px; font-weight: 800; color: #9f1239; background: transparent; border: none;")
                
                avg_lbl = QLabel(f"Moyenne : {avg:.1f}/20")
                avg_lbl.setStyleSheet("font-size: 12px; font-weight: 600; color: #be123c; background: transparent; border: none;")
                
                info_layout.addWidget(topic_lbl)
                info_layout.addWidget(avg_lbl)
                card_layout.addLayout(info_layout)
                
                revise_btn = QPushButton("🎯 Réviser")
                revise_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                revise_btn.setStyleSheet("""
                    QPushButton {
                        background-color: #ffffff;
                        color: #be123c;
                        border: 1px solid #fda4af;
                        border-radius: 6px;
                        padding: 6px 12px;
                        font-size: 12px;
                        font-weight: bold;
                    }
                    QPushButton:hover {
                        background-color: #ffe4e6;
                        border-color: #f43f5e;
                    }
                    QPushButton:pressed {
                        background-color: #fecdd3;
                    }
                """)
                revise_btn.clicked.connect(lambda checked, t=name: self.revise_topic_requested.emit(t))
                card_layout.addWidget(revise_btn)
                
                section_layout.addWidget(card)

        layout.addWidget(section)

    def _add_milestones_gallery(self, layout):
        from core.leveling_system import calculate_leveling_data, get_all_levels_info

        data = calculate_leveling_data(self.history)
        all_levels = get_all_levels_info()

        # ── LEVELS PROGRESSION TABLE ────────────────────────────────────────
        levels_section = self._section("Progression des Niveaux")
        lsec_layout = levels_section.layout()

        levels_intro = QLabel(
            "Voici les 10 niveaux et les XP nécessaires pour les atteindre. "
            "Votre niveau actuel est mis en évidence."
        )
        levels_intro.setStyleSheet("font-size: 13px; color: #64748b; font-weight: 500; background: transparent; border: none;")
        levels_intro.setWordWrap(True)
        lsec_layout.addWidget(levels_intro)

        levels_grid = QGridLayout()
        levels_grid.setSpacing(10)

        level_emojis = ["🌱", "📘", "🔓", "📐", "🚀", "🔬", "🏅", "🌟", "🏆", "👑"]

        for i, lv in enumerate(all_levels):
            is_current = lv["level"] == data["level"]
            is_reached = lv["level"] <= data["level"]

            if is_current:
                bg, border, text_col = "#fef9c3", "#facc15", "#78350f"
            elif is_reached:
                bg, border, text_col = "#f0fdf4", "#86efac", "#14532d"
            else:
                bg, border, text_col = "#f8fafc", "#e2e8f0", "#94a3b8"

            lv_card = QFrame()
            lv_card.setStyleSheet(f"""
                QFrame {{
                    background-color: {bg};
                    border: 2px solid {border};
                    border-radius: 10px;
                    padding: 4px;
                }}
            """)
            lv_lay = QVBoxLayout(lv_card)
            lv_lay.setContentsMargins(10, 8, 10, 8)
            lv_lay.setSpacing(3)
            lv_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

            emoji_lbl = QLabel(level_emojis[i])
            emoji_lbl.setStyleSheet("font-size: 22px; background: transparent; border: none;")
            emoji_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

            title_lbl = QLabel(f"Niv. {lv['level']} — {lv['name']}")
            title_lbl.setStyleSheet(f"font-size: 13px; font-weight: 900; color: {text_col}; background: transparent; border: none;")
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

            xp_lbl = QLabel(f"≥ {lv['xp_required']} XP")
            xp_lbl.setStyleSheet(f"font-size: 12px; font-weight: 700; color: {text_col}; background: transparent; border: none;")
            xp_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

            if is_current:
                status_txt = f"📍 Actuel — {data['xp']} XP"
                next_xp = lv["xp_next"]
                remaining = max(0, next_xp - data['xp'])
                status_txt2 = f"Prochain niveau à {next_xp} XP (encore {remaining} XP)"
                status2 = QLabel(status_txt2)
                status2.setStyleSheet(f"font-size: 10px; font-weight: 700; color: {text_col}; background: transparent; border: none;")
                status2.setAlignment(Qt.AlignmentFlag.AlignCenter)
                status2.setWordWrap(True)
            elif is_reached:
                status_txt = "✅ Atteint"
                status2 = None
            else:
                remaining = lv["xp_required"] - data["xp"]
                status_txt = f"🔒 {remaining} XP manquants"
                status2 = None

            status_lbl = QLabel(status_txt)
            status_lbl.setStyleSheet(f"font-size: 11px; font-weight: 800; color: {text_col}; background: transparent; border: none;")
            status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

            lv_lay.addWidget(emoji_lbl)
            lv_lay.addWidget(title_lbl)
            lv_lay.addWidget(xp_lbl)
            lv_lay.addWidget(status_lbl)
            if is_current and status2:
                lv_lay.addWidget(status2)

            row = i // 5
            col = i % 5
            levels_grid.addWidget(lv_card, row, col)

        lsec_layout.addLayout(levels_grid)
        layout.addWidget(levels_section)

        # ── MILESTONES GALLERY ──────────────────────────────────────────────
        section = self._section("Succès & Milestones")
        section_layout = section.layout()

        desc = QLabel("Accomplissez des défis lors de vos entraînements pour débloquer des badges exclusifs.")
        desc.setStyleSheet("font-size: 13px; color: #64748b; font-weight: 500; background: transparent; border: none; margin-bottom: 10px;")
        section_layout.addWidget(desc)

        summary_lbl = QLabel(
            f"🏆 Badges débloqués : {data['unlocked_badges']} sur {data['total_badges']}  |  "
            f"⭐ Niveau {data['level']} — {data['level_name']}  |  "
            f"XP : {data['xp']} / 2760 points"
        )
        summary_lbl.setStyleSheet("""
            QLabel {
                font-size: 15px;
                font-weight: 900;
                color: #7c3aed;
                background-color: #f3e8ff;
                border: 2px solid #c084fc;
                border-radius: 10px;
                padding: 12px 18px;
                margin-bottom: 15px;
            }
        """)
        section_layout.addWidget(summary_lbl)

        def add_badge_group(title_text, milestones_list):
            group_frame = QFrame()
            group_frame.setStyleSheet("background: transparent; border: none;")
            group_lay = QVBoxLayout(group_frame)
            group_lay.setContentsMargins(0, 0, 0, 15)
            group_lay.setSpacing(10)

            title_lbl = QLabel(title_text)
            title_lbl.setStyleSheet("font-size: 16px; font-weight: 900; color: #1e293b; margin-top: 10px;")
            group_lay.addWidget(title_lbl)

            grid = QGridLayout()
            grid.setSpacing(12)
            for idx, m in enumerate(milestones_list):
                if m["unlocked"]:
                    progress_text = f"Débloqué ! (+{m['points']} XP)"
                else:
                    if "note" in m["desc"].lower() or "score" in m["desc"].lower() or "≥" in m["desc"]:
                        progress_text = f"Requis : {m['target']:.0f}/20 (Meilleure : {m['actual']:.1f}/20)"
                    else:
                        progress_text = f"Requis : {m['target']} (Actuel : {m['actual']} / {m['target']})"

                card = self._create_badge_card(m["emoji"], m["name"], m["desc"], m["unlocked"], progress_text)
                row = idx // 3
                col = idx % 3
                grid.addWidget(card, row, col)

            group_lay.addLayout(grid)
            section_layout.addWidget(group_frame)

        add_badge_group("📖 Entraînements Théoriques Réussis (MCQ)", data["theo_milestones"])
        add_badge_group("💻 Laboratoires Pratiques Réussis (Coding)", data["prac_milestones"])

        # ── Per-topic mastery rows (compact: 1 row per topic, MCQ + Coding) ──
        from core.exam_code import TOPIC_ORDER

        def _tier_for_score(score):
            if score == 20.0: return 2  # gold
            if score >= 18.0: return 1  # silver
            if score >= 16.0: return 0  # bronze
            return -1                   # none

        tiers_info = [
            {"emoji": "🥉", "label": "Bronze", "color": "#b45309", "bg": "#fef3c7", "border": "#fcd34d", "xp": 10, "req": "≥16/20"},
            {"emoji": "🥈", "label": "Argent", "color": "#475569", "bg": "#f1f5f9", "border": "#94a3b8", "xp": 20, "req": "≥18/20"},
            {"emoji": "🥇", "label": "Or",     "color": "#92400e", "bg": "#fef9c3", "border": "#fbbf24", "xp": 50, "req": "=20/20"},
        ]

        def build_topic_type_cell(score, label):
            """Build a small cell showing current badge and next one to get."""
            tier = _tier_for_score(score)
            cell = QFrame()

            if tier == 2:
                # Max — gold
                cell.setStyleSheet("""QFrame { background: #fef9c3; border: 1.5px solid #fbbf24; border-radius: 8px; }""")
                lay = QVBoxLayout(cell)
                lay.setContentsMargins(8, 6, 8, 6)
                lay.setSpacing(2)
                emo = QLabel("🥇")
                emo.setStyleSheet("font-size: 20px; background: transparent; border: none;")
                emo.setAlignment(Qt.AlignmentFlag.AlignCenter)
                t = QLabel(f"{label} · Or ✓")
                t.setStyleSheet("font-size: 11px; font-weight: 800; color: #92400e; background: transparent; border: none;")
                t.setAlignment(Qt.AlignmentFlag.AlignCenter)
                s = QLabel(f"Score : {score:.1f}/20")
                s.setStyleSheet("font-size: 10px; font-weight: 600; color: #78350f; background: transparent; border: none;")
                s.setAlignment(Qt.AlignmentFlag.AlignCenter)
                lay.addWidget(emo)
                lay.addWidget(t)
                lay.addWidget(s)
            elif tier >= 0:
                current = tiers_info[tier]
                nxt = tiers_info[tier + 1]
                cell.setStyleSheet(f"""QFrame {{ background: {current['bg']}; border: 1.5px solid {current['border']}; border-radius: 8px; }}""")
                lay = QVBoxLayout(cell)
                lay.setContentsMargins(8, 6, 8, 6)
                lay.setSpacing(2)

                row1 = QHBoxLayout()
                row1.setSpacing(4)
                cur_emo = QLabel(current["emoji"])
                cur_emo.setStyleSheet("font-size: 16px; background: transparent; border: none;")
                cur_lbl = QLabel(f"{current['label']} ✓")
                cur_lbl.setStyleSheet(f"font-size: 11px; font-weight: 800; color: {current['color']}; background: transparent; border: none;")
                row1.addWidget(cur_emo)
                row1.addWidget(cur_lbl)
                row1.addStretch()

                row2 = QHBoxLayout()
                row2.setSpacing(4)
                nxt_emo = QLabel(nxt["emoji"])
                nxt_emo.setStyleSheet("font-size: 14px; background: transparent; border: none; opacity: 0.6;")
                nxt_lbl = QLabel(f"→ {nxt['label']} ({nxt['req']})")
                nxt_lbl.setStyleSheet(f"font-size: 10px; font-weight: 700; color: #64748b; background: transparent; border: none;")
                row2.addWidget(nxt_emo)
                row2.addWidget(nxt_lbl)
                row2.addStretch()

                score_lbl = QLabel(f"Score actuel : {score:.1f}/20")
                score_lbl.setStyleSheet(f"font-size: 10px; font-weight: 600; color: {current['color']}; background: transparent; border: none;")

                top_lbl = QLabel(label)
                top_lbl.setStyleSheet(f"font-size: 10px; font-weight: 700; color: #64748b; background: transparent; border: none;")

                lay.addWidget(top_lbl)
                lay.addLayout(row1)
                lay.addLayout(row2)
                lay.addWidget(score_lbl)
            else:
                # Locked
                first = tiers_info[0]
                cell.setStyleSheet("""QFrame { background: #f8fafc; border: 1.5px solid #e2e8f0; border-radius: 8px; }""")
                lay = QVBoxLayout(cell)
                lay.setContentsMargins(8, 6, 8, 6)
                lay.setSpacing(2)
                emo = QLabel("🔒")
                emo.setStyleSheet("font-size: 18px; background: transparent; border: none;")
                emo.setAlignment(Qt.AlignmentFlag.AlignCenter)
                top = QLabel(label)
                top.setStyleSheet("font-size: 10px; font-weight: 700; color: #94a3b8; background: transparent; border: none;")
                top.setAlignment(Qt.AlignmentFlag.AlignCenter)
                t = QLabel(f"Débutez avec {first['req']}")
                t.setStyleSheet("font-size: 10px; font-weight: 700; color: #94a3b8; background: transparent; border: none;")
                t.setAlignment(Qt.AlignmentFlag.AlignCenter)
                nxt_emo_lbl = QLabel(f"{first['emoji']} Bronze (+{first['xp']} XP)")
                nxt_emo_lbl.setStyleSheet("font-size: 10px; font-weight: 600; color: #cbd5e1; background: transparent; border: none;")
                nxt_emo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
                lay.addWidget(emo)
                lay.addWidget(top)
                lay.addWidget(t)
                lay.addWidget(nxt_emo_lbl)

            return cell

        # Build score lookup per topic × type
        from core.leveling_system import match_canonical_topic
        scores_theo = {t: 0.0 for t in TOPIC_ORDER}
        scores_prac = {t: 0.0 for t in TOPIC_ORDER}
        for m in data["theo_topic_milestones"]:
            if m["unlocked"] and "_theo_" in m["id"]:
                topic = m["id"].rsplit("_theo_", 1)[0]
                # Find best score already stored in actual field
                scores_theo[topic] = max(scores_theo.get(topic, 0.0), m["actual"])
        for m in data["prac_topic_milestones"]:
            if "_prac_" in m["id"]:
                topic = m["id"].rsplit("_prac_", 1)[0]
                scores_prac[topic] = max(scores_prac.get(topic, 0.0), m["actual"])
        # Use actual (highest score) directly from milestone data regardless of unlocked
        for m in data["theo_topic_milestones"]:
            if "_theo_bronze" in m["id"]:
                t = m["id"].replace("_theo_bronze", "")
                if t in TOPIC_ORDER:
                    scores_theo[t] = m["actual"]
        for m in data["prac_topic_milestones"]:
            if "_prac_bronze" in m["id"]:
                t = m["id"].replace("_prac_bronze", "")
                if t in TOPIC_ORDER:
                    scores_prac[t] = m["actual"]

        topic_section = self._section("🏅 Maîtrise par Thème (MCQ & Coding)")
        ts_layout = topic_section.layout()

        ts_intro = QLabel(
            "Pour chaque thème, votre meilleure note MCQ et Coding est affichée, "
            "ainsi que le prochain badge à débloquer."
        )
        ts_intro.setStyleSheet("font-size: 13px; color: #64748b; font-weight: 500; background: transparent; border: none;")
        ts_intro.setWordWrap(True)
        ts_layout.addWidget(ts_intro)

        # Column header
        header_row = QHBoxLayout()
        header_row.setSpacing(10)
        h_topic = QLabel("Thème")
        h_topic.setFixedWidth(170)
        h_topic.setStyleSheet("font-size: 12px; font-weight: 900; color: #475569; background: transparent; border: none;")
        h_mcq = QLabel("MCQ (Théorique)")
        h_mcq.setStyleSheet("font-size: 12px; font-weight: 900; color: #2563eb; background: transparent; border: none;")
        h_code = QLabel("Coding (Pratique)")
        h_code.setStyleSheet("font-size: 12px; font-weight: 900; color: #7c3aed; background: transparent; border: none;")
        header_row.addWidget(h_topic)
        header_row.addWidget(h_mcq, 1)
        header_row.addWidget(h_code, 1)
        ts_layout.addLayout(header_row)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background: #e2e8f0; border: none; max-height: 1px;")
        ts_layout.addWidget(sep)

        for topic in TOPIC_ORDER:
            row_frame = QFrame()
            row_frame.setStyleSheet("QFrame { background: transparent; border: none; }")
            row_lay = QHBoxLayout(row_frame)
            row_lay.setContentsMargins(0, 4, 0, 4)
            row_lay.setSpacing(10)

            topic_lbl = QLabel(topic)
            topic_lbl.setFixedWidth(170)
            topic_lbl.setWordWrap(True)
            topic_lbl.setStyleSheet("font-size: 12px; font-weight: 800; color: #1e293b; background: transparent; border: none;")
            row_lay.addWidget(topic_lbl)

            mcq_cell = build_topic_type_cell(scores_theo.get(topic, 0.0), "MCQ")
            prac_cell = build_topic_type_cell(scores_prac.get(topic, 0.0), "Coding")
            row_lay.addWidget(mcq_cell, 1)
            row_lay.addWidget(prac_cell, 1)

            ts_layout.addWidget(row_frame)

            divider = QFrame()
            divider.setFrameShape(QFrame.Shape.HLine)
            divider.setStyleSheet("background: #f1f5f9; border: none; max-height: 1px;")
            ts_layout.addWidget(divider)

        layout.addWidget(topic_section)
        layout.addWidget(section)


    def _create_badge_card(self, emoji, name, description, unlocked, progress_text):
        card = QFrame()
        card.setObjectName("badgeCard")
        
        if unlocked:
            bg_color = "#f3e8ff"      # very soft violet background
            border_color = "#c084fc"  # purple-400
            emoji_style = "font-size: 32px; background: transparent; border: none;"
            title_style = "font-size: 14px; font-weight: 800; color: #6b21a8; background: transparent; border: none;"
            desc_style = "font-size: 11px; font-weight: 600; color: #581c87; background: transparent; border: none;"
            progress_style = "font-size: 11px; font-weight: 800; color: #7c3aed; background: transparent; border: none;"
        else:
            bg_color = "#f1f5f9"      # slate-100 (locked, greyscaled)
            border_color = "#cbd5e1"  # slate-300
            emoji_style = "font-size: 32px; background: transparent; border: none; color: #94a3b8;"
            title_style = "font-size: 14px; font-weight: 800; color: #64748b; background: transparent; border: none;"
            desc_style = "font-size: 11px; font-weight: 600; color: #94a3b8; background: transparent; border: none;"
            progress_style = "font-size: 11px; font-weight: 800; color: #64748b; background: transparent; border: none;"
            
        card.setStyleSheet(f"""
            QFrame#badgeCard {{
                background-color: {bg_color};
                border: 2px solid {border_color};
                border-radius: 12px;
                padding: 12px;
            }}
        """)
        
        layout = QVBoxLayout(card)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        emoji_lbl = QLabel(emoji)
        emoji_lbl.setStyleSheet(emoji_style)
        emoji_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title_lbl = QLabel(name)
        title_lbl.setStyleSheet(title_style)
        title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        desc_lbl = QLabel(description)
        desc_lbl.setStyleSheet(desc_style)
        desc_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_lbl.setWordWrap(True)
        
        progress_lbl = QLabel(progress_text)
        progress_lbl.setStyleSheet(progress_style)
        progress_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        status_lbl = QLabel("✓ Débloqué" if unlocked else "🔒 Verrouillé")
        status_lbl_color = "#047857" if unlocked else "#94a3b8"
        status_lbl.setStyleSheet(f"font-size: 10px; font-weight: 900; color: {status_lbl_color}; background: transparent; border: none;")
        status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        layout.addWidget(emoji_lbl)
        layout.addWidget(title_lbl)
        layout.addWidget(desc_lbl)
        layout.addWidget(progress_lbl)
        layout.addWidget(status_lbl)
        
        return card

    def _add_history_controls(self, layout):
        """Header card containing real-time filters for training history in light mode."""
        controls_frame = QFrame()
        controls_frame.setStyleSheet("""
            QFrame {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
            }
        """)
        controls_layout = QHBoxLayout(controls_frame)
        controls_layout.setContentsMargins(16, 12, 16, 12)
        controls_layout.setSpacing(16)

        # Search Bar
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by topic or question name...")
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: #f8fafc;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                padding: 10px 14px;
                font-size: 13px;
                font-weight: 700;
            }
            QLineEdit:focus {
                border-color: #8b5cf6;
            }
        """)
        self.search_input.textChanged.connect(self.filter_history)
        controls_layout.addWidget(self.search_input, 3)

        # Type Filter
        self.type_filter = QComboBox()
        self.type_filter.addItems(["All Assessment Types", "Theoretical MCQ", "Practical Coding"])
        self.type_filter.setStyleSheet("""
            QComboBox {
                background-color: #f8fafc;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                padding: 10px 14px;
                font-size: 13px;
                font-weight: 700;
                min-width: 180px;
            }
            QComboBox:focus {
                border-color: #8b5cf6;
            }
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #0f172a;
                selection-background-color: #8b5cf6;
                selection-color: white;
                border: 1px solid #cbd5e1;
            }
        """)
        self.type_filter.currentIndexChanged.connect(self.filter_history)
        controls_layout.addWidget(self.type_filter, 1)

        # Status Filter
        self.status_filter = QComboBox()
        self.status_filter.addItems(["All Results", "Passed", "Failed"])
        self.status_filter.setStyleSheet("""
            QComboBox {
                background-color: #f8fafc;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                padding: 10px 14px;
                font-size: 13px;
                font-weight: 700;
                min-width: 140px;
            }
            QComboBox:focus {
                border-color: #8b5cf6;
            }
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #0f172a;
                selection-background-color: #8b5cf6;
                selection-color: white;
                border: 1px solid #cbd5e1;
            }
        """)
        self.status_filter.currentIndexChanged.connect(self.filter_history)
        controls_layout.addWidget(self.status_filter, 1)

        # Clear History Button
        self.clear_history_btn = QPushButton("🗑️ Clear History")
        self.clear_history_btn.setStyleSheet("""
            QPushButton {
                background-color: #fee2e2;
                color: #ef4444;
                border: 1px solid #fca5a5;
                border-radius: 8px;
                padding: 10px 16px;
                font-size: 13px;
                font-weight: 800;
            }
            QPushButton:hover {
                background-color: #ef4444;
                color: white;
                border-color: #dc2626;
            }
            QPushButton:pressed {
                background-color: #b91c1c;
                color: white;
            }
        """)
        self.clear_history_btn.clicked.connect(self.clear_history_action)
        controls_layout.addWidget(self.clear_history_btn, 0)

        layout.addWidget(controls_frame)

    def _add_timeline_container(self, layout):
        """Scrollable area containing timeline attempts in light mode."""
        self.timeline_scroll = QScrollArea()
        self.timeline_scroll.setWidgetResizable(True)
        self.timeline_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.timeline_scroll.setStyleSheet("background-color: transparent; border: none;")

        self.timeline_content = QWidget()
        self.timeline_content.setStyleSheet("background-color: transparent;")
        self.timeline_layout = QVBoxLayout(self.timeline_content)
        self.timeline_layout.setContentsMargins(0, 0, 0, 0)
        self.timeline_layout.setSpacing(10)

        self.history_items = []
        
        if not self.history:
            empty = QLabel("No training history completed yet.")
            empty.setStyleSheet("font-size: 14px; font-weight: 800; color: #94a3b8; padding: 20px;")
            self.timeline_layout.addWidget(empty)
        else:
            for attempt in reversed(self.history):
                atype = attempt.get("assessment_type", "theoretical")
                topic = attempt.get("target_topic") or ", ".join(attempt.get("selected_topics", [])) or "Training"
                difficulty = attempt.get("target_difficulty") or ", ".join(attempt.get("selected_difficulties", [])) or "custom"
                passed = is_passing_attempt(attempt)
                status = "Passed" if passed else "Failed"
                color = "#10b981" if passed else "#ef4444"
                
                q_title = attempt.get("question_title")
                type_label = "Coding" if atype == "practical" else "MCQ"
                
                display_text = f'{attempt.get("timestamp", "")} · [{type_label}] '
                if q_title:
                    display_text += f'{q_title} · '
                display_text += f'{topic} · {difficulty.title()} · {attempt.get("final_mark", 0):.1f}/20 · {status}'

                row = QFrame()
                row.setObjectName("historyRow")
                row.setStyleSheet(f"""
                    QFrame#historyRow {{
                        background-color: #ffffff;
                        color: #334155;
                        border-left: 4px solid {color};
                        border-top: 1px solid #cbd5e1;
                        border-right: 1px solid #cbd5e1;
                        border-bottom: 1px solid #cbd5e1;
                        border-radius: 8px;
                    }}
                    QFrame#historyRow:hover {{
                        background-color: #f8fafc;
                        border-color: #8b5cf6;
                    }}
                """)
                row_lay = QHBoxLayout(row)
                row_lay.setContentsMargins(12, 10, 12, 10)

                lbl = QLabel(display_text)
                lbl.setStyleSheet("font-size: 13px; font-weight: 800; color: #334155;")
                lbl.setWordWrap(True)
                row_lay.addWidget(lbl)

                self.timeline_layout.addWidget(row)
                
                self.history_items.append({
                    "widget": row,
                    "type": atype,
                    "passed": passed,
                    "topic": topic.lower(),
                    "q_title": (q_title or "").lower(),
                })

        self.timeline_layout.addStretch()
        self.timeline_scroll.setWidget(self.timeline_content)
        layout.addWidget(self.timeline_scroll)

    def filter_history(self):
        """Filters historical rows dynamically as search or filter states change."""
        search_text = self.search_input.text().strip().lower()
        type_idx = self.type_filter.currentIndex()
        status_idx = self.status_filter.currentIndex()

        for item in self.history_items:
            widget = item["widget"]
            
            # Match search text
            match_search = (
                not search_text 
                or search_text in item["topic"] 
                or search_text in item["q_title"]
            )
            
            # Match type filter (0: All, 1: Theoretical MCQ, 2: Practical Coding)
            match_type = True
            if type_idx == 1:
                match_type = (item["type"] == "theoretical")
            elif type_idx == 2:
                match_type = (item["type"] == "practical")
                
            # Match status filter (0: All, 1: Passed, 2: Failed)
            match_status = True
            if status_idx == 1:
                match_status = item["passed"]
            elif status_idx == 2:
                match_status = not item["passed"]

            # Show or hide
            if match_search and match_type and match_status:
                widget.show()
            else:
                widget.hide()

    def _section(self, title):
        frame = QFrame()
        frame.setObjectName("dashboardSection")
        frame.setStyleSheet("""
            QFrame#dashboardSection {
                background-color: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 16px;
            }
        """)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(16)
        title_label = QLabel(title)
        title_label.setStyleSheet("font-size: 22px; font-weight: 900; color: #0f172a; letter-spacing: 0px;")
        layout.addWidget(title_label)
        return frame

    def clear_history_action(self):
        confirm = QMessageBox(self)
        confirm.setIcon(QMessageBox.Icon.Warning)
        confirm.setWindowTitle("Clear History")
        confirm.setText("Are you sure you want to delete all training history?")
        confirm.setInformativeText("This action is permanent and cannot be undone.")
        confirm.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        confirm.setDefaultButton(QMessageBox.StandardButton.No)
        
        confirm.setStyleSheet("""
            QMessageBox {
                background-color: #ffffff;
            }
            QLabel {
                color: #0f172a;
                font-size: 14px;
            }
            QPushButton {
                background-color: #f1f5f9;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 13px;
                font-weight: 700;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #e2e8f0;
            }
            QPushButton[text="&Yes"] {
                background-color: #ef4444;
                color: white;
                border-color: #dc2626;
            }
            QPushButton[text="&Yes"]:hover {
                background-color: #dc2626;
            }
        """)
        
        if confirm.exec() == QMessageBox.StandardButton.Yes:
            clear_training_history()
            self.history_cleared.emit()
            
            self.history = []
            self.theoretical_history = []
            self.practical_history = []
            
            self.analytics = build_progress_analytics(
                get_training_questions(builtin_questions.BASE64_QUESTIONS),
                self.theoretical_history,
            )
            self.practical_analytics = build_progress_analytics(
                CODING_QUESTIONS,
                self.practical_history,
            )
            
            self.init_ui()
            
            success = QMessageBox(self)
            success.setIcon(QMessageBox.Icon.Information)
            success.setWindowTitle("History Cleared")
            success.setText("All training history has been successfully cleared.")
            success.setStyleSheet("""
                QMessageBox { background-color: #ffffff; }
                QLabel { color: #0f172a; font-size: 14px; }
                QPushButton {
                    background-color: #f1f5f9;
                    color: #0f172a;
                    border: 1px solid #cbd5e1;
                    border-radius: 6px;
                    padding: 6px 14px;
                    font-size: 13px;
                    font-weight: 700;
                }
                QPushButton:hover { background-color: #e2e8f0; }
            """)
            success.exec()
