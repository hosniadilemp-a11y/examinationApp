"""
Modern minimalist results window with elegant visualizations and auto-generated reports.
"""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QMessageBox, QFrame,
    QScrollArea, QGridLayout, QSizePolicy, QProgressBar
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QPoint, pyqtProperty,pyqtSignal
from PyQt6.QtGui import QFont, QColor, QPainter, QPen, QLinearGradient, QDesktopServices
from PyQt6.QtCore import QUrl
import os
import sys
from core.training_history import (
    load_training_history, 
    get_progression_stats, 
    get_topic_historical_averages,
    get_level
)


class CircularProgress(QWidget):
    """Custom circular progress indicator with dynamic styling."""
        # New signal to request exit
    
    def __init__(self, percentage, size=120):
        super().__init__()
        self.percentage = percentage
        self.size = size
        self.setMinimumSize(size, size)
        self._animated_percentage = 0.0
        
        # Determine color based on percentage
        if percentage >= 70:
            self.color = "#10b981"  # Green - Excellent
            self.bg_color = "#d1fae5"
        elif percentage >= 50:
            self.color = "#f59e0b"  # Orange - Good
            self.bg_color = "#fef3c7"
        elif percentage > 0:
            self.color = "#ef4444"  # Red - Needs improvement
            self.bg_color = "#fee2e2"
        else:
            self.color = "#9ca3af"  # Gray - No score
            self.bg_color = "#f3f4f6"
        
        # Animation
        self.animation = QPropertyAnimation(self, b"animatedPercentage")
        self.animation.setDuration(1500)
        self.animation.setStartValue(0.0)
        self.animation.setEndValue(float(percentage))
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
    
    def start_animation(self):
        """Start the progress animation."""
        self.animation.start()
    
    def getAnimatedPercentage(self):
        return self._animated_percentage
    
    def setAnimatedPercentage(self, value):
        self._animated_percentage = value
        self.update()
    
    animatedPercentage = pyqtProperty(float, getAnimatedPercentage, setAnimatedPercentage)
    
    def paintEvent(self, event):
        """Draw the circular progress."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Background circle
        pen = QPen(QColor(self.bg_color), 10)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        rect = self.rect().adjusted(10, 10, -10, -10)
        painter.drawArc(rect, 90 * 16, -360 * 16)
        
        # Progress arc
        pen = QPen(QColor(self.color), 10)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        angle = int(360 * self._animated_percentage / 100)
        painter.drawArc(rect, 90 * 16, -angle * 16)
        
        # Center text
        painter.setPen(QColor("#1f2937"))
        font = QFont("Segoe UI", 26, QFont.Weight.Bold)
        painter.setFont(font)
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, f"{int(self._animated_percentage)}%")


class StatCard(QFrame):
    """Minimalist statistics card with emoji."""
    
    def __init__(self, value, label, emoji="", color="#3b82f6"):
        super().__init__()
        self.setObjectName("statCard")
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Emoji
        if emoji:
            emoji_label = QLabel(emoji)
            emoji_label.setStyleSheet("font-size: 36px;")
            emoji_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(emoji_label)
        
        # Value
        value_label = QLabel(str(value))
        value_label.setStyleSheet(f"""
            font-size: 32px;
            font-weight: bold;
            color: {color};
        """)
        value_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(value_label)
        
        # Label
        label_label = QLabel(label)
        label_label.setStyleSheet("""
            font-size: 13px;
            color: #6b7280;
            font-weight: 500;
        """)
        label_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(label_label)
        
        self.setStyleSheet(f"""
            QFrame#statCard {{
                background-color: white;
                border-radius: 16px;
                border: 2px solid #f3f4f6;
            }}
            QFrame#statCard:hover {{
                border: 2px solid {color};
                background-color: #fafafa;
            }}
        """)


class DifficultyBar(QWidget):
    """Horizontal bar showing difficulty breakdown."""
    
    def __init__(self, easy_pct, medium_pct, hard_pct, very_hard_pct=0):
        super().__init__()
        self.segments = [
            (easy_pct, "#10b981"),
            (medium_pct, "#f59e0b"),
            (hard_pct, "#ef4444"),
            (very_hard_pct, "#7c3aed"),
        ]
        self.setMinimumHeight(34)
        
    def paintEvent(self, event):
        """Draw the difficulty breakdown bar."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        width = self.width()
        height = 24
        y_pos = 8
        radius = 12
        
        # Background
        painter.setBrush(QColor("#f3f4f6"))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, y_pos, width, height, radius, radius)
        
        x_pos = 0
        visible_segments = [(pct, color) for pct, color in self.segments if pct > 0]

        for index, (pct, color) in enumerate(visible_segments):
            segment_width = int(width * pct / 100)
            if index == len(visible_segments) - 1:
                segment_width = width - x_pos

            painter.setBrush(QColor(color))
            if len(visible_segments) == 1:
                painter.drawRoundedRect(x_pos, y_pos, segment_width, height, radius, radius)
            elif index == 0:
                painter.drawRoundedRect(x_pos, y_pos, segment_width + radius, height, radius, radius)
            elif index == len(visible_segments) - 1:
                painter.drawRoundedRect(x_pos - radius, y_pos, segment_width + radius, height, radius, radius)
            else:
                painter.drawRect(x_pos, y_pos, segment_width, height)
            x_pos += segment_width


class MarkEvolutionChart(QWidget):
    """Simple line chart for mark evolution."""

    def __init__(self, marks, title, color="#3b82f6"):
        super().__init__()
        self.marks = marks[-12:]
        self.title = title
        self.color = color
        self.setMinimumHeight(180)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(20, 24, -20, -28)

        painter.setPen(QColor("#111827"))
        painter.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        painter.drawText(20, 18, self.title)

        painter.setPen(QPen(QColor("#e5e7eb"), 1))
        painter.drawLine(rect.left(), rect.bottom(), rect.right(), rect.bottom())
        painter.drawLine(rect.left(), rect.top(), rect.left(), rect.bottom())

        if not self.marks:
            painter.setPen(QColor("#6b7280"))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "No training history yet")
            return

        if len(self.marks) == 1:
            x = rect.center().x()
            y = rect.bottom() - int((self.marks[0] / 20) * rect.height())
            painter.setBrush(QColor(self.color))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(x - 5, y - 5, 10, 10)
            painter.setPen(QColor("#374151"))
            painter.drawText(x - 18, y - 12, f"{self.marks[0]:.1f}")
            return

        points = []
        for index, mark in enumerate(self.marks):
            x = rect.left() + int((index / (len(self.marks) - 1)) * rect.width())
            y = rect.bottom() - int((mark / 20) * rect.height())
            points.append((x, y, mark))

        painter.setPen(QPen(QColor(self.color), 3))
        for index in range(len(points) - 1):
            painter.drawLine(points[index][0], points[index][1], points[index + 1][0], points[index + 1][1])

        painter.setBrush(QColor(self.color))
        painter.setPen(Qt.PenStyle.NoPen)
        for x, y, mark in points:
            painter.drawEllipse(x - 4, y - 4, 8, 8)

        painter.setPen(QColor("#6b7280"))
        painter.setFont(QFont("Segoe UI", 8))
        painter.drawText(rect.left() - 4, rect.top() + 8, "20")
        painter.drawText(rect.left() - 4, rect.bottom(), "0")




class ResultsWindow(QMainWindow):
    """Modern minimalist results window with auto-generated report."""
    restart_requested = pyqtSignal()  # New signal to request restart
    exit_requested = pyqtSignal() 
    progress_requested = pyqtSignal()
    def __init__(self, quiz_engine, user_info, exam_config, score_result):
        super().__init__()
        self.quiz_engine = quiz_engine
        self.user_info = user_info
        self.exam_config = exam_config
        self.score_result = score_result
        self.pdf_path = None
        
        # Auto-generate PDF reports only for official exams.
        if self.user_info.get('mode') == 'exam':
            self.generate_pdf_report_silent()
        
        self.init_ui()
        
        # Start animations after window is shown
        QTimer.singleShot(100, self.start_animations)
    
    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle("🎓 Training Results" if self.user_info.get('mode') == 'training' else "🎓 Exam Results")
        self.setMinimumSize(380, 560)
        
        # Central widget with scroll
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background-color: #f9fafb; }")
        
        central_widget = QWidget()
        scroll.setWidget(central_widget)
        self.setCentralWidget(scroll)
        
        main_layout = QVBoxLayout(central_widget)
        self.main_layout = main_layout
        main_layout.setContentsMargins(24, 24, 24, 24)
        main_layout.setSpacing(24)
        
        # Header section
        self._create_header(main_layout)
        
        # Main score section
        self._create_score_section(main_layout)
        
        # Statistics grid
        self._create_stats_grid(main_layout)

        # Action buttons
        self._create_action_buttons(main_layout)

        self._create_points_by_result_section(main_layout)
        
        main_layout.addStretch()
    
    def toggle_details(self):
        is_visible = self.details_container.isVisible()
        self.details_container.setVisible(not is_visible)
        if is_visible:
            self.toggle_details_btn.setText("Show Details ⬇️")
        else:
            self.toggle_details_btn.setText("Hide Details ⬆️")

    
    def _create_header(self, parent_layout):
        """Create the header with pass/fail status."""
        header_container = QFrame()
        header_container.setObjectName("headerContainer")
        header_layout = QVBoxLayout(header_container)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(15)
        
        # Title
        title_text = "🎯 Training Results" if self.user_info.get('mode') == 'training' else "🎓 Exam Results"
        title = QLabel(title_text)
        title.setStyleSheet("""
            font-size: 36px;
            font-weight: 700;
            color: #111827;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(title)
        
        # Student name
        student_name = f"{self.user_info.get('first_name', '')} {self.user_info.get('last_name', '')}".strip()
        if student_name:
            name_label = QLabel(f"👤 {student_name}")
            name_label.setStyleSheet("""
                font-size: 16px;
                font-weight: 500;
                color: #6b7280;
            """)
            name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            header_layout.addWidget(name_label)
        
        # Status banner
        percentage = self.score_result['percentage']
        if percentage >= 70:
            status_text = "Outstanding Performance!"
            status_emoji = "🌟"
            status_color = "#10b981"
        elif percentage >= 50:
            status_text = "Good Effort!"
            status_emoji = "👍"
            status_color = "#f59e0b"
        elif percentage > 0:
            status_text = "Keep Practicing!"
            status_emoji = "💪"
            status_color = "#ef4444"
        else:
            status_text = "No Answers Submitted"
            status_emoji = "📝"
            status_color = "#9ca3af"
        
        status_label = QLabel(f"{status_emoji} {status_text}")
        status_label.setStyleSheet(f"""
            font-size: 20px;
            font-weight: 600;
            color: {status_color};
            padding: 12px 24px;
        """)
        status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(status_label)
        
        parent_layout.addWidget(header_container)
    
    def _create_score_section(self, parent_layout):
        """Create the main score visualization."""
        score_container = QFrame()
        score_container.setObjectName("scoreContainer")
        score_container.setStyleSheet("""
            QFrame#scoreContainer {
                background-color: white;
                border-radius: 20px;
                border: 2px solid #e5e7eb;
            }
        """)
        
        score_layout = QVBoxLayout(score_container)
        score_layout.setContentsMargins(40, 40, 40, 40)
        score_layout.setSpacing(20)
        
        # Circular progress in center
        circle_container = QWidget()
        circle_layout = QHBoxLayout(circle_container)
        circle_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Calculate percentage - handle both percentage and mark-based scoring
        percentage = self.score_result.get('percentage', 0)
        
        # If percentage is 0 but we have a final_mark, calculate from mark
        if percentage == 0 and self.score_result.get('final_mark', 0) > 0:
            final_mark = self.score_result.get('final_mark', 0)
            percentage = (final_mark / 20.0) * 100
        
        # If still 0 but we have points, calculate from points
        if percentage == 0 and self.score_result.get('total_points', 0) > 0:
            total_points = self.score_result.get('total_points', 0)
            max_points = self.score_result.get('max_points', 1)
            percentage = (total_points / max_points) * 100 if max_points > 0 else 0
        
        circle_size = 150 if self.width() < 640 else 180
        self.circular_progress = CircularProgress(percentage, circle_size)
        circle_layout.addWidget(self.circular_progress)
        
        score_layout.addWidget(circle_container)
        
        # Status emoji based on score
        if percentage >= 70:
            emoji = "🎉"
        elif percentage >= 50:
            emoji = "😊"
        elif percentage > 0:
            emoji = "📚"
        else:
            emoji = "⚠️"
        
        emoji_label = QLabel(emoji)
        emoji_label.setStyleSheet("font-size: 48px;")
        emoji_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_layout.addWidget(emoji_label)
        
        # Final mark
        mark_label = QLabel(f"Final Mark: {self.score_result['final_mark']:.1f}/20")
        mark_label.setStyleSheet("""
            font-size: 22px;
            font-weight: 600;
            color: #374151;
        """)
        mark_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_layout.addWidget(mark_label)
        
        # Points breakdown
        points_label = QLabel(
            f"📊 {self.score_result['total_points']:.1f} / {self.score_result['max_points']:.1f} points"
        )
        points_label.setStyleSheet("""
            font-size: 14px;
            color: #6b7280;
            font-weight: 500;
        """)
        points_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_layout.addWidget(points_label)
        
        parent_layout.addWidget(score_container)
    
    def _create_stats_grid(self, parent_layout):
        """Create grid of statistics cards."""
        grid_container = QWidget()
        grid_layout = QGridLayout(grid_container)
        self.stats_grid_layout = grid_layout
        grid_layout.setSpacing(20)
        
        total_q = self.score_result['total_questions']
        correct = self.score_result['correct_count']
        wrong = self.score_result['wrong_count']
        unanswered = self.score_result['unanswered_count']
        partial = self.score_result.get('partial_count', 0)
        submitted = self.score_result.get('submitted_count')
        
        # Create stat cards with emojis
        cards = [
            (correct, "Correct", "✅", "#10b981"),
            (partial, "Partial", "⚠️", "#f59e0b"),
            (wrong, "Incorrect", "❌", "#ef4444"),
            (unanswered, "Skipped", "⏭️", "#9ca3af"),
            (submitted if submitted is not None else total_q, "Submitted" if submitted is not None else "Total", "📝", "#3b82f6"),
        ]
        
        self.stat_cards = [StatCard(value, label, emoji, color) for value, label, emoji, color in cards]
        self._relayout_grid(self.stats_grid_layout, self.stat_cards)
        
        parent_layout.addWidget(grid_container)

    def _create_points_by_result_section(self, parent_layout):
        """Show earned points by status and by question."""
        summary = self._get_points_by_result()
        question_rows = self._get_question_points_by_result()

        container = QFrame()
        container.setObjectName("pointsByResultContainer")
        container.setStyleSheet("""
            QFrame#pointsByResultContainer {
                background-color: white;
                border: none;
            }
        """)

        layout = QVBoxLayout(container)
        layout.setContentsMargins(4, 18, 4, 18)
        layout.setSpacing(16)

        header = QWidget()
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 0)

        title = QLabel("Points by Result")
        title.setStyleSheet("""
            font-size: 20px;
            font-weight: 700;
            color: #111827;
        """)
        header_layout.addWidget(title)
        header_layout.addStretch()

        total_label = QLabel(
            f"Total: {self.score_result.get('total_points', 0):+.2f} pts"
        )
        total_label.setStyleSheet("""
            font-size: 13px;
            font-weight: 800;
            color: #1d4ed8;
            background-color: transparent;
            border: none;
            padding: 0;
        """)
        header_layout.addWidget(total_label)
        layout.addWidget(header)

        overview = QWidget()
        overview_layout = QGridLayout(overview)
        self.points_overview_layout = overview_layout
        overview_layout.setContentsMargins(0, 0, 0, 6)
        overview_layout.setHorizontalSpacing(20)
        overview_layout.setVerticalSpacing(8)

        cards = [
            ("Correct", summary["correct"], "#10b981"),
            ("Partial", summary["partial"], "#f59e0b"),
            ("Incorrect", summary["incorrect"], "#ef4444"),
            ("Missed", summary["unanswered"], "#9ca3af"),
        ]

        self.points_overview_widgets = [
            self._create_points_status_line(label, data, color)
            for label, data, color in cards
        ]
        self._relayout_grid(self.points_overview_layout, self.points_overview_widgets)

        layout.addWidget(overview)

        groups = [
            ("Correct", "correct", "#10b981"),
            ("Partial", "partial", "#f59e0b"),
            ("Incorrect", "incorrect", "#ef4444"),
            ("Missed", "unanswered", "#9ca3af"),
        ]
        for label, status, color in groups:
            layout.addWidget(
                self._create_question_points_group(label, question_rows.get(status, []), color)
            )

        parent_layout.addWidget(container)

    def _get_points_by_result(self):
        """Aggregate net earned points and possible points by result status."""
        question_points = {
            question["id"]: question.get("points", 0)
            for question in self.quiz_engine.selected_questions
        }
        summary = {
            "correct": {"count": 0, "earned": 0.0, "possible": 0.0},
            "partial": {"count": 0, "earned": 0.0, "possible": 0.0},
            "incorrect": {"count": 0, "earned": 0.0, "possible": 0.0},
            "unanswered": {"count": 0, "earned": 0.0, "possible": 0.0},
            "total": {
                "count": self.score_result.get("total_questions", 0),
                "earned": self.score_result.get("total_points", 0.0),
                "possible": self.score_result.get("max_points", 0.0),
            },
        }

        for detail in getattr(self.quiz_engine, "score_details", []):
            status = detail.get("status", "unanswered")
            if status not in summary:
                status = "incorrect"

            points = detail.get("points", 0.0)
            penalty = detail.get("penalty", 0.0)
            net_points = points - penalty
            possible_points = question_points.get(detail.get("id"), 0.0)

            summary[status]["count"] += 1
            summary[status]["earned"] += net_points
            summary[status]["possible"] += possible_points

        return summary

    def _get_question_points_by_result(self):
        """Return per-question net points grouped by result status."""
        detail_by_id = {
            detail.get("id"): detail
            for detail in getattr(self.quiz_engine, "score_details", [])
        }
        rows = {
            "correct": [],
            "partial": [],
            "incorrect": [],
            "unanswered": [],
        }

        for index, question in enumerate(self.quiz_engine.selected_questions, start=1):
            detail = detail_by_id.get(question.get("id"), {})
            status = detail.get("status", "unanswered")
            if status not in rows:
                status = "incorrect"

            net_points = detail.get("points", 0.0) - detail.get("penalty", 0.0)
            rows[status].append({
                "number": index,
                "points": net_points,
                "topic": question.get("topic", "Unknown"),
                "difficulty": question.get("difficulty", "unknown"),
                "passed_tests": detail.get("passed_tests"),
                "total_tests": detail.get("total_tests"),
                "hints_used": detail.get("hints_used", 0),
            })

        return rows

    def _create_points_status_line(self, label, data, color):
        """Create a compact status summary without a boxed card."""
        row = QWidget()
        row.setStyleSheet("background-color: transparent; border: none;")

        layout = QVBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(3)

        title = QLabel(label)
        title.setStyleSheet(f"font-size: 13px; font-weight: 900; color: {color};")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(title)

        count = QLabel(f"{data.get('count', 0)} question(s)")
        count.setStyleSheet("font-size: 12px; color: #6b7280; font-weight: 600;")
        count.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(count)

        earned = data.get("earned", 0.0)
        points = QLabel(f"{earned:+.2f} pts")
        points.setStyleSheet("""
            font-size: 17px;
            color: #111827;
            font-weight: 900;
        """)
        points.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(points)

        return row

    def _create_question_points_group(self, label, rows, color):
        """Create a per-question points group for one result status."""
        group = QFrame()
        group.setStyleSheet("""
            QFrame {
                background-color: transparent;
                border: none;
            }
        """)
        layout = QVBoxLayout(group)
        layout.setContentsMargins(0, 6, 0, 6)
        layout.setSpacing(8)

        header = QLabel(f"{label} Questions")
        header.setStyleSheet(f"""
            font-size: 15px;
            font-weight: 800;
            color: {color};
            padding: 0 2px 4px 2px;
        """)
        layout.addWidget(header)

        if not rows:
            empty = QLabel("No questions in this group")
            empty.setStyleSheet("font-size: 12px; color: #94a3b8; font-weight: 600;")
            layout.addWidget(empty)
            return group

        chips = QWidget()
        chips_layout = QGridLayout(chips)
        chips_layout.setContentsMargins(0, 0, 0, 0)
        chips_layout.setHorizontalSpacing(12)
        chips_layout.setVerticalSpacing(8)

        columns = self._responsive_columns(max_columns=4)
        for index, row in enumerate(rows):
            chips_layout.addWidget(self._create_question_points_chip(row, color), index // columns, index % columns)

        layout.addWidget(chips)
        return group

    def _create_question_points_chip(self, row, color):
        """Create a clean per-question points row without boxed text."""
        chip = QFrame()
        chip.setStyleSheet(f"""
            QFrame {{
                background-color: transparent;
                border: none;
                border-bottom: 1px solid #e5e7eb;
            }}
        """)
        layout = QHBoxLayout(chip)
        layout.setContentsMargins(4, 8, 4, 8)
        layout.setSpacing(10)

        q_label = QLabel(f"Q{row['number']}")
        q_label.setMinimumWidth(38)
        q_label.setStyleSheet(f"font-size: 13px; font-weight: 900; color: {color};")
        q_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(q_label)

        points_label = QLabel(f"{row['points']:+.2f} pts")
        points_label.setMinimumWidth(78)
        points_label.setStyleSheet("""
            font-size: 15px;
            font-weight: 900;
            color: #111827;
        """)
        points_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(points_label)

        meta_layout = QVBoxLayout()
        meta_layout.setContentsMargins(0, 0, 0, 0)
        meta_layout.setSpacing(4)
        
        meta_text = f"{row['topic']}  •  {row['difficulty'].title()}"
        if row.get('hints_used', 0) > 0:
            meta_text += f"  •  Hints: {row['hints_used']}"
            
        meta = QLabel(meta_text)
        meta.setStyleSheet("font-size: 12px; color: #64748b; font-weight: 600;")
        meta.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        meta.setWordWrap(True)
        meta_layout.addWidget(meta)
        
        if row.get('total_tests'):
            tests_lbl = QLabel(f"Passed: {row.get('passed_tests', 0)}/{row['total_tests']} tests")
            tests_lbl.setStyleSheet(f"font-size: 11px; font-weight: 800; color: {color};")
            meta_layout.addWidget(tests_lbl)
            
            pb = QProgressBar()
            pb.setFixedHeight(6)
            pb.setTextVisible(False)
            pb.setMaximum(row['total_tests'])
            pb.setValue(row.get('passed_tests', 0))
            pb.setStyleSheet(f"""
                QProgressBar {{
                    background-color: #e2e8f0;
                    border: none;
                    border-radius: 3px;
                }}
                QProgressBar::chunk {{
                    background-color: {color};
                    border-radius: 3px;
                }}
            """)
            meta_layout.addWidget(pb)
            
        layout.addLayout(meta_layout, 1)

        return chip
    
    def _create_performance_section(self, parent_layout):
        """Create performance breakdown section."""
        perf_container = QFrame()
        perf_container.setObjectName("perfContainer")
        perf_container.setStyleSheet("""
            QFrame#perfContainer {
                background-color: white;
                border-radius: 20px;
                border: 2px solid #e5e7eb;
            }
        """)
        
        perf_layout = QVBoxLayout(perf_container)
        perf_layout.setContentsMargins(30, 30, 30, 30)
        perf_layout.setSpacing(25)
        
        # Section title
        title = QLabel("📈 Performance Breakdown")
        title.setStyleSheet("""
            font-size: 20px;
            font-weight: 600;
            color: #111827;
        """)
        perf_layout.addWidget(title)
        
        # Difficulty analysis
        self._create_difficulty_section(perf_layout)
        
        # Topic analysis
        self._create_topic_section(perf_layout)
        
        parent_layout.addWidget(perf_container)

    def _responsive_columns(self, max_columns=5):
        """Return a column count that fits the current window width."""
        width = self.width()
        if width < 560:
            return 1
        if width < 780:
            return min(2, max_columns)
        if width < 1020:
            return min(3, max_columns)
        return max_columns

    def _relayout_grid(self, grid_layout, widgets):
        """Place widgets into a responsive grid."""
        if not grid_layout:
            return

        while grid_layout.count():
            item = grid_layout.takeAt(0)
            widget = item.widget()
            if widget:
                grid_layout.removeWidget(widget)

        columns = self._responsive_columns(max_columns=min(5, len(widgets)))
        for index, widget in enumerate(widgets):
            grid_layout.addWidget(widget, index // columns, index % columns)

    def resizeEvent(self, event):
        """Adapt margins and grid columns as the results window resizes."""
        width = event.size().width()
        compact = width < 640
        margin = 12 if compact else 20 if width < 900 else 32
        spacing = 16 if compact else 24

        if hasattr(self, "main_layout"):
            self.main_layout.setContentsMargins(margin, margin, margin, margin)
            self.main_layout.setSpacing(spacing)

        if hasattr(self, "stats_grid_layout") and hasattr(self, "stat_cards"):
            self._relayout_grid(self.stats_grid_layout, self.stat_cards)

        if hasattr(self, "points_overview_layout") and hasattr(self, "points_overview_widgets"):
            self._relayout_grid(self.points_overview_layout, self.points_overview_widgets)

        super().resizeEvent(event)
    
    def _create_difficulty_section(self, parent_layout):
        """Create difficulty breakdown."""
        diff_analysis = self.score_result.get('difficulty_analysis', {})
        
        if not diff_analysis:
            return
        
        section = QWidget()
        section_layout = QVBoxLayout(section)
        section_layout.setContentsMargins(0, 0, 0, 0)
        section_layout.setSpacing(12)
        
        # Title
        label = QLabel("🎯 By Difficulty")
        label.setStyleSheet("font-size: 15px; font-weight: 600; color: #374151;")
        section_layout.addWidget(label)
        
        # Calculate percentages for bar
        easy_data = diff_analysis.get('easy', {})
        medium_data = diff_analysis.get('medium', {})
        hard_data = diff_analysis.get('hard', {})
        very_hard_data = diff_analysis.get('very hard', {})
        
        total = self.score_result['total_questions']
        easy_pct = (easy_data.get('total', 0) / total * 100) if total > 0 else 0
        medium_pct = (medium_data.get('total', 0) / total * 100) if total > 0 else 0
        hard_pct = (hard_data.get('total', 0) / total * 100) if total > 0 else 0
        very_hard_pct = (very_hard_data.get('total', 0) / total * 100) if total > 0 else 0
        
        # Difficulty bar
        bar = DifficultyBar(easy_pct, medium_pct, hard_pct, very_hard_pct)
        section_layout.addWidget(bar)
        
        # Legend
        legend_layout = QHBoxLayout()
        legend_layout.setSpacing(25)
        
        difficulties = [
            ('😊 Easy', easy_data, '#10b981'),
            ('🤔 Medium', medium_data, '#f59e0b'),
            ('😰 Hard', hard_data, '#ef4444'),
            ('🔥 Very hard', very_hard_data, '#7c3aed')
        ]
        
        for name, data, color in difficulties:
            legend_item = QLabel(
                f"{name}: {data.get('correct', 0)}/{data.get('total', 0)}"
            )
            legend_item.setStyleSheet(f"font-size: 13px; color: {color}; font-weight: 500;")
            legend_layout.addWidget(legend_item)
        
        legend_layout.addStretch()
        section_layout.addLayout(legend_layout)
        
        parent_layout.addWidget(section)
    
    def _create_topic_section(self, parent_layout):
        """Create topic performance list with historical comparisons."""
        topic_analysis = self.score_result.get('topic_analysis', {})
        history = load_training_history()
        
        if not topic_analysis:
            return
        
        # Historical averages
        historical_avgs = get_topic_historical_averages(history)

        section = QWidget()
        section_layout = QVBoxLayout(section)
        section_layout.setContentsMargins(0, 0, 0, 0)
        section_layout.setSpacing(12)
        
        # Title
        label = QLabel("📚 Performance by Topic")
        label.setStyleSheet("font-size: 18px; font-weight: 700; color: #111827;")
        section_layout.addWidget(label)
        
        # Topic rows
        for topic_name, data in sorted(topic_analysis.items(), 
                                       key=lambda x: x[1].get('percentage', 0), 
                                       reverse=True):
            avg_score = historical_avgs.get(topic_name, 0)
            topic_row = self._create_topic_row(topic_name, data, avg_score)
            section_layout.addWidget(topic_row)
        
        parent_layout.addWidget(section)

        # 4. Weak Topics Detection (Needs Revision)
        self._create_needs_revision_section(parent_layout, topic_analysis)

    def _create_needs_revision_section(self, parent_layout, topic_analysis):
        """Highlight topics where performance < 50%."""
        weak_topics = [
            (name, data) for name, data in topic_analysis.items()
            if data.get('percentage', 0) < 50
        ]
        
        if not weak_topics:
            return

        # Sort ascending by performance
        weak_topics.sort(key=lambda x: x[1].get('percentage', 0))

        container = QFrame()
        container.setStyleSheet("""
            QFrame {
                background-color: #fef2f2;
                border: 1px solid #fee2e2;
                border-radius: 16px;
                padding: 20px;
            }
        """)
        layout = QVBoxLayout(container)
        
        header_layout = QHBoxLayout()
        icon = QLabel("⚠️")
        icon.setStyleSheet("font-size: 24px;")
        header_layout.addWidget(icon)
        
        title = QLabel("Needs Revision")
        title.setStyleSheet("font-size: 18px; font-weight: 700; color: #991b1b;")
        header_layout.addWidget(title)
        header_layout.addStretch()
        layout.addLayout(header_layout)
        
        desc = QLabel("Focus on these topics to improve your global score:")
        desc.setStyleSheet("font-size: 13px; color: #b91c1c; font-weight: 500;")
        layout.addWidget(desc)
        
        for name, data in weak_topics:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 4, 0, 4)
            
            t_name = QLabel(f"• {name}")
            t_name.setStyleSheet("font-size: 14px; color: #7f1d1d; font-weight: 600;")
            row_layout.addWidget(t_name)
            
            row_layout.addStretch()
            
            score = QLabel(f"{data.get('percentage', 0):.0f}%")
            score.setStyleSheet("""
                font-weight: 800;
                color: #dc2626;
                background-color: white;
                padding: 2px 8px;
                border-radius: 8px;
                border: 1px solid #fecaca;
            """)
            row_layout.addWidget(score)
            layout.addWidget(row)
            
        parent_layout.addWidget(container)

    def _create_topic_row(self, topic_name, data, avg_score):
        """Create a single topic performance row with trend and average."""
        row = QFrame()
        row.setStyleSheet("""
            QFrame {
                background-color: #ffffff;
                border: 1px solid #f1f5f9;
                border-radius: 12px;
                padding: 4px;
            }
            QFrame:hover {
                background-color: #f8fafc;
                border-color: #e2e8f0;
            }
        """)
        
        layout = QHBoxLayout(row)
        layout.setContentsMargins(15, 12, 15, 12)
        
        # Topic name & current vs avg
        name_container = QWidget()
        name_layout = QVBoxLayout(name_container)
        name_layout.setContentsMargins(0, 0, 0, 0)
        name_layout.setSpacing(2)
        
        name_label = QLabel(topic_name)
        name_label.setStyleSheet("font-size: 14px; font-weight: 700; color: #1e293b;")
        name_layout.addWidget(name_label)
        
        avg_label = QLabel(f"Historical Average: {avg_score:.1f}/20")
        avg_label.setStyleSheet("font-size: 11px; color: #64748b; font-weight: 500;")
        name_layout.addWidget(avg_label)
        layout.addWidget(name_container)
        
        layout.addStretch()
        
        # Score and Trend
        correct = data.get('correct', 0)
        total = data.get('total', 0)
        percentage = data.get('percentage', 0)
        current_mark = round((percentage / 100) * 20, 2)
        
        # Trend indicator
        if current_mark > avg_score + 0.5:
            trend = "↑"
            trend_color = "#10b981"
        elif current_mark < avg_score - 0.5:
            trend = "↓"
            trend_color = "#ef4444"
        else:
            trend = "→"
            trend_color = "#94a3b8"
            
        trend_label = QLabel(trend)
        trend_label.setStyleSheet(f"font-size: 18px; font-weight: 900; color: {trend_color};")
        layout.addWidget(trend_label)
        
        score_label = QLabel(f"{correct}/{total}")
        score_label.setStyleSheet("font-size: 13px; color: #475569; font-weight: 700; margin-left: 5px;")
        layout.addWidget(score_label)
        
        # Percentage badge
        color = "#10b981" if percentage >= 70 else "#f59e0b" if percentage >= 50 else "#ef4444"
        
        pct_label = QLabel(f"{percentage:.0f}%")
        pct_label.setStyleSheet(f"""
            font-size: 13px;
            font-weight: 800;
            color: white;
            padding: 4px 10px;
            background-color: {color};
            border-radius: 8px;
            min-width: 40px;
        """)
        pct_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(pct_label)
        
        return row    
    def _create_action_buttons(self, parent_layout):
        """Create action buttons."""
        button_container = QWidget()
        button_layout = QHBoxLayout(button_container)
        button_layout.setSpacing(15)
        
        # Open Report Button (replaces Download)
        if self.pdf_path:
            open_btn = QPushButton("📄 Open Report")
            open_btn.setMinimumHeight(48)
            open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            open_btn.setStyleSheet("""
                QPushButton {
                    background-color: #3b82f6;
                    color: white;
                    font-size: 15px;
                    font-weight: 600;
                    padding: 0 30px;
                    border-radius: 12px;
                    border: none;
                }
                QPushButton:hover {
                    background-color: #2563eb;
                }
            """)
            open_btn.clicked.connect(self.open_pdf_report)
            button_layout.addWidget(open_btn)

        if self.user_info.get('mode') == 'training':
            progress_btn = QPushButton("📈 Progress")
            progress_btn.setMinimumHeight(48)
            progress_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            progress_btn.setStyleSheet("""
                QPushButton {
                    background-color: #2563eb;
                    color: white;
                    font-size: 15px;
                    font-weight: 700;
                    padding: 0 30px;
                    border-radius: 12px;
                    border: none;
                }
                QPushButton:hover {
                    background-color: #1d4ed8;
                }
            """)
            progress_btn.clicked.connect(self.progress_requested.emit)
            button_layout.addWidget(progress_btn)
        
        # Restart Button
        restart_btn = QPushButton("🔄 Try Again")
        restart_btn.setMinimumHeight(48)
        restart_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        restart_btn.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #374151;
                font-size: 15px;
                font-weight: 600;
                padding: 0 30px;
                border-radius: 12px;
                border: 2px solid #e5e7eb;
            }
            QPushButton:hover {
                border-color: #3b82f6;
                color: #3b82f6;
            }
        """)
        restart_btn.clicked.connect(self.restart_exam)
        button_layout.addWidget(restart_btn)
        
        # Exit Button
        exit_btn = QPushButton("✕ Close")
        exit_btn.setMinimumHeight(48)
        exit_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        exit_btn.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #6b7280;
                font-size: 15px;
                font-weight: 600;
                padding: 0 30px;
                border-radius: 12px;
                border: 2px solid #e5e7eb;
            }
            QPushButton:hover {
                border-color: #ef4444;
                color: #ef4444;
            }
        """)
        exit_btn.clicked.connect(self.exit_application)
        button_layout.addWidget(exit_btn)
        
        parent_layout.addWidget(button_container)

    def _create_training_history_section(self, parent_layout):
        """Create training evolution and level progression section."""
        history = load_training_history()
        if not history:
            return

        container = QFrame()
        container.setObjectName("trainingHistoryContainer")
        container.setStyleSheet("""
            QFrame#trainingHistoryContainer {
                background-color: white;
                border-radius: 24px;
                border: 2px solid #e5e7eb;
            }
        """)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(24)

        header = QLabel("📈 Training Evolution & Level Progression")
        header.setStyleSheet("font-size: 22px; font-weight: 700; color: #111827;")
        layout.addWidget(header)

        # 1. Overall Score Evolution Chart (The only chart)
        overall_marks = [attempt.get("final_mark", 0) for attempt in history]
        layout.addWidget(MarkEvolutionChart(overall_marks, "Overall Score Evolution (out of 20)"))

        # 2. Level Progression UI
        prog_stats = get_progression_stats(history, history[-1])
        if prog_stats:
            level_widget = self._create_level_progression_widget(prog_stats)
            layout.addWidget(level_widget)

        parent_layout.addWidget(container)

    def _create_level_progression_widget(self, stats):
        """Stylish level progression widget."""
        widget = QFrame()
        widget.setStyleSheet("""
            QFrame {
                background-color: #f8fafc;
                border-radius: 16px;
                border: 1px solid #e2e8f0;
                padding: 20px;
            }
        """)
        layout = QVBoxLayout(widget)
        
        # Horizontal layout for levels
        levels_layout = QHBoxLayout()
        
        # Initial Level Badge
        init_box = self._create_level_badge("Initial Level", stats['initial_level'], "#64748b")
        levels_layout.addWidget(init_box)
        
        # Arrow
        arrow = QLabel("➜")
        arrow.setStyleSheet("font-size: 24px; color: #cbd5e1;")
        levels_layout.addWidget(arrow)
        
        # Current Level Badge
        curr_color = "#10b981" if stats['new_avg'] >= 14 else "#3b82f6" if stats['new_avg'] >= 10 else "#f59e0b"
        curr_box = self._create_level_badge("Current Level", stats['curr_level'], curr_color, is_current=True)
        levels_layout.addWidget(curr_box)
        
        layout.addLayout(levels_layout)
        
        # Progression info
        info_layout = QHBoxLayout()
        
        # Level Change
        change_text = f"Level UP! (+{stats['curr_level'] - stats['prev_level']})" if stats['level_up'] else "Level Maintained"
        change_color = "#10b981" if stats['level_up'] else "#64748b"
        change_label = QLabel(change_text)
        change_label.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {change_color};")
        info_layout.addWidget(change_label)
        
        info_layout.addStretch()
        
        # Point Gain (Delta)
        delta = stats['delta']
        delta_text = f"{'+' if delta >= 0 else ''}{delta:.2f} pts"
        delta_color = "#10b981" if delta > 0 else "#ef4444" if delta < 0 else "#64748b"
        delta_label = QLabel(f"Global Average change: {delta_text}")
        delta_label.setStyleSheet(f"font-size: 14px; font-weight: 600; color: #475569;")
        
        delta_badge = QLabel(delta_text)
        delta_badge.setStyleSheet(f"""
            padding: 4px 12px;
            background-color: {delta_color}20;
            color: {delta_color};
            border-radius: 12px;
            font-weight: 800;
        """)
        info_layout.addWidget(delta_label)
        info_layout.addWidget(delta_badge)
        
        layout.addLayout(info_layout)
        
        # Average Score Progress Bar (Simplified)
        progress_container = QWidget()
        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setContentsMargins(0, 10, 0, 0)
        
        avg_label = QLabel(f"Global Average Score: {stats['new_avg']:.2f} / 20")
        avg_label.setStyleSheet("font-size: 13px; color: #64748b; font-weight: 600;")
        progress_layout.addWidget(avg_label)
        
        # Custom mini progress bar
        bar_bg = QFrame()
        bar_bg.setFixedHeight(12)
        bar_bg.setStyleSheet("background-color: #e2e8f0; border-radius: 6px;")
        
        bar_fill = QFrame(bar_bg)
        bar_fill.setFixedHeight(12)
        fill_width = int((stats['new_avg'] / 20) * 100)
        bar_fill.setStyleSheet(f"background-color: {curr_color}; border-radius: 6px;")
        bar_fill.setFixedWidth(max(10, int(fill_width * 3))) # Approximate
        
        progress_layout.addWidget(bar_bg)
        layout.addWidget(progress_container)
        
        return widget

    def _create_level_badge(self, label, level, color, is_current=False):
        badge = QFrame()
        size = 100 if is_current else 80
        font_size = 32 if is_current else 24
        badge.setFixedSize(size, size + 30)
        
        layout = QVBoxLayout(badge)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        
        circle = QFrame()
        circle.setFixedSize(size, size)
        circle.setStyleSheet(f"""
            background-color: {color};
            border-radius: {size//2}px;
            color: white;
        """)
        circle_layout = QVBoxLayout(circle)
        level_num = QLabel(f"L{level}")
        level_num.setStyleSheet(f"font-size: {font_size}px; font-weight: 900; color: white;")
        level_num.setAlignment(Qt.AlignmentFlag.AlignCenter)
        circle_layout.addWidget(level_num)
        
        layout.addWidget(circle)
        
        txt = QLabel(label)
        txt.setStyleSheet(f"font-size: 11px; font-weight: 800; color: {color if is_current else '#94a3b8'};")
        txt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(txt)
        
        return badge


    def start_animations(self):
        """Start all animations."""
        if hasattr(self, 'circular_progress'):
            self.circular_progress.start_animation()
    
    def generate_pdf_report_silent(self):
        """Generate PDF report silently without showing dialog."""
        try:
            from core.pdf_generator import PDFReportGenerator
            
            pdf_generator = PDFReportGenerator()
            pdf_path = pdf_generator.generate_report(
                exam_data=self.exam_config,
                user_info=self.user_info,
                score_result=self.score_result,
                quiz_engine=self.quiz_engine
            )
            
            self.pdf_path = pdf_path
            
        except Exception as e:
            print(f"Failed to auto-generate PDF: {e}")
            self.pdf_path = None
    
    def open_pdf_report(self):
        """Open the generated PDF report."""
        if not self.pdf_path or not os.path.exists(self.pdf_path):
            QMessageBox.warning(
                self,
                "Report Not Found",
                "The PDF report could not be found. It may have been moved or deleted.",
                QMessageBox.StandardButton.Ok
            )
            return
        
        try:
            # Open with default PDF viewer
            abs_path = os.path.abspath(self.pdf_path)
            if sys.platform == 'win32':
                os.startfile(abs_path)
            elif sys.platform == 'darwin':  # macOS
                os.system(f'open "{abs_path}"')
            else:  # Linux
                os.system(f'xdg-open "{abs_path}"')
            
        except Exception as e:
            # Fallback to QDesktopServices
            try:
                QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.abspath(self.pdf_path)))
            except:
                QMessageBox.critical(
                    self,
                    "Error",
                    f"Failed to open PDF report:\n{str(e)}",
                    QMessageBox.StandardButton.Ok
                )
    
    def restart_exam(self):
        """Restart the exam."""
        
        self.restart_requested.emit()
        self.close()
        # Main application should handle restart logic
    def exit_application(self):
        """Exit the application - emit signal instead of closing directly"""
        self.exit_requested.emit()
        self.close()
