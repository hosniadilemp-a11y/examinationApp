# utils/config.py
import sys
from pathlib import Path
import json

class Config:
    def __init__(self):
        self.system = sys.platform
        self.setup_paths()
    
    def setup_paths(self):
        if self.system == "win32":
            self.app_data = Path.home() / "AppData" / "Local" / "QuizApp"
        elif self.system == "darwin":  # macOS
            self.app_data = Path.home() / "Library" / "Application Support" / "QuizApp"
        else:  # Linux/Unix
            self.app_data = Path.home() / ".quizapp"
        
        self.app_data.mkdir(parents=True, exist_ok=True)