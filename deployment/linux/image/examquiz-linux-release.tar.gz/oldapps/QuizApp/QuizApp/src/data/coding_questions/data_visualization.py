"""Questions for topic: Data Visualization"""

QUESTIONS = [
    {
        'id': 4099,
        'is_exam': False,
        'type': 'coding',
        'topic': 'Data Visualization',
        'difficulty': 'easy',
        'title': 'Tracé de courbe simple',
        'description': "Lisez le fichier 'sales.csv' à l'aide de pandas. Tracez la courbe des ventes ('Sales') en fonction du mois ('Month'). Sauvegardez le graphique sous le nom 'plot_sales.png', puis affichez la chaîne 'Graphique sauvegardé'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Tracez la courbe Sales vs Month et sauvegardez dans 'plot_sales.png'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Graphique sauvegardé'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Graphique sauvegardé'
            }
        ],
        'points': 1,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `plt.plot(df['Month'], df['Sales'])`.",
        'hint2': "N'oubliez pas d'appeler `plt.savefig('plot_sales.png')` et d'afficher 'Graphique sauvegardé'.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('sales.csv')\nplt.figure()\nplt.plot(df['Month'], df['Sales'])\nplt.savefig('plot_sales.png')\nprint('Graphique sauvegardé')"
    },
    {
        'id': 4100,
        'is_exam': False,
        'type': 'coding',
        'topic': 'Data Visualization',
        'difficulty': 'medium',
        'title': 'Graphique en barres des dépenses',
        'description': "Lisez le fichier 'sales.csv'. Tracez un graphique en barres des dépenses ('Expenses') en fonction du mois ('Month'). Ajoutez le titre 'Expenses' à l'aide de matplotlib, puis sauvegardez le graphique sous le nom 'plot_expenses.png' et affichez 'Barres sauvegardées'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Tracez un graphique en barres Expenses vs Month avec le titre 'Expenses' et sauvegardez\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Barres sauvegardées'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Barres sauvegardées'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `plt.bar(df['Month'], df['Expenses'])`.",
        'hint2': "Utilisez `plt.title('Expenses')` et `plt.savefig('plot_expenses.png')`.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('sales.csv')\nplt.figure()\nplt.bar(df['Month'], df['Expenses'])\nplt.title('Expenses')\nplt.savefig('plot_expenses.png')\nprint('Barres sauvegardées')"
    },
    {
        'id': 4106,
        'is_exam': False,
        'type': 'coding',
        'topic': 'Data Visualization',
        'difficulty': 'hard',
        'title': "Histogramme de l'âge",
        'description': "Lisez le fichier 'data.csv'. Tracez un histogramme de la colonne 'Age' des employés avec 3 bacs (bins=3). Sauvegardez le graphique sous le nom 'plot_age_hist.png' et affichez 'Histogramme sauvegardé'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Tracez un histogramme de la colonne 'Age' avec bins=3 et sauvegardez sous 'plot_age_hist.png'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Histogramme sauvegardé'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Histogramme sauvegardé'
            }
        ],
        'points': 3,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `plt.hist(df['Age'], bins=3)`.",
        'hint2': "N'oubliez pas `plt.savefig('plot_age_hist.png')`.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('data.csv')\nplt.figure()\nplt.hist(df['Age'], bins=3)\nplt.savefig('plot_age_hist.png')\nprint('Histogramme sauvegardé')"
    },
    {
        'id': 4108,
        'is_exam': False,
        'type': 'coding',
        'topic': 'Data Visualization',
        'difficulty': 'very hard',
        'title': 'Nuage de points (Scatter)',
        'description': "Lisez le fichier 'data.csv'. Tracez un nuage de points (scatter plot) du salaire ('Salary') en fonction de l'âge ('Age'). Activez la grille d'arrière-plan avec plt.grid(True), sauvegardez le graphique sous le nom 'plot_salary_age.png' et affichez 'Nuage sauvegardé'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Tracez le scatter plot (x=Age, y=Salary), activez la grille et sauvegardez sous 'plot_salary_age.png'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Nuage sauvegardé'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Nuage sauvegardé'
            }
        ],
        'points': 4,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `plt.scatter(df['Age'], df['Salary'])`.",
        'hint2': "Utilisez `plt.grid(True)` pour afficher la grille.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('data.csv')\nplt.figure()\nplt.scatter(df['Age'], df['Salary'])\nplt.grid(True)\nplt.savefig('plot_salary_age.png')\nprint('Nuage sauvegardé')"
    },
    {
        'id': 4112,
        'is_exam': False,
        'topic': 'Data Visualization',
        'type': 'coding',
        'difficulty': 'medium',
        'title': 'Graphique à courbes multiples',
        'description': "Lisez 'sales.csv'. Tracez deux courbes sur le même graphique : les ventes ('Sales') et les dépenses ('Expenses') en fonction du mois ('Month'). Sauvegardez le graphique sous le nom 'plot_multiline.png' et affichez 'Multi-courbe sauvegardée'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Tracez deux courbes et sauvegardez dans 'plot_multiline.png'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Multi-courbe sauvegardée'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Multi-courbe sauvegardée'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Appelez `plt.plot(df['Month'], df['Sales'])` puis `plt.plot(df['Month'], df['Expenses'])`.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('sales.csv')\nplt.figure()\nplt.plot(df['Month'], df['Sales'])\nplt.plot(df['Month'], df['Expenses'])\nplt.savefig('plot_multiline.png')\nprint('Multi-courbe sauvegardée')"
    },
    {
        'id': 4113,
        'is_exam': False,
        'topic': 'Data Visualization',
        'type': 'coding',
        'difficulty': 'hard',
        'title': 'Boîte à moustaches (Boxplot)',
        'description': "Lisez 'data.csv'. Tracez une boîte à moustaches (boxplot) de la colonne 'Salary' par département ('Department'). Sauvegardez le graphique sous le nom 'plot_salary_box.png' et affichez 'Boxplot sauvegardé'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Tracez une boîte à moustaches de Salary par Department et sauvegardez sous 'plot_salary_box.png'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Boxplot sauvegardé'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Boxplot sauvegardé'
            }
        ],
        'points': 3,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez la méthode pandas `df.boxplot(column='Salary', by='Department')`.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('data.csv')\nplt.figure()\ndf.boxplot(column='Salary', by='Department')\nplt.savefig('plot_salary_box.png')\nprint('Boxplot sauvegardé')"
    },
    {
        'id': 4118,
        'is_exam': False,
        'topic': 'Data Visualization',
        'type': 'coding',
        'difficulty': 'medium',
        'title': 'Diagramme circulaire (Pie)',
        'description': "Lisez le fichier 'data.csv'. Comptez le nombre d'employés par département à l'aide de `.value_counts()`. Tracez un diagramme circulaire (pie chart) montrant la répartition des employés par département avec leurs labels correspondants. Sauvegardez le graphique sous le nom 'plot_dept_pie.png' et affichez 'Camembert sauvegardé'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Comptez les employés par département, tracez un diagramme circulaire et sauvegardez dans 'plot_dept_pie.png'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Camembert sauvegardé'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Camembert sauvegardé'
            }
        ],
        'points': 2,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Calculez les fréquences avec `counts = df['Department'].value_counts()`, puis tracez avec `plt.pie(counts, labels=counts.index)`.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('data.csv')\ncounts = df['Department'].value_counts()\nplt.figure()\nplt.pie(counts, labels=counts.index)\nplt.savefig('plot_dept_pie.png')\nprint('Camembert sauvegardé')"
    },
    {
        'id': 4119,
        'is_exam': False,
        'topic': 'Data Visualization',
        'type': 'coding',
        'difficulty': 'hard',
        'title': 'Graphique en aires (Area)',
        'description': "Lisez le fichier 'sales.csv'. Tracez un graphique en aires empilées (stacked area plot) pour afficher les ventes ('Sales') et les dépenses ('Expenses') en fonction du mois ('Month'). Utilisez labels=['Sales', 'Expenses']. Sauvegardez le graphique sous le nom 'plot_sales_area.png' et affichez 'Aire sauvegardée'.",
        'starter_code': "import pandas as pd\nimport matplotlib.pyplot as plt\n# Tracez le graphique en aires pour Sales et Expenses par Month, et sauvegardez sous 'plot_sales_area.png'\n",
        'function_signature': None,
        'public_tests': [
            {
                'input': '',
                'output': 'Aire sauvegardée'
            }
        ],
        'hidden_tests': [
            {
                'input': '',
                'output': 'Aire sauvegardée'
            }
        ],
        'points': 3,
        'execution_settings': {'language': 'python', 'timeout_ms': 4000, 'memory_limit_mb': 128},
        'hint1': "Utilisez `plt.stackplot(df['Month'], df['Sales'], df['Expenses'], labels=['Sales', 'Expenses'])`.",
        'solution': "import pandas as pd\nimport matplotlib.pyplot as plt\ndf = pd.read_csv('sales.csv')\nplt.figure()\nplt.stackplot(df['Month'], df['Sales'], df['Expenses'], labels=['Sales', 'Expenses'])\nplt.savefig('plot_sales_area.png')\nprint('Aire sauvegardée')"
    }
]

