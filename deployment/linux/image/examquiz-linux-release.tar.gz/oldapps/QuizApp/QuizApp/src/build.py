import PyInstaller.__main__
import os

PyInstaller.__main__.run([
    'main.py',
    '--onefile',
    '--windowed',
    '--name=SecureQuizApp',
    '--add-data=data;data',
    '--hidden-import=cryptography',
    '--hidden-import=reportlab',
    '--clean',
    '--distpath=./dist'
])