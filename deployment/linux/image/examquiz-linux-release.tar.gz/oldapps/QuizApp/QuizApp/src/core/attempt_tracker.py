"""
Daily Attempt Tracker
=====================
Stores attempt counts per (user_key, date) in ~/.quizmasterrc (JSON).
Max 3 attempts per user per day.
"""

import json
import os
from datetime import date as _date

_RC_PATH = os.path.expanduser("~/.quizmasterrc")
MAX_DAILY_ATTEMPTS = 3


def _load() -> dict:
    if os.path.exists(_RC_PATH):
        try:
            with open(_RC_PATH, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save(data: dict) -> None:
    try:
        with open(_RC_PATH, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _key(user_key: str) -> str:
    today = _date.today().isoformat()
    return f"{user_key}::{today}"


def get_attempts(user_key: str) -> int:
    """Return how many attempts the user has made today."""
    data = _load()
    return data.get(_key(user_key), 0)


def can_attempt(user_key: str) -> bool:
    """Return True if the user still has attempts remaining today."""
    return get_attempts(user_key) < MAX_DAILY_ATTEMPTS


def record_attempt(user_key: str) -> bool:
    """
    Record one attempt for today.
    Returns True on success, False if the daily limit was already reached.
    """
    data = _load()
    k = _key(user_key)
    current = data.get(k, 0)
    if current >= MAX_DAILY_ATTEMPTS:
        return False
    data[k] = current + 1
    _save(data)
    return True


def attempts_remaining(user_key: str) -> int:
    """Return how many attempts are still available today."""
    return max(0, MAX_DAILY_ATTEMPTS - get_attempts(user_key))
