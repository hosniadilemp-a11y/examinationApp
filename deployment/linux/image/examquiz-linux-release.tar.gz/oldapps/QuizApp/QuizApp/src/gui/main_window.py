"""
Main application window with training/exam mode selection
Enhanced version with improved window management, title, and button handling
"""

from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QLabel, QPushButton, QLineEdit, QComboBox,
                            QGroupBox, QFormLayout, QMessageBox, QSpinBox,
                            QFileDialog, QRadioButton, QButtonGroup, QStackedWidget,
                            QFrame, QGridLayout, QScrollArea, QSizePolicy,
                            QCheckBox, QBoxLayout, QTabWidget, QGraphicsDropShadowEffect,
                            QProgressBar)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QFont, QIcon, QColor, QLinearGradient, QPalette
from importlib import reload
import sys
import random
from data import questions as builtin_questions
from data.coding_questions import CODING_QUESTIONS
from core.exam_code import TOPIC_ORDER, decode_exam_code
from core.attempt_tracker import (get_attempts, can_attempt,
    record_attempt, attempts_remaining, MAX_DAILY_ATTEMPTS)
from core.training_history import filter_history_by_type, load_training_history
from core.progression import (
    DEFAULT_VALIDATION_QUESTIONS,
    DIFFICULTY_LABELS,
    DIFFICULTY_ORDER,
    PASSING_MARK,
    PASSING_PERCENTAGE,
    build_progression_state,
    count_validation_questions,
    get_training_questions,
    get_validation_difficulties,
    is_difficulty_unlocked,
)


class MainWindow(QMainWindow):
    exam_started = pyqtSignal(dict)  # Signal with user info and mode
    exam_loaded = pyqtSignal(dict)   # Signal for loaded exam
    progress_requested = pyqtSignal()
    exit_requested = pyqtSignal()
    
    def __init__(self, saved_training_config=None):
        super().__init__()
        reload(builtin_questions)
        self.user_info = {}
        self.saved_training_config = saved_training_config or {}
        self.loaded_exam_data = None
        self.start_button_original_text = ""
        self.start_button_original_style = ""
        self.is_starting = False
        self.topic_checkboxes = {}
        self.difficulty_checkboxes = {}
        self.progression_state = {}
        self.training_type_group = None
        self.init_ui()

    def create_step_card(self, step_number, title_text):
        card = QFrame()
        card.setObjectName(f"stepCard{step_number}")
        card.setStyleSheet(f"""
            QFrame#stepCard{step_number} {{
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
            }}
        """)
        
        # Add a soft drop shadow
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(16)
        shadow.setColor(QColor(15, 23, 42, 20))  # dark slate color with opacity 20/255
        shadow.setOffset(0, 4)
        card.setGraphicsEffect(shadow)
        
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 16, 18, 16)
        card_layout.setSpacing(10)
        
        header_layout = QHBoxLayout()
        header_layout.setSpacing(12)
        
        badge = QLabel(str(step_number))
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setFixedSize(26, 26)
        badge.setStyleSheet("""
            QLabel {
                background-color: #eff6ff;
                color: #2563eb;
                border: 2px solid #bfdbfe;
                border-radius: 13px;
                font-size: 13px;
                font-weight: 900;
            }
        """)
        header_layout.addWidget(badge)
        
        title = QLabel(title_text)
        title.setStyleSheet("""
            QLabel {
                color: #0f172a;
                font-size: 15px;
                font-weight: 800;
                background: transparent;
            }
        """)
        header_layout.addWidget(title)
        header_layout.addStretch()
        
        card_layout.addLayout(header_layout)
        
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        separator.setStyleSheet("background-color: #e2e8f0; border: none; height: 1px;")
        card_layout.addWidget(separator)
        
        return card, card_layout
    
    def init_ui(self):
        # Enforce window layout
        self.setWindowTitle("🎓 SecureQuizMaster v2.0 - Certification Python")
        self.setMinimumSize(950, 640)
        self.center_window()
        
        central_widget = QWidget()
        central_widget.setObjectName("centralWidget")
        central_widget.setStyleSheet("""
            #centralWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #f8fafc, stop:1 #f1f5f9);
            }
        """)
        self.setCentralWidget(central_widget)
        
        # Main horizontally split layout
        main_layout = QHBoxLayout(central_widget)
        self.main_layout = main_layout
        main_layout.setContentsMargins(30, 30, 30, 30)
        main_layout.setSpacing(30)
        
        left_pane = QVBoxLayout()
        left_pane.setSpacing(20)
        
        right_pane = QVBoxLayout()
        right_pane.setSpacing(20)
        
        main_layout.addLayout(left_pane, 5)
        main_layout.addLayout(right_pane, 5)
        
        # --- LEFT PANE ---
        # Header Stringent
        title_label = QLabel("🎓 SecureQuizMaster v2.0")
        self.title_label = title_label
        title_label.setStyleSheet("""
            color: #0f172a; 
            font-size: 30px; 
            font-weight: 800; 
            background: transparent;
            letter-spacing: -0.5px;
        """)
        left_pane.addWidget(title_label)
        
        subtitle_label = QLabel("Plateforme de Certification Python Professionnelle")
        subtitle_label.setStyleSheet("color: #64748b; font-size: 15px; margin-bottom: 10px; font-weight: 600; background: transparent;")
        left_pane.addWidget(subtitle_label)
        
        # Leveling & XP Card
        self.level_card = QFrame()
        self.level_card.setObjectName("levelCard")
        self.level_card.setStyleSheet("""
            QFrame#levelCard {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
                padding: 12px;
                margin-bottom: 10px;
            }
        """)
        
        # Drop shadow for level card
        shadow_level = QGraphicsDropShadowEffect(self)
        shadow_level.setBlurRadius(12)
        shadow_level.setColor(QColor(15, 23, 42, 15))
        shadow_level.setOffset(0, 3)
        self.level_card.setGraphicsEffect(shadow_level)
        
        level_layout = QVBoxLayout(self.level_card)
        level_layout.setContentsMargins(12, 10, 12, 10)
        level_layout.setSpacing(8)
        
        stats_row = QHBoxLayout()
        self.level_label = QLabel("⭐ Niveau 1")
        self.level_label.setStyleSheet("font-weight: 900; color: #0f172a; font-size: 13px; background: transparent; border: none;")
        
        self.badges_label = QLabel("🏆 Badges : 0 / 38")
        self.badges_label.setStyleSheet("font-weight: 800; color: #2563eb; font-size: 12px; background: transparent; border: none;")
        
        self.xp_label = QLabel("XP : 0 / 20")
        self.xp_label.setStyleSheet("font-weight: 800; color: #7c3aed; font-size: 12px; background: transparent; border: none;")
        
        stats_row.addWidget(self.level_label)
        stats_row.addStretch()
        stats_row.addWidget(self.badges_label)
        stats_row.addStretch()
        stats_row.addWidget(self.xp_label)
        level_layout.addLayout(stats_row)
        
        self.level_progress = QProgressBar()
        self.level_progress.setRange(0, 100)
        self.level_progress.setValue(0)
        self.level_progress.setTextVisible(True)
        self.level_progress.setFormat("Progress to next level")
        self.level_progress.setMinimumHeight(14)
        self.level_progress.setStyleSheet("""
            QProgressBar {
                background-color: #f1f5f9;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                text-align: center;
                font-weight: 800;
                font-size: 10px;
            }
            QProgressBar::chunk {
                background-color: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                          stop: 0 #8b5cf6, stop: 1 #3b82f6);
                border-radius: 6px;
            }
        """)
        level_layout.addWidget(self.level_progress)
        
        # Progress button inside level card so it sits with the user summary
        self.progress_button = QPushButton("📈 Voir ma Progression")
        self.progress_button.setMinimumHeight(34)
        self.progress_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.progress_button.setStyleSheet("""
            QPushButton {
                background-color: #eff6ff;
                color: #2563eb;
                border: 1px solid #bfdbfe;
                border-radius: 8px;
                font-weight: 800;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #dbeafe;
                border-color: #3b82f6;
            }
            QPushButton:pressed {
                background-color: #bfdbfe;
                border-color: #2563eb;
            }
        """)
        self.progress_button.clicked.connect(self.progress_requested.emit)
        level_layout.addWidget(self.progress_button)
        
        left_pane.addWidget(self.level_card)

        
        # Step 1 Card: Choose Mode
        card1, card1_layout = self.create_step_card(1, "Choisir le Mode")
        
        self.mode_button_group = QButtonGroup()
        mode_btn_widget = QWidget()
        mode_btn_widget.setStyleSheet("background: transparent;")
        mode_btn_layout = QHBoxLayout(mode_btn_widget)
        mode_btn_layout.setContentsMargins(0, 0, 0, 0)
        mode_btn_layout.setSpacing(15)
        
        self.training_radio = QRadioButton("🎯 Entraînement")
        self.training_radio.setChecked(True)
        self.training_radio.setStyleSheet("""
            QRadioButton { 
                color: #334155; 
                background: #ffffff; 
                padding: 12px; 
                border-radius: 10px; 
                font-weight: bold; 
                font-size: 14px; 
                border: 2px solid #e2e8f0; 
            }
            QRadioButton:checked { 
                background: #eff6ff; 
                border: 2px solid #3b82f6; 
                color: #1d4ed8; 
            }
        """)
        self.training_radio.toggled.connect(self.on_mode_changed)
        self.mode_button_group.addButton(self.training_radio)
        mode_btn_layout.addWidget(self.training_radio)
        
        self.exam_radio = QRadioButton("📝 Examen Officiel")
        self.exam_radio.setStyleSheet("""
            QRadioButton { 
                color: #334155; 
                background: #ffffff; 
                padding: 12px; 
                border-radius: 10px; 
                font-weight: bold; 
                font-size: 14px; 
                border: 2px solid #e2e8f0; 
            }
            QRadioButton:checked { 
                background: #fff1f2; 
                border: 2px solid #f43f5e; 
                color: #be123c; 
            }
        """)
        self.exam_radio.toggled.connect(self.on_mode_changed)
        self.mode_button_group.addButton(self.exam_radio)
        mode_btn_layout.addWidget(self.exam_radio)
        card1_layout.addWidget(mode_btn_widget)
        
        self.mode_description = QLabel()
        self.mode_description.setStyleSheet("color: #475569; font-size: 13px; background: #f8fafc; padding: 10px; border-radius: 8px; font-weight: 500; border: 1px solid #e2e8f0;")
        self.mode_description.setWordWrap(True)
        card1_layout.addWidget(self.mode_description)
        
        left_pane.addWidget(card1)
        
        # Step 2 Card: Candidate Profile
        card2, card2_layout = self.create_step_card(2, "Informations du Candidat")
        
        name_h = QHBoxLayout()
        name_h.setSpacing(8)
        self.first_name_input = QLineEdit()
        self.first_name_input.setPlaceholderText("Prénom")
        self.first_name_input.setStyleSheet("padding: 8px; border-radius: 6px; background: #f8fafc; color: #0f172a; border: 1px solid #cbd5e1; font-size: 13px;")
        self.first_name_input.textChanged.connect(self.update_test_info)
        name_h.addWidget(self.first_name_input)
        
        self.last_name_input = QLineEdit()
        self.last_name_input.setPlaceholderText("Nom")
        self.last_name_input.setStyleSheet("padding: 8px; border-radius: 6px; background: #f8fafc; color: #0f172a; border: 1px solid #cbd5e1; font-size: 13px;")
        self.last_name_input.textChanged.connect(self.update_test_info)
        name_h.addWidget(self.last_name_input)
        
        self.specialty_combo = QComboBox()
        self.specialty_combo.addItems(["", "R1", "R2", "R3", "Other"])
        self.specialty_combo.setStyleSheet("padding: 8px; border-radius: 6px; background: #f8fafc; color: #0f172a; border: 1px solid #cbd5e1; font-size: 13px; font-weight: bold;")
        self.specialty_combo.currentTextChanged.connect(self.update_test_info)
        name_h.addWidget(self.specialty_combo)
        
        card2_layout.addLayout(name_h)
        left_pane.addWidget(card2)
        
        # Step 4 Card: Start Session
        card4, card4_layout = self.create_step_card(4, "Lancer la Session")
        
        # Test Overview Frame (originally test_info_container)
        test_info_container = QFrame()
        test_info_container.setObjectName("testInfoContainer")
        test_info_container.setStyleSheet("""
            QFrame#testInfoContainer {
                background: #f8fafc;
                border-radius: 8px;
                border: 1px solid #cbd5e1;
            }
            QLabel {
                border: none;
                background: transparent;
            }
        """)
        test_info_layout = QGridLayout(test_info_container)
        test_info_layout.setContentsMargins(12, 12, 12, 12)
        test_info_layout.setVerticalSpacing(8)
        
        summ_title = QLabel("📊 Aperçu de la Session")
        summ_title.setStyleSheet("color: #0f172a; font-weight: 800; font-size: 14px; background: transparent; margin-bottom: 2px;")
        test_info_layout.addWidget(summ_title, 0, 0, 1, 2)
        
        info_items = [
            ("Mode :", "mode_info", "#2563eb"),
            ("Durée :", "duration_info", "#334155"),
            ("Questions:", "questions_info", "#334155"),
            ("Spécialité :", "specialty_info", "#334155")
        ]
        self.test_info_labels = {}
        for i, (l_text, key, color) in enumerate(info_items):
            lbl = QLabel(l_text)
            lbl.setStyleSheet("color: #64748b; font-weight: 600; font-size: 13px; background: transparent; border: none;")
            test_info_layout.addWidget(lbl, i+1, 0)
            val = QLabel("-")
            val.setStyleSheet(f"color: {color}; font-weight: 800; font-size: 13px; background: transparent; border: none;")
            test_info_layout.addWidget(val, i+1, 1)
            self.test_info_labels[key] = val
        card4_layout.addWidget(test_info_container)
        
        self.status_label = QLabel("● Prêt")
        self.status_label.setStyleSheet("color: #10b981; font-weight: 800; font-size: 13px; padding: 4px; background: transparent; text-align: center;")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card4_layout.addWidget(self.status_label)
        
        # Action Buttons Layout
        btn_box = QHBoxLayout()
        btn_box.setSpacing(10)
        
        self.exit_button = QPushButton("🚪 Quitter")
        self.exit_button.setMinimumHeight(44)
        self.exit_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.exit_button.setStyleSheet("""
            QPushButton {
                background-color: #ffffff;
                color: #dc2626;
                border: 2px solid #fecaca;
                border-radius: 10px;
                font-weight: 800;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #fef2f2;
                border-color: #f87171;
            }
            QPushButton:pressed {
                background-color: #fee2e2;
                border-color: #dc2626;
            }
        """)
        self.exit_button.clicked.connect(self.exit_requested.emit)
        btn_box.addWidget(self.exit_button)
        card4_layout.addLayout(btn_box)
        
        self.start_button = QPushButton("🚀 Démarrer")
        self.start_button.setObjectName("startButton")
        self.start_button.setMinimumHeight(54)
        self.start_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.start_button.setStyleSheet("""
            QPushButton#startButton {
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                          stop: 0 #4f46e5, stop: 0.5 #7c3aed, stop: 1 #4f46e5);
                color: white; border-radius: 12px; font-weight: 900; font-size: 18px;
                border: none;
            }
        """)
        self.start_button_original_style = self.start_button.styleSheet()
        self.start_button_animation = QPropertyAnimation(self.start_button, b"geometry")
        self.start_button.clicked.connect(self.on_start_button_clicked)
        card4_layout.addWidget(self.start_button)
        
        self.loading_indicator = QLabel()
        self.loading_indicator.setVisible(False)
        self.loading_indicator.setStyleSheet("color: #64748b; font-weight: 600; font-size: 13px; text-align: center; background: transparent;")
        card4_layout.addWidget(self.loading_indicator)
        
        left_pane.addWidget(card4)
        
        footer_label = QLabel("© 2025 SecureQuizMaster")
        footer_label.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: bold; background: transparent; margin-top: 5px;")
        footer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        left_pane.addWidget(footer_label)
        
        # --- RIGHT PANE ---
        # Step 3 Card: Setup Parameters
        card3, card3_layout = self.create_step_card(3, "Configuration des Paramètres")
        
        self.stacked_widget = QStackedWidget()
        self.stacked_widget.setStyleSheet("background: transparent; border: none;")
        
        # 3a. Training config widget
        training_widget = QWidget()
        training_layout = QVBoxLayout(training_widget)
        training_layout.setContentsMargins(0, 0, 0, 0)
        training_layout.setSpacing(10)
        
        config_container = QWidget()
        config_container.setStyleSheet("background: transparent;")
        config_layout = QGridLayout(config_container)
        config_layout.setHorizontalSpacing(15)
        config_layout.setVerticalSpacing(12)
        config_layout.setContentsMargins(0, 0, 0, 0)
        config_layout.setColumnStretch(0, 0)
        config_layout.setColumnStretch(1, 1)
        
        type_label = QLabel("Type:")
        type_label.setStyleSheet("color: #475569; font-weight: 600; font-size: 13px; background: transparent;")
        config_layout.addWidget(type_label, 0, 0)
        
        type_widget = QWidget()
        type_widget.setStyleSheet("background: transparent;")
        type_layout = QHBoxLayout(type_widget)
        type_layout.setContentsMargins(0, 0, 0, 0)
        type_layout.setSpacing(8)
        self.training_type_group = QButtonGroup(self)
        
        self.theoretical_radio = QRadioButton("Théorique")
        self.theoretical_radio.setChecked(True)
        self.practical_radio = QRadioButton("Pratique")
        for radio in (self.theoretical_radio, self.practical_radio):
            radio.setStyleSheet("""
                QRadioButton {
                    color: #334155;
                    background: #ffffff;
                    border: 1px solid #cbd5e1;
                    border-radius: 8px;
                    padding: 6px 12px;
                    font-size: 13px;
                    font-weight: bold;
                }
                QRadioButton:checked {
                    background: #eff6ff;
                    color: #1d4ed8;
                    border: 2px solid #3b82f6;
                }
            """)
            radio.toggled.connect(self.on_training_type_changed)
            self.training_type_group.addButton(radio)
            type_layout.addWidget(radio)
        type_layout.addStretch()
        config_layout.addWidget(type_widget, 0, 1)
        
        q_label = QLabel("Questions:")
        q_label.setStyleSheet("color: #475569; font-weight: 600; font-size: 13px; background: transparent;")
        config_layout.addWidget(q_label, 1, 0)
        self.training_question_count = QSpinBox()
        self.training_question_count.setRange(1, 20)
        self.training_question_count.setValue(DEFAULT_VALIDATION_QUESTIONS)
        self.training_question_count.setEnabled(False)
        self.style_training_spinbox(self.training_question_count)
        self.training_question_count.valueChanged.connect(self.update_training_filter_limits)
        self.training_question_count.valueChanged.connect(self.update_test_info)
        config_layout.addWidget(self.create_stepper_control(self.training_question_count), 1, 1)
        
        d_label = QLabel("Minutes:")
        d_label.setStyleSheet("color: #475569; font-weight: 600; font-size: 13px; background: transparent;")
        config_layout.addWidget(d_label, 2, 0)
        self.training_duration = QSpinBox()
        self.training_duration.setRange(1, 180)
        self.training_duration.setValue(DEFAULT_VALIDATION_QUESTIONS)
        self.training_duration.setEnabled(False)
        self.style_training_spinbox(self.training_duration)
        self.training_duration.valueChanged.connect(self.update_test_info)
        config_layout.addWidget(self.create_stepper_control(self.training_duration), 2, 1)
        
        self.custom_quiz_checkbox = QCheckBox("Quiz Personnalisé")
        self.custom_quiz_checkbox.setStyleSheet("""
            QCheckBox {
                color: #0f766e;
                background: #f0fdfa;
                border: 1px solid #99f6e4;
                border-radius: 8px;
                padding: 6px;
                font-size: 12px;
                font-weight: bold;
            }
            QCheckBox:checked {
                background: #ccfbf1;
                border: 2px solid #0f766e;
            }
        """)
        self.custom_quiz_checkbox.stateChanged.connect(self.on_custom_quiz_changed)
        config_layout.addWidget(self.custom_quiz_checkbox, 3, 0, 1, 2)
        
        top_lbl = QLabel("Thèmes :")
        top_lbl.setStyleSheet("color: #475569; font-weight: 600; font-size: 13px; background: transparent;")
        config_layout.addWidget(top_lbl, 4, 0)
        
        top_scroll = QScrollArea()
        top_scroll.setWidgetResizable(True)
        top_scroll.setFixedHeight(350)
        top_scroll.setStyleSheet("QScrollArea { background: #f8fafc; border-radius: 8px; border: 1px solid #cbd5e1; }")
        top_widget = QWidget()
        top_layout = QVBoxLayout(top_widget)
        top_layout.setContentsMargins(8, 8, 8, 8)
        top_layout.setSpacing(6)
        
        self.select_all_topics_checkbox = QCheckBox("Tout sélectionner")
        self.select_all_topics_checkbox.setChecked(False)
        self.select_all_topics_checkbox.setVisible(False)
        self.select_all_topics_checkbox.setStyleSheet("color: #0f172a; font-weight: bold; background: transparent;")
        self.select_all_topics_checkbox.stateChanged.connect(self.on_all_topics_changed)
        top_layout.addWidget(self.select_all_topics_checkbox)
        
        for topic in self.get_training_topics():
            cb = QCheckBox(topic)
            cb.setChecked(False)
            cb.setStyleSheet("color: #334155; background: transparent; font-size: 12px;")
            cb.stateChanged.connect(self.on_topic_selection_changed)
            top_layout.addWidget(cb)
            self.topic_checkboxes[topic] = cb
            
        top_scroll.setWidget(top_widget)
        config_layout.addWidget(top_scroll, 4, 1)
        
        self.topic_summary_label = QLabel()
        self.topic_summary_label.setStyleSheet("color: #0ea5e9; font-size: 11px; font-weight: 600; background: transparent;")
        config_layout.addWidget(self.topic_summary_label, 5, 1)
        
        diff_lbl = QLabel("Difficulté :")
        diff_lbl.setStyleSheet("color: #475569; font-weight: 600; font-size: 13px; background: transparent;")
        config_layout.addWidget(diff_lbl, 6, 0)
        diff_widget = QWidget()
        diff_widget.setStyleSheet("background: transparent;")
        diff_layout = QHBoxLayout(diff_widget)
        diff_layout.setContentsMargins(0, 0, 0, 0)
        
        self.select_all_difficulties_checkbox = QCheckBox("Tout")
        self.select_all_difficulties_checkbox.setChecked(False)
        self.select_all_difficulties_checkbox.setVisible(False)
        self.select_all_difficulties_checkbox.setStyleSheet("color: #0f172a; font-weight: bold; font-size: 12px; background: transparent;")
        self.select_all_difficulties_checkbox.stateChanged.connect(self.on_all_difficulties_changed)
        diff_layout.addWidget(self.select_all_difficulties_checkbox)
        
        for diff in self.get_training_difficulties():
            cb = QCheckBox(DIFFICULTY_LABELS.get(diff, diff.title()))
            cb.setChecked(False)
            cb.setStyleSheet("color: #334155; background: transparent; font-size: 12px;")
            cb.stateChanged.connect(self.on_difficulty_selection_changed)
            diff_layout.addWidget(cb)
            self.difficulty_checkboxes[diff] = cb
            
        config_layout.addWidget(diff_widget, 6, 1)
        
        training_layout.addWidget(config_container)
        
        # Rules reminder — placed under difficulty for clarity
        rules_frame = QFrame()
        rules_frame.setObjectName("rulesContainerRight")
        rules_frame.setStyleSheet("""
            QFrame#rulesContainerRight {
                background: #fffbeb;
                border-radius: 8px;
                border: 1px solid #fcd34d;
            }
            QLabel { border: none; background: transparent; }
        """)
        rules_frame_layout = QHBoxLayout(rules_frame)
        rules_frame_layout.setContentsMargins(12, 8, 12, 8)
        rules_frame_layout.setSpacing(10)
        rf_icon = QLabel("⚠️")
        rf_icon.setStyleSheet("font-size: 14px; color: #b45309;")
        rules_frame_layout.addWidget(rf_icon)
        rf_text = QLabel("Plein écran activé · Soumission automatique · Note de passage : 14/20")
        rf_text.setStyleSheet("color: #b45309; font-size: 11px; font-weight: 600;")
        rf_text.setWordWrap(True)
        rules_frame_layout.addWidget(rf_text, 1)
        training_layout.addWidget(rules_frame)
        training_layout.addStretch()
        
        # 3b. Exam config widget
        exam_widget = QWidget()
        exam_layout = QVBoxLayout(exam_widget)
        exam_layout.setContentsMargins(0, 0, 0, 0)
        exam_layout.setSpacing(10)
        
        exam_tab = QTabWidget()
        exam_tab.setMinimumHeight(150)
        exam_tab.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        exam_tab.setStyleSheet(
            "QTabWidget::pane { border: 1px solid #cbd5e1; border-radius: 8px; background: #ffffff; }"
            "QTabBar::tab { padding: 8px 16px; font-weight: bold; font-size: 12px; color: #64748b; }"
            "QTabBar::tab:selected { color: #1d4ed8; border-bottom: 2px solid #3b82f6; }"
        )
        
        # Tab 1: File Upload
        file_tab = QWidget()
        file_tab_layout = QVBoxLayout(file_tab)
        file_tab_layout.setContentsMargins(12, 12, 12, 12)
        file_tab_layout.setSpacing(8)
        
        file_input_h = QHBoxLayout()
        self.file_path_input = QLineEdit()
        self.file_path_input.setPlaceholderText("Sélectionner un fichier .quiz...")
        self.file_path_input.setStyleSheet(
            "padding: 8px; border-radius: 6px; background: #f8fafc; "
            "color: #0f172a; border: 1px solid #cbd5e1; font-size: 12px;"
        )
        file_input_h.addWidget(self.file_path_input)
        
        self.browse_button = QPushButton("Parcourir")
        self.browse_button.setStyleSheet("""
            QPushButton {
                background-color: #2563eb;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                font-size: 12px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #1d4ed8;
            }
            QPushButton:pressed {
                background-color: #1e40af;
            }
        """)
        self.browse_button.clicked.connect(self.browse_exam_file)
        file_input_h.addWidget(self.browse_button)
        file_tab_layout.addLayout(file_input_h)
        
        self.exam_info_label = QLabel("Aucun fichier sélectionné")
        self.exam_info_label.setStyleSheet(
            "color: #94a3b8; font-style: italic; font-size: 12px; background: transparent;"
        )
        self.exam_info_label.setWordWrap(True)
        file_tab_layout.addWidget(self.exam_info_label)
        file_tab_layout.addStretch()
        exam_tab.addTab(file_tab, "📁 Fichier .quiz")
        
        # Tab 2: Access Code
        code_tab = QWidget()
        code_tab_layout = QVBoxLayout(code_tab)
        code_tab_layout.setContentsMargins(12, 12, 12, 12)
        code_tab_layout.setSpacing(8)
        
        code_lbl = QLabel("Code d'accès à l'examen :")
        code_lbl.setStyleSheet("color: #475569; font-weight: 600; font-size: 12px; background: transparent;")
        code_tab_layout.addWidget(code_lbl)
        
        code_input_h = QHBoxLayout()
        self.exam_code_input = QLineEdit()
        self.exam_code_input.setPlaceholderText("Entrer le code de l'examen…")
        self.exam_code_input.setStyleSheet(
            "padding: 8px; border-radius: 6px; background: #f8fafc; "
            "color: #0f172a; border: 1px solid #cbd5e1; font-size: 12px; letter-spacing: 1px;"
        )
        code_input_h.addWidget(self.exam_code_input)
        
        self.validate_code_button = QPushButton("Valider ✓")
        self.validate_code_button.setStyleSheet("""
            QPushButton {
                background-color: #7c3aed;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                font-size: 12px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #6d28d9;
            }
            QPushButton:pressed {
                background-color: #5b21b6;
            }
        """)
        self.validate_code_button.clicked.connect(self.validate_exam_code_input)
        code_input_h.addWidget(self.validate_code_button)
        code_tab_layout.addLayout(code_input_h)
        
        self.exam_code_info_label = QLabel("")
        self.exam_code_info_label.setStyleSheet(
            "color: #64748b; font-size: 12px; background: transparent;"
        )
        self.exam_code_info_label.setWordWrap(True)
        code_tab_layout.addWidget(self.exam_code_info_label)
        code_tab_layout.addStretch()
        exam_tab.addTab(code_tab, "🔑 Code d'accès")
        
        exam_layout.addWidget(exam_tab)
        exam_layout.addStretch()
        
        self.stacked_widget.addWidget(training_widget)
        self.stacked_widget.addWidget(exam_widget)
        card3_layout.addWidget(self.stacked_widget)
        
        right_pane.addWidget(card3)
        
        # Compatibility
        self.question_count = self.training_question_count
        self.update_mode_description()
        self.refresh_training_progression_controls()
        self.update_training_filter_limits()
        self.apply_saved_training_config()
        self.update_test_info()
        self.update_user_level_summary()
    
    def update_user_level_summary(self):
        """Calculates XP and Level data and updates the top left widget."""
        try:
            from core.training_history import load_training_history
            from core.leveling_system import calculate_leveling_data
            
            history = load_training_history()
            data = calculate_leveling_data(history)
            
            self.level_label.setText(f"⭐ Niv.{data['level']} — {data['level_name']}")
            self.badges_label.setText(f"🏆 {data['unlocked_badges']} / {data['total_badges']} badges")
            
            if data['level'] < 10:
                self.xp_label.setText(f"XP : {data['xp']} / {data['xp_for_next']}")
                pct = int((data['xp_in_level'] / max(1, data['level_range'])) * 100)
                self.level_progress.setValue(pct)
                self.level_progress.setFormat(f"{data['xp_in_level']} / {data['level_range']} XP → Niv.{data['level'] + 1}")
            else:
                self.xp_label.setText(f"XP : {data['xp']} / 2760 (Max)")
                self.level_progress.setValue(100)
                self.level_progress.setFormat("🏆 Niveau Légendaire Atteint !")
        except Exception as e:
            print(f"Error updating level summary: {e}")

    def apply_saved_training_config(self):
        """Restore the previous training setup when trying again."""
        if not self.saved_training_config:
            return

        self.training_radio.setChecked(True)
        if self.saved_training_config.get("assessment_type") == "practical" and hasattr(self, "practical_radio"):
            self.practical_radio.setChecked(True)
        elif hasattr(self, "theoretical_radio"):
            self.theoretical_radio.setChecked(True)
        self.custom_quiz_checkbox.blockSignals(True)
        self.custom_quiz_checkbox.setChecked(bool(self.saved_training_config.get('custom_quiz')))
        self.custom_quiz_checkbox.blockSignals(False)
        self.on_custom_quiz_changed()

        if self.saved_training_config.get('first_name') not in (None, "Anonymous"):
            self.first_name_input.setText(self.saved_training_config.get('first_name', ''))
        if self.saved_training_config.get('last_name') not in (None, "User"):
            self.last_name_input.setText(self.saved_training_config.get('last_name', ''))

        specialty = self.saved_training_config.get('specialty')
        if specialty:
            index = self.specialty_combo.findText(specialty)
            if index >= 0:
                self.specialty_combo.setCurrentIndex(index)

        selected_topics = set(self.saved_training_config.get('selected_topics', []))
        if selected_topics:
            self.select_all_topics_checkbox.blockSignals(True)
            self.select_all_topics_checkbox.setChecked(False)
            self.select_all_topics_checkbox.blockSignals(False)
            for topic, checkbox in self.topic_checkboxes.items():
                checkbox.blockSignals(True)
                checkbox.setChecked(topic in selected_topics)
                checkbox.blockSignals(False)

        selected_difficulties = set(self.saved_training_config.get('selected_difficulties', []))
        if selected_difficulties:
            self.select_all_difficulties_checkbox.blockSignals(True)
            self.select_all_difficulties_checkbox.setChecked(False)
            self.select_all_difficulties_checkbox.blockSignals(False)
            for difficulty, checkbox in self.difficulty_checkboxes.items():
                checkbox.blockSignals(True)
                checkbox.setChecked(difficulty in selected_difficulties)
                checkbox.blockSignals(False)

        self.update_training_filter_limits()
        self.training_question_count.setValue(
            min(
                self.saved_training_config.get('question_count', self.training_question_count.value()),
                self.training_question_count.maximum()
            )
        )
        if self.is_custom_training():
            self.training_duration.setValue(self.saved_training_config.get('duration', self.training_duration.value()))
        else:
            self.training_duration.setValue(self.training_question_count.value())
        self.on_topic_selection_changed()
        self.on_difficulty_selection_changed()
        self.refresh_training_progression_controls()
        self.update_training_filter_limits()

    def style_training_spinbox(self, spinbox):
        spinbox.setButtonSymbols(QSpinBox.ButtonSymbols.NoButtons)
        spinbox.setAlignment(Qt.AlignmentFlag.AlignCenter)
        spinbox.setStyleSheet("background: #f8fafc; color: #0f172a; border-radius: 5px; padding: 2px 4px; font-size: 13px; font-weight: bold; border: 1px solid #cbd5e1;")

    def create_stepper_control(self, spinbox):
        """Create a compact plus/minus control around a hidden-button spinbox."""
        control = QWidget()
        control.setStyleSheet("background: transparent; border: none;")
        layout = QHBoxLayout(control)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        minus_button = QPushButton("−")
        plus_button = QPushButton("+")
        btn_style = """
            QPushButton {
                background-color: #e2e8f0;
                color: #334155;
                border: 1px solid #cbd5e1;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
                min-width: 24px; max-width: 24px;
                min-height: 24px; max-height: 24px;
                padding: 0px;
            }
            QPushButton:hover { background-color: #3b82f6; color: white; border-color: #3b82f6; }
            QPushButton:pressed { background-color: #2563eb; }
            QPushButton:disabled { background-color: #f1f5f9; color: #94a3b8; }
        """
        for button in (minus_button, plus_button):
            button.setFixedSize(24, 24)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            button.setStyleSheet(btn_style)

        spinbox.setFixedHeight(26)
        spinbox.setFixedWidth(52)

        minus_button.clicked.connect(lambda: spinbox.setValue(spinbox.value() - spinbox.singleStep()))
        plus_button.clicked.connect(lambda: spinbox.setValue(spinbox.value() + spinbox.singleStep()))
        spinbox._stepper_minus_button = minus_button
        spinbox._stepper_plus_button = plus_button
        spinbox.valueChanged.connect(lambda value: self.refresh_stepper_buttons(spinbox))
        self.refresh_stepper_buttons(spinbox)

        layout.addWidget(minus_button)
        layout.addWidget(spinbox)
        layout.addWidget(plus_button)
        layout.addStretch()
        return control

    def refresh_stepper_buttons(self, spinbox):
        """Keep custom stepper buttons in sync with the spinbox range."""
        if hasattr(spinbox, "_stepper_minus_button"):
            spinbox._stepper_minus_button.setEnabled(spinbox.isEnabled() and spinbox.value() > spinbox.minimum())
        if hasattr(spinbox, "_stepper_plus_button"):
            spinbox._stepper_plus_button.setEnabled(spinbox.isEnabled() and spinbox.value() < spinbox.maximum())

    def get_training_topics(self):
        """Return topics in canonical order, filtered to those in the question bank."""
        return [
            topic_state["name"]
            for topic_state in build_progression_state(
                get_training_questions(builtin_questions.BASE64_QUESTIONS),
                load_training_history(),
            )["topics"]
        ]

    def get_selected_training_topics(self):
        """Return currently selected training topics."""
        selected = [
            topic for topic, checkbox in self.topic_checkboxes.items()
            if checkbox.isChecked()
        ]
        if self.is_custom_training():
            return selected
        if selected:
            return selected[:1]
        active_topic = self.progression_state.get("active_topic")
        return [active_topic] if active_topic else self.get_training_topics()[:1]

    def get_training_difficulties(self):
        """Return sorted difficulties available in the built-in training questions."""
        difficulties = set()
        for question in get_training_questions(builtin_questions.BASE64_QUESTIONS):
            difficulties.add(question.get('difficulty', 'unknown'))
        return sorted(list(difficulties), key=lambda d: DIFFICULTY_ORDER.index(d) if d in DIFFICULTY_ORDER else 999)

    def get_selected_training_difficulties(self):
        """Return currently selected training difficulties."""
        selected = [
            difficulty for difficulty, checkbox in self.difficulty_checkboxes.items()
            if checkbox.isChecked()
        ]
        if self.is_custom_training():
            return selected
        if selected:
            return selected[:1]
        active_difficulty = self.progression_state.get("active_difficulty")
        return [active_difficulty] if active_difficulty else ["easy"]

    def is_custom_training(self):
        return hasattr(self, "custom_quiz_checkbox") and self.custom_quiz_checkbox.isChecked()

    def is_practical_training(self):
        return hasattr(self, "practical_radio") and self.practical_radio.isChecked()

    def get_practical_questions_for_filters(self, topics=None, difficulties=None):
        topic_set = set(topics or [])
        difficulty_set = set(difficulties or [])
        return [
            question for question in CODING_QUESTIONS
            if (not topic_set or question.get("topic") in topic_set)
            and (not difficulty_set or question.get("difficulty") in difficulty_set)
        ]

    def get_topic_state_map(self):
        return {
            topic_state["name"]: topic_state
            for topic_state in self.progression_state.get("topics", [])
        }

    def get_available_by_topic(self):
        return {
            state["name"]: [difficulty["name"] for difficulty in state.get("difficulties", [])]
            for state in self.progression_state.get("topics", [])
        }

    def get_practical_available_by_topic(self):
        available = {}
        for topic in self.topic_checkboxes:
            difficulties = {
                question.get("difficulty", "unknown")
                for question in CODING_QUESTIONS
                if question.get("topic") == topic
            }
            ordered = [
                difficulty for difficulty in self.difficulty_checkboxes
                if difficulty in difficulties
            ]
            available[topic] = ordered
        return available

    def get_unlocked_training_pairs(self, topics=None, difficulties=None):
        topic_filter = set(topics or [])
        difficulty_filter = set(difficulties or [])
        topic_order = [state["name"] for state in self.progression_state.get("topics", [])]
        available_by_topic = self.get_available_by_topic()
        completed = self.progression_state.get("completed", {})
        pairs = []

        for topic in topic_order:
            if topic_filter and topic not in topic_filter:
                continue
            for difficulty in available_by_topic.get(topic, []):
                if difficulty_filter and difficulty not in difficulty_filter:
                    continue
                if is_difficulty_unlocked(
                    topic,
                    difficulty,
                    topic_order,
                    completed,
                    available_by_topic.get(topic, []),
                    available_by_topic,
                ):
                    pairs.append((topic, difficulty))
        return pairs

    def count_questions_for_pairs(self, pairs):
        pair_set = set(pairs)
        return sum(
            1 for question in get_training_questions(builtin_questions.BASE64_QUESTIONS)
            if (question.get("topic"), question.get("difficulty")) in pair_set
        )

    def count_questions_for_filters(self, topics, difficulties):
        """Count built-in training questions matching selected topics and difficulties."""
        topic_set = set(topics)
        difficulty_set = set(difficulties)
        return sum(
            1 for question in builtin_questions.BASE64_QUESTIONS
            if not question.get('Exams', False)
            and question.get('topic', 'Unknown') in topic_set
            and question.get('difficulty', 'unknown') in difficulty_set
        )

    def count_practical_questions_for_filters(self, topics, difficulties):
        return len(self.get_practical_questions_for_filters(topics, difficulties))

    def refresh_training_progression_controls(self):
        """Apply locked/unlocked/completed/current state to training controls."""
        history = load_training_history()
        if self.is_practical_training():
            filtered_history = filter_history_by_type(history, "practical")
            self.progression_state = build_progression_state(
                CODING_QUESTIONS,
                filtered_history,
            )
        else:
            filtered_history = filter_history_by_type(history, "theoretical")
            self.progression_state = build_progression_state(
                get_training_questions(builtin_questions.BASE64_QUESTIONS),
                filtered_history,
            )
        topic_states = self.get_topic_state_map()
        custom = self.is_custom_training()
        previously_selected_topics = []
        for topic, checkbox in self.topic_checkboxes.items():
            state = topic_states.get(topic, {})
            if checkbox.isChecked() and state.get("unlocked"):
                previously_selected_topics.append(topic)

        if custom:
            selected_topics = previously_selected_topics or [self.progression_state.get("active_topic")]
        else:
            selected_topics = [previously_selected_topics[0]] if previously_selected_topics else [self.progression_state.get("active_topic")]
        selected_topics = {topic for topic in selected_topics if topic}

        checked_topic = None
        for topic, checkbox in self.topic_checkboxes.items():
            state = topic_states.get(topic, {})
            icon = "✓" if state.get("completed") else "▶" if state.get("current") else "◆" if state.get("unlocked") else "🔒"
            checkbox.blockSignals(True)
            checkbox.setEnabled(bool(state.get("unlocked")))
            checkbox.setText(f"{icon}  {topic}  ({state.get('completed_count', 0)}/{state.get('total_count', 0)})")
            if topic in selected_topics and state.get("unlocked"):
                checkbox.setChecked(True)
                checked_topic = topic
            elif not custom or topic not in selected_topics:
                checkbox.setChecked(False)
            checkbox.setStyleSheet(
                self._topic_checkbox_style(
                    completed=state.get("completed", False),
                    current=state.get("current", False),
                    unlocked=state.get("unlocked", False),
                )
            )
            checkbox.blockSignals(False)

        if checked_topic is None:
            active_topic = self.progression_state.get("active_topic")
            checkbox = self.topic_checkboxes.get(active_topic)
            if checkbox and checkbox.isEnabled():
                checkbox.blockSignals(True)
                checkbox.setChecked(True)
                checkbox.blockSignals(False)

        self.refresh_difficulty_progression_controls()
        if hasattr(self, "level_label"):
            self.update_user_level_summary()

    def refresh_difficulty_progression_controls(self):
        """Apply progression state for the currently selected topic's difficulties."""
        topics = [state["name"] for state in self.progression_state.get("topics", [])]
        practical = self.is_practical_training()
        available_by_topic = (
            self.get_practical_available_by_topic()
            if practical
            else self.get_available_by_topic()
        )
        completed = self.progression_state.get("completed", {})
        selected_topics = self.get_selected_training_topics()
        custom = self.is_custom_training()
        previously_selected = []
        for difficulty, checkbox in self.difficulty_checkboxes.items():
            if checkbox.isChecked():
                previously_selected.append(difficulty)

        unlocked_by_difficulty = {}
        completed_by_difficulty = {}
        for difficulty in self.difficulty_checkboxes:
            relevant_topics = selected_topics if custom else selected_topics[:1]
            unlocked_by_difficulty[difficulty] = any(
                is_difficulty_unlocked(
                    topic,
                    difficulty,
                    topics,
                    completed,
                    available_by_topic.get(topic, []),
                    available_by_topic,
                )
                for topic in relevant_topics
            )
            if practical:
                unlocked_by_difficulty[difficulty] = (
                    unlocked_by_difficulty[difficulty]
                    and any(
                        difficulty in available_by_topic.get(topic, [])
                        for topic in relevant_topics
                    )
                )
            topics_with_difficulty = [
                topic for topic in relevant_topics
                if difficulty in available_by_topic.get(topic, [])
            ]
            completed_by_difficulty[difficulty] = bool(topics_with_difficulty) and all(
                difficulty in completed.get(topic, set())
                for topic in topics_with_difficulty
            )

        selected_difficulties = []
        if custom:
            selected_difficulties = [
                difficulty for difficulty in previously_selected
                if unlocked_by_difficulty.get(difficulty)
            ]
            if not selected_difficulties:
                selected_difficulties = [
                    difficulty for difficulty in self.difficulty_checkboxes
                    if unlocked_by_difficulty.get(difficulty)
                ][:1]
        else:
            if previously_selected and unlocked_by_difficulty.get(previously_selected[0]):
                selected_difficulties = [previously_selected[0]]
            else:
                for difficulty in self.difficulty_checkboxes:
                    if unlocked_by_difficulty.get(difficulty) and not completed_by_difficulty.get(difficulty):
                        selected_difficulties = [difficulty]
                        break
            if not selected_difficulties:
                for difficulty in self.difficulty_checkboxes:
                    if unlocked_by_difficulty.get(difficulty):
                        selected_difficulties = [difficulty]
                        break

        selected_difficulty_set = set(selected_difficulties)
        for difficulty, checkbox in self.difficulty_checkboxes.items():
            unlocked = unlocked_by_difficulty.get(difficulty, False)
            completed_here = completed_by_difficulty.get(difficulty, False)
            current = difficulty in selected_difficulty_set and not completed_here
            icon = "✓" if completed_here else "▶" if current else "◆" if unlocked else "🔒"
            checkbox.blockSignals(True)
            checkbox.setEnabled(unlocked)
            checkbox.setText(f"{icon} {DIFFICULTY_LABELS.get(difficulty, difficulty.title())}")
            checkbox.setChecked(difficulty in selected_difficulty_set)
            checkbox.setStyleSheet(
                self._difficulty_checkbox_style(
                    completed=completed_here,
                    current=current,
                    unlocked=unlocked,
                )
            )
            checkbox.blockSignals(False)

    def _topic_checkbox_style(self, completed=False, current=False, unlocked=False):
        if completed:
            border, bg, color = "#059669", "#ecfdf5", "#065f46"
        elif current:
            border, bg, color = "#2563eb", "#eff6ff", "#1d4ed8"
        elif unlocked:
            border, bg, color = "#0f766e", "#f0fdfa", "#115e59"
        else:
            border, bg, color = "#cbd5e1", "#f1f5f9", "#64748b"
        return f"""
            QCheckBox {{
                color: {color};
                background: {bg};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 7px;
                font-size: 13px;
                font-weight: 800;
            }}
            QCheckBox:checked {{ border: 2px solid #2563eb; }}
            QCheckBox:disabled {{
                color: #64748b;
                background: #f1f5f9;
                border: 1px dashed #cbd5e1;
            }}
        """

    def _difficulty_checkbox_style(self, completed=False, current=False, unlocked=False):
        if completed:
            border, bg, color = "#10b981", "#ecfdf5", "#047857"
        elif current:
            border, bg, color = "#f59e0b", "#fffbeb", "#b45309"
        elif unlocked:
            border, bg, color = "#cbd5e1", "#ffffff", "#334155"
        else:
            border, bg, color = "#e5e7eb", "#f8fafc", "#94a3b8"
        return f"""
            QCheckBox {{
                color: {color};
                background: {bg};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 7px;
                font-size: 13px;
                font-weight: 800;
            }}
            QCheckBox:checked {{ border: 2px solid #f59e0b; }}
            QCheckBox:disabled {{ color: #94a3b8; }}
        """

    def on_all_topics_changed(self, *args):
        """Select or clear every training topic."""
        checked = self.select_all_topics_checkbox.isChecked()
        for checkbox in self.topic_checkboxes.values():
            checkbox.blockSignals(True)
            checkbox.setChecked(checked and checkbox.isEnabled())
            checkbox.blockSignals(False)
        self.refresh_difficulty_progression_controls()
        self.update_training_filter_limits()
        self.update_test_info()

    def on_topic_selection_changed(self, *args):
        """Keep training question count aligned with selected topics."""
        sender = self.sender()
        if not self.is_custom_training() and isinstance(sender, QCheckBox) and sender.isChecked():
            for checkbox in self.topic_checkboxes.values():
                if checkbox is not sender:
                    checkbox.blockSignals(True)
                    checkbox.setChecked(False)
                    checkbox.blockSignals(False)
        self.refresh_difficulty_progression_controls()
        self.update_training_filter_limits()
        self.update_test_info()

    def preselect_topic(self, topic_name):
        """Pre-select a specific topic and unselect others, forcing custom quiz mode if needed."""
        if hasattr(self, "custom_quiz_checkbox"):
            self.custom_quiz_checkbox.setChecked(True)
            
        for name, cb in self.topic_checkboxes.items():
            cb.blockSignals(True)
            cb.setChecked(False)
            cb.blockSignals(False)
            
        if topic_name in self.topic_checkboxes:
            cb = self.topic_checkboxes[topic_name]
            cb.blockSignals(True)
            cb.setChecked(True)
            cb.blockSignals(False)
            
        self.refresh_difficulty_progression_controls()
        self.update_training_filter_limits()
        self.update_test_info()

    def on_all_difficulties_changed(self, *args):
        """Select or clear every training difficulty."""
        checked = self.select_all_difficulties_checkbox.isChecked()
        for checkbox in self.difficulty_checkboxes.values():
            checkbox.blockSignals(True)
            checkbox.setChecked(checked and checkbox.isEnabled())
            checkbox.blockSignals(False)
        self.update_training_filter_limits()
        self.update_test_info()

    def on_difficulty_selection_changed(self, *args):
        """Keep training question count aligned with selected difficulties."""
        sender = self.sender()
        if not self.is_custom_training() and isinstance(sender, QCheckBox) and sender.isChecked():
            for checkbox in self.difficulty_checkboxes.values():
                if checkbox is not sender:
                    checkbox.blockSignals(True)
                    checkbox.setChecked(False)
                    checkbox.blockSignals(False)
        self.update_training_filter_limits()
        self.update_test_info()

    def on_custom_quiz_changed(self, *args):
        """Toggle guided progression versus unlocked custom quiz mode."""
        custom = self.is_custom_training()
        self.training_question_count.setEnabled(custom)
        self.training_duration.setEnabled(custom)
        self.select_all_topics_checkbox.setVisible(custom)
        self.select_all_difficulties_checkbox.setVisible(custom)
        self.refresh_training_progression_controls()
        self.update_training_filter_limits()
        self.update_test_info()

    def on_training_type_changed(self, *args):
        """Switch between theoretical MCQ training and practical coding."""
        if not getattr(self, "training_radio", None) or not self.training_radio.isChecked():
            return
        self.refresh_training_progression_controls()
        self.update_training_filter_limits()
        self.update_test_info()

    def update_training_filter_limits(self):
        """Update training question maximum and selected filter summary."""
        topics = self.get_selected_training_topics()
        difficulties = self.get_selected_training_difficulties()
        custom = self.is_custom_training()

        if self.is_practical_training():
            if custom:
                available = self.count_practical_questions_for_filters(topics, difficulties)
                maximum = max(1, min(DEFAULT_VALIDATION_QUESTIONS, available))
                self.training_question_count.setMaximum(maximum)
                self.training_question_count.setEnabled(True)
                self.training_duration.setEnabled(True)
                if self.training_question_count.value() > maximum:
                    self.training_question_count.setValue(maximum)
                if available > 0 and self.training_question_count.value() < 1:
                    self.training_question_count.setValue(1)
                summary_detail = f"practical pool: {available} coding question(s)"
            else:
                self.training_question_count.setEnabled(False)
                self.training_duration.setEnabled(False)
                
                topic_states = [state["name"] for state in self.progression_state.get("topics", [])]
                completed = self.progression_state.get("completed", {})
                available_by_topic = self.get_practical_available_by_topic()
                
                highest_idx = -1
                highest_diff = "easy"
                for topic in topics:
                    for idx, diff in enumerate(DIFFICULTY_ORDER):
                        if is_difficulty_unlocked(topic, diff, topic_states, completed, available_by_topic.get(topic, []), available_by_topic):
                            if idx > highest_idx:
                                highest_idx = idx
                                highest_diff = diff
                                
                if highest_diff == "easy":
                    qc = 3
                elif highest_diff == "medium":
                    qc = 2
                elif highest_diff == "hard":
                    qc = 1
                elif highest_diff == "very hard":
                    qc = 1
                else:
                    qc = 3
                
                available = self.count_practical_questions_for_filters(topics, [highest_diff])
                if 0 < available < qc:
                    qc = available
                elif available == 0:
                    qc = 1
                
                self.training_question_count.setValue(qc)
                self.training_duration.setValue(qc * 10)
                summary_detail = f"auto progression: {highest_diff} ({qc} question(s))"
        elif custom:
            self.training_question_count.setEnabled(True)
            self.training_duration.setEnabled(True)
            pairs = self.get_unlocked_training_pairs(topics, difficulties)
            available = max(1, self.count_questions_for_pairs(pairs))
            maximum = min(DEFAULT_VALIDATION_QUESTIONS, available)
            self.training_question_count.setMaximum(maximum)
            if self.training_question_count.value() > maximum:
                self.training_question_count.setValue(maximum)
            if self.training_question_count.value() < self.training_question_count.minimum():
                self.training_question_count.setValue(self.training_question_count.minimum())
            summary_detail = f"custom pool: {available} unlocked matching question(s)"
        else:
            self.training_question_count.setEnabled(False)
            self.training_duration.setEnabled(False)
            topic = topics[0] if topics else None
            difficulty = difficulties[0] if difficulties else None
            validation_difficulties = get_validation_difficulties(difficulty) if difficulty else []
            available = max(
                1,
                count_validation_questions(
                    get_training_questions(builtin_questions.BASE64_QUESTIONS),
                    topic,
                    difficulty,
                ) if topic and difficulty else 0,
            )
            maximum = min(DEFAULT_VALIDATION_QUESTIONS, available)
            self.training_question_count.setMaximum(maximum)
            self.training_question_count.setValue(maximum)
            self.training_duration.setValue(maximum)
            summary_detail = f"validation includes {', '.join(validation_difficulties)} - {maximum} question(s)"

        self.refresh_stepper_buttons(self.training_question_count)
        self.refresh_stepper_buttons(self.training_duration)

        selected_count = len([cb for cb in self.topic_checkboxes.values() if cb.isChecked()])
        total_count = len(self.topic_checkboxes)
        self.topic_summary_label.setText(
            f"{selected_count}/{total_count} topic selected - {summary_detail}"
        )
    
    def center_window(self):
        """Center the window on the screen"""
        frame_geometry = self.frameGeometry()
        screen_center = self.screen().availableGeometry().center()
        frame_geometry.moveCenter(screen_center)
        self.move(frame_geometry.topLeft())

    def resizeEvent(self, event):
        """Scale outer spacing and headline size with available width."""
        width = event.size().width()
        compact = width < 640
        medium = width < 900

        margin = 12 if compact else 20 if medium else 28
        spacing = 12 if compact else 16 if medium else 20
        if hasattr(self, "main_layout"):
            self.main_layout.setContentsMargins(margin, margin, margin, margin)
            self.main_layout.setSpacing(spacing)

        if hasattr(self, "title_label"):
            font = self.title_label.font()
            font.setPointSize(22 if compact else 28 if medium else 34)
            self.title_label.setFont(font)

        if hasattr(self, "mode_button_layout"):
            self.mode_button_layout.setDirection(
                QBoxLayout.Direction.TopToBottom
                if compact else QBoxLayout.Direction.LeftToRight
            )

        super().resizeEvent(event)
    
    def update_mode_description(self):
        """Update mode description based on selection"""
        if self.training_radio.isChecked():
            self.mode_description.setText("🎯 Training Mode: Practice with built-in questions, immediate feedback, and customizable settings. Perfect for learning at your own pace.")
        else:
            self.mode_description.setText("📝 Exam Mode: Take an official exam with encrypted files. All candidate information is required. This is a secure, timed assessment environment.")
    
    def on_mode_changed(self):
        """Handle mode change between training and exam"""
        self.update_mode_description()
        
        if self.training_radio.isChecked():
            self.stacked_widget.setCurrentIndex(0)  # Training widget
            self.start_button.setText("🚀 Start Training")
            self.setWindowTitle("🎓 SecureQuizMaster v2.0 - Training Mode")
            # Update button style
            self.start_button_original_style = """
                QPushButton#startButton {
                    background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                              stop: 0 #4f46e5, stop: 0.5 #7c3aed, stop: 1 #4f46e5);
                    color: white;
                    font-size: 18px;
                    font-weight: bold;
                    border-radius: 16px;
                    padding: 20px;
                    border: none;
                    min-width: 300px;
                    text-align: center;
                }
                QPushButton#startButton:hover {
                    background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                              stop: 0 #4338ca, stop: 0.5 #6d28d9, stop: 1 #4338ca);
                }
                QPushButton#startButton:pressed {
                    background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                              stop: 0 #3730a3, stop: 0.5 #5b21b6, stop: 1 #3730a3);
                }
            """
        else:
            self.stacked_widget.setCurrentIndex(1)  # Exam widget
            self.start_button.setText("🎯 Start Exam")
            self.setWindowTitle("🎓 SecureQuizMaster v2.0 - Exam Mode")
            # Update button style
            self.start_button_original_style = """
                QPushButton#startButton {
                    background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                              stop: 0 #be185d, stop: 0.5 #db2777, stop: 1 #be185d);
                    color: white;
                    font-size: 18px;
                    font-weight: bold;
                    border-radius: 16px;
                    padding: 20px;
                    border: none;
                    min-width: 300px;
                    text-align: center;
                }
                QPushButton#startButton:hover {
                    background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                              stop: 0 #9d174d, stop: 0.5 #be185d, stop: 1 #9d174d);
                }
                QPushButton#startButton:pressed {
                    background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                              stop: 0 #831843, stop: 0.5 #9d174d, stop: 1 #831843);
                }
            """
        
        if not self.is_starting:
            self.start_button.setStyleSheet(self.start_button_original_style)
        
        self.update_test_info()
    
    def update_test_info(self):
        """Update test information display"""
        if self.training_radio.isChecked():
            # Training mode info
            questions = self.training_question_count.value()
            duration = self.training_duration.value()
            topics = self.get_selected_training_topics()
            difficulties = self.get_selected_training_difficulties()
            
            if self.is_practical_training():
                mode_text = "Practical Coding"
                mode_color = "#0f766e"
            else:
                mode_text = "Custom Training" if self.is_custom_training() else "Theoretical Training"
                mode_color = "#4f46e5"
            self.test_info_labels['mode_info'].setText(mode_text)
            self.test_info_labels['mode_info'].setStyleSheet(f"color: {mode_color}; font-weight: 600; font-size: 14px;")
            self.test_info_labels['duration_info'].setText(f"{duration} minutes")
            if self.is_practical_training():
                self.test_info_labels['questions_info'].setText(
                    f"{questions} coding questions · {len(topics)} topic(s), {len(difficulties)} level(s)"
                )
            elif self.is_custom_training():
                self.test_info_labels['questions_info'].setText(
                    f"{questions} custom questions · {len(topics)} topic(s), {len(difficulties)} level(s)"
                )
            else:
                active_topic = topics[0] if topics else "-"
                active_difficulty = difficulties[0] if difficulties else "-"
                self.test_info_labels['questions_info'].setText(
                    f"{questions} validation questions · {active_topic} · {DIFFICULTY_LABELS.get(active_difficulty, active_difficulty.title())}"
                )
            
            # Get user info or defaults
            first_name = self.first_name_input.text().strip() or "Anonymous"
            last_name = self.last_name_input.text().strip() or "User"
            specialty = self.specialty_combo.currentText() or "-"
            
            self.test_info_labels['specialty_info'].setText(specialty)
            pass
        else:
            # Exam mode info
            if self.loaded_exam_data:
                config = self.loaded_exam_data.get('config', {})
                duration = config.get('duration', 'N/A')
                nbr_questions = config.get('question_count', 'N/A')
                questions = len(self.loaded_exam_data.get('questions', []))
                
                self.test_info_labels['mode_info'].setText("Official Exam")
                self.test_info_labels['mode_info'].setStyleSheet("color: #be185d; font-weight: 600; font-size: 14px;")
                self.test_info_labels['duration_info'].setText(f"{duration} minutes")
                self.test_info_labels['questions_info'].setText(str(nbr_questions))
                
                # Update specialty from user input
                specialty = self.specialty_combo.currentText() or "-"
                self.test_info_labels['specialty_info'].setText(specialty)
            else:
                self.test_info_labels['mode_info'].setText("Exam (No file loaded)")
                self.test_info_labels['mode_info'].setStyleSheet("color: #9ca3af; font-weight: 600; font-size: 14px;")
                self.test_info_labels['duration_info'].setText("N/A")
                self.test_info_labels['questions_info'].setText("N/A")
                
                # Update specialty from user input
                specialty = self.specialty_combo.currentText() or "-"
                self.test_info_labels['specialty_info'].setText(specialty)

    def select_official_exam_questions(self, questions, enabled_topics=None, difficulty_distribution=None, max_questions=20):
        """Prefer exam-designated questions, then fill gaps with regular questions."""
        enabled_topics = set(enabled_topics or [])
        difficulty_distribution = difficulty_distribution or {
            "easy": 8,
            "medium": 7,
            "hard": 3,
            "very hard": 2,
        }
        filtered = [
            question for question in questions
            if not enabled_topics or question.get("topic") in enabled_topics
        ]

        selected = []
        used_ids = set()

        def question_key(question):
            return question.get("id", id(question))

        def add_from_pool(pool, needed):
            random.shuffle(pool)
            added = 0
            for question in pool:
                key = question_key(question)
                if key in used_ids:
                    continue
                selected.append(question)
                used_ids.add(key)
                added += 1
                if added >= needed or len(selected) >= max_questions:
                    break
            return added

        for difficulty, count in difficulty_distribution.items():
            if len(selected) >= max_questions:
                break
            quota = min(count, max_questions - len(selected))
            difficulty_pool = [
                question for question in filtered
                if question.get("difficulty") == difficulty
            ]
            added = add_from_pool(
                [question for question in difficulty_pool if question.get("Exams", False)],
                quota,
            )
            if added < quota:
                add_from_pool(
                    [question for question in difficulty_pool if not question.get("Exams", False)],
                    quota - added,
                )

        if len(selected) < max_questions:
            add_from_pool(
                [question for question in filtered if question.get("Exams", False)],
                max_questions - len(selected),
            )
        if len(selected) < max_questions:
            add_from_pool(
                [question for question in filtered if not question.get("Exams", False)],
                max_questions - len(selected),
            )

        return selected[:max_questions]
    
    def validate_exam_code_input(self):
        """Validate manually entered exam code and populate exam data."""
        reload(builtin_questions)
        code = self.exam_code_input.text().strip()
        if not code:
            self.exam_code_info_label.setText("⚠️ Veuillez saisir un code.")
            self.exam_code_info_label.setStyleSheet("color: #f59e0b; font-size: 12px; background: transparent;")
            return

        result = decode_exam_code(code)
        if not result["valid"]:
            self.exam_code_info_label.setText(f"❌ {result['error']}")
            self.exam_code_info_label.setStyleSheet("color: #ef4444; font-size: 12px; background: transparent;")
            return

        enabled_topics = result["topics"]
        duration = result["duration"]
        exam_id = result["exam_id"]

        DIFFICULTY_DIST = {"easy": 8, "medium": 7, "hard": 3, "very hard": 2}
        all_q = builtin_questions.BASE64_QUESTIONS
        selected_questions = self.select_official_exam_questions(
            all_q,
            enabled_topics=enabled_topics,
            difficulty_distribution=DIFFICULTY_DIST,
            max_questions=20,
        )
        exam_priority_count = sum(1 for question in selected_questions if question.get("Exams", False))

        self.loaded_exam_data = {
            "config": {
                "title": f"Examen Officiel — ID {exam_id}",
                "duration": duration,
                "points_per_question": 1,
                "penalty_per_question": 0.25,
                "max_questions": 20,
                "question_count": len(selected_questions),
                "shuffle_questions": True,
                "shuffle_options": True,
                "options_per_question": 4,
                "topic_filter": enabled_topics,
                "difficulty_filter": list(DIFFICULTY_DIST.keys()),
                "exam_id": exam_id,
            },
            "questions": selected_questions,
        }

        topics_str = ", ".join(enabled_topics)
        info = (
            f"✅ Code valide!\n"
            f"🆔 ID : {exam_id}\n"
            f"⏱ Durée : {duration} min\n"
            f"📚 Thèmes : {topics_str}\n"
            f"📝 Questions : {len(selected_questions)}/20\n"
            f"⭐ Questions officielles : {exam_priority_count}"
        )
        self.exam_code_info_label.setText(info)
        self.exam_code_info_label.setStyleSheet(
            "color: #059669; font-size: 12px; background: transparent; font-weight: 600;"
        )
        self.update_test_info()

    def browse_exam_file(self):
        """Open file dialog to select encrypted exam file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Encrypted Exam File",
            "",
            "Quiz Files (*.quiz);;All Files (*.*)"
        )
        
        if file_path:
            self.file_path_input.setText(file_path)
            
            try:
                # Emit signal to load exam (handled by main controller)
                self.exam_loaded.emit({'file_path': file_path})
                
                # Extract filename
                if '/' in file_path:
                    filename = file_path.split('/')[-1]
                elif '\\' in file_path:
                    filename = file_path.split('\\')[-1]
                else:
                    filename = file_path
                    
                self.exam_info_label.setText(f"✅ Exam file loaded: {filename}")
                self.exam_info_label.setStyleSheet("color: #059669; font-weight: 500; padding: 12px; background-color: white; border-radius: 10px; border: 1px solid #a7f3d0; font-size: 13px;")
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load exam file:\n{str(e)}")
                self.exam_info_label.setText("❌ Failed to load exam file")
                self.exam_info_label.setStyleSheet("color: #dc2626; font-weight: 500; padding: 12px; background-color: white; border-radius: 10px; border: 1px solid #fca5a5; font-size: 13px;")
                self.loaded_exam_data = None
    
    def set_exam_data(self, exam_data):
        """Set loaded exam data and update UI - CALLED BY CONTROLLER"""
        self.loaded_exam_data = exam_data
        if exam_data:
            # Update UI with exam data
            self.update_test_info()
            
            # For compatibility with controller
            questions = len(exam_data.get('questions', []))
            config = exam_data.get('config', {})
            nbr_questions = config.get('question_count', 60)
            duration = config.get('duration', 60)
            
            # Update test info labels
            self.test_info_labels['questions_info'].setText(str(nbr_questions))
            self.test_info_labels['duration_info'].setText(f"{duration} minutes")
            
            # Keep training capped independently from loaded exam files.
            self.training_question_count.setMaximum(20)
    
    def update_exam_info(self):
        """Update exam info display - COMPATIBILITY METHOD"""
        self.update_test_info()
    
    def on_start_button_clicked(self):
        """Handle start button click with animation"""
        if self.is_starting:
            return
            
        # Animate button press
        self.animate_button_press()
        
        # Small delay before validation
        QTimer.singleShot(200, self.validate_and_start)
    
    def animate_button_press(self):
        """Animate the button press effect"""
        original_geometry = self.start_button.geometry()
        pressed_geometry = original_geometry.adjusted(2, 2, -2, -2)
        
        self.start_button_animation.setStartValue(original_geometry)
        self.start_button_animation.setEndValue(pressed_geometry)
        self.start_button_animation.start()
    
    def show_starting_animation(self):
        """Show starting animation on the button"""
        self.is_starting = True
        self.start_button.setEnabled(False)
        self.start_button_original_text = self.start_button.text()
        
        # Change button style to loading state
        self.start_button.setStyleSheet("""
            QPushButton#startButton {
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0,
                                          stop: 0 #10B981, stop: 0.5 #059669, stop: 1 #10B981);
                color: white;
                font-size: 18px;
                font-weight: bold;
                border-radius: 16px;
                padding: 20px;
                border: 2px solid #059669;
                min-width: 300px;
                text-align: center;
            }
        """)
        
        # Show loading text
        self.start_button.setText("🚀 Starting...")
        
        # Show loading indicator
        self.loading_indicator.setText("Initializing secure environment...")
        self.loading_indicator.setVisible(True)
        
        # Update status label
        self.status_label.setText("● Starting...")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #F59E0B;
                font-size: 12px;
                font-weight: 600;
                padding: 5px 15px;
                background: rgba(245, 158, 11, 0.1);
                border-radius: 10px;
                border: 1px solid rgba(245, 158, 11, 0.3);
            }
        """)
    
    def reset_start_button(self):
        """Reset start button to normal state"""
        self.is_starting = False
        self.start_button.setEnabled(True)
        self.start_button.setText(self.start_button_original_text)
        self.start_button.setStyleSheet(self.start_button_original_style)
        self.loading_indicator.setVisible(False)
        
        # Reset status label
        self.status_label.setText("● Prêt")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #10B981;
                font-size: 12px;
                font-weight: 600;
                padding: 5px 15px;
                background: rgba(16, 185, 129, 0.1);
                border-radius: 10px;
                border: 1px solid rgba(16, 185, 129, 0.3);
            }
        """)
    
    def validate_and_start(self):
        """Validate user input and start training/exam with enhanced UI feedback"""
        is_training = self.training_radio.isChecked()
        
        # Show starting animation
        self.show_starting_animation()
        
        # Small delay to show animation before validation
        QTimer.singleShot(300, lambda: self.perform_validation(is_training))
    
    def perform_validation(self, is_training):
        """Perform actual validation and start process"""
        # Validation logic
        errors = []
        
        if is_training:
            # Training mode validation
            self.refresh_training_progression_controls()
            first_name = self.first_name_input.text().strip() or "Anonymous"
            last_name = self.last_name_input.text().strip() or "User"
            specialty = self.specialty_combo.currentText() or "Training"
            question_count = self.training_question_count.value()
            nbr_question = self.training_question_count.value()
            duration = self.training_duration.value()
            selected_topics = self.get_selected_training_topics()
            selected_difficulties = self.get_selected_training_difficulties()
            custom_quiz = self.is_custom_training()
            allowed_training_pairs = []
            practical_training = self.is_practical_training()

            if practical_training:
                if custom_quiz:
                    target_topic = selected_topics[0] if len(selected_topics) == 1 else None
                    target_difficulty = selected_difficulties[0] if len(selected_difficulties) == 1 else None
                    validation_difficulties = selected_difficulties
                    available = self.count_practical_questions_for_filters(selected_topics, selected_difficulties)
                    if not selected_topics:
                        errors.append("Sélectionnez au moins un thème pour la pratique")
                    if not selected_difficulties:
                        errors.append("Sélectionnez au moins une difficulté pour la pratique")
                    if available <= 0:
                        errors.append("Aucune question pratique disponible pour cette sélection")
                    if question_count > available:
                        question_count = min(DEFAULT_VALIDATION_QUESTIONS, available)
                        nbr_question = question_count
                    allowed_training_pairs = sorted({
                        (question.get("topic"), question.get("difficulty"))
                        for question in self.get_practical_questions_for_filters(selected_topics, selected_difficulties)
                    })
                else:
                    if not selected_topics:
                        errors.append("Sélectionnez au moins un thème pour la pratique")
                        target_topic = None
                        target_difficulty = None
                        validation_difficulties = []
                        allowed_training_pairs = []
                    else:
                        target_topic = selected_topics[0] if len(selected_topics) == 1 else None
                        topic_states = [state["name"] for state in self.progression_state.get("topics", [])]
                        completed = self.progression_state.get("completed", {})
                        available_by_topic = self.get_practical_available_by_topic()
                        
                        highest_idx = -1
                        highest_diff = "easy"
                        for topic in selected_topics:
                            for idx, diff in enumerate(DIFFICULTY_ORDER):
                                if is_difficulty_unlocked(topic, diff, topic_states, completed, available_by_topic.get(topic, []), available_by_topic):
                                    if idx > highest_idx:
                                        highest_idx = idx
                                        highest_diff = diff
                                        
                        target_difficulty = highest_diff
                        selected_difficulties = [highest_diff]
                        validation_difficulties = [highest_diff]
                        
                        if highest_diff == "easy":
                            question_count = 3
                        elif highest_diff == "medium":
                            question_count = 2
                        elif highest_diff == "hard":
                            question_count = 1
                        elif highest_diff == "very hard":
                            question_count = 1
                        else:
                            question_count = 3
                            
                        nbr_question = question_count
                        duration = question_count * 10
                        
                        available = self.count_practical_questions_for_filters(selected_topics, selected_difficulties)
                        if available <= 0:
                            errors.append("Aucune question pratique disponible pour cette sélection")
                        if question_count > available:
                            question_count = available
                            nbr_question = available
                            duration = available * 10
                            
                        allowed_training_pairs = sorted({
                            (question.get("topic"), question.get("difficulty"))
                            for question in self.get_practical_questions_for_filters(selected_topics, selected_difficulties)
                        })
            elif custom_quiz:
                target_topic = None
                target_difficulty = None
                validation_difficulties = []
                allowed_training_pairs = self.get_unlocked_training_pairs(selected_topics, selected_difficulties)
                available = self.count_questions_for_pairs(allowed_training_pairs)
                if not selected_topics:
                    errors.append("Sélectionnez au moins un thème débloqué")
                if not selected_difficulties:
                    errors.append("Sélectionnez au moins une difficulté débloquée")
                if not allowed_training_pairs or available <= 0:
                    errors.append("Aucune question disponible pour les thèmes/difficultés débloqués sélectionnés")
                if question_count > available:
                    question_count = min(DEFAULT_VALIDATION_QUESTIONS, available)
                    nbr_question = question_count
            else:
                target_topic = selected_topics[0] if selected_topics else None
                target_difficulty = selected_difficulties[0] if selected_difficulties else None
                validation_difficulties = get_validation_difficulties(target_difficulty) if target_difficulty else []
                topic_states = [state["name"] for state in self.progression_state.get("topics", [])]
                available_by_topic = self.get_available_by_topic()
                completed = self.progression_state.get("completed", {})
                if not target_topic or not target_difficulty:
                    errors.append("Aucun parcours d'entraînement disponible")
                elif not is_difficulty_unlocked(
                    target_topic,
                    target_difficulty,
                    topic_states,
                    completed,
                    available_by_topic.get(target_topic, []),
                    available_by_topic,
                ):
                    errors.append("Ce niveau est encore verrouillé. Terminez le niveau précédent d'abord.")
                allowed_training_pairs = [(target_topic, difficulty) for difficulty in validation_difficulties]
        else:
            # Exam mode validation — enforce daily attempt limit
            first_name = self.first_name_input.text().strip()
            last_name = self.last_name_input.text().strip()
            specialty = self.specialty_combo.currentText()

            # Attempt limit check
            user_key = f"{first_name}.{last_name}".lower().replace(" ", "_") or "anonymous"
            if not can_attempt(user_key):
                self.reset_start_button()
                QMessageBox.warning(
                    self,
                    "Limite atteinte",
                    f"Vous avez atteint le nombre maximum de tentatives ({MAX_DAILY_ATTEMPTS}) "
                    "pour aujourd'hui.\nRevenez demain.",
                    QMessageBox.StandardButton.Ok
                )
                return

            if not first_name:
                errors.append("Le prénom est requis pour l'examen officiel")
            if not last_name:
                errors.append("Le nom de famille est requis pour l'examen officiel")
            if not specialty:
                errors.append("Veuillez sélectionner une spécialité")
            if not self.loaded_exam_data:
                errors.append("Veuillez charger ou valider un fichier/code d'examen")
            
            if self.loaded_exam_data:
                question_count = len(self.loaded_exam_data.get('questions', []))
                config = self.loaded_exam_data.get('config', {})
                nbr_question = config.get('question_count', question_count)
                duration = config.get('duration', 60)
                exam_types = config.get('exam_types', 'theoretical')
                selected_topics = []
                selected_difficulties = []
                target_topic = None
                target_difficulty = None
                validation_difficulties = []
                custom_quiz = False
                allowed_training_pairs = []
            else:
                errors.append("Exam file not loaded properly")
                selected_topics = []
                selected_difficulties = []
                target_topic = None
                target_difficulty = None
                validation_difficulties = []
                custom_quiz = False
                allowed_training_pairs = []
        
        if errors:
            self.reset_start_button()
            QMessageBox.warning(
                self,
                "Validation Error",
                "\n".join(errors),
                QMessageBox.StandardButton.Ok
            )
            return
        
        # Store user info
        self.user_info = {
            'first_name': first_name,
            'last_name': last_name,
            'full_name': f"{first_name} {last_name}",
            'specialty': specialty,
            'question_count': question_count,
            'nbr_question': nbr_question,
            'duration': duration,
            'mode': 'training' if is_training else 'exam',
            'assessment_type': 'practical' if is_training and self.is_practical_training() else 'theoretical',
            'selected_topics': selected_topics,
            'selected_difficulties': selected_difficulties,
            'target_topic': target_topic,
            'target_difficulty': target_difficulty,
            'validation_difficulties': validation_difficulties,
            'custom_quiz': custom_quiz,
            'allowed_training_pairs': allowed_training_pairs,
            'exam_data': self.loaded_exam_data if not is_training else None
        }
        
        # Update loading text
        self.loading_indicator.setText("Preparing secure environment...")
        
        # Small delay before confirmation
        QTimer.singleShot(500, lambda: self.show_confirmation_dialog(is_training, first_name, last_name, specialty, nbr_question, duration))
    
    def show_confirmation_dialog(self, is_training, first_name, last_name, specialty, nbr_question, duration):
        """Show confirmation dialog with enhanced styling"""
        if is_training:
            if self.user_info.get('assessment_type') == 'practical':
                topic_text = ", ".join(self.user_info.get('selected_topics', [])) or "-"
                difficulty_text = ", ".join(
                    DIFFICULTY_LABELS.get(difficulty, difficulty.title())
                    for difficulty in self.user_info.get('selected_difficulties', [])
                ) or "-"
                includes_row = f"""
                <tr><td style='padding: 5px;'><b>📚 Topics:</b></td><td>{topic_text}</td></tr>
                <tr><td style='padding: 5px;'><b>🎚️ Difficulties:</b></td><td>{difficulty_text}</td></tr>
                """
                mode_text = "Practical coding"
            elif self.user_info.get('custom_quiz'):
                topic_text = ", ".join(self.user_info.get('selected_topics', [])) or "-"
                difficulty_text = ", ".join(
                    DIFFICULTY_LABELS.get(difficulty, difficulty.title())
                    for difficulty in self.user_info.get('selected_difficulties', [])
                ) or "-"
                includes_row = f"""
                <tr><td style='padding: 5px;'><b>📚 Topics:</b></td><td>{topic_text}</td></tr>
                <tr><td style='padding: 5px;'><b>🎚️ Difficulties:</b></td><td>{difficulty_text}</td></tr>
                """
                mode_text = "Custom quiz"
            else:
                includes_row = f"""
                <tr><td style='padding: 5px;'><b>📚 Topic:</b></td><td>{self.user_info.get('target_topic', '-')}</td></tr>
                <tr><td style='padding: 5px;'><b>🎚️ Target:</b></td><td>{DIFFICULTY_LABELS.get(self.user_info.get('target_difficulty', ''), self.user_info.get('target_difficulty', '-'))}</td></tr>
                <tr><td style='padding: 5px;'><b>🧪 Includes:</b></td><td>{", ".join(self.user_info.get('validation_difficulties', []))}</td></tr>
                """
                mode_text = "Guided progression"
            confirm_msg = f"""
            <div style='font-size: 14px;'>
            <h3 style='color: #4f46e5;'>Ready to start training?</h3>
            <table style='margin: 15px 0;'>
                <tr><td style='padding: 5px;'><b>👤 Name:</b></td><td>{first_name} {last_name}</td></tr>
                <tr><td style='padding: 5px;'><b>🎯 Mode:</b></td><td>{mode_text}</td></tr>
                <tr><td style='padding: 5px;'><b>📝 Questions:</b></td><td>{nbr_question}</td></tr>
                <tr><td style='padding: 5px;'><b>⏱️ Duration:</b></td><td>{duration} minutes</td></tr>
                {includes_row}
                <tr><td style='padding: 5px;'><b>✅ Pass:</b></td><td>{PASSING_MARK:.0f}/20 ({PASSING_PERCENTAGE}%)</td></tr>
            </table>
            <p>The training will start in <b>fullscreen mode</b>.</p>
            </div>
            """
        else:
            confirm_msg = f"""
            <div style='font-size: 14px;'>
            <h3 style='color: #be185d;'>Ready to start the official exam?</h3>
            <table style='margin: 15px 0;'>
                <tr><td style='padding: 5px;'><b>👤 Name:</b></td><td>{first_name} {last_name}</td></tr>
                <tr><td style='padding: 5px;'><b>🎓 Specialty:</b></td><td>{specialty}</td></tr>
                <tr><td style='padding: 5px;'><b>📝 Questions:</b></td><td>{nbr_question}</td></tr>
                <tr><td style='padding: 5px;'><b>⏱️ Duration:</b></td><td>{duration} minutes</td></tr>
                <tr><td style='padding: 5px;'><b>🎯 Mode:</b></td><td>Official Exam</td></tr>
            </table>
            <p>The exam will start in <b>secure fullscreen mode</b>.</p>
            </div>
            """
        
        # Create custom styled message box
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Confirm Start")
        msg_box.setTextFormat(Qt.TextFormat.RichText)
        msg_box.setText(confirm_msg)
        
        # Style the message box
        msg_box.setStyleSheet("""
            QMessageBox {
                background-color: white;
                border-radius: 15px;
                border: 2px solid #e5e7eb;
            }
            QMessageBox QLabel {
                font-size: 14px;
                color: #374151;
            }
            QMessageBox QPushButton {
                background-color: #3b82f6;
                color: white;
                border-radius: 8px;
                padding: 10px 20px;
                font-weight: bold;
                min-width: 80px;
            }
            QMessageBox QPushButton:hover {
                background-color: #2563eb;
            }
        """)
        
        msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg_box.setDefaultButton(QMessageBox.StandardButton.No)
        
        reply = msg_box.exec()
        
        if reply == QMessageBox.StandardButton.Yes:
            # Final preparation text
            self.loading_indicator.setText("Launching exam interface...")
            self.status_label.setText("● Launching...")
            self.status_label.setStyleSheet("""
                QLabel {
                    color: #3B82F6;
                    font-size: 12px;
                    font-weight: 600;
                    padding: 5px 15px;
                    background: rgba(59, 130, 246, 0.1);
                    border-radius: 10px;
                    border: 1px solid rgba(59, 130, 246, 0.3);
                }
            """)
            
            if not is_training:
                user_key = f"{first_name}.{last_name}".lower().replace(" ", "_") or "anonymous"
                record_attempt(user_key)
            
            # Small delay before emitting signal
            QTimer.singleShot(500, self.emit_start_signal)
        else:
            self.reset_start_button()
    
    def emit_start_signal(self):
        """Emit the start signal and close window"""
        self.exam_started.emit(self.user_info)
        
        # Add fade out effect before closing
        self.fade_out_and_close()
    
    def fade_out_and_close(self):
        """Fade out window before closing"""
        self.fade_animation = QPropertyAnimation(self, b"windowOpacity")
        self.fade_animation.setDuration(300)
        self.fade_animation.setStartValue(1.0)
        self.fade_animation.setEndValue(0.0)
        self.fade_animation.finished.connect(self.close)
        self.fade_animation.start()


if __name__ == "__main__":
    # Test code
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
