"""Persistence helpers for training attempt history with secure storage."""

import json
import os
import pickle
import base64
from datetime import datetime
from typing import Any, Dict, List
from cryptography.fernet import Fernet

HISTORY_DIR = "results"
HISTORY_FILE = "training_history.bin"

# A simple fixed key for "non-human-readable" requirement.
# We derive a valid 32-byte URL-safe base64 key from a stable string.
_RAW_KEY = b'QuizApp-Secure-History-Key-2024!' # 32 bytes exactly
FERNET_KEY = base64.urlsafe_b64encode(_RAW_KEY)

def get_cipher():
    return Fernet(FERNET_KEY)

def get_history_path() -> str:
    return os.path.join(HISTORY_DIR, HISTORY_FILE)


def load_training_history() -> List[Dict[str, Any]]:
    path = get_history_path()
    
    # Try loading from old JSON first for migration
    old_path = os.path.join(HISTORY_DIR, "training_history.json")
    if os.path.exists(old_path) and not os.path.exists(path):
        try:
            with open(old_path, "r", encoding="utf-8") as file:
                data = json.load(file)
            if isinstance(data, list):
                # Save to new format and delete old
                save_history_secure(data)
                os.remove(old_path)
                return data
        except:
            pass

    if not os.path.exists(path):
        return []

    try:
        cipher = get_cipher()
        with open(path, "rb") as file:
            encrypted_data = file.read()
            decrypted_data = cipher.decrypt(encrypted_data)
            return pickle.loads(decrypted_data)
    except Exception as e:
        print(f"Error loading history: {e}")
        return []


def save_history_secure(history: List[Dict[str, Any]]):
    os.makedirs(HISTORY_DIR, exist_ok=True)
    path = get_history_path()
    cipher = get_cipher()
    try:
        serialized_data = pickle.dumps(history)
        encrypted_data = cipher.encrypt(serialized_data)
        with open(path, "wb") as file:
            file.write(encrypted_data)
    except Exception as e:
        print(f"Error saving history: {e}")


def save_training_attempt(user_info: Dict[str, Any], score_result: Dict[str, Any]) -> Dict[str, Any]:
    topic_marks = {}
    for topic, stats in score_result.get("topic_analysis", {}).items():
        topic_marks[topic] = {
            "mark": round((stats.get("percentage", 0) / 100) * 20, 2),
            "percentage": stats.get("percentage", 0),
            "correct": stats.get("correct", 0),
            "total": stats.get("total", 0),
        }

    attempt = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "assessment_type": user_info.get("assessment_type", "theoretical"),
        "student": user_info.get("full_name") or "Anonymous User",
        "specialty": user_info.get("specialty", "Training"),
        "selected_topics": user_info.get("selected_topics", []),
        "selected_difficulties": user_info.get("selected_difficulties", []),
        "target_topic": user_info.get("target_topic"),
        "target_difficulty": user_info.get("target_difficulty"),
        "validation_difficulties": user_info.get("validation_difficulties", []),
        "final_mark": score_result.get("final_mark", 0),
        "percentage": score_result.get("percentage", 0),
        "passed": score_result.get("final_mark", 0) >= 14,
        "correct_count": score_result.get("correct_count", 0),
        "wrong_count": score_result.get("wrong_count", 0),
        "partial_count": score_result.get("partial_count", 0),
        "unanswered_count": score_result.get("unanswered_count", 0),
        "total_questions": score_result.get("total_questions", 0),
        "total_points": score_result.get("total_points", 0),
        "topic_marks": topic_marks,
        "selected_subtypes": user_info.get("selected_subtypes", []),
    }

    history = load_training_history()
    history.append(attempt)
    save_history_secure(history)

    return attempt


def save_practical_attempt(
    user_info: Dict[str, Any],
    question: Dict[str, Any],
    submission_result: Dict[str, Any],
) -> Dict[str, Any]:
    """Persist one practical coding submission in the shared training history."""
    hidden_result = submission_result.get("hidden_result", {})
    max_points = float(submission_result.get("max_points", question.get("points", 0)) or 0)
    score = float(submission_result.get("score", 0) or 0)
    percentage = float(hidden_result.get("percentage", 0) or 0)
    final_mark = round((score / max_points) * 20, 2) if max_points else 0
    topic = question.get("topic", "Practical")
    difficulty = question.get("difficulty", "unknown")

    attempt = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "assessment_type": "practical",
        "student": user_info.get("full_name") or "Anonymous User",
        "specialty": user_info.get("specialty", "Training"),
        "selected_topics": [topic],
        "selected_difficulties": [difficulty],
        "target_topic": topic,
        "target_difficulty": difficulty,
        "validation_difficulties": [difficulty],
        "question_id": question.get("id"),
        "question_title": question.get("title"),
        "final_mark": final_mark,
        "percentage": percentage,
        "passed": final_mark >= 14,
        "correct_count": hidden_result.get("passed", 0),
        "wrong_count": hidden_result.get("failed", 0),
        "partial_count": 0,
        "unanswered_count": 0,
        "total_questions": hidden_result.get("total", 0),
        "total_points": score,
        "max_points": max_points,
        "topic_marks": {
            topic: {
                "mark": final_mark,
                "percentage": percentage,
                "correct": hidden_result.get("passed", 0),
                "total": hidden_result.get("total", 0),
            }
        },
    }

    history = load_training_history()
    history.append(attempt)
    save_history_secure(history)
    return attempt


def filter_history_by_type(history: List[Dict[str, Any]], assessment_type: str) -> List[Dict[str, Any]]:
    """Return attempts for one assessment type. Legacy attempts are theoretical."""
    if assessment_type == "theoretical":
        return [
            attempt for attempt in history
            if attempt.get("assessment_type", "theoretical") == "theoretical"
        ]
    return [
        attempt for attempt in history
        if attempt.get("assessment_type") == assessment_type
    ]

def get_level(average_score: float) -> int:
    """Determine level (1-8) based on average score (0-20)."""
    if average_score < 5: return 1
    if average_score < 7: return 2
    if average_score < 10: return 3
    if average_score < 12: return 4
    if average_score < 14: return 5
    if average_score < 16: return 6
    if average_score < 18: return 7
    return 8

def get_progression_stats(history: List[Dict[str, Any]], latest_attempt: Dict[str, Any]):
    """Calculate levels and point gains."""
    if not history:
        return None
    
    # Exclude the latest attempt from the "previous" average
    previous_attempts = history[:-1]
    
    if not previous_attempts:
        prev_avg = 0
        new_avg = latest_attempt.get("final_mark", 0)
    else:
        prev_marks = [a.get("final_mark", 0) for a in previous_attempts]
        prev_avg = sum(prev_marks) / len(prev_marks)
        
        all_marks = [a.get("final_mark", 0) for a in history]
        new_avg = sum(all_marks) / len(all_marks)
    
    delta = new_avg - prev_avg
    prev_level = get_level(prev_avg) if previous_attempts else 1
    curr_level = get_level(new_avg)
    
    # Calculate initial level
    first_mark = history[0].get("final_mark", 0)
    initial_level = get_level(first_mark)

    return {
        "prev_avg": round(prev_avg, 2),
        "new_avg": round(new_avg, 2),
        "delta": round(delta, 2),
        "prev_level": prev_level,
        "curr_level": curr_level,
        "initial_level": initial_level,
        "level_up": curr_level > prev_level
    }

def get_topic_historical_averages(history: List[Dict[str, Any]]) -> Dict[str, float]:
    """Calculate average mark per topic across all attempts."""
    topic_totals = {}
    topic_counts = {}
    
    for attempt in history:
        for topic, data in attempt.get("topic_marks", {}).items():
            mark = data.get("mark", 0)
            topic_totals[topic] = topic_totals.get(topic, 0) + mark
            topic_counts[topic] = topic_counts.get(topic, 0) + 1
            
    averages = {}
    for topic in topic_totals:
        averages[topic] = round(topic_totals[topic] / topic_counts[topic], 2)
        
    return averages


def clear_training_history():
    """Delete all training history files securely from the filesystem."""
    path = get_history_path()
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception as e:
            print(f"Error removing history file: {e}")
            
    # Also clean legacy history files if they exist
    old_path = os.path.join(HISTORY_DIR, "training_history.json")
    if os.path.exists(old_path):
        try:
            os.remove(old_path)
        except Exception as e:
            print(f"Error removing legacy history file: {e}")
