import os
import datetime
import qrcode
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.units import inch
from reportlab.platypus import KeepTogether

class FusedPDFGenerator:
    def __init__(self):
        self.output_dir = "Finals"
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            
    def _create_qr_code(self, data: str, filename: str) -> str:
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        qr_path = os.path.join(self.output_dir, filename)
        img.save(qr_path)
        return qr_path

    def generate_fused_report(self, theo_score, prac_score, user_info, theo_engine, prac_engine):
        first_name = user_info.get('first_name', 'Anonymous')
        last_name = user_info.get('last_name', 'User')
        specialty = user_info.get('specialty', '-')
        
        theo_mark = theo_score.get('final_mark', 0)
        prac_mark = prac_score.get('final_mark', 0)
        fused_mark = (theo_mark + prac_mark) / 2.0
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_name = f"{first_name}_{last_name}".replace(" ", "_").lower()
        filename = os.path.join(self.output_dir, f"Official_Exam_{safe_name}_{timestamp}.pdf")
        
        doc = SimpleDocTemplate(
            filename,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=50,
            bottomMargin=50
        )
        
        styles = getSampleStyleSheet()
        story = []
        
        # Header
        header_text = "<b>CERTIFICAT D'EXAMEN OFFICIEL</b><br/>"
        header_text += "<font size=12 color='#666666'>SecureQuizMaster - Évaluation Complète</font>"
        story.append(Paragraph(header_text, ParagraphStyle(
            'Header', parent=styles['Title'], fontSize=20, spaceAfter=20, textColor=colors.HexColor('#1e293b')
        )))
        
        # QR Code
        qr_data = f"Name:{first_name} {last_name}|Spec:{specialty}|Theo:{theo_mark:.2f}/20|Prac:{prac_mark:.2f}/20|Final:{fused_mark:.2f}/20"
        qr_path = self._create_qr_code(qr_data, f"qr_temp_{timestamp}.png")
        story.append(Image(qr_path, width=1.5*inch, height=1.5*inch))
        story.append(Spacer(1, 20))
        
        # Executive Summary
        story.append(Paragraph("<b>Résumé de l'Examen</b>", ParagraphStyle('Sub', parent=styles['Heading2'], textColor=colors.HexColor('#2563eb'))))
        
        theo_points_str = f"{theo_score.get('total_points', 0):.2f} / {theo_score.get('max_points', 0):.2f} ({theo_score.get('percentage', 0):.2f}%)"
        prac_points_str = f"{prac_score.get('total_points', 0):.2f} / {prac_score.get('max_points', 0):.2f} ({prac_score.get('percentage', 0):.2f}%)"
        
        summary_data = [
            ["Candidat", f"{first_name} {last_name}"],
            ["Spécialité", specialty],
            ["Note Théorique (/20)", f"{theo_mark:.2f} / 20"],
            ["Détail Théorique", theo_points_str],
            ["Note Pratique (/20)", f"{prac_mark:.2f} / 20"],
            ["Détail Pratique", prac_points_str],
            ["NOTE FINALE", f"{fused_mark:.2f} / 20 ({(theo_score.get('percentage', 0) + prac_score.get('percentage', 0)) / 2:.2f}%)"]
        ]
        
        t = Table(summary_data, colWidths=[200, 200])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (0,-1), colors.HexColor('#f1f5f9')),
            ('TEXTCOLOR', (0,0), (-1,-1), colors.HexColor('#1e293b')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
            ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0,0), (-1,-1), 10),
            ('TOPPADDING', (0,0), (-1,-1), 10),
            ('GRID', (0,0), (-1,-1), 1, colors.HexColor('#cbd5e1'))
        ]))
        story.append(t)
        story.append(Spacer(1, 30))
        
        def render_questions(questions, details, title, is_coding=False):
            story.append(Paragraph(f"<b>{title}</b>", ParagraphStyle('Sub2', parent=styles['Heading2'], textColor=colors.HexColor('#4f46e5'))))
            
            for i, q in enumerate(questions, 1):
                story.append(Spacer(1, 10))
                if is_coding:
                    q_text = f"<b>Q{i}. {q.get('title', 'Coding')}:</b> {q.get('description', '')}"
                else:
                    q_text = f"<b>Q{i}. {q.get('topic', 'Topic')}:</b> {q.get('text', '')}"
                story.append(Paragraph(q_text, ParagraphStyle('Q', parent=styles['Normal'], fontSize=11, textColor=colors.black)))
                
                status = details.get(q['id'], {})
                points_earned = status.get('points', 0) - status.get('penalty', 0)
                status_str = status.get('status', 'unanswered').upper()
                
                if status_str == 'CORRECT':
                    status_color = colors.HexColor('#10b981')
                elif status_str == 'INCORRECT':
                    status_color = colors.HexColor('#ef4444')
                elif status_str == 'PARTIAL':
                    status_color = colors.HexColor('#f59e0b')
                else:
                    status_color = colors.grey
                    
                if is_coding:
                    passed = status.get('passed_tests', 0)
                    total = status.get('total_tests', 0)
                    hints = status.get('hints_used', 0)
                    code_snippet = status.get('code', '')
                    ans_text = f"<b>Tests Passed:</b> {passed}/{total}<br/>"
                    if hints > 0:
                        ans_text += f"<b>Hints Used:</b> {hints} (Penalty applied)<br/>"
                    story.append(Paragraph(ans_text, ParagraphStyle('A', parent=styles['Normal'], fontSize=10, textColor=status_color, leftIndent=15)))
                    if code_snippet:
                        formatted_code = code_snippet.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('\n', '<br/>')
                        code_style = ParagraphStyle('Code', parent=styles['Normal'], fontName='Courier', fontSize=9, leftIndent=15, textColor=colors.HexColor('#334155'))
                        story.append(Paragraph(f"<b>Code:</b><br/>{formatted_code}", code_style))
                else:
                    user_answer = status.get('user_answer')
                    ans_text = f"<b>Status:</b> {status_str}"
                    if user_answer is not None:
                        if q.get('type') == 'mcq':
                            if isinstance(user_answer, list):
                                selected_options = []
                                for idx in user_answer:
                                    if 0 <= idx < len(q.get('display_options', [])):
                                        selected_options.append(q['display_options'][idx])
                                    elif 0 <= idx < len(q.get('options', [])):
                                        selected_options.append(q['options'][idx])
                                if selected_options:
                                    ans_text += f" | <b>Réponse :</b> {', '.join(selected_options)}"
                                else:
                                    ans_text += f" | <b>Réponse :</b> {user_answer}"
                            else:
                                ans_text += f" | <b>Réponse :</b> {user_answer}"
                        elif q.get('type') == 'yesno':
                            val = "Vrai" if user_answer is True else "Faux" if user_answer is False else str(user_answer)
                            ans_text += f" | <b>Réponse :</b> {val}"
                        else:
                            ans_text += f" | <b>Réponse :</b> {user_answer}"
                    story.append(Paragraph(ans_text, ParagraphStyle('A', parent=styles['Normal'], fontSize=10, textColor=status_color, leftIndent=15)))
                
                stat_text = f"<b>Points:</b> {points_earned:+.2f} / {q.get('points', 1.0):.2f}"
                story.append(Paragraph(stat_text, ParagraphStyle('S', parent=styles['Normal'], fontSize=9, textColor=colors.grey, leftIndent=15)))

        # Part 1: Theoretical
        if hasattr(theo_engine, 'selected_questions'):
            render_questions(theo_engine.selected_questions, theo_score.get('details', {}), "Partie 1 : Examen Théorique")
            
        story.append(Spacer(1, 20))
        
        # Part 2: Practical
        if hasattr(prac_engine, 'selected_questions'):
            render_questions(prac_engine.selected_questions, prac_score.get('details', {}), "Partie 2 : Examen Pratique (Code)", is_coding=True)

        story.append(Spacer(1, 30))
        story.append(Paragraph(f"Généré le {datetime.datetime.now().strftime('%d/%m/%Y à %H:%M:%S')}", ParagraphStyle('F', parent=styles['Normal'], fontSize=8, textColor=colors.grey, alignment=1)))

        doc.build(story)
        
        try:
            os.remove(qr_path)
        except:
            pass
            
        return filename
