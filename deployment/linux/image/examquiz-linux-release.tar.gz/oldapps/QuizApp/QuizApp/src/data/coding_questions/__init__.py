# Auto-generated CODING_QUESTIONS module

from .numpy import QUESTIONS as q_numpy
from .pandas import QUESTIONS as q_pandas
from .python_basics import QUESTIONS as q_python_basics
from .python_data_types import QUESTIONS as q_python_data_types
from .control_flow import QUESTIONS as q_control_flow
from .list_comprehension import QUESTIONS as q_list_comprehension
from .i_o import QUESTIONS as q_i_o
from .modules_de_base import QUESTIONS as q_modules_de_base
from .oop import QUESTIONS as q_oop
from .data_visualization import QUESTIONS as q_data_visualization

CODING_QUESTIONS = q_numpy + q_pandas + q_python_basics + q_python_data_types + q_control_flow + q_list_comprehension + q_i_o + q_modules_de_base + q_oop + q_data_visualization
