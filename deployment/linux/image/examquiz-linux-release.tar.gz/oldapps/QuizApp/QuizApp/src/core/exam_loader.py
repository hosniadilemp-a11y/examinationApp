"""
Load and decrypt exam files
"""

import json
import base64
import os
from typing import Dict, List
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import hashlib


class ExamLoader:
    def __init__(self, password: str = None):
        """Initialize ExamLoader with optional password"""
        self.password = password
       
        if password:
            # Derive key from password using PBKDF2
            self.encryption_key = self._derive_key_from_password(password)
        else:
            # Use default key or generate one
            self.encryption_key = self._generate_key()
        
        self.cipher = Fernet(self.encryption_key)
    
    @staticmethod
    def _generate_key() -> bytes:
        """Generate encryption key"""
        return Fernet.generate_key()
    
    def _derive_key_from_password(self, password: str) -> bytes:
        """Derive encryption key from password using PBKDF2"""
        # Use a fixed salt for simplicity (in production, store salt with encrypted data)
        salt = b"SecureQuizMaster2025"  # Fixed salt - can be changed
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        
        # Derive key from password
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        return key
    
    def encrypt_exam(self, exam_data: Dict, output_file: str) -> None:
        """Encrypt exam data and save to file"""
        # Convert to JSON and encrypt
        json_data = json.dumps(exam_data, indent=2).encode()
        encrypted_data = self.cipher.encrypt(json_data)
        
        # Save with .quiz extension
        with open(output_file, 'wb') as f:
            f.write(encrypted_data)
        print(f"Exam encrypted and saved to: {output_file}")
    
    def decrypt_exam(self, encrypted_file: str) -> Dict:
        """Decrypt exam file"""
        with open(encrypted_file, 'rb') as f:
            encrypted_data = f.read()
        
        try:
            # Decrypt
            decrypted_data = self.cipher.decrypt(encrypted_data)
            exam_data = json.loads(decrypted_data.decode())
            return exam_data
        except Exception as e:
            raise ValueError(f"Failed to decrypt exam file. Wrong password? Error: {str(e)}")
    
    def load_builtin_exam(self, questions_module) -> Dict:
        """Load exam from built-in questions module"""
        # This is for the integrated training questions
        return {
            'config': questions_module.EXAM_CONFIG,
            'questions': questions_module.BASE64_QUESTIONS
        }
    
   
def create_sample_exam(password: str = "dilo2025"):
    """Create a sample exam file for testing"""
#     exam_data = {
#         'config': {
#             'duration': 55,
#             'exam_types':'Theoritical',
#             'points_per_question': 1,
#             'penalty_per_question': 0.25,
#             'shuffle_questions': True,
#             'shuffle_options': True,
#             'title': 'Python Certification Exam',
#             'version': '1.0',
#             'description': 'Sample exam for testing'
#         },
#         'questions': [
            
#     {
#     "id": 1,
#     "type": "mcq",
#     "text": "Quelle est la caracteristique principale de Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "Compile",
#         "Dynamiquement type",
#         "Bas niveau",
#         "Non orienté objet"
#     ],
#     "correct": [1]
# },

# {
#     "id": 2,
#     "type": "mcq",
#     "text": "Quelle est la methode utilisee pour redimensionner un tableau NumPy ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "resize()",
#         "reshape()",
#         "reformat()",
#         "rearrange()"
#     ],
#     "correct": [1]
# },

# {
#     "id": 3,
#     "type": "mcq",
#     "text": "Quel est l'avantage de la programmation orientee objet (POO) en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "Reduction de la lisibilite du code",
#         "Diminution de la reutilisation du code",
#         "Augmentation de la modularite et de la reutilisation du code",
#         "Simplification de la complexite du code"
#     ],
#     "correct": [2]
# },

# {
#     "id": 4,
#     "type": "mcq",
#     "text": "Quel est le module utilise pour la manipulation des fichiers et repertoires en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "fileutils",
#         "os",
#         "filesystem",
#         "dirtools"
#     ],
#     "correct": [1]
# },

# {
#     "id": 5,
#     "type": "mcq",
#     "text": "Comment creer un histogramme avec Matplotlib ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "plot_histogram()",
#         "show_histogram()",
#         "hist()",
#         "draw_histogram()"
#     ],
#     "correct": [2]
# },



# {
#     "id": 7,
#     "type": "mcq",
#     "text": "Quelle methode NumPy est utilisee pour aplatir un tableau ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "ravel()",
#         "flat()",
#         "reshape()",
#         "squeeze()"
#     ],
#     "correct": [0]
# },

# {
#     "id": 8,
#     "type": "mcq",
#     "text": "Quel module Python est utilise pour generer des nombres aleatoires ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "random",
#         "randint",
#         "rand",
#         "randomize"
#     ],
#     "correct": [0]
# },

# {
#     "id": 9,
#     "type": "mcq",
#     "text": "Comment créer un dictionnaire vide en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "dict = {}",
#         "dict()",
#         "new dictionary()",
#         "create dict {}"
#     ],
#     "correct": [0]
# },

# {
#     "id": 10,
#     "type": "mcq",
#     "text": "Quelle methode est utilisee pour creer des sequences numeriques avec NumPy ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "generate_sequence()",
#         "sequence()",
#         "arange()",
#         "number_sequence()"
#     ],
#     "correct": [2]
# },

# {
#     "id": 11,
#     "type": "mcq",
#     "text": "Comment obtenir la taille d'une liste en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "len(list)",
#         "size(list)",
#         "count(list)",
#         "length(list)"
#     ],
#     "correct": [0]
# },

# {
#     "id": 12,
#     "type": "mcq",
#     "text": "Quelle est la principale utilisation de la fonction lambda en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "Declaration de variables",
#         "Creation de fonctions anonymes",
#         "Manipulation de fichiers",
#         "Application d'expressions régulieres"
#     ],
#     "correct": [1]
# },

# {
#     "id": 13,
#     "type": "mcq",
#     "text": "Quelle methode est utilisee pour creer des sequences numeriques avec NumPy ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "generate_sequence()",
#         "sequence()",
#         "arange()",
#         "number_sequence()"
#     ],
#     "correct": [2]
# },

# {
#     "id": 14,
#     "type": "mcq",
#     "text": "Comment concatener horizontalement deux tableaux NumPy ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "concatenate_h()",
#         "hstack()",
#         "stack_horizontal()",
#         "horiz_concat()",
#         "concatenate()"
#     ],
#     "correct": [1,4]
# },

# {
#     "id": 15,
#     "type": "mcq",
#     "text": "Quelle fonction NumPy est utilisee pour generer un tableau avec des valeurs aleatoires ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "randarray()",
#         "random_array()",
#         "random()",
#         "randint()",
#         "generate_random()"
#     ],
#     "correct": [2,3]
# },


# {
#     "id": 26,
#     "type": "mcq",
#     "text": "Quelle instruction permet d'afficher un message en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "echo()",
#         "print()",
#         "display()",
#         "show()"
#     ],
#     "correct": [1]
# },

# {
#     "id": 27,
#     "type": "mcq",
#     "text": "Quel type de donnees est retourne par input() en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "int",
#         "float",
#         "string",
#         "bool"
#     ],
#     "correct": [2]
# },

# {
#     "id": 28,
#     "type": "mcq",
#     "text": "Quel operateur est utilise pour la division entiere en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "/",
#         "//",
#         "%",
#         "**"
#     ],
#     "correct": [1]
# },

# {
#     "id": 29,
#     "type": "mcq",
#     "text": "Quel mot cle est utilise pour definir une fonction en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "function",
#         "define",
#         "def",
#         "func"
#     ],
#     "correct": [2]
# },





# {
#     "id": 34,
#     "type": "mcq",
#     "text": "Quelle fonction Pandas permet de lire un fichier CSV ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "load_csv()",
#         "open_csv()",
#         "read_csv()",
#         "import_csv()"
#     ],
#     "correct": [2]
# },

# {
#     "id": 35,
#     "type": "mcq",
#     "text": "Quelle structure principale est utilisee dans Pandas pour stocker des donnees tabulaires ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "Array",
#         "Series",
#         "DataFrame",
#         "Matrix"
#     ],
#     "correct": [2]
# },

# {
#     "id": 36,
#     "type": "mcq",
#     "text": "Quelle methode Pandas permet d'afficher les premieres lignes d un DataFrame ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "start()",
#         "top()",
#         "head()",
#         "begin()"
#     ],
#     "correct": [2]
# },

# {
#     "id": 37,
#     "type": "mcq",
#     "text": "Quelle fonction NumPy permet de creer un tableau rempli de un ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "ones()",
#         "empty()",
#         "null()",
#         "fill_zero()"
#     ],
#     "correct": [0]
# },

# {
#     "id": 38,
#     "type": "mcq",
#     "text": "Quel attribut NumPy donne la forme d'un tableau ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "size",
#         "shape",
#         "length",
#         "dimension"
#     ],
#     "correct": [1]
# },

# {
#     "id": 39,
#     "type": "mcq",
#     "text": "Quelle fonction NumPy permet de calculer la moyenne d un tableau ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "avg()",
#         "mean()",
#         "median()",
#         "sum()",
#         "moy"
#     ],
#     "correct": [1]
# },

# {
#     "id": 40,
#     "type": "mcq",
#     "text": "Quel module Python est utilise pour tracer des graphiques simples ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "seaborn",
#         "plotly",
#         "matplotlib",
#         "matplotlib__v2",
#         "graphlib"
#     ],
#     "correct": [2]
# },

# {
#     "id": 41,
#     "type": "mcq",
#     "text": "Quelle fonction Seaborn est utilisee pour tracer un histogramme ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "hist()",
#         "distplot()",
#         "bar()",
#         "count()"
#     ],
#     "correct": [1]
# },

# {
#     "id": 42,
#     "type": "mcq",
#     "text": "Quel module Python permet d'acceder aux fonctions mathematiques avancees ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "calc",
#         "math",
#         "numpy",
#         "statistics"
#     ],
#     "correct": [1]
# },

# {
#     "id": 43,
#     "type": "mcq",
#     "text": "Quelle instruction permet d'importer un module en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "include",
#         "using",
#         "import",
#         "require"
#     ],
#     "correct": [2]
# },

# {
#     "id": 44,
#     "type": "mcq",
#     "text": "Quel type de boucle est utilise quand le nombre d'iterations est connu ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "while",
#         "loop",
#         "for",
#         "repeat"
#     ],
#     "correct": [2]
# },

# {
#     "id": 45,
#     "type": "mcq",
#     "text": "Quelle fonction permet de convertir une chaine en entier en Python ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "toInt()",
#         "int()",
#         "convert()",
#         "parseInt()"
#     ],
#     "correct": [1]
# },

# {
#     "id": 101,
#     "type": "yesno",
#     "text": "En Python une variable doit etre declaree avant son utilisation",
#     "points": 2,
#     "penalty": 1,
#     "correct": False
# },

# {
#     "id": 102,
#     "type": "yesno",
#     "text": "Une liste Python peut contenir des elements de types differents",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },

# {
#     "id": 103,
#     "type": "yesno",
#     "text": "Un tuple Python peut etre modifie apres sa creation",
#     "points": 2,
#     "penalty": 1,
#     "correct": False
# },

# {
#     "id": 104,
#     "type": "yesno",
#     "text": "La fonction len() peut etre appliquee a une chaine de caracteres",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },

# {
#     "id": 105,
#     "type": "yesno",
#     "text": "NumPy est obligatoire pour utiliser des tableaux en Python",
#     "points": 2,
#     "penalty": 1,
#     "correct": False
# },

# {
#     "id": 106,
#     "type": "yesno",
#     "text": "Un DataFrame Pandas peut contenir des valeurs manquantes",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },

# {
#     "id": 107,
#     "type": "yesno",
#     "text": "La division avec / en Python retourne toujours un entier",
#     "points": 2,
#     "penalty": 1,
#     "correct": False
# },

# {
#     "id": 108,
#     "type": "yesno",
#     "text": "Une fonction Python peut retourner plusieurs valeurs",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },

# {
#     "id": 109,
#     "type": "yesno",
#     "text": "Seaborn peut etre utilise sans Matplotlib installe",
#     "points": 2,
#     "penalty": 1,
#     "correct": False
# },

# {
#     "id": 110,
#     "type": "yesno",
#     "text": "Le mot cle pass permet de ne rien faire dans un bloc de code",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },

# {
#     "id": 301,
#     "type": "mcq",
#     "text": "Quelles fonctions Python peuvent convertir une chaine de caracteres en entier ou en flottant ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "int()",
#         "str()",
#         "float()",
#         "len()",
#         "round()",
#         "chr()"
#     ],
#     "correct": [0, 2]
# },



# {
#     "id": 303,
#     "type": "mcq",
#     "text": "Quelles fonctions NumPy permettent de creer des tableaux avec des valeurs predefinies ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "zeros()",
#         "ones()",
#         "random()",
#         "empty()",
#         "array()",
#         "linspace()"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 304,
#     "type": "mcq",
#     "text": "Quelles instructions Python permettent de faire des boucles ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "for",
#         "while",
#         "if",
#         "def",
#         "try",
#         "switch"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 305,
#     "type": "mcq",
#     "text": "Quelles methodes Python permettent de manipuler des listes ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "append()",
#         "extend()",
#         "pop()",
#         "remove()",
#         "add()",
#         "insert()"
#     ],
#     "correct": [0, 1,5]
# },

# {
#     "id": 306,
#     "type": "mcq",
#     "text": "Quelles methodes Pandas permettent de traiter les valeurs manquantes ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "dropna()",
#         "fillna()",
#         "remove_na()",
#         "replace()",
#         "clear()",
#         "reset()"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 307,
#     "type": "mcq",
#     "text": "Quelles fonctions NumPy permettent de combiner ou concatener des tableaux verticalement ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "concatenate()",
#         "vstack()",
#         "stack()",
#         "append()",
#         "merge()"
#     ],
#     "correct": [0, 1]
# },
# {
#     "id": 307,
#     "type": "mcq",
#     "text": "Quelles fonctions NumPy permettent de combiner ou concatener des tableaux horizantalement ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "concatenate()",
#         "hstack()",
#         "stack()",
#         "append()",
#         "merge()"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 308,
#     "type": "mcq",
#     "text": "Quelles fonctions Python permettent de travailler avec les chaines de caracteres ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "len()",
#         "upper()",
#         "append()",
#         "split()",
#         "extend()",
#         "pop()"
#     ],
#     "correct": [1, 3]
# },

# {
#     "id": 309,
#     "type": "mcq",
#     "text": "Quelles methodes Matplotlib permettent de tracer des graphiques ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "plot()",
#         "scatter()",
#         "hist()",
#         "bar()",
#         "show()",
#         "display()"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 310,
#     "type": "mcq",
#     "text": "Quelles methodes Pandas permettent de grouper et d'aggreguer des donnees ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "groupby()",
#         "aggregate()",
#         "combine()",
#         "join()",
#         "merge()",
#         "concat()"
#     ],
#     "correct": [0, 1]
# },


# {
#     "id": 51,
#     "type": "mcq",
#     "text": "Quelle fonction NumPy permet de calculer le produit des éléments d'un tableau ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "multiply()",
#         "prod()",
#         "product()",
#         "times()",
#         "cumprod()"
#     ],
#     "correct": [1]
# },



# {
#     "id": 53,
#     "type": "mcq",
#     "text": "Quelle méthode permet de compter les occurrences d'une valeur dans une liste ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "count()",
#         "occur()",
#         "frequency()",
#         "times()",
#         "sum()"
#     ],
#     "correct": [0]
# },

# {
#     "id": 54,
#     "type": "mcq",
#     "text": "Quelle fonction NumPy permet de créer un tableau de nombres espacés régulièrement ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "arange()",
#         "linspace()",
#         "range()",
#         "seq()",
#         "regular()"
#     ],
#     "correct": [1]
# },

# {
#     "id": 55,
#     "type": "mcq",
#     "text": "Quelles méthodes permettent de manipuler les index d'un DataFrame Pandas ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "reset_index()",
#         "set_index()",
#         "reindex()",
#         "rename_index()",
#         "drop_index()"
#     ],
#     "correct": [0, 1, 2]
# },

# {
#     "id": 56,
#     "type": "mcq",
#     "text": "Quelles méthodes NumPy permettent de trier un tableau ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "sort()",
#         "argsort()",
#         "order()",
#         "sorted()",
#         "arrange()"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 57,
#     "type": "mcq",
#     "text": "Quelle fonction Python permet de lire le contenu d'un fichier texte ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "open()",
#         "read()",
#         "load()",
#         "import()",
#         "file()"
#     ],
#     "correct": [0]
# },

# {
#     "id": 58,
#     "type": "yesno",
#     "text": "En Python, les ensembles (sets) maintiennent l'ordre d'insertion des éléments",
#     "points": 2,
#     "penalty": 1,
#     "correct": False
# },

# {
#     "id": 59,
#     "type": "yesno",
#     "text": "La fonction map() peut être utilisée pour appliquer une fonction à chaque élément d'une liste",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },

# {
#     "id": 60,
#     "type": "yesno",
#     "text": "NumPy permet d'effectuer des opérations mathématiques sur des tableaux entiers sans boucles explicites",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },


# {
#     "id": 62,
#     "type": "mcq",
#     "text": "Quelle fonction Python permet de vérifier le type d'une variable ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "typeof()",
#         "type()",
#         "checktype()",
#         "var_type()",
#         "dtype()"
#     ],
#     "correct": [1]
# },



# {
#     "id": 64,
#     "type": "mcq",
#     "text": "Quelle méthode NumPy permet de transposer un tableau ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "transpose()",
#         "T",
#         "rotate()",
#         "flip()",
#         "swap()"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 65,
#     "type": "yesno",
#     "text": "Les DataFrames Pandas peuvent être fusionnés avec la méthode merge()",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# },

# {
#     "id": 66,
#     "type": "mcq",
#     "text": "Quelle fonction Matplotlib permet d'enregistrer un graphique dans un fichier ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "save()",
#         "savefig()",
#         "export()",
#         "write()",
#         "store()"
#     ],
#     "correct": [1]
# },



# {
#     "id": 68,
#     "type": "mcq",
#     "text": "Quelles sont les méthodes principales pour gérer les exceptions en Python ?",
#     "points": 2,
#     "penalty": 0.5,
#     "options": [
#         "try",
#         "except",
#         "catch",
#         "finally",
#         "error"
#     ],
#     "correct": [0, 1, 3]
# },

# {
#     "id": 69,
#     "type": "mcq",
#     "text": "Quelle fonction NumPy permet de créer un tableau identité ?",
#     "points": 1,
#     "penalty": 0.25,
#     "options": [
#         "identity()",
#         "eye()",
#         "ones()",
#         "diag()",
#         "matrix()"
#     ],
#     "correct": [0, 1]
# },

# {
#     "id": 70,
#     "type": "yesno",
#     "text": "Les listes en Python sont mutables alors que les tuples sont immutables",
#     "points": 2,
#     "penalty": 1,
#     "correct": True
# }


    #     ]
    # }
    exam_data = {
    'config': {
        'duration': 45,
        'exam_types': 'Practical Programming',
        'points_per_question': 1,
        'question_count': 20,  # Updated from 20 to 30
        'penalty_per_question': 0.25,
        'shuffle_questions': True,
        'shuffle_options': True,
        'title': 'Practique',
        'version': '1.0',
        'description': 'Practical Python programming questions'
    },
    'questions': [
        {
            "id": 501,
            "type": "mcq",
            "topic": "Python Data Types",
            "difficulty": "easy",
            "text": "Quel code permet de creer une liste des nombres de 1 a 10 en utilisant une comprehension de liste?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "list(range(1, 11))",
                "[x for x in range(1, 11)]",
                "[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]",
                "list(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)"
            ],
            "correct": [0, 1]
        },
        
        # === 10 NEW BASIC PYTHON QUESTIONS ===
        {
            "id": 525,
            "type": "mcq",
            "topic": "Python Basics - Variables",
            "difficulty": "easy",
            "text": "Comment declarer une variable en Python?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "x = 5",
                "var x = 5",
                "int x = 5",
                "declare x = 5"
            ],
            "correct": [0]
        },
        
        {
            "id": 526,
            "type": "mcq",
            "topic": "Python Basics - Loops",
            "difficulty": "easy",
            "text": "Comment ecrire une boucle for qui itere sur les nombres de 0 a 4?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "for i in range(5):",
                "for i in [0,1,2,3,4]:",
                "for i from 0 to 4:",
                "for (i=0; i<5; i++):"
            ],
            "correct": [0, 1]
        },
        
        {
            "id": 527,
            "type": "mcq",
            "topic": "Python Basics - Loops",
            "difficulty": "easy",
            "text": "Comment ecrire une boucle while qui s'arrete quand i est egal a 5?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "i = 0\nwhile i < 5:\n    i += 1",
                "i = 0\nwhile i != 5:\n    i = i + 1",
                "i = 0\nwhile i <= 5:\n    i += 1",
                "while i < 5:\n    i = 0\n    i += 1"
            ],
            "correct": [0, 1]
        },
        
        {
            "id": 528,
            "type": "mcq",
            "topic": "Python Basics - Strings",
            "difficulty": "easy",
            "text": "Comment obtenir la longueur d'une chaine de caracteres?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "len(ma_chaine)",
                "ma_chaine.length()",
                "length(ma_chaine)",
                "ma_chaine.size()"
            ],
            "correct": [0]
        },
        
        {
            "id": 529,
            "type": "mcq",
            "topic": "Python Basics - Strings",
            "difficulty": "easy",
            "text": "Comment convertir une chaine en majuscules?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "ma_chaine.upper()",
                "ma_chaine.toUpperCase()",
                "upper(ma_chaine)",
                "str.upper(ma_chaine)"
            ],
            "correct": [0]
        },
        
        {
            "id": 530,
            "type": "mcq",
            "topic": "Python Basics - Conditionals",
            "difficulty": "easy",
            "text": "Comment ecrire une condition if-elif-else en Python?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "if x > 5:\n    print('>5')\nelif x == 5:\n    print('=5')\nelse:\n    print('<5')",
                "if (x > 5) {\n    print('>5')\n} elif (x == 5) {\n    print('=5')\n} else {\n    print('<5')\n}",
                "if x > 5 then\n    print('>5')\nelse if x == 5 then\n    print('=5')\nelse\n    print('<5')",
                "when x > 5:\n    print('>5')\nwhen x == 5:\n    print('=5')\notherwise:\n    print('<5')"
            ],
            "correct": [0]
        },
        
        {
            "id": 531,
            "type": "mcq",
            "topic": "Python Basics - Lists",
            "difficulty": "easy",
            "text": "Comment ajouter un element a la fin d'une liste?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "ma_liste.append(element)",
                "ma_liste.add(element)",
                "ma_liste.push(element)",
                "ma_liste.insert(-1, element)"
            ],
            "correct": [0]
        },
        
        {
            "id": 532,
            "type": "mcq",
            "topic": "Python Basics - Lists",
            "difficulty": "easy",
            "text": "Comment supprimer le premier element d'une liste?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "ma_liste.pop(0)",
                "ma_liste.remove(ma_liste[0])",
                "del ma_liste[0]",
                "ma_liste.delete(0)"
            ],
            "correct": [0, 1, 2]
        },
        
        {
            "id": 533,
            "type": "mcq",
            "topic": "Python Basics - Functions",
            "difficulty": "easy",
            "text": "Comment definir une fonction en Python?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "def ma_fonction(x):\n    return x * 2",
                "function ma_fonction(x):\n    return x * 2",
                "def ma_fonction(x):\n    result = x * 2\n    return result",
                "define ma_fonction(x):\n    return x * 2"
            ],
            "correct": [0, 2]
        },
        
        {
            "id": 534,
            "type": "mcq",
            "topic": "Python Basics - Operators",
            "difficulty": "easy",
            "text": "Quels sont les operateurs de comparaison valides en Python?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "== (egalite)",
                "!= (difference)",
                ">= (superieur ou egal)",
                "== (egal) et === (strictement egal)"
            ],
            "correct": [0, 1, 2]
        },
        # === END OF NEW QUESTIONS ===
        
        {
            "id": 504,
            "type": "mcq",
            "text": "Comment creer un graphique lineaire avec matplotlib?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "plt.plot([1,2,3], [4,5,6])",
                "plt.line([1,2,3], [4,5,6])",
                "plt.plots([1,2,3], [4,5,6])",
                "plt.graph([1,2,3], [4,5,6])"
            ],
            "correct": [0]
        },
        
        {
            "id": 505,
            "type": "mcq",
            "text": "Comment creer un array numpy de zeros de taille 3x3?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "np.zeros((3,3))",
                "np.array([[0,0,0],[0,0,0],[0,0,0]])",
                "np.zeroes(3,3)",
                "np.zeros(shape=(4,4))"
            ],
            "correct": [0, 1]
        },
        
        {
            "id": 506,
            "type": "mcq",
            "text": "Comment filtrer un DataFrame pandas pour garder les lignes ou age > 30?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "df[df['age'] > 30]",
                "df.filter(df['age'] > 30)",
                "df.query('age > 30')",
                "df.where(df['age'] > 30)"
            ],
            "correct": [0, 2]
        },
        
        {
            "id": 507,
            "type": "mcq",
            "text": "Comment calculer la moyenne des valeurs d'une colonne dans pandas?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "df['column'].mean()",
                "df['column'].average()",
                "np.mean(df['column'])",
                "df.min()['column']"
            ],
            "correct": [0, 2]
        },
        
        {
            "id": 508,
            "type": "mcq",
            "text": "Comment creer un histogramme avec seaborn?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "sns.histplot(data=df, x='column')",
                "sns.distplot(df['column'])",
                "sns.hist(df['column'])",
                "sns.histogramme(data=df, x='column')"
            ],
            "correct": [0]
        },
       
        {
            "id": 511,
            "type": "mcq",
            "text": "Comment creer une fonction lambda qui double un nombre?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "lambda x: x * 2",
                "double = lambda x: x * 2",
                "def double(x): return x * 2",
                "lambda x: return x * 2"
            ],
            "correct": [0, 1, 2]
        },
        
        {
            "id": 515,
            "type": "mcq",
            "text": "Comment sauvegarder un graphique matplotlib dans un fichier?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "plt.savefig('graph.png')",
                "plt.export('graph.png')",
                "plt.figure().savefig('graph.png')",
                "fig.savefig('graph.png', dpi=300)"
            ],
            "correct": [0, 3]
        },
        
        {
            "id": 516,
            "type": "mcq",
            "text": "Comment creer un subplot avec matplotlib?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "fig, axes = plt.subplots(2, 2)",
                "plt.subplot(2, 2, 1)\nplt.plot(x, y)",
                "axes = plt.grids(2, 2)",
                "axes = plt.grid(2, 2)"
            ],
            "correct": [0, 1]
        },

        {
            "id": 518,
            "type": "mcq",
            "text": "Comment grouper des donnees et calculer des statistiques avec pandas?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "df.groupby('category')['value'].mean()",
                "df.groupby('category').agg({'value': ['mean', 'sum']})",
                "df.groupby('category').describe()",
                "df.group('category').mean('value')"
            ],
            "correct": [0, 1, 2]
        },
        
        {
            "id": 519,
            "type": "mcq",
            "text": "Comment fusionner deux DataFrames pandas?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "pd.merge(df1, df2, on='key')",
                "df1.mergesWith(df2, on='key')",
                "pd.concat([df1, df2], axis=1)",
                "df1.joinswiht(df2, on='key')"
            ],
            "correct": [0]
        },
        
        {
            "id": 520,
            "type": "mcq",
            "text": "Comment creer un scatter plot avec seaborn?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "sns.scatterplot(data=df, x='x_col', y='y_col')",
                "sns.scatter(x='x_col', y='y_col', data=df)",
                "sns.plot_scatter(data=df, x='x_col', y='y_col', kind='scatter')",
                "sns.plot_scatter(df['x_col'], df['y_col'])"
            ],
            "correct": [0]
        },
        
        {
            "id": 521,
            "type": "mcq",
            "text": "Comment changer le style d'un graphique seaborn?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "sns.set_style('darkgrid')",
                "sns.set_theme(style='whitegrid')",
                "sns.set(context='paper', style='ticks')",
                "plt.style.use('seaborn-darkgrid')"
            ],
            "correct": [0, 1, 2, 3]
        },
        
        {
            "id": 522,
            "type": "mcq",
            "text": "Comment trier un DataFrame pandas par une colonne?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "df.sort_values('column')",
                "df.sort('column')",
                "df.order_by('column')",
                "df.sort_values(by='column', ascending=False)"
            ],
            "correct": [0, 1, 2, 3]
        },
        
        {
            "id": 523,
            "type": "mcq",
            "text": "Comment calculer des statistiques descriptives avec pandas?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "df.describe()",
                "df.agg(['mean', 'std', 'min', 'max'])",
                "df.summary()",
                "pd.describe(df)"
            ],
            "correct": [0, 1]
        },
        
        {
            "id": 524,
            "type": "mcq",
            "text": "Comment creer un bar plot avec matplotlib?",
            "points": 1,
            "penalty": 0.25,
            "options": [
                "plt.bar(['A','B','C'], [1,2,3])",
                "plt.bars(['A','B','C'], [1,2,3])",
                "plt.plot(kind='bars', x=['A','B','C'], y=[1,2,3])",
                "plt.plot(kind='bar', x=['A','B','C'], y=[1,2,3])"
            ],
            "correct": [0, 1]
        },
    ]
}
#  %------------------------------------------------  

#  %------------------------------------------------  
#  %------------------------------------------------  
    # exam_data = {
    #     'config': {
    #     'duration': 45,
    #     'exam_types': 'Practical Programming',
    #     'question_count':20,
    #     'points_per_question': 1,
    #     'penalty_per_question': 0.25,
    #     'shuffle_questions': True,
    #     'shuffle_options': True,
    #     ''
    #     'title': 'Theorique',
    #     'version': '1.0',
    #     'description': 'Practical Python programming questions'
    # },
    # 'questions':[
    # {
    #     "id": 1,
    #     "type": "mcq",
    #     "topic": "Python Basics",
    #     "difficulty": "easy",
    #     "text": "Quelle est la caracteristique principale de Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "Compile",
    #         "Dynamiquement type",
    #         "Bas niveau",
    #         "Non orienté objet"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 2,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle est la methode utilisee pour redimensionner un tableau NumPy ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "resize()",
    #         "reshape()",
    #         "reformat()",
    #         "rearrange()"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 3,
    #     "type": "mcq",
    #     "topic": "OOP Concepts",
    #     "difficulty": "medium",
    #     "text": "Quel est l'avantage de la programmation orientee objet (POO) en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "Reduction de la lisibilite du code",
    #         "Diminution de la reutilisation du code",
    #         "Augmentation de la modularite et de la reutilisation du code",
    #         "Simplification de la complexite du code"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 4,
    #     "type": "mcq",
    #     "topic": "File Handling",
    #     "difficulty": "easy",
    #     "text": "Quel est le module utilise pour la manipulation des fichiers et repertoires en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "fileutils",
    #         "os",
    #         "filesystem",
    #         "dirtools"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 5,
    #     "type": "mcq",
    #     "topic": "Data Visualization",
    #     "difficulty": "easy",
    #     "text": "Comment creer un histogramme avec Matplotlib ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "plot_histogram()",
    #         "show_histogram()",
    #         "hist()",
    #         "draw_histogram()"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 7,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle methode NumPy est utilisee pour aplatir un tableau ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "ravel()",
    #         "flat()",
    #         "reshape()",
    #         "squeeze()"
    #     ],
    #     "correct": [0]
    # },
    # {
    #     "id": 8,
    #     "type": "mcq",
    #     "topic": "Python Basics",
    #     "difficulty": "easy",
    #     "text": "Quel module Python est utilise pour generer des nombres aleatoires ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "random",
    #         "randint",
    #         "rand",
    #         "randomize"
    #     ],
    #     "correct": [0]
    # },
    # {
    #     "id": 9,
    #     "type": "mcq",
    #     "topic": "Data Structures",
    #     "difficulty": "easy",
    #     "text": "Comment créer un dictionnaire vide en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "dict = {}",
    #         "dict()",
    #         "new dictionary()",
    #         "create dict {}"
    #     ],
    #     "correct": [0]
    # },
    # {
    #     "id": 10,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle methode est utilisee pour creer des sequences numeriques avec NumPy ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "generate_sequence()",
    #         "sequence()",
    #         "arange()",
    #         "number_sequence()"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 11,
    #     "type": "mcq",
    #     "topic": "Data Structures",
    #     "difficulty": "easy",
    #     "text": "Comment obtenir la taille d'une liste en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "len(list)",
    #         "size(list)",
    #         "count(list)",
    #         "length(list)"
    #     ],
    #     "correct": [0]
    # },
    # {
    #     "id": 12,
    #     "type": "mcq",
    #     "topic": "Functions",
    #     "difficulty": "medium",
    #     "text": "Quelle est la principale utilisation de la fonction lambda en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "Declaration de variables",
    #         "Creation de fonctions anonymes",
    #         "Manipulation de fichiers",
    #         "Application d'expressions régulieres"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 13,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle methode est utilisee pour creer des sequences numeriques avec NumPy ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "generate_sequence()",
    #         "sequence()",
    #         "arange()",
    #         "number_sequence()"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 14,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "hard",
    #     "text": "Comment concatener horizontalement deux tableaux NumPy ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "concatenate_h()",
    #         "hstack()",
    #         "stack_horizontal()",
    #         "horiz_concat()",
    #         "concatenate()"
    #     ],
    #     "correct": [1,4]
    # },
    # {
    #     "id": 15,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle fonction NumPy est utilisee pour generer un tableau avec des valeurs aleatoires ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "randarray()",
    #         "random_array()",
    #         "random()",
    #         "randint()",
    #         "generate_random()"
    #     ],
    #     "correct": [2,3]
    # },
    # {
    #     "id": 26,
    #     "type": "mcq",
    #     "topic": "Python Basics",
    #     "difficulty": "easy",
    #     "text": "Quelle instruction permet d'afficher un message en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "echo()",
    #         "print()",
    #         "display()",
    #         "show()"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 27,
    #     "type": "mcq",
    #     "topic": "Input/Output",
    #     "difficulty": "easy",
    #     "text": "Quel type de donnees est retourne par input() en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "int",
    #         "float",
    #         "string",
    #         "bool"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 28,
    #     "type": "mcq",
    #     "topic": "Operators",
    #     "difficulty": "easy",
    #     "text": "Quel operateur est utilise pour la division entiere en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "/",
    #         "//",
    #         "%",
    #         "**"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 29,
    #     "type": "mcq",
    #     "topic": "Functions",
    #     "difficulty": "easy",
    #     "text": "Quel mot cle est utilise pour definir une fonction en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "function",
    #         "define",
    #         "def",
    #         "func"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 34,
    #     "type": "mcq",
    #     "topic": "Pandas",
    #     "difficulty": "easy",
    #     "text": "Quelle fonction Pandas permet de lire un fichier CSV ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "load_csv()",
    #         "open_csv()",
    #         "read_csv()",
    #         "import_csv()"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 35,
    #     "type": "mcq",
    #     "topic": "Pandas",
    #     "difficulty": "easy",
    #     "text": "Quelle structure principale est utilisee dans Pandas pour stocker des donnees tabulaires ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "Array",
    #         "Series",
    #         "DataFrame",
    #         "Matrix"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 36,
    #     "type": "mcq",
    #     "topic": "Pandas",
    #     "difficulty": "easy",
    #     "text": "Quelle methode Pandas permet d'afficher les premieres lignes d un DataFrame ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "start()",
    #         "top()",
    #         "head()",
    #         "begin()"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 37,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "easy",
    #     "text": "Quelle fonction NumPy permet de creer un tableau rempli de un ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "ones()",
    #         "empty()",
    #         "null()",
    #         "fill_zero()"
    #     ],
    #     "correct": [0]
    # },
    # {
    #     "id": 38,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "easy",
    #     "text": "Quel attribut NumPy donne la forme d'un tableau ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "size",
    #         "shape",
    #         "length",
    #         "dimension"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 39,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "easy",
    #     "text": "Quelle fonction NumPy permet de calculer la moyenne d un tableau ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "avg()",
    #         "mean()",
    #         "median()",
    #         "sum()",
    #         "moy"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 40,
    #     "type": "mcq",
    #     "topic": "Data Visualization",
    #     "difficulty": "easy",
    #     "text": "Quel module Python est utilise pour tracer des graphiques simples ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "seaborn",
    #         "plotly",
    #         "matplotlib",
    #         "matplotlib__v2",
    #         "graphlib"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 41,
    #     "type": "mcq",
    #     "topic": "Data Visualization",
    #     "difficulty": "medium",
    #     "text": "Quelle fonction Seaborn est utilisee pour tracer un histogramme ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "hist()",
    #         "distplot()",
    #         "bar()",
    #         "count()"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 42,
    #     "type": "mcq",
    #     "topic": "Python Modules",
    #     "difficulty": "easy",
    #     "text": "Quel module Python permet d'acceder aux fonctions mathematiques avancees ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "calc",
    #         "math",
    #         "numpy",
    #         "statistics"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 43,
    #     "type": "mcq",
    #     "topic": "Python Basics",
    #     "difficulty": "easy",
    #     "text": "Quelle instruction permet d'importer un module en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "include",
    #         "using",
    #         "import",
    #         "require"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 44,
    #     "type": "mcq",
    #     "topic": "Control Flow",
    #     "difficulty": "easy",
    #     "text": "Quel type de boucle est utilise quand le nombre d'iterations est connu ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "while",
    #         "loop",
    #         "for",
    #         "repeat"
    #     ],
    #     "correct": [2]
    # },
    # {
    #     "id": 45,
    #     "type": "mcq",
    #     "topic": "Type Conversion",
    #     "difficulty": "easy",
    #     "text": "Quelle fonction permet de convertir une chaine en entier en Python ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "toInt()",
    #         "int()",
    #         "convert()",
    #         "parseInt()"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 101,
    #     "type": "yesno",
    #     "topic": "Python Basics",
    #     "difficulty": "easy",
    #     "text": "En Python une variable doit etre declaree avant son utilisation",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": False
    # },
    # {
    #     "id": 102,
    #     "type": "yesno",
    #     "topic": "Data Structures",
    #     "difficulty": "easy",
    #     "text": "Une liste Python peut contenir des elements de types differents",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 103,
    #     "type": "yesno",
    #     "topic": "Data Structures",
    #     "difficulty": "medium",
    #     "text": "Un tuple Python peut etre modifie apres sa creation",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": False
    # },
    # {
    #     "id": 104,
    #     "type": "yesno",
    #     "topic": "Built-in Functions",
    #     "difficulty": "easy",
    #     "text": "La fonction len() peut etre appliquee a une chaine de caracteres",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 105,
    #     "type": "yesno",
    #     "topic": "NumPy",
    #     "difficulty": "easy",
    #     "text": "NumPy est obligatoire pour utiliser des tableaux en Python",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": False
    # },
    # {
    #     "id": 106,
    #     "type": "yesno",
    #     "topic": "Pandas",
    #     "difficulty": "medium",
    #     "text": "Un DataFrame Pandas peut contenir des valeurs manquantes",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 107,
    #     "type": "yesno",
    #     "topic": "Operators",
    #     "difficulty": "easy",
    #     "text": "La division avec / en Python retourne toujours un entier",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": False
    # },
    # {
    #     "id": 108,
    #     "type": "yesno",
    #     "topic": "Functions",
    #     "difficulty": "medium",
    #     "text": "Une fonction Python peut retourner plusieurs valeurs",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 109,
    #     "type": "yesno",
    #     "topic": "Data Visualization",
    #     "difficulty": "medium",
    #     "text": "Seaborn peut etre utilise sans Matplotlib installe",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": False
    # },
    # {
    #     "id": 110,
    #     "type": "yesno",
    #     "topic": "Control Flow",
    #     "difficulty": "easy",
    #     "text": "Le mot cle pass permet de ne rien faire dans un bloc de code",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 301,
    #     "type": "mcq",
    #     "topic": "Type Conversion",
    #     "difficulty": "medium",
    #     "text": "Quelles fonctions Python peuvent convertir une chaine de caracteres en entier ou en flottant ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "int()",
    #         "str()",
    #         "float()",
    #         "len()",
    #         "round()",
    #         "chr()"
    #     ],
    #     "correct": [0, 2]
    # },
    # {
    #     "id": 303,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelles fonctions NumPy permettent de creer des tableaux avec des valeurs predefinies ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "zeros()",
    #         "ones()",
    #         "random()",
    #         "empty()",
    #         "array()",
    #         "linspace()"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 304,
    #     "type": "mcq",
    #     "topic": "Control Flow",
    #     "difficulty": "easy",
    #     "text": "Quelles instructions Python permettent de faire des boucles ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "for",
    #         "while",
    #         "if",
    #         "def",
    #         "try",
    #         "switch"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 305,
    #     "type": "mcq",
    #     "topic": "Data Structures",
    #     "difficulty": "medium",
    #     "text": "Quelles methodes Python permettent de manipuler des listes ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "append()",
    #         "extend()",
    #         "pop()",
    #         "remove()",
    #         "add()",
    #         "insert()"
    #     ],
    #     "correct": [0, 1,5]
    # },
    # {
    #     "id": 306,
    #     "type": "mcq",
    #     "topic": "Pandas",
    #     "difficulty": "hard",
    #     "text": "Quelles methodes Pandas permettent de traiter les valeurs manquantes ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "dropna()",
    #         "fillna()",
    #         "remove_na()",
    #         "replace()",
    #         "clear()",
    #         "reset()"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 307,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "hard",
    #     "text": "Quelles fonctions NumPy permettent de combiner ou concatener des tableaux verticalement ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "concatenate()",
    #         "vstack()",
    #         "stack()",
    #         "append()",
    #         "merge()"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 307,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "hard",
    #     "text": "Quelles fonctions NumPy permettent de combiner ou concatener des tableaux horizantalement ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "concatenate()",
    #         "hstack()",
    #         "stack()",
    #         "append()",
    #         "merge()"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 308,
    #     "type": "mcq",
    #     "topic": "String Methods",
    #     "difficulty": "medium",
    #     "text": "Quelles fonctions Python permettent de travailler avec les chaines de caracteres ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "len()",
    #         "upper()",
    #         "append()",
    #         "split()",
    #         "extend()",
    #         "pop()"
    #     ],
    #     "correct": [1, 3]
    # },
    # {
    #     "id": 309,
    #     "type": "mcq",
    #     "topic": "Data Visualization",
    #     "difficulty": "medium",
    #     "text": "Quelles methodes Matplotlib permettent de tracer des graphiques ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "plot()",
    #         "scatter()",
    #         "hist()",
    #         "bar()",
    #         "show()",
    #         "display()"
    #     ],
    #     "correct": [0, 1]
    # },

    # {
    #     "id": 51,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle fonction NumPy permet de calculer le produit des éléments d'un tableau ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "multiply()",
    #         "prod()",
    #         "product()",
    #         "times()",
    #         "cumprod()"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 53,
    #     "type": "mcq",
    #     "topic": "Data Structures",
    #     "difficulty": "easy",
    #     "text": "Quelle méthode permet de compter les occurrences d'une valeur dans une liste ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "count()",
    #         "occur()",
    #         "frequency()",
    #         "times()",
    #         "sum()"
    #     ],
    #     "correct": [0]
    # },
    # {
    #     "id": 54,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle fonction NumPy permet de créer un tableau de nombres espacés régulièrement ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "arange()",
    #         "linspace()",
    #         "range()",
    #         "seq()",
    #         "regular()"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 55,
    #     "type": "mcq",
    #     "topic": "Pandas",
    #     "difficulty": "hard",
    #     "text": "Quelles méthodes permettent de manipuler les index d'un DataFrame Pandas ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "reset_index()",
    #         "set_index()",
    #         "reindex()",
    #         "rename_index()",
    #         "drop_index()"
    #     ],
    #     "correct": [0, 1, 2]
    # },
    # {
    #     "id": 56,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelles méthodes NumPy permettent de trier un tableau ?",
    #     "points": 2,
    #     "penalty": 0.5,
    #     "options": [
    #         "sort()",
    #         "argsort()",
    #         "order()",
    #         "sorted()",
    #         "arrange()"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 57,
    #     "type": "mcq",
    #     "topic": "File Handling",
    #     "difficulty": "easy",
    #     "text": "Quelle fonction Python permet de lire le contenu d'un fichier texte ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "open()",
    #         "read()",
    #         "load()",
    #         "import()",
    #         "file()"
    #     ],
    #     "correct": [0]
    # },
    # {
    #     "id": 58,
    #     "type": "yesno",
    #     "topic": "Data Structures",
    #     "difficulty": "medium",
    #     "text": "En Python, les ensembles (sets) maintiennent l'ordre d'insertion des éléments",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": False
    # },
    # {
    #     "id": 59,
    #     "type": "yesno",
    #     "topic": "Functional Programming",
    #     "difficulty": "hard",
    #     "text": "La fonction map() peut être utilisée pour appliquer une fonction à chaque élément d'une liste",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 60,
    #     "type": "yesno",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "NumPy permet d'effectuer des opérations mathématiques sur des tableaux entiers sans boucles explicites",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 62,
    #     "type": "mcq",
    #     "topic": "Python Basics",
    #     "difficulty": "easy",
    #     "text": "Quelle fonction Python permet de vérifier le type d'une variable ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "typeof()",
    #         "type()",
    #         "checktype()",
    #         "var_type()",
    #         "dtype()"
    #     ],
    #     "correct": [1]
    # },
    # {
    #     "id": 64,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle méthode NumPy permet de transposer un tableau ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "transpose()",
    #         "T",
    #         "rotate()",
    #         "flip()",
    #         "swap()"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 65,
    #     "type": "yesno",
    #     "topic": "Pandas",
    #     "difficulty": "medium",
    #     "text": "Les DataFrames Pandas peuvent être fusionnés avec la méthode merge()",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # },
    # {
    #     "id": 66,
    #     "type": "mcq",
    #     "topic": "Data Visualization",
    #     "difficulty": "easy",
    #     "text": "Quelle fonction Matplotlib permet d'enregistrer un graphique dans un fichier ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "save()",
    #         "savefig()",
    #         "export()",
    #         "write()",
    #         "store()"
    #     ],
    #     "correct": [1]
    # },

    # {
    #     "id": 69,
    #     "type": "mcq",
    #     "topic": "NumPy",
    #     "difficulty": "medium",
    #     "text": "Quelle fonction NumPy permet de créer un tableau identité ?",
    #     "points": 1,
    #     "penalty": 0.25,
    #     "options": [
    #         "identity()",
    #         "eye()",
    #         "ones()",
    #         "diag()",
    #         "matrix()"
    #     ],
    #     "correct": [0, 1]
    # },
    # {
    #     "id": 70,
    #     "type": "yesno",
    #     "topic": "Data Structures",
    #     "difficulty": "easy",
    #     "text": "Les listes en Python sont mutables alors que les tuples sont immutables",
    #     "points": 2,
    #     "penalty": 1,
    #     "correct": True
    # }]
    # }
    
    
    loader = ExamLoader(password)
    files_name= 'pratique _exam.quiz'
    loader.encrypt_exam(exam_data, files_name)
    
    print(f"File: {files_name}")
    


if __name__ == "__main__":
    create_sample_exam()