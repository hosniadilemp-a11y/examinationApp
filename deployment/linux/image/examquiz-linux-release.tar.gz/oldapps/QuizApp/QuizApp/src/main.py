"""
Main application entry point
"""

import sys
import os
import random
from importlib import reload
from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtCore import Qt

from PyQt6.QtGui import QFont

# Add src directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui.main_window import MainWindow
from gui.quiz_window import QuizWindow
from gui.results_window import ResultsWindow
from gui.progress_window import ProgressWindow
from gui.coding_window import CodingWindow
from core.quiz_engine import QuizEngine
from core.exam_loader import ExamLoader
from core.training_history import save_training_attempt
from core.progression import PASSING_PERCENTAGE, get_training_questions
from data import questions as builtin_questions
from data.coding_questions import CODING_QUESTIONS


class SecureQuizMaster:
    """Main application controller"""
    
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setApplicationName("SecureQuizMaster")
        self.app.setStyle("Fusion")
        
        # Set high-fidelity global UI typography
        ui_font = QFont()
        ui_font.setFamily("system-ui")
        ui_font.setFamilies(["system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"])
        ui_font.setPointSize(10)
        self.app.setFont(ui_font)
        
        self.main_window = None
        self.quiz_window = None
        self.results_window = None
        self.progress_window = None
        self.coding_window = None
        
        self.quiz_engine = None
        self.user_info = None
        self.exam_data = None
        self.last_training_config = self.load_last_config()
        
        # Load exam loader
        self.exam_loader = ExamLoader("dilo2025")

    def load_last_config(self) -> dict:
        import json
        config_path = os.path.join("results", "last_config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                    if isinstance(config, dict):
                        return config
            except Exception as e:
                print(f"Error loading config: {e}")
        return {}

    def save_last_config(self, config: dict):
        import json
        os.makedirs("results", exist_ok=True)
        config_path = os.path.join("results", "last_config.json")
        try:
            serializable_config = {}
            for k, v in config.items():
                if isinstance(v, set):
                    serializable_config[k] = list(v)
                else:
                    serializable_config[k] = v
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(serializable_config, f, indent=4)
        except Exception as e:
            print(f"Error saving config: {e}")
        
    def start(self):
        """Start the application"""
        from core.session_recovery import load_session
        session = load_session()
        if session:
            self.show_recovery_prompt(session)
        else:
            self.show_main_window()
        sys.exit(self.app.exec())
    
    def show_recovery_prompt(self, session):
        box = QMessageBox()
        box.setWindowTitle("Récupération de Session")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("Une session d'examen active non soumise a été détectée.")
        box.setInformativeText("Souhaitez-vous restaurer votre session et reprendre là où vous vous étiez arrêté ?")
        box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        box.setDefaultButton(QMessageBox.StandardButton.Yes)
        box.setStyleSheet("""
            QMessageBox {
                background-color: white;
            }
            QLabel {
                color: #1e293b;
                font-size: 13px;
                font-weight: 500;
            }
            QPushButton {
                background-color: #2563eb;
                color: white;
                border: 2px solid #1d4ed8;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1d4ed8;
            }
        """)
        
        reply = box.exec()
        if reply == QMessageBox.StandardButton.Yes:
            self.restore_recovered_session(session)
        else:
            from core.session_recovery import clear_session
            clear_session()
            self.show_main_window()

    def restore_recovered_session(self, session):
        self.user_info = session["user_info"]
        session_type = session["session_type"]
        
        if session_type == "quiz":
            self.exam_data = {
                "config": session["exam_config"],
                "questions": session["questions"]
            }
            # Recreate the quiz engine with restored questions
            self.quiz_engine = QuizEngine(
                config=self.exam_data["config"],
                questions=self.exam_data["questions"]
            )
            self.quiz_engine.selected_questions = session["questions"]
            self.quiz_engine.user_answers = session["user_answers"]
            self.quiz_engine.current_question_index = session["current_index"]
            
            # Show quiz window and apply recovered properties
            self.quiz_window = QuizWindow(
                quiz_engine=self.quiz_engine,
                user_info=self.user_info,
                exam_config=self.exam_data["config"]
            )
            self.quiz_window.time_remaining = session["time_remaining"]
            self.quiz_window.flagged_questions = set(session["flagged_questions"])
            self.quiz_window.visited_questions = set(session.get("visited_questions", []))
            
            # Update dots and cells displays
            self.quiz_window.update_navigation_dots()
            self.quiz_window.update_drawer_cells()
            self.quiz_window.update_flag_button_style()
            
            self.quiz_window.exam_submitted.connect(self.on_exam_submitted)
            self.quiz_window.showFullScreen()
            
        elif session_type == "coding":
            questions = session["questions"]
            self._assign_coding_points(questions)
            self.coding_window = CodingWindow(questions, self.user_info)
            self.coding_window.current_index = session["current_index"]
            self.coding_window.time_remaining = session["time_remaining"]
            self.coding_window.flagged_questions = set(session["flagged_questions"])
            self.coding_window.visited_questions = set(session.get("visited_questions", []))
            self.coding_window.code_by_question = session["code_by_question"]
            self.coding_window.submission_results = session["submission_results"]
            self.coding_window.public_results = session["public_results"]
            self.coding_window.hint_state = session.get("hint_state", {})
            
            # Connect finish signals
            self.coding_window.coding_finished.connect(self.on_coding_finished)
            self.coding_window.destroyed.connect(lambda: setattr(self, "coding_window", None))
            
            # Load the current question to populate everything
            self.coding_window.load_question(self.coding_window.current_index)
            self.coding_window.showFullScreen()

    def show_main_window(self):
        """Show the main window with user info form"""
        self.main_window = MainWindow(self.last_training_config)
        self.main_window.exam_started.connect(self.on_exam_started)
        self.main_window.exam_loaded.connect(self.on_exam_loaded)
        self.main_window.progress_requested.connect(self.show_progress_window)
        self.main_window.exit_requested.connect(self.handle_exit)
        self.main_window.showFullScreen()
    
# In the SecureQuizMaster class, update the on_exam_loaded method:
    def on_exam_loaded(self, file_info):
        """Handle exam file loading"""
        file_path = file_info['file_path']
        self.exam_data = self.exam_loader.decrypt_exam(file_path)

        # Update UI with loaded exam info
        config = self.exam_data.get('config', {})
        question_count = len(self.exam_data.get('questions', []))
        
        self.main_window.loaded_exam_data = self.exam_data
        self.main_window.update_exam_info()
        
        # Update max questions based on loaded exam
        if question_count > 0:
            self.main_window.question_count.setMaximum(20)
            self.main_window.question_count.setValue(min(20, self.main_window.question_count.value()))
            
        # Extract and display available difficulties and topics
        if self.exam_data.get('questions'):
            difficulties = set()
            topics = set()
            for q in self.exam_data['questions']:
                if 'difficulty' in q:
                    difficulties.add(q['difficulty'])
                if 'topic' in q:
                    topics.add(q['topic'])
            

    def on_exam_started(self, user_info):
        """Handle exam/training start"""
        reload(builtin_questions)
        self.user_info = user_info
        # Prefill config with user profile info regardless of mode
        if not self.last_training_config:
            self.last_training_config = {}
        self.last_training_config['first_name'] = user_info.get('first_name', '')
        self.last_training_config['last_name'] = user_info.get('last_name', '')
        self.last_training_config['specialty'] = user_info.get('specialty', '')
        
        if user_info.get('mode') == 'training':
            self.last_training_config = user_info.copy()
            
        self.save_last_config(self.last_training_config)

        if user_info.get('mode') == 'training' and user_info.get('assessment_type') == 'practical':
            coding_started = self.show_coding_window(user_info)
            if coding_started and self.main_window:
                self.main_window.close()
            return
        
        if user_info['mode'] == 'training':
            # Use built-in questions for training
            self.exam_data = {
                'config': {
                    "title": "Python Certification Exam",
                    'duration': user_info['duration'],  # 15 minutes for training
                    'points_per_question': 1,
                    'penalty_per_question': 0.25,
                    'max_questions': 20,
                    'passing_score': PASSING_PERCENTAGE,
                    'shuffle_questions': True,
                    'shuffle_options': True,
                    'options_per_question': 4,
                    'exams_filter': False,
                    'topic_filter': user_info.get('selected_topics', []),
                    'difficulty_filter': (
                        user_info.get('selected_difficulties', [])
                        if user_info.get('custom_quiz')
                        else user_info.get('validation_difficulties', [])
                    ),
                    'allowed_topic_difficulty_pairs': user_info.get('allowed_training_pairs', []),
            },
                'questions': get_training_questions(builtin_questions.BASE64_QUESTIONS)
            }
            # Fixed 10 questions for training
            question_count = user_info['question_count']
        else:
            # Use loaded exam data
            self.exam_data = user_info.get('exam_data')
            question_count = user_info.get('nbr_question', user_info.get('question_count', 20))
            if self.exam_data and self.exam_data.get('questions') and self.main_window:
                config = self.exam_data.get('config', {}).copy()
                difficulty_distribution = {
                    "easy": 8,
                    "medium": 7,
                    "hard": 3,
                    "very hard": 2,
                }
                selected_questions = self.main_window.select_official_exam_questions(
                    self.exam_data.get('questions', []),
                    enabled_topics=config.get('topic_filter', []),
                    difficulty_distribution=difficulty_distribution,
                    max_questions=min(20, question_count),
                )
                config['question_count'] = len(selected_questions)
                config['max_questions'] = len(selected_questions)
                self.exam_data = {
                    'config': config,
                    'questions': selected_questions,
                }
                question_count = len(selected_questions)
        
        # Initialize quiz engine
        self.quiz_engine = QuizEngine(
            config=self.exam_data['config'],
            questions=self.exam_data['questions']
        )
        
        # Prepare exam with selected number of questions
        self.quiz_engine.prepare_exam(question_count)
        
        # Show quiz window
        self.show_quiz_window()
    
    def show_quiz_window(self):
        """Show the quiz window"""
        self.quiz_window = QuizWindow(
            quiz_engine=self.quiz_engine,
            user_info=self.user_info,
            exam_config=self.exam_data['config']
        )
        self.quiz_window.exam_submitted.connect(self.on_exam_submitted)
        self.quiz_window.showFullScreen()
    
    def on_exam_submitted(self, results):
        """Handle exam submission"""
        from core.training_history import load_training_history
        from gui.badge_notification import check_and_show_notifications
        # Calculate score
        score_result = self.quiz_engine.calculate_score()

        if self.user_info.get('mode') == 'training':
            history_before = load_training_history()
            save_training_attempt(self.user_info, score_result)
            history_after = load_training_history()
            self.show_results_window(score_result)
            # Show badge/level-up popup if something new was earned
            self._badge_popup = check_and_show_notifications(history_before, history_after)
        else:
            self.theoretical_score_result = score_result
            self.theoretical_engine = self.quiz_engine
            self.show_coding_exam_window(self.user_info)
    
    def show_results_window(self, score_result):
        """Show the results window"""
        self.results_window = ResultsWindow(
            quiz_engine=self.quiz_engine,
            user_info=self.user_info,
            exam_config=self.exam_data['config'],
            score_result=score_result
        )
        # Connect signals
        self.results_window.restart_requested.connect(self.handle_restart)
        self.results_window.exit_requested.connect(self.handle_exit)
        self.results_window.progress_requested.connect(self.show_progress_window)
        self.results_window.showFullScreen()

    def show_fused_results_window(self):
        """Show the fused results window containing both theoretical and practical results"""
        from gui.fused_results_window import FusedResultsWindow
        self.fused_results_window = FusedResultsWindow(
            theoretical_engine=self.theoretical_engine,
            theoretical_score=self.theoretical_score_result,
            coding_engine=self.coding_engine,
            coding_score=self.coding_score_result,
            user_info=self.user_info,
            exam_config=self.exam_data['config']
        )
        self.fused_results_window.restart_requested.connect(self.handle_restart)
        self.fused_results_window.exit_requested.connect(self.handle_exit)
        self.fused_results_window.showFullScreen()

    def show_progress_window(self):
        """Open the dedicated training progress analytics window."""
        self.progress_window = ProgressWindow()
        self.progress_window.revise_topic_requested.connect(self.handle_revise_topic_request)
        self.progress_window.history_cleared.connect(self.on_history_cleared)
        self.progress_window.show()
        self.progress_window.raise_()
        self.progress_window.activateWindow()

    def on_history_cleared(self):
        """Refresh main window after history is wiped from the progress window."""
        if self.main_window:
            self.main_window.refresh_training_progression_controls()
            self.main_window.update_user_level_summary()
            self.main_window.update_test_info()


    def handle_revise_topic_request(self, topic_name):
        if hasattr(self, "progress_window") and self.progress_window:
            self.progress_window.close()
        if hasattr(self, "results_window") and self.results_window:
            self.results_window.close()
        if hasattr(self, "fused_results_window") and self.fused_results_window:
            self.fused_results_window.close()
        if hasattr(self, "main_window") and self.main_window:
            self.main_window.showFullScreen()
            self.main_window.raise_()
            self.main_window.activateWindow()
            self.main_window.preselect_topic(topic_name)

    def _assign_coding_points(self, questions):
        for q in questions:
            d = q.get("difficulty", "easy").lower()
            if d == "easy": q["points"] = 2.0
            elif d == "medium": q["points"] = 3.0
            elif d == "hard": q["points"] = 4.0
            elif d == "very hard": q["points"] = 5.0
            else: q["points"] = 2.0

    def show_coding_window(self, user_info=None):
        """Open the prototype coding question lab."""
        topics = set((user_info or {}).get("selected_topics", []))
        difficulties = set((user_info or {}).get("selected_difficulties", []))
        selected = [
            question for question in CODING_QUESTIONS
            if (not topics or question.get("topic") in topics)
            and (not difficulties or question.get("difficulty") in difficulties)
        ]
        question_count = (user_info or {}).get("question_count", len(selected))
        if not selected:
            QMessageBox.warning(
                self.main_window,
                "No Coding Questions",
                "No coding questions are available for the selected filters.",
            )
            return False

        random.shuffle(selected)
        selected = selected[:question_count]
        self._assign_coding_points(selected)
        if self.coding_window is None:
            self.coding_window = CodingWindow(selected, user_info or {})
            self.coding_window.coding_finished.connect(self.on_coding_finished)
            self.coding_window.destroyed.connect(lambda: setattr(self, "coding_window", None))
        self.coding_window.showFullScreen()
        self.coding_window.raise_()
        self.coding_window.activateWindow()
        return True

    def show_coding_exam_window(self, user_info=None):
        """Open the official coding exam window."""
        topics = set((user_info or {}).get("selected_topics", []))
        if not topics and self.exam_data and 'config' in self.exam_data:
            topics = set(self.exam_data['config'].get('topic_filter', []))
            
        exam_questions = CODING_QUESTIONS
        topic_questions = [q for q in exam_questions if q.get("topic") in topics]
        
        def get_by_diff(pool, diffs):
            return [q for q in pool if q.get("difficulty", "").lower() in diffs]
            
        easy = get_by_diff(topic_questions, ["easy"])
        medium = get_by_diff(topic_questions, ["medium"])
        hard = get_by_diff(topic_questions, ["hard", "very hard"])
        
        if len(easy) < 4:
            easy += [q for q in get_by_diff(exam_questions, ["easy"]) if q not in easy]
        if len(medium) < 2:
            medium += [q for q in get_by_diff(exam_questions, ["medium"]) if q not in medium]
        if len(hard) < 1:
            hard += [q for q in get_by_diff(exam_questions, ["hard", "very hard"]) if q not in hard]
            
        random.shuffle(easy)
        random.shuffle(medium)
        random.shuffle(hard)
        
        selected = easy[:4] + medium[:2] + hard[:1]
        random.shuffle(selected)
        
        if not selected:
            QMessageBox.warning(
                self.main_window,
                "No Coding Questions",
                "No exam coding questions are available.",
            )
            return False

        if self.coding_window is None:
            self.coding_window = CodingWindow(selected, user_info or {})
            self.coding_window.coding_finished.connect(self.on_coding_finished)
            self.coding_window.destroyed.connect(lambda: setattr(self, "coding_window", None))
        self.coding_window.showFullScreen()
        self.coding_window.raise_()
        self.coding_window.activateWindow()
        return True

    def on_coding_finished(self, questions, submission_results):
        """Handle completion of coding training and display custom results."""
        from core.training_history import save_training_attempt
        def get_points(difficulty):
            d = difficulty.lower()
            if d == "easy": return 2.0
            if d == "medium": return 3.0
            if d == "hard": return 4.0
            if d == "very hard": return 5.0
            return 2.0
            
        sum_max_pts = sum(get_points(q.get("difficulty", "easy")) for q in questions)
        
        score_details = []
        earned_total = 0.0
        correct_count = 0
        wrong_count = 0
        partial_count = 0
        unanswered_count = 0
        topic_analysis = {}
        
        for q in questions:
            q_id = q["id"]
            max_pts = get_points(q.get("difficulty", "easy"))
            q["points"] = max_pts
            
            if q_id in submission_results:
                hidden = submission_results[q_id].get("hidden_result", {})
                passed = hidden.get("passed", 0)
                total = hidden.get("total", 0)
                hints_used = submission_results[q_id].get("hints_used", 0)
                
                hint_multiplier = 1.0
                if hints_used == 1:
                    hint_multiplier = 0.5
                elif hints_used >= 2:
                    hint_multiplier = 0.0
                
                if total > 0:
                    earned = (passed / total) * max_pts * hint_multiplier
                    if passed == total:
                        status = "correct"
                        correct_count += 1
                    elif passed > 0:
                        status = "partial"
                        partial_count += 1
                    else:
                        status = "incorrect"
                        wrong_count += 1
                else:
                    earned = 0.0
                    status = "incorrect"
                    wrong_count += 1
            else:
                earned = 0.0
                status = "unanswered"
                unanswered_count += 1
                
            earned_total += earned
            topic = q.get("topic", "Practical")
            topic_stats = topic_analysis.setdefault(
                topic,
                {"earned": 0.0, "max": 0.0, "correct": 0, "total": 0},
            )
            topic_stats["earned"] += earned
            topic_stats["max"] += max_pts
            topic_stats["total"] += 1
            if status == "correct":
                topic_stats["correct"] += 1

            score_details.append({
                "id": q_id,
                "status": status,
                "points": earned,
                "penalty": 0.0,
                "passed_tests": passed if q_id in submission_results else 0,
                "total_tests": total if q_id in submission_results else 0,
                "hints_used": hints_used if q_id in submission_results else 0,
                "hidden_result": hidden if q_id in submission_results else {},
                "code": submission_results[q_id].get("code", "") if q_id in submission_results else "",
            })
            
        final_mark_out_of_20 = (earned_total / sum_max_pts * 20.0) if sum_max_pts > 0 else 0.0
            
        score_result = {
            "percentage": (earned_total / sum_max_pts) * 100.0 if sum_max_pts > 0 else 0.0,
            "final_mark": final_mark_out_of_20,
            "total_points": earned_total,
            "max_points": sum_max_pts,
            "total_questions": len(questions),
            "correct_count": correct_count,
            "wrong_count": wrong_count,
            "unanswered_count": unanswered_count,
            "partial_count": partial_count,
            "submitted_count": correct_count + wrong_count + partial_count,
            "topic_analysis": {
                topic: {
                    "percentage": round((stats["earned"] / stats["max"]) * 100, 2)
                    if stats["max"] else 0,
                    "correct": stats["correct"],
                    "total": stats["total"],
                }
                for topic, stats in topic_analysis.items()
            },
            "details": {d['id']: d for d in score_details}
        }
        
        class DummyQuizEngine:
            def __init__(self, selected_questions, details):
                self.selected_questions = selected_questions
                self.score_details = details
                
        self.quiz_engine = DummyQuizEngine(questions, score_details)
        if not self.exam_data:
            self.exam_data = {"config": self.last_training_config or {}}
            
        if self.user_info and self.user_info.get("mode") == "training":
            from core.training_history import load_training_history
            from gui.badge_notification import check_and_show_notifications
            history_before = load_training_history()
            save_training_attempt(self.user_info, score_result)
            history_after = load_training_history()
            self.show_results_window(score_result)
            self._badge_popup = check_and_show_notifications(history_before, history_after)
        else:
            self.coding_score_result = score_result
            self.coding_engine = self.quiz_engine
            from gui.fused_results_window import FusedResultsWindow
            self.show_fused_results_window()

    def handle_restart(self):
        """Handle restart request from results window"""
       
        if self.results_window:
            self.results_window.close()
        if hasattr(self, 'fused_results_window') and self.fused_results_window:
            self.fused_results_window.close()
            self.fused_results_window = None
        if self.progress_window:
            self.progress_window.close()
            self.results_window = None
        if self.coding_window:
            self.coding_window.coding_finished_flag = True
            self.coding_window.close()
            self.coding_window = None
        
        # Clear current data
        self.quiz_engine = None
        if self.user_info and self.user_info.get('mode') == 'training':
            self.last_training_config = self.user_info.copy()
            self.save_last_config(self.last_training_config)
        self.user_info = None
        self.exam_data = None

        # Show main window to start over
        self.show_main_window()
    
    def handle_exit(self):
        """Handle exit request from results window"""
        # Close all windows
        if self.main_window:
            self.main_window.close()
        if self.quiz_window:
            self.quiz_window.close()
        if self.results_window:
            self.results_window.close()
        if hasattr(self, 'fused_results_window') and self.fused_results_window:
            self.fused_results_window.close()
        if self.coding_window:
            self.coding_window.coding_finished_flag = True
            self.coding_window.close()
        
        # Quit application
        self.app.quit()

def main():
    """Application entry point"""
    # Set high DPI scaling for better display
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    
    # Create and start application
    app = SecureQuizMaster()
    app.start()


if __name__ == "__main__":
    main()
