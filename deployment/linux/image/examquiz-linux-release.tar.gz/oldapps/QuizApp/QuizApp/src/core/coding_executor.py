"""Run prototype coding-question submissions against public or hidden tests."""

from __future__ import annotations

import base64
import subprocess
import sys
from typing import Any, Dict, List


RUNNER = r"""
import base64
import builtins
import sys

code = base64.b64decode(sys.argv[1]).decode("utf-8")

def blocked_import(name, globals=None, locals=None, fromlist=(), level=0):
    frame = sys._getframe()
    is_user_code = False
    while frame:
        if frame.f_code.co_filename == "<user_code>":
            is_user_code = True
            break
        frame = frame.f_back
        
    if is_user_code:
        allowed = ["math", "datetime", "collections", "itertools", "pandas", "numpy", "matplotlib", "matplotlib.pyplot", "seaborn", "io"]
        root_name = name.split('.')[0]
        if root_name not in allowed:
            raise ImportError(f"Importing '{name}' is disabled in this coding sandbox.")
    return builtins.__import__(name, globals, locals, fromlist, level)

def blocked_open(file, mode='r', *args, **kwargs):
    frame = sys._getframe()
    is_user_code = False
    while frame:
        if frame.f_code.co_filename == "<user_code>":
            is_user_code = True
            break
        frame = frame.f_back
        
    if is_user_code:
        import os
        filename = os.path.basename(str(file))
        if filename.endswith('.csv') or filename.endswith('.png') or filename.endswith('.txt') or 'r' in mode:
            return builtins.open(file, mode, *args, **kwargs)
        raise PermissionError("File access is disabled or restricted in this coding sandbox.")
    return builtins.open(file, mode, *args, **kwargs)

try:
    import matplotlib
    matplotlib.use('Agg')
except:
    pass

allowed_names = [
    "abs", "all", "any", "bool", "chr", "dict", "divmod", "enumerate",
    "filter", "float", "format", "int", "isinstance", "len", "list", "map",
    "max", "min", "ord", "pow", "print", "range", "reversed", "round",
    "set", "slice", "sorted", "str", "sum", "tuple", "zip",
    "Exception", "ValueError", "TypeError", "IndexError", "KeyError",
    "__build_class__", "type", "repr", "super", "object", "property",
    "classmethod", "staticmethod", "issubclass", "getattr", "setattr", "hasattr",
    "callable",
]
safe_builtins = {name: getattr(builtins, name) for name in allowed_names}
safe_builtins["input"] = input
safe_builtins["open"] = blocked_open
safe_builtins["__import__"] = blocked_import

globals_dict = {
    "__builtins__": safe_builtins,
    "__name__": "__main__",
}

exec(compile(code, "<user_code>", "exec"), globals_dict, globals_dict)
"""


def normalize_output(value: str) -> str:
    """Normalize line endings and trailing whitespace for judge comparison."""
    lines = value.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    return "\n".join(line.rstrip() for line in lines).strip()


def run_code(code: str, input_data: str, timeout_ms: int) -> Dict[str, Any]:
    """Run user code once and return output, error, and timeout state."""
    import os
    import shutil

    # Copy sample CSV files to the current working directory if missing
    script_dir = os.path.dirname(os.path.abspath(__file__))
    sample_data_dir = os.path.abspath(os.path.join(script_dir, "..", "data", "sample_data"))
    
    csv_files = ["data.csv", "bonus.csv", "sales.csv", "users.csv"]
    for csv_file in csv_files:
        dest_path = os.path.join(os.getcwd(), csv_file)
        if not os.path.exists(dest_path):
            src_path = os.path.join(sample_data_dir, csv_file)
            if os.path.exists(src_path):
                try:
                    shutil.copy2(src_path, dest_path)
                except Exception as e:
                    print(f"Error copying sample CSV: {e}", file=sys.stderr)

    encoded_code = base64.b64encode(code.encode("utf-8")).decode("ascii")
    timeout_seconds = max(timeout_ms, 1) / 1000

    try:
        completed = subprocess.run(
            [sys.executable, "-I", "-c", RUNNER, encoded_code],
            input=input_data,
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {
            "status": "timeout",
            "output": "",
            "error": f"Timed out after {timeout_ms} ms",
        }

    status = "passed" if completed.returncode == 0 else "runtime_error"
    return {
        "status": status,
        "output": completed.stdout,
        "error": completed.stderr.strip(),
    }


def run_tests(question: Dict[str, Any], code: str, test_group: str) -> Dict[str, Any]:
    """Run code against a question's public_tests or hidden_tests."""
    tests: List[Dict[str, str]] = question.get(test_group, [])
    timeout_ms = question.get("execution_settings", {}).get("timeout_ms", 2000)
    details = []
    passed = 0

    for index, test in enumerate(tests, start=1):
        run_result = run_code(code, test.get("input", ""), timeout_ms)
        expected = normalize_output(test.get("output", ""))
        actual = normalize_output(run_result.get("output", ""))
        test_passed = run_result["status"] == "passed" and actual == expected
        if test_passed:
            passed += 1

        detail = {
            "case": index,
            "passed": test_passed,
            "status": run_result["status"],
            "expected": expected,
            "output": actual,
            "error": run_result.get("error", ""),
        }
        if test_group == "public_tests":
            detail["input"] = test.get("input", "")
        details.append(detail)

    total = len(tests)
    max_points = question.get("points", 0)
    score = (passed / total) * max_points if total else 0

    return {
        "passed": passed,
        "total": total,
        "failed": total - passed,
        "percentage": round((passed / total) * 100, 2) if total else 0,
        "score": round(score, 2),
        "max_points": max_points,
        "details": details,
    }


def evaluate_submission(question: Dict[str, Any], code: str) -> Dict[str, Any]:
    """Run public and hidden tests, returning the submission JSON shape."""
    public_result = run_tests(question, code, "public_tests")
    hidden_result = run_tests(question, code, "hidden_tests")
    return {
        "status": "completed",
        "public_result": {
            "passed": public_result["passed"],
            "total": public_result["total"],
            "failed": public_result["failed"],
            "percentage": public_result["percentage"],
        },
        "hidden_result": {
            "passed": hidden_result["passed"],
            "total": hidden_result["total"],
            "failed": hidden_result["failed"],
            "percentage": hidden_result["percentage"],
        },
        "score": hidden_result["score"],
        "max_points": hidden_result["max_points"],
        "code": code,
    }
