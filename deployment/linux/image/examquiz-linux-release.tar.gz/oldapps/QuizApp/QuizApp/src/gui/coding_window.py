"""Coding quiz window with public-test practice and hidden-test grading."""

import datetime
import keyword
import ast

from PyQt6.QtCore import QEvent, QRegularExpression, Qt, QTimer, pyqtSignal, QSize
from PyQt6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QKeySequence,
    QSyntaxHighlighter,
    QTextCharFormat,
    QTextCursor,
    QPainter,
    QShortcut,
)
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
    QTextEdit,
)

from core.coding_executor import evaluate_submission, run_code, run_tests
from data.coding_questions import CODING_QUESTIONS


class PythonHighlighter(QSyntaxHighlighter):
    """Small Python syntax highlighter for the built-in coding editor."""

    def __init__(self, document):
        super().__init__(document)
        self.rules = []

        keyword_format = self.make_format("#2563eb", bold=True)
        for word in keyword.kwlist:
            self.rules.append((QRegularExpression(rf"\b{word}\b"), keyword_format))

        builtin_format = self.make_format("#7c3aed")
        for word in ("print", "input", "range", "len", "int", "str", "float", "list",
                     "dict", "set", "tuple", "sum", "min", "max", "sorted", "enumerate"):
            self.rules.append((QRegularExpression(rf"\b{word}\b"), builtin_format))

        self.rules.extend([
            (QRegularExpression(r"#.*"), self.make_format("#64748b", italic=True)),
            (QRegularExpression(r"\b[0-9]+(\.[0-9]+)?\b"), self.make_format("#d97706")),
            (QRegularExpression(r"\b[A-Za-z_][A-Za-z0-9_]*(?=\()"), self.make_format("#0d9488", bold=True)),
            (QRegularExpression(r'"[^"\\]*(\\.[^"\\]*)*"'), self.make_format("#16a34a")),
            (QRegularExpression(r"'[^'\\]*(\\.[^'\\]*)*'"), self.make_format("#16a34a")),
        ])

    def make_format(self, color, bold=False, italic=False):
        text_format = QTextCharFormat()
        text_format.setForeground(QColor(color))
        if bold:
            text_format.setFontWeight(QFont.Weight.Bold)
        if italic:
            text_format.setFontItalic(True)
        return text_format

    def highlightBlock(self, text):
        for pattern, text_format in self.rules:
            match_iterator = pattern.globalMatch(text)
            while match_iterator.hasNext():
                match = match_iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), text_format)


class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.code_editor = editor

    def sizeHint(self):
        return QSize(self.code_editor.lineNumberAreaWidth(), 0)

    def paintEvent(self, event):
        self.code_editor.lineNumberAreaPaintEvent(event)


class CodeEditor(QPlainTextEdit):
    """Python editor with indentation helpers, line numbers, bracket matching, and clipboard blocking."""
    outline_changed = pyqtSignal(list)

    def __init__(self):
        super().__init__()
        editor_font = QFont("Consolas", 11)
        editor_font.setFamilies(["Consolas", "Fira Code", "DejaVu Sans Mono", "Courier New", "monospace"])
        self.setFont(editor_font)
        self.setTabStopDistance(32)
        self.highlighter = PythonHighlighter(self.document())
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        
        # Line Number Area initialization
        self.lineNumberArea = LineNumberArea(self)
        self.blockCountChanged.connect(self.updateLineNumberAreaWidth)
        self.updateRequest.connect(self.updateLineNumberArea)
        self.updateLineNumberAreaWidth(0)

        # Debounced syntax linter
        self.linter_timer = QTimer(self)
        self.linter_timer.setSingleShot(True)
        self.linter_timer.setInterval(1000)
        self.linter_timer.timeout.connect(self.run_linter)
        self.textChanged.connect(self.reset_linter_timer)

    def reset_linter_timer(self):
        self.linter_timer.start()

    def run_linter(self):
        self.linter_timer.stop()
        code = self.toPlainText()
        
        # 1. Parse outline and emit
        outline = self.parse_outline(code)
        self.outline_changed.emit(outline)
        
        # 2. Run ast syntax check
        try:
            ast.parse(code)
            self.clear_linter_errors()
        except SyntaxError as e:
            self.show_linter_error(e)
        except Exception:
            pass

    def clear_linter_errors(self):
        self.setExtraSelections([])

    def show_linter_error(self, e):
        lineno = e.lineno
        offset = e.offset
        
        if lineno is None:
            return
            
        doc = self.document()
        block = doc.findBlockByLineNumber(lineno - 1)
        if not block.isValid():
            return
            
        cursor = QTextCursor(block)
        line_text = block.text()
        line_start = block.position()
        
        if offset is not None and offset > 0 and offset <= len(line_text):
            start_pos = line_start + offset - 1
            end_pos = start_pos
            while end_pos < line_start + len(line_text) and line_text[end_pos - line_start].isalnum():
                end_pos += 1
            if end_pos == start_pos:
                end_pos = min(line_start + len(line_text), start_pos + 1)
        else:
            start_pos = line_start
            end_pos = line_start + len(line_text)
            if start_pos == end_pos:
                end_pos = min(doc.characterCount() - 1, start_pos + 1)
                
        cursor.setPosition(start_pos)
        cursor.setPosition(end_pos, QTextCursor.MoveMode.KeepAnchor)
        
        selection = QTextEdit.ExtraSelection()
        selection.cursor = cursor
        
        char_format = QTextCharFormat()
        char_format.setUnderlineColor(QColor("#ef4444"))
        char_format.setUnderlineStyle(QTextCharFormat.UnderlineStyle.SpellCheckUnderline)
        selection.format = char_format
        
        self.setExtraSelections([selection])

    def parse_outline(self, code):
        outline = []
        lines = code.split('\n')
        for idx, line in enumerate(lines):
            stripped = line.lstrip()
            indent = len(line) - len(stripped)
            if stripped.startswith("def ") or stripped.startswith("class "):
                parts = stripped.split(maxsplit=1)
                if len(parts) < 2:
                    continue
                name_part = parts[1]
                if "(" in name_part:
                    name = name_part.split("(", 1)[0].strip()
                elif ":" in name_part:
                    name = name_part.split(":", 1)[0].strip()
                else:
                    name = name_part.strip()
                
                is_class = stripped.startswith("class ")
                if is_class and "(" in name_part:
                    name = name_part.split("(", 1)[0].strip()
                
                outline.append({
                    "name": name,
                    "line": idx + 1,
                    "is_class": is_class,
                    "indent": indent
                })
        return outline

    def lineNumberAreaWidth(self):
        digits = 1
        max_num = max(1, self.blockCount())
        while max_num >= 10:
            max_num //= 10
            digits += 1
        space = 24 + self.fontMetrics().horizontalAdvance('9') * digits
        return space

    def updateLineNumberAreaWidth(self, _):
        self.setViewportMargins(self.lineNumberAreaWidth(), 0, 0, 0)

    def updateLineNumberArea(self, rect, dy):
        if dy:
            self.lineNumberArea.scroll(0, dy)
        else:
            self.lineNumberArea.update(0, rect.y(), self.lineNumberArea.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.updateLineNumberAreaWidth(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.lineNumberArea.setGeometry(
            cr.left(), cr.top(), self.lineNumberAreaWidth(), cr.height()
        )

    def lineNumberAreaPaintEvent(self, event):
        painter = QPainter(self.lineNumberArea)
        painter.fillRect(event.rect(), QColor("#f1f5f9"))  # Soft slate sidebar
        
        # Draw border dividing numbers and code
        painter.setPen(QColor("#cbd5e1"))
        painter.drawLine(event.rect().width() - 1, event.rect().top(), 
                         event.rect().width() - 1, event.rect().bottom())

        block = self.firstVisibleBlock()
        blockNumber = block.blockNumber()
        top = int(self.blockBoundingGeometry(block).translated(self.contentOffset()).y())
        bottom = top + int(self.blockBoundingRect(block).height())

        painter.setPen(QColor("#64748b"))  # Slate number color
        font = self.font()
        font.setBold(False)
        painter.setFont(font)

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(blockNumber + 1)
                width = self.lineNumberAreaWidth() - 12
                painter.drawText(0, top, width, self.fontMetrics().height(),
                                 Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, number)
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
            blockNumber += 1

    def cut(self):
        if getattr(self, "test_mode", False):
            super().cut()
        else:
            return

    def copy(self):
        if getattr(self, "test_mode", False):
            super().copy()
        else:
            return

    def paste(self):
        if getattr(self, "test_mode", False):
            super().paste()
        else:
            return

    def insertFromMimeData(self, source):
        if getattr(self, "test_mode", False):
            super().insertFromMimeData(source)
        else:
            return

    def canInsertFromMimeData(self, source):
        if getattr(self, "test_mode", False):
            return super().canInsertFromMimeData(source)
        return False

    def selected_line_bounds(self):
        cursor = self.textCursor()
        start = cursor.selectionStart()
        end = cursor.selectionEnd()
        cursor.setPosition(start)
        cursor.movePosition(QTextCursor.MoveOperation.StartOfLine)
        start = cursor.position()
        cursor.setPosition(end)
        if cursor.positionInBlock() == 0 and end != start:
            cursor.movePosition(QTextCursor.MoveOperation.PreviousBlock)
        cursor.movePosition(QTextCursor.MoveOperation.EndOfLine)
        end = cursor.position()
        return start, end

    def transform_selected_lines(self, transform):
        cursor = self.textCursor()
        start, end = self.selected_line_bounds()
        cursor.beginEditBlock()
        cursor.setPosition(start)
        cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
        selected_text = cursor.selectedText().replace("\u2029", "\n")
        transformed = "\n".join(transform(line) for line in selected_text.split("\n"))
        cursor.insertText(transformed)
        cursor.endEditBlock()

    def indent_selection(self):
        self.transform_selected_lines(lambda line: "    " + line)

    def outdent_selection(self):
        def outdent(line):
            return line[4:] if line.startswith("    ") else line[1:] if line.startswith("\t") else line
        self.transform_selected_lines(outdent)

    def toggle_comment(self):
        cursor = self.textCursor()
        start, end = self.selected_line_bounds()
        cursor.setPosition(start)
        lines = []
        while True:
            cursor.movePosition(QTextCursor.MoveOperation.EndOfLine, QTextCursor.MoveMode.KeepAnchor)
            lines.append(cursor.selectedText())
            if cursor.position() >= end:
                break
            cursor.movePosition(QTextCursor.MoveOperation.NextBlock)
        should_uncomment = all(line.lstrip().startswith("#") for line in lines if line.strip())

        def transform(line):
            if not line.strip():
                return line
            if should_uncomment:
                index = line.find("#")
                return line[:index] + line[index + 1:].lstrip(" ")
            indent = len(line) - len(line.lstrip(" "))
            return line[:indent] + "# " + line[indent:]

        self.transform_selected_lines(transform)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.StandardKey.Undo):
            self.undo()
            return
        if event.matches(QKeySequence.StandardKey.Redo):
            self.redo()
            return
        if not getattr(self, "test_mode", False):
            if (
                event.matches(QKeySequence.StandardKey.Cut)
                or event.matches(QKeySequence.StandardKey.Copy)
                or event.matches(QKeySequence.StandardKey.Paste)
            ):
                event.accept()
                return

        if event.key() == Qt.Key.Key_Tab:
            if self.textCursor().hasSelection():
                self.indent_selection()
            else:
                self.insertPlainText("    ")
            return

        if event.key() == Qt.Key.Key_Backtab:
            self.outdent_selection()
            return

        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            cursor = self.textCursor()
            block_text = cursor.block().text()
            indent = block_text[:len(block_text) - len(block_text.lstrip(" "))]
            if block_text.rstrip().endswith(":"):
                indent += "    "
            self.insertPlainText("\n" + indent)
            return

        # Handle Backspace for empty bracket pairs
        if event.key() == Qt.Key.Key_Backspace:
            cursor = self.textCursor()
            if not cursor.hasSelection() and cursor.position() > 0:
                cursor.movePosition(QTextCursor.MoveOperation.Left, QTextCursor.MoveMode.KeepAnchor)
                left_char = cursor.selectedText()
                cursor.movePosition(QTextCursor.MoveOperation.Right)
                cursor.movePosition(QTextCursor.MoveOperation.Right, QTextCursor.MoveMode.KeepAnchor)
                right_char = cursor.selectedText()
                cursor.movePosition(QTextCursor.MoveOperation.Left)
                
                pairs = {
                    "(": ")",
                    "[": "]",
                    "{": "}",
                    '"': '"',
                    "'": "'",
                }
                if left_char in pairs and right_char == pairs[left_char]:
                    cursor.deletePreviousChar()
                    cursor.deleteChar()
                    self.setTextCursor(cursor)
                    return

        pairs = {
            "(": ")",
            "[": "]",
            "{": "}",
            '"': '"',
            "'": "'",
        }
        text = event.text()
        
        # If user types a closing bracket, and the cursor is right before that same closing bracket,
        # just move the cursor right instead of inserting a duplicate!
        if text in (")", "]", "}", '"', "'"):
            cursor = self.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.Right, QTextCursor.MoveMode.KeepAnchor)
            next_char = cursor.selectedText()
            cursor.movePosition(QTextCursor.MoveOperation.Left)
            
            if next_char == text:
                cursor.movePosition(QTextCursor.MoveOperation.Right)
                self.setTextCursor(cursor)
                return
                
        if text in pairs and not self.textCursor().hasSelection():
            cursor = self.textCursor()
            cursor.insertText(text + pairs[text])
            cursor.movePosition(QTextCursor.MoveOperation.Left)
            self.setTextCursor(cursor)
            return

        super().keyPressEvent(event)


class NoClipboardPlainTextEdit(QPlainTextEdit):
    """Plain text input that blocks clipboard operations during secure coding."""

    def __init__(self):
        super().__init__()
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)

    def cut(self):
        if getattr(self, "test_mode", False):
            super().cut()
        else:
            return

    def copy(self):
        if getattr(self, "test_mode", False):
            super().copy()
        else:
            return

    def paste(self):
        if getattr(self, "test_mode", False):
            super().paste()
        else:
            return

    def insertFromMimeData(self, source):
        if getattr(self, "test_mode", False):
            super().insertFromMimeData(source)
        else:
            return

    def canInsertFromMimeData(self, source):
        if getattr(self, "test_mode", False):
            return super().canInsertFromMimeData(source)
        return False

    def keyPressEvent(self, event):
        if not getattr(self, "test_mode", False):
            if (
                event.matches(QKeySequence.StandardKey.Cut)
                or event.matches(QKeySequence.StandardKey.Copy)
                or event.matches(QKeySequence.StandardKey.Paste)
            ):
                event.accept()
                return
        super().keyPressEvent(event)


class TestResultCard(QFrame):
    """Expandable public-test result card."""

    def __init__(self, detail):
        super().__init__()
        self.detail = detail
        self.expanded = not detail["passed"]
        self.setObjectName("testCard")

        color = "#059669" if detail["passed"] else "#dc2626"
        bg = "#ecfdf5" if detail["passed"] else "#fef2f2"
        border = "#86efac" if detail["passed"] else "#fecaca"
        status = "PASSED" if detail["passed"] else "FAILED"

        self.setStyleSheet(f"""
            QFrame#testCard {{
                background: {bg};
                border: 1px solid {border};
                border-radius: 8px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        self.header_button = QPushButton(f"Test {detail['case']}  {status}")
        self.header_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.header_button.setMinimumHeight(34)
        self.header_button.clicked.connect(self.toggle_details)
        self.header_button.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {color};
                border: none;
                text-align: left;
                font-size: 13px;
                font-weight: 900;
                padding: 4px;
            }}
        """)
        layout.addWidget(self.header_button)

        self.detail_widget = QLabel(self.format_detail())
        self.detail_widget.setWordWrap(True)
        self.detail_widget.setVisible(self.expanded)
        self.detail_widget.setStyleSheet("""
            QLabel {
                background: #ffffff;
                color: #0f172a;
                border: 1px solid #e2e8f0;
                border-radius: 6px;
                padding: 10px;
                font-family: Consolas, "Fira Code", "DejaVu Sans Mono", "Courier New", monospace;
                font-size: 12px;
            }
        """)
        layout.addWidget(self.detail_widget)

    def format_detail(self):
        parts = [
            "Input:",
            self.detail.get("input", "") or "(empty input)",
            "",
            "Expected output:",
            self.detail.get("expected", "") or "(no output)",
            "",
            "Your output:",
            self.detail.get("output", "") or "(no output)",
        ]
        if self.detail.get("error"):
            parts.extend(["", "Error:", self.detail["error"]])
        return "\n".join(parts)

    def toggle_details(self):
        self.expanded = not self.expanded
        self.detail_widget.setVisible(self.expanded)


class CodingWindow(QMainWindow):
    """Coding quiz experience that mirrors the main quiz navigation pattern."""

    coding_finished = pyqtSignal(list, dict)

    def __init__(self, questions=None, user_info=None):
        super().__init__()
        self.questions = questions or CODING_QUESTIONS
        self.user_info = user_info or {}
        self.current_index = 0
        self.nav_dot_buttons = []
        self.visited_questions = set()
        self.flagged_questions = set()
        self.drawer_buttons = []
        self.code_by_question = {}
        self.loaded_question_id = None
        self.public_results = {}
        self.submission_results = {}
        self.coding_finished_flag = False
        self.warning_count = 0
        self.max_warnings = 3
        self.security_events = []
        self.last_security_warning_at = None
        self.security_paused = False
        self.security_ready_at = None
        self.security_timer = QTimer()
        self.security_status_label = None
        self.hint_state = {}
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        # Timer setup
        self.time_limit = (self.user_info or {}).get("duration", 60) * 60
        self.time_remaining = self.time_limit
        self.warnings_given = set()
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.timer.start(1000)

        self.init_ui()
        self.load_question(0)
        if not (self.user_info or {}).get("test_mode"):
            self.start_security_monitoring()

    def init_ui(self):
        self.setWindowTitle("SecureQuizMaster - Coding Quiz")
        if (self.user_info or {}).get("test_mode"):
            self.setWindowFlags(Qt.WindowType.Window)
            self.resize(1600, 1000)
            self.showNormal()
        else:
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
            self.showFullScreen()
        self.setMinimumSize(1280, 800)

        central_widget = QWidget()
        central_widget.setObjectName("centralWidget")
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(14, 12, 14, 12)
        main_layout.setSpacing(10)

        header_frame = QFrame()
        header_frame.setObjectName("headerFrame")
        header_frame.setMinimumHeight(72)
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(16, 8, 16, 8)
        header_layout.setSpacing(12)

        # Menu toggle button
        self.menu_button = QPushButton("☰ Questions")
        self.menu_button.setMinimumSize(110, 36)
        self.menu_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.menu_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.menu_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.2);
                color: white;
                border: 1px solid rgba(255, 255, 255, 0.4);
                border-radius: 6px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.35);
            }
        """)
        self.menu_button.clicked.connect(self.toggle_drawer)
        header_layout.addWidget(self.menu_button)

        title_box = QVBoxLayout()
        self.window_title = QLabel("Python Coding Quiz")
        self.window_title.setStyleSheet("font-size: 18px; color: white; font-weight: 900;")
        title_box.addWidget(self.window_title)
        self.question_title_label = QLabel()
        self.question_title_label.setStyleSheet("font-size: 13px; color: #e0f2fe; font-weight: 700;")
        title_box.addWidget(self.question_title_label)
        header_layout.addLayout(title_box, 1)

        self.security_status_label = QLabel("SECURE MODE")
        self.security_status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.security_status_label.setMinimumWidth(170)
        self.security_status_label.setStyleSheet("""
            QLabel {
                color: white;
                background: rgba(15, 118, 110, 0.34);
                border: 1px solid rgba(255, 255, 255, 0.35);
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 12px;
                font-weight: 900;
            }
        """)
        header_layout.addWidget(self.security_status_label)

        self.score_label = QLabel("Score: 0/0")
        self.score_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.score_label.setMinimumWidth(160)
        self.score_label.setStyleSheet("""
            QLabel {
                color: white;
                background: rgba(15, 23, 42, 0.28);
                border: 1px solid rgba(255, 255, 255, 0.32);
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 12px;
                font-weight: 900;
            }
        """)
        header_layout.addWidget(self.score_label)

        # Timer widget
        timer_container = QWidget()
        timer_container.setMinimumWidth(104)
        timer_layout = QVBoxLayout(timer_container)
        timer_layout.setContentsMargins(0, 0, 0, 5)
        timer_layout.setSpacing(3)
        
        timer_title = QLabel("TIME REMAINING")
        timer_title.setStyleSheet("font-size: 9px; color: white; font-weight: bold; letter-spacing: 1px;")
        timer_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        timer_layout.addWidget(timer_title)
        
        self.timer_label = QLabel()
        self.timer_label.setObjectName("timerLabel")
        self.update_timer_display()
        self.timer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.timer_label.setMinimumWidth(96)
        timer_layout.addWidget(self.timer_label)
        
        header_layout.addWidget(timer_container)

        main_layout.addWidget(header_frame)

        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimumHeight(18)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                border-radius: 5px;
                background-color: #e2e8f0;
                text-align: center;
                font-size: 11px;
                color: #0f172a;
            }
            QProgressBar::chunk {
                background-color: #2563eb;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(self.progress_bar)

        question_card = QFrame()
        question_card.setObjectName("questionCard")
        question_layout = QVBoxLayout(question_card)
        question_layout.setContentsMargins(20, 16, 20, 16)
        question_layout.setSpacing(10)

        meta_layout = QHBoxLayout()
        self.number_badge = QLabel()
        self.number_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.number_badge.setMinimumSize(46, 46)
        self.number_badge.setMaximumSize(52, 52)
        self.number_badge.setStyleSheet("""
            QLabel {
                background-color: #2563eb;
                color: white;
                font-size: 18px;
                font-weight: 900;
                border-radius: 23px;
                border: 3px solid #1d4ed8;
            }
        """)
        meta_layout.addWidget(self.number_badge)

        self.difficulty_badge = QLabel()
        self.topic_badge = QLabel()
        self.points_badge = QLabel()
        for badge in (self.difficulty_badge, self.topic_badge, self.points_badge):
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            badge.setMinimumHeight(26)
            badge.setStyleSheet("""
                QLabel {
                    background-color: #eef2ff;
                    color: #3730a3;
                    font-size: 11px;
                    font-weight: 900;
                    border-radius: 13px;
                    padding: 3px 10px;
                    border: 1px solid #c7d2fe;
                }
            """)
            meta_layout.addWidget(badge)
        meta_layout.addStretch()
        question_layout.addLayout(meta_layout)

        self.description_label = QLabel()
        self.description_label.setWordWrap(True)
        self.description_label.setStyleSheet("""
            QLabel {
                font-size: 15px;
                color: #1e293b;
                font-weight: 600;
                line-height: 1.35;
                padding: 10px 0;
                border-left: 4px solid #2563eb;
            }
        """)
        question_layout.addWidget(self.description_label)
        
        self.hint_display_label = QLabel()
        self.hint_display_label.setWordWrap(True)
        self.hint_display_label.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #b45309;
                font-weight: 700;
                background-color: #fef3c7;
                padding: 10px;
                border-left: 4px solid #f59e0b;
                border-radius: 4px;
            }
        """)
        self.hint_display_label.setVisible(False)
        question_layout.addWidget(self.hint_display_label)
        
        main_layout.addWidget(question_card)

        work_layout = QGridLayout()
        work_layout.setHorizontalSpacing(12)
        work_layout.setVerticalSpacing(12)

        editor_frame = QFrame()
        editor_frame.setObjectName("panel")
        editor_layout = QVBoxLayout(editor_frame)
        editor_layout.setContentsMargins(14, 14, 14, 14)
        editor_layout.setSpacing(8)

        self.code_editor = CodeEditor()
        self.code_editor.test_mode = (self.user_info or {}).get("test_mode", False)
        self.code_editor.setMinimumHeight(310)

        editor_body_layout = QHBoxLayout()
        editor_body_layout.setSpacing(10)
        editor_body_layout.addWidget(self.code_editor, 3)

        # Code Outline Sidebar Panel
        self.outline_panel = QFrame()
        self.outline_panel.setObjectName("outlinePanel")
        self.outline_panel.setFixedWidth(190)
        self.outline_panel.setStyleSheet("""
            QFrame#outlinePanel {
                background-color: #f8fafc;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
            }
        """)
        
        outline_layout = QVBoxLayout(self.outline_panel)
        outline_layout.setContentsMargins(8, 8, 8, 8)
        outline_layout.setSpacing(6)
        
        outline_title = QLabel("Outline")
        outline_title.setStyleSheet("font-size: 11px; font-weight: bold; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;")
        outline_layout.addWidget(outline_title)
        
        self.outline_scroll = QScrollArea()
        self.outline_scroll.setWidgetResizable(True)
        self.outline_scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        self.outline_content = QWidget()
        self.outline_content_layout = QVBoxLayout(self.outline_content)
        self.outline_content_layout.setContentsMargins(0, 0, 0, 0)
        self.outline_content_layout.setSpacing(4)
        self.outline_content_layout.addStretch()
        
        self.outline_scroll.setWidget(self.outline_content)
        outline_layout.addWidget(self.outline_scroll)
        
        editor_body_layout.addWidget(self.outline_panel, 1)
        
        # Connect signal
        self.code_editor.outline_changed.connect(self.update_outline)
        self.code_editor.textChanged.connect(self.on_code_changed)

        editor_header = QHBoxLayout()
        editor_title = QLabel("Python Editor")
        editor_title.setStyleSheet("font-size: 15px; font-weight: 900; color: #0f172a;")
        editor_header.addWidget(editor_title)
        editor_header.addStretch()

        editor_actions = [
            ("Undo", "editorToolButton", self.code_editor.undo),
            ("Redo", "editorToolButton", self.code_editor.redo),
            ("Indent", "editorToolButton", self.code_editor.indent_selection),
            ("Outdent", "editorToolButton", self.code_editor.outdent_selection),
            ("Comment", "editorToolButton", self.code_editor.toggle_comment),
        ]
        for text, object_name, handler in editor_actions:
            button = QPushButton(text)
            button.setObjectName(object_name)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setMinimumHeight(30)
            button.clicked.connect(handler)
            editor_header.addWidget(button)

        self.toggle_outline_button = QPushButton("Outline 📋")
        self.toggle_outline_button.setObjectName("editorToolButton")
        self.toggle_outline_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle_outline_button.setMinimumHeight(30)
        self.toggle_outline_button.setCheckable(True)
        self.toggle_outline_button.setChecked(True)
        self.toggle_outline_button.clicked.connect(self.toggle_outline)
        editor_header.addWidget(self.toggle_outline_button)

        self.reset_button = QPushButton("Reset Starter")
        self.reset_button.setObjectName("editorDangerButton")
        self.reset_button.clicked.connect(self.reset_starter_code)
        editor_header.addWidget(self.reset_button)
        editor_layout.addLayout(editor_header)

        editor_layout.addLayout(editor_body_layout)
        work_layout.addWidget(editor_frame, 0, 0, 2, 1)

        custom_frame = QFrame()
        custom_frame.setObjectName("panel")
        custom_layout = QVBoxLayout(custom_frame)
        custom_layout.setContentsMargins(14, 14, 14, 14)
        custom_layout.setSpacing(8)
        custom_title = QLabel("Custom Input")
        custom_title.setStyleSheet("font-size: 15px; font-weight: 900; color: #0f172a;")
        custom_layout.addWidget(custom_title)
        self.custom_input = NoClipboardPlainTextEdit()
        self.custom_input.test_mode = (self.user_info or {}).get("test_mode", False)
        self.custom_input.setPlaceholderText("Type stdin here, then click Run Custom.")
        self.custom_input.setMinimumHeight(120)
        custom_layout.addWidget(self.custom_input)
        self.custom_output_label = QTextEdit()
        self.custom_output_label.setReadOnly(True)
        self.custom_output_label.setPlaceholderText("Custom output will appear here.")
        self.custom_output_label.setStyleSheet("""
            QTextEdit {
                background: #f8fafc;
                color: #334155;
                border: 1px solid #e2e8f0;
                border-radius: 6px;
                padding: 8px;
                font-family: Consolas, "Fira Code", "DejaVu Sans Mono", "Courier New", monospace;
                font-size: 12px;
            }
        """)
        custom_layout.addWidget(self.custom_output_label)
        work_layout.addWidget(custom_frame, 0, 1)

        results_frame = QFrame()
        results_frame.setObjectName("panel")
        results_layout = QVBoxLayout(results_frame)
        results_layout.setContentsMargins(14, 14, 14, 14)
        results_layout.setSpacing(8)

        self.results_title = QLabel("Test Results")
        self.results_title.setStyleSheet("font-size: 15px; font-weight: 900; color: #0f172a;")
        results_layout.addWidget(self.results_title)

        self.results_summary = QLabel("Run public tests to reveal the visible test list.")
        self.results_summary.setWordWrap(True)
        self.results_summary.setStyleSheet("font-size: 12px; color: #64748b; font-weight: 700;")
        results_layout.addWidget(self.results_summary)

        results_scroll = QScrollArea()
        results_scroll.setWidgetResizable(True)
        results_scroll.setMinimumHeight(220)
        results_scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        self.results_container = QWidget()
        self.results_container_layout = QVBoxLayout(self.results_container)
        self.results_container_layout.setContentsMargins(0, 0, 0, 0)
        self.results_container_layout.setSpacing(8)
        self.results_container_layout.addStretch()
        results_scroll.setWidget(self.results_container)
        results_layout.addWidget(results_scroll, 1)
        work_layout.addWidget(results_frame, 1, 1)

        work_layout.setColumnStretch(0, 3)
        work_layout.setColumnStretch(1, 2)

        # Body layout holding collapsible navigation drawer and coding panel side-by-side
        body_layout = QHBoxLayout()
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(10)
        
        # 1. Slide-out Question Navigation Drawer
        self.nav_drawer = QFrame()
        self.nav_drawer.setObjectName("navDrawer")
        self.nav_drawer.setMinimumWidth(0)
        self.nav_drawer.setMaximumWidth(0)  # Start collapsed
        self.nav_drawer.setStyleSheet("""
            QFrame#navDrawer {
                background-color: white;
                border-radius: 12px;
                border: 2px solid #dfe6e9;
            }
        """)
        
        nav_drawer_layout = QVBoxLayout(self.nav_drawer)
        nav_drawer_layout.setContentsMargins(12, 12, 12, 12)
        nav_drawer_layout.setSpacing(10)
        
        drawer_title = QLabel("Questions Grid")
        drawer_title.setStyleSheet("font-size: 12px; font-weight: bold; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;")
        nav_drawer_layout.addWidget(drawer_title)
        
        self.drawer_scroll = QScrollArea()
        self.drawer_scroll.setWidgetResizable(True)
        self.drawer_scroll.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.drawer_scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        self.drawer_content = QWidget()
        self.drawer_content_layout = QGridLayout(self.drawer_content)
        self.drawer_content_layout.setContentsMargins(0, 0, 0, 0)
        self.drawer_content_layout.setSpacing(8)
        self.drawer_content_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        self.drawer_scroll.setWidget(self.drawer_content)
        nav_drawer_layout.addWidget(self.drawer_scroll)
        
        body_layout.addWidget(self.nav_drawer)
        
        # 2. Main Work Layout (wrapped in a widget)
        work_container = QWidget()
        work_container.setLayout(work_layout)
        body_layout.addWidget(work_container, 1)
        
        main_layout.addLayout(body_layout, 1)

        nav_frame = QFrame()
        nav_layout = QVBoxLayout(nav_frame)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(6)

        action_layout = QHBoxLayout()
        self.prev_button = QPushButton("Previous")
        self.prev_button.clicked.connect(self.previous_question)
        self.next_button = QPushButton("Next")
        self.next_button.clicked.connect(self.next_question)
        
        self.flag_button = QPushButton("🚩 Signaler")
        self.flag_button.setMinimumSize(100, 36)
        self.flag_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.flag_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.flag_button.clicked.connect(self.toggle_flag_current_question)
        
        self.run_custom_button = QPushButton("Run Custom")
        self.run_custom_button.clicked.connect(self.run_custom_input)
        self.run_tests_button = QPushButton("Run Tests")
        self.run_tests_button.clicked.connect(self.run_public_tests)
        
        self.hint_button = QPushButton("Hint 1 (-50% pts)")
        self.hint_button.setObjectName("hintButton")
        self.hint_button.setStyleSheet("QPushButton#hintButton { background-color: #f59e0b; border-color: #d97706; } QPushButton#hintButton:hover { background-color: #d97706; }")
        self.hint_button.clicked.connect(self.reveal_hint)
        
        self.submit_button = QPushButton("Submit")
        self.submit_button.setObjectName("submitButton")
        self.submit_button.clicked.connect(self.submit_hidden_tests)
        self.close_button = QPushButton("Finish Training")
        self.close_button.clicked.connect(self.request_close)

        action_layout.addWidget(self.prev_button)
        action_layout.addWidget(self.next_button)
        action_layout.addWidget(self.flag_button)
        action_layout.addStretch()
        action_layout.addWidget(self.hint_button)
        action_layout.addWidget(self.run_custom_button)
        action_layout.addWidget(self.run_tests_button)
        action_layout.addWidget(self.submit_button)
        action_layout.addWidget(self.close_button)
        nav_layout.addLayout(action_layout)

        dots_scroll = QScrollArea()
        dots_scroll.setWidgetResizable(True)
        dots_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        dots_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        dots_scroll.setMinimumHeight(48)
        dots_scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        dots_widget = QWidget()
        self.nav_dots_layout = QHBoxLayout(dots_widget)
        self.nav_dots_layout.setContentsMargins(10, 5, 10, 5)
        self.nav_dots_layout.setSpacing(6)
        self.nav_dots_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dots_scroll.setWidget(dots_widget)
        nav_layout.addWidget(dots_scroll)

        main_layout.addWidget(nav_frame)
        self.create_navigation_dots()

        # Keyboard shortcuts
        self.shortcut_run = QShortcut(QKeySequence("F5"), self)
        self.shortcut_run.activated.connect(self.run_custom_input)

        self.shortcut_submit_enter = QShortcut(QKeySequence("Ctrl+Return"), self)
        self.shortcut_submit_enter.activated.connect(self.run_public_tests)

        self.shortcut_submit_kp = QShortcut(QKeySequence("Ctrl+Enter"), self)
        self.shortcut_submit_kp.activated.connect(self.run_public_tests)

        # Tab/Arrow navigation for questions
        self.shortcut_next_tab = QShortcut(QKeySequence("Ctrl+Tab"), self)
        self.shortcut_next_tab.activated.connect(self.next_question)

        self.shortcut_prev_tab = QShortcut(QKeySequence("Ctrl+Shift+Tab"), self)
        self.shortcut_prev_tab.activated.connect(self.previous_question)
        
        self.shortcut_prev_backtab = QShortcut(QKeySequence("Ctrl+Shift+Backtab"), self)
        self.shortcut_prev_backtab.activated.connect(self.previous_question)

        self.setStyleSheet("""
            QWidget#centralWidget {
                background: #f8fafc;
            }
            QFrame#headerFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                            stop:0 #3498db, stop:1 #2ecc71);
                border-radius: 10px;
            }
            QFrame#questionCard, QFrame#panel {
                background: #ffffff;
                border: 1px solid #dfe6e9;
                border-radius: 8px;
            }
            QPushButton {
                background-color: #3498db;
                color: white;
                border: 2px solid #2980b9;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 13px;
                font-weight: 800;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:disabled {
                background-color: #bdc3c7;
                color: #7f8c8d;
                border-color: #95a5a6;
            }
            QPushButton#submitButton {
                background-color: #e74c3c;
                border-color: #c0392b;
            }
            QPushButton#submitButton:hover {
                background-color: #c0392b;
            }
            QLabel#timerLabel {
                font-size: 18px;
                font-weight: bold;
                color: white;
                background-color: #34495e;
                padding: 5px 10px;
                border-radius: 8px;
                border: 2px solid #2c3e50;
            }
            QPushButton#editorToolButton {
                background-color: #f8fafc;
                color: #334155;
                border: 1px solid #cbd5e1;
                border-radius: 5px;
                padding: 5px 8px;
                font-size: 11px;
                font-weight: 800;
            }
            QPushButton#editorToolButton:hover {
                background-color: #e0f2fe;
                border-color: #38bdf8;
                color: #075985;
            }
            QPushButton#editorDangerButton {
                background-color: #fff7ed;
                color: #9a3412;
                border: 1px solid #fed7aa;
                border-radius: 5px;
                padding: 5px 8px;
                font-size: 11px;
                font-weight: 900;
            }
            QPushButton#editorDangerButton:hover {
                background-color: #ffedd5;
                border-color: #fb923c;
            }
            QPlainTextEdit {
                background: #ffffff;
                color: #0f172a;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                padding: 9px;
                font-family: Consolas, "Fira Code", "DejaVu Sans Mono", "Courier New", monospace;
                font-size: 12px;
                selection-background-color: #bfdbfe;
                selection-color: #0f172a;
            }
        """)

    def update_timer(self):
        """Update timer and check for warnings"""
        self.time_remaining -= 1
        
        if self.time_remaining <= 0:
            self.timer.stop()
            self.coding_finished_flag = True
            self.security_timer.stop()
            from core.session_recovery import clear_session
            clear_session()
            self.coding_finished.emit(self.questions, self.submission_results)
            self.close()
            return
            
        self.update_timer_display()
        self.auto_save_state()
        
        # Check for warnings — only fire in the first 2 seconds of that minute
        minutes_left = self.time_remaining // 60
        seconds_in_minute = self.time_remaining % 60
        if minutes_left in [10, 5] and seconds_in_minute >= 58:
            if minutes_left not in self.warnings_given:
                self.warnings_given.add(minutes_left)
                
                # Style warning alert box
                warning = QMessageBox(self)
                warning.setWindowTitle("Temps Restant")
                warning.setIcon(QMessageBox.Icon.Warning)
                warning.setText(f"Attention, il ne reste que {minutes_left} minutes !")
                warning.setStandardButtons(QMessageBox.StandardButton.Ok)
                warning.setStyleSheet("""
                    QMessageBox {
                        background-color: #fff7ed;
                        font-size: 13px;
                    }
                    QLabel {
                        color: #9a3412;
                        font-weight: 600;
                    }
                """)
                self.security_paused = True
                try:
                    warning.exec()
                finally:
                    self.security_paused = False
                    QTimer.singleShot(0, self.enforce_secure_window)
                
        # Update timer color based on time remaining
        if self.time_remaining < 300:  # 5 minutes
            if (self.time_remaining % 2) == 0:
                self.timer_label.setStyleSheet("""
                    QLabel {
                        font-size: 18px;
                        font-weight: bold;
                        color: white;
                        background-color: #ef4444;
                        padding: 5px 10px;
                        border-radius: 8px;
                        border: 2px solid #b91c1c;
                    }
                """)
            else:
                self.timer_label.setStyleSheet("""
                    QLabel {
                        font-size: 18px;
                        font-weight: bold;
                        color: #b91c1c;
                        background-color: #fee2e2;
                        padding: 5px 10px;
                        border-radius: 8px;
                        border: 2px solid #fca5a5;
                    }
                """)
        elif self.time_remaining < 600:  # 10 minutes
            self.timer_label.setStyleSheet("""
                QLabel {
                    font-size: 18px;
                    font-weight: bold;
                    color: white;
                    background-color: #f39c12;
                    padding: 5px 10px;
                    border-radius: 8px;
                    border: 2px solid #d68910;
                }
            """)
        else:
            self.timer_label.setStyleSheet("""
                QLabel {
                    font-size: 18px;
                    font-weight: bold;
                    color: white;
                    background-color: #34495e;
                    padding: 5px 10px;
                    border-radius: 8px;
                    border: 2px solid #2c3e50;
                }
            """)

    def update_timer_display(self):
        """Update timer display"""
        hours = self.time_remaining // 3600
        minutes = (self.time_remaining % 3600) // 60
        seconds = self.time_remaining % 60
        self.timer_label.setText(f"{hours:02d}:{minutes:02d}:{seconds:02d}")

    def current_question(self):
        return self.questions[self.current_index]

    def start_security_monitoring(self):
        self.security_ready_at = datetime.datetime.now() + datetime.timedelta(seconds=2)
        self.security_timer.timeout.connect(self.enforce_secure_window)
        QTimer.singleShot(2000, lambda: self.security_timer.start(750))
        QTimer.singleShot(2100, self.enforce_secure_window)

    def record_security_event(self, reason):
        if self.coding_finished_flag or self.security_paused or QApplication.activeModalWidget():
            return

        now = datetime.datetime.now()
        if self.security_ready_at and now < self.security_ready_at:
            return

        if self.last_security_warning_at and (now - self.last_security_warning_at).total_seconds() < 2:
            return

        self.last_security_warning_at = now
        self.security_events.append({
            "reason": reason,
            "time": now.isoformat(timespec="seconds"),
        })
        self.warning_count += 1

        if self.warning_count >= self.max_warnings:
            self.show_security_exit_message(reason)
        else:
            if self.warning_count == self.max_warnings - 1:
                self.apply_last_warning_style()
            self.show_security_warning(reason)

    def apply_last_warning_style(self):
        if self.security_status_label:
            self.security_status_label.setText("LAST WARNING")
            self.security_status_label.setStyleSheet("""
                QLabel {
                    color: white;
                    background-color: #dc2626;
                    border: 2px solid #fecaca;
                    border-radius: 8px;
                    padding: 8px 12px;
                    font-size: 12px;
                    font-weight: 900;
                }
            """)

    def show_security_warning(self, reason):
        remaining = self.max_warnings - self.warning_count
        warning = QMessageBox(self)
        warning.setWindowTitle("Security Warning")
        warning.setIcon(QMessageBox.Icon.Warning)
        warning.setText(f"Warning {self.warning_count}/{self.max_warnings}: {reason}")
        warning.setInformativeText(
            f"Stay in fullscreen and keep focus inside the coding quiz. "
            f"{remaining} warning(s) remaining before the coding quiz exits."
        )
        warning.setStandardButtons(QMessageBox.StandardButton.Ok)

        self.security_paused = True
        try:
            warning.exec()
        finally:
            self.last_security_warning_at = datetime.datetime.now()
            self.security_paused = False
            QTimer.singleShot(0, self.enforce_secure_window)

    def show_security_exit_message(self, reason):
        warning = QMessageBox(self)
        warning.setWindowTitle("Coding Quiz Exited")
        warning.setIcon(QMessageBox.Icon.Critical)
        warning.setText("The coding quiz is being exited after 3 security warnings.")
        warning.setInformativeText(f"Last violation: {reason}")
        warning.setStandardButtons(QMessageBox.StandardButton.Ok)

        self.security_paused = True
        try:
            warning.exec()
        finally:
            self.security_paused = False

        self.coding_finished_flag = True
        self.security_timer.stop()
        from core.session_recovery import clear_session
        clear_session()
        self.close()

    def enforce_secure_window(self):
        if self.coding_finished_flag or self.security_paused or QApplication.activeModalWidget():
            return

        if not self.isFullScreen():
            self.record_security_event("Fullscreen was exited")
            self.showFullScreen()

        if not self.isActiveWindow():
            self.record_security_event("Coding quiz window lost focus")
            self.raise_()
            self.activateWindow()

        local_cursor_pos = self.mapFromGlobal(QCursor.pos())
        if not self.rect().contains(local_cursor_pos):
            self.record_security_event("Mouse left the coding quiz window")
            QCursor.setPos(self.mapToGlobal(self.rect().center()))

    def request_close(self):
        confirm = QMessageBox(self)
        confirm.setWindowTitle("Finish Coding Training")
        confirm.setIcon(QMessageBox.Icon.Question)
        confirm.setText("Finish the coding training?")
        confirm.setInformativeText("Your final results will be calculated.")
        confirm.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        confirm.setDefaultButton(QMessageBox.StandardButton.No)

        self.security_paused = True
        try:
            reply = confirm.exec()
        finally:
            self.security_paused = False
            QTimer.singleShot(0, self.enforce_secure_window)

        if reply == QMessageBox.StandardButton.Yes:
            self.coding_finished_flag = True
            self.security_timer.stop()
            from core.session_recovery import clear_session
            clear_session()
            self.coding_finished.emit(self.questions, self.submission_results)
            self.close()

    def save_current_code(self):
        if self.loaded_question_id is not None:
            self.code_by_question[self.loaded_question_id] = self.code_editor.toPlainText()

    def load_question(self, index):
        if not 0 <= index < len(self.questions):
            return

        self.save_current_code()
        self.current_index = index
        question = self.current_question()
        self.loaded_question_id = question["id"]
        self.visited_questions.add(question["id"])

        self.question_title_label.setText(question["title"])
        self.number_badge.setText(f"Q{index + 1}")
        self.difficulty_badge.setText(question.get("difficulty", "-").title())
        self.topic_badge.setText(question.get("topic", "-"))
        self.points_badge.setText(f"{question.get('points', 0)} point(s)")
        self.description_label.setText(question.get("description", ""))
        self.code_editor.setPlainText(
            # Temporarily load 'solution' instead of 'starter_code' for testing phase
            self.code_by_question.get(question["id"], question.get("solution", question.get("starter_code", "")))
        )
        is_submitted = question["id"] in self.submission_results
        self.code_editor.setReadOnly(is_submitted)
        self.submit_button.setEnabled(not is_submitted)
        self.run_tests_button.setEnabled(not is_submitted)
        self.run_custom_button.setEnabled(not is_submitted)
        self.reset_button.setEnabled(not is_submitted)
        
        is_exam = question.get("is_exam", False)
        state = self.hint_state.get(question["id"], 0)
        
        if is_exam:
            self.hint_button.setVisible(False)
            self.hint_display_label.setVisible(False)
        else:
            if state == 0:
                self.hint_button.setText("Hint 1 (-50% pts)")
                self.hint_button.setVisible(not is_submitted)
                self.hint_display_label.setVisible(False)
            elif state == 1:
                self.hint_button.setText("Hint 2 (-100% pts)")
                self.hint_button.setVisible(not is_submitted)
                self.hint_display_label.setText(question.get("hint1", ""))
                self.hint_display_label.setVisible(True)
            else:
                self.hint_button.setVisible(False)
                self.hint_display_label.setText(f"{question.get('hint1', '')}\n\n{question.get('hint2', '')}")
                self.hint_display_label.setVisible(True)
            
            if is_submitted and state > 0:
                self.hint_display_label.setVisible(True)
                hints = []
                if state >= 1: hints.append(question.get("hint1", ""))
                if state >= 2: hints.append(question.get("hint2", ""))
                self.hint_display_label.setText("\n\n".join(hints))

        self.custom_input.setPlainText("")
        self.custom_output_label.setHtml("<span style='color: #94a3b8; font-style: italic;'>Custom output will appear here.</span>")
        self.render_saved_results()
        self.update_navigation()
        self.update_score_label()
        
        # Trigger linter immediately to populate outline and show existing syntax warnings
        self.code_editor.run_linter()
        
    def toggle_outline(self):
        visible = self.toggle_outline_button.isChecked()
        self.outline_panel.setVisible(visible)

    def update_outline(self, outline):
        # Clear previous widgets
        while self.outline_content_layout.count():
            item = self.outline_content_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
                
        if not outline:
            empty_lbl = QLabel("No classes or defs")
            empty_lbl.setStyleSheet("color: #94a3b8; font-size: 11px; font-style: italic; padding: 5px;")
            self.outline_content_layout.addWidget(empty_lbl)
            self.outline_content_layout.addStretch()
            return
            
        for item in outline:
            btn = QPushButton()
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            
            # Format text based on class vs method and indentation
            indent_spaces = "  " * (item["indent"] // 4)
            prefix = "📁 " if item["is_class"] else "⚡ "
            btn.setText(f"{indent_spaces}{prefix}{item['name']}")
            
            if item["is_class"]:
                btn.setStyleSheet("""
                    QPushButton {
                        background: transparent;
                        color: #1e3a8a;
                        border: none;
                        text-align: left;
                        font-size: 11px;
                        font-weight: 800;
                        padding: 3px 5px;
                    }
                    QPushButton:hover {
                        background-color: #eff6ff;
                        color: #1d4ed8;
                        border-radius: 4px;
                    }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton {
                        background: transparent;
                        color: #334155;
                        border: none;
                        text-align: left;
                        font-size: 10px;
                        font-weight: 500;
                        padding: 2px 5px;
                    }
                    QPushButton:hover {
                        background-color: #f1f5f9;
                        color: #0f172a;
                        border-radius: 4px;
                    }
                """)
                
            btn.clicked.connect(lambda checked=False, line=item["line"]: self.jump_to_line(line))
            self.outline_content_layout.addWidget(btn)
            
        self.outline_content_layout.addStretch()
        
    def jump_to_line(self, line_num):
        doc = self.code_editor.document()
        block = doc.findBlockByLineNumber(line_num - 1)
        if block.isValid():
            cursor = self.code_editor.textCursor()
            cursor.setPosition(block.position())
            self.code_editor.setTextCursor(cursor)
            self.code_editor.setFocus()

    def reveal_hint(self):
        question = self.current_question()
        qid = question["id"]
        state = self.hint_state.get(qid, 0)
        
        if state == 0:
            self.hint_state[qid] = 1
        elif state == 1:
            self.hint_state[qid] = 2
            
        self.load_question(self.current_index)

    def create_navigation_dots(self):
        for index in range(len(self.questions)):
            dot = QPushButton(str(index + 1))
            dot.setFixedSize(36, 36)
            dot.setCursor(Qt.CursorShape.PointingHandCursor)
            dot.clicked.connect(lambda checked=False, idx=index: self.load_question(idx))
            self.nav_dot_buttons.append(dot)
            self.nav_dots_layout.addWidget(dot)
        self.create_drawer_cells()
        self.update_navigation()

    def update_navigation(self):
        submitted_count = len(self.submission_results)
        total_questions = len(self.questions)
        progress = int((submitted_count / total_questions) * 100) if total_questions else 0
        
        p = progress
        if p < 50:
            r = 255
            g = int(255 * (p / 50.0))
        else:
            g = 255
            r = int(255 * ((100 - p) / 50.0))
        color = f"rgb({r}, {g}, 0)"
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: none;
                border-radius: 5px;
                text-align: center;
                color: #2c3e50;
                font-weight: bold;
                background-color: #ecf0f1;
            }}
            QProgressBar::chunk {{
                background-color: {color};
                border-radius: 4px;
            }}
        """)
        
        self.progress_bar.setValue(progress)
        self.progress_bar.setFormat(
            f"Submitted: {submitted_count}/{total_questions} ({progress}%)"
        )
        self.prev_button.setEnabled(self.current_index > 0)
        self.next_button.setEnabled(self.current_index < len(self.questions) - 1)

        for index, button in enumerate(self.nav_dot_buttons):
            question_id = self.questions[index]["id"]
            is_flagged = question_id in self.flagged_questions
            is_visited = question_id in self.visited_questions
            is_submitted = question_id in self.submission_results
            
            if index == self.current_index:
                color = "#2563eb"
                border = "#1d4ed8"
                text = "white"
            elif is_flagged:
                color = "#fee2e2"
                border = "#dc2626"
                text = "#dc2626"
            elif is_submitted:
                color = "#10b981"
                border = "#059669"
                text = "white"
            elif is_visited:
                color = "#fef3c7"
                border = "#f59e0b"
                text = "#b45309"
            else:
                color = "#e2e8f0"
                border = "#cbd5e1"
                text = "#334155"
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: {color};
                    color: {text};
                    border: 2px solid {border};
                    border-radius: 18px;
                    font-size: 12px;
                    font-weight: 900;
                    padding: 0;
                }}
            """)
            
        self.update_flag_button_style()
        self.update_drawer_cells()
        self.auto_save_state()

    def toggle_drawer(self):
        is_collapsed = self.nav_drawer.maximumWidth() == 0
        
        self.drawer_animation = QPropertyAnimation(self.nav_drawer, b"maximumWidth")
        self.drawer_animation.setDuration(250)
        self.drawer_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)
        
        if is_collapsed:
            self.drawer_animation.setStartValue(0)
            self.drawer_animation.setEndValue(210)
            self.nav_drawer.setMinimumWidth(210)
        else:
            self.drawer_animation.setStartValue(210)
            self.drawer_animation.setEndValue(0)
            
            def on_animation_finished():
                if self.nav_drawer.maximumWidth() == 0:
                    self.nav_drawer.setMinimumWidth(0)
            self.drawer_animation.finished.connect(on_animation_finished)
            
        self.drawer_animation.start()

    def create_drawer_cells(self):
        # Clear drawer layout
        while self.drawer_content_layout.count():
            item = self.drawer_content_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
                
        self.drawer_buttons = []
        total = len(self.questions)
        columns = 4
        for idx in range(total):
            btn = QPushButton(str(idx + 1))
            btn.setFixedSize(36, 36)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            
            # Connect navigation
            btn.clicked.connect(lambda checked=False, i=idx: self.load_question(i))
            
            row = idx // columns
            col = idx % columns
            self.drawer_content_layout.addWidget(btn, row, col)
            self.drawer_buttons.append(btn)
            
        self.update_drawer_cells()

    def update_drawer_cells(self):
        if not hasattr(self, "drawer_buttons") or not self.drawer_buttons:
            return
            
        for i, button in enumerate(self.drawer_buttons):
            if button:
                question_id = self.questions[i]['id']
                is_submitted = question_id in self.submission_results
                is_flagged = question_id in self.flagged_questions
                is_visited = question_id in self.visited_questions
                
                # Determine colors based on state
                if i == self.current_index:
                    bg = "#2563eb"
                    border = "#1d4ed8"
                    text = "white"
                elif is_flagged:
                    bg = "#fee2e2"
                    border = "#dc2626"
                    text = "#dc2626"
                elif is_submitted:
                    bg = "#dcfce7"
                    border = "#10b981"
                    text = "#15803d"
                elif is_visited:
                    bg = "#fef3c7"
                    border = "#f59e0b"
                    text = "#b45309"
                else:
                    bg = "#f1f5f9"
                    border = "#cbd5e1"
                    text = "#64748b"
                    
                button.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {bg};
                        color: {text};
                        border: 2px solid {border};
                        border-radius: 6px;
                        font-weight: bold;
                        font-size: 11px;
                    }}
                    QPushButton:hover {{
                        border-color: #2563eb;
                    }}
                """)

    def toggle_flag_current_question(self):
        question = self.current_question()
        if not question:
            return
        qid = question["id"]
        if qid in self.flagged_questions:
            self.flagged_questions.remove(qid)
        else:
            self.flagged_questions.add(qid)
            
        self.update_flag_button_style()
        self.update_navigation()
        self.update_drawer_cells()

    def update_flag_button_style(self):
        question = self.current_question()
        if not question:
            return
        qid = question["id"]
        if qid in self.flagged_questions:
            self.flag_button.setText("🚩 Flagged")
            self.flag_button.setStyleSheet("""
                QPushButton {
                    background-color: #fee2e2;
                    color: #dc2626;
                    border: 2px solid #fca5a5;
                    border-radius: 6px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #fca5a5;
                }
            """)
        else:
            self.flag_button.setText("🚩 Signaler")
            self.flag_button.setStyleSheet("""
                QPushButton {
                    background-color: #f1f5f9;
                    color: #475569;
                    border: 2px solid #cbd5e1;
                    border-radius: 6px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #cbd5e1;
                }
            """)

    def auto_save_state(self):
        if self.coding_finished_flag:
            return
        from core.session_recovery import save_session
        save_session(
            session_type="coding",
            user_info=self.user_info,
            time_remaining=self.time_remaining,
            current_index=self.current_index,
            flagged_questions=list(self.flagged_questions),
            code_by_question=self.code_by_question,
            submission_results=self.submission_results,
            public_results=self.public_results,
            hint_state=self.hint_state,
            questions=self.questions,
            visited_questions=list(self.visited_questions)
        )

    def on_code_changed(self):
        self.save_current_code()
        self.auto_save_state()

    def clear_results_cards(self):
        while self.results_container_layout.count():
            item = self.results_container_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def render_saved_results(self):
        question_id = self.current_question()["id"]
        if question_id in self.submission_results:
            self.render_submit_summary(self.submission_results[question_id])
        elif question_id in self.public_results:
            self.render_public_results(self.public_results[question_id])
        else:
            self.clear_results_cards()
            self.results_title.setText("Test Results")
            self.results_summary.setText("Run public tests to reveal the visible test list.")
            self.results_container_layout.addStretch()

    def reset_starter_code(self):
        question = self.current_question()
        # Temporarily load 'solution' instead of 'starter_code' for testing phase
        code_to_load = question.get("solution", question.get("starter_code", ""))
        self.code_editor.setPlainText(code_to_load)
        self.code_by_question[question["id"]] = code_to_load

    def run_custom_input(self):
        import html
        question = self.current_question()
        timeout_ms = question.get("execution_settings", {}).get("timeout_ms", 2000)
        result = run_code(
            self.code_editor.toPlainText(),
            self.custom_input.toPlainText(),
            timeout_ms,
        )
        
        status = result.get("status", "unknown")
        output = result.get("output", "")
        error = result.get("error", "")
        
        # Build colored HTML output
        html_content = ""
        
        if status == "passed":
            html_content += (
                f"<div style='margin-bottom: 6px;'>"
                f"<b>Status:</b> <span style='color: #059669; font-weight: bold;'>SUCCESS (PASSED)</span>"
                f"</div>"
            )
        elif status == "timeout":
            html_content += (
                f"<div style='margin-bottom: 6px;'>"
                f"<b>Status:</b> <span style='color: #ea580c; font-weight: bold;'>TIMEOUT</span>"
                f"</div>"
            )
        else:
            html_content += (
                f"<div style='margin-bottom: 6px;'>"
                f"<b>Status:</b> <span style='color: #dc2626; font-weight: bold;'>RUNTIME ERROR</span>"
                f"</div>"
            )
            
        # Format the stdout output
        escaped_output = html.escape(output).replace("\n", "<br>")
        if not output.strip():
            escaped_output = "<span style='color: #94a3b8; font-style: italic;'>(no console output)</span>"
            
        html_content += (
            f"<div style='margin-bottom: 6px;'>"
            f"<b>Console Output:</b>"
            f"<div style='font-family: Consolas, \"Fira Code\", \"DejaVu Sans Mono\", \"Courier New\", monospace; background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 6px; border-radius: 4px; color: #334155; margin-top: 4px;'>"
            f"{escaped_output}"
            f"</div>"
            f"</div>"
        )
        
        # Format errors/stderr if present
        if error:
            escaped_error = html.escape(error).replace("\n", "<br>")
            html_content += (
                f"<div style='margin-bottom: 6px;'>"
                f"<b>Error Details:</b>"
                f"<div style='font-family: Consolas, \"Fira Code\", \"DejaVu Sans Mono\", \"Courier New\", monospace; background-color: #fef2f2; border: 1px solid #fecaca; padding: 6px; border-radius: 4px; color: #b91c1c; margin-top: 4px;'>"
                f"{escaped_error}"
                f"</div>"
                f"</div>"
            )
            
        self.custom_output_label.setHtml(html_content)

    def run_public_tests(self):
        question = self.current_question()
        result = run_tests(question, self.code_editor.toPlainText(), "public_tests")
        self.public_results[question["id"]] = result
        self.render_public_results(result)
        self.update_navigation()

    def render_public_results(self, result):
        failed = result["failed"]
        self.results_title.setText("Public Test Results")
        self.results_summary.setText(
            f"Passed: {result['passed']}/{result['total']} | "
            f"Failed: {failed} | Public percentage: {result['percentage']}%"
        )
        self.clear_results_cards()
        for detail in result["details"]:
            self.results_container_layout.addWidget(TestResultCard(detail))
        self.results_container_layout.addStretch()

    def submit_hidden_tests(self):
        question = self.current_question()
        result = evaluate_submission(question, self.code_editor.toPlainText())
        result["hints_used"] = self.hint_state.get(question["id"], 0)
        self.submission_results[question["id"]] = result
        self.render_submit_summary(result)
        self.update_navigation()
        self.update_score_label()

        self.code_editor.setReadOnly(True)
        self.submit_button.setEnabled(False)
        self.run_tests_button.setEnabled(False)
        self.run_custom_button.setEnabled(False)
        self.reset_button.setEnabled(False)

    def render_submit_summary(self, result):
        hidden = result["hidden_result"]
        self.results_title.setText("Submission Result")
        self.results_summary.setText(
            "Hidden tests are graded without revealing their inputs. "
            f"Passed: {hidden['passed']}/{hidden['total']} | "
            f"Failed: {hidden['failed']} | "
            f"Score: {result['score']}/{result['max_points']} | "
            f"Percentage: {hidden['percentage']}%"
        )
        self.clear_results_cards()

        card = QFrame()
        card.setObjectName("submitSummary")
        card.setStyleSheet("""
            QFrame#submitSummary {
                background: #eff6ff;
                border: 1px solid #bfdbfe;
                border-radius: 8px;
            }
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 14, 14, 14)
        label = QLabel(
            f"Hidden tests passed: {hidden['passed']}\n"
            f"Hidden tests failed: {hidden['failed']}\n"
            f"Points earned: {result['score']} / {result['max_points']}\n"
            f"Percentage: {hidden['percentage']}%"
        )
        label.setStyleSheet("font-size: 15px; color: #1e3a8a; font-weight: 900;")
        layout.addWidget(label)
        self.results_container_layout.addWidget(card)
        self.results_container_layout.addStretch()

    def update_score_label(self):
        earned = sum(result["score"] for result in self.submission_results.values())
        max_points = sum(question.get("points", 0) for question in self.questions)
        percentage = (earned / max_points * 100) if max_points else 0
        self.score_label.setText(f"Score: {earned:.2f}/{max_points} ({percentage:.1f}%)")

    def previous_question(self):
        self.load_question(self.current_index - 1)

    def next_question(self):
        self.load_question(self.current_index + 1)

    def closeEvent(self, event):
        if (self.user_info or {}).get("test_mode"):
            event.accept()
            return
        if not self.coding_finished_flag:
            self.record_security_event("Attempted to close the coding quiz window")
            event.ignore()
        else:
            event.accept()

    def changeEvent(self, event):
        if (self.user_info or {}).get("test_mode"):
            super().changeEvent(event)
            return
        if event.type() == QEvent.Type.WindowStateChange and not self.isFullScreen():
            self.record_security_event("Window state changed")
            QTimer.singleShot(0, self.showFullScreen)
        elif event.type() == QEvent.Type.ActivationChange and not self.isActiveWindow():
            self.record_security_event("Active window changed")
            QTimer.singleShot(0, self.enforce_secure_window)
        super().changeEvent(event)

    def focusOutEvent(self, event):
        if (self.user_info or {}).get("test_mode"):
            event.accept()
            return
        self.record_security_event("Keyboard focus left the coding quiz window")
        QTimer.singleShot(0, self.enforce_secure_window)
        event.accept()

    def leaveEvent(self, event):
        if (self.user_info or {}).get("test_mode"):
            event.accept()
            return
        self.record_security_event("Mouse left the coding quiz area")
        QCursor.setPos(self.mapToGlobal(self.rect().center()))
        event.accept()

    def keyPressEvent(self, event):
        if (self.user_info or {}).get("test_mode"):
            super().keyPressEvent(event)
            return
        if event.key() == Qt.Key.Key_Escape:
            self.record_security_event("Escape key blocked")
            event.accept()
            return
        super().keyPressEvent(event)
