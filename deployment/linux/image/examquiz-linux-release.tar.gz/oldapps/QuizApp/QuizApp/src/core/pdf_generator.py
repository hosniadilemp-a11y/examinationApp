"""Generate PDF reports with scores, answers, and QR code verification"""
from reportlab.lib.pagesizes import letter, A4
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image
from reportlab.lib import colors
from reportlab.lib.units import inch
import datetime
import os
from collections import defaultdict
import qrcode
from io import BytesIO
import json
import hashlib
import base64


class PDFReportGenerator:
    def __init__(self, output_path: str = "results"):
        self.output_path = output_path
        os.makedirs(output_path, exist_ok=True)
    
    def generate_qr_code(self, data: dict) -> BytesIO:
        """Generate QR code containing exam result data with hash verification"""
        # Prepare data for hash
        data_string = (
            f"{data.get('name', '')}"
            f"{data.get('last_name', '')}"
            f"{data.get('specialty', '')}"
            f"{data.get('points_earned', 0)}"
            f"{data.get('final_mark', 0)}"
            f"{data.get('correct_answers', 0)}"
            f"{data.get('exam_date', '')}"
            f"{data.get('exam_title', '')}"
            "dilo2025"  # password
        )
        
        # Compute SHA256 hash
        hash_value = hashlib.sha256(data_string.encode()).hexdigest()
        
        # Create QR code data string with hash
        qr_data = json.dumps({
            'name': data.get('name', ''),
            'last_name': data.get('last_name', ''),
            'specialty': data.get('specialty', ''),
            'points_earned': data.get('points_earned', 0),
            'final_mark': data.get('final_mark', 0),
            'correct_answers': data.get('correct_answers', 0),
            'exam_date': data.get('exam_date', ''),
            'exam_title': data.get('exam_title', ''),
            'hash': hash_value,
        }, ensure_ascii=False)
        
        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_data)
        qr.make(fit=True)
        
        # Create QR code image
        qr_image = qr.make_image(fill_color="black", back_color="white")
        
        # Save to BytesIO
        buffer = BytesIO()
        qr_image.save(buffer, format='PNG')
        buffer.seek(0)
        
        return buffer
    
    def generate_report(self, exam_data: dict, user_info: dict, 
                       score_result: dict, quiz_engine) -> str:
        """Generate complete PDF report in French with enhanced analysis and QR code"""
        
        # Create filename with timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        student_name = f"{user_info.get('first_name', '')}_{user_info.get('last_name', '')}"
        filename = f"{self.output_path}/{student_name}_{user_info.get('specialty', '')}Resultat_Examen__{timestamp}.pdf"
        
        # Create PDF document
        doc = SimpleDocTemplate(
            filename,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=50,
            bottomMargin=50
        )
        
        story = []
        styles = getSampleStyleSheet()
        
        # Add custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=22,
            spaceAfter=15,
            alignment=1,
            textColor=colors.HexColor('#2C3E50'),
            fontName='Helvetica-Bold'
        )
        
        subtitle_style = ParagraphStyle(
            'CustomSubtitle',
            parent=styles['Heading2'],
            fontSize=15,
            spaceAfter=15,
            textColor=colors.HexColor('#34495E'),
            fontName='Helvetica-Bold'
        )
        
        # Generate QR code data
        qr_data = {
            'name': user_info.get('first_name', ''),
            'last_name': user_info.get('last_name', ''),
            'specialty': user_info.get('specialty', ''),
            'points_earned': f"{score_result['total_points']:.2f}",
            'final_mark': f"{score_result['final_mark']:.2f}",
            'correct_answers': score_result['correct_count'],
            'exam_date': datetime.datetime.now().strftime('%d/%m/%Y'),
            'exam_title': exam_data.get('title', '')
        }
        
        qr_buffer = self.generate_qr_code(qr_data)
        
        # 1. Header Section with QR Code (French)
        header_table_data = [
            [
                Paragraph(f"RAPPORT DÉTAILLÉ D'EXAMEN {exam_data.get('title', 'N/A').upper()}", title_style),
                Image(qr_buffer, width=1.5*inch, height=1.5*inch)
            ]
        ]
        
        header_table = Table(header_table_data, colWidths=[350, 150])
        header_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (0, 0), 'LEFT'),
            ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        
        story.append(header_table)
        story.append(Paragraph(f"Généré le: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}", 
                             styles['Normal']))
        story.append(Spacer(1, 20))
        
        # QR Code Information Box (French)
        qr_info = Paragraph(
            "<i>Scannez le code QR ci-dessus pour vérifier l'authenticité de ce certificat et voir les détails essentiels de l'examen</i>",
            ParagraphStyle(
                'QRInfo',
                parent=styles['Normal'],
                fontSize=9,
                textColor=colors.HexColor('#6b7280'),
                alignment=1,
                spaceAfter=20
            )
        )
        story.append(qr_info)
        
        # 2. User Information with Enhanced Styling (French)
        story.append(Paragraph("INFORMATIONS DU CANDIDAT", subtitle_style))
        
        user_table = Table([
            ['Nom complet:', f"{user_info.get('first_name', '')} {user_info.get('last_name', '')}"],
            ['Spécialité:', user_info.get('specialty', 'N/A')],
            ['Titre de l\'examen:', exam_data.get('title', 'N/A')],
            ['Date de l\'examen:', datetime.datetime.now().strftime('%d/%m/%Y')],
            ['Durée:', f"{exam_data.get('duration', 0)} minutes"],
            ['Mode:', 'ENTRAÎNEMENT' if user_info.get('mode') == 'training' else 'EXAMEN']
        ], colWidths=[120, 330])
        
        user_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f0f9ff')),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#1e40af')),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('TOPPADDING', (0, 0), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#dbeafe')),
            ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.white, colors.HexColor('#fafafa')])
        ]))
        story.append(user_table)
        story.append(Spacer(1, 30))
        
        # 3. Overall Score Summary with Pass/Fail Banner (French)
        story.append(Paragraph("RÉSUMÉ DES SCORES", subtitle_style))
        
        # Pass/Fail Banner (French)
        if score_result['passed']:
            banner_color = colors.HexColor('#10b981')
            banner_text = "RÉUSSI - Excellente Performance!"
        else:
            banner_color = colors.HexColor('#ef4444')
            banner_text = "NÉCESSITE DES AMÉLIORATIONS - Continuez à vous entraîner!"
        
        banner_style = ParagraphStyle(
            'Banner',
            parent=styles['Normal'],
            fontSize=14,
            textColor=colors.white,
            backColor=banner_color,
            alignment=1,
            spaceAfter=15,
            spaceBefore=0,
            borderPadding=10,
            fontName='Helvetica-Bold'
        )
        story.append(Paragraph(banner_text, banner_style))
        
        summary_data = [
            ['Métrique', 'Valeur', 'Détails'],
            ['Total des Questions', str(score_result.get('total_questions', 0)), ''],
            ['Questions Répondues', str(score_result['correct_count'] + score_result['wrong_count'] + score_result.get('partial_count', 0)), 
             f"{((score_result['correct_count'] + score_result['wrong_count'] + score_result.get('partial_count', 0))/score_result.get('total_questions', 1)*100):.1f}%"],
            ['Réponses Correctes', str(score_result['correct_count']), 
             f"{(score_result['correct_count']/score_result.get('total_questions', 1)*100):.1f}%"],
            ['Réponses Partielles', str(score_result.get('partial_count', 0)), 
             f"{(score_result.get('partial_count', 0)/score_result.get('total_questions', 1)*100):.1f}%"],
            ['Réponses Incorrectes', str(score_result['wrong_count']), 
             f"{(score_result['wrong_count']/score_result.get('total_questions', 1)*100):.1f}%"],
            ['Non Répondues', str(score_result['unanswered_count']), 
             f"{(score_result['unanswered_count']/score_result.get('total_questions', 1)*100):.1f}%"],
            ['Points Obtenus', f"{score_result['total_points']:.2f}", 
             f"sur {score_result['max_points']:.2f}"],
            ['Pourcentage', f"{score_result['percentage']:.2f}%", 
             'RÉUSSI' if score_result['passed'] else 'ÉCHEC'],
            ['Note Finale', f"{score_result['final_mark']:.2f}/20", 
             f"Score de passage: {exam_data.get('passing_score', 50)}%"]
        ]
        
        summary_table = Table(summary_data, colWidths=[150, 120, 180])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')])
        ]))
        story.append(summary_table)
        story.append(Spacer(1, 30))
        
        # 4. Performance by Difficulty Analysis (French)
        if score_result.get('difficulty_analysis'):
            story.append(Paragraph("PERFORMANCE PAR NIVEAU DE DIFFICULTÉ", subtitle_style))
            
            difficulty_data = [['Difficulté', 'Questions', 'Correctes', '% Succès', 'Points Moy.']]
            for diff, stats in score_result['difficulty_analysis'].items():
                if diff == 'easy':
                    diff_label = 'FACILE'
                elif diff == 'medium':
                    diff_label = 'MOYEN'
                else:
                    diff_label = 'DIFFICILE'
                
                avg_points = stats['points'] / stats['total'] if stats['total'] > 0 else 0
                
                difficulty_data.append([
                    diff_label,
                    str(stats['total']),
                    str(stats['correct']),
                    f"{stats['percentage']:.1f}%",
                    f"{avg_points:.2f}"
                ])
            
            diff_table = Table(difficulty_data, colWidths=[100, 80, 80, 90, 90])
            diff_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
                ('TOPPADDING', (0, 0), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')])
            ]))
            story.append(diff_table)
            
            # Find best and worst difficulty
            valid_diffs = [(k, v) for k, v in score_result['difficulty_analysis'].items() if v['total'] > 0]
            if valid_diffs:
                best_diff = max(valid_diffs, key=lambda x: x[1]['percentage'])
                worst_diff = min(valid_diffs, key=lambda x: x[1]['percentage'])
                
                diff_analysis = f"""
                <b>Analyse:</b><br/>
                • <b>Plus fort:</b> {best_diff[0].upper()} ({best_diff[1]['percentage']:.1f}% taux de réussite)<br/>
                • <b>Zone d'amélioration:</b> {worst_diff[0].upper()} ({worst_diff[1]['percentage']:.1f}% taux de réussite)
                """
                story.append(Paragraph(diff_analysis, styles['Normal']))
            story.append(Spacer(1, 30))
        
        # 5. Performance by Topic Analysis (French)
        if score_result.get('topic_analysis'):
            story.append(PageBreak())
            story.append(Paragraph("PERFORMANCE PAR THÈME", subtitle_style))
            
            topic_data = [['Thème', 'Questions', 'Correctes', '% Succès', 'Niveau']]
            
            # Sort topics by percentage
            sorted_topics = sorted(score_result['topic_analysis'].items(), 
                                 key=lambda x: x[1]['percentage'], 
                                 reverse=True)
            
            for topic, stats in sorted_topics:
                # Assign grade based on percentage
                pct = stats['percentage']
                if pct >= 90:
                    grade = 'A+'
                elif pct >= 80:
                    grade = 'A'
                elif pct >= 70:
                    grade = 'B+'
                elif pct >= 60:
                    grade = 'B'
                elif pct >= 50:
                    grade = 'C'
                else:
                    grade = 'D'
                
                topic_data.append([
                    topic,
                    str(stats['total']),
                    str(stats['correct']),
                    f"{stats['percentage']:.1f}%",
                    grade
                ])
            
            topic_table = Table(topic_data, colWidths=[130, 70, 70, 90, 90])
            topic_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
                ('TOPPADDING', (0, 0), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')])
            ]))
            story.append(topic_table)
            
            # Find top 3 strengths and weaknesses
            if len(sorted_topics) >= 3:
                strengths = sorted_topics[:3]
                weaknesses = list(reversed(sorted_topics[-3:]))
                
                topic_analysis = f"""
                <b>Analyse par Thème:</b><br/>
                <br/>
                <b>Top 3 Forces:</b><br/>
                1. <b>{strengths[0][0]}</b>: {strengths[0][1]['percentage']:.1f}% ({strengths[0][1]['correct']}/{strengths[0][1]['total']})<br/>
                2. <b>{strengths[1][0]}</b>: {strengths[1][1]['percentage']:.1f}% ({strengths[1][1]['correct']}/{strengths[1][1]['total']})<br/>
                3. <b>{strengths[2][0]}</b>: {strengths[2][1]['percentage']:.1f}% ({strengths[2][1]['correct']}/{strengths[2][1]['total']})<br/>
                <br/>
                <b>Top 3 Domaines à Améliorer:</b><br/>
                1. <b>{weaknesses[0][0]}</b>: {weaknesses[0][1]['percentage']:.1f}% ({weaknesses[0][1]['correct']}/{weaknesses[0][1]['total']})<br/>
                2. <b>{weaknesses[1][0]}</b>: {weaknesses[1][1]['percentage']:.1f}% ({weaknesses[1][1]['correct']}/{weaknesses[1][1]['total']})<br/>
                3. <b>{weaknesses[2][0]}</b>: {weaknesses[2][1]['percentage']:.1f}% ({weaknesses[2][1]['correct']}/{weaknesses[2][1]['total']})
                """
                story.append(Paragraph(topic_analysis, styles['Normal']))
            
            story.append(Spacer(1, 30))
        
        # 6. Recommendations (French)
        story.append(Paragraph("RECOMMANDATIONS", subtitle_style))
        
        recommendations = []
        
        if score_result['percentage'] >= 80:
            recommendations.append("<b>Performance excellente!</b> Vous avez démontré une compréhension solide du matériel.")
            recommendations.append("Considérez vous challenger avec des sujets plus avancés et aider les autres à apprendre.")
        elif score_result['percentage'] >= 60:
            recommendations.append("<b>Bonne performance.</b> Vous avez une base solide dans la plupart des domaines.")
            recommendations.append("Concentrez-vous sur la révision des thèmes avec des taux de réussite plus bas pour vous améliorer.")
        else:
            recommendations.append("<b>Révision nécessaire.</b> Concentrez-vous sur les concepts fondamentaux et pratiquez régulièrement.")
            recommendations.append("Créez un plan d'étude ciblant vos domaines les plus faibles en premier.")
        
        # Add specific recommendations based on weaknesses
        if score_result.get('topic_analysis'):
            weak_topics = [(topic, stats) for topic, stats in score_result['topic_analysis'].items() 
                          if stats['percentage'] < 60 and stats['total'] > 0]
            if weak_topics:
                recommendations.append("<br/><b>Thèmes de révision prioritaires:</b>")
                for topic, stats in sorted(weak_topics, key=lambda x: x[1]['percentage'])[:5]:
                    recommendations.append(f"• <b>{topic}</b> ({stats['percentage']:.1f}% - {stats['correct']}/{stats['total']} correct)")
        
        rec_text = "<br/>".join(recommendations)
        story.append(Paragraph(rec_text, styles['Normal']))
        story.append(Spacer(1, 30))
        
        # 7. Detailed Question-by-Question Analysis (French)
        story.append(PageBreak())
        story.append(Paragraph("ANALYSE DÉTAILLÉE DES QUESTIONS", subtitle_style))
        
        for idx, question in enumerate(quiz_engine.selected_questions):
            status = next((s for s in quiz_engine.score_details 
                         if s['id'] == question['id']), {})
            
            # Question header
            difficulty = question.get('difficulty', 'unknown').upper()
            topic = question.get('topic', 'Non spécifié')
            
            # Text label for difficulty (no emoji)
            if difficulty == 'EASY':
                diff_label = '[FACILE]'
                diff_color = '#10b981'
                bg_color = '#f0fdf4'
            elif difficulty == 'MEDIUM':
                diff_label = '[MOYEN]'
                diff_color = '#f59e0b'
                bg_color = '#fffbeb'
            else:
                diff_label = '[DIFFICILE]'
                diff_color = '#ef4444'
                bg_color = '#fef2f2'
            
            q_header = f"<b>Question {idx + 1}</b> {diff_label} (Thème: {topic})<br/>"
            q_header += f"{question['text']}<br/>"
            
            header_style = ParagraphStyle(
                f'Question{idx}',
                parent=styles['Normal'],
                fontSize=11,
                textColor=colors.HexColor(diff_color),
                spaceAfter=8,
                borderWidth=1,
                borderPadding=8,
                borderColor=colors.HexColor(diff_color),
                borderRadius=3,
                backColor=colors.HexColor(bg_color),
                fontName='Helvetica-Bold'
            )
            
            story.append(Paragraph(q_header, header_style))
            
            q_type = question.get('type', 'coding')
            
            # For MCQ questions
            if q_type == 'mcq':
                user_answer = quiz_engine.user_answers.get(question['id'], {}).get('answer', [])
                num_correct = len(question.get('displayed_correct', question.get('original_correct', question.get('correct', []))))
                points_per_correct = question['points'] / max(1, num_correct)
                penalty = question.get('penalty', 0)
                
                options_text = []
                for opt_idx, option in enumerate(question.get('display_options', [])):
                    mapping = question['display_mapping'].get(opt_idx, {})
                    is_correct = mapping.get('is_correct', False)
                    is_selected = opt_idx in user_answer
                    
                    point_str = f"(+{points_per_correct:.2f} pts)" if is_correct else f"(-{penalty:.2f} pts)"
                    
                    if is_correct and is_selected:
                        prefix = f"[CORRECT] {point_str} "
                        color = colors.HexColor('#10b981')
                    elif is_correct and not is_selected:
                        prefix = f"[BONNE RÉPONSE] {point_str} "
                        color = colors.HexColor('#10b981')
                    elif not is_correct and is_selected:
                        prefix = f"[INCORRECT] {point_str} "
                        color = colors.HexColor('#ef4444')
                    else:
                        prefix = f"[ ] {point_str} "
                        color = colors.black
                    
                    options_text.append(f"<font color='{color.hexval()}'>{prefix}{option}</font>")
                
                options_paragraph = "<br/>".join(options_text)
                story.append(Paragraph(options_paragraph, ParagraphStyle(
                    'Options',
                    parent=styles['Normal'],
                    fontSize=10,
                    leftIndent=20,
                    spaceAfter=10
                )))
            
            # For Yes/No questions
            elif q_type == 'yesno':
                user_answer = quiz_engine.user_answers.get(question['id'], {}).get('answer')
                correct_answer = question['correct']
                
                if user_answer is None:
                    user_text = "[NON RÉPONDU]"
                    answer_color = colors.grey
                elif user_answer == correct_answer:
                    user_text = f"[CORRECT] {'Oui' if user_answer else 'Non'}"
                    answer_color = colors.HexColor('#10b981')
                else:
                    user_text = f"[INCORRECT] {'Oui' if user_answer else 'Non'}"
                    answer_color = colors.HexColor('#ef4444')
                
                correct_text = f"[BONNE RÉPONSE] {'Oui' if correct_answer else 'Non'}"
                
                answer_text = f"<b>Votre réponse:</b> {user_text}<br/>"
                answer_text += f"<b>Bonne réponse:</b> {correct_text}"
                
                story.append(Paragraph(answer_text, ParagraphStyle(
                    'YesNoAnswer',
                    parent=styles['Normal'],
                    fontSize=10,
                    leftIndent=20,
                    spaceAfter=10,
                    textColor=answer_color
                )))
                
            # For Coding questions
            else:
                passed = status.get('passed_tests', 0)
                total = status.get('total_tests', 0)
                hints = status.get('hints_used', 0)
                
                if total > 0 and passed == total:
                    answer_color = colors.HexColor('#10b981')
                elif passed > 0:
                    answer_color = colors.HexColor('#f59e0b')
                else:
                    answer_color = colors.HexColor('#ef4444')
                    
                answer_text = f"<b>Tests Passed:</b> {passed}/{total}<br/>"
                if hints > 0:
                    answer_text += f"<b>Hints Used:</b> {hints} (Penalty applied)<br/>"
                    
                story.append(Paragraph(answer_text, ParagraphStyle(
                    'CodingAnswer',
                    parent=styles['Normal'],
                    fontSize=10,
                    leftIndent=20,
                    spaceAfter=10,
                    textColor=answer_color
                )))
            
            # Status and points
            points_earned = status.get('points', 0) - status.get('penalty', 0)
            status_str = status.get('status', 'unanswered').upper()
            
            if status_str == 'CORRECT':
                status_color = colors.HexColor('#10b981')
                status_label = '[CORRECT]'
            elif status_str == 'INCORRECT':
                status_color = colors.HexColor('#ef4444')
                status_label = '[INCORRECT]'
            elif status_str == 'PARTIAL':
                status_color = colors.HexColor('#f59e0b')
                status_label = '[PARTIEL]'
            else:
                status_color = colors.grey
                status_label = '[NON RÉPONDU]'
            
            status_text = f"{status_label} <b>Statut:</b> <font color='{status_color.hexval()}'>{status_str}</font> | "
            status_text += f"<b>Points:</b> {points_earned:+.2f} | "
            if q_type == 'mcq':
                num_correct = len(question.get('displayed_correct', question.get('original_correct', question.get('correct', []))))
                points_per_correct = question['points'] / max(1, num_correct)
                status_text += f"<b>Valeur de la question:</b> +{points_per_correct:.2f} par choix correct / -{question.get('penalty', 0):.2f} par choix incorrect"
            else:
                status_text += f"<b>Valeur de la question:</b> +{question.get('points', 0):.2f} / -{question.get('penalty', 0):.2f}"
            
            story.append(Paragraph(status_text, ParagraphStyle(
                'StatusInfo',
                parent=styles['Normal'],
                fontSize=9,
                textColor=colors.grey,
                spaceAfter=20,
                leftIndent=20
            )))
        
        # 8. Footer with QR info (French)
        story.append(Spacer(1, 30))
        story.append(Paragraph("_" * 80, ParagraphStyle(
            'Line',
            parent=styles['Normal'],
            fontSize=8,
            textColor=colors.grey,
            alignment=1
        )))
        
        footer_text = f"Généré le {datetime.datetime.now().strftime('%d/%m/%Y à %H:%M:%S')} | "
        footer_text += f"SecureQuizMaster v{exam_data.get('version', '1.0')}<br/>"
        footer_text += f"<i>Le code QR contient: Nom, Spécialité, Note Finale, Réponses Correctes, Points - Scannez pour vérifier l'authenticité</i>"
        
        story.append(Paragraph(footer_text, ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=8,
            textColor=colors.grey,
            alignment=1
        )))
        
        # Build PDF
        try:
            doc.build(story)
            return filename
        except Exception as e:
            print(f"Erreur lors de la génération du PDF: {e}")
            raise