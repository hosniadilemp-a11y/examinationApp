"""
Fused Results Window for Official Exams containing both Theoretical and Practical parts.
"""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QMessageBox, QFrame,
    QScrollArea, QGridLayout, QSizePolicy, QTabWidget
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QDesktopServices
from PyQt6.QtCore import QUrl
import os
import sys

from gui.results_window import CircularProgress, StatCard
from core.fused_pdf import FusedPDFGenerator

class FusedResultsWindow(QMainWindow):
    """Window to display fused results of theoretical and practical exams."""
    restart_requested = pyqtSignal()
    exit_requested = pyqtSignal() 
    
    def __init__(self, theoretical_engine, theoretical_score, coding_engine, coding_score, user_info, exam_config):
        super().__init__()
        self.theoretical_engine = theoretical_engine
        self.theoretical_score = theoretical_score
        self.coding_engine = coding_engine
        self.coding_score = coding_score
        self.user_info = user_info
        self.exam_config = exam_config
        self.pdf_path = None
        
        # Calculate Fused Score
        self.theo_mark = self.theoretical_score.get('final_mark', 0)
        self.prac_mark = self.coding_score.get('final_mark', 0)
        self.fused_mark = (self.theo_mark + self.prac_mark) / 2.0
        self.fused_percentage = (self.fused_mark / 20.0) * 100
        
        if self.user_info.get('mode') == 'exam':
            self.generate_fused_pdf_report_silent()
            
        self.init_ui()
        QTimer.singleShot(100, self.start_animations)

    def generate_fused_pdf_report_silent(self):
        """Silently generate the fused PDF report."""
        try:
            pdf_gen = FusedPDFGenerator()
            self.pdf_path = pdf_gen.generate_fused_report(
                self.theoretical_score, 
                self.coding_score, 
                self.user_info,
                self.theoretical_engine,
                self.coding_engine
            )
        except Exception as e:
            print(f"Failed to generate PDF: {e}")
            self.pdf_path = None

    def init_ui(self):
        self.setWindowTitle("🎓 Fused Exam Results")
        self.setMinimumSize(500, 700)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background-color: #f9fafb; }")
        
        central_widget = QWidget()
        scroll.setWidget(central_widget)
        self.setCentralWidget(scroll)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(24, 24, 24, 24)
        main_layout.setSpacing(24)
        
        # --- Header ---
        header_layout = QVBoxLayout()
        header_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title = QLabel("Examen Officiel Terminé ! 🎉")
        title.setStyleSheet("font-size: 28px; font-weight: 800; color: #0f172a;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(title)
        
        subtitle = QLabel(f"Candidat : {self.user_info.get('first_name', '')} {self.user_info.get('last_name', '')}")
        subtitle.setStyleSheet("font-size: 16px; color: #64748b; margin-top: -8px;")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(subtitle)
        
        main_layout.addLayout(header_layout)
        
        # --- Fused Score ---
        score_container = QFrame()
        score_container.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 20px;
                border: 1px solid #e2e8f0;
            }
        """)
        score_layout = QVBoxLayout(score_container)
        score_layout.setContentsMargins(30, 30, 30, 30)
        score_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.circular_progress = CircularProgress(self.fused_percentage, size=160)
        score_layout.addWidget(self.circular_progress, alignment=Qt.AlignmentFlag.AlignCenter)
        
        mark_label = QLabel(f"{self.fused_mark:.2f} / 20")
        mark_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #1e293b; margin-top: 10px;")
        mark_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_layout.addWidget(mark_label)
        
        status = "Admis(e)" if self.fused_mark >= 14 else "Ajourné(e)"
        status_color = "#10b981" if self.fused_mark >= 14 else "#ef4444"
        status_label = QLabel(status)
        status_label.setStyleSheet(f"font-size: 20px; font-weight: bold; color: {status_color};")
        status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_layout.addWidget(status_label)
        
        main_layout.addWidget(score_container)
        
        # --- Breakdowns ---
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(16)
        
        theo_card = StatCard(f"{self.theo_mark:.2f}/20", "Théorique", "📝", "#3b82f6")
        prac_card = StatCard(f"{self.prac_mark:.2f}/20", "Pratique", "💻", "#0f766e")
        
        stats_layout.addWidget(theo_card)
        stats_layout.addWidget(prac_card)
        main_layout.addLayout(stats_layout)
        
        # --- PDF Button ---
        if self.pdf_path and os.path.exists(self.pdf_path):
            pdf_btn = QPushButton("📄 Ouvrir le Certificat Officiel (PDF)")
            pdf_btn.setStyleSheet("""
                QPushButton {
                    background-color: #be185d;
                    color: white;
                    border: none;
                    border-radius: 12px;
                    padding: 16px;
                    font-size: 15px;
                    font-weight: bold;
                }
                QPushButton:hover { background-color: #9d174d; }
                QPushButton:pressed { background-color: #831843; }
            """)
            pdf_btn.clicked.connect(self.open_pdf)
            main_layout.addWidget(pdf_btn)
            
        main_layout.addStretch()
        
        # --- Bottom Buttons ---
        buttons_layout = QHBoxLayout()
        
        self.restart_btn = QPushButton("🏠 Menu Principal")
        self.restart_btn.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #3b82f6;
                border: 2px solid #3b82f6;
                border-radius: 12px;
                padding: 14px;
                font-size: 15px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #eff6ff; }
        """)
        self.restart_btn.clicked.connect(self.restart_requested.emit)
        
        self.exit_btn = QPushButton("🚪 Quitter")
        self.exit_btn.setStyleSheet("""
            QPushButton {
                background-color: #f1f5f9;
                color: #64748b;
                border: none;
                border-radius: 12px;
                padding: 14px;
                font-size: 15px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #e2e8f0; color: #475569; }
        """)
        self.exit_btn.clicked.connect(self.exit_requested.emit)
        
        buttons_layout.addWidget(self.restart_btn)
        buttons_layout.addWidget(self.exit_btn)
        
        main_layout.addLayout(buttons_layout)
        
    def start_animations(self):
        self.circular_progress.start_animation()
        
    def open_pdf(self):
        if self.pdf_path and os.path.exists(self.pdf_path):
            abs_path = os.path.abspath(self.pdf_path)
            QDesktopServices.openUrl(QUrl.fromLocalFile(abs_path))
        else:
            QMessageBox.warning(self, "Erreur", "Le rapport PDF est introuvable.")
