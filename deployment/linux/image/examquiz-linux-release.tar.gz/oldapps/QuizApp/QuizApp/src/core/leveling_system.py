"""Leveling and Milestones System for QuizApp

Defines:
- 68 milestones total:
    * 4 theoretical passed tests
    * 4 practical passed tests
    * 30 topic mastery (theoretical) — 10 topics × 3 tiers
    * 30 topic mastery (practical)  — 10 topics × 3 tiers
- Fixed XP level thresholds (10 levels, rounded to clean numbers)
- Dynamic metric tracking and requirements display
"""

import math
from core.exam_code import TOPIC_ORDER

PASSING_MARK = 14.0

# Level XP thresholds — chosen so Level 10 ≈ max achievable XP (~2760)
# Rounded up to the nearest 100 for clean display
LEVEL_XP_THRESHOLDS = [0, 100, 200, 400, 700, 1000, 1400, 1800, 2300, 2760]
# Index i → Level i+1
# Level 1:  0 XP
# Level 2:  100 XP
# Level 3:  200 XP
# Level 4:  400 XP
# Level 5:  700 XP
# Level 6:  1000 XP
# Level 7:  1400 XP
# Level 8:  1800 XP
# Level 9:  2300 XP
# Level 10: 2760 XP (max — all milestones unlocked)

LEVEL_NAMES = [
    "Débutant",       # 1
    "Apprenti",       # 2
    "Initié",         # 3
    "Intermédiaire",  # 4
    "Avancé",         # 5
    "Expert",         # 6
    "Maître",         # 7
    "Grand Maître",   # 8
    "Champion",       # 9
    "Légendaire",     # 10
]


def match_canonical_topic(topic_str):
    if not topic_str:
        return None
    topic_str_lower = topic_str.lower()

    if "basic" in topic_str_lower or ("base" in topic_str_lower and "python" in topic_str_lower):
        return "Python Basics"
    if "type" in topic_str_lower:
        return "Python Data Types"
    if "flow" in topic_str_lower or "contrôle" in topic_str_lower or "controle" in topic_str_lower or "boucle" in topic_str_lower:
        return "Control Flow"
    if "comprehension" in topic_str_lower or "compréhension" in topic_str_lower:
        return "List Comprehension"
    if "modules de base" in topic_str_lower or "modules_de_base" in topic_str_lower or "module" in topic_str_lower:
        return "Modules de Base"
    if "i/o" in topic_str_lower or "input" in topic_str_lower or "entrée" in topic_str_lower or "lecture" in topic_str_lower or "ecriture" in topic_str_lower:
        return "Input / Output (I/O)"
    if "objet" in topic_str_lower or "oop" in topic_str_lower or "poo" in topic_str_lower or "class" in topic_str_lower:
        return "Object-Oriented Programming (OOP / POO)"
    if "numpy" in topic_str_lower:
        return "NumPy"
    if "pandas" in topic_str_lower:
        return "Pandas"
    if "vis" in topic_str_lower or "graphe" in topic_str_lower or "plot" in topic_str_lower:
        return "Data Visualization"

    # Fallback to direct substring matching
    for canonical in TOPIC_ORDER:
        if canonical.lower() in topic_str_lower:
            return canonical

    return None


def _compute_level(total_xp):
    """Return level (1–10) based on total XP using fixed thresholds."""
    level = 1
    for i, threshold in enumerate(LEVEL_XP_THRESHOLDS):
        if total_xp >= threshold:
            level = i + 1
    return min(level, 10)


def get_all_levels_info():
    """Return a list of dicts describing all 10 levels with their XP thresholds."""
    levels = []
    for i, xp in enumerate(LEVEL_XP_THRESHOLDS):
        level_num = i + 1
        next_xp = LEVEL_XP_THRESHOLDS[i + 1] if i + 1 < len(LEVEL_XP_THRESHOLDS) else xp
        levels.append({
            "level": level_num,
            "name": LEVEL_NAMES[i],
            "xp_required": xp,
            "xp_next": next_xp,
        })
    return levels


def calculate_leveling_data(history):
    """
    Computes milestones status, XP, Level, and progress to next level.

    Returns 68 milestones:
      - 4 theoretical test count milestones
      - 4 practical test count milestones
      - 30 theoretical topic mastery milestones (10 topics × 3 tiers)
      - 30 practical topic mastery milestones (10 topics × 3 tiers)
    """
    theoretical_history = [a for a in history if a.get("assessment_type", "theoretical") == "theoretical"]
    practical_history = [a for a in history if a.get("assessment_type", "theoretical") == "practical"]

    passed_theoretical = sum(1 for a in theoretical_history if float(a.get("final_mark", 0) or 0) >= PASSING_MARK)
    passed_practical = sum(1 for a in practical_history if float(a.get("final_mark", 0) or 0) >= PASSING_MARK)

    # Track highest score per topic per assessment type
    highest_scores_theo = {topic: 0.0 for topic in TOPIC_ORDER}
    highest_scores_prac = {topic: 0.0 for topic in TOPIC_ORDER}

    for attempt in history:
        atype = attempt.get("assessment_type", "theoretical")
        target_dict = highest_scores_theo if atype == "theoretical" else highest_scores_prac

        topic = attempt.get("topic") or attempt.get("target_topic")
        mark = float(attempt.get("final_mark", 0) or 0)
        matched = match_canonical_topic(topic)
        if matched:
            target_dict[matched] = max(target_dict[matched], mark)

        for t_name, data in attempt.get("topic_marks", {}).items():
            t_mark = float(data.get("mark", 0) or 0)
            matched = match_canonical_topic(t_name)
            if matched:
                target_dict[matched] = max(target_dict[matched], t_mark)

    # 1. Theoretical passed tests milestones (4)
    theo_milestones = [
        {"id": "theo_1",  "emoji": "📖", "name": "Théoricien Apprenti",   "desc": "Réussir 1 test théorique",   "target": 1,  "actual": passed_theoretical, "points": 10,  "unlocked": passed_theoretical >= 1},
        {"id": "theo_5",  "emoji": "📚", "name": "Théoricien Confirmé",   "desc": "Réussir 5 tests théoriques", "target": 5,  "actual": passed_theoretical, "points": 20,  "unlocked": passed_theoretical >= 5},
        {"id": "theo_20", "emoji": "🧠", "name": "Théoricien Expert",     "desc": "Réussir 20 tests théoriques","target": 20, "actual": passed_theoretical, "points": 50,  "unlocked": passed_theoretical >= 20},
        {"id": "theo_40", "emoji": "🎓", "name": "Théoricien Légendaire", "desc": "Réussir 40 tests théoriques","target": 40, "actual": passed_theoretical, "points": 100, "unlocked": passed_theoretical >= 40},
    ]

    # 2. Practical passed tests milestones (4)
    prac_milestones = [
        {"id": "prac_1",  "emoji": "💻", "name": "Codeur Novice",   "desc": "Réussir 1 laboratoire pratique",   "target": 1,  "actual": passed_practical, "points": 10,  "unlocked": passed_practical >= 1},
        {"id": "prac_5",  "emoji": "🛠️", "name": "Codeur Agile",   "desc": "Réussir 5 laboratoires pratiques",  "target": 5,  "actual": passed_practical, "points": 20,  "unlocked": passed_practical >= 5},
        {"id": "prac_20", "emoji": "⚡", "name": "Codeur Élite",   "desc": "Réussir 20 laboratoires pratiques", "target": 20, "actual": passed_practical, "points": 50,  "unlocked": passed_practical >= 20},
        {"id": "prac_40", "emoji": "🛡️", "name": "Codeur Suprême", "desc": "Réussir 40 laboratoires pratiques","target": 40, "actual": passed_practical, "points": 100, "unlocked": passed_practical >= 40},
    ]

    # 3. Topic milestones — Theoretical (30: 10 topics × 3 tiers)
    theo_topic_milestones = []
    for topic in TOPIC_ORDER:
        hs = highest_scores_theo[topic]
        theo_topic_milestones.append({
            "id": f"{topic}_theo_bronze", "emoji": "🥉",
            "name": f"{topic} - Bronze (MCQ)",
            "desc": f"Score MCQ ≥ 16/20 sur {topic}",
            "target": 16.0, "actual": hs, "points": 10, "unlocked": hs >= 16.0
        })
        theo_topic_milestones.append({
            "id": f"{topic}_theo_silver", "emoji": "🥈",
            "name": f"{topic} - Argent (MCQ)",
            "desc": f"Score MCQ ≥ 18/20 sur {topic}",
            "target": 18.0, "actual": hs, "points": 20, "unlocked": hs >= 18.0
        })
        theo_topic_milestones.append({
            "id": f"{topic}_theo_gold", "emoji": "🥇",
            "name": f"{topic} - Or (MCQ)",
            "desc": f"Score MCQ parfait 20/20 sur {topic}",
            "target": 20.0, "actual": hs, "points": 50, "unlocked": hs == 20.0
        })

    # 4. Topic milestones — Practical (30: 10 topics × 3 tiers)
    prac_topic_milestones = []
    for topic in TOPIC_ORDER:
        hs = highest_scores_prac[topic]
        prac_topic_milestones.append({
            "id": f"{topic}_prac_bronze", "emoji": "🥉",
            "name": f"{topic} - Bronze (Code)",
            "desc": f"Score Coding ≥ 16/20 sur {topic}",
            "target": 16.0, "actual": hs, "points": 10, "unlocked": hs >= 16.0
        })
        prac_topic_milestones.append({
            "id": f"{topic}_prac_silver", "emoji": "🥈",
            "name": f"{topic} - Argent (Code)",
            "desc": f"Score Coding ≥ 18/20 sur {topic}",
            "target": 18.0, "actual": hs, "points": 20, "unlocked": hs >= 18.0
        })
        prac_topic_milestones.append({
            "id": f"{topic}_prac_gold", "emoji": "🥇",
            "name": f"{topic} - Or (Code)",
            "desc": f"Score Coding parfait 20/20 sur {topic}",
            "target": 20.0, "actual": hs, "points": 50, "unlocked": hs == 20.0
        })

    all_milestones = theo_milestones + prac_milestones + theo_topic_milestones + prac_topic_milestones

    total_xp = sum(m["points"] for m in all_milestones if m["unlocked"])
    unlocked_badges = sum(1 for m in all_milestones if m["unlocked"])
    total_badges = len(all_milestones)  # 68

    # Level calculation using fixed thresholds
    level = _compute_level(total_xp)

    xp_for_current = LEVEL_XP_THRESHOLDS[level - 1]
    if level < 10:
        xp_for_next = LEVEL_XP_THRESHOLDS[level]
        xp_in_level = total_xp - xp_for_current
        level_range = xp_for_next - xp_for_current
    else:
        xp_for_next = LEVEL_XP_THRESHOLDS[-1]
        xp_in_level = total_xp - xp_for_current
        level_range = max(1, xp_for_next - xp_for_current)

    return {
        "level": level,
        "level_name": LEVEL_NAMES[level - 1],
        "xp": total_xp,
        "unlocked_badges": unlocked_badges,
        "total_badges": total_badges,
        "xp_in_level": xp_in_level,
        "level_range": level_range,
        "xp_for_next": xp_for_next,
        "theo_milestones": theo_milestones,
        "prac_milestones": prac_milestones,
        "theo_topic_milestones": theo_topic_milestones,
        "prac_topic_milestones": prac_topic_milestones,
        "all_milestones": all_milestones,
    }
