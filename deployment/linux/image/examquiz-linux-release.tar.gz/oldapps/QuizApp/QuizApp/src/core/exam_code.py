"""
Exam Code — Compact Binary Format
==================================
Code = URL-safe Base64 of 8 packed bytes (no padding):

  Byte  0-3  : uint32  — random exam ID (seeded with "Dilo" + DD-MM-YYYY)
  Byte  4-5  : uint16  — topic bitmask  (bit i = 1 → topic i included)
  Byte  6-7  : uint16  — duration in minutes

Result: 8 bytes → ceil(8/3)*4 = 12 Base64 chars → 11 chars after stripping '='

Example: NjA3ODg -> 11 chars instead of 28.
"""

import base64
import random
import struct
from datetime import date as _date

# Canonical topic list — bit position follows index order
TOPIC_ORDER = [
    "Python Basics",
    "Python Data Types",
    "Control Flow",
    "List Comprehension",
    "Modules de Base",
    "Input / Output (I/O)",
    "Object-Oriented Programming (OOP / POO)",
    "NumPy",
    "Pandas",
    "Data Visualization",
]

N_TOPICS = len(TOPIC_ORDER)   # 10  → fits in uint16 (max 16 bits)


def _today_str() -> str:
    return _date.today().strftime("%d-%m-%Y")


def _seed_id(date_str: str) -> int:
    """Generate a seeded exam ID (32-bit uint) from the date."""
    rng = random.Random("Dilo" + date_str)
    return rng.randint(0, 0xFFFF_FFFF)


def generate_exam_code(
    topics_mask: list[bool],
    duration: int,
    date_str: str | None = None,
) -> str:
    """
    Generate a compact URL-safe exam code (~11 chars).

    Parameters
    ----------
    topics_mask : list[bool]  — one per TOPIC_ORDER entry
    duration    : int         — exam duration in minutes (max 65535)
    date_str    : str | None  — DD-MM-YYYY (default: today)
    """
    if len(topics_mask) != N_TOPICS:
        raise ValueError(f"topics_mask must have {N_TOPICS} items")
    if date_str is None:
        date_str = _today_str()

    exam_id = _seed_id(date_str)
    bitmask = sum((1 << i) for i, v in enumerate(topics_mask) if v)

    packed = struct.pack(">IHH", exam_id, bitmask, int(duration))
    return base64.urlsafe_b64encode(packed).decode().rstrip("=")


def decode_exam_code(code: str, date_str: str | None = None) -> dict:
    """
    Decode and validate an exam code.

    Returns
    -------
    dict with keys: valid, exam_id, topics, topics_mask, duration, error
    """
    if date_str is None:
        date_str = _today_str()

    result = {
        "valid": False,
        "exam_id": None,
        "topics": [],
        "topics_mask": [],
        "duration": 0,
        "error": None,
    }

    try:
        # Restore Base64 padding
        padded = code + "=" * (-len(code) % 4)
        packed = base64.urlsafe_b64decode(padded)

        if len(packed) != 8:
            result["error"] = "Format de code invalide (longueur incorrecte)."
            return result

        exam_id, bitmask, duration = struct.unpack(">IHH", packed)

        # Validate exam_id against expected seed
        expected_id = _seed_id(date_str)
        if exam_id != expected_id:
            result["error"] = "Code invalide ou expiré (mauvaise date)."
            return result

        topics_mask = [(bitmask >> i) & 1 == 1 for i in range(N_TOPICS)]
        enabled = [t for t, m in zip(TOPIC_ORDER, topics_mask) if m]

        result["valid"] = True
        result["exam_id"] = str(exam_id)
        result["topics_mask"] = topics_mask
        result["topics"] = enabled
        result["duration"] = duration

    except Exception as exc:
        result["error"] = f"Erreur de décodage : {exc}"

    return result


def validate_exam_code(code: str, date_str: str | None = None) -> bool:
    return decode_exam_code(code, date_str)["valid"]
