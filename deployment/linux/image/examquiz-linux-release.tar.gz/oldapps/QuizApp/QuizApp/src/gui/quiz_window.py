"""Main exam window with timer, questions, and navigation"""

from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QLabel, QPushButton, QRadioButton, QCheckBox,
                            QButtonGroup, QGroupBox, QProgressBar,
                            QMessageBox, QFrame, QSpacerItem, QSizePolicy,
                            QScrollArea, QGridLayout, QApplication)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QPropertyAnimation, QEasingCurve, QRect, QEvent
from PyQt6.QtGui import QFont, QPalette, QColor, QKeyEvent, QCursor
import datetime


class QuizWindow(QMainWindow):
    exam_submitted = pyqtSignal(dict)  # Signal with user answers
    
    def __init__(self, quiz_engine, user_info, exam_config):
        super().__init__()
        self.quiz_engine = quiz_engine
        self.user_info = user_info
        self.exam_config = exam_config

        self.timer = QTimer()
        self.warnings_given = set()
        self.yes_button = None
        self.no_button = None
        self.exam_submitted_flag = False
        self.option_widgets = []  # Store option widgets
        self.visited_questions = set()
        self.flagged_questions = set()
        self.drawer_buttons = []
        self.nav_dot_buttons = []
        
        # Timer
        if user_info.get('mode') == 'training':
            self.time_limit = exam_config.get('duration', 60) * 60  # 15 minutes for training
            self.time_remaining = exam_config.get('duration', 60) * 60
        else:
            self.time_limit = exam_config.get('duration', 60) * 60
            self.time_remaining = exam_config.get('duration', 60) * 60
        
        # Security flags
        self.warning_count = 0
        self.max_warnings = 5 if user_info.get('mode') == 'training' else 3
        self.security_events = []
        self.last_security_reason = None
        self.last_security_warning_at = None
        self.security_paused = False
        self.security_ready_at = None
        self.security_status_label = None
        self.security_timer = QTimer()
        # Counter that is incremented when any QComboBox popup is open so that
        # enforce_secure_window does not misread those transient popups as cheating.
        self._combo_popup_count = 0
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFocus()

        self.init_ui()
        self.start_exam()
        if not self.user_info.get('test_mode'):
            self.start_security_monitoring()
    
    def init_ui(self):
        mode_label = "Training" if self.user_info.get('mode') == 'training' else ("Test" if self.user_info.get('test_mode') else "Exam")
        self.setWindowTitle(f"{mode_label}: {self.exam_config.get('title', 'Exam')}")
        
        if self.user_info.get('test_mode'):
            self.setWindowFlags(Qt.WindowType.Window)
            self.resize(1600, 1000)
            self.showNormal()
        else:
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
            self.showFullScreen()
        
        # Central widget with nice background
        central_widget = QWidget()
        central_widget.setObjectName("centralWidget")
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        self.main_layout = main_layout
        main_layout.setContentsMargins(14, 12, 14, 12)
        main_layout.setSpacing(10)
        
        # Header container
        header_frame = QFrame()
        header_frame.setObjectName("headerFrame")
        header_frame.setMinimumHeight(66)
        header_frame.setStyleSheet("""
            QFrame#headerFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                            stop:0 #3498db, stop:1 #2ecc71);
                border-radius: 10px;
            }
        """)
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(15, 0, 15, 0)  # Reduced margins
        
        # Menu toggle button
        self.menu_button = QPushButton("☰ Questions")
        self.menu_button.setMinimumSize(110, 36)
        self.menu_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.menu_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.menu_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.2);
                color: white;
                border: 1px solid rgba(255, 255, 255, 0.4);
                border-radius: 6px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.35);
            }
        """)
        self.menu_button.clicked.connect(self.toggle_drawer)
        header_layout.addWidget(self.menu_button)
        
        # Exam info on left
        info_container = QWidget()
        info_layout = QVBoxLayout(info_container)
        info_layout.setContentsMargins(0, 0, 0, 0)
        info_layout.setSpacing(3)  # Reduced spacing
        
        self.user_label = QLabel(f"{self.user_info.get('first_name', '')} {self.user_info.get('last_name', '')}")
        self.user_label.setStyleSheet("font-size: 12px; color: white; font-weight: 600;")  # Smaller font
        info_layout.addWidget(self.user_label)
        
        title_label = QLabel(self.exam_config['title'])
        title_label.setStyleSheet("font-size: 16px; color: white; font-weight: bold;")  # Smaller font
        info_layout.addWidget(title_label)
        
        header_layout.addWidget(info_container)
        header_layout.addStretch()
        
        # Timer widget
        timer_container = QWidget()
        timer_container.setMinimumWidth(104)
        timer_layout = QVBoxLayout(timer_container)
        timer_layout.setContentsMargins(0, 0, 0, 5)  # Reduced bottom margin
        timer_layout.setSpacing(3)  # Reduced spacing
        
        timer_title = QLabel("TIME REMAINING")
        timer_title.setStyleSheet("font-size: 9px; color: white; font-weight: bold; letter-spacing: 1px;")  # Smaller font
        timer_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        timer_layout.addWidget(timer_title)
        
        self.timer_label = QLabel()
        self.update_timer_display()
        self.timer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.timer_label.setMinimumWidth(96)
        timer_layout.addWidget(self.timer_label)
        
        header_layout.addWidget(timer_container)

        self.security_status_label = QLabel("")
        self.security_status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.security_status_label.setMinimumWidth(150)
        self.security_status_label.setMaximumWidth(260)
        self.security_status_label.setWordWrap(True)
        self.security_status_label.setStyleSheet("""
            QLabel {
                color: white;
                background-color: rgba(15, 118, 110, 0.28);
                border: 1px solid rgba(255, 255, 255, 0.35);
                border-radius: 8px;
                padding: 7px 10px;
                font-size: 11px;
                font-weight: 700;
            }
        """)
        self.security_status_label.setText("SECURE MODE")
        header_layout.addWidget(self.security_status_label)
        
        main_layout.addWidget(header_frame)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setMinimumHeight(18)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                border-radius: 5px;
                background-color: #ecf0f1;
                text-align: center;
                font-size: 11px;
                color: #2c3e50;
            }
            QProgressBar::chunk {
                background-color: #3498db;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(self.progress_bar)
        
        # Body layout holding collapsible navigation drawer and question card side-by-side
        body_layout = QHBoxLayout()
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(10)
        
        # 1. Slide-out Question Navigation Drawer
        self.nav_drawer = QFrame()
        self.nav_drawer.setObjectName("navDrawer")
        self.nav_drawer.setMinimumWidth(0)
        self.nav_drawer.setMaximumWidth(0)  # Start collapsed
        self.nav_drawer.setStyleSheet("""
            QFrame#navDrawer {
                background-color: white;
                border-radius: 12px;
                border: 2px solid #dfe6e9;
            }
        """)
        
        nav_drawer_layout = QVBoxLayout(self.nav_drawer)
        nav_drawer_layout.setContentsMargins(12, 12, 12, 12)
        nav_drawer_layout.setSpacing(10)
        
        drawer_title = QLabel("Questions Grid")
        drawer_title.setStyleSheet("font-size: 12px; font-weight: bold; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;")
        nav_drawer_layout.addWidget(drawer_title)
        
        self.drawer_scroll = QScrollArea()
        self.drawer_scroll.setWidgetResizable(True)
        self.drawer_scroll.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.drawer_scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        self.drawer_content = QWidget()
        self.drawer_content_layout = QGridLayout(self.drawer_content)
        self.drawer_content_layout.setContentsMargins(0, 0, 0, 0)
        self.drawer_content_layout.setSpacing(8)
        self.drawer_content_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        self.drawer_scroll.setWidget(self.drawer_content)
        nav_drawer_layout.addWidget(self.drawer_scroll)
        
        body_layout.addWidget(self.nav_drawer)
        
        # 2. Question card container - Takes most space
        self.question_card = QFrame()
        self.question_card.setObjectName("questionCard")
        self.question_card.setStyleSheet("""
            QFrame#questionCard {
                background-color: white;
                border-radius: 12px;
                border: 2px solid #dfe6e9;
            }
        """)
        self.question_card_layout = QVBoxLayout(self.question_card)
        self.question_card_layout.setContentsMargins(25, 20, 25, 20)  # Reduced margins
        self.question_card_layout.setSpacing(15)  # Reduced spacing
        
        body_layout.addWidget(self.question_card, 1)  # Takes priority space
        main_layout.addLayout(body_layout, 1)
        
        # Navigation container - Flexible height
        nav_frame = QFrame()
        nav_frame.setMinimumHeight(60)
        nav_layout = QVBoxLayout(nav_frame)  # Changed to VBox for better layout
        nav_layout.setContentsMargins(0, 5, 0, 5)  # Reduced margins
        nav_layout.setSpacing(5)  # Reduced spacing
        
        # Navigation buttons (Previous, Next, Submit) - Top row
        nav_buttons_container = QWidget()
        nav_buttons_layout = QHBoxLayout(nav_buttons_container)
        nav_buttons_layout.setContentsMargins(0, 0, 0, 0)
        
        # Previous button
        self.prev_button = QPushButton("← Previous")
        self.prev_button.setMinimumSize(96, 36)
        self.prev_button.clicked.connect(self.previous_question)
        self.prev_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)


        nav_buttons_layout.addWidget(self.prev_button)
        
        nav_buttons_layout.addStretch()
        
        # Next button
        self.next_button = QPushButton("Next →")
        self.next_button.setMinimumSize(96, 36)
        self.next_button.clicked.connect(self.next_question)
        self.next_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        nav_buttons_layout.addWidget(self.next_button)
        
        # Flag button
        self.flag_button = QPushButton("🚩 Signaler")
        self.flag_button.setMinimumSize(100, 36)
        self.flag_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.flag_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.flag_button.clicked.connect(self.toggle_flag_current_question)
        nav_buttons_layout.addWidget(self.flag_button)
        
        nav_buttons_layout.addStretch()
        
        # Submit button
        submit_text = "✓ Submit Training" if self.user_info.get('mode') == 'training' else "✓ Submit Exam"
        self.submit_button = QPushButton(submit_text)
        self.submit_button.setMinimumSize(118, 36)
        self.submit_button.clicked.connect(self.confirm_submit)
        self.submit_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        nav_buttons_layout.addWidget(self.submit_button)
        
        nav_layout.addWidget(nav_buttons_container)
        
        # Navigation dots container - Scrollable area
        nav_dots_container = QWidget()
        nav_dots_container.setMinimumHeight(48)
        nav_dots_main_layout = QVBoxLayout(nav_dots_container)
        nav_dots_main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create scroll area for dots
        dots_scroll_area = QScrollArea()
        dots_scroll_area.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        dots_scroll_area.setWidgetResizable(True)
        dots_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        dots_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        dots_scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: transparent;
            }
            QScrollArea > QWidget > QWidget {
                background-color: transparent;
            }
        """)
        
        # Container for dots
        self.nav_dots_widget = QWidget()
        self.nav_dots_layout = QHBoxLayout(self.nav_dots_widget)
        self.nav_dots_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.nav_dots_layout.setSpacing(5)  # Reduced spacing between dots
        self.nav_dots_layout.setContentsMargins(10, 5, 10, 5)
        
        dots_scroll_area.setWidget(self.nav_dots_widget)
        nav_dots_main_layout.addWidget(dots_scroll_area)
        
        nav_layout.addWidget(nav_dots_container)
        
        main_layout.addWidget(nav_frame)
        
        # Set overall styles
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f8fafc;
            }
            QPushButton {
                background-color: #3498db;
                color: white;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 600;
                border: 2px solid #2980b9;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:disabled {
                background-color: #bdc3c7;
                border-color: #95a5a6;
                color: #7f8c8d;
            }
            QPushButton#submitButton {
                background-color: #e74c3c;
                border-color: #c0392b;
            }
            QPushButton#submitButton:hover {
                background-color: #c0392b;
            }
            QLabel#timerLabel {
                font-size: 18px;
                font-weight: bold;
                color: white;
                background-color: #34495e;
                padding: 5px 10px;
                border-radius: 8px;
                border: 2px solid #2c3e50;
            }
        """)
        
        # Update timer label style
        self.timer_label.setObjectName("timerLabel")
        self.submit_button.setObjectName("submitButton")
        
        # Setup timer
        self.timer.timeout.connect(self.update_timer)
        self.timer.start(1000)

    def start_security_monitoring(self):
        """Continuously enforce fullscreen, focus, and mouse containment."""
        self.security_ready_at = datetime.datetime.now() + datetime.timedelta(seconds=2)
        self.security_timer.timeout.connect(self.enforce_secure_window)
        QTimer.singleShot(2000, lambda: self.security_timer.start(750))
        QTimer.singleShot(2100, self.enforce_secure_window)

    def record_security_event(self, reason):
        """Track suspicious exam-window behavior without interrupting normal navigation."""
        if self.exam_submitted_flag or self.security_paused or QApplication.activeModalWidget():
            return

        now = datetime.datetime.now()
        if self.security_ready_at and now < self.security_ready_at:
            return

        if self.last_security_warning_at and (now - self.last_security_warning_at).total_seconds() < 2:
            return

        self.last_security_warning_at = now
        self.security_events.append({
            'reason': reason,
            'time': now.isoformat(timespec='seconds')
        })
        self.warning_count += 1
        self.last_security_reason = reason

        if self.warning_count >= self.max_warnings:
            self.show_security_exit_message(reason)
        else:
            if self.warning_count == self.max_warnings - 1:
                self.apply_last_warning_style()
            self.show_security_warning(reason)

    def apply_last_warning_style(self):
        """Make the quiz visibly red when only one security warning remains."""
        if self.security_status_label:
            self.security_status_label.setText("LAST WARNING - NEXT VIOLATION EXITS")
            self.security_status_label.setStyleSheet("""
                QLabel {
                    color: white;
                    background-color: #dc2626;
                    border: 2px solid #fecaca;
                    border-radius: 8px;
                    padding: 7px 10px;
                    font-size: 11px;
                    font-weight: 800;
                }
            """)

        if hasattr(self, "question_card"):
            self.question_card.setStyleSheet("""
                QFrame#questionCard {
                    background-color: white;
                    border-radius: 12px;
                    border: 4px solid #dc2626;
                }
            """)

    def show_security_warning(self, reason):
        """Show one visible warning for a security violation."""
        remaining = self.max_warnings - self.warning_count
        warning = QMessageBox(self)
        warning.setWindowTitle("Security Warning")
        warning.setIcon(QMessageBox.Icon.Warning)
        warning.setText(f"Warning {self.warning_count}/{self.max_warnings}: {reason}")
        if remaining == 1:
            warning.setInformativeText(
                "This is your last warning. The next fullscreen, focus, mouse, "
                "keyboard, or close violation will exit the quiz."
            )
        else:
            warning.setInformativeText(
                f"Stay in fullscreen and keep focus on the quiz window. "
                f"{remaining} warning(s) remaining before the quiz exits."
            )
        warning.setStandardButtons(QMessageBox.StandardButton.Ok)
        warning.setStyleSheet("""
            QMessageBox {
                background-color: #fff7ed;
                font-size: 13px;
            }
            QLabel {
                color: #9a3412;
                font-weight: 600;
            }
        """)

        self.security_paused = True
        try:
            warning.exec()
        finally:
            self.last_security_warning_at = datetime.datetime.now()
            self.security_paused = False
            QTimer.singleShot(0, self.enforce_secure_window)

    def show_security_exit_message(self, reason):
        """Tell the user why the quiz is being exited after three warnings."""
        warning = QMessageBox(self)
        warning.setWindowTitle("Quiz Exited")
        warning.setIcon(QMessageBox.Icon.Critical)
        warning.setText("The quiz is being exited after 3 security warnings.")
        warning.setInformativeText(f"Last violation: {reason}")
        warning.setStandardButtons(QMessageBox.StandardButton.Ok)
        warning.setStyleSheet("""
            QMessageBox {
                background-color: #fef2f2;
                font-size: 13px;
            }
            QLabel {
                color: #991b1b;
                font-weight: 700;
            }
        """)

        self.security_paused = True
        try:
            warning.exec()
        finally:
            self.security_paused = False

        self.submit_exam("Quiz exited after 3 security warnings")

    def _child_text_widget_has_focus(self):
        """Return True when a text-input child widget currently has keyboard focus.

        All question types that require typing (simple_blank QLineEdit) or
        dropdown selection (matching QComboBox) are legitimate in-window
        interactions and must never be misread as a security violation.
        Supported widget classes: QLineEdit, QTextEdit, QPlainTextEdit, QComboBox.
        """
        from PyQt6.QtWidgets import QLineEdit, QTextEdit, QPlainTextEdit, QComboBox
        fw = QApplication.focusWidget()
        if fw is None:
            return False
        # Check type
        if isinstance(fw, (QLineEdit, QTextEdit, QPlainTextEdit, QComboBox)):
            # Verify it is a descendant of this window (not some other window)
            w = fw
            while w is not None:
                if w is self:
                    return True
                w = w.parent()
        return False

    def enforce_secure_window(self):
        """Restore secure window state if the user leaves it."""
        if self.exam_submitted_flag or self.security_paused or QApplication.activeModalWidget():
            return

        # A QComboBox dropdown is currently open inside this window – do NOT
        # treat the temporary focus/active-window change as a violation.
        if self._combo_popup_count > 0:
            return

        if not self.isFullScreen():
            self.record_security_event("Fullscreen was exited")
            self.showFullScreen()

        # Only check and restore active-window status when NO child text widget
        # has focus.  A QLineEdit (simple_blank) or QComboBox (matching) inside
        # this window legitimately holds keyboard focus while the student types;
        # stealing focus back every 750 ms would break typing completely.
        typing_in_child = self._child_text_widget_has_focus()

        if not typing_in_child:
            if not self.isActiveWindow():
                self.record_security_event("Quiz window lost focus")
                self.raise_()
                self.activateWindow()
            # Restore window-level focus only when no child input is being used.
            self.setFocus(Qt.FocusReason.ActiveWindowFocusReason)

        try:
            local_cursor_pos = self.mapFromGlobal(QCursor.pos())
            if not self.rect().contains(local_cursor_pos):
                self.record_security_event("Mouse left the quiz window")
                # QCursor.setPos is not supported on Wayland (pointer-warp
                # protocol unavailable).  Only call it on X11 / Windows / macOS.
                if QApplication.platformName() not in ('wayland', 'wayland-egl'):
                    try:
                        QCursor.setPos(self.mapToGlobal(self.rect().center()))
                    except Exception:
                        pass
        except Exception:
            pass
    
    def _decrement_combo_popup_count(self):
        """Called after a matching QComboBox popup closes (with a short delay)."""
        self._combo_popup_count = max(0, self._combo_popup_count - 1)

    def start_exam(self):
        """Start the exam"""
        self.quiz_engine.start_exam()
        self.load_current_question()
        self.create_navigation_dots()
        self.create_drawer_cells()
    
    def load_current_question(self):
        """Load and display current question"""
        question = self.quiz_engine.get_current_question()
        if not question:
            return
            
        # Mark as visited
        self.visited_questions.add(question["id"])
        
        # Clear previous question content
        self.clear_layout(self.question_card_layout)
        
        # Clear references to previous buttons
        self.yes_button = None
        self.no_button = None
        self.option_widgets = []
        
        # Question header with number and status
        progress = self.quiz_engine.get_progress()
        header_widget = QWidget()
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(0, 0, 0, 0)
        
        # Question number badge
        number_badge = QLabel(f"Q{progress['current']}")
        number_badge.setMinimumSize(46, 46)
        number_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        number_badge.setStyleSheet("""
            QLabel {
                background-color: #3498db;
                color: white;
                font-size: 18px;
                font-weight: bold;
                border-radius: 25px;
                border: 3px solid #2980b9;
            }
        """)
        header_layout.addWidget(number_badge)
        
        # Add difficulty badge if available
        if question and 'difficulty' in question:
            difficulty = question['difficulty']
            color = self.quiz_engine.get_difficulty_color(difficulty)
            label = self.quiz_engine.get_difficulty_label(difficulty)
            
            difficulty_badge = QLabel(label)
            difficulty_badge.setMinimumSize(68, 24)
            difficulty_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            difficulty_badge.setStyleSheet(f"""
                QLabel {{
                    background-color: {color};
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    border-radius: 12px;
                    padding: 2px;
                }}
            """)
            header_layout.addWidget(difficulty_badge)

        if question and question.get('topic'):
            topic_badge = QLabel(question.get('topic'))
            topic_badge.setMinimumWidth(72)
            topic_badge.setMaximumWidth(220)
            topic_badge.setMinimumHeight(24)
            topic_badge.setWordWrap(True)
            topic_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            topic_badge.setStyleSheet("""
                QLabel {
                    background-color: #eef2ff;
                    color: #3730a3;
                    font-size: 10px;
                    font-weight: bold;
                    border-radius: 12px;
                    padding: 2px 8px;
                    border: 1px solid #c7d2fe;
                }
            """)
            header_layout.addWidget(topic_badge)
        
        header_layout.addStretch()
        
        self.question_card_layout.addWidget(header_widget)
        self.question_card_layout.addSpacing(8)
        
        # Question text
        question_text = QLabel(question['text'])
        question_text.setWordWrap(True)
        question_text.setStyleSheet("""
            QLabel {
                font-size: 16px;
                color: #2c3e50;
                font-weight: 500;
                line-height: 1.3;
                padding: 12px 0;
                background-color: transparent;
                border: none;
                border-left: 4px solid #3498db;
            }
        """)
        self.question_card_layout.addWidget(question_text)
        
        # Add spacer
        self.question_card_layout.addSpacing(15)  # Reduced spacing
        
        # Options for MCQ or Intruder
        if question['type'] in ('mcq', 'intruder'):
            self.display_mcq_options(question)
        elif question['type'] == 'simple_blank':
            self.display_simple_blank_options(question)
        elif question['type'] == 'matching':
            self.display_matching_options(question)
        # Yes/No buttons
        else:
            self.display_yesno_options(question)
        
        # Add stretch to push everything up
        self.question_card_layout.addStretch()
        
        # Update progress bar
        p = progress['percentage']
        if p < 50:
            r = 255
            g = int(255 * (p / 50.0))
        else:
            g = 255
            r = int(255 * ((100 - p) / 50.0))
        color = f"rgb({r}, {g}, 0)"
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 1px solid #dcdde1;
                border-radius: 5px;
                text-align: center;
                color: #2f3640;
                font-weight: bold;
                background-color: #f5f6fa;
            }}
            QProgressBar::chunk {{
                background-color: {color};
                border-radius: 4px;
            }}
        """)
        self.progress_bar.setValue(int(progress['percentage']))
        self.progress_bar.setFormat(f"Progress: {progress['answered']}/{progress['total']} ({progress['percentage']:.1f}%)")
        
        # Update navigation buttons state
        self.prev_button.setEnabled(progress['current'] > 1)
        self.next_button.setEnabled(progress['current'] < progress['total'])
        
        # Update navigation dots
        self.update_navigation_dots()
        
        # Update flag button visual style
        self.update_flag_button_style()
        
        # Update drawer cells visual style
        self.update_drawer_cells()
        
        # Auto-save session state
        self.auto_save_state()
    
    def clear_layout(self, layout):
        """Clear all widgets from a layout"""
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
            elif item.layout():
                self.clear_layout(item.layout())
    
    def display_mcq_options(self, question):
        """Display MCQ options with cleaner, unified design"""
        options = question.get('display_options', question.get('options', []))
        correct_val = question.get('displayed_correct', question.get('original_correct', question.get('correct', [])))
        is_multiple = isinstance(correct_val, list) and len(correct_val) > 1
        
        # Clear previous option widgets
        self.option_widgets = []
        
        options_container = QWidget()
        options_layout = QVBoxLayout(options_container)
        options_layout.setSpacing(6)  # Reduced spacing
        
        if is_multiple:
            note = QLabel("⚠️ Multiple answers possible")
            note.setStyleSheet("color: #f39c12; font-size: 12px; font-style: italic; margin-bottom: 6px;")  # Smaller font
            options_layout.addWidget(note)
        
        user_answers = self.quiz_engine.user_answers.get(question['id'], {}).get('answer', [])
        
        # Adjust option height based on number of options
        option_height = 50 if len(options) <= 4 else 45  # Smaller for many options
        
        if is_multiple:
            # Use checkboxes for multiple selection
            for i, option_text in enumerate(options):
                # Create a custom widget for the option
                option_widget = QWidget()
                option_widget.setMinimumHeight(option_height)
                option_widget.setCursor(Qt.CursorShape.PointingHandCursor)
                option_widget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                
                # Create main layout
                main_layout = QHBoxLayout(option_widget)
                main_layout.setContentsMargins(12, 0, 12, 0)  # Reduced margins
                main_layout.setSpacing(10)  # Reduced spacing
                
                # Create custom selection indicator (checkbox style)
                indicator = QWidget()
                indicator.setMinimumSize(20, 20)
                indicator.setMaximumSize(20, 20)
                indicator.setStyleSheet("""
                    QWidget {
                        border: 2px solid #3498db;
                        border-radius: 3px;
                        background-color: %s;
                    }
                """ % ("#3498db" if i in user_answers else "white"))
                
                # Add checkmark for selected state
                if i in user_answers:
                    check_label = QLabel("✓")
                    check_label.setStyleSheet("color: white; font-size: 14px; font-weight: bold;")  # Smaller font
                    check_layout = QVBoxLayout(indicator)
                    check_layout.setContentsMargins(0, 0, 0, 0)
                    check_layout.addWidget(check_label, 0, Qt.AlignmentFlag.AlignCenter)
                
                main_layout.addWidget(indicator)
                
                # Add option text
                text_label = QLabel(option_text)
                text_label.setWordWrap(True)
                text_label.setStyleSheet("""
                    QLabel {
                        font-size: 14px;
                        color: #2c3e50;
                        padding: 6px 0;
                        background-color: transparent;
                        border-color: transparent;
                    }
                """)
                main_layout.addWidget(text_label, 1)
                
                # Style the entire widget
                option_widget.setStyleSheet("""
                    QWidget {
                        background-color: white;
                        border-radius: 6px;
                        border: 1px solid #e2e8f0;
                    }
                    QWidget:hover {
                        background-color: #f8fafc;
                        border-color: #3498db;
                    }
                """)
                
                # Store data for click handling
                option_widget.option_index = i
                option_widget.question_id = question['id']
                option_widget.is_selected = i in user_answers
                
                # Connect click
                option_widget.mousePressEvent = lambda event, idx=i: self.on_mcq_option_clicked(idx, question['id'], is_multiple=True)
                
                options_layout.addWidget(option_widget)
                self.option_widgets.append(option_widget)
            
        else:
            # Use radio buttons for single selection
            for i, option_text in enumerate(options):
                # Create a custom widget for the option
                option_widget = QWidget()
                option_widget.setMinimumHeight(option_height)
                option_widget.setCursor(Qt.CursorShape.PointingHandCursor)
                
                # Create main layout
                main_layout = QHBoxLayout(option_widget)
                main_layout.setContentsMargins(12, 0, 12, 0)  # Reduced margins
                main_layout.setSpacing(10)  # Reduced spacing
                
                # Create custom selection indicator (radio style)
                indicator = QWidget()
                indicator.setMinimumSize(20, 20)
                indicator.setMaximumSize(20, 20)
                indicator.setStyleSheet("""
                    QWidget {
                        border: 2px solid #3498db;
                        border-radius: 10px;
                        background-color: %s;
                    }
                """ % ("#3498db" if i in user_answers else "white"))
                
                # Add inner dot for selected state
                if i in user_answers:
                    inner_dot = QWidget()
                    inner_dot.setMinimumSize(10, 10)
                    inner_dot.setMaximumSize(10, 10)
                    inner_dot.setStyleSheet("background-color: white; border-radius: 5px;")
                    indicator_layout = QVBoxLayout(indicator)
                    indicator_layout.setContentsMargins(0, 0, 0, 0)
                    indicator_layout.addWidget(inner_dot, 0, Qt.AlignmentFlag.AlignCenter)
                
                main_layout.addWidget(indicator)
                
                # Add option text
                text_label = QLabel(option_text)
                text_label.setWordWrap(True)
                text_label.setStyleSheet("""
                    QLabel {
                        font-size: 14px;
                        color: #2c3e50;
                        padding: 6px 0;
                        background-color: transparent;
                        border-color: transparent;
                    }
                """)
                
                main_layout.addWidget(text_label, 1)
                
                # Style the entire widget
                option_widget.setStyleSheet("""
                    QWidget {
                        background-color: white;
                        border-radius: 6px;
                        border: 1px solid #e2e8f0;
                    }
                    QWidget:hover {
                        background-color: #f8fafc;
                        border-color: #3498db;
                    }
                """)
                
                # Store data for click handling
                option_widget.option_index = i
                option_widget.question_id = question['id']
                option_widget.is_selected = i in user_answers
                
                # Connect click
                option_widget.mousePressEvent = lambda event, idx=i: self.on_mcq_option_clicked(idx, question['id'], is_multiple=False)
                
                options_layout.addWidget(option_widget)
                self.option_widgets.append(option_widget)
        
        self.question_card_layout.addWidget(options_container)
    
    def on_mcq_option_clicked(self, option_index, question_id, is_multiple=False):
        """Handle clicking on MCQ options with custom widgets"""
        # Get current answers
        current_answers = self.quiz_engine.user_answers.get(question_id, {}).get('answer', [])
        
        if is_multiple:
            # Multiple selection - toggle
            if option_index in current_answers:
                current_answers.remove(option_index)
            else:
                current_answers.append(option_index)
        else:
            # Single selection - replace
            current_answers = [option_index]
        
        # Submit answer
        self.quiz_engine.submit_answer(question_id, current_answers)
        
        # Update visual state for all options
        self.update_mcq_option_styles(question_id, is_multiple)
        self.update_navigation_dots()
        
        # Add visual feedback
        self.animate_selection()
    
    def update_mcq_option_styles(self, question_id, is_multiple=False):
        """Update the visual style of all MCQ options based on selection"""
        user_answers = self.quiz_engine.user_answers.get(question_id, {}).get('answer', [])
        
        for option_widget in self.option_widgets:
            if option_widget.question_id == question_id:
                idx = option_widget.option_index
                is_selected = idx in user_answers
                
                # Update the indicator widget
                indicator = option_widget.findChild(QWidget)  # Find the indicator widget
                
                if indicator:
                    if is_multiple:
                        # Checkbox style
                        indicator.setStyleSheet("""
                            QWidget {
                                border: 2px solid #3498db;
                                border-radius: 3px;
                                background-color: %s;
                            }
                        """ % ("#3498db" if is_selected else "white"))
                        
                        # Update checkmark
                        if is_selected:
                            # Add checkmark if not already present
                            if indicator.layout() is None or indicator.layout().count() == 0:
                                check_label = QLabel("✓")
                                check_label.setStyleSheet("color: white; font-size: 14px; font-weight: bold;")
                                check_layout = QVBoxLayout(indicator)
                                check_layout.setContentsMargins(0, 0, 0, 0)
                                check_layout.addWidget(check_label, 0, Qt.AlignmentFlag.AlignCenter)
                        else:
                            # Remove checkmark
                            if indicator.layout():
                                while indicator.layout().count():
                                    item = indicator.layout().takeAt(0)
                                    if item.widget():
                                        item.widget().deleteLater()
                    else:
                        # Radio button style
                        indicator.setStyleSheet("""
                            QWidget {
                                border: 2px solid #3498db;
                                border-radius: 10px;
                                background-color: %s;
                            }
                        """ % ("#3498db" if is_selected else "white"))
                        
                        # Update inner dot
                        if is_selected:
                            # Add inner dot if not already present
                            if indicator.layout() is None or indicator.layout().count() == 0:
                                inner_dot = QWidget()
                                inner_dot.setMinimumSize(10, 10)
                                inner_dot.setMaximumSize(10, 10)
                                inner_dot.setStyleSheet("background-color: white; border-radius: 5px;")
                                indicator_layout = QVBoxLayout(indicator)
                                indicator_layout.setContentsMargins(0, 0, 0, 0)
                                indicator_layout.addWidget(inner_dot, 0, Qt.AlignmentFlag.AlignCenter)
                        else:
                            # Remove inner dot
                            if indicator.layout():
                                while indicator.layout().count():
                                    item = indicator.layout().takeAt(0)
                                    if item.widget():
                                        item.widget().deleteLater()
                
                # Update widget background for better visual feedback
                if is_selected:
                    option_widget.setStyleSheet("""
                        QWidget {
                            background-color: #f0f8ff;
                            border-radius: 6px;
                            border: 2px solid #3498db;
                        }
                    """)
                else:
                    option_widget.setStyleSheet("""
                        QWidget {
                            background-color: white;
                            border-radius: 6px;
                            border: 1px solid #e2e8f0;
                        }
                        QWidget:hover {
                            background-color: #f8fafc;
                            border-color: #3498db;
                        }
                    """)
    
    def display_simple_blank_options(self, question):
        """Display Fill-in-the-Blank textbox with a code editor box"""
        from PyQt6.QtWidgets import QLineEdit
        
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)
        
        # Display the code block nicely
        code_label = QLabel(question.get('code', ''))
        code_label.setStyleSheet("""
            QLabel {
                background-color: #1e1e2e;
                color: #cdd6f4;
                font-family: Consolas, "Fira Code", monospace;
                font-size: 14px;
                padding: 15px;
                border-radius: 8px;
                border: 1px solid #313244;
            }
        """)
        code_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(code_label)
        
        # Input block
        input_container = QWidget()
        input_layout = QHBoxLayout(input_container)
        input_layout.setContentsMargins(0, 5, 0, 0)
        
        input_label = QLabel("Votre réponse :")
        input_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #2c3e50;")
        input_layout.addWidget(input_label)
        
        line_edit = QLineEdit()
        line_edit.setMinimumHeight(40)
        line_edit.setStyleSheet("""
            QLineEdit {
                border: 2px solid #cbd5e1;
                border-radius: 6px;
                padding: 0 10px;
                font-size: 14px;
                background-color: white;
            }
            QLineEdit:focus {
                border-color: #3498db;
            }
        """)
        
        # Retrieve saved answer
        saved_answer = self.quiz_engine.user_answers.get(question['id'], {}).get('answer', '')
        line_edit.setText(saved_answer)
        
        # Connect change listener
        line_edit.textChanged.connect(lambda text: self.on_blank_text_changed(text, question['id']))
        
        input_layout.addWidget(line_edit, 1)
        layout.addWidget(input_container)
        
        self.question_card_layout.addWidget(container)

    def on_blank_text_changed(self, text, question_id):
        self.quiz_engine.submit_answer(question_id, text)
        self.update_navigation_dots()

    def update_matching_combos(self, left_items, right_items):
        # 1. Gather all currently selected values
        selected_values = {}
        for left, combo in self.combo_boxes.items():
            val = combo.currentData() or ""
            if val:
                selected_values[left] = val
                
        # 2. For each combo box, rebuild its items list
        for left, combo in self.combo_boxes.items():
            combo.blockSignals(True)
            current_val = selected_values.get(left, "")
            
            # Find values selected by OTHER combo boxes
            other_selected = {v for k, v in selected_values.items() if k != left}
            
            # Re-populate items
            combo.clear()
            combo.addItem("-- Sélectionner --", "")
            
            # Add right items if they are not selected by others, or if it is the current selection
            for val in right_items:
                if val not in other_selected or val == current_val:
                    combo.addItem(val, val)
                    
            # Set the selected index back
            if current_val:
                idx = combo.findText(current_val)
                if idx >= 0:
                    combo.setCurrentIndex(idx)
            else:
                combo.setCurrentIndex(0)
                
            combo.blockSignals(False)

    def display_matching_options(self, question):
        """Display Match the Columns dropdown grid"""
        from PyQt6.QtWidgets import QComboBox
        
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(12)
        
        left_items = question.get('left_items', [])
        right_items = question.get('right_items', [])
        
        # If left_items/right_items are empty but 'pairs' exists, build them
        if not left_items and question.get('pairs'):
            left_items = list(question['pairs'].keys())
            right_items = sorted(list(question['pairs'].values()))
            # Cache them on the question object for consistency
            question['left_items'] = left_items
            question['right_items'] = right_items
            
        grid = QGridLayout()
        grid.setSpacing(12)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        
        saved_answers = self.quiz_engine.user_answers.get(question['id'], {}).get('answer', {})
        self.combo_boxes = {}
        
        for i, left_item in enumerate(left_items):
            # Left item label
            left_label = QLabel(left_item)
            left_label.setStyleSheet("""
                QLabel {
                    font-size: 13px;
                    font-weight: 600;
                    color: #1e293b;
                    padding: 8px 12px;
                    background-color: #f8fafc;
                    border: 1px solid #e2e8f0;
                    border-radius: 6px;
                }
            """)
            grid.addWidget(left_label, i, 0)
            
            # Right item dropdown selector
            combo = QComboBox()
            combo.setMinimumHeight(38)
            combo.setStyleSheet("""
                QComboBox {
                    border: 1px solid #cbd5e1;
                    border-radius: 6px;
                    padding: 4px 10px;
                    font-size: 13px;
                    background-color: #ffffff;
                    color: #0f172a;
                }
                QComboBox:hover {
                    border-color: #38bdf8;
                    background-color: #f8fafc;
                }
                QComboBox:focus {
                    border: 2px solid #38bdf8;
                }
            """)

            # Patch showPopup / hidePopup so that the security monitor is
            # silenced while the dropdown list is visible.  Using a counter
            # (rather than a boolean) handles the edge-case where multiple
            # combo boxes could theoretically have overlapping open states.
            _orig_show = combo.showPopup
            _orig_hide = combo.hidePopup

            def _on_show(c=combo, f=_orig_show):
                self._combo_popup_count += 1
                f()

            def _on_hide(c=combo, f=_orig_hide):
                f()
                # Small delay so any focus-change events from the closing
                # popup are fully processed before we re-enable checks.
                QTimer.singleShot(250, self._decrement_combo_popup_count)

            combo.showPopup = _on_show
            combo.hidePopup = _on_hide

            self.combo_boxes[left_item] = combo
            
        # Rebuild combos with exclusions
        self.update_matching_combos(left_items, right_items)
        
        # Set saved values and connect signals
        for left_item in left_items:
            combo = self.combo_boxes[left_item]
            saved_val = saved_answers.get(left_item, "")
            if saved_val:
                combo.blockSignals(True)
                idx = combo.findText(saved_val)
                if idx >= 0:
                    combo.setCurrentIndex(idx)
                combo.blockSignals(False)
                
            # Connect listener
            combo.currentIndexChanged.connect(
                lambda _, item=left_item: self.on_matching_changed(question['id'], left_items, right_items)
            )
            grid.addWidget(combo, left_items.index(left_item), 1)
            
        # Do a sync/update in case some items are loaded
        self.update_matching_combos(left_items, right_items)
        
        layout.addLayout(grid)
        self.question_card_layout.addWidget(container)

    def on_matching_changed(self, question_id, left_items, right_items):
        # Update available selections in other combos
        self.update_matching_combos(left_items, right_items)
        
        # Gather all dropdown choices
        matches = {}
        for left_item, combo in self.combo_boxes.items():
            selected_val = combo.currentData() or ""
            if selected_val:
                matches[left_item] = selected_val
        self.quiz_engine.submit_answer(question_id, matches)
        self.update_navigation_dots()

    def display_yesno_options(self, question):
        """Display Yes/No buttons with better styling"""
        # Clear previous buttons safely
        if self.yes_button is not None:
            try:
                self.yes_button.deleteLater()
            except RuntimeError:
                pass  # Button was already deleted
            self.yes_button = None
        
        if self.no_button is not None:
            try:
                self.no_button.deleteLater()
            except RuntimeError:
                pass  # Button was already deleted
            self.no_button = None
        
        button_container = QWidget()
        button_layout = QHBoxLayout(button_container)
        button_layout.setSpacing(30)  # Reduced spacing
        button_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        user_answer = self.quiz_engine.user_answers.get(question['id'], {}).get('answer')
        
        # Yes button
        self.yes_button = QPushButton("✓ YES")
        self.yes_button.setMinimumSize(130, 54)
        self.yes_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        if user_answer == True:
            self.yes_button.setStyleSheet("""
                QPushButton {
                    background-color: #27ae60;
                    color: white;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 10px;
                    border: 3px solid #219653;
                }
                QPushButton:hover {
                    background-color: #219653;
                }
            """)
        else:
            self.yes_button.setStyleSheet("""
                QPushButton {
                    background-color: #d5f4e6;
                    color: #145a32;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 10px;
                    border: 3px solid #27ae60;
                }
                QPushButton:hover {
                    background-color: #27ae60;
                    color: white;
                }
            """)
        
        self.yes_button.clicked.connect(lambda: self.handle_yesno_answer(question['id'], True))
        
        # No button
        self.no_button = QPushButton("✗ NO")
        self.no_button.setMinimumSize(130, 54)
        self.no_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        if user_answer == False:
            self.no_button.setStyleSheet("""
                QPushButton {
                    background-color: #c0392b;
                    color: white;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 10px;
                    border: 3px solid #a93226;
                }
                QPushButton:hover {
                    background-color: #a93226;
                }
            """)
        else:
            self.no_button.setStyleSheet("""
                QPushButton {
                    background-color: #fadbd8;
                    color: #7b241c;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 10px;
                    border: 3px solid #c0392b;
                }
                QPushButton:hover {
                    background-color: #c0392b;
                    color: white;
                }
            """)
        
        self.no_button.clicked.connect(lambda: self.handle_yesno_answer(question['id'], False))
        
        button_layout.addWidget(self.yes_button)
        button_layout.addWidget(self.no_button)
        
        self.question_card_layout.addWidget(button_container)
        
        # Add some helpful text
        hint_label = QLabel("Click YES if the statement is correct, NO if it's incorrect")
        hint_label.setStyleSheet("color: #7f8c8d; font-size: 12px; font-style: italic; text-align: center; margin-top: 8px;")  # Smaller font
        self.question_card_layout.addWidget(hint_label)
    
    def handle_yesno_answer(self, question_id, answer):
        """Handle Yes/No answer selection"""
        self.quiz_engine.submit_answer(question_id, answer)
        self.update_navigation_dots()
        
        # Update button styles if buttons still exist
        if self.yes_button is not None and self.no_button is not None:
            if answer == True:
                self.yes_button.setStyleSheet("""
                    QPushButton {
                        background-color: #27ae60;
                        color: white;
                        font-size: 16px;
                        font-weight: bold;
                        border-radius: 10px;
                        border: 3px solid #219653;
                    }
                    QPushButton:hover {
                        background-color: #219653;
                    }
                """)
                self.no_button.setStyleSheet("""
                    QPushButton {
                        background-color: #fadbd8;
                        color: #7b241c;
                        font-size: 16px;
                        font-weight: bold;
                        border-radius: 10px;
                        border: 3px solid #c0392b;
                    }
                    QPushButton:hover {
                        background-color: #c0392b;
                        color: white;
                    }
                """)
            else:
                self.yes_button.setStyleSheet("""
                    QPushButton {
                        background-color: #d5f4e6;
                        color: #145a32;
                        font-size: 16px;
                        font-weight: bold;
                        border-radius: 10px;
                        border: 3px solid #27ae60;
                    }
                    QPushButton:hover {
                        background-color: #27ae60;
                        color: white;
                    }
                """)
                self.no_button.setStyleSheet("""
                    QPushButton {
                        background-color: #c0392b;
                        color: white;
                        font-size: 16px;
                        font-weight: bold;
                        border-radius: 10px;
                        border: 3px solid #a93226;
                    }
                    QPushButton:hover {
                        background-color: #a93226;
                    }
                """)
        
        # Visual feedback
        self.animate_selection()
    
    def animate_selection(self):
        """Add a subtle animation when an answer is selected"""
        animation = QPropertyAnimation(self.question_card, b"geometry")
        animation.setDuration(200)
        animation.setEasingCurve(QEasingCurve.Type.OutQuad)
        
        current_geometry = self.question_card.geometry()
        animation.setStartValue(current_geometry)
        animation.setKeyValueAt(0.5, QRect(
            current_geometry.x() - 8,
            current_geometry.y(),
            current_geometry.width(),
            current_geometry.height()
        ))
        animation.setEndValue(current_geometry)
        animation.start()
    
    def create_navigation_dots(self):
        """Create navigation dots for all questions"""
        self.clear_layout(self.nav_dots_layout)
        self.nav_dot_buttons = []  # Clear the list
        
        total_questions = len(self.quiz_engine.selected_questions)
        
        # Calculate appropriate dot size based on number of questions
        if total_questions > 50:
            dot_size = 30  # Very small for many questions
            font_size = 10
        elif total_questions > 30:
            dot_size = 32  # Smaller for many questions
            font_size = 10
        elif total_questions > 20:
            dot_size = 34  # Medium-small
            font_size = 11
        else:
            dot_size = 36  # Normal size
            font_size = 12
        
        for i in range(total_questions):
            dot = QPushButton(str(i + 1))
            dot.setMinimumSize(dot_size, dot_size)
            dot.setMaximumSize(dot_size + 6, dot_size + 6)
            dot.setCursor(Qt.CursorShape.PointingHandCursor)
            dot.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            
            # Store reference to button
            self.nav_dot_buttons.append(dot)
            
            # Proper lambda with default argument
            dot.clicked.connect(lambda checked, idx=i: self.go_to_question(idx))
            
            self.nav_dots_layout.addWidget(dot)
        
        self.update_navigation_dots()
    
    def update_navigation_dots(self):
        """Update navigation dots appearance"""
        current_idx = self.quiz_engine.current_question_index
        
        for i, button in enumerate(self.nav_dot_buttons):
            if button:
                question_id = self.quiz_engine.selected_questions[i]['id']
                has_answer = question_id in self.quiz_engine.user_answers
                is_flagged = question_id in self.flagged_questions
                is_visited = question_id in self.visited_questions
                
                # Determine colors based on state
                if i == current_idx:
                    bg = "#3498db"
                    border = "#2980b9"
                    text = "white"
                elif is_flagged:
                    bg = "#fee2e2"
                    border = "#dc2626"
                    text = "#dc2626"
                elif has_answer:
                    bg = "#2ecc71"
                    border = "#27ae60"
                    text = "white"
                elif is_visited:
                    bg = "#fef3c7"
                    border = "#f59e0b"
                    text = "#b45309"
                else:
                    bg = "#ecf0f1"
                    border = "#bdc3c7"
                    text = "#7f8c8d"
                
                button.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {bg};
                        color: {text};
                        border: 2px solid {border};
                        border-radius: 15px;
                        font-weight: bold;
                        font-size: {self.get_dot_font_size(i)}px;
                    }}
                """)
    
    def get_dot_font_size(self, index):
        """Get appropriate font size for dot based on question number"""
        if index + 1 > 99:
            return 9
        elif index + 1 > 50:
            return 10
        else:
            return 11
    
    def go_to_question(self, index):
        """Navigate to specific question"""
        if 0 <= index < len(self.quiz_engine.selected_questions):
            self.quiz_engine.current_question_index = index
            self.load_current_question()
    
    def previous_question(self):
        """Navigate to previous question"""
        if self.quiz_engine.previous_question():
            self.load_current_question()
    
    def next_question(self):
        """Navigate to next question"""
        if self.quiz_engine.next_question():
            self.load_current_question()

    def toggle_drawer(self):
        is_collapsed = self.nav_drawer.maximumWidth() == 0
        
        self.drawer_animation = QPropertyAnimation(self.nav_drawer, b"maximumWidth")
        self.drawer_animation.setDuration(250)
        self.drawer_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)
        
        if is_collapsed:
            self.drawer_animation.setStartValue(0)
            self.drawer_animation.setEndValue(210)
            self.nav_drawer.setMinimumWidth(210)
        else:
            self.drawer_animation.setStartValue(210)
            self.drawer_animation.setEndValue(0)
            
            def on_animation_finished():
                if self.nav_drawer.maximumWidth() == 0:
                    self.nav_drawer.setMinimumWidth(0)
            self.drawer_animation.finished.connect(on_animation_finished)
            
        self.drawer_animation.start()

    def create_drawer_cells(self):
        # Clear drawer layout
        while self.drawer_content_layout.count():
            item = self.drawer_content_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
                
        self.drawer_buttons = []
        total = len(self.quiz_engine.selected_questions)
        columns = 4
        for idx in range(total):
            btn = QPushButton(str(idx + 1))
            btn.setFixedSize(36, 36)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            
            # Connect navigation
            btn.clicked.connect(lambda checked=False, i=idx: self.go_to_question(i))
            
            row = idx // columns
            col = idx % columns
            self.drawer_content_layout.addWidget(btn, row, col)
            self.drawer_buttons.append(btn)
            
        self.update_drawer_cells()

    def update_drawer_cells(self):
        if not hasattr(self, "drawer_buttons") or not self.drawer_buttons:
            return
            
        current_idx = self.quiz_engine.current_question_index
        
        for i, button in enumerate(self.drawer_buttons):
            if button:
                question_id = self.quiz_engine.selected_questions[i]['id']
                has_answer = question_id in self.quiz_engine.user_answers
                is_flagged = question_id in self.flagged_questions
                is_visited = question_id in self.visited_questions
                
                # Determine colors based on state
                if i == current_idx:
                    bg = "#2563eb"
                    border = "#1d4ed8"
                    text = "white"
                elif is_flagged:
                    bg = "#fee2e2"
                    border = "#dc2626"
                    text = "#dc2626"
                elif has_answer:
                    bg = "#dcfce7"
                    border = "#10b981"
                    text = "#15803d"
                elif is_visited:
                    bg = "#fef3c7"
                    border = "#f59e0b"
                    text = "#b45309"
                else:
                    bg = "#f1f5f9"
                    border = "#cbd5e1"
                    text = "#64748b"
                    
                button.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {bg};
                        color: {text};
                        border: 2px solid {border};
                        border-radius: 6px;
                        font-weight: bold;
                        font-size: 11px;
                    }}
                    QPushButton:hover {{
                        border-color: #2563eb;
                    }}
                """)

    def toggle_flag_current_question(self):
        question = self.quiz_engine.get_current_question()
        if not question:
            return
        qid = question["id"]
        if qid in self.flagged_questions:
            self.flagged_questions.remove(qid)
        else:
            self.flagged_questions.add(qid)
            
        self.update_flag_button_style()
        self.update_navigation_dots()
        self.update_drawer_cells()
        self.auto_save_state()

    def update_flag_button_style(self):
        question = self.quiz_engine.get_current_question()
        if not question:
            return
        qid = question["id"]
        if qid in self.flagged_questions:
            self.flag_button.setText("🚩 Flagged")
            self.flag_button.setStyleSheet("""
                QPushButton {
                    background-color: #fee2e2;
                    color: #dc2626;
                    border: 2px solid #fca5a5;
                    border-radius: 6px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #fca5a5;
                }
            """)
        else:
            self.flag_button.setText("🚩 Signaler")
            self.flag_button.setStyleSheet("""
                QPushButton {
                    background-color: #f1f5f9;
                    color: #475569;
                    border: 2px solid #cbd5e1;
                    border-radius: 6px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #cbd5e1;
                }
            """)

    def auto_save_state(self):
        if self.exam_submitted_flag:
            return
        from core.session_recovery import save_session
        save_session(
            session_type="quiz",
            user_info=self.user_info,
            time_remaining=self.time_remaining,
            current_index=self.quiz_engine.current_question_index,
            flagged_questions=list(self.flagged_questions),
            user_answers=self.quiz_engine.user_answers,
            visited_questions=list(self.visited_questions),
            questions=self.quiz_engine.selected_questions,
            exam_config=self.exam_config
        )
    
    def update_timer(self):
        """Update timer and check for warnings"""
        self.time_remaining -= 1
        
        if self.time_remaining <= 0:
            self.timer.stop()
            self.submit_exam("Time's up!")
            return
        
        self.update_timer_display()
        
        # Check for warnings — only fire in the first 2 seconds of that minute
        minutes_left = self.time_remaining // 60
        seconds_in_minute = self.time_remaining % 60
        if minutes_left in self.exam_config.get('warning_times', [10, 5]) and seconds_in_minute >= 58:
            if minutes_left not in self.warnings_given:
                self.warnings_given.add(minutes_left)
                self.show_warning(f"⚠️ {minutes_left} minutes remaining!")
        
        # Update timer color based on time remaining
        if self.time_remaining < 300:  # 5 minutes
            if (self.time_remaining % 2) == 0:
                self.timer_label.setStyleSheet("""
                    QLabel {
                        font-size: 18px;
                        font-weight: bold;
                        color: white;
                        background-color: #ef4444;
                        padding: 5px 10px;
                        border-radius: 8px;
                        border: 2px solid #b91c1c;
                    }
                """)
            else:
                self.timer_label.setStyleSheet("""
                    QLabel {
                        font-size: 18px;
                        font-weight: bold;
                        color: #b91c1c;
                        background-color: #fee2e2;
                        padding: 5px 10px;
                        border-radius: 8px;
                        border: 2px solid #fca5a5;
                    }
                """)
        elif self.time_remaining < 600:  # 10 minutes
            self.timer_label.setStyleSheet("""
                QLabel {
                    font-size: 18px;
                    font-weight: bold;
                    color: white;
                    background-color: #f39c12;
                    padding: 5px 10px;
                    border-radius: 8px;
                    border: 2px solid #d68910;
                }
            """)
        else:
            self.timer_label.setStyleSheet("""
                QLabel {
                    font-size: 18px;
                    font-weight: bold;
                    color: white;
                    background-color: #34495e;
                    padding: 5px 10px;
                    border-radius: 8px;
                    border: 2px solid #2c3e50;
                }
            """)
    
    def update_timer_display(self):
        """Update timer display"""
        hours = self.time_remaining // 3600
        minutes = (self.time_remaining % 3600) // 60
        seconds = self.time_remaining % 60
        self.timer_label.setText(f"{hours:02d}:{minutes:02d}:{seconds:02d}")

    def resizeEvent(self, event):
        """Keep fullscreen quiz spacing comfortable across screen sizes."""
        width = event.size().width()
        compact = width < 760
        margin_x = 8 if compact else 14
        margin_y = 8 if compact else 12

        if hasattr(self, "main_layout"):
            self.main_layout.setContentsMargins(margin_x, margin_y, margin_x, margin_y)
            self.main_layout.setSpacing(8 if compact else 10)

        if getattr(self, "security_status_label", None) is not None:
            self.security_status_label.setVisible(width >= 620)

        super().resizeEvent(event)
    
    def show_warning(self, message):
        """Show warning message"""
        warning = QMessageBox(self)
        warning.setWindowTitle("⏰ Time Warning")
        warning.setText(message)
        warning.setIcon(QMessageBox.Icon.Warning)
        warning.setStandardButtons(QMessageBox.StandardButton.Ok)
        warning.setStyleSheet("""
            QMessageBox {
                background-color: #fff9e6;
                font-size: 13px;
            }
            QLabel {
                color: #d35400;
                font-weight: bold;
                font-size: 13px;
            }
        """)
        self.security_paused = True
        try:
            warning.exec()
        finally:
            self.security_paused = False
            QTimer.singleShot(0, self.enforce_secure_window)
    
    def confirm_submit(self):
        """Confirm exam submission"""
        answered = len(self.quiz_engine.user_answers)
        total = len(self.quiz_engine.selected_questions)
        is_training = self.user_info.get('mode') == 'training'
        
        confirm_dialog = QMessageBox(self)
        confirm_dialog.setWindowTitle("Submit Training" if is_training else "Submit Exam")
        confirm_dialog.setText(
            "Are you sure you want to submit your training?"
            if is_training else
            "Are you sure you want to submit your exam?"
        )
        confirm_dialog.setInformativeText(f"You have answered {answered} out of {total} questions.")
        confirm_dialog.setIcon(QMessageBox.Icon.Question)
        confirm_dialog.setStandardButtons(
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        confirm_dialog.setDefaultButton(QMessageBox.StandardButton.No)
        confirm_dialog.setStyleSheet("""
            QMessageBox {
                background-color: white;
                font-size: 13px;
            }
            QLabel {
                color: #2c3e50;
                font-size: 13px;
            }
        """)
        
        self.security_paused = True
        try:
            reply = confirm_dialog.exec()
        finally:
            self.security_paused = False
            QTimer.singleShot(0, self.enforce_secure_window)
        
        if reply == QMessageBox.StandardButton.Yes:
            self.submit_exam()
    
    def submit_exam(self, reason="Exam submitted"):
        """Submit the exam"""
        self.timer.stop()
        self.security_timer.stop()
        self.exam_submitted_flag = True
        
        from core.session_recovery import clear_session
        clear_session()
        
        # Collect results
        results = {
            'user_info': self.user_info,
            'answers': self.quiz_engine.user_answers,
            'time_remaining': self.time_remaining,
            'submission_reason': reason
        }
        
        self.exam_submitted.emit(results)
        self.close()
    
    def closeEvent(self, event):
        """Handle window close event"""
        if self.user_info.get('test_mode'):
            event.accept()
            return
        if not self.exam_submitted_flag:
            self.record_security_event("Attempted to close the quiz window")
            event.ignore()
        else:
            event.accept()

    def changeEvent(self, event):
        """Detect fullscreen loss and activation changes."""
        if self.user_info.get('test_mode'):
            super().changeEvent(event)
            return
        if event.type() == QEvent.Type.WindowStateChange and not self.isFullScreen():
            self.record_security_event("Window state changed")
            QTimer.singleShot(0, self.showFullScreen)
        elif event.type() == QEvent.Type.ActivationChange and not self.isActiveWindow():
            self.record_security_event("Active window changed")
            QTimer.singleShot(0, self.enforce_secure_window)

        super().changeEvent(event)

    def focusOutEvent(self, event):
        """Recover focus when another window receives it."""
        if self.user_info.get('test_mode'):
            event.accept()
            return
        self.record_security_event("Keyboard focus left the quiz window")
        QTimer.singleShot(0, self.enforce_secure_window)
        event.accept()

    def leaveEvent(self, event):
        """Keep the mouse pointer inside the fullscreen quiz area."""
        if self.user_info.get('test_mode'):
            event.accept()
            return
        self.record_security_event("Mouse left the quiz area")
        QCursor.setPos(self.mapToGlobal(self.rect().center()))
        event.accept()

    def is_last_question(self) -> bool:
        return (
            self.quiz_engine.current_question_index
            == len(self.quiz_engine.selected_questions) - 1
        )

    def keyPressEvent(self, event):
        """Global keyboard navigation handler"""
        if self.user_info.get('test_mode'):
            key = event.key()
            modifiers = event.modifiers()
            focus_widget = QApplication.focusWidget()
            from PyQt6.QtWidgets import QLineEdit, QTextEdit, QPlainTextEdit
            is_editing = isinstance(focus_widget, (QLineEdit, QTextEdit, QPlainTextEdit))
            
            if not is_editing:
                if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and modifiers == Qt.KeyboardModifier.NoModifier:
                    if self.is_last_question():
                        self.confirm_submit()
                    else:
                        self.next_question()
                    event.accept()
                    return
                if key in (Qt.Key.Key_Left, Qt.Key.Key_Down) and modifiers == Qt.KeyboardModifier.NoModifier:
                    self.previous_question()
                    event.accept()
                    return
                if key in (Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Space) and modifiers == Qt.KeyboardModifier.NoModifier:
                    self.next_question()
                    event.accept()
                    return
            super().keyPressEvent(event)
            return

        key = event.key()
        modifiers = event.modifiers()

        # ENTER / RETURN
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and modifiers == Qt.KeyboardModifier.NoModifier:
            if self.is_last_question():
                self.confirm_submit()
            else:
                self.next_question()
            event.accept()
            return

        # LEFT ARROW
        if key in (Qt.Key.Key_Left, Qt.Key.Key_Down) and modifiers == Qt.KeyboardModifier.NoModifier:
            self.previous_question()
            event.accept()
            return

        # RIGHT ARROW
        if key in (Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Space) and modifiers == Qt.KeyboardModifier.NoModifier:
            self.next_question()
            event.accept()
            return

        # ESCAPE (disabled)
        if key == Qt.Key.Key_Escape:
            self.record_security_event("Escape key blocked")
            event.accept()
            return

        self.record_security_event(f"Blocked key: {key}")
        event.accept()
