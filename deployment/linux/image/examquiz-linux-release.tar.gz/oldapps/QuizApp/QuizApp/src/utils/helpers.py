"""
Utility functions
"""

import base64
import json
import os
from datetime import datetime
from typing import Dict, Any


def decode_base64_string(encoded: str) -> str:
    """Decode base64 string"""
    try:
        return base64.b64decode(encoded).decode('utf-8')
    except:
        return encoded


def encode_base64_string(text: str) -> str:
    """Encode string to base64"""
    return base64.b64encode(text.encode('utf-8')).decode('utf-8')


def save_results(results: Dict[str, Any], filename: str = None) -> str:
    """Save results to JSON file"""
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"exam_results_{timestamp}.json"
    
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    return filename


def load_results(filename: str) -> Dict[str, Any]:
    """Load results from JSON file"""
    with open(filename, 'r', encoding='utf-8') as f:
        return json.load(f)


def ensure_directory(path: str) -> None:
    """Ensure directory exists"""
    os.makedirs(path, exist_ok=True)


def format_time(seconds: int) -> str:
    """Format seconds to HH:MM:SS"""
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


# Helper function to create encrypted exam files
# exam_creator.py
import json
from core.exam_loader import ExamLoader

def create_sample_exam():
    exam_data = {
        'config': {
            'duration': 60,
            'points_per_question': 1,
            'penalty_per_question': 0.25,
            'shuffle_questions': True,
            'shuffle_options': True,
            'title': 'Python Certification Exam',
            'version': '1.0'
        },
        'questions': [
            # Your questions here
        ]
    }
    
    loader = ExamLoader()
    loader.encrypt_exam(exam_data, 'exam.quiz')
    print("Exam created: exam.quiz")
"""Helper functions for difficulty colors and translations"""
from PyQt6.QtGui import QColor


class QuizHelpers:
    @staticmethod
    def get_difficulty_color(difficulty: str) -> str:
        """Get hex color for difficulty level"""
        colors = {
            'easy': '#10b981',    # Green
            'medium': '#f59e0b',  # Yellow/Orange
            'hard': '#ef4444',    # Red
            'very hard': '#7c3aed',
            'unknown': '#6b7280'  # Gray
        }
        return colors.get(difficulty.lower(), '#6b7280')
    
    @staticmethod
    def get_difficulty_label_fr(difficulty: str) -> str:
        """Get French label for difficulty"""
        labels = {
            'easy': 'Facile',
            'medium': 'Moyen',
            'hard': 'Difficile',
            'very hard': 'Tres difficile',
            'unknown': 'Inconnu'
        }
        return labels.get(difficulty.lower(), 'Inconnu')
    
    @staticmethod
    def get_status_label_fr(status: str) -> str:
        """Get French label for answer status"""
        labels = {
            'correct': 'Correct',
            'incorrect': 'Incorrect',
            'unanswered': 'Non répondu',
            'unknown': 'Inconnu'
        }
        return labels.get(status.lower(), 'Inconnu')
    
    @staticmethod
    def get_performance_color(percentage: float) -> str:
        """Get color based on performance percentage"""
        if percentage >= 80:
            return '#10b981'  # Green
        elif percentage >= 60:
            return '#f59e0b'  # Yellow/Orange
        else:
            return '#ef4444'  # Red
    
    @staticmethod
    def get_performance_label(percentage: float) -> str:
        """Get performance label based on percentage"""
        if percentage >= 90:
            return "Excellent"
        elif percentage >= 80:
            return "Très bien"
        elif percentage >= 70:
            return "Bien"
        elif percentage >= 60:
            return "Satisfaisant"
        elif percentage >= 50:
            return "Passable"
        else:
            return "À améliorer"

if __name__ == "__main__":
    # This is for testing
    create_sample_exam()  # Uncomment to create example encrypted exam
    pass
