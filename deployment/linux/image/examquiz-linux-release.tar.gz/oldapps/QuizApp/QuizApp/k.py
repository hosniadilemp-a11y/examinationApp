#!/usr/bin/env python3
"""
AMR Novel Gene Discovery Pipeline – Phase 11 (Optimized for Kaggle)
===================================================================
- Skips Prokka when RefSeq GFF is available (95%+ of cases).
- Downloads & renames GFF directly → each genome processes in ~10 seconds.
- Panaroo runs in 'moderate' mode to reduce memory/time.
- Optional swap creation for low‑memory Kaggle instances.
- Checkpoint/resume fully preserved.
"""

import os
import sys
import argparse
import subprocess
import urllib.request
import urllib.parse
import json
import gzip
import shutil
import csv
import time
import ssl
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

# ---------- Progress bar fallback ----------
try:
    from tqdm import tqdm
except ImportError:
    class tqdm:
        def __init__(self, iterable=None, total=None, desc=""):
            self.iterable = iterable
            self.total = total if total is not None else (len(iterable) if iterable else 0)
            self.desc = desc
            self.n = 0
            self.start_time = time.time()
        def __iter__(self):
            for item in self.iterable:
                yield item
                self.update(1)
        def update(self, n=1):
            self.n += n
            percent = min(100, int(self.n / self.total * 100)) if self.total > 0 else 0
            elapsed = time.time() - self.start_time
            sys.stdout.write(f"\r{self.desc}: [{self.n}/{self.total}] {percent}% ({elapsed:.1f}s elapsed)")
            sys.stdout.flush()
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc_val, exc_tb):
            self.close()
        def close(self):
            print()

# ---------- SSL & paths ----------
try:
    ssl._create_default_https_context = ssl._create_unverified_context
except AttributeError:
    pass

WORKING_DIR = "/kaggle/working" if os.path.exists("/kaggle/working") else os.getcwd()
GENOMES_DIR = os.path.join(WORKING_DIR, "genomes")
PROKKA_DIR = os.path.join(WORKING_DIR, "prokka_out")
PANAROO_DIR = os.path.join(WORKING_DIR, "panaroo_out")
CHECKPOINT_FILE = os.path.join(WORKING_DIR, "pangenome_checkpoint.json")
MAMBA_BIN = os.path.join(WORKING_DIR, "micromamba")
ENV_DIR = os.path.join(WORKING_DIR, "pan_env")
ERRORS_FILE = os.path.join(WORKING_DIR, "errors.log")

os.makedirs(GENOMES_DIR, exist_ok=True)
os.makedirs(PROKKA_DIR, exist_ok=True)
os.makedirs(PANAROO_DIR, exist_ok=True)

state_lock = threading.Lock()
state = {}

# ---------- Checkpoint helpers ----------
def load_checkpoint():
    if os.path.exists(CHECKPOINT_FILE):
        try:
            with open(CHECKPOINT_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {
        "ncbi_query_completed": False,
        "assembly_metadata": {},
        "completed_annotations": [],
        "failed_annotations": {},
        "panaroo_completed": False,
        "fasttree_completed": False,
        "packaged_completed": False
    }

def save_checkpoint(current_state):
    try:
        temp_file = CHECKPOINT_FILE + ".tmp"
        with open(temp_file, 'w') as f:
            json.dump(current_state, f, indent=4)
        os.replace(temp_file, CHECKPOINT_FILE)
    except Exception as e:
        print(f"[ERROR] Failed to save checkpoint: {e}")

def write_progress_json(phase, percent, processed, total, errors):
    progress_data = {
        "timestamp": time.time(),
        "phase": phase,
        "percent": percent,
        "processed": processed,
        "total": total,
        "errors": errors
    }
    try:
        with open(os.path.join(WORKING_DIR, "pangenome_progress.json"), 'w') as f:
            json.dump(progress_data, f, indent=4)
    except:
        pass

def print_status_card(phase, completed, total, errors_count):
    percent = int((completed / total) * 100) if total > 0 else 0
    bar_width = 30
    filled = int(percent / 100 * bar_width)
    bar = "█" * filled + "░" * (bar_width - filled)
    print("\n" + "="*60)
    print(f" PANGENOME PIPELINE STATUS - {phase.upper()}")
    print("="*60)
    print(f" Progress:    {bar} {percent}% ({completed}/{total})")
    print(f" Errors:      {errors_count} genomes failed")
    print(f" Time:        {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")
    sys.stdout.flush()

# ---------- Tool wrappers ----------
def run_bio_cmd(cmd_list, conda_env):
    """Run a command either inside a conda env or the local micromamba env."""
    if conda_env:
        full_cmd = ["conda", "run", "-n", conda_env] + cmd_list
        my_env = os.environ.copy()
    else:
        full_cmd = [MAMBA_BIN, "run", "-p", ENV_DIR] + cmd_list
        my_env = os.environ.copy()
        my_env["PATH"] = f"{ENV_DIR}/bin:" + my_env["PATH"]
    res = subprocess.run(full_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=my_env, text=True)
    return res.returncode == 0, res.stdout, res.stderr

def run_bio_cmd_with_redirect(cmd_list, stdout_file, conda_env):
    if conda_env:
        full_cmd = ["conda", "run", "-n", conda_env] + cmd_list
        my_env = os.environ.copy()
    else:
        full_cmd = [MAMBA_BIN, "run", "-p", ENV_DIR] + cmd_list
        my_env = os.environ.copy()
        my_env["PATH"] = f"{ENV_DIR}/bin:" + my_env["PATH"]
    with open(stdout_file, 'w') as out_f:
        res = subprocess.run(full_cmd, stdout=out_f, stderr=subprocess.PIPE, env=my_env, text=True)
    return res.returncode == 0

# ---------- Dependency installation ----------
def install_dependencies():
    print("=== Installing micromamba and bioinformatics tools ===")
    if not os.path.exists(MAMBA_BIN):
        print("Downloading micromamba...")
        url = "https://github.com/mamba-org/micromamba-releases/releases/latest/download/micromamba-linux-64"
        try:
            urllib.request.urlretrieve(url, MAMBA_BIN)
        except Exception as e:
            print(f"Failed to download micromamba: {e}")
            sys.exit(1)
        os.chmod(MAMBA_BIN, 0o755)
    if not os.path.exists(ENV_DIR):
        print("Creating bioconda environment (Prokka, Panaroo, FastTree)...")
        mamba_root = os.path.join(WORKING_DIR, "mamba_root")
        cmd = [MAMBA_BIN, "create", "-r", mamba_root, "-p", ENV_DIR, "-c", "bioconda", "-c", "conda-forge", "-y",
               "prokka", "panaroo", "fasttree"]
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if res.returncode != 0:
            print("[ERROR] Failed to create conda environment.")
            print("STDERR:", res.stderr)
            sys.exit(1)
        print("Bioconda environment ready.")
    else:
        print("Bioconda environment already exists.")

# ---------- Optional swap file (Kaggle memory boost) ----------
def create_swap_if_needed(target_gb=10):
    """Create a swap file if total memory < 16 GB and swap < 1 GB."""
    try:
        with open('/proc/meminfo') as f:
            mem = f.read()
        total_mem = int([l for l in mem.splitlines() if 'MemTotal' in l][0].split()[1])  # kB
        swap_total = int([l for l in mem.splitlines() if 'SwapTotal' in l][0].split()[1])
        if total_mem < 16 * 1024 * 1024 and swap_total < 1024 * 1024:
            print(f"Total RAM: {total_mem//1024} MB, Swap: {swap_total//1024} MB → creating {target_gb} GB swap...")
            os.system(f"sudo fallocate -l {target_gb}G /swapfile")
            os.system("sudo chmod 600 /swapfile")
            os.system("sudo mkswap /swapfile")
            os.system("sudo swapon /swapfile")
            print("Swap enabled.")
    except Exception as e:
        print(f"Warning: swap creation failed ({e}). Continuing with limited RAM.")

# ---------- NCBI queries ----------
def get_ncbi_assembly_ids(term, retmax=100):
    """Search NCBI Assembly and return list of UIDs."""
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=assembly&term={urllib.parse.quote(term)}&retmax={retmax}&retmode=json"
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode())
                return data.get("esearchresult", {}).get("idlist", [])
        except Exception as e:
            time.sleep(2 ** attempt)
    return []

def get_assembly_ftp_details(uid_list):
    """Return dict: assembly_accession → ftp_path (prefer RefSeq)."""
    details = {}
    chunk_size = 200
    for i in range(0, len(uid_list), chunk_size):
        chunk = uid_list[i:i+chunk_size]
        url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=assembly&id={','.join(chunk)}&retmode=json"
        for attempt in range(5):
            try:
                time.sleep(0.5)
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    data = json.loads(resp.read().decode())
                    results = data.get("result", {})
                    for uid in results:
                        if uid == "uids": continue
                        acc = results[uid].get("assemblyaccession")
                        ftp_refseq = results[uid].get("ftppath_refseq")
                        ftp_genbank = results[uid].get("ftppath_genbank")
                        ftp = ftp_refseq or ftp_genbank  # prefer RefSeq (always has GFF)
                        if acc and ftp:
                            details[acc] = ftp
                break
            except Exception as e:
                time.sleep(2 ** attempt)
    return details

# ---------- File download (robust) ----------
def download_file(url, dest_path, retries=5):
    """Download a file with retry & SSL hack. Returns True on success."""
    for i in range(retries):
        try:
            time.sleep(0.2)
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=30) as resp, open(dest_path, 'wb') as f:
                shutil.copyfileobj(resp, f)
            return True
        except Exception:
            if os.path.exists(dest_path):
                os.remove(dest_path)
            time.sleep(2 * (i+1))
    return False

# ---------- GFF contig renamer ----------
def rename_gff_contigs(input_gff, output_gff):
    """
    Read GFF, replace all seqid entries with 'contig_1', 'contig_2', ...
    This ensures compatibility regardless of FASTA headers.
    """
    seen = {}
    counter = 0
    with open(input_gff, 'r') as fin, open(output_gff, 'w') as fout:
        for line in fin:
            if line.startswith('#'):
                fout.write(line)
                continue
            parts = line.strip().split('\t')
            if len(parts) < 9:
                continue
            seqid = parts[0]
            if seqid not in seen:
                counter += 1
                seen[seqid] = f"contig_{counter}"
            parts[0] = seen[seqid]
            fout.write('\t'.join(parts) + '\n')
    return True

# ---------- GFF-only processing (fast) ----------
def strip_version(seqid):
    """Remove trailing version number (e.g., NC_000913.3 -> NC_000913)."""
    return re.sub(r'\.\d+$', '', seqid)

def normalize_fasta_headers(fasta_path):
    """Read FASTA, strip version from headers, write back."""
    tmp = fasta_path + ".tmp"
    with open(fasta_path, 'r') as fin, open(tmp, 'w') as fout:
        for line in fin:
            if line.startswith('>'):
                header = line[1:].strip().split()[0]   # take only first word (ID)
                header = strip_version(header)
                fout.write(f'>{header}\n')
            else:
                fout.write(line)
    os.replace(tmp, fasta_path)

def normalize_gff_contigs(gff_path):
    """Strip version from all seqid columns in GFF lines."""
    tmp = gff_path + ".tmp"
    with open(gff_path, 'r') as fin, open(tmp, 'w') as fout:
        for line in fin:
            if line.startswith('#'):
                fout.write(line)
                continue
            parts = line.strip().split('\t')
            if len(parts) >= 9:
                parts[0] = strip_version(parts[0])
            fout.write('\t'.join(parts) + '\n')
    os.replace(tmp, gff_path)

def process_gff_only(ftp_path, out_dir, genome_name, gff_path):
    """
    Download GFF and FASTA, combine them, and normalise contig IDs.
    Returns True on success.
    """
    https_path = ftp_path.replace("ftp://", "https://")
    basename = os.path.basename(ftp_path)

    # Files to download
    gff_gz_url = f"{https_path}/{basename}_genomic.gff.gz"
    fna_gz_url = f"{https_path}/{basename}_genomic.fna.gz"

    tmp_gff_gz = os.path.join(out_dir, "tmp.gff.gz")
    tmp_fna_gz = os.path.join(out_dir, "tmp.fna.gz")
    combined_gff = os.path.join(out_dir, "combined.gff")
    clean_fna = os.path.join(out_dir, "genome.fna")

    # Download GFF
    if not download_file(gff_gz_url, tmp_gff_gz):
        return False

    # Download FASTA
    if not download_file(fna_gz_url, tmp_fna_gz):
        os.remove(tmp_gff_gz)
        return False

    try:
        # Decompress GFF
        with gzip.open(tmp_gff_gz, 'rb') as f_in, open(os.path.join(out_dir, "orig.gff"), 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
        # Decompress FASTA
        with gzip.open(tmp_fna_gz, 'rb') as f_in, open(clean_fna, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

        # Normalise contig IDs in both files
        normalize_fasta_headers(clean_fna)
        normalize_gff_contigs(os.path.join(out_dir, "orig.gff"))

        # Build final GFF with embedded FASTA
        with open(os.path.join(out_dir, "orig.gff"), 'r') as fin, \
             open(combined_gff, 'w') as fout:
            # copy all GFF lines
            shutil.copyfileobj(fin, fout)
            fout.write('##FASTA\n')
            with open(clean_fna, 'r') as fna:
                shutil.copyfileobj(fna, fout)

        shutil.move(combined_gff, gff_path)

        # Clean up temp files
        for f in [tmp_gff_gz, tmp_fna_gz, os.path.join(out_dir, "orig.gff"), clean_fna]:
            if os.path.exists(f):
                os.remove(f)
        return True

    except Exception as e:
        print(f"GFF+FASTA processing error: {e}")
        return False
# ---------- Prokka fallback (original slow path) ----------
def process_prokka(fasta_path, out_dir, genome_name, gff_path, prokka_cpus, conda_env):
    """Run Prokka on the downloaded FASTA (slower)."""
    cmd = ["prokka", "--outdir", out_dir, "--prefix", genome_name, "--locustag", genome_name,
           "--cpus", str(prokka_cpus), "--compliant", "--fast", "--force", fasta_path]
    success, stdout, stderr = run_bio_cmd(cmd, conda_env)
    if not success:
        print(f"[PROKKA FAILED] for {genome_name}")
        return False
    return os.path.exists(gff_path) and os.path.getsize(gff_path) > 0

# ---------- Master genome processing (choose GFF or Prokka) ----------
def process_genome(acc, ftp_path, prefix, prokka_cpus, conda_env):
    safe_acc = acc.replace(".", "_")
    genome_name = f"{prefix}_{safe_acc}"
    out_dir = os.path.join(PROKKA_DIR, genome_name)
    gff_path = os.path.join(out_dir, f"{genome_name}.gff")

    # Check if already completed
    with state_lock:
        if genome_name in state["completed_annotations"]:
            if os.path.exists(gff_path) and os.path.getsize(gff_path) > 0:
                return True

    os.makedirs(out_dir, exist_ok=True)

    success = False
    error_msg = None

    # Clean up any previous partial results
    for stale in [os.path.join(out_dir, f) for f in os.listdir(out_dir) if not f.endswith('.gff')]:
        if os.path.isfile(stale):
            os.remove(stale)

    try:
        # Strategy 1: Try to grab the ready-made GFF (fast)
        if process_gff_only(ftp_path, out_dir, genome_name, gff_path):
            success = True
        else:
            # Strategy 2: Download FASTA and run Prokka (slow)
            fna_gz = os.path.join(GENOMES_DIR, f"{prefix}_{safe_acc}.fna.gz")
            fna_path = os.path.join(GENOMES_DIR, f"{prefix}_{safe_acc}.fna")
            https_path = ftp_path.replace("ftp://", "https://")
            basename = os.path.basename(ftp_path)
            fna_url = f"{https_path}/{basename}_genomic.fna.gz"

            if not download_file(fna_url, fna_gz):
                raise Exception("FASTA download failed")
            with gzip.open(fna_gz, 'rb') as f_in, open(fna_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
            os.remove(fna_gz)

            if not process_prokka(fna_path, out_dir, genome_name, gff_path, prokka_cpus, conda_env):
                raise Exception("Prokka annotation failed")
            os.remove(fna_path)   # delete FASTA immediately
            success = True

    except Exception as e:
        error_msg = str(e)
        # Log error
        with open(ERRORS_FILE, "a") as ef:
            ef.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {acc}: {error_msg}\n")
    finally:
        # Ensure no large temp files remain
        for tmp in [os.path.join(GENOMES_DIR, f"{prefix}_{safe_acc}.fna.gz"),
                    os.path.join(GENOMES_DIR, f"{prefix}_{safe_acc}.fna")]:
            if os.path.exists(tmp):
                os.remove(tmp)

    if success:
        with state_lock:
            if genome_name not in state["completed_annotations"]:
                state["completed_annotations"].append(genome_name)
            if acc in state["failed_annotations"]:
                del state["failed_annotations"][acc]
            save_checkpoint(state)
    else:
        with state_lock:
            state["failed_annotations"][acc] = error_msg
            save_checkpoint(state)

    return success

# ---------- Phases ----------
def search_phase(state, total_genomes):
    if state["ncbi_query_completed"]:
        print("=== NCBI search already done, loading metadata from checkpoint ===")
        return

    print("=== Querying NCBI Assembly (prefer RefSeq for speed) ===")
    # ST354 genomes
    st354_ids = get_ncbi_assembly_ids(
        'Escherichia coli[Organism] AND (ST354 OR "sequence type 354") AND latest[filter]',
        retmax=500)
    st354_details = get_assembly_ftp_details(st354_ids)

    # Diverse complete genomes (prefer RefSeq)
    other_ids = get_ncbi_assembly_ids(
        'Escherichia coli[Organism] AND latest[filter] AND "complete genome"[filter] AND "refseq"[filter]',
        retmax=2000)
    other_details = get_assembly_ftp_details(other_ids)

    assembly_meta = {}
    for acc, ftp in st354_details.items():
        assembly_meta[acc] = {"ftp": ftp, "prefix": "ST354"}

    for acc, ftp in other_details.items():
        if len(assembly_meta) >= total_genomes:
            break
        if acc not in assembly_meta:
            assembly_meta[acc] = {"ftp": ftp, "prefix": "COMP"}

    print(f"Selected {len(assembly_meta)} assemblies (ST354: {len(st354_details)}, others: {len(assembly_meta)-len(st354_details)})")
    state["assembly_metadata"] = assembly_meta
    state["ncbi_query_completed"] = True
    save_checkpoint(state)

def processing_phase(state, cores, prokka_cpus, conda_env):
    print("=== Processing Annotations (GFF-first, Prokka fallback) ===")
    targets = [(acc, info["ftp"], info["prefix"]) for acc, info in state["assembly_metadata"].items()]
    total = len(targets)

    # Add QA5221 isolate if present
    qa_path = os.path.join(WORKING_DIR, "QA5221.fasta")
    if os.path.exists(qa_path):
        qa_dir = os.path.join(PROKKA_DIR, "QUERY_QA5221")
        qa_gff = os.path.join(qa_dir, "QUERY_QA5221.gff")
        if not (os.path.exists(qa_gff) and os.path.getsize(qa_gff) > 0):
            print("Annotating QA5221 isolate with Prokka...")
            os.makedirs(qa_dir, exist_ok=True)
            success = process_prokka(qa_path, qa_dir, "QUERY_QA5221", qa_gff, prokka_cpus, conda_env)
            if success:
                with state_lock:
                    if "QUERY_QA5221" not in state["completed_annotations"]:
                        state["completed_annotations"].append("QUERY_QA5221")
                    save_checkpoint(state)
            else:
                print("WARNING: QA5221 annotation failed")
        else:
            print("QA5221 already annotated.")

    completed_start = len(state["completed_annotations"])
    errors_start = len(state["failed_annotations"])
    print_status_card("Download & Annotation", completed_start, total, errors_start)
    write_progress_json("Download & Annotation", int(completed_start/total*100) if total else 0,
                        completed_start, total, errors_start)

    last_update = time.time()
    with ThreadPoolExecutor(max_workers=cores) as executor:
        future_to_acc = {executor.submit(process_genome, acc, ftp, prefix, prokka_cpus, conda_env): acc
                         for acc, ftp, prefix in targets}
        with tqdm(total=total, desc="Processing Cohort") as pbar:
            # skip already completed in progress bar
            for acc, ftp, prefix in targets:
                if f"{prefix}_{acc.replace('.', '_')}" in state["completed_annotations"]:
                    pbar.update(1)
            for future in as_completed(future_to_acc):
                acc = future_to_acc[future]
                try:
                    future.result()
                except Exception as e:
                    print(f"\n[CRITICAL THREAD ERROR] {acc}: {e}")
                    with open(ERRORS_FILE, "a") as ef:
                        ef.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {acc} ThreadException: {e}\n")
                pbar.update(1)
                if time.time() - last_update > 60:
                    with state_lock:
                        comp = len(state["completed_annotations"])
                        errs = len(state["failed_annotations"])
                    print_status_card("Download & Annotation", comp, total, errs)
                    write_progress_json("Download & Annotation", int(comp/total*100) if total else 0, comp, total, errs)
                    last_update = time.time()

    with state_lock:
        final_completed = len(state["completed_annotations"])
        final_errors = len(state["failed_annotations"])
    print_status_card("Download & Annotation (Finished)", final_completed, total, final_errors)
    write_progress_json("Download & Annotation", 100, final_completed, total, final_errors)

def panaroo_phase(state, cores, conda_env):
    if state["panaroo_completed"]:
        print("=== Panaroo already completed. ===")
        return

    print("=== Running Panaroo (moderate mode for speed) ===")
    gff_files = []
    for root, _, files in os.walk(PROKKA_DIR):
        for f in files:
            if f.endswith(".gff"):
                gff_files.append(os.path.join(root, f))
    if not gff_files:
        print("ERROR: No GFF files found.")
        sys.exit(1)

    print(f"Panaroo with {len(gff_files)} genomes...")
    write_progress_json("Panaroo Pangenome", 0, 0, 1, 0)

    cmd = ["panaroo", "-i"] + gff_files + ["-o", PANAROO_DIR,
           "--clean-mode", "moderate",          # <-- changed from strict
           "--clean-mode", "sensitive",
           "-a", "core", "-t", str(cores)]
    success, stdout, stderr = run_bio_cmd(cmd, conda_env)
    if not success:
        print("ERROR: Panaroo failed.")
        print("STDERR:", stderr)
        write_progress_json("Panaroo Failed", 0, 0, 1, 1)
        sys.exit(1)

    print("Panaroo finished successfully.")
    state["panaroo_completed"] = True
    save_checkpoint(state)
    write_progress_json("Panaroo Pangenome", 100, 1, 1, 0)

def fasttree_phase(state, conda_env):
    if state["fasttree_completed"]:
        print("=== FastTree already built. ===")
        return

    aln = os.path.join(PANAROO_DIR, "core_gene_alignment.aln")
    tree = os.path.join(PANAROO_DIR, "core_phylogeny.tree")
    if not os.path.exists(aln):
        print(f"ERROR: Alignment not found at {aln}")
        write_progress_json("FastTree Failed", 0, 0, 1, 1)
        sys.exit(1)

    print("=== Building phylogeny with FastTree ===")
    write_progress_json("FastTree", 0, 0, 1, 0)
    if not run_bio_cmd_with_redirect(["fasttree", "-gtr", "-nt", aln], tree, conda_env):
        print("ERROR: FastTree failed")
        write_progress_json("FastTree Failed", 0, 0, 1, 1)
        sys.exit(1)

    state["fasttree_completed"] = True
    save_checkpoint(state)
    write_progress_json("FastTree", 100, 1, 1, 0)
    print(f"Phylogeny saved to {tree}")

def packaging_phase(state):
    if state["packaged_completed"]:
        print("=== Packaging already done. ===")
        return

    print("=== Packaging results ===")
    write_progress_json("Packaging", 0, 0, 1, 0)
    archive_dir = os.path.join(WORKING_DIR, "pangenome_export")
    os.makedirs(archive_dir, exist_ok=True)

    for f in ["gene_presence_absence.csv", "summary_statistics.txt",
              "core_gene_alignment.aln", "core_phylogeny.tree"]:
        src = os.path.join(PANAROO_DIR, f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(archive_dir, f))

    manifest_path = os.path.join(archive_dir, "metadata_manifest.csv")
    with open(manifest_path, "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["GenomeName", "Lineage", "NCBI_Accession"])
        for root, _, files in os.walk(PROKKA_DIR):
            for f in files:
                if f.endswith(".gff"):
                    name = f.replace(".gff", "")
                    parts = name.split("_", 1)
                    prefix = parts[0]
                    acc = parts[1] if len(parts) > 1 else ""
                    writer.writerow([name, prefix, acc])

    if os.path.exists(ERRORS_FILE):
        shutil.copy2(ERRORS_FILE, os.path.join(archive_dir, "errors.log"))

    shutil.make_archive(os.path.join(WORKING_DIR, "pangenome_expansion_results"), 'zip', archive_dir)
    print(f"Archive: pangenome_expansion_results.zip")
    state["packaged_completed"] = True
    save_checkpoint(state)
    write_progress_json("Finished", 100, 1, 1, 0)

# ---------- Main ----------
def main():
    global state
    parser = argparse.ArgumentParser(description="Optimized Pangenome Expansion Pipeline (Kaggle)")
    parser.add_argument("--total-genomes", type=int, default=500)
    parser.add_argument("--cores", type=int, default=4)
    parser.add_argument("--prokka-cpus", type=int, default=1)
    parser.add_argument("--conda-env", type=str, default="")
    args, _ = parser.parse_known_args()

    print("==========================================================")
    print(f"Pangenome Expansion (max {args.total_genomes} genomes)")
    print(f"Workers: {args.cores}, Prokka CPUs/job: {args.prokka_cpus}")
    print("==========================================================")

    # Environment setup
    if not args.conda_env:
        install_dependencies()

    # Optional swap for Kaggle
    create_swap_if_needed(10)

    state = load_checkpoint()

    # 1. Search NCBI
    search_phase(state, args.total_genomes)

    # 2. Process all genomes (GFF-first, Prokka fallback)
    processing_phase(state, args.cores, args.prokka_cpus, args.conda_env)

    # 3. Panaroo
    panaroo_phase(state, args.cores, args.conda_env)

    # 4. FastTree
    fasttree_phase(state, args.conda_env)

    # 5. Packaging
    packaging_phase(state)

    print("\n==========================================================")
    print("Pipeline completed successfully!")
    print(f"Results: {WORKING_DIR}/pangenome_expansion_results.zip")
    print("==========================================================")

if __name__ == "__main__":
    main()