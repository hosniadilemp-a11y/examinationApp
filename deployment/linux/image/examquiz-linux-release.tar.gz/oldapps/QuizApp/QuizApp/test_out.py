Q = {'starter_code': 'def func():\n    pass\n',
 'solution': "print('hello')\nprint('world')"}