import json
import os

qs = []

current_id = 3000

def add_q(topic, diff, title, desc, start, pin, pout, hin, hout):
    global current_id
    qs.append({
        "id": current_id,
        "is_exam": False,
        "type": "coding",
        "topic": topic,
        "difficulty": diff,
        "title": title,
        "description": desc,
        "starter_code": start,
        "function_signature": None,
        "public_tests": [{"input": pin, "output": pout}],
        "hidden_tests": [{"input": hin, "output": hout}],
        "points": 1 if diff == "easy" else (2 if diff == "medium" else (3 if diff == "hard" else 4)),
        "execution_settings": {"language": "python", "timeout_ms": 2000, "memory_limit_mb": 128}
    })
    current_id += 1

# --- EASY (20) ---
add_q("I/O", "easy", "Echo Input", "Read a string and print it.", "x = input()\n# print x\n", "hello", "hello", "test", "test")
add_q("Python Basics", "easy", "Add Two Integers", "Read two integers separated by a space and print their sum.", "a, b = map(int, input().split())\n", "3 4", "7", "10 20", "30")
add_q("Python Basics", "easy", "Subtract Two Integers", "Read two integers separated by a space and print the first minus the second.", "a, b = map(int, input().split())\n", "10 4", "6", "5 10", "-5")
add_q("Python Basics", "easy", "Float Addition", "Read two floats and print their sum.", "a, b = map(float, input().split())\n", "2.5 3.1", "5.6", "1.0 1.0", "2.0")
add_q("Python Basics", "easy", "Integer Division", "Read two integers and print the integer division (//) of the first by the second.", "a, b = map(int, input().split())\n", "10 3", "3", "20 5", "4")
add_q("Python Basics", "easy", "True Float Division", "Read a, b and print a / b.", "a, b = map(int, input().split())\n", "10 2", "5.0", "5 2", "2.5")
add_q("Python Basics", "easy", "Multiplication", "Read two integers and print their product.", "a, b = map(int, input().split())\n", "3 4", "12", "10 -2", "-20")
add_q("Python Basics", "easy", "Power Operator", "Read two integers x and y and print x ** y.", "x, y = map(int, input().split())\n", "2 3", "8", "5 2", "25")
add_q("Python Basics", "easy", "Equality Check", "Read two integers and print True if equal, else False.", "x, y = map(int, input().split())\n", "5 5", "True", "3 4", "False")
add_q("Python Basics", "easy", "Inequality Check", "Read two strings and print True if they are different.", "x, y = input().split()\n", "a b", "True", "a a", "False")
add_q("Python Basics", "easy", "Greater Than", "Read two integers and print True if x > y.", "x, y = map(int, input().split())\n", "5 3", "True", "3 5", "False")
add_q("Python Basics", "easy", "Less or Equal", "Read two integers and print True if x <= y.", "x, y = map(int, input().split())\n", "3 3", "True", "5 3", "False")
add_q("Python Basics", "easy", "Logical AND", "Read two booleans (1 or 0) and print x and y.", "x, y = map(int, input().split())\nx, y = bool(x), bool(y)\n", "1 1", "True", "1 0", "False")
add_q("Python Basics", "easy", "Logical OR", "Read two booleans (1 or 0) and print x or y.", "x, y = map(int, input().split())\nx, y = bool(x), bool(y)\n", "0 0", "False", "1 0", "True")
add_q("Python Basics", "easy", "Logical XOR", "Read two booleans (1 or 0) and print x ^ y.", "x, y = map(int, input().split())\nx, y = bool(x), bool(y)\n", "1 1", "False", "1 0", "True")
add_q("Python Basics", "easy", "Variables Swap", "Read two values, and output them swapped with a space.", "x, y = input().split()\n", "1 2", "2 1", "a b", "b a")
add_q("Python Data Types", "easy", "String Plus Number?", "Read a string and an integer. Note: you cannot add them. Print them joined without spaces.", "s, n = input().split()\n", "hello 5", "hello5", "x 10", "x10")
add_q("Python Basics", "easy", "Basic Function", "Write a function f(x) that returns x+1. Read an int x and print f(x).", "def f(x):\n    return x + 1\nx = int(input())\n", "5", "6", "99", "100")
add_q("Python Basics", "easy", "Basic Lambda", "Use a lambda function to return x * 2. Read x and print.", "f = lambda x: x * 2\nx = int(input())\n", "4", "8", "-3", "-6")
add_q("I/O", "easy", "Output Formatting", "Read a large integer and print it with commas.", "x = int(input())\n", "1000000", "1,000,000", "5000", "5,000")

# --- MEDIUM (10) ---
add_q("Control Flow", "medium", "Check Limits", "Read an integer. Print True if >= 10 and <= 20.", "x = int(input())\n", "15", "True", "5", "False")
add_q("Python Basics", "medium", "Function x^2 - y^2", "Write a function g(x, y) = x^2 - y^2. Read x and y, print result.", "def g(x,y):\n    return x**2 - y**2\nx, y = map(int, input().split())\n", "4 2", "12", "5 3", "16")
add_q("Python Data Types", "medium", "Variable Unpacking", "Given a string of space separated numbers, split into a list, unpack the first two as a, b and print a+b.", "nums = list(map(int, input().split()))\n", "5 6 7 8", "11", "10 20 30", "30")
add_q("Python Basics", "medium", "Default Arguments", "Write e_potentielle(masse, hauteur, g=9.81) returning m*h*g. Read m and h, print the result.", "def e_potentielle(masse, hauteur, g=9.81):\n    return masse * hauteur * g\nm, h = map(float, input().split())\n", "10 10", "981.0", "5 2", "98.1")
add_q("Python Basics", "medium", "Composed Lambda", "Create f = lambda x: x+1, and g = lambda x: x*2. Print g(f(x)).", "f = lambda x: x+1\ng = lambda x: x*2\nx = int(input())\n", "2", "6", "5", "12")
add_q("Control Flow", "medium", "Complex Logic", "Read four booleans. Print True if (a and b) or (c and d) else False.", "a, b, c, d = map(int, input().split())\na,b,c,d=bool(a),bool(b),bool(c),bool(d)\n", "1 1 0 0", "True", "1 0 1 0", "False")
add_q("Python Basics", "medium", "Polynomial Def", "Write f(x) = x^2 + 2x + 1.", "def f(x):\n    return x**2 + 2*x + 1\nx = int(input())\n", "3", "16", "0", "1")
add_q("I/O", "medium", "Print Formatted String", "Read name and age. Print 'My name is {name} and I am {age}'.", "name, age = input().split()\n", "Pierre 25", "My name is Pierre and I am 25", "Jean 30", "My name is Jean and I am 30")
add_q("Python Basics", "medium", "String Slicing", "Read a string and print its first 3 characters.", "s = input()\n", "Python", "Pyt", "Hello", "Hel")
add_q("Python Data Types", "medium", "List Unpacking with *", "Read numbers, unpack a, *b = numbers. Print b as a list.", "numbers = list(map(int, input().split()))\n", "1 2 3 4", "[2, 3, 4]", "10 20", "[20]")

# --- HARD (5) ---
add_q("Python Basics", "hard", "Energy Limit Exercise", "Modify e_potentielle(m, h, limit, g=9.81) to return True if energy > limit, otherwise False.", "def e_potentielle(m, h, limit, g=9.81):\n    return (m * h * g) > limit\nm, h, limit = map(float, input().split())\nprint(e_potentielle(m, h, limit))\n", "10 10 1000", "False", "10 10 900", "True")
add_q("Python Basics", "hard", "Function Composition", "Write f(x) and g(x). Read x, print f(g(f(x))). f multiplies by 2, g subtracts 3.", "def f(x): return x*2\ndef g(x): return x-3\nx = int(input())\nprint(f(g(f(x))))\n", "5", "14", "10", "34")
add_q("Python Data Types", "hard", "Unpack First and Last", "Read numbers, unpack a, *_, b = numbers. Print a * b. If only one number, a and b are both that number (needs fallback). Actually assume at least two numbers.", "numbers = list(map(int, input().split()))\na, *_, b = numbers\nprint(a * b)\n", "2 5 8 3", "6", "10 9 9 10", "100")
add_q("Python Basics", "hard", "Nested Lamda", "f = lambda x: lambda y: x ** y. Read x, y and print f(x)(y).", "f = lambda x: lambda y: x ** y\nx, y = map(int, input().split())\nprint(f(x)(y))\n", "3 2", "9", "2 6", "64")
add_q("Control Flow", "hard", "NAND Logic", "Implement NAND using lambda (not (x and y)). Read x, y and apply.", "nand = lambda x, y: not (x and y)\nx, y = map(int, input().split())\nx, y = bool(x), bool(y)\nprint(nand(x, y))\n", "1 1", "False", "1 0", "True")

# --- VERY HARD (5) ---
add_q("Python Basics", "very hard", "Multiple Return Unpacking", "Function returns x+y, x-y. Unpack to a, b and print a*b.", "def calc(x,y): return x+y, x-y\nx, y = map(int, input().split())\na, b = calc(x,y)\nprint(a*b)\n", "5 3", "16", "10 5", "75")
add_q("Python Basics", "very hard", "Lambda Data Pipeline", "Apply a list of lambda functions [lam x: x+1, lam x: x*2, lam x: x**2] in sequence on x.", "funcs = [lambda x: x+1, lambda x: x*2, lambda x: x**2]\nx = int(input())\nfor f in funcs: x = f(x)\nprint(x)\n", "2", "36", "3", "64")
add_q("Control Flow", "very hard", "Ternary Operator Equiv", "Use (a and b) or c logic to mimic ternary. Read x. If x > 0 print POSITIVE else NEGATIVE.", "x = int(input())\nres = (x > 0 and 'POSITIVE') or 'NEGATIVE'\nprint(res)\n", "5", "POSITIVE", "-2", "NEGATIVE")
add_q("Python Data Types", "very hard", "Complex Formatting", "Def print_stats(x, y). Print 'X: {x:,}, Y: {y:.2f}'. (x is large int, y is float)", "def print_stats(x, y):\n    print(f'X: {x:,}, Y: {y:.2f}')\nx = int(input())\ny = float(input())\nprint_stats(x, y)\n", "1000000\n3.1415", "X: 1,000,000, Y: 3.14", "5000\n2", "X: 5,000, Y: 2.00")
add_q("Python Basics", "very hard", "Args Wrapper", "Write a function that takes *args, returns the sum of the first, last, and length.", "def wrap(*args):\n    return args[0] + args[-1] + len(args)\nargs = list(map(int, input().split()))\nprint(wrap(*args))\n", "1 2 3 4 5", "11", "10 20 30", "43")

with open('/home/adel/Documents/Coding and projects/QuizApp/src/data/coding_questions.py', 'r') as f:
    text = f.read()

def build_q(q):
    s = "    {\\n"
    for k, v in q.items():
        s += f"        {repr(k)}: {repr(v)},\\n"
    s += "    },"
    return s

q_strings = "\\n".join(build_q(q) for q in qs)

text = text.replace(']', q_strings + '\\n]')

with open('/home/adel/Documents/Coding and projects/QuizApp/src/data/coding_questions.py', 'w') as f:
    f.write(text)

print("40 Questions injected successfully!")
