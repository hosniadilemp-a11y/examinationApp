#!/bin/bash
# This script generates an access code for an exam covering ALL topics
# Duration: 60 minutes
# Note: In QuizApp, you use this code to unlock the exam, and then select "Practical" for the coding exam.

echo "Generating Exam Access Code for ALL topics (Duration: 60 mins)..."
python3 generate_exam_code.py --topics 1111111111 --duration 60
