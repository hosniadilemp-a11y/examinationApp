# GitHub Publishing Workflow

This guide details how to publish and maintain the **QuizApp** project on GitHub.

## 1. Initial Repository Setup

If you haven't initialized the repository locally yet:

```bash
# Initialize git
git init

# Add all project files (honors .gitignore)
git add .

# Create initial commit
git commit -m "chore: initial project structure and cleanup"
```

## 2. Linking to GitHub (Private)

1. Create a new repository on GitHub (keep it **Private**).
2. Link your local repository to the remote:
   ```bash
   git remote add origin https://github.com/hosniadilemp-a11y/QuizAPP.git
   git branch -M main
   git push -u origin main
   ```

## 3. Daily Development Workflow

Maintain a clean repository by following these steps:

1. **Keep it Clean**: Before committing, ensure no temporary files are present. Our `.gitignore` should handle most cases.
2. **Commit Often**: Use descriptive commit messages.
   ```bash
   git add .
   git commit -m "feat: add evolution chart for training results"
   git push
   ```
3. **Use the Build System**: Always use `python make.py build` to test your changes before pushing.

## 4. Release Management

When a new version is ready for distribution:

1. **Update Version**: Increment version numbers in `pyproject.toml` or `src/main.py`.
2. **Build Binaries**:
   ```bash
   python make.py clean
   python make.py build
   ```
3. **GitHub Release**:
   - Go to your repo on GitHub.
   - Click "Releases" -> "Create a new release".
   - Upload the `.exe` file from the `dist/` folder.

## 5. Collaboration Best Practices

- **Pull before Push**: Always run `git pull` before pushing to avoid conflicts.
- **Feature Branches**: For large features, create a new branch: `git checkout -b feature/new-level-system`.

## 6. Using GitHub Actions (Workflows)

The project includes an automated build workflow in `.github/workflows/build.yml`.

### How to Trigger a Build
1. **Manual Trigger**:
   - Go to your repository on GitHub.
   - Click the **Actions** tab.
   - Select **Build Executables** from the left sidebar.
   - Click **Run workflow**.

2. **Automatic Build (Releases)**:
   - Create a git tag starting with `v` (e.g., `v1.0.0`):
     ```bash
     git tag v1.0.0
     git push origin v1.0.0
     ```
   - GitHub will automatically start building the Windows, Linux, and macOS executables.

### Where to Find Built Files
Once the workflow finishes:
- Go to the **Actions** tab.
- Click on the most recent run.
- Scroll down to the **Artifacts** section to download the zipped executables.

