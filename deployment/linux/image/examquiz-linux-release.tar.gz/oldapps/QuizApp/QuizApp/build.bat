@echo off
echo Building Quiz App for Windows...

REM Create virtual environment if it doesn't exist
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)

REM Activate virtual environment
call venv\Scripts\activate.bat

REM Install requirements
echo Installing dependencies...
pip install -r requirements.txt
pip install pyinstaller

REM Create build directory
if not exist "dist" mkdir dist

REM Build with PyInstaller
echo Building executable...
pyinstaller --noconfirm --onefile --windowed ^
  --name "QuizApp" ^
  --icon "assets/icon.ico" ^
  --add-data "src/data;data" ^
  --add-data "src/core;core" ^
  --add-data "src/gui;gui" ^
  --add-data "src/utils;utils" ^
  --hidden-import PyQt6.sip ^
  --hidden-import cryptography ^
  --hidden-import reportlab ^
  --clean ^
  src/main.py

echo Build complete! Check the 'dist' folder.
pause