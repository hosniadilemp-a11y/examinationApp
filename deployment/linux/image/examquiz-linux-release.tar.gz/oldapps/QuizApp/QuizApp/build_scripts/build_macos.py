import PyInstaller.__main__
import os

PyInstaller.__main__.run([
    'src/main.py',
    '--name=QuizApp',
    '--windowed',
    '--onefile',
    '--icon=assets/icon.icns',
    '--add-data=src/data:data',
    '--add-data=src/utils:utils',
    '--hidden-import=PyQt6.sip',
    '--clean',
    '--osx-bundle-identifier=com.yourcompany.quizapp'
])