import PyInstaller.__main__
import os

PyInstaller.__main__.run([
    'src/main.py',
    '--name=quizapp',
    '--windowed',
    '--onefile',
    '--add-data=src/data:data',
    '--add-data=src/utils:utils',
    '--hidden-import=PyQt6.sip',
    '--clean'
])