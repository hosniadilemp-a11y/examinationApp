# build_windows.py - More control than batch file
import os
import subprocess
import sys
import shutil
from pathlib import Path

def build_windows():
    """Build Windows executable with PyInstaller"""
    
    print("🚀 Building Quiz App for Windows...")
    
    # Check if requirements are installed
    try:
        import PyInstaller
    except ImportError:
        print("Installing PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Clean previous builds
    print("Cleaning previous builds...")
    for folder in ['build', 'dist']:
        if os.path.exists(folder):
            shutil.rmtree(folder)
    
    # PyInstaller command
    cmd = [
        'pyinstaller',
        '--name=QuizApp',
        '--windowed',
        '--onefile',
        '--icon=assets/icon.ico',
        '--add-data=src/data;data',
        '--add-data=src/core;core',
        '--add-data=src/gui;gui',
        '--add-data=src/utils;utils',
        '--hidden-import=PyQt6.sip',
        '--hidden-import=cryptography',
        '--hidden-import=reportlab',
        '--clean',
        '--noconsole',
        'src/main.py'
    ]
    
    print(f"Running: {' '.join(cmd)}")
    subprocess.run(cmd)
    
    # Verify build
    exe_path = Path("dist") / "QuizApp.exe"
    if exe_path.exists():
        print(f"✅ Build successful! Executable: {exe_path}")
        print(f"Size: {exe_path.stat().st_size / (1024*1024):.2f} MB")
    else:
        print("❌ Build failed!")

if __name__ == "__main__":
    build_windows()