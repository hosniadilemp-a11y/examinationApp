# Final Exam Creation Procedure

Final exams are encrypted `.quiz` files created with `src/core/exam_loader.py`.

## Folders

- `source_json/`: editable exam source files.
- `encrypted_quiz/`: generated final `.quiz` files used by the app.

## JSON Format

Create a JSON file in `source_json/` with this structure:

```json
{
  "config": {
    "title": "Final Python Exam",
    "duration": 60,
    "question_count": 40,
    "exam_types": "Theoretical",
    "points_per_question": 1,
    "penalty_per_question": 0.25,
    "shuffle_questions": true,
    "shuffle_options": true,
    "passing_score": 50,
    "warning_times": [10, 5]
  },
  "questions": [
    {
      "id": 1,
      "type": "mcq",
      "topic": "Python Basics",
      "difficulty": "easy",
      "text": "Question text",
      "points": 1,
      "penalty": 0.25,
      "options": ["A", "B", "C", "D"],
      "correct": [0]
    }
  ]
}
```

## Create Encrypted Exam

From the project root:

```bash
python tools/create_final_exam.py exams_final/source_json/final_exam.json exams_final/encrypted_quiz/final_exam.quiz
```

Default password is `dilo2025`, matching the current app loader.
