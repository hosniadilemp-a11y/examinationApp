import os
import json
from datetime import datetime
from zoneinfo import ZoneInfo
import pytest
from fastapi.testclient import TestClient

from student_app.app.main import app
from student_app.app.scheduler import (
    is_within_scheduled_hours,
    get_schedule_status_payload,
    get_schedule_config,
    save_schedule_config,
    set_app_active,
    toggle_app_active,
    set_active_groups,
    set_master_slot_lock,
    extract_group_from_code,
    DEFAULT_SCHEDULE_CONFIG,
    SCHEDULE_CONFIG_FILE,
    TZ,
    ALL_GROUPS
)

client = TestClient(app)

@pytest.fixture(autouse=True)
def reset_schedule_config():
    """Ensure tests start and finish with the default schedule configuration."""
    from student_app.app.scheduler import _get_db_session
    from student_app.app.models import SystemSetting

    def _reset():
        os.makedirs(os.path.dirname(SCHEDULE_CONFIG_FILE), exist_ok=True)
        with open(SCHEDULE_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_SCHEDULE_CONFIG, f, indent=2)
        db = _get_db_session()
        if db:
            try:
                setting = db.query(SystemSetting).filter(SystemSetting.key == "schedule_config").first()
                if setting:
                    setting.value = json.dumps(DEFAULT_SCHEDULE_CONFIG)
                else:
                    setting = SystemSetting(key="schedule_config", value=json.dumps(DEFAULT_SCHEDULE_CONFIG))
                    db.add(setting)
                db.commit()
            except Exception:
                db.rollback()
            finally:
                db.close()

    _reset()
    yield
    _reset()


def test_active_days_morning_slot():
    # Sunday at 09:15
    sun_m = datetime(2026, 9, 6, 9, 15, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(sun_m)
    assert is_open is True
    assert code == "OPEN_SLOT_1"
    assert meta["active_slot"] == "morning"

    # Thursday at 12:45
    thu_m = datetime(2026, 9, 10, 12, 45, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(thu_m)
    assert is_open is True
    assert code == "OPEN_SLOT_1"


def test_lunch_break_closed():
    # Sunday at 12:55 (between 12:50 and 13:00)
    sun_break = datetime(2026, 9, 6, 12, 55, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(sun_break)
    assert is_open is False
    assert code == "CLOSED_BREAK"
    assert "13:00" in meta.get("next_opening", "")


def test_active_days_afternoon_slot():
    # Sunday at 13:00 (slot 2 starts)
    sun_a_start = datetime(2026, 9, 6, 13, 0, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(sun_a_start)
    assert is_open is True
    assert code == "OPEN_SLOT_2"

    # Tuesday at 16:30
    tue_a = datetime(2026, 9, 8, 16, 30, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(tue_a)
    assert is_open is True
    assert code == "OPEN_SLOT_2"

    # Thursday at 16:49 (slot 2 ends at 16:50)
    thu_a_end = datetime(2026, 9, 10, 16, 49, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(thu_a_end)
    assert is_open is True
    assert code == "OPEN_SLOT_2"


def test_weekend_closed():
    # Friday at 10:00 (Weekend)
    fri = datetime(2026, 9, 4, 10, 0, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(fri)
    assert is_open is False
    assert code == "CLOSED_WEEKEND"
    assert "Sunday" in meta.get("next_opening", "")

    # Saturday at 15:00 (Weekend)
    sat = datetime(2026, 9, 5, 15, 0, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(sat)
    assert is_open is False
    assert code == "CLOSED_WEEKEND"


def test_before_and_after_hours_closed():
    # Wednesday at 07:45 (before 08:00)
    wed_early = datetime(2026, 9, 9, 7, 45, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(wed_early)
    assert is_open is False
    assert code == "CLOSED_BEFORE_HOURS"

    # Wednesday at 17:00 (after 16:50)
    wed_late = datetime(2026, 9, 9, 17, 0, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(wed_late)
    assert is_open is False
    assert code == "CLOSED_AFTER_HOURS"


def test_extract_group_from_code():
    assert extract_group_from_code("IASD01") == "IASD"
    assert extract_group_from_code("iasd15") == "IASD"
    assert extract_group_from_code("SIAD99") == "SIAD"
    assert extract_group_from_code("RSD02") == "RSD"
    assert extract_group_from_code("CS10") == "CS"
    assert extract_group_from_code("cs01") == "CS"
    assert extract_group_from_code("UNKNOWN") == ""
    assert extract_group_from_code("") == ""


def test_separate_morning_and_afternoon_locks():
    # Lock Sunday morning while leaving afternoon open
    save_schedule_config({
        "daily_schedule": {
            "6": {
                "name_en": "Sunday",
                "name_fr": "Dimanche",
                "is_open": True,
                "morning": {"is_open": False, "start": "08:00", "end": "12:50", "allowed_groups": ALL_GROUPS},
                "afternoon": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ALL_GROUPS}
            }
        }
    })

    # Sunday morning at 09:30 should be CLOSED_MORNING_LOCKED
    sun_m = datetime(2026, 9, 6, 9, 30, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(sun_m)
    assert is_open is False
    assert code == "CLOSED_MORNING_LOCKED"
    assert "Afternoon" in meta.get("next_opening", "") or "13:00" in meta.get("next_opening", "") or "Today" in meta.get("next_opening", "")

    # Sunday afternoon at 14:30 should be OPEN_SLOT_2
    sun_a = datetime(2026, 9, 6, 14, 30, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(sun_a)
    assert is_open is True
    assert code == "OPEN_SLOT_2"

    # Now lock Sunday afternoon while opening morning
    save_schedule_config({
        "daily_schedule": {
            "6": {
                "morning": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ALL_GROUPS},
                "afternoon": {"is_open": False, "start": "13:00", "end": "16:50", "allowed_groups": ALL_GROUPS}
            }
        }
    })

    # Morning open
    is_open, code, _ = is_within_scheduled_hours(sun_m)
    assert is_open is True
    assert code == "OPEN_SLOT_1"

    # Afternoon locked
    is_open, code, meta = is_within_scheduled_hours(sun_a)
    assert is_open is False
    assert code == "CLOSED_AFTERNOON_LOCKED"


def test_master_group_gating():
    # Lock RSD globally, keep CS, IASD, SIAD
    set_active_groups(["CS", "IASD", "SIAD"])

    sun_m = datetime(2026, 9, 6, 9, 30, tzinfo=TZ)

    # IASD student should be allowed
    is_open_iasd, code_iasd, _ = is_within_scheduled_hours(sun_m, student_code="IASD01")
    assert is_open_iasd is True
    assert code_iasd == "OPEN_SLOT_1"

    # CS student should be allowed
    is_open_cs, code_cs, _ = is_within_scheduled_hours(sun_m, student_code="CS12")
    assert is_open_cs is True
    assert code_cs == "OPEN_SLOT_1"

    # RSD student should be blocked by teacher
    is_open_rsd, code_rsd, meta_rsd = is_within_scheduled_hours(sun_m, student_code="RSD05")
    assert is_open_rsd is False
    assert code_rsd == "GROUP_LOCKED_BY_TEACHER"
    assert meta_rsd["student_group"] == "RSD"


def test_slot_specific_group_authorization():
    # Sunday: morning allows IASD only, afternoon allows RSD only
    save_schedule_config({
        "daily_schedule": {
            "6": {
                "name_en": "Sunday",
                "name_fr": "Dimanche",
                "is_open": True,
                "morning": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ["IASD"]},
                "afternoon": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ["RSD"]}
            }
        }
    })

    sun_m = datetime(2026, 9, 6, 9, 30, tzinfo=TZ)
    sun_a = datetime(2026, 9, 6, 14, 0, tzinfo=TZ)

    # In morning: IASD allowed, RSD rejected
    is_open, code, _ = is_within_scheduled_hours(sun_m, student_code="IASD01")
    assert is_open is True
    assert code == "OPEN_SLOT_1"

    is_open, code, meta = is_within_scheduled_hours(sun_m, student_code="RSD01")
    assert is_open is False
    assert code == "GROUP_NOT_ALLOWED_IN_SLOT"

    # In afternoon: RSD allowed, IASD rejected
    is_open, code, _ = is_within_scheduled_hours(sun_a, student_code="RSD01")
    assert is_open is True
    assert code == "OPEN_SLOT_2"

    is_open, code, meta = is_within_scheduled_hours(sun_a, student_code="IASD01")
    assert is_open is False
    assert code == "GROUP_NOT_ALLOWED_IN_SLOT"


def test_api_schedule_status_with_group():
    set_active_groups(["CS", "IASD"])
    res = client.get("/api/schedule-status?code=RSD01")
    assert res.status_code == 200
    data = res.json()
    assert data["active_groups"] == ["CS", "IASD"]
    assert "metadata" in data


def test_online_schedule_control_routes():
    # Test GET
    res = client.get("/schedule-control")
    assert res.status_code == 200
    assert "config" in res.json()
    assert "status" in res.json()

    # Test set-groups
    res = client.post("/schedule-control/set-groups", json={"groups": ["CS", "RSD"]})
    assert res.status_code == 200
    assert res.json()["config"]["active_groups"] == ["CS", "RSD"]

    # Test lock-slot
    res = client.post("/schedule-control/lock-slot", json={"slot": "morning", "locked": True})
    assert res.status_code == 200
    assert res.json()["config"]["lock_morning_all"] is True

    # Test toggle
    res = client.post("/schedule-control/toggle", json={"active": False})
    assert res.status_code == 200
    assert res.json()["app_active"] is False


def test_teacher_deactivation_controls():
    # Deactivate the app
    set_app_active(False)
    sun_m = datetime(2026, 9, 6, 9, 15, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(sun_m)
    assert is_open is False
    assert code == "DEACTIVATED_BY_TEACHER"

    # Toggle back to active
    toggle_app_active()
    is_open, code, meta = is_within_scheduled_hours(sun_m)
    assert is_open is True
    assert code == "OPEN_SLOT_1"


def test_teacher_force_open_override():
    # Friday midnight (normally weekend closed)
    fri_midnight = datetime(2026, 9, 4, 0, 30, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(fri_midnight)
    assert is_open is False

    # Turn on teacher force open
    save_schedule_config({"force_open": True})
    is_open, code, meta = is_within_scheduled_hours(fri_midnight)
    assert is_open is True
    assert code == "FORCE_OPEN_OVERRIDE"


def test_admin_override_env(monkeypatch):
    monkeypatch.setenv("ALLOW_OFF_HOURS", "true")
    # Even on Friday midnight, should allow access
    fri_midnight = datetime(2026, 9, 4, 0, 30, tzinfo=TZ)
    is_open, code, meta = is_within_scheduled_hours(fri_midnight)
    assert is_open is True
    assert code == "ADMIN_OVERRIDE"


def test_attempt_start_rejected_when_closed(monkeypatch):
    import student_app.app.api.attempts as att_module
    # Mock is_within_scheduled_hours to return closed
    monkeypatch.setattr(
        att_module,
        "is_within_scheduled_hours",
        lambda *args, **kwargs: (False, "CLOSED_WEEKEND", {"next_opening": "Sunday 06 September at 08:00"})
    )
    res = client.post("/api/attempt/start", json={"code": "IASD01", "tp_id": 1})
    assert res.status_code == 403
    assert "FERMÉ" in res.json()["detail"] or "CLOSED" in res.json()["detail"]


def test_attempt_start_rejected_when_group_locked(monkeypatch):
    import student_app.app.api.attempts as att_module
    monkeypatch.setattr(
        att_module,
        "is_within_scheduled_hours",
        lambda *args, **kwargs: (False, "GROUP_LOCKED_BY_TEACHER", {"student_group": "RSD", "allowed_groups": ["CS", "IASD"]})
    )
    res = client.post("/api/attempt/start", json={"code": "RSD01", "tp_id": 1})
    assert res.status_code == 403
    assert "RSD" in res.json()["detail"]
    assert "verrouillées" in res.json()["detail"] or "locked" in res.json()["detail"]
