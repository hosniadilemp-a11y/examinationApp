import os
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from datetime import datetime, timedelta

from student_app.app.main import app
from student_app.app.database import Base, get_db
from student_app.app.models import ValidCode, TP, Question, Session, Attempt, AttemptAnswer, QuestionFlag
from admin_app.backend.main import app as admin_app
from admin_app.backend.database import get_db as admin_get_db

# In-memory SQLite DB for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
admin_app.dependency_overrides[admin_get_db] = override_get_db

student_client = TestClient(app)
admin_client = TestClient(admin_app)

@pytest.fixture(autouse=True)
def setup_db():
    app.dependency_overrides[get_db] = override_get_db
    admin_app.dependency_overrides[get_db] = override_get_db
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()


    # Seed Student Codes
    db.add(ValidCode(code="IASD01", group_code="IASD", active=True))

    # Seed TP
    tp1 = TP(id=1, name="TP 1: Data Cleaning", ordering=1)
    db.add(tp1)

    # Seed Active Session
    now = datetime.utcnow()
    sess = Session(tp_id=1, opens_at=now - timedelta(days=1), closes_at=now + timedelta(days=1))
    db.add(sess)

    # Seed 25 Questions for TP1 (Question #5 marked cannot_be_flagged = True)
    for i in range(1, 26):
        db.add(Question(
            id=i,
            tp_id=1,
            topic_id=1,
            text=f"Question {i} statement text",
            correct_answer=(i % 2 == 0),
            cannot_be_flagged=(i == 5),
            active=True
        ))

    db.commit()
    db.close()


def test_student_flag_question_success_and_limit():
    # 1. Start Attempt
    resp = student_client.post("/api/attempt/start", json={"code": "IASD01", "tp_id": 1})
    assert resp.status_code == 200
    attempt_id = resp.json()["attempt_id"]

    # 2. Serve next questions & flag them
    # Flag question 1
    resp_q1 = student_client.get(f"/api/attempt/{attempt_id}/next-question")
    assert resp_q1.status_code == 200
    q1_id = resp_q1.json()["question_id"]

    flag_resp1 = student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={
        "question_id": q1_id,
        "reason_category": "typo",
        "student_comment": "Spelling mistake in IQR term."
    })
    assert flag_resp1.status_code == 200
    assert flag_resp1.json()["flags_used"] == 1
    assert flag_resp1.json()["flags_remaining"] == 2

    # Duplicate flag on q1 should fail
    dup_resp = student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={
        "question_id": q1_id,
        "reason_category": "ambiguous"
    })
    assert dup_resp.status_code == 400
    assert "already been reported" in dup_resp.json()["detail"]

    # Answer question 1 & get question 2
    student_client.post(f"/api/attempt/{attempt_id}/answer-and-next", json={"question_id": q1_id, "chosen": True})
    
    resp_q2 = student_client.get(f"/api/attempt/{attempt_id}/next-question")
    q2_id = resp_q2.json()["question_id"]
    flag_resp2 = student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={"question_id": q2_id})
    assert flag_resp2.status_code == 200
    assert flag_resp2.json()["flags_used"] == 2

    student_client.post(f"/api/attempt/{attempt_id}/answer-and-next", json={"question_id": q2_id, "chosen": False})

    resp_q3 = student_client.get(f"/api/attempt/{attempt_id}/next-question")
    q3_id = resp_q3.json()["question_id"]
    flag_resp3 = student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={"question_id": q3_id})
    assert flag_resp3.status_code == 200
    assert flag_resp3.json()["flags_used"] == 3
    assert flag_resp3.json()["flags_remaining"] == 0

    student_client.post(f"/api/attempt/{attempt_id}/answer-and-next", json={"question_id": q3_id, "chosen": True})

    # 4th flag attempt should be rejected due to 3-flag limit
    resp_q4 = student_client.get(f"/api/attempt/{attempt_id}/next-question")
    q4_id = resp_q4.json()["question_id"]
    flag_resp4 = student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={"question_id": q4_id})
    assert flag_resp4.status_code == 400
    assert "limit of 3 reached" in flag_resp4.json()["detail"]


def test_cannot_be_flagged_verified_question_block():
    # Question #5 is seeded with cannot_be_flagged = True
    resp = student_client.post("/api/attempt/start", json={"code": "IASD01", "tp_id": 1})
    attempt_id = resp.json()["attempt_id"]

    flag_resp = student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={
        "question_id": 5,
        "reason_category": "typo"
    })
    assert flag_resp.status_code == 400
    assert "verified as 100% correct" in flag_resp.json()["detail"]


def test_teacher_review_workflow_and_scoring():
    # 1. Create student attempt & flag question 1
    resp = student_client.post("/api/attempt/start", json={"code": "IASD01", "tp_id": 1})
    attempt_id = resp.json()["attempt_id"]

    resp_q1 = student_client.get(f"/api/attempt/{attempt_id}/next-question")
    q1_id = resp_q1.json()["question_id"]

    student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={
        "question_id": q1_id,
        "reason_category": "invalid_key",
        "student_comment": "Answer key True is wrong."
    })

    # Complete test
    for pos in range(1, 21):
        resp_q = student_client.get(f"/api/attempt/{attempt_id}/next-question")
        if resp_q.json().get("finished"):
            break
        qid = resp_q.json()["question_id"]
        student_client.post(f"/api/attempt/{attempt_id}/answer-and-next", json={"question_id": qid, "chosen": True})

    finish_resp = student_client.post(f"/api/attempt/{attempt_id}/finish")
    assert finish_resp.status_code == 200
    assert finish_resp.json()["status"] == "pending_review"

    # 2. Teacher retrieves flag queue
    flags_resp = admin_client.get("/questions/flags")
    assert flags_resp.status_code == 200
    flags_list = flags_resp.json()
    assert len(flags_list) >= 1
    flag_id = flags_list[0]["flag_id"]

    # 3. Teacher confirms issue (awards +1 pt)
    review_resp = admin_client.post(f"/questions/flags/{flag_id}/review", json={
        "status": "ISSUE_CONFIRMED",
        "teacher_note": "Typo in question statement confirmed.",
        "points_awarded": 1.0
    })
    assert review_resp.status_code == 200
    assert review_resp.json()["status"] == "ISSUE_CONFIRMED"
    assert review_resp.json()["attempt_status"] == "finished"
    assert review_resp.json()["points_awarded"] == 1.0


def test_teacher_toggle_flag_lock():
    # Toggle flag lock on question #2
    toggle_resp = admin_client.post("/questions/2/toggle-flag-lock", json={"lock_state": True})
    assert toggle_resp.status_code == 200
    assert toggle_resp.json()["cannot_be_flagged"] is True

    # Student trying to flag question #2 should fail
    resp = student_client.post("/api/attempt/start", json={"code": "IASD01", "tp_id": 1})
    attempt_id = resp.json()["attempt_id"]

    flag_resp = student_client.post(f"/api/attempt/{attempt_id}/flag-question", json={"question_id": 2})
    assert flag_resp.status_code == 400
    assert "verified as 100% correct" in flag_resp.json()["detail"]
