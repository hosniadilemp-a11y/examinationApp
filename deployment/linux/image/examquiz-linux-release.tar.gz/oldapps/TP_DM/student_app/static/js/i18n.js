/* ==========================================================================
   Data Mining TP Evaluation Platform — Internationalization (i18n) Engine
   Supports 🇬🇧 English & 🇫🇷 Français
   ========================================================================== */

const I18N_DICTIONARY = {
    en: {
        // App Header & Brand
        "brand.title": "Data Mining Evaluation",
        "brand.subtitle": "Continuous Assessment Platform",

        // Cooldown Banner
        "cooldown.active_label": "COOLDOWN ACTIVE:",
        "cooldown.remaining_text": "remaining before you can start another evaluation attempt.",
        "cooldown.reset_btn": "Reset Cooldown (Dev)",

        // Login / Auth Screen
        "login.badge": "Timed Evaluation System",
        "login.title": "TP Continuous Test",
        "login.subtitle": "Enter your official student code and select a TP to begin your timed 20-question evaluation.",
        "login.choose_language": "🌐 Select Application Language / Choisissez la Langue",
        "login.student_code_label": "Student Identifier Code",
        "login.student_code_placeholder": "e.g. IASD01, SIAD15, RSD02, CS99",
        "login.student_code_hint": "Format: Speciality (SIAD, IASD, RSD, CS) + 2-digit number (01..100)",
        "login.select_tp_label": "Select Evaluation TP",
        "login.loading_tps": "Loading TPs...",
        "rule.timer": "20s Per Question:",
        "rule.timer_desc": "Server-enforced timer per question.",
        "rule.scoring": "Scoring Rule:",
        "rule.scoring_desc": "+1 for correct, −1 for wrong or expired. Final mark out of 20.",
        "rule.cooldown": "10-Min Cooldown:",
        "rule.cooldown_desc": "Enforced between consecutive attempts of the same TP.",
        "btn.start_test": "Start Timed Test",
        "btn.validating_code": "Validating Code...",

        // Detailed Information Section & Anti-Cheat System
        "info.title": "Evaluation Rules & Platform Features",
        "info.subtitle": "Official grading structure, IQR outlier trimming, attempt advisory, and security policies.",
        
        "info.score_heading": "Course Grade Calculation (20 Points Total)",
        "info.tp_weight_title": "18 Points — 6 TP Evaluations (3 pts each)",
        "info.tp_weight_desc": "Continuous evaluation across the 6 Data Mining TPs. Each TP evaluation contributes 3 points to your final grade (6 × 3 = 18 pts).",
        "info.teacher_weight_title": "2 Points — Teacher Evaluation",
        "info.teacher_weight_desc": "2 points awarded directly by the teacher based on presence, active participation, and lab performance.",
        "info.total_weight_title": "Total Continuous Evaluation Mark: 20 Points",
        "info.total_weight_desc": "18 Points (6 TP Tests) + 2 Points (Teacher Grade) = 20 Points Total.",
        
        "info.rules_heading": "Attempt Rules & Scoring",
        "info.rule_correct": "+1 Point for each correct answer.",
        "info.rule_wrong": "−1 Point for wrong or expired answers (penalizes blind guessing).",
        "info.rule_skip": "0 Points for skipped questions.",

        "info.iqr_heading": "Average of All Valid Attempts Strategy",
        "info.iqr_calc_title": "How Your Final TP Score is Calculated (Average of All Valid Attempts)",
        "info.iqr_calc_desc": "Your final score for each TP is calculated as the plain average of all your valid finished attempts. Every valid completed attempt is included in your mean score.",
        "info.iqr_wise_title": "Recommended Student Test Strategy",
        "info.iqr_wise_desc": "Since every valid attempt directly impacts your average grade, make sure to take prepared, serious attempts so that each test score actively raises your overall average!",

        "info.anticheat_heading": "Implemented Anti-Cheat & Security Mechanisms",
        "info.anticheat_warning": "Warning: Multi-layered security is active to detect automated answering and integrity violations.",
        "info.ac_timer_title": "Strict Server-Side 20s Countdown",
        "info.ac_timer_desc": "Timers are validated strictly on the backend server clock. Client-side script manipulation cannot pause or extend time.",
        "info.ac_violations_title": "Proctored Violation Tracking (Max 4)",
        "info.ac_violations_desc": "Monitors tab switching, window focus loss, mouse exiting viewport, exiting fullscreen, context menus, and dev tools. 4 violations auto-fails the attempt (Score 0.0/20).",
        "info.ac_traps_title": "Trap Questions & AI/LLM Detection",
        "info.ac_traps_desc": "Question bank contains hidden trap pairs and attention-check questions to flag automated scripts, AI solvers, and random clicking.",
        "info.ac_fingerprint_title": "Device Fingerprint & Hashed IP Logging",
        "info.ac_fingerprint_desc": "Hashed IP addresses, device metrics, and user agents are logged per attempt for security audits and proxy detection.",

        "info.flagging_heading": "Question Reporting & Teacher Review System",
        "info.flagging_title": "Student Flagging & Grade Protection (Max 3 per Test)",
        "info.flagging_desc": "If you encounter a potential typo, ambiguity, or invalid statement, you can report up to 3 questions per attempt. Reported attempts enter 'Pending Review' status. The teacher inspects each flag and can award bonus points if the issue is confirmed.",

        // Live Quiz Screen
        "quiz.question_label": "Question",
        "quiz.statement_badge": "True / False Statement",
        "quiz.loading_question": "Loading question text...",
        "btn.true": "TRUE",
        "btn.false": "FALSE",
        "btn.skip": "Skip Question (0 pts)",
        "btn.end_test": "End Test",
        "quiz.footer_hint": "Strictly server-timed. Select your answer before the clock reaches 0.",

        // Fullscreen Overlay
        "fullscreen.title": "Fullscreen Required",
        "fullscreen.desc": "You exited fullscreen mode. Test progress is paused and violations are recorded. Click below to return to fullscreen and resume your evaluation test.",
        "btn.reenter_fullscreen": "Re-enter Fullscreen Mode",

        // End Test Confirmation Modal
        "end_test.title": "End Evaluation Test Early?",
        "end_test.desc": "Are you sure you want to finalize your evaluation attempt now? Any unanswered questions will score 0 points. Timer continues running in the background.",
        "btn.continue_test": "Continue Test",
        "btn.confirm_end_test": "End & Submit",

        // Anti-Cheat Violation Toast
        "violation.header": "ANTI-CHEAT VIOLATION DETECTED",
        "violation.warning_prefix": "Warning",
        "violation.subtext": "4 violations will result in automatic test failure (Score: 0.0/20).",

        // Specific Violation Descriptions
        "violation.tab_hidden": "Switched tab or minimized browser window",
        "violation.window_blur": "Window focus lost",
        "violation.mouse_left_viewport": "Mouse exited top of window",
        "violation.fullscreen_exit": "Exited fullscreen mode",
        "violation.copy_or_context_menu_attempt": "Right-click context menu attempt",
        "violation.shortcut_attempt": "Keyboard shortcut or developer tool attempt",

        // Report Question Modal
        "report.modal_title": "Report Question Problem",
        "report.modal_desc": "If you believe this question contains a typo, incorrect answer key, or ambiguity, report it below for teacher review.",
        "report.category_label": "Select Problem Category:",
        "report.comment_label": "Optional Explanation (max 300 chars):",
        "report.timeout_notice": "Question time has expired. Submit or cancel your report to proceed to the next question.",
        "btn.report_question": "Report Question",
        "btn.cancel": "Cancel",
        "btn.submit_report": "Submit Report",

        // Results View
        "results.title": "Evaluation Complete",
        "results.subtitle": "Your official test mark has been registered.",
        "results.pending_title": "Pending Teacher Review",
        "results.pending_desc": "You reported questions during this test. Your final score will update automatically once the teacher completes the review.",
        "results.score_box_label": "Final Evaluation Mark",
        "results.correct_label": "Correct Answers (+1 pt):",
        "results.wrong_label": "Wrong / Expired (-1 pt):",
        "results.skipped_label": "Skipped (0 pts):",
        "results.formula_label": "Scoring Formula:",
        "results.formula_val": "Max(0, Correct − Wrong)",
        "btn.return_home": "Return to Dashboard",

        // Performance Pill Labels
        "pill.excellent": "Excellent Pass",
        "pill.very_good": "Very Good Pass",
        "pill.pass": "Pass",
        "pill.needs_improvement": "Needs Improvement",

        // System Toasts & Messages
        "msg.cooldown_reset_success": "✅ Cooldown reset! You can now start a new evaluation attempt.",
        "msg.cooldown_reset_fail": "Failed to reset cooldown.",
        "msg.enter_code": "Please enter your student identifier code.",
        "msg.select_tp": "⚠️ Please select a TP evaluation card from the options above to begin.",
        "msg.wrong_code": "Wrong student code typed: '{code}'. Please check your code.",
        "msg.cooldown_active": "⏳ Cooldown active (TP {tp} completed). Please wait {min} minute(s) before starting any attempt.",
        "msg.daily_limit": "Daily attempt limit reached (maximum {max} attempts per day).",
        "msg.server_error": "Server connection error. Please verify server is running.",
        "msg.tp_load_error": "Error loading TPs. Please refresh page.",
        "msg.network_next_q": "Network error fetching next question."
    },
    fr: {
        // App Header & Brand
        "brand.title": "Évaluation Data Mining",
        "brand.subtitle": "Plateforme d'Évaluation Continue",

        // Cooldown Banner
        "cooldown.active_label": "TEMPS DE PAUSE ACTIF :",
        "cooldown.remaining_text": "restants avant de pouvoir démarrer une nouvelle évaluation.",
        "cooldown.reset_btn": "Réinitialiser Pause (Dev)",

        // Login / Auth Screen
        "login.badge": "Système d'Évaluation Chronométré",
        "login.title": "Test Continu de TP",
        "login.subtitle": "Entrez votre code étudiant officiel et sélectionnez un TP pour commencer votre évaluation chronométrée de 20 questions.",
        "login.student_code_label": "Code d'Identification Étudiant",
        "login.student_code_placeholder": "ex: IASD01, SIAD15, RSD02, CS99",
        "login.student_code_hint": "Format : Spécialité (SIAD, IASD, RSD, CS) + numéro à 2 chiffres (01..100)",
        "login.select_tp_label": "Sélectionnez le TP à Évaluer",
        "login.loading_tps": "Chargement des TP...",
        "rule.timer": "20s Par Question :",
        "rule.timer_desc": "Chronomètre par question imposé par le serveur.",
        "rule.scoring": "Règle de Notation :",
        "rule.scoring_desc": "+1 pour correct, −1 pour faux ou expiré. Note finale sur 20.",
        "rule.cooldown": "Pause de 10 Min :",
        "rule.cooldown_desc": "Appliquée entre deux tentatives consécutives du même TP.",
        "btn.start_test": "Démarrer le Test Chronométré",
        "btn.validating_code": "Validation du Code...",

        // Detailed Information Section & Anti-Cheat System
        "info.title": "Règles d'Évaluation & Fonctionnalités de la Plateforme",
        "info.subtitle": "Structure officielle des notes, filtrage IQR, conseils sur les tentatives et sécurité.",
        
        "info.score_heading": "Calcul de la Note Continue (20 Points au Total)",
        "info.tp_weight_title": "18 Points — 6 Évaluations TP (3 pts chacun)",
        "info.tp_weight_desc": "Évaluation continue sur les 6 TP de Data Mining. Chaque TP compte pour 3 points dans la note finale (6 × 3 = 18 pts).",
        "info.teacher_weight_title": "2 Points — Note de l'Enseignant",
        "info.teacher_weight_desc": "2 points attribués directement par l'enseignant selon la présence aux TP, la participation et le travail en séance.",
        "info.total_weight_title": "Note Finale de Contrôle Continu : 20 Points",
        "info.total_weight_desc": "18 Points (6 Évaluations TP) + 2 Points (Note Enseignant) = 20 Points au Total.",
        
        "info.rules_heading": "Règles des Tentatives & Barème",
        "info.rule_correct": "+1 Point pour chaque réponse correcte.",
        "info.rule_wrong": "−1 Point pour toute réponse fausse ou expirée (sélection au hasard pénalisée).",
        "info.rule_skip": "0 Point pour les questions ignorées.",

        "info.iqr_heading": "Stratégie par Moyenne de Toutes les Tentatives Valides",
        "info.iqr_calc_title": "Calcul de la Note Finale TP (Moyenne Globale des Tentatives)",
        "info.iqr_calc_desc": "Votre note finale pour chaque TP est calculée comme la moyenne arithmétique de toutes vos tentatives valides terminées. Chaque tentative valide réalisée compte directement dans votre moyenne.",
        "info.iqr_wise_title": "Stratégie Étudiante Recommandée",
        "info.iqr_wise_desc": "Puisque chaque tentative valide influe directement sur votre moyenne globale, veillez à effectuer des tests révisés et sérieux afin que chaque note contribue à augmenter votre moyenne !",

        "info.anticheat_heading": "Mécanismes Anti-Triche & Sécurité Intégrés",
        "info.anticheat_warning": "Attention : Des mécanismes de sécurité multicouches sont actifs pour détecter la triche et l'automatisation.",
        "info.ac_timer_title": "Chronomètre Strict Côté Serveur (20s)",
        "info.ac_timer_desc": "Le temps de 20s par question est vérifié sur le serveur backend. Manipuler les scripts ou le HTML client ne peut pas stopper l'horloge.",
        "info.ac_violations_title": "Suivi des Infractions Navigateur (Max 4)",
        "info.ac_violations_desc": "Détection des changements d'onglet, pertes de focus, sortie de souris, sortie du plein écran et outils dév. 4 infractions entraînent un échec automatique (0.0/20).",
        "info.ac_traps_title": "Questions Pièges & Détection de Bots / IA",
        "info.ac_traps_desc": "La banque de questions contient des pièges masqués et des tests d'attention pour identifier les scripts automatisés, les résolveurs IA et le cliquage aléatoire.",
        "info.ac_fingerprint_title": "Enregistrement IP Haché & Empreinte Appareil",
        "info.ac_fingerprint_desc": "L'adresse IP hachée, le User-Agent et l'empreinte navigateur sont enregistrés pour chaque tentative à des fins d'audit.",

        "info.flagging_heading": "Signalement des Questions & Révision Enseignant",
        "info.flagging_title": "Signalement Étudiant & Protection des Notes (Max 3 par Test)",
        "info.flagging_desc": "Si vous remarquez une coquille, une ambiguïté ou une erreur de formulation, vous pouvez signaler jusqu'à 3 questions par test. L'épreuve passe alors en statut 'En Attente de Révision'. L'enseignant examine le signalement et peut attribuer des points bonus si l'anomalie est confirmée.",

        // Live Quiz Screen
        "quiz.question_label": "Question",
        "quiz.statement_badge": "Affirmation Vrai / Faux",
        "quiz.loading_question": "Chargement de la question...",
        "btn.true": "VRAI",
        "btn.false": "FAUX",
        "btn.skip": "Passer la question (0 pt)",
        "btn.end_test": "Terminer le Test",
        "quiz.footer_hint": "Chronométré par le serveur. Choisissez votre réponse avant que l'horloge n'atteigne 0.",

        // Fullscreen Overlay
        "fullscreen.title": "Plein Écran Requis",
        "fullscreen.desc": "Vous avez quitté le mode plein écran. La progression du test est suspendue et des infractions sont enregistrées. Cliquez ci-dessous pour revenir en plein écran et reprendre votre évaluation.",
        "btn.reenter_fullscreen": "Revenir en Mode Plein Écran",

        // End Test Confirmation Modal
        "end_test.title": "Terminer le Test d'Évaluation plus tôt ?",
        "end_test.desc": "Êtes-vous sûr de vouloir finaliser votre évaluation maintenant ? Toutes les questions sans réponse vaudront 0 point. Le chronomètre continue de tourner en arrière-plan.",
        "btn.continue_test": "Poursuivre le Test",
        "btn.confirm_end_test": "Terminer & Soumettre",

        // Report Question Modal
        "report.modal_title": "Signaler un Problème sur la Question",
        "report.modal_desc": "Si vous pensez que cette question contient une faute, une réponse incorrecte ou une ambiguïté, signalez-la ci-dessous pour examen par l'enseignant.",
        "report.category_label": "Sélectionnez la Catégorie du Problème :",
        "report.comment_label": "Explication Optionnelle (max 300 caractères) :",
        "report.timeout_notice": "Le temps imparti pour la question est écoulé. Soumettez ou annulez votre signalement pour passer à la question suivante.",
        "btn.report_question": "Signaler la Question",
        "btn.cancel": "Annuler",
        "btn.submit_report": "Soumettre le Rapport",

        // Anti-Cheat Violation Toast
        "violation.header": "INFRACTION ANTI-TRICHE DÉTECTÉE",
        "violation.warning_prefix": "Avertissement",
        "violation.subtext": "4 infractions entraîneront un échec automatique au test (Note : 0.0/20).",

        // Specific Violation Descriptions
        "violation.tab_hidden": "Changement d'onglet ou fenêtre réduite",
        "violation.window_blur": "Perte de focus de la fenêtre",
        "violation.mouse_left_viewport": "La souris est sortie du haut de la fenêtre",
        "violation.fullscreen_exit": "Sortie du mode plein écran",
        "violation.copy_or_context_menu_attempt": "Tentative d'ouverture du menu clic-droit",
        "violation.shortcut_attempt": "Tentative de raccourci clavier ou outil développeur",

        // Results View
        "results.title": "Évaluation Terminée",
        "results.subtitle": "Votre note officielle a été enregistrée.",
        "results.pending_title": "En Attente de Révision Enseignant",
        "results.pending_desc": "Vous avez signalé des questions pendant ce test. Votre note finale sera mise à jour automatiquement dès que l'enseignant aura terminé l'examen.",

        "results.score_box_label": "Note Finale d'Évaluation",
        "results.correct_label": "Réponses Correctes (+1 pt) :",
        "results.wrong_label": "Incorrectes / Expirées (-1 pt) :",
        "results.skipped_label": "Ignorées (0 pt) :",
        "results.formula_label": "Formule de Calcul :",
        "results.formula_val": "Max(0, Correctes − Incorrectes)",
        "btn.return_home": "Retour au Tableau de Bord",

        // Performance Pill Labels
        "pill.excellent": "Réussite Excellente",
        "pill.very_good": "Très Bien",
        "pill.pass": "Admis",
        "pill.needs_improvement": "À Améliorer",

        // System Toasts & Messages
        "msg.cooldown_reset_success": "✅ Temps de pause réinitialisé ! Vous pouvez commencer une nouvelle évaluation.",
        "msg.cooldown_reset_fail": "Échec de la réinitialisation de la pause.",
        "msg.enter_code": "Veuillez saisir votre code d'identification étudiant.",
        "msg.select_tp": "⚠️ Veuillez sélectionner une carte de TP ci-dessus pour commencer.",
        "msg.wrong_code": "Code étudiant incorrect : '{code}'. Veuillez vérifier votre code.",
        "msg.cooldown_active": "⏳ Pause active (TP {tp} terminé). Veuillez attendre {min} minute(s) avant de démarrer une tentative.",
        "msg.daily_limit": "Limite quotidienne de tentatives atteinte (maximum {max} tentatives par jour).",
        "msg.server_error": "Erreur de connexion au serveur. Veuillez vérifier que le serveur fonctionne.",
        "msg.tp_load_error": "Erreur de chargement des TP. Veuillez rafraîchir la page.",
        "msg.network_next_q": "Erreur réseau lors de la récupération de la question suivante."
    }
};

class StudentI18nEngine {
    constructor() {
        this.currentLang = localStorage.getItem('student_lang') || 'en';
    }

    setLanguage(lang) {
        if (lang !== 'en' && lang !== 'fr') return;
        this.currentLang = lang;
        localStorage.setItem('student_lang', lang);
        this.updateDOM();
        
        // Dispatch custom event for dynamic components (e.g., questions re-rendering)
        window.dispatchEvent(new CustomEvent('student_lang_changed', { detail: { lang: this.currentLang } }));
    }

    getLanguage() {
        return this.currentLang;
    }

    t(key, params = {}) {
        const langDict = I18N_DICTIONARY[this.currentLang] || I18N_DICTIONARY['en'];
        let text = langDict[key] || I18N_DICTIONARY['en'][key] || key;

        Object.keys(params).forEach(pKey => {
            text = text.replace(new RegExp(`\\{${pKey}\\}`, 'g'), params[pKey]);
        });

        return text;
    }

    updateDOM() {
        // Update elements with data-i18n
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            const translation = this.t(key);
            if (translation && translation !== key) {
                // If element has nested HTML icons, only update text nodes or spans
                const icon = el.querySelector('i');
                if (icon) {
                    const textSpan = el.querySelector('span:not(.tab-badge)');
                    if (textSpan) {
                        textSpan.textContent = translation;
                    } else {
                        el.childNodes.forEach(node => {
                            if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
                                node.textContent = ' ' + translation;
                            }
                        });
                    }
                } else {
                    el.textContent = translation;
                }
            }
        });

        // Update elements with data-i18n-placeholder
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            const translation = this.t(key);
            if (translation && translation !== key) {
                el.placeholder = translation;
            }
        });

        // Update elements with data-i18n-title
        document.querySelectorAll('[data-i18n-title]').forEach(el => {
            const key = el.getAttribute('data-i18n-title');
            const translation = this.t(key);
            if (translation && translation !== key) {
                el.title = translation;
            }
        });

        // Update active language switcher UI state
        document.querySelectorAll('.lang-btn').forEach(btn => {
            if (btn.dataset.lang === this.currentLang) {
                btn.classList.add('active');
                btn.style.background = 'linear-gradient(135deg, #3B82F6, #2563EB)';
                btn.style.color = '#FFFFFF';
                btn.style.borderColor = '#60A5FA';
                btn.style.boxShadow = '0 4px 12px rgba(59, 130, 246, 0.4)';
            } else {
                btn.classList.remove('active');
                btn.style.background = 'rgba(255, 255, 255, 0.06)';
                btn.style.color = '#94A3B8';
                btn.style.borderColor = 'rgba(255, 255, 255, 0.12)';
                btn.style.boxShadow = 'none';
            }
        });
    }
}

// Global i18n instance
window.studentI18n = new StudentI18nEngine();
