/* ==========================================================================
   Data Mining TP Evaluation Platform — SPA JavaScript Controller
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
    // App State
    let selectedTPId = null;
    let studentCode = '';
    let attemptId = null;
    let currentQuestionId = null;
    let secondsRemaining = 20;
    let timerInterval = null;
    let isSubmitting = false;

    const TIMER_FULL_DASH_ARRAY = 264; // SVG circumference 2 * pi * 42

    // DOM Elements
    const screenLogin = document.getElementById('screen-login');
    const screenQuiz = document.getElementById('screen-quiz');
    const screenResults = document.getElementById('screen-results');
    const screenClosed = document.getElementById('screen-closed');

    const tpGrid = document.getElementById('tp-grid');
    const startForm = document.getElementById('start-form');
    const codeInput = document.getElementById('student-code-input');
    const btnStartTest = document.getElementById('btn-start-test');

    const alertBanner = document.getElementById('alert-banner');
    const alertMessage = document.getElementById('alert-message');
    const alertClose = document.getElementById('alert-close');

    const topCooldownBar = document.getElementById('top-cooldown-bar');
    const topCooldownTimer = document.getElementById('top-cooldown-timer');

    const userBadge = document.getElementById('user-badge');
    const activeUserCode = document.getElementById('active-user-code');

    const currentPosEl = document.getElementById('current-pos');
    const totalPosEl = document.getElementById('total-pos');
    const progressBarFill = document.getElementById('progress-bar-fill');

    const timerWidget = document.getElementById('timer-widget');
    const timerProgressCircle = document.getElementById('timer-progress-circle');
    const timerDisplayNum = document.getElementById('timer-display-num');

    const questionTextEl = document.getElementById('question-text');
    const btnAnswerTrue = document.getElementById('btn-answer-true');
    const btnAnswerFalse = document.getElementById('btn-answer-false');
    const btnAnswerSkip = document.getElementById('btn-answer-skip');

    const finalScoreVal = document.getElementById('final-score-val');
    const performancePill = document.getElementById('performance-pill');
    const btnReturnHome = document.getElementById('btn-return-home');

    // Cookie Helper Functions for Autofill
    function setCookie(name, value, days = 30) {
        const d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = `${name}=${encodeURIComponent(value)};expires=${d.toUTCString()};path=/`;
        try { localStorage.setItem(name, value); } catch (e) {}
    }

    function getCookie(name) {
        try {
            const localVal = localStorage.getItem(name);
            if (localVal) return localVal;
        } catch (e) {}

        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : '';
    }

    // Restore saved student identifier code
    function loadSavedStudentCode() {
        const savedCode = getCookie('student_code');
        if (savedCode) {
            codeInput.value = savedCode;
            validateForm();
        }
    }

    // 1. Device Fingerprinting Generator
    function getDeviceFingerprint() {
        const raw = [
            navigator.userAgent,
            navigator.language,
            screen.width + 'x' + screen.height,
            screen.colorDepth,
            new Date().getTimezoneOffset()
        ].join('|');
        
        let hash = 0;
        for (let i = 0; i < raw.length; i++) {
            const char = raw.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0;
        }
        return 'fp_' + Math.abs(hash).toString(16);
    }

    // Alert Banner Utility
    function showAlert(msg) {
        alertMessage.textContent = msg;
        alertBanner.classList.remove('hidden');
        alertBanner.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function hideAlert() {
        alertBanner.classList.add('hidden');
    }

    if (alertClose) alertClose.addEventListener('click', hideAlert);

    // Language Switcher Bindings
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const lang = btn.dataset.lang;
            if (window.studentI18n) {
                window.studentI18n.setLanguage(lang);
            }
        });
    });

    window.addEventListener('student_lang_changed', (e) => {
        if (window.studentI18n) window.studentI18n.updateDOM();
        if (lastServedQuestionPayload && screenQuiz.classList.contains('active')) {
            renderQuestionPayload(lastServedQuestionPayload, false);
        }
    });

    let lastServedQuestionPayload = null;

    let cooldownInterval = null;

    function startCooldownTimer(remainingSec) {
        clearInterval(cooldownInterval);
        btnStartTest.disabled = true;
        if (topCooldownBar) topCooldownBar.classList.remove('hidden');

        function updateDisplay() {
            if (remainingSec <= 0) {
                clearInterval(cooldownInterval);
                if (topCooldownBar) topCooldownBar.classList.add('hidden');
                showAlert(window.studentI18n.t('msg.cooldown_reset_success'));
                btnStartTest.disabled = false;
                btnStartTest.querySelector('span').textContent = window.studentI18n.t('btn.start_test');
                return;
            }

            const mins = Math.floor(remainingSec / 60);
            const secs = remainingSec % 60;
            const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
            
            if (topCooldownTimer) topCooldownTimer.textContent = timeStr;
            btnStartTest.querySelector('span').textContent = window.studentI18n.t('btn.start_test');
            remainingSec--;
        }

        updateDisplay();
        cooldownInterval = setInterval(updateDisplay, 1000);
    }



    let isQuizActive = false;

    // 3. Screen Switching Helper
    function showScreen(screenName) {
        // Hide loading gate if present
        const screenGate = document.getElementById('screen-gate-loading');
        if (screenGate) {
            screenGate.classList.add('hidden');
            screenGate.classList.remove('active');
            screenGate.style.display = 'none';
        }

        // Hide all screens
        if (screenLogin) {
            screenLogin.classList.add('hidden');
            screenLogin.classList.remove('active');
        }
        if (screenQuiz) {
            screenQuiz.classList.add('hidden');
            screenQuiz.classList.remove('active');
        }
        if (screenResults) {
            screenResults.classList.add('hidden');
            screenResults.classList.remove('active');
        }
        if (screenClosed) {
            screenClosed.classList.add('hidden');
            screenClosed.classList.remove('active');
        }

        if (screenName === 'login') {
            // Strictly guard against showing login screen if platform is closed
            if (scheduleStatusData && !scheduleStatusData.is_open && !isManualRevisionViewing) {
                showScreen('closed');
                return;
            }
            isQuizActive = false;
            if (fullscreenOverlay) fullscreenOverlay.classList.add('hidden');
            if (screenLogin) {
                screenLogin.classList.remove('hidden');
                screenLogin.classList.add('active');
            }
            if (userBadge) userBadge.classList.add('hidden');
        } else if (screenName === 'closed') {
            isQuizActive = false;
            if (fullscreenOverlay) fullscreenOverlay.classList.add('hidden');
            if (screenClosed) {
                screenClosed.classList.remove('hidden');
                screenClosed.classList.add('active');
            }
            if (userBadge) userBadge.classList.add('hidden');
        } else if (screenName === 'quiz') {
            isQuizActive = true;
            if (screenQuiz) {
                screenQuiz.classList.remove('hidden');
                screenQuiz.classList.add('active');
            }
            if (userBadge) userBadge.classList.remove('hidden');
        } else if (screenName === 'results') {
            isQuizActive = false;
            if (fullscreenOverlay) fullscreenOverlay.classList.add('hidden');
            if (document.fullscreenElement) {
                document.exitFullscreen().catch(() => {});
            }
            if (screenResults) {
                screenResults.classList.remove('hidden');
                screenResults.classList.add('active');
            }
            if (userBadge) userBadge.classList.remove('hidden');
        }
        if (window.studentI18n) window.studentI18n.updateDOM();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Dynamic Forensic Anti-Photo Watermark
    function updateWatermark(code) {
        const overlay = document.getElementById('quiz-watermark-overlay');
        if (!overlay) return;
        const now = new Date();
        const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0') + ':' + now.getSeconds().toString().padStart(2, '0');
        const stamp = `${code || studentCode || 'STUDENT'} • ${timeStr}`;
        const items = [];
        for (let i = 0; i < 32; i++) {
            items.push(`<div class="quiz-watermark-item">${stamp}</div>`);
        }
        overlay.innerHTML = items.join('');
    }

    // Schedule & Revision Hub Controller
    let scheduleStatusData = null;
    let pendingTelemetryEvents = [];
    let isManualRevisionViewing = false;

    async function checkScheduleStatus() {
        try {
            const res = await fetch('/api/schedule-status');
            if (!res.ok) return;
            const data = await res.json();
            scheduleStatusData = data;

            updateLoginScreenScheduleDisplay(data);
            validateForm();

            const urlParams = new URLSearchParams(window.location.search);
            const isPreviewClosed = urlParams.has('closed') || urlParams.get('view') === 'closed' || urlParams.has('preview');
            const shouldBeClosed = (!data.is_open || isPreviewClosed || isManualRevisionViewing);

            if (shouldBeClosed) {
                // If quiz is not actively running, switch to closed screen
                if (!screenQuiz.classList.contains('active') && !screenResults.classList.contains('active')) {
                    showScreen('closed');
                }
                updateClosedScreenDisplay(data, !data.is_open);
            } else {
                // If currently open and quiz is not active, switch to login screen
                if (!screenQuiz.classList.contains('active') && !screenResults.classList.contains('active') && !isManualRevisionViewing) {
                    showScreen('login');
                }
            }
        } catch (e) {
            console.warn("Schedule check note:", e);
        }
    }

    function updateLoginScreenScheduleDisplay(data) {
        if (!data) return;
        const groupsListEl = document.getElementById('login-active-groups-list');
        const slotIndEl = document.getElementById('login-slot-indicator');
        const slotTextEl = document.getElementById('login-slot-text');

        const activeGroups = data.active_groups || ['CS', 'RSD', 'IASD', 'SIAD'];
        const allGroups = ['CS', 'RSD', 'IASD', 'SIAD'];

        if (groupsListEl) {
            groupsListEl.innerHTML = allGroups.map(g => {
                const isActive = activeGroups.includes(g);
                if (isActive) {
                    return `<span class="group-badge-pill grp-active" title="Spécialité ${g} autorisée"><i class="fa-solid fa-check" style="font-size: 8px; margin-right: 3px;"></i>${g}</span>`;
                } else {
                    return `<span class="group-badge-pill grp-locked" title="Spécialité ${g} verrouillée par l'enseignant"><i class="fa-solid fa-lock" style="font-size: 8px; margin-right: 3px;"></i>${g}</span>`;
                }
            }).join('');
        }

        if (slotIndEl && slotTextEl) {
            if (data.is_open) {
                slotIndEl.style.color = '#34d399';
                const closesAt = (data.metadata && data.metadata.closes_at) ? data.metadata.closes_at : '';
                const slotName = (data.metadata && data.metadata.active_slot === 'morning') ? 'Matin' : ((data.metadata && data.metadata.active_slot === 'afternoon') ? 'Après-midi / Soir' : 'Active');
                slotTextEl.textContent = `Session ${slotName} (ferme à ${closesAt || '--'})`;
            } else {
                slotIndEl.style.color = '#f87171';
                if (data.status_code === 'DEACTIVATED_BY_TEACHER') {
                    slotTextEl.textContent = 'Tests Suspendus';
                } else if (data.status_code === 'CLOSED_MORNING_LOCKED') {
                    slotTextEl.textContent = 'Matin Verrouillé';
                } else if (data.status_code === 'CLOSED_AFTERNOON_LOCKED') {
                    slotTextEl.textContent = 'Soir Verrouillé';
                } else {
                    slotTextEl.textContent = 'Plateforme Fermée';
                }
            }
        }
    }

    function updateClosedScreenDisplay(data, isActuallyClosed) {
        const statusPill = document.getElementById('closed-status-pill');
        const statusPillText = document.getElementById('closed-status-pill-text');
        const descEl = document.getElementById('closed-status-desc');
        const reopenNotice = document.getElementById('closed-reopen-notice');
        const reopenText = document.getElementById('closed-reopen-text');
        const backContainer = document.getElementById('closed-back-container');

        if (isActuallyClosed) {
            // Strictly hide any back-to-login button when closed!
            if (backContainer) backContainer.style.display = 'none';
            if (statusPill) statusPill.style.display = 'inline-flex';
            if (statusPillText) {
                if (data.status_code === 'DEACTIVATED_BY_TEACHER') {
                    statusPillText.textContent = "Tests Suspendus par l'Enseignant • Stopped by Teacher";
                } else if (data.status_code === 'CLOSED_MORNING_LOCKED') {
                    statusPillText.textContent = "Session Matin Verrouillée • Morning Locked";
                } else if (data.status_code === 'CLOSED_AFTERNOON_LOCKED') {
                    statusPillText.textContent = "Session Soir Verrouillée • Evening Locked";
                } else if (data.status_code === 'GROUP_LOCKED_BY_TEACHER') {
                    statusPillText.textContent = "Spécialité Verrouillée • Group Locked";
                } else {
                    statusPillText.textContent = 'Plateforme Fermée • Platform Closed';
                }
            }
            if (descEl) {
                const isFr = (!window.studentI18n || window.studentI18n.currentLang === 'fr');
                descEl.textContent = isFr ? (data.message_fr || data.message_en) : (data.message_en || data.message_fr);
                descEl.style.display = 'block';
            }
            if (reopenNotice) {
                reopenNotice.style.display = 'none';
            }
        } else {
            // Open hours: only show back button if student was voluntarily viewing revision hub
            if (backContainer) backContainer.style.display = isManualRevisionViewing ? 'block' : 'none';
            if (statusPill) statusPill.style.display = 'none';
            if (reopenNotice) reopenNotice.style.display = 'none';
            if (descEl) {
                descEl.textContent = "Ressources vidéo académiques recommandées pour les concepts fondamentaux de Data Mining.";
            }
        }

        const closedGroupsList = document.getElementById('closed-active-groups-list');
        if (closedGroupsList && data) {
            const activeGroups = data.active_groups || ['CS', 'RSD', 'IASD', 'SIAD'];
            const allGroups = data.all_groups || ['CS', 'RSD', 'IASD', 'SIAD'];
            closedGroupsList.innerHTML = allGroups.map(g => {
                const isActive = activeGroups.includes(g);
                if (isActive) {
                    return `<span class="group-badge-pill grp-active" title="Spécialité ${g} autorisée"><i class="fa-solid fa-check" style="font-size: 8px; margin-right: 3px;"></i>${g}</span>`;
                } else {
                    return `<span class="group-badge-pill grp-locked" title="Spécialité ${g} verrouillée par l'enseignant"><i class="fa-solid fa-lock" style="font-size: 8px; margin-right: 3px;"></i>${g}</span>`;
                }
            }).join('');
        }
    }

    // 4. Fetch Available TPs with Customized Topic Icons
    async function loadTPs() {
        try {
            const res = await fetch('/api/tps');
            if (!res.ok) throw new Error('Failed to load TPs');
            const tps = await res.json();

            // Mapped icons for each classical Data Mining module
            const tpIcons = {
                1: 'fa-solid fa-broom',          // TP1: Data Cleaning & Missing Values
                2: 'fa-solid fa-chart-pie',      // TP2: Exploratory Data Analysis & Viz
                3: 'fa-solid fa-sliders',        // TP3: Preprocessing, Scaling & Encoding
                4: 'fa-solid fa-bullseye',       // TP4: Evaluation Metrics & ROC-AUC
                5: 'fa-solid fa-sitemap',        // TP5: Decision Trees & Random Forest
                6: 'fa-solid fa-circle-nodes'    // TP6: Clustering & K-Means
            };

            tpGrid.innerHTML = '';
            tps.forEach(tp => {
                const iconClass = tpIcons[tp.id] || 'fa-solid fa-database';
                const card = document.createElement('div');
                card.className = 'tp-card';
                card.dataset.tpId = tp.id;
                card.innerHTML = `
                    <div class="tp-icon-box"><i class="${iconClass}"></i></div>
                    <div class="tp-details">
                        <span>TP ${tp.id} Evaluation</span>
                        <small>${tp.name.split(':')[1] || tp.name}</small>
                    </div>
                `;

                card.addEventListener('click', () => {
                    document.querySelectorAll('.tp-card').forEach(c => c.classList.remove('selected'));
                    card.classList.add('selected');
                    selectedTPId = tp.id;
                    hideAlert();
                    validateForm();
                });

                tpGrid.appendChild(card);
            });
        } catch (err) {
            tpGrid.innerHTML = `<div class="text-danger">${window.studentI18n.t('msg.tp_load_error')}</div>`;
        }
    }

    function validateForm() {
        const code = codeInput ? codeInput.value.trim().toUpperCase().replace(/[-_]/g, '') : '';
        let isGroupLocked = false;

        if (code.length >= 2 && scheduleStatusData) {
            let detectedGrp = '';
            for (const g of ['IASD', 'SIAD', 'RSD', 'CS']) {
                if (code.startsWith(g)) {
                    detectedGrp = g;
                    break;
                }
            }
            const activeGroups = scheduleStatusData.active_groups || ['CS', 'RSD', 'IASD', 'SIAD'];
            const warningEl = document.getElementById('code-group-warning');
            const warningText = document.getElementById('code-group-warning-text');

            if (detectedGrp && !activeGroups.includes(detectedGrp)) {
                isGroupLocked = true;
                if (warningEl && warningText) {
                    warningText.textContent = `Les évaluations pour la spécialité '${detectedGrp}' sont actuellement verrouillées par l'enseignant. Spécialités autorisées : [${activeGroups.join(', ')}].`;
                    warningEl.style.display = 'block';
                }
            } else {
                if (warningEl) warningEl.style.display = 'none';
            }
        } else {
            const warningEl = document.getElementById('code-group-warning');
            if (warningEl) warningEl.style.display = 'none';
        }

        if (btnStartTest) {
            btnStartTest.disabled = (code.length < 2 || isGroupLocked);
        }
    }

    if (codeInput) {
        codeInput.addEventListener('input', () => {
            hideAlert();
            validateForm();
        });
    }

    // Start Quiz Attempt
    if (startForm) {
        startForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            hideAlert();

            studentCode = codeInput.value.trim().toUpperCase();

            if (!studentCode) {
                showAlert(window.studentI18n.t('msg.enter_code'));
                codeInput.focus();
                return;
            }

            if (selectedTPId === null) {
                showAlert(window.studentI18n.t('msg.select_tp'));
                tpGrid.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                return;
            }

            btnStartTest.disabled = true;
            btnStartTest.querySelector('span').textContent = window.studentI18n.t('btn.validating_code');

            try {
                const res = await fetch('/api/attempt/start', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        code: studentCode,
                        tp_id: selectedTPId,
                        device_fingerprint: getDeviceFingerprint(),
                        user_agent: navigator.userAgent
                    })
                });

                const data = await res.json();

                if (!res.ok) {
                    if (res.status === 403) {
                        checkScheduleStatus();
                        showAlert(data.detail);
                        btnStartTest.disabled = false;
                        btnStartTest.querySelector('span').textContent = window.studentI18n.t('btn.start_test');
                        return;
                    } else if (res.status === 429) {
                        let sec = 600;
                        const match = data.detail ? data.detail.match(/\((\d+)s remaining\)/) : null;
                        if (match) {
                            sec = parseInt(match[1]);
                        } else if (res.headers.get('X-Cooldown-Remaining-Sec')) {
                            sec = parseInt(res.headers.get('X-Cooldown-Remaining-Sec'));
                        }
                        const min = Math.ceil(sec / 60);
                        showAlert(data.detail || window.studentI18n.t('msg.cooldown_active', { tp: selectedTPId, min: min }), true);
                        startCooldownTimer(sec);
                    } else {
                        showAlert(data.detail || window.studentI18n.t('msg.wrong_code', { code: studentCode }));
                        btnStartTest.disabled = false;
                        btnStartTest.querySelector('span').textContent = window.studentI18n.t('btn.start_test');
                    }
                    return;
                }

                setCookie('student_code', studentCode, 30);

                attemptId = data.attempt_id;
                currentViolationCount = 0;
                pendingTelemetryEvents = [];
                updateWatermark(studentCode);
                activeUserCode.textContent = studentCode + ' (TP ' + selectedTPId + ')';
                
                showScreen('quiz');
                requestFullscreenMode();
                fetchNextQuestion();

            } catch (err) {
                showAlert(window.studentI18n.t('msg.server_error'));
                btnStartTest.disabled = false;
                btnStartTest.querySelector('span').textContent = window.studentI18n.t('btn.start_test');
            }
        });
    }

    // Auto-finish attempt if student refreshes or exits page during active quiz
    window.addEventListener('beforeunload', () => {
        if (attemptId && screenQuiz.classList.contains('active')) {
            navigator.sendBeacon(`/api/attempt/${attemptId}/finish`);
        }
    });

    // Anti-Cheat Violation Manager & Toast System
    const fullscreenOverlay = document.getElementById('fullscreen-overlay');
    const btnReenterFullscreen = document.getElementById('btn-reenter-fullscreen');
    const violationToast = document.getElementById('violation-toast');
    const violationBadge = document.getElementById('violation-badge');
    const violationDesc = document.getElementById('violation-desc');

    let currentViolationCount = 0;
    let violationToastTimeout = null;

    function requestFullscreenMode() {
        if (document.fullscreenElement) return;
        try {
            const docEl = document.documentElement;
            if (docEl.requestFullscreen) {
                const res = docEl.requestFullscreen();
                if (res && typeof res.catch === 'function') {
                    res.catch(err => {
                        console.warn("Fullscreen notice:", err ? (err.message || err) : 'Denied');
                    });
                }
            }
        } catch (e) {}
    }


    if (btnReenterFullscreen) {
        btnReenterFullscreen.addEventListener('click', () => {
            requestFullscreenMode();
        });
    }

    document.addEventListener('fullscreenchange', () => {
        if (screenQuiz.classList.contains('active') && isQuizActive) {
            if (!document.fullscreenElement) {
                if (fullscreenOverlay) fullscreenOverlay.classList.remove('hidden');
                reportViolationEvent("fullscreen_exit", window.studentI18n.t("violation.fullscreen_exit"));
            } else {
                if (fullscreenOverlay) fullscreenOverlay.classList.add('hidden');
            }
        } else {
            if (fullscreenOverlay) fullscreenOverlay.classList.add('hidden');
        }
    });

    let isEndTestModalOpen = false;
    let isReportModalOpen = false;
    let questionTimedOutWhileReporting = false;

    function reportViolationEvent(eventType, details) {
        if (!attemptId || !screenQuiz.classList.contains('active') || isEndTestModalOpen || isReportModalOpen || !isQuizActive) return;

        // Buffer telemetry so it gets piggybacked into mandatory /answer requests
        pendingTelemetryEvents.push(`${eventType}: ${details || ''}`);

        const payload = JSON.stringify({ event_type: eventType, details: details });
        if (navigator.sendBeacon) {
            navigator.sendBeacon(`/api/attempt/${attemptId}/event`, new Blob([payload], { type: 'application/json' }));
        } else {
            fetch(`/api/attempt/${attemptId}/event`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: payload
            }).catch(() => {});
        }

        currentViolationCount++;
        showViolationToast(eventType, details, currentViolationCount);

        if (currentViolationCount >= 4) {
            clearInterval(timerInterval);
            setTimeout(() => {
                finishQuizEarlyDueToViolations();
            }, 600);
        }
    }

    function showViolationToast(eventType, details, count) {
        if (!violationToast) return;
        clearTimeout(violationToastTimeout);
        if (violationBadge) violationBadge.textContent = `${window.studentI18n.t('violation.warning_prefix')} ${count}/4`;
        if (violationDesc) violationDesc.textContent = `${details || eventType}!`;
        violationToast.classList.remove('hidden');

        violationToastTimeout = setTimeout(() => {
            violationToast.classList.add('hidden');
        }, 4000);
    }

    async function finishQuizEarlyDueToViolations() {
        clearInterval(timerInterval);
        try {
            await fetch(`/api/attempt/${attemptId}/finish`, { method: 'POST' });
        } catch (e) {}
        finishAttempt();
    }

    // Monitor Page Visibility & Window Focus
    document.addEventListener('visibilitychange', () => {
        if (document.hidden && screenQuiz.classList.contains('active')) {
            reportViolationEvent("tab_hidden", window.studentI18n.t("violation.tab_hidden"));
        }
    });

    window.addEventListener('blur', () => {
        if (screenQuiz.classList.contains('active')) {
            reportViolationEvent("window_blur", window.studentI18n.t("violation.window_blur"));
        }
    });

    // Monitor Mouse Leaving Viewport
    document.addEventListener('mouseleave', (e) => {
        if (screenQuiz.classList.contains('active') && e.clientY <= 0) {
            reportViolationEvent("mouse_left_viewport", window.studentI18n.t("violation.mouse_left_viewport"));
        }
    });

    // Prevent Context Menu & Shortcut Keys
    document.addEventListener('contextmenu', (e) => {
        if (screenQuiz.classList.contains('active')) {
            e.preventDefault();
            reportViolationEvent("copy_or_context_menu_attempt", window.studentI18n.t("violation.copy_or_context_menu_attempt"));
            return false;
        }
    });

    document.addEventListener('keydown', (e) => {
        if (!screenQuiz.classList.contains('active')) return;

        const key = e.key.toLowerCase();
        const isCmdCtrl = e.ctrlKey || e.metaKey;

        if (isCmdCtrl && (key === 'c' || key === 'v' || key === 'u' || key === 'a' || key === 's' || key === 'p')) {
            e.preventDefault();
            reportViolationEvent("shortcut_attempt", window.studentI18n.t("violation.shortcut_attempt"));
            return false;
        }

        if (e.key === 'F12' || (isCmdCtrl && e.shiftKey && (key === 'i' || key === 'j' || key === 'c'))) {
            e.preventDefault();
            reportViolationEvent("shortcut_attempt", window.studentI18n.t("violation.shortcut_attempt"));
            return false;
        }
    });

    // 6. Fetch Next Question & Render
    function renderQuestionPayload(data, startTimer = true) {
        if (!data) return;
        lastServedQuestionPayload = data;

        if (data.finished) {
            finishAttempt();
            return;
        }

        currentQuestionId = data.question_id;
        
        // Localized question statement
        const currentLang = window.studentI18n.getLanguage();
        if (data.text_multilingual && data.text_multilingual[currentLang]) {
            questionTextEl.textContent = data.text_multilingual[currentLang];
        } else {
            questionTextEl.textContent = data.text;
        }
        
        currentPosEl.textContent = data.position;
        totalPosEl.textContent = data.total;

        const progressPct = (data.position / data.total) * 100;
        progressBarFill.style.width = `${progressPct}%`;

        if (data.flags_remaining !== undefined) {
            flagsRemaining = data.flags_remaining;
            if (flagsRemainingBadge) {
                flagsRemainingBadge.textContent = `${flagsRemaining}/3`;
            }
        }


        // Render Randomized True/False Button Order
        const optionsContainer = document.querySelector('.answers-grid');
        if (optionsContainer && data.options && Array.isArray(data.options)) {
            optionsContainer.innerHTML = '';
            data.options.forEach(optVal => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = `btn btn-choice ${optVal ? 'btn-true' : 'btn-false'}`;
                btn.id = optVal ? 'btn-answer-true' : 'btn-answer-false';
                btn.innerHTML = optVal 
                    ? `<i class="fa-solid fa-check"></i><span>${window.studentI18n.t('btn.true')}</span>` 
                    : `<i class="fa-solid fa-xmark"></i><span>${window.studentI18n.t('btn.false')}</span>`;
                btn.onclick = () => submitAnswer(optVal);
                optionsContainer.appendChild(btn);
            });
        }

        const btnSkip = document.getElementById('btn-answer-skip');
        if (btnSkip) btnSkip.disabled = false;
        isSubmitting = false;

        updateWatermark(studentCode);

        if (startTimer) {
            startQuestionTimer();
        }
    }

    async function fetchNextQuestion() {
        clearInterval(timerInterval);
        isSubmitting = false;

        try {
            const currentLang = window.studentI18n ? window.studentI18n.getLanguage() : 'en';
            const res = await fetch(`/api/attempt/${attemptId}/next-question?lang=${currentLang}`);
            const data = await res.json();

            if (!res.ok) {
                showAlert(data.detail || window.studentI18n.t('msg.network_next_q'));
                return;
            }

            renderQuestionPayload(data, true);

        } catch (err) {
            showAlert(window.studentI18n.t('msg.network_next_q'));
        }
    }

    // 7. 20s Visual Countdown Timer
    function startQuestionTimer() {
        secondsRemaining = 20;
        updateTimerUI();

        timerInterval = setInterval(() => {
            secondsRemaining--;
            updateTimerUI();

            if (secondsRemaining <= 0) {
                clearInterval(timerInterval);
                if (isReportModalOpen) {
                    questionTimedOutWhileReporting = true;
                    // Silently log question timeout on server without fetching or starting next question timer yet
                    fetch(`/api/attempt/${attemptId}/answer`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            question_id: currentQuestionId,
                            chosen: null
                        })
                    }).catch(err => console.error("Error recording timeout during report:", err));

                    const timeoutNotice = document.getElementById('report-timeout-notice');
                    if (timeoutNotice) timeoutNotice.classList.remove('hidden');
                } else {
                    submitAnswer(null);
                }
            }
        }, 1000);
    }

    function updateTimerUI() {
        timerDisplayNum.textContent = secondsRemaining;

        const fraction = secondsRemaining / 20;
        const dashoffset = TIMER_FULL_DASH_ARRAY * (1 - fraction);
        timerProgressCircle.style.strokeDashoffset = dashoffset;

        timerWidget.classList.remove('warning', 'danger');
        if (secondsRemaining <= 5) {
            timerWidget.classList.add('danger');
        } else if (secondsRemaining <= 10) {
            timerWidget.classList.add('warning');
        }
    }

    // 8. Submit Answer
    async function submitAnswer(chosenValue) {
        if (isSubmitting) return;
        isSubmitting = true;
        clearInterval(timerInterval);

        // Highlight selected choice instantly
        if (chosenValue === true) {
            const btnTrue = document.getElementById('btn-answer-true');
            if (btnTrue) btnTrue.classList.add('selected-feedback');
        } else if (chosenValue === false) {
            const btnFalse = document.getElementById('btn-answer-false');
            if (btnFalse) btnFalse.classList.add('selected-feedback');
        }

        const allBtns = document.querySelectorAll('.answers-grid button, #btn-answer-skip');
        allBtns.forEach(b => b.disabled = true);

        try {
            const currentLang = window.studentI18n ? window.studentI18n.getLanguage() : 'en';
            const res = await fetch(`/api/attempt/${attemptId}/answer-and-next?lang=${currentLang}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    question_id: currentQuestionId,
                    chosen: chosenValue,
                    telemetry: {
                        new_events: pendingTelemetryEvents.splice(0)
                    }
                })
            });

            if (!res.ok) {
                fetchNextQuestion();
                return;
            }

            const data = await res.json();
            renderQuestionPayload(data.next_question, true);

        } catch (err) {
            showAlert(window.studentI18n.t('msg.network_next_q'));
            fetchNextQuestion();
        }
    }


    if (btnAnswerTrue) btnAnswerTrue.addEventListener('click', () => submitAnswer(true));
    if (btnAnswerFalse) btnAnswerFalse.addEventListener('click', () => submitAnswer(false));
    if (btnAnswerSkip) {
        btnAnswerSkip.addEventListener('click', () => submitAnswer(null));
    }

    const endTestModal = document.getElementById('end-test-modal');
    const btnCancelEndTest = document.getElementById('btn-cancel-end-test');
    const btnConfirmEndTest = document.getElementById('btn-confirm-end-test');
    const btnExitTest = document.getElementById('btn-exit-test');

    if (btnExitTest) {
        btnExitTest.addEventListener('click', () => {
            isEndTestModalOpen = true;
            if (endTestModal) endTestModal.classList.remove('hidden');
        });
    }

    if (btnCancelEndTest) {
        btnCancelEndTest.addEventListener('click', () => {
            isEndTestModalOpen = false;
            if (endTestModal) endTestModal.classList.add('hidden');
        });
    }

    if (btnConfirmEndTest) {
        btnConfirmEndTest.addEventListener('click', () => {
            isEndTestModalOpen = false;
            if (endTestModal) endTestModal.classList.add('hidden');
            isQuizActive = false;
            if (fullscreenOverlay) fullscreenOverlay.classList.add('hidden');
            finishAttempt();
        });
    }

    // 9. Finish Quiz Attempt
    async function finishAttempt() {
        isQuizActive = false;
        if (fullscreenOverlay) fullscreenOverlay.classList.add('hidden');
        if (document.fullscreenElement) {
            document.exitFullscreen().catch(() => {});
        }
        clearInterval(timerInterval);
        try {
            const res = await fetch(`/api/attempt/${attemptId}/finish`, {
                method: 'POST'
            });
            const data = await res.json();

            if (!res.ok) {
                showAlert(data.detail || window.studentI18n.t('msg.server_error'));
                return;
            }

            // Display Results
            const mark = data.final_mark.toFixed(1);
            finalScoreVal.textContent = mark;

            document.getElementById('res-correct-count').textContent = data.correct_count || 0;
            document.getElementById('res-wrong-count').textContent = data.wrong_count || 0;
            document.getElementById('res-skipped-count').textContent = data.skipped_count || 0;

            if (data.final_mark >= 10.0) {
                performancePill.className = 'performance-pill pill-pass';
                performancePill.textContent = mark >= 16 ? window.studentI18n.t('pill.excellent') : (mark >= 14 ? window.studentI18n.t('pill.very_good') : window.studentI18n.t('pill.pass'));
            } else {
                performancePill.className = 'performance-pill pill-fail';
                performancePill.textContent = window.studentI18n.t('pill.needs_improvement');
            }

            const pendingBanner = document.getElementById('pending-review-banner');
            if (pendingBanner) {
                if (data.status === 'pending_review') {
                    pendingBanner.classList.remove('hidden');
                } else {
                    pendingBanner.classList.add('hidden');
                }
            }

            showScreen('results');

        } catch (err) {
            showAlert(window.studentI18n.t('msg.server_error'));
        }
    }

    // Question Flag / Report Dialog & Form Handling
    const btnReportQuestion = document.getElementById('btn-report-question');
    const flagsRemainingBadge = document.getElementById('flags-remaining-badge');
    const reportQuestionModal = document.getElementById('report-question-modal');
    const reportCounterModal = document.getElementById('report-counter-modal');
    const reportForm = document.getElementById('report-form');
    const btnCancelReport = document.getElementById('btn-cancel-report');

    let currentQuestionCannotBeFlagged = false;
    let flagsRemaining = 3;

    // Hook into renderQuestionPayload to track flag lock and remaining flags
    const originalRenderQuestionPayload = renderQuestionPayload;
    renderQuestionPayload = function(data, startTimer) {
        currentQuestionCannotBeFlagged = data.cannot_be_flagged || false;
        if (data.flags_remaining !== undefined) {
            flagsRemaining = data.flags_remaining;
            if (flagsRemainingBadge) flagsRemainingBadge.textContent = `${flagsRemaining}/3`;
        }
        if (originalRenderQuestionPayload) {
            originalRenderQuestionPayload(data, startTimer);
        }
    };

    if (btnReportQuestion) {
        btnReportQuestion.addEventListener('click', async () => {
            if (currentQuestionCannotBeFlagged) {
                showAlert("This question has been verified as 100% correct by the teacher and cannot be reported. Skipping to next question...");
                await submitAnswer(null);
                return;
            }
            if (flagsRemaining <= 0) {
                showAlert("You have reached the maximum limit of 3 question reports per attempt.");
                return;
            }
            if (reportCounterModal) {
                reportCounterModal.textContent = `${flagsRemaining}/3 Reports Remaining`;
            }
            isReportModalOpen = true;
            questionTimedOutWhileReporting = false;
            const timeoutNotice = document.getElementById('report-timeout-notice');
            if (timeoutNotice) timeoutNotice.classList.add('hidden');
            if (reportQuestionModal) reportQuestionModal.classList.remove('hidden');
        });
    }

    if (btnCancelReport) {
        btnCancelReport.addEventListener('click', async () => {
            isReportModalOpen = false;
            if (reportQuestionModal) reportQuestionModal.classList.add('hidden');
            const timeoutNotice = document.getElementById('report-timeout-notice');
            if (timeoutNotice) timeoutNotice.classList.add('hidden');
            requestFullscreenMode();

            if (questionTimedOutWhileReporting) {
                questionTimedOutWhileReporting = false;
                await fetchNextQuestion();
            }
        });
    }

    if (reportForm) {
        reportForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            requestFullscreenMode();

            const category = document.getElementById('report-category-select').value;
            const commentInput = document.getElementById('report-comment-input');
            const comment = commentInput ? commentInput.value.trim() : '';

            if (!attemptId || !currentQuestionId) return;

            const btnSubmitReport = reportForm.querySelector('button[type="submit"]');
            const origBtnText = btnSubmitReport ? btnSubmitReport.innerHTML : 'Submit Report';

            if (btnSubmitReport) {
                btnSubmitReport.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting & Loading Next...';
                btnSubmitReport.disabled = true;
            }

            const allBtns = document.querySelectorAll('.answers-grid button, #btn-answer-skip');
            allBtns.forEach(b => b.disabled = true);

            try {
                const res = await fetch(`/api/attempt/${attemptId}/flag-question`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        question_id: currentQuestionId,
                        reason_category: category,
                        student_comment: comment
                    })
                });

                const data = await res.json();

                if (!res.ok) {
                    allBtns.forEach(b => b.disabled = false);
                    if (btnSubmitReport) {
                        btnSubmitReport.innerHTML = origBtnText;
                        btnSubmitReport.disabled = false;
                    }
                    showAlert(data.detail || "Unable to submit report.");
                    return;
                }

                flagsRemaining = data.flags_remaining;
                if (flagsRemainingBadge) flagsRemainingBadge.textContent = `${flagsRemaining}/3`;
                if (commentInput) commentInput.value = '';

                isReportModalOpen = false;
                if (reportQuestionModal) reportQuestionModal.classList.add('hidden');
                const timeoutNotice = document.getElementById('report-timeout-notice');
                if (timeoutNotice) timeoutNotice.classList.add('hidden');
                if (btnSubmitReport) {
                    btnSubmitReport.innerHTML = origBtnText;
                    btnSubmitReport.disabled = false;
                }

                const wasTimedOut = questionTimedOutWhileReporting;
                questionTimedOutWhileReporting = false;

                if (!wasTimedOut) {
                    // Mark current question as answered/skipped on server
                    await fetch(`/api/attempt/${attemptId}/answer`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            question_id: currentQuestionId,
                            chosen: null
                        })
                    }).catch(() => {});
                }

                // Fetch next question now (starts timer for next question at this exact moment)
                await fetchNextQuestion();

            } catch (err) {
                allBtns.forEach(b => b.disabled = false);
                if (btnSubmitReport) {
                    btnSubmitReport.innerHTML = origBtnText;
                    btnSubmitReport.disabled = false;
                }
                showAlert("Network error submitting question report.");
            }
        });
    }



    // Return Home Button
    if (btnReturnHome) {
        btnReturnHome.addEventListener('click', () => {
            selectedTPId = null;
            attemptId = null;
            currentQuestionId = null;
            if (btnStartTest) {
                btnStartTest.disabled = false;
                const sp = btnStartTest.querySelector('span');
                if (sp) sp.textContent = window.studentI18n.t('btn.start_test');
            }
            document.querySelectorAll('.tp-card').forEach(c => c.classList.remove('selected'));
            showScreen('login');
            loadSavedStudentCode();
        });
    }

    // Revision Hub Toggle Buttons
    const btnViewRevisionHub = document.getElementById('btn-view-revision-hub');
    const btnClosedBackToLogin = document.getElementById('btn-closed-back-to-login');

    if (btnViewRevisionHub) {
        btnViewRevisionHub.addEventListener('click', () => {
            isManualRevisionViewing = true;
            showScreen('closed');
            checkScheduleStatus();
        });
    }

    if (btnClosedBackToLogin) {
        btnClosedBackToLogin.addEventListener('click', () => {
            if (scheduleStatusData && !scheduleStatusData.is_open) {
                // Strictly blocked if closed!
                return;
            }
            isManualRevisionViewing = false;
            showScreen('login');
        });
    }

    // Init App
    if (window.studentI18n) window.studentI18n.updateDOM();
    loadTPs();
    loadSavedStudentCode();
    
    // Initial schedule check will transition screen-gate-loading to closed or login directly
    checkScheduleStatus();
    setInterval(checkScheduleStatus, 30000);
});


