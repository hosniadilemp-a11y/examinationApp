"""
Server-Side Course Evaluation Scheduler
Data Mining TP Continuous Evaluation Engine

Operating Schedule:
- Supports 7-Day Per-Day Customization (Sunday to Saturday)
- Each day can be individually toggled: OPEN or CLOSED
- Each day has INDEPENDENT Morning and Afternoon/Evening Windows:
  - Morning Window (Matin) can be OPEN or LOCKED independently
  - Afternoon/Evening Window (Après-midi / Soir) can be OPEN or LOCKED independently
- Group-Specific Access Control:
  - CS, RSD, IASD, SIAD can be toggled globally via active_groups
  - Each slot can optionally specify allowed_groups
- Default Hours for Active Days (Sun-Thu): 08:00 - 12:50 & 13:00 - 16:50
- Weekend Days (Fri-Sat): Closed by default, can be opened and customized by teacher

Timezone: Africa/Algiers (UTC+1)
"""

import os
import json
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

# Configurable Timezone (defaults to Africa/Algiers, UTC+1)
TIMEZONE_NAME = os.getenv("APP_TIMEZONE", "Africa/Algiers")
TZ = ZoneInfo(TIMEZONE_NAME)

APP_DIR = os.path.dirname(os.path.abspath(__file__))
STUDENT_APP_DIR = os.path.dirname(APP_DIR)
PROJECT_ROOT = os.path.dirname(STUDENT_APP_DIR)
SCHEDULE_CONFIG_FILE = os.path.join(PROJECT_ROOT, "data", "schedule_config.json")

ALL_GROUPS = ["CS", "RSD", "IASD", "SIAD"]

WEEKDAY_NAMES_EN = {
    0: "Monday",
    1: "Tuesday",
    2: "Wednesday",
    3: "Thursday",
    4: "Friday",
    5: "Saturday",
    6: "Sunday",
}

WEEKDAY_NAMES_FR = {
    0: "Lundi",
    1: "Mardi",
    2: "Mercredi",
    3: "Jeudi",
    4: "Vendredi",
    5: "Samedi",
    6: "Dimanche",
}

MONTH_NAMES_FR = {
    1: "janvier",
    2: "février",
    3: "mars",
    4: "avril",
    5: "mai",
    6: "juin",
    7: "juillet",
    8: "août",
    9: "septembre",
    10: "octobre",
    11: "novembre",
    12: "décembre",
}


def _format_next_opening_text(target_dt: datetime, from_dt: datetime) -> str:
    """Formats human-friendly opening in English: 'Today at HH:MM', 'Tomorrow at HH:MM', or 'Weekday DD Month at HH:MM'."""
    diff_days = (target_dt.date() - from_dt.date()).days
    time_str = target_dt.strftime("%H:%M")
    if diff_days == 0:
        return f"Today at {time_str}"
    elif diff_days == 1:
        return f"Tomorrow at {time_str}"
    else:
        return target_dt.strftime("%A %d %B at %H:%M")


def _format_next_opening_text_fr(target_dt: datetime, from_dt: datetime) -> str:
    """Formats human-friendly opening in French: 'Aujourd'hui à HH:MM', 'Demain à HH:MM', ou 'Jour DD Mois à HH:MM'."""
    diff_days = (target_dt.date() - from_dt.date()).days
    time_str = target_dt.strftime("%H:%M")
    if diff_days == 0:
        return f"Aujourd'hui à {time_str}"
    elif diff_days == 1:
        return f"Demain à {time_str}"
    else:
        day_fr = WEEKDAY_NAMES_FR.get(target_dt.weekday(), target_dt.strftime("%A"))
        month_fr = MONTH_NAMES_FR.get(target_dt.month, target_dt.strftime("%B"))
        return f"{day_fr} {target_dt.day} {month_fr} à {time_str}"

# Default 7-day configuration (Sun-Thu open 08:00-12:50 & 13:00-16:50, Fri-Sat closed)
DEFAULT_DAILY_SCHEDULE = {
    "6": {
        "name_en": "Sunday",
        "name_fr": "Dimanche",
        "is_open": True,
        "morning": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
        "afternoon": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
    },
    "0": {
        "name_en": "Monday",
        "name_fr": "Lundi",
        "is_open": True,
        "morning": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
        "afternoon": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
    },
    "1": {
        "name_en": "Tuesday",
        "name_fr": "Mardi",
        "is_open": True,
        "morning": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
        "afternoon": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
    },
    "2": {
        "name_en": "Wednesday",
        "name_fr": "Mercredi",
        "is_open": True,
        "morning": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
        "afternoon": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
    },
    "3": {
        "name_en": "Thursday",
        "name_fr": "Jeudi",
        "is_open": True,
        "morning": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
        "afternoon": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
    },
    "4": {
        "name_en": "Friday",
        "name_fr": "Vendredi",
        "is_open": False,
        "morning": {"is_open": False, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
        "afternoon": {"is_open": False, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
    },
    "5": {
        "name_en": "Saturday",
        "name_fr": "Samedi",
        "is_open": False,
        "morning": {"is_open": False, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
        "afternoon": {"is_open": False, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
    },
}

DEFAULT_SCHEDULE_CONFIG = {
    "app_active": True,
    "force_open": False,
    "timezone": TIMEZONE_NAME,
    "active_groups": ["CS", "RSD", "IASD", "SIAD"],
    "lock_morning_all": False,
    "lock_afternoon_all": False,
    "daily_schedule": DEFAULT_DAILY_SCHEDULE,
    "active_weekdays": [6, 0, 1, 2, 3],
    "morning_slot": {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]},
    "afternoon_slot": {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ["CS", "RSD", "IASD", "SIAD"]}
}


def extract_group_from_code(code: str) -> str:
    """
    Extracts the student's group/speciality from their code.
    Examples:
        'IASD01' -> 'IASD'
        'siad15' -> 'SIAD'
        'RSD-02' -> 'RSD'
        'CS05'   -> 'CS'
    Returns empty string if no valid group matches.
    """
    if not code:
        return ""
    clean = str(code).strip().upper().replace("-", "").replace("_", "")
    for g in ["IASD", "SIAD", "RSD", "CS"]:
        if clean.startswith(g):
            return g
    return ""


def parse_time_str(val: str, default: time) -> time:
    """Parses 'HH:MM' string into a datetime.time object."""
    try:
        parts = str(val).strip().split(":")
        return time(int(parts[0]), int(parts[1]), 0)
    except Exception:
        return default


def _get_db_session():
    """Helper to safely obtain a database session without circular imports."""
    try:
        from student_app.app.database import SessionLocal
        return SessionLocal()
    except Exception:
        return None


def sanitize_schedule_config(config: dict) -> dict:
    """
    Validates and cleans up schedule config:
    - Guarantees active_groups is present and valid
    - Guarantees morning and afternoon slots have is_open, start, end, allowed_groups
    - Resolves invalid morning/afternoon overlaps (e.g. morning set to 20:50)
    """
    # 1. Active groups
    if "active_groups" not in config or not isinstance(config["active_groups"], list):
        config["active_groups"] = list(ALL_GROUPS)
    else:
        config["active_groups"] = [g for g in ALL_GROUPS if g in config["active_groups"]]

    # 2. Master slot locks
    config.setdefault("lock_morning_all", False)
    config.setdefault("lock_afternoon_all", False)

    # 3. Daily schedule structure
    daily = config.get("daily_schedule") or {}
    for k in ["6", "0", "1", "2", "3", "4", "5"]:
        if k not in daily:
            daily[k] = json.loads(json.dumps(DEFAULT_DAILY_SCHEDULE[k]))
            continue

        day_info = daily[k]
        day_is_open = day_info.get("is_open", False)

        m = day_info.get("morning") or {}
        a = day_info.get("afternoon") or {}

        # Default is_open for slots to day's is_open if not explicitly specified
        if "is_open" not in m:
            m["is_open"] = day_is_open
        if "is_open" not in a:
            a["is_open"] = day_is_open

        m.setdefault("start", "08:00")
        m.setdefault("end", "12:50")
        if "allowed_groups" not in m or not isinstance(m["allowed_groups"], list):
            m["allowed_groups"] = list(ALL_GROUPS)
        else:
            m["allowed_groups"] = [g for g in ALL_GROUPS if g in m["allowed_groups"]]

        a.setdefault("start", "13:00")
        a.setdefault("end", "16:50")
        if "allowed_groups" not in a or not isinstance(a["allowed_groups"], list):
            a["allowed_groups"] = list(ALL_GROUPS)
        else:
            a["allowed_groups"] = [g for g in ALL_GROUPS if g in a["allowed_groups"]]

        # Fix any corrupted overlap where morning end was dragged past afternoon start
        m_start = parse_time_str(m["start"], time(8, 0))
        m_end = parse_time_str(m["end"], time(12, 50))
        a_start = parse_time_str(a["start"], time(13, 0))
        a_end = parse_time_str(a["end"], time(16, 50))

        if m_end > a_start:
            # If morning was extended into evening (e.g. 20:50 or 20:01), shift that evening end to afternoon
            if m_end > a_end:
                a["end"] = m["end"]
            # Morning cannot end after afternoon starts: clamp morning end to afternoon start
            m["end"] = a["start"]

        day_info["morning"] = m
        day_info["afternoon"] = a
        daily[k] = day_info

    config["daily_schedule"] = daily
    return config


def get_schedule_config() -> dict:
    """
    Reads persistent schedule and activation config.
    Prioritizes the shared database (Supabase / PostgreSQL) so changes sync to Render,
    falling back to local JSON file and defaults.
    """
    config = json.loads(json.dumps(DEFAULT_SCHEDULE_CONFIG))

    # 1. Try reading from shared Database (Supabase Postgres)
    db = _get_db_session()
    if db:
        try:
            from student_app.app.models import SystemSetting
            setting = db.query(SystemSetting).filter(SystemSetting.key == "schedule_config").first()
            if setting and setting.value:
                saved = json.loads(setting.value)
                config.update(saved)
                if "daily_schedule" in saved:
                    merged_days = json.loads(json.dumps(DEFAULT_DAILY_SCHEDULE))
                    merged_days.update(saved["daily_schedule"])
                    config["daily_schedule"] = merged_days
                config = sanitize_schedule_config(config)
                return config
        except Exception:
            pass
        finally:
            db.close()

    # 2. Fallback to local JSON file
    if os.path.exists(SCHEDULE_CONFIG_FILE):
        try:
            with open(SCHEDULE_CONFIG_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
                config.update(saved)
                if "daily_schedule" in saved:
                    merged_days = json.loads(json.dumps(DEFAULT_DAILY_SCHEDULE))
                    merged_days.update(saved["daily_schedule"])
                    config["daily_schedule"] = merged_days
        except Exception as e:
            print(f"Notice: Failed to read {SCHEDULE_CONFIG_FILE}: {e}")

    config = sanitize_schedule_config(config)
    return config


def save_schedule_config(new_config: dict) -> dict:
    """
    Saves updated schedule configuration to BOTH the shared Database (Supabase Postgres)
    and the local JSON file.
    This guarantees that Render instances immediately pick up activation/deactivation!
    """
    current = get_schedule_config()

    # Handle daily_schedule deep update if present
    if "daily_schedule" in new_config:
        merged_schedule = json.loads(json.dumps(current.get("daily_schedule", DEFAULT_DAILY_SCHEDULE)))
        for k, v in new_config["daily_schedule"].items():
            k_str = str(k)
            if k_str in merged_schedule:
                if isinstance(v, dict):
                    merged_schedule[k_str].update(v)
                else:
                    merged_schedule[k_str] = v
            else:
                merged_schedule[k_str] = v
        current["daily_schedule"] = merged_schedule

        # Derive active_weekdays list from daily_schedule
        active_days = []
        for d_str in ["6", "0", "1", "2", "3", "4", "5"]:
            d_info = current["daily_schedule"].get(d_str, {})
            if d_info.get("is_open", False):
                try:
                    active_days.append(int(d_str))
                except ValueError:
                    pass
        current["active_weekdays"] = active_days

    for k, v in new_config.items():
        if k != "daily_schedule":
            current[k] = v

    current = sanitize_schedule_config(current)
    current["updated_at"] = datetime.now(TZ).isoformat()

    # 1. Persist to shared database (Supabase / Postgres)
    db = _get_db_session()
    if db:
        try:
            from student_app.app.models import SystemSetting
            from student_app.app.database import Base, engine
            Base.metadata.create_all(bind=engine, tables=[SystemSetting.__table__])

            setting = db.query(SystemSetting).filter(SystemSetting.key == "schedule_config").first()
            if not setting:
                setting = SystemSetting(key="schedule_config", value=json.dumps(current))
                db.add(setting)
            else:
                setting.value = json.dumps(current)
                setting.updated_at = datetime.now(timezone.utc)
            db.commit()
        except Exception as e:
            print(f"Warning: Failed to save schedule_config to DB: {e}")
            if db:
                db.rollback()
        finally:
            db.close()

    # 2. Persist to local JSON file
    try:
        os.makedirs(os.path.dirname(SCHEDULE_CONFIG_FILE), exist_ok=True)
        with open(SCHEDULE_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(current, f, indent=2)
    except Exception as e:
        print(f"Warning: Failed to write {SCHEDULE_CONFIG_FILE}: {e}")

    return current


def set_app_active(active: bool) -> dict:
    """Sets whether the TP tests are activated/launched or stopped/deactivated."""
    return save_schedule_config({"app_active": bool(active)})


def toggle_app_active() -> dict:
    """Toggles app_active between True and False."""
    cfg = get_schedule_config()
    return set_app_active(not cfg.get("app_active", True))


def set_active_groups(groups: list[str]) -> dict:
    """Sets which groups (CS, RSD, IASD, SIAD) are authorized globally."""
    valid_groups = [g for g in ALL_GROUPS if g in groups]
    return save_schedule_config({"active_groups": valid_groups})


def set_master_slot_lock(slot_name: str, locked: bool) -> dict:
    """
    Sets quick master lock for all morning or all afternoon slots.
    slot_name: 'morning' or 'afternoon'
    """
    if slot_name == "morning":
        return save_schedule_config({"lock_morning_all": bool(locked)})
    elif slot_name in ("afternoon", "evening"):
        return save_schedule_config({"lock_afternoon_all": bool(locked)})
    return get_schedule_config()


def get_current_local_time() -> datetime:
    """Returns the current datetime in the configured course timezone."""
    return datetime.now(TZ)


def is_within_scheduled_hours(
    dt: datetime = None,
    student_code: str = None,
    group: str = None
) -> tuple[bool, str, dict]:
    """
    Checks whether a given datetime (or now) falls within the official scheduled hours,
    taking teacher activation status, 7-day timetable, separate morning/evening slot locks,
    and group-specific access control into account.

    Parameters:
        dt: Optional specific datetime to evaluate (defaults to now in Africa/Algiers)
        student_code: Optional student code (e.g. 'IASD01', 'CS10') to check group permissions
        group: Optional explicit group ('CS', 'RSD', 'IASD', 'SIAD')

    Returns:
        (is_open: bool, status_code: str, metadata: dict)
    """
    cfg = get_schedule_config()
    now_dt = dt.astimezone(TZ) if dt else get_current_local_time()
    weekday = now_dt.weekday()
    current_time = now_dt.time()

    # Determine student group
    student_group = (group or extract_group_from_code(student_code) or "").upper()

    active_groups = cfg.get("active_groups", ALL_GROUPS)
    lock_morning_all = cfg.get("lock_morning_all", False)
    lock_afternoon_all = cfg.get("lock_afternoon_all", False)

    meta = {
        "current_time": now_dt.strftime("%Y-%m-%d %H:%M:%S %Z"),
        "weekday": weekday,
        "day_name_en": WEEKDAY_NAMES_EN.get(weekday, ""),
        "day_name_fr": WEEKDAY_NAMES_FR.get(weekday, ""),
        "app_active": cfg.get("app_active", True),
        "force_open": cfg.get("force_open", False),
        "active_groups": active_groups,
        "student_group": student_group,
        "lock_morning_all": lock_morning_all,
        "lock_afternoon_all": lock_afternoon_all,
    }

    # 1. Environment Overrides (Testing / Admin)
    if os.getenv("ALLOW_OFF_HOURS", "").lower() in ("true", "1", "yes") or (
        dt is None and "PYTEST_CURRENT_TEST" in os.environ and os.getenv("STRICT_SCHEDULE_TEST") != "true"
    ):
        return True, "ADMIN_OVERRIDE", {
            **meta,
            "is_open": True,
            "reason": "Administrative / test override active",
            "active_slot": "all_day_override",
        }

    # 2. Teacher Manual Master Switch: Deactivated / Stopped
    if not cfg.get("app_active", True):
        return False, "DEACTIVATED_BY_TEACHER", {
            **meta,
            "is_open": False,
            "reason": "Platform deactivated / stopped by teacher",
        }

    # 3. Master Group Check: Is the student's group active globally?
    if student_group and student_group in ALL_GROUPS and student_group not in active_groups:
        return False, "GROUP_LOCKED_BY_TEACHER", {
            **meta,
            "is_open": False,
            "reason": f"Speciality '{student_group}' is currently locked by the instructor.",
            "allowed_groups": active_groups,
        }

    # 4. Teacher Manual Force Open Override
    if cfg.get("force_open", False):
        return True, "FORCE_OPEN_OVERRIDE", {
            **meta,
            "is_open": True,
            "reason": "Teacher manual emergency override active (FORCE_OPEN=true)",
            "active_slot": "teacher_override",
        }

    if os.getenv("FORCE_CLOSED", "").lower() in ("true", "1", "yes"):
        return False, "CLOSED_FORCED_PREVIEW", {
            **meta,
            "is_open": False,
            "reason": "Administrative preview mode active (FORCE_CLOSED=true)",
            "next_opening": "Sunday at 08:00 (Simulated Preview)",
        }

    # 5. Check 7-Day Per-Day Schedule
    daily_schedule = cfg.get("daily_schedule", DEFAULT_DAILY_SCHEDULE)
    day_key = str(weekday)
    day_cfg = daily_schedule.get(day_key) or daily_schedule.get(weekday)

    if not day_cfg:
        active_weekdays = set(cfg.get("active_weekdays", [6, 0, 1, 2, 3]))
        is_day_open = weekday in active_weekdays
        m_slot = cfg.get("morning_slot", {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ALL_GROUPS})
        a_slot = cfg.get("afternoon_slot", {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ALL_GROUPS})
    else:
        is_day_open = day_cfg.get("is_open", False)
        m_slot = day_cfg.get("morning", {"is_open": True, "start": "08:00", "end": "12:50", "allowed_groups": ALL_GROUPS})
        a_slot = day_cfg.get("afternoon", {"is_open": True, "start": "13:00", "end": "16:50", "allowed_groups": ALL_GROUPS})

    if not is_day_open:
        next_open = _compute_next_opening(now_dt, cfg, student_group)
        meta["next_opening"] = next_open.strftime("%A %d %B at %H:%M")
        meta["next_opening_iso"] = next_open.isoformat()
        code = "CLOSED_WEEKEND" if weekday in (4, 5) else "CLOSED_DAY"
        return False, code, meta

    # Slot parameters
    slot1_start = parse_time_str(m_slot.get("start", "08:00"), time(8, 0, 0))
    slot1_end = parse_time_str(m_slot.get("end", "12:50"), time(12, 50, 0))
    slot2_start = parse_time_str(a_slot.get("start", "13:00"), time(13, 0, 0))
    slot2_end = parse_time_str(a_slot.get("end", "16:50"), time(16, 50, 0))

    # Guarantee morning slot does not bleed into or overlap afternoon slot
    if slot1_end > slot2_start:
        slot1_end = slot2_start

    has_morning = slot1_start < slot1_end
    has_afternoon = slot2_start < slot2_end

    # Individual slot openness (considering slot's is_open and master quick lock)
    morning_is_open = m_slot.get("is_open", True) and not lock_morning_all
    afternoon_is_open = a_slot.get("is_open", True) and not lock_afternoon_all

    morning_allowed_groups = m_slot.get("allowed_groups", ALL_GROUPS)
    afternoon_allowed_groups = a_slot.get("allowed_groups", ALL_GROUPS)

    # Effective authorized groups per slot (intersection of globally active and slot-level allowed)
    effective_morning_groups = [g for g in ALL_GROUPS if g in active_groups and g in morning_allowed_groups]
    effective_afternoon_groups = [g for g in ALL_GROUPS if g in active_groups and g in afternoon_allowed_groups]

    meta["morning_is_open"] = morning_is_open
    meta["afternoon_is_open"] = afternoon_is_open
    meta["morning_allowed_groups"] = morning_allowed_groups
    meta["afternoon_allowed_groups"] = afternoon_allowed_groups
    meta["effective_morning_groups"] = effective_morning_groups
    meta["effective_afternoon_groups"] = effective_afternoon_groups

    # 6. Check Morning Slot Window
    if has_morning and slot1_start <= current_time < slot1_end:
        meta["active_slot"] = "morning"
        meta["session_active_groups"] = effective_morning_groups
        meta["closes_at"] = now_dt.replace(
            hour=slot1_end.hour, minute=slot1_end.minute, second=0, microsecond=0
        ).strftime("%H:%M")

        # Check if morning is locked
        if not morning_is_open:
            next_open = _compute_next_opening(now_dt, cfg, student_group)
            meta["next_opening"] = _format_next_opening_text(next_open, now_dt)
            meta["next_opening_fr"] = _format_next_opening_text_fr(next_open, now_dt)
            meta["next_opening_iso"] = next_open.isoformat()
            return False, "CLOSED_MORNING_LOCKED", meta

        # Check group authorization for morning slot
        if student_group and student_group in ALL_GROUPS and student_group not in effective_morning_groups:
            return False, "GROUP_NOT_ALLOWED_IN_SLOT", {
                **meta,
                "is_open": False,
                "reason": f"Group '{student_group}' is not scheduled for the morning session.",
                "allowed_groups": effective_morning_groups,
            }

        return True, "OPEN_SLOT_1", meta

    # 7. Check Lunch / Midday Break
    if has_morning and has_afternoon and slot1_end < slot2_start and slot1_end <= current_time < slot2_start:
        meta["session_active_groups"] = effective_afternoon_groups
        next_open = now_dt.replace(
            hour=slot2_start.hour, minute=slot2_start.minute, second=0, microsecond=0
        )
        meta["next_opening"] = _format_next_opening_text(next_open, now_dt)
        meta["next_opening_fr"] = _format_next_opening_text_fr(next_open, now_dt)
        meta["next_opening_iso"] = next_open.isoformat()
        return False, "CLOSED_BREAK", meta

    # 8. Check Afternoon / Evening Slot Window
    if has_afternoon and slot2_start <= current_time < slot2_end:
        meta["active_slot"] = "afternoon"
        meta["session_active_groups"] = effective_afternoon_groups
        meta["closes_at"] = now_dt.replace(
            hour=slot2_end.hour, minute=slot2_end.minute, second=0, microsecond=0
        ).strftime("%H:%M")

        # Check if afternoon is locked
        if not afternoon_is_open:
            next_open = _compute_next_opening(now_dt, cfg, student_group)
            meta["next_opening"] = _format_next_opening_text(next_open, now_dt)
            meta["next_opening_fr"] = _format_next_opening_text_fr(next_open, now_dt)
            meta["next_opening_iso"] = next_open.isoformat()
            return False, "CLOSED_AFTERNOON_LOCKED", meta

        # Check group authorization for afternoon slot
        if student_group and student_group in ALL_GROUPS and student_group not in effective_afternoon_groups:
            return False, "GROUP_NOT_ALLOWED_IN_SLOT", {
                **meta,
                "is_open": False,
                "reason": f"Group '{student_group}' is not scheduled for the afternoon/evening session.",
                "allowed_groups": effective_afternoon_groups,
            }

        return True, "OPEN_SLOT_2", meta

    # 9. Outside Operating Hours on an Open Day
    next_open = _compute_next_opening(now_dt, cfg, student_group)
    meta["next_opening"] = _format_next_opening_text(next_open, now_dt)
    meta["next_opening_fr"] = _format_next_opening_text_fr(next_open, now_dt)
    meta["next_opening_iso"] = next_open.isoformat()

    earliest_open = slot1_start if has_morning else (slot2_start if has_afternoon else None)
    if earliest_open and current_time < earliest_open:
        meta["session_active_groups"] = effective_morning_groups if has_morning else effective_afternoon_groups
        return False, "CLOSED_BEFORE_HOURS", meta
    else:
        meta["session_active_groups"] = active_groups
        return False, "CLOSED_AFTER_HOURS", meta


def _compute_next_opening(from_dt: datetime, cfg: dict = None, student_group: str = None) -> datetime:
    """
    Computes the exact datetime when the next open window starts across all 7 days,
    skipping slots locked by the teacher or unassigned to student_group.
    """
    if not cfg:
        cfg = get_schedule_config()

    daily_schedule = cfg.get("daily_schedule", DEFAULT_DAILY_SCHEDULE)
    lock_morning_all = cfg.get("lock_morning_all", False)
    lock_afternoon_all = cfg.get("lock_afternoon_all", False)
    current = from_dt

    for day_offset in range(8):
        candidate_day = current + timedelta(days=day_offset)
        w = candidate_day.weekday()
        day_key = str(w)
        day_cfg = daily_schedule.get(day_key) or daily_schedule.get(w)

        if day_cfg and day_cfg.get("is_open", False):
            m_slot = day_cfg.get("morning", {})
            a_slot = day_cfg.get("afternoon", {})

            m_is_open = m_slot.get("is_open", True) and not lock_morning_all
            a_is_open = a_slot.get("is_open", True) and not lock_afternoon_all

            # Filter by group if specified
            if student_group and student_group in ALL_GROUPS:
                if student_group not in m_slot.get("allowed_groups", ALL_GROUPS):
                    m_is_open = False
                if student_group not in a_slot.get("allowed_groups", ALL_GROUPS):
                    a_is_open = False

            slot1_start = parse_time_str(m_slot.get("start", "08:00"), time(8, 0, 0))
            slot1_end = parse_time_str(m_slot.get("end", "12:50"), time(12, 50, 0))
            slot2_start = parse_time_str(a_slot.get("start", "13:00"), time(13, 0, 0))
            slot2_end = parse_time_str(a_slot.get("end", "16:50"), time(16, 50, 0))

            if slot1_end > slot2_start:
                slot1_end = slot2_start

            # Morning candidate
            if m_is_open and slot1_start < slot1_end:
                if day_offset == 0:
                    if current.time() < slot1_end:
                        return candidate_day.replace(
                            hour=slot1_start.hour, minute=slot1_start.minute, second=0, microsecond=0
                        )
                else:
                    return candidate_day.replace(
                        hour=slot1_start.hour, minute=slot1_start.minute, second=0, microsecond=0
                    )

            # Afternoon candidate
            if a_is_open and slot2_start < slot2_end:
                if day_offset == 0:
                    if current.time() < slot2_end:
                        return candidate_day.replace(
                            hour=slot2_start.hour, minute=slot2_start.minute, second=0, microsecond=0
                        )
                else:
                    return candidate_day.replace(
                        hour=slot2_start.hour, minute=slot2_start.minute, second=0, microsecond=0
                    )

    # Fallback to tomorrow at 08:00
    return (current + timedelta(days=1)).replace(hour=8, minute=0, second=0, microsecond=0)


def get_schedule_status_payload(
    dt: datetime = None,
    student_code: str = None,
    group: str = None
) -> dict:
    """Returns comprehensive schedule status payload for API consumers & frontend."""
    cfg = get_schedule_config()
    is_open, code, meta = is_within_scheduled_hours(dt, student_code, group)

    daily_schedule = cfg.get("daily_schedule", DEFAULT_DAILY_SCHEDULE)
    now_dt = dt.astimezone(TZ) if dt else get_current_local_time()
    today_cfg = daily_schedule.get(str(now_dt.weekday()), {})

    m_slot = today_cfg.get("morning", cfg.get("morning_slot", {"start": "08:00", "end": "12:50"}))
    a_slot = today_cfg.get("afternoon", cfg.get("afternoon_slot", {"start": "13:00", "end": "16:50"}))

    m_range = f"{m_slot.get('start', '08:00')} - {m_slot.get('end', '12:50')}"
    l_range = f"{m_slot.get('end', '12:50')} - {a_slot.get('start', '13:00')}"
    a_range = f"{a_slot.get('start', '13:00')} - {a_slot.get('end', '16:50')}"

    st_grp = meta.get("student_group") or "demandé"
    session_grps = meta.get("session_active_groups")
    if session_grps is None:
        session_grps = cfg.get("active_groups", ALL_GROUPS)
    active_grps_str = ", ".join(session_grps)

    messages_en = {
        "OPEN_SLOT_1": f"Platform is currently OPEN (Morning Window until {meta.get('closes_at', '12:50')}).",
        "OPEN_SLOT_2": f"Platform is currently OPEN (Afternoon/Evening Window until {meta.get('closes_at', '16:50')}).",
        "ADMIN_OVERRIDE": "Platform is OPEN (Administrative / Test override active).",
        "FORCE_OPEN_OVERRIDE": "Platform is OPEN (Teacher Manual Override Active).",
        "DEACTIVATED_BY_TEACHER": "Evaluation tests are currently suspended by the instructor.",
        "GROUP_LOCKED_BY_TEACHER": f"Evaluations for speciality '{st_grp}' are currently locked by the instructor. Active groups: {active_grps_str}.",
        "GROUP_NOT_ALLOWED_IN_SLOT": f"Speciality '{st_grp}' is not scheduled for this session window. Active groups: {active_grps_str}.",
        "CLOSED_MORNING_LOCKED": "The morning evaluation session is currently locked by the instructor.",
        "CLOSED_AFTERNOON_LOCKED": "The afternoon/evening evaluation session is currently locked by the instructor.",
        "CLOSED_WEEKEND": "Platform is CLOSED for the weekend.",
        "CLOSED_DAY": "Platform is CLOSED today.",
        "CLOSED_BREAK": "The evaluation platform is currently closed.",
        "CLOSED_BEFORE_HOURS": "The evaluation platform is currently closed.",
        "CLOSED_AFTER_HOURS": "The evaluation platform is currently closed for today.",
        "CLOSED_FORCED_PREVIEW": "Platform is in Administrative Preview mode (Forced Closed).",
    }

    next_fr = meta.get("next_opening_fr") or meta.get("next_opening", "")
    messages_fr = {
        "OPEN_SLOT_1": f"La plateforme est OUVERTE (Session du matin jusqu'à {meta.get('closes_at', '12:50')}).",
        "OPEN_SLOT_2": f"La plateforme est OUVERTE (Session de l'après-midi / soir jusqu'à {meta.get('closes_at', '16:50')}).",
        "ADMIN_OVERRIDE": "La plateforme est OUVERTE (Mode test administrateur activé).",
        "FORCE_OPEN_OVERRIDE": "La plateforme est OUVERTE (Dérogation manuelle de l'enseignant activée).",
        "DEACTIVATED_BY_TEACHER": "Les tests sont actuellement suspendus par l'enseignant.",
        "GROUP_LOCKED_BY_TEACHER": f"Les évaluations pour la spécialité '{st_grp}' sont actuellement verrouillées par l'enseignant. Groupes autorisés : {active_grps_str}.",
        "GROUP_NOT_ALLOWED_IN_SLOT": f"La spécialité '{st_grp}' n'est pas programmée pour cette plage horaire. Spécialités autorisées : {active_grps_str}.",
        "CLOSED_MORNING_LOCKED": "La session du matin est actuellement verrouillée par l'enseignant.",
        "CLOSED_AFTERNOON_LOCKED": "La session de l'après-midi / soir est actuellement verrouillée par l'enseignant.",
        "CLOSED_WEEKEND": "La plateforme est FERMÉE le weekend.",
        "CLOSED_DAY": "La plateforme est FERMÉE aujourd'hui.",
        "CLOSED_BREAK": "La plateforme d'évaluation est actuellement fermée.",
        "CLOSED_BEFORE_HOURS": "La plateforme d'évaluation est actuellement fermée.",
        "CLOSED_AFTER_HOURS": "La plateforme d'évaluation est actuellement fermée pour aujourd'hui.",
        "CLOSED_FORCED_PREVIEW": "Mode aperçu administrateur activé (Fermeture forcée).",
    }

    return {
        "is_open": is_open,
        "status_code": code,
        "message_en": messages_en.get(code, "Platform status checked."),
        "message_fr": messages_fr.get(code, "Statut de la plateforme vérifié."),
        "metadata": meta,
        "active_groups": session_grps,
        "master_active_groups": cfg.get("active_groups", ALL_GROUPS),
        "all_groups": ALL_GROUPS,
        "teacher_control": {
            "app_active": cfg.get("app_active", True),
            "force_open": cfg.get("force_open", False),
            "active_groups": cfg.get("active_groups", ALL_GROUPS),
            "lock_morning_all": cfg.get("lock_morning_all", False),
            "lock_afternoon_all": cfg.get("lock_afternoon_all", False),
        },
        "schedule": {
            "timezone": cfg.get("timezone", TIMEZONE_NAME),
            "morning_slot": m_range,
            "lunch_break": l_range,
            "afternoon_slot": a_range,
            "active_weekdays": cfg.get("active_weekdays", [6, 0, 1, 2, 3]),
            "daily_schedule": daily_schedule,
        },
    }
