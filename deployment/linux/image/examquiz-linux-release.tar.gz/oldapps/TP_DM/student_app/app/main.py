import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from student_app.app.database import engine, Base
from student_app.app.api.attempts import router as attempts_router

# Initialize tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Data Mining TP Continuous Evaluation Engine",
    description="Timed True/False Continuous Evaluation Platform for Data Mining TPs",
    version="1.0.0"
)

from collections import defaultdict
import time
from fastapi.responses import JSONResponse, FileResponse, RedirectResponse, HTMLResponse

# Simple sliding window rate limiter to prevent bot brute-forcing
IP_REQUEST_TIMES = defaultdict(list)

# HTTP Security Headers Middleware (OWASP ZAP & Observatory Compliance)
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    # Anti-Bot Rate Limiter for Attempt Starts (Bypassed during automated test suite runs)
    if request.url.path.startswith("/api/attempt/start") and "PYTEST_CURRENT_TEST" not in os.environ:
        client_ip = request.headers.get("x-forwarded-for")
        if client_ip:
            client_ip = client_ip.split(",")[0].strip()
        else:
            client_ip = request.client.host if request.client else "127.0.0.1"

        now = time.time()
        IP_REQUEST_TIMES[client_ip] = [t for t in IP_REQUEST_TIMES[client_ip] if now - t < 60]
        if len(IP_REQUEST_TIMES[client_ip]) >= 10:
            return JSONResponse(
                status_code=429,
                content={"detail": "Too many automated test requests detected. Please wait 1 minute before retrying."}
            )
        IP_REQUEST_TIMES[client_ip].append(now)

    response = await call_next(request)
    
    # Strictly defined CSP without wildcard directives or missing fallbacks
    if request.url.path.startswith("/static/simulators") or request.url.path.startswith("/simulators"):
        response.headers["Content-Security-Policy"] = (
            "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: https:; "
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "font-src 'self' data: https://fonts.gstatic.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "img-src 'self' data: blob: https:; "
            "connect-src 'self' https:;"
        )
    else:
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "img-src 'self' data: https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "connect-src 'self'; "
            "media-src 'none'; "
            "object-src 'none'; "
            "child-src 'none'; "
            "worker-src 'none'; "
            "manifest-src 'self'; "
            "base-uri 'self'; "
            "form-action 'self'; "
            "frame-ancestors 'none'; "
            "upgrade-insecure-requests;"
        )
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Router
app.include_router(attempts_router)

# Mount Static directory
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(PROJECT_ROOT, "static")
SIMULATORS_DIR = os.path.join(STATIC_DIR, "simulators")
os.makedirs(STATIC_DIR, exist_ok=True)
os.makedirs(SIMULATORS_DIR, exist_ok=True)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.api_route("/simulators/decision-tree", methods=["GET", "HEAD"])
def get_dt_simulator():
    path = os.path.join(SIMULATORS_DIR, "dt_simulator.html")
    return FileResponse(path)

@app.api_route("/simulators/kdtree", methods=["GET", "HEAD"])
def get_kdtree_simulator():
    path = os.path.join(SIMULATORS_DIR, "kdtree_simulator.html")
    return FileResponse(path)

@app.api_route("/simulators/knn-regression", methods=["GET", "HEAD"])
def get_knn_reg_simulator():
    path = os.path.join(SIMULATORS_DIR, "knn_regression_simulator.html")
    return FileResponse(path)

@app.api_route("/simulators/bayes", methods=["GET", "HEAD"])
def get_bayes_simulator():
    path = os.path.join(SIMULATORS_DIR, "bayes_simulator.html")
    return FileResponse(path)

app.mount("/simulators", StaticFiles(directory=SIMULATORS_DIR), name="simulators")

# Fallback & Compatibility Redirects for Inter-Simulator Relative Links
@app.api_route("/2-knn/{filename}", methods=["GET", "HEAD"])
def redirect_2knn(filename: str):
    return RedirectResponse(url=f"/simulators/{filename}", status_code=302)

@app.api_route("/3.1-Arbres_de_decision/{filename}", methods=["GET", "HEAD"])
def redirect_31dt(filename: str):
    return RedirectResponse(url=f"/simulators/{filename}", status_code=302)

@app.api_route("/4-Data_mining_classification_Bayes_classifier/{filename}", methods=["GET", "HEAD"])
def redirect_4bayes(filename: str):
    return RedirectResponse(url=f"/simulators/{filename}", status_code=302)

@app.api_route("/apps/TP_tests/student_app/static/index.html", methods=["GET", "HEAD"])
@app.api_route("/apps/TP_tests/student_app/static/{rest:path}", methods=["GET", "HEAD"])
def redirect_to_portal_home(rest: str = ""):
    return RedirectResponse(url="/", status_code=302)

@app.api_route("/project-progress", methods=["GET", "HEAD"])
@app.api_route("/project-evaluation-progress", methods=["GET", "HEAD"])
def get_project_progress():
    progress_file = os.path.join(STATIC_DIR, "project_progress.html")
    if os.path.exists(progress_file):
        return FileResponse(progress_file)
    return HTMLResponse(
        "<div style='font-family: sans-serif; text-align: center; padding: 40px; background: #0B132B; color: #FFF; min-height: 100vh;'>"
        "<h2>📊 Rapport de Progression des Projets</h2>"
        "<p style='color: #94A3B8;'>Le rapport de progression des projets n'a pas encore été publié par l'enseignant.</p>"
        "<p style='margin-top: 20px;'><a href='/' style='color: #38BDF8; text-decoration: none;'>&larr; Retour au Portail des Évaluations de TP</a></p>"
        "</div>",
        status_code=404
    )

@app.get("/")
@app.head("/")
def read_root():
    index_file = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": "Data Mining Evaluation API Engine is Running. Static files not yet deployed."}

@app.get("/health")
@app.head("/health")
def health_check():
    return {"status": "ok", "app": "TP Continuous Evaluation Engine"}

@app.get("/favicon.ico")
@app.head("/favicon.ico")
def favicon():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"), status_code=204)


@app.get("/schedule-control")
def get_schedule_control():
    """
    Returns real-time operating schedule status, activation state, and weekly timetable configuration.
    """
    from student_app.app.scheduler import get_schedule_status_payload, get_schedule_config
    return {
        "status": get_schedule_status_payload(),
        "config": get_schedule_config(),
    }

@app.post("/schedule-control/toggle")
def toggle_app_activation(payload: dict = None):
    """
    Teacher master switch: toggles or explicitly sets test activation (app_active: True/False).
    """
    from student_app.app.scheduler import set_app_active, toggle_app_active, get_schedule_status_payload, get_schedule_config
    if payload and "active" in payload:
        cfg = set_app_active(bool(payload["active"]))
    else:
        cfg = toggle_app_active()
    return {
        "app_active": cfg.get("app_active", True),
        "status": get_schedule_status_payload(),
        "config": cfg,
    }

@app.post("/schedule-control/update")
def update_schedule_settings(payload: dict):
    """
    Updates weekly operating schedule (active days, morning/afternoon slot hours, force_open override, active_groups).
    """
    from student_app.app.scheduler import save_schedule_config, get_schedule_status_payload
    cfg = save_schedule_config(payload)
    return {
        "success": True,
        "config": cfg,
        "status": get_schedule_status_payload(),
    }

@app.post("/schedule-control/set-groups")
def set_schedule_groups(payload: dict):
    """
    Quick update of active groups (e.g. {"groups": ["CS", "RSD", "IASD", "SIAD"]}).
    """
    from student_app.app.scheduler import set_active_groups, get_schedule_status_payload
    groups = payload.get("groups", [])
    cfg = set_active_groups(groups)
    return {
        "success": True,
        "config": cfg,
        "status": get_schedule_status_payload(),
    }

@app.post("/schedule-control/lock-slot")
def lock_slot_quick(payload: dict):
    """
    Quick lock/unlock of all morning or all afternoon slots.
    Payload: {"slot": "morning"|"afternoon", "locked": True/False}
    """
    from student_app.app.scheduler import set_master_slot_lock, get_schedule_status_payload
    slot = payload.get("slot", "")
    locked = bool(payload.get("locked", False))
    cfg = set_master_slot_lock(slot, locked)
    return {
        "success": True,
        "config": cfg,
        "status": get_schedule_status_payload(),
    }

@app.get("/.well-known/appspecific/com.chrome.devtools.json")
def chrome_devtools_wellknown():
    return {}
