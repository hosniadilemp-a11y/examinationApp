from typing import List, Optional, Union
from pydantic import BaseModel, Field, ConfigDict

class TPInfo(BaseModel):
    id: int
    name: str

    model_config = ConfigDict(from_attributes=True)

class AttemptStartRequest(BaseModel):
    code: str = Field(..., description="Student code (e.g. IASD01, SIAD05, RSD02, CS10)")
    tp_id: int = Field(..., description="TP ID (1..6)")
    device_fingerprint: Optional[str] = None
    user_agent: Optional[str] = None

class AttemptStartResponse(BaseModel):
    attempt_id: int

class QuestionServeResponse(BaseModel):
    question_id: Union[int, str]
    text: str
    options: List[bool] = [True, False]
    position: int # 1..20
    total: int = 20

class AnswerSubmitRequest(BaseModel):
    question_id: Union[int, str]
    chosen: Optional[bool] = None
    telemetry: Optional[dict] = None

class AnswerSubmitResponse(BaseModel):
    received: bool = True

class FinishAttemptResponse(BaseModel):
    final_mark: float
    raw_score: float
    correct_count: int
    wrong_count: int
    skipped_count: int
    status: str

class ViolationEventRequest(BaseModel):
    event_type: str = Field(..., description="e.g. fullscreen_exit, tab_hidden, window_blur, mouse_left_viewport, copy_or_context_menu_attempt")
    details: Optional[str] = None

class ViolationEventResponse(BaseModel):
    violation_count: int
    auto_failed: bool = False
    message: str

class FlagQuestionRequest(BaseModel):
    question_id: int
    reason_category: str = Field("other", description="typo, ambiguous, invalid_key, syntax, other")
    student_comment: Optional[str] = Field(None, max_length=300)

class FlagQuestionResponse(BaseModel):
    flag_id: int
    question_id: int
    flags_used: int
    flags_remaining: int
    message: str
