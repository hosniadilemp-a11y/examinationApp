#!/usr/bin/env bash
# ==============================================================================
# ExamQuiz Platform — Point d'entrée Bash (.bash) pour le déploiement complet
# ==============================================================================
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$SCRIPT_DIR/deploy.sh" "$@"

