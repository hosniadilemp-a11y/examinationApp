#!/usr/bin/env bash
# ==============================================================================
# ExamQuiz Platform — Script Principal de Déploiement & Création Complète (.sh)
# Compatible Linux (Ubuntu/Debian/CentOS/Fedora) & Windows (Git Bash / WSL)
# ==============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

MODE="${1:---native}" # Options : --native (défaut) | --docker | --seed-only | --build-images

echo "=============================================================================="
echo "   🚀 DÉPLOIEMENT AUTOMATISÉ — PLATEFORME D'EXAMEN & FORMATION EXAMQUIZ"
echo "=============================================================================="

# Détection Python
if command -v python3 &>/dev/null; then
    PY_CMD="python3"
elif command -v python &>/dev/null; then
    PY_CMD="python"
else
    echo "[ERREUR] Python 3.10+ est requis mais introuvable dans le PATH."
    exit 1
fi

echo "[1/5] Vérification de l'environnement Python ($($PY_CMD --version))..."

if [ "$MODE" = "--docker" ]; then
    echo "[DOCKER] Lancement via Docker Compose..."
    docker compose up -d --build
    echo "✅ Conteneur ExamQuiz démarré sur http://localhost:8000"
    exit 0
fi

# Création de l'environnement virtuel si absent
if [ ! -d ".venv" ]; then
    echo "[2/5] Création de l'environnement virtuel (.venv)..."
    $PY_CMD -m venv .venv
else
    echo "[2/5] Environnement virtuel (.venv) déjà présent."
fi

# Activation du venv (Linux ou Git Bash Windows)
if [ -f ".venv/bin/activate" ]; then
    # shellcheck disable=SC1091
    source ".venv/bin/activate"
elif [ -f ".venv/Scripts/activate" ]; then
    # shellcheck disable=SC1091
    source ".venv/Scripts/activate"
fi

echo "[3/5] Installation / vérification des dépendances Python (requirements.txt)..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

echo "[4/5] Initialisation de la base de données et insertion des données de test..."
echo "      - Archivage sécurisé dans archive_data/"
echo "      - Création Admin (admin / Admin123!)"
echo "      - Création des 3 Modules (PYTHON_INIT, CRYPTO, LINUX_ADMIN) + Enseignants dédiés"
echo "      - Création des 4 Classes × 4 Étudiants = 16 Étudiants complets"
echo "      - Création des Examens Modèles pour les 3 modules"
python scripts/reset_and_seed_exact_3_exams.py

if [ "$MODE" = "--seed-only" ]; then
    echo "✅ Base de données initialisée avec succès (mode --seed-only)."
    exit 0
fi

echo "[5/5] Démarrage du serveur de production sur 0.0.0.0:8000..."
echo "=============================================================================="
echo "   🌐 Accès Local : http://127.0.0.1:8000"
echo "   🔑 Identifiants complets disponibles dans : logins.txt"
echo "=============================================================================="
exec python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000

